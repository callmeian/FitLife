<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Progress_model extends CI_Model
{
    public function get_selesai_progress($user_id)
    {
        $result = [];

        $this->db->where('status', 'selesai');
        $this->db->where('user_id', $user_id);
        $query = $this->db->get('fitness_progress');

        foreach ($query->result() as $row) {
            $result[] = [
                'id' => 'fitness_' . $row->id,
                'title' => $row->activity,
                'start' => $row->progress_date,
                'color' => '#0d6efd',
                'type' => 'fitness'
            ];
        }

        return $result;
    }

    public function get_progress_by_id($id, $user_id)
    {
        $real_id = str_replace('fitness_', '', $id);
        $this->db->where('id', $real_id);
        $this->db->where('user_id', $user_id);
        $data = $this->db->get('fitness_progress')->row();

        return [
            'type' => 'fitness',
            'data' => $data
        ];
    }

    public function get_weekly_summary($user_id)
    {
        $this->db->where('user_id', $user_id);
        $this->db->where('status', 'selesai');
        $this->db->where('progress_date >=', date('Y-m-d', strtotime('-6 days')));
        $query = $this->db->get('fitness_progress');

        $total_workouts = 0;
        $total_calories = 0;

        foreach ($query->result() as $row) {
            $total_workouts++;
            $total_calories += (int)$row->calories;
        }

        return [
            'total_workouts' => $total_workouts,
            'total_calories' => $total_calories
        ];
    }

    public function get_summary($user_id, $filter = 'week')
    {
        $this->db->select('
        COUNT(*) as total_workouts,
        COALESCE(SUM(calories), 0) as total_calories
    ');
        $this->db->where('user_id', $user_id);
        $this->db->where('status', 'selesai');

        // Filter tanggal berdasarkan pilihan filter
        switch ($filter) {
            case 'month':
                $this->db->where('progress_date >=', date('Y-m-01')); // awal bulan ini
                break;
            case 'year':
                $this->db->where('progress_date >=', date('Y-01-01')); // awal tahun ini
                break;
            case 'all':
                // tanpa filter tanggal
                break;
            default: // 'week'
                $this->db->where('progress_date >=', date('Y-m-d', strtotime('-6 days'))); // 7 hari terakhir termasuk hari ini
                break;
        }

        return $this->db->get('fitness_progress')->row();
    }

    public function get_weekly_chart_data($user_id)
    {
        $this->db->select("DATE(progress_date) as date, COUNT(*) as workouts, SUM(calories) as calories");
        $this->db->where('user_id', $user_id);
        $this->db->where('status', 'selesai');
        $this->db->where('progress_date >=', date('Y-m-d', strtotime('-6 days')));
        $this->db->group_by('DATE(progress_date)');
        $query = $this->db->get('fitness_progress')->result();

        $data = [];
        $labels = [];

        for ($i = 6; $i >= 0; $i--) {
            $day = date('Y-m-d', strtotime("-$i days"));
            $labels[] = date('D', strtotime($day));
            $data[$day] = ['workouts' => 0, 'calories' => 0];
        }

        foreach ($query as $row) {
            $data[$row->date]['workouts'] = (int)$row->workouts;
            $data[$row->date]['calories'] = (int)$row->calories;
        }

        return [
            'labels' => $labels,
            'workouts' => array_column($data, 'workouts'),
            'calories' => array_column($data, 'calories')
        ];
    }

    public function get_muscle_distribution($user_id)
    {
        $this->db->select("muscle, COUNT(*) as count");
        $this->db->where('user_id', $user_id);
        $this->db->where('status', 'selesai');
        $this->db->group_by('muscle');
        return $this->db->get('fitness_progress')->result();
    }
}
