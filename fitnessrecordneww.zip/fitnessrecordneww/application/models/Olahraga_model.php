<?php
class Olahraga_model extends CI_Model
{

    public function get_menu_by_muscle_and_level($muscle, $level)
    {
        return $this->db->get_where('menu_latihan', [
            'target_otot' => $muscle,
            'level' => $level
        ])->result();
    }

    public function get_by_id($id)
    {
        return $this->db->get_where('menu_latihan', ['id' => $id])->row();
    }

    public function insert($data)
    {
        $this->db->insert('fitness_progress', $data);
    }

    public function get_next_latihan($current_id, $muscle, $level)
    {
        $this->db->where('id >', $current_id);
        $this->db->where('target_otot', $muscle);
        $this->db->where('level', $level);
        $this->db->order_by('id', 'ASC');
        $this->db->limit(1);
        return $this->db->get('menu_latihan')->row(); // Ganti 'latihan' jika nama tabelnya berbeda
    }
}
