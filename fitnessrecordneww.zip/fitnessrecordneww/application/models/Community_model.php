<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Community_model extends CI_Model
{

    public function get_all_posts()
    {
        $this->db->select('posts.*, users.name');
        $this->db->from('posts');
        $this->db->join('users', 'users.id = posts.user_id');
        $this->db->order_by('posts.created_at', 'DESC');
        return $this->db->get()->result();
    }

    public function insert_post($user_id, $content)
    {
        $data = [
            'user_id' => $user_id,
            'content' => $content
        ];
        $this->db->insert('posts', $data);
    }

    public function get_post_by_id($id)
    {
        return $this->db->get_where('posts', ['id' => $id])->row();
    }

    public function delete_post($id)
    {
        return $this->db->delete('posts', ['id' => $id]);
    }
}
