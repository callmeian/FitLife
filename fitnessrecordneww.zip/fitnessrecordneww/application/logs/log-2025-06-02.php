<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-06-02 12:21:05 --> Config Class Initialized
INFO - 2025-06-02 12:21:05 --> Hooks Class Initialized
DEBUG - 2025-06-02 12:21:05 --> UTF-8 Support Enabled
INFO - 2025-06-02 12:21:05 --> Utf8 Class Initialized
INFO - 2025-06-02 12:21:05 --> URI Class Initialized
DEBUG - 2025-06-02 12:21:05 --> No URI present. Default controller set.
INFO - 2025-06-02 12:21:05 --> Router Class Initialized
INFO - 2025-06-02 12:21:05 --> Output Class Initialized
INFO - 2025-06-02 12:21:05 --> Security Class Initialized
DEBUG - 2025-06-02 12:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 12:21:05 --> Input Class Initialized
INFO - 2025-06-02 12:21:05 --> Language Class Initialized
INFO - 2025-06-02 12:21:05 --> Loader Class Initialized
INFO - 2025-06-02 12:21:05 --> Helper loaded: url_helper
INFO - 2025-06-02 12:21:05 --> Helper loaded: form_helper
INFO - 2025-06-02 12:21:05 --> Database Driver Class Initialized
DEBUG - 2025-06-02 12:21:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 12:21:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 12:21:06 --> Controller Class Initialized
INFO - 2025-06-02 12:21:06 --> Model "User_model" initialized
INFO - 2025-06-02 12:21:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-06-02 12:21:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-06-02 12:21:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-06-02 12:21:06 --> Final output sent to browser
DEBUG - 2025-06-02 12:21:06 --> Total execution time: 0.8456
INFO - 2025-06-02 12:32:31 --> Config Class Initialized
INFO - 2025-06-02 12:32:31 --> Hooks Class Initialized
DEBUG - 2025-06-02 12:32:31 --> UTF-8 Support Enabled
INFO - 2025-06-02 12:32:31 --> Utf8 Class Initialized
INFO - 2025-06-02 12:32:32 --> URI Class Initialized
INFO - 2025-06-02 12:32:32 --> Router Class Initialized
INFO - 2025-06-02 12:32:32 --> Output Class Initialized
INFO - 2025-06-02 12:32:32 --> Security Class Initialized
DEBUG - 2025-06-02 12:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 12:32:32 --> Input Class Initialized
INFO - 2025-06-02 12:32:32 --> Language Class Initialized
INFO - 2025-06-02 12:32:32 --> Loader Class Initialized
INFO - 2025-06-02 12:32:32 --> Helper loaded: url_helper
INFO - 2025-06-02 12:32:32 --> Helper loaded: form_helper
INFO - 2025-06-02 12:32:32 --> Database Driver Class Initialized
DEBUG - 2025-06-02 12:32:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 12:32:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 12:32:33 --> Controller Class Initialized
INFO - 2025-06-02 12:32:33 --> Model "User_model" initialized
INFO - 2025-06-02 12:32:33 --> Form Validation Class Initialized
INFO - 2025-06-02 12:32:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-06-02 12:32:33 --> Final output sent to browser
DEBUG - 2025-06-02 12:32:33 --> Total execution time: 1.8250
INFO - 2025-06-02 12:32:38 --> Config Class Initialized
INFO - 2025-06-02 12:32:38 --> Hooks Class Initialized
DEBUG - 2025-06-02 12:32:38 --> UTF-8 Support Enabled
INFO - 2025-06-02 12:32:38 --> Utf8 Class Initialized
INFO - 2025-06-02 12:32:38 --> URI Class Initialized
INFO - 2025-06-02 12:32:38 --> Router Class Initialized
INFO - 2025-06-02 12:32:38 --> Output Class Initialized
INFO - 2025-06-02 12:32:38 --> Security Class Initialized
DEBUG - 2025-06-02 12:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 12:32:38 --> Input Class Initialized
INFO - 2025-06-02 12:32:38 --> Language Class Initialized
INFO - 2025-06-02 12:32:38 --> Loader Class Initialized
INFO - 2025-06-02 12:32:38 --> Helper loaded: url_helper
INFO - 2025-06-02 12:32:38 --> Helper loaded: form_helper
INFO - 2025-06-02 12:32:38 --> Database Driver Class Initialized
DEBUG - 2025-06-02 12:32:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 12:32:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 12:32:38 --> Controller Class Initialized
INFO - 2025-06-02 12:32:38 --> Model "User_model" initialized
INFO - 2025-06-02 12:32:38 --> Form Validation Class Initialized
INFO - 2025-06-02 12:32:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-06-02 12:32:39 --> Config Class Initialized
INFO - 2025-06-02 12:32:39 --> Hooks Class Initialized
DEBUG - 2025-06-02 12:32:39 --> UTF-8 Support Enabled
INFO - 2025-06-02 12:32:39 --> Utf8 Class Initialized
INFO - 2025-06-02 12:32:39 --> URI Class Initialized
INFO - 2025-06-02 12:32:39 --> Router Class Initialized
INFO - 2025-06-02 12:32:39 --> Output Class Initialized
INFO - 2025-06-02 12:32:39 --> Security Class Initialized
DEBUG - 2025-06-02 12:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 12:32:39 --> Input Class Initialized
INFO - 2025-06-02 12:32:39 --> Language Class Initialized
INFO - 2025-06-02 12:32:39 --> Loader Class Initialized
INFO - 2025-06-02 12:32:39 --> Helper loaded: url_helper
INFO - 2025-06-02 12:32:39 --> Helper loaded: form_helper
INFO - 2025-06-02 12:32:39 --> Database Driver Class Initialized
DEBUG - 2025-06-02 12:32:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 12:32:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 12:32:39 --> Controller Class Initialized
INFO - 2025-06-02 12:32:39 --> Model "User_model" initialized
INFO - 2025-06-02 12:32:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-06-02 12:32:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-06-02 12:32:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-06-02 12:32:39 --> Final output sent to browser
DEBUG - 2025-06-02 12:32:39 --> Total execution time: 0.3408
INFO - 2025-06-02 12:32:43 --> Config Class Initialized
INFO - 2025-06-02 12:32:43 --> Hooks Class Initialized
DEBUG - 2025-06-02 12:32:43 --> UTF-8 Support Enabled
INFO - 2025-06-02 12:32:43 --> Utf8 Class Initialized
INFO - 2025-06-02 12:32:43 --> URI Class Initialized
INFO - 2025-06-02 12:32:43 --> Router Class Initialized
INFO - 2025-06-02 12:32:43 --> Output Class Initialized
INFO - 2025-06-02 12:32:43 --> Security Class Initialized
DEBUG - 2025-06-02 12:32:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 12:32:43 --> Input Class Initialized
INFO - 2025-06-02 12:32:43 --> Language Class Initialized
INFO - 2025-06-02 12:32:43 --> Loader Class Initialized
INFO - 2025-06-02 12:32:43 --> Helper loaded: url_helper
INFO - 2025-06-02 12:32:43 --> Helper loaded: form_helper
INFO - 2025-06-02 12:32:43 --> Database Driver Class Initialized
DEBUG - 2025-06-02 12:32:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 12:32:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 12:32:43 --> Controller Class Initialized
INFO - 2025-06-02 12:32:43 --> Model "User_model" initialized
INFO - 2025-06-02 12:32:43 --> Model "Progress_model" initialized
INFO - 2025-06-02 12:32:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 12:32:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 12:32:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-06-02 12:32:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 12:32:43 --> Final output sent to browser
DEBUG - 2025-06-02 12:32:43 --> Total execution time: 0.3653
INFO - 2025-06-02 12:33:05 --> Config Class Initialized
INFO - 2025-06-02 12:33:05 --> Hooks Class Initialized
DEBUG - 2025-06-02 12:33:05 --> UTF-8 Support Enabled
INFO - 2025-06-02 12:33:05 --> Utf8 Class Initialized
INFO - 2025-06-02 12:33:05 --> URI Class Initialized
INFO - 2025-06-02 12:33:05 --> Router Class Initialized
INFO - 2025-06-02 12:33:05 --> Output Class Initialized
INFO - 2025-06-02 12:33:05 --> Security Class Initialized
DEBUG - 2025-06-02 12:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 12:33:05 --> Input Class Initialized
INFO - 2025-06-02 12:33:05 --> Language Class Initialized
INFO - 2025-06-02 12:33:05 --> Loader Class Initialized
INFO - 2025-06-02 12:33:05 --> Helper loaded: url_helper
INFO - 2025-06-02 12:33:05 --> Helper loaded: form_helper
INFO - 2025-06-02 12:33:05 --> Database Driver Class Initialized
DEBUG - 2025-06-02 12:33:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 12:33:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 12:33:05 --> Controller Class Initialized
INFO - 2025-06-02 12:33:05 --> Model "User_model" initialized
INFO - 2025-06-02 12:33:05 --> Model "Progress_model" initialized
INFO - 2025-06-02 12:33:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 12:33:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 12:33:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-06-02 12:33:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 12:33:05 --> Final output sent to browser
DEBUG - 2025-06-02 12:33:05 --> Total execution time: 0.0766
INFO - 2025-06-02 12:33:24 --> Config Class Initialized
INFO - 2025-06-02 12:33:24 --> Hooks Class Initialized
DEBUG - 2025-06-02 12:33:24 --> UTF-8 Support Enabled
INFO - 2025-06-02 12:33:24 --> Utf8 Class Initialized
INFO - 2025-06-02 12:33:24 --> URI Class Initialized
INFO - 2025-06-02 12:33:24 --> Router Class Initialized
INFO - 2025-06-02 12:33:24 --> Output Class Initialized
INFO - 2025-06-02 12:33:24 --> Security Class Initialized
DEBUG - 2025-06-02 12:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 12:33:24 --> Input Class Initialized
INFO - 2025-06-02 12:33:24 --> Language Class Initialized
INFO - 2025-06-02 12:33:24 --> Loader Class Initialized
INFO - 2025-06-02 12:33:24 --> Helper loaded: url_helper
INFO - 2025-06-02 12:33:24 --> Helper loaded: form_helper
INFO - 2025-06-02 12:33:24 --> Database Driver Class Initialized
DEBUG - 2025-06-02 12:33:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 12:33:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 12:33:24 --> Controller Class Initialized
INFO - 2025-06-02 12:33:24 --> Model "User_model" initialized
INFO - 2025-06-02 12:33:24 --> Model "Progress_model" initialized
INFO - 2025-06-02 12:33:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 12:33:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 12:33:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-06-02 12:33:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 12:33:24 --> Final output sent to browser
DEBUG - 2025-06-02 12:33:24 --> Total execution time: 0.0776
INFO - 2025-06-02 12:50:06 --> Config Class Initialized
INFO - 2025-06-02 12:50:06 --> Hooks Class Initialized
DEBUG - 2025-06-02 12:50:06 --> UTF-8 Support Enabled
INFO - 2025-06-02 12:50:06 --> Utf8 Class Initialized
INFO - 2025-06-02 12:50:06 --> URI Class Initialized
INFO - 2025-06-02 12:50:06 --> Router Class Initialized
INFO - 2025-06-02 12:50:06 --> Output Class Initialized
INFO - 2025-06-02 12:50:06 --> Security Class Initialized
DEBUG - 2025-06-02 12:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 12:50:06 --> Input Class Initialized
INFO - 2025-06-02 12:50:06 --> Language Class Initialized
INFO - 2025-06-02 12:50:06 --> Loader Class Initialized
INFO - 2025-06-02 12:50:06 --> Helper loaded: url_helper
INFO - 2025-06-02 12:50:06 --> Helper loaded: form_helper
INFO - 2025-06-02 12:50:06 --> Database Driver Class Initialized
DEBUG - 2025-06-02 12:50:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 12:50:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 12:50:06 --> Controller Class Initialized
INFO - 2025-06-02 12:50:06 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 12:50:06 --> Model "User_model" initialized
INFO - 2025-06-02 12:50:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 12:50:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 12:50:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-06-02 12:50:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 12:50:06 --> Final output sent to browser
DEBUG - 2025-06-02 12:50:06 --> Total execution time: 0.1971
INFO - 2025-06-02 13:00:32 --> Config Class Initialized
INFO - 2025-06-02 13:00:32 --> Hooks Class Initialized
DEBUG - 2025-06-02 13:00:32 --> UTF-8 Support Enabled
INFO - 2025-06-02 13:00:32 --> Utf8 Class Initialized
INFO - 2025-06-02 13:00:32 --> URI Class Initialized
INFO - 2025-06-02 13:00:32 --> Router Class Initialized
INFO - 2025-06-02 13:00:32 --> Output Class Initialized
INFO - 2025-06-02 13:00:32 --> Security Class Initialized
DEBUG - 2025-06-02 13:00:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 13:00:32 --> Input Class Initialized
INFO - 2025-06-02 13:00:32 --> Language Class Initialized
INFO - 2025-06-02 13:00:32 --> Loader Class Initialized
INFO - 2025-06-02 13:00:32 --> Helper loaded: url_helper
INFO - 2025-06-02 13:00:32 --> Helper loaded: form_helper
INFO - 2025-06-02 13:00:32 --> Database Driver Class Initialized
DEBUG - 2025-06-02 13:00:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 13:00:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 13:00:33 --> Controller Class Initialized
INFO - 2025-06-02 13:00:33 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 13:00:33 --> Model "User_model" initialized
INFO - 2025-06-02 13:00:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 13:00:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 13:00:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-06-02 13:00:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 13:00:33 --> Final output sent to browser
DEBUG - 2025-06-02 13:00:33 --> Total execution time: 0.1055
INFO - 2025-06-02 13:05:49 --> Config Class Initialized
INFO - 2025-06-02 13:05:49 --> Hooks Class Initialized
DEBUG - 2025-06-02 13:05:49 --> UTF-8 Support Enabled
INFO - 2025-06-02 13:05:49 --> Utf8 Class Initialized
INFO - 2025-06-02 13:05:49 --> URI Class Initialized
INFO - 2025-06-02 13:05:49 --> Router Class Initialized
INFO - 2025-06-02 13:05:49 --> Output Class Initialized
INFO - 2025-06-02 13:05:49 --> Security Class Initialized
DEBUG - 2025-06-02 13:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 13:05:49 --> Input Class Initialized
INFO - 2025-06-02 13:05:49 --> Language Class Initialized
INFO - 2025-06-02 13:05:49 --> Loader Class Initialized
INFO - 2025-06-02 13:05:49 --> Helper loaded: url_helper
INFO - 2025-06-02 13:05:49 --> Helper loaded: form_helper
INFO - 2025-06-02 13:05:49 --> Database Driver Class Initialized
DEBUG - 2025-06-02 13:05:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 13:05:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 13:05:49 --> Controller Class Initialized
INFO - 2025-06-02 13:05:49 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 13:05:49 --> Model "User_model" initialized
INFO - 2025-06-02 13:05:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 13:05:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 13:05:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-06-02 13:05:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 13:05:49 --> Final output sent to browser
DEBUG - 2025-06-02 13:05:49 --> Total execution time: 0.0671
INFO - 2025-06-02 13:07:22 --> Config Class Initialized
INFO - 2025-06-02 13:07:22 --> Hooks Class Initialized
DEBUG - 2025-06-02 13:07:22 --> UTF-8 Support Enabled
INFO - 2025-06-02 13:07:22 --> Utf8 Class Initialized
INFO - 2025-06-02 13:07:22 --> URI Class Initialized
INFO - 2025-06-02 13:07:22 --> Router Class Initialized
INFO - 2025-06-02 13:07:22 --> Output Class Initialized
INFO - 2025-06-02 13:07:22 --> Security Class Initialized
DEBUG - 2025-06-02 13:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 13:07:22 --> Input Class Initialized
INFO - 2025-06-02 13:07:22 --> Language Class Initialized
INFO - 2025-06-02 13:07:22 --> Loader Class Initialized
INFO - 2025-06-02 13:07:22 --> Helper loaded: url_helper
INFO - 2025-06-02 13:07:22 --> Helper loaded: form_helper
INFO - 2025-06-02 13:07:22 --> Database Driver Class Initialized
DEBUG - 2025-06-02 13:07:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 13:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 13:07:22 --> Controller Class Initialized
INFO - 2025-06-02 13:07:22 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 13:07:22 --> Model "User_model" initialized
INFO - 2025-06-02 13:07:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 13:07:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 13:07:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-06-02 13:07:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 13:07:22 --> Final output sent to browser
DEBUG - 2025-06-02 13:07:22 --> Total execution time: 0.0696
INFO - 2025-06-02 13:07:41 --> Config Class Initialized
INFO - 2025-06-02 13:07:41 --> Hooks Class Initialized
DEBUG - 2025-06-02 13:07:41 --> UTF-8 Support Enabled
INFO - 2025-06-02 13:07:41 --> Utf8 Class Initialized
INFO - 2025-06-02 13:07:41 --> URI Class Initialized
INFO - 2025-06-02 13:07:41 --> Router Class Initialized
INFO - 2025-06-02 13:07:41 --> Output Class Initialized
INFO - 2025-06-02 13:07:41 --> Security Class Initialized
DEBUG - 2025-06-02 13:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 13:07:41 --> Input Class Initialized
INFO - 2025-06-02 13:07:41 --> Language Class Initialized
INFO - 2025-06-02 13:07:41 --> Loader Class Initialized
INFO - 2025-06-02 13:07:41 --> Helper loaded: url_helper
INFO - 2025-06-02 13:07:41 --> Helper loaded: form_helper
INFO - 2025-06-02 13:07:41 --> Database Driver Class Initialized
DEBUG - 2025-06-02 13:07:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 13:07:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 13:07:41 --> Controller Class Initialized
INFO - 2025-06-02 13:07:41 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 13:07:41 --> Model "User_model" initialized
INFO - 2025-06-02 13:07:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 13:07:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 13:07:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-06-02 13:07:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 13:07:41 --> Final output sent to browser
DEBUG - 2025-06-02 13:07:41 --> Total execution time: 0.0835
INFO - 2025-06-02 13:08:06 --> Config Class Initialized
INFO - 2025-06-02 13:08:06 --> Hooks Class Initialized
DEBUG - 2025-06-02 13:08:06 --> UTF-8 Support Enabled
INFO - 2025-06-02 13:08:06 --> Utf8 Class Initialized
INFO - 2025-06-02 13:08:06 --> URI Class Initialized
INFO - 2025-06-02 13:08:06 --> Router Class Initialized
INFO - 2025-06-02 13:08:06 --> Output Class Initialized
INFO - 2025-06-02 13:08:06 --> Security Class Initialized
DEBUG - 2025-06-02 13:08:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 13:08:06 --> Input Class Initialized
INFO - 2025-06-02 13:08:06 --> Language Class Initialized
INFO - 2025-06-02 13:08:06 --> Loader Class Initialized
INFO - 2025-06-02 13:08:06 --> Helper loaded: url_helper
INFO - 2025-06-02 13:08:06 --> Helper loaded: form_helper
INFO - 2025-06-02 13:08:06 --> Database Driver Class Initialized
DEBUG - 2025-06-02 13:08:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 13:08:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 13:08:06 --> Controller Class Initialized
INFO - 2025-06-02 13:08:06 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 13:08:06 --> Model "User_model" initialized
INFO - 2025-06-02 13:08:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 13:08:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 13:08:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-06-02 13:08:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 13:08:06 --> Final output sent to browser
DEBUG - 2025-06-02 13:08:06 --> Total execution time: 0.0869
INFO - 2025-06-02 13:10:21 --> Config Class Initialized
INFO - 2025-06-02 13:10:21 --> Hooks Class Initialized
DEBUG - 2025-06-02 13:10:21 --> UTF-8 Support Enabled
INFO - 2025-06-02 13:10:21 --> Utf8 Class Initialized
INFO - 2025-06-02 13:10:21 --> URI Class Initialized
INFO - 2025-06-02 13:10:21 --> Router Class Initialized
INFO - 2025-06-02 13:10:21 --> Output Class Initialized
INFO - 2025-06-02 13:10:21 --> Security Class Initialized
DEBUG - 2025-06-02 13:10:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 13:10:21 --> Input Class Initialized
INFO - 2025-06-02 13:10:21 --> Language Class Initialized
INFO - 2025-06-02 13:10:21 --> Loader Class Initialized
INFO - 2025-06-02 13:10:21 --> Helper loaded: url_helper
INFO - 2025-06-02 13:10:21 --> Helper loaded: form_helper
INFO - 2025-06-02 13:10:21 --> Database Driver Class Initialized
DEBUG - 2025-06-02 13:10:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 13:10:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 13:10:21 --> Controller Class Initialized
INFO - 2025-06-02 13:10:21 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 13:10:21 --> Model "User_model" initialized
INFO - 2025-06-02 13:10:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 13:10:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 13:10:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-06-02 13:10:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 13:10:21 --> Final output sent to browser
DEBUG - 2025-06-02 13:10:21 --> Total execution time: 0.0657
INFO - 2025-06-02 13:10:48 --> Config Class Initialized
INFO - 2025-06-02 13:10:48 --> Hooks Class Initialized
DEBUG - 2025-06-02 13:10:48 --> UTF-8 Support Enabled
INFO - 2025-06-02 13:10:48 --> Utf8 Class Initialized
INFO - 2025-06-02 13:10:48 --> URI Class Initialized
INFO - 2025-06-02 13:10:48 --> Router Class Initialized
INFO - 2025-06-02 13:10:48 --> Output Class Initialized
INFO - 2025-06-02 13:10:48 --> Security Class Initialized
DEBUG - 2025-06-02 13:10:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 13:10:48 --> Input Class Initialized
INFO - 2025-06-02 13:10:48 --> Language Class Initialized
INFO - 2025-06-02 13:10:48 --> Loader Class Initialized
INFO - 2025-06-02 13:10:48 --> Helper loaded: url_helper
INFO - 2025-06-02 13:10:48 --> Helper loaded: form_helper
INFO - 2025-06-02 13:10:48 --> Database Driver Class Initialized
DEBUG - 2025-06-02 13:10:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 13:10:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 13:10:48 --> Controller Class Initialized
INFO - 2025-06-02 13:10:48 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 13:10:48 --> Model "User_model" initialized
INFO - 2025-06-02 13:10:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 13:10:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 13:10:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-06-02 13:10:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 13:10:48 --> Final output sent to browser
DEBUG - 2025-06-02 13:10:48 --> Total execution time: 0.0939
INFO - 2025-06-02 13:13:51 --> Config Class Initialized
INFO - 2025-06-02 13:13:51 --> Hooks Class Initialized
DEBUG - 2025-06-02 13:13:51 --> UTF-8 Support Enabled
INFO - 2025-06-02 13:13:51 --> Utf8 Class Initialized
INFO - 2025-06-02 13:13:51 --> URI Class Initialized
INFO - 2025-06-02 13:13:51 --> Router Class Initialized
INFO - 2025-06-02 13:13:51 --> Output Class Initialized
INFO - 2025-06-02 13:13:51 --> Security Class Initialized
DEBUG - 2025-06-02 13:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 13:13:51 --> Input Class Initialized
INFO - 2025-06-02 13:13:51 --> Language Class Initialized
INFO - 2025-06-02 13:13:51 --> Loader Class Initialized
INFO - 2025-06-02 13:13:51 --> Helper loaded: url_helper
INFO - 2025-06-02 13:13:51 --> Helper loaded: form_helper
INFO - 2025-06-02 13:13:51 --> Database Driver Class Initialized
DEBUG - 2025-06-02 13:13:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 13:13:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 13:13:51 --> Controller Class Initialized
INFO - 2025-06-02 13:13:51 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 13:13:51 --> Model "User_model" initialized
INFO - 2025-06-02 13:13:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 13:13:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 13:13:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-06-02 13:13:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 13:13:51 --> Final output sent to browser
DEBUG - 2025-06-02 13:13:51 --> Total execution time: 0.0790
INFO - 2025-06-02 13:17:01 --> Config Class Initialized
INFO - 2025-06-02 13:17:01 --> Hooks Class Initialized
DEBUG - 2025-06-02 13:17:01 --> UTF-8 Support Enabled
INFO - 2025-06-02 13:17:01 --> Utf8 Class Initialized
INFO - 2025-06-02 13:17:01 --> URI Class Initialized
INFO - 2025-06-02 13:17:01 --> Router Class Initialized
INFO - 2025-06-02 13:17:01 --> Output Class Initialized
INFO - 2025-06-02 13:17:01 --> Security Class Initialized
DEBUG - 2025-06-02 13:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 13:17:01 --> Input Class Initialized
INFO - 2025-06-02 13:17:01 --> Language Class Initialized
INFO - 2025-06-02 13:17:01 --> Loader Class Initialized
INFO - 2025-06-02 13:17:01 --> Helper loaded: url_helper
INFO - 2025-06-02 13:17:01 --> Helper loaded: form_helper
INFO - 2025-06-02 13:17:01 --> Database Driver Class Initialized
DEBUG - 2025-06-02 13:17:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 13:17:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 13:17:01 --> Controller Class Initialized
INFO - 2025-06-02 13:17:01 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 13:17:01 --> Model "User_model" initialized
INFO - 2025-06-02 13:17:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 13:17:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 13:17:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-06-02 13:17:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 13:17:01 --> Final output sent to browser
DEBUG - 2025-06-02 13:17:01 --> Total execution time: 0.0887
INFO - 2025-06-02 13:17:35 --> Config Class Initialized
INFO - 2025-06-02 13:17:35 --> Hooks Class Initialized
DEBUG - 2025-06-02 13:17:35 --> UTF-8 Support Enabled
INFO - 2025-06-02 13:17:35 --> Utf8 Class Initialized
INFO - 2025-06-02 13:17:35 --> URI Class Initialized
INFO - 2025-06-02 13:17:35 --> Router Class Initialized
INFO - 2025-06-02 13:17:35 --> Output Class Initialized
INFO - 2025-06-02 13:17:35 --> Security Class Initialized
DEBUG - 2025-06-02 13:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 13:17:35 --> Input Class Initialized
INFO - 2025-06-02 13:17:35 --> Language Class Initialized
INFO - 2025-06-02 13:17:35 --> Loader Class Initialized
INFO - 2025-06-02 13:17:35 --> Helper loaded: url_helper
INFO - 2025-06-02 13:17:35 --> Helper loaded: form_helper
INFO - 2025-06-02 13:17:35 --> Database Driver Class Initialized
DEBUG - 2025-06-02 13:17:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 13:17:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 13:17:35 --> Controller Class Initialized
INFO - 2025-06-02 13:17:35 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 13:17:35 --> Model "User_model" initialized
INFO - 2025-06-02 13:17:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-06-02 13:17:35 --> Final output sent to browser
DEBUG - 2025-06-02 13:17:35 --> Total execution time: 0.0621
INFO - 2025-06-02 13:19:10 --> Config Class Initialized
INFO - 2025-06-02 13:19:10 --> Hooks Class Initialized
DEBUG - 2025-06-02 13:19:10 --> UTF-8 Support Enabled
INFO - 2025-06-02 13:19:10 --> Utf8 Class Initialized
INFO - 2025-06-02 13:19:10 --> URI Class Initialized
INFO - 2025-06-02 13:19:10 --> Router Class Initialized
INFO - 2025-06-02 13:19:10 --> Output Class Initialized
INFO - 2025-06-02 13:19:10 --> Security Class Initialized
DEBUG - 2025-06-02 13:19:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 13:19:10 --> Input Class Initialized
INFO - 2025-06-02 13:19:10 --> Language Class Initialized
INFO - 2025-06-02 13:19:10 --> Loader Class Initialized
INFO - 2025-06-02 13:19:10 --> Helper loaded: url_helper
INFO - 2025-06-02 13:19:10 --> Helper loaded: form_helper
INFO - 2025-06-02 13:19:10 --> Database Driver Class Initialized
DEBUG - 2025-06-02 13:19:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 13:19:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 13:19:10 --> Controller Class Initialized
INFO - 2025-06-02 13:19:10 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 13:19:10 --> Model "User_model" initialized
INFO - 2025-06-02 13:19:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-06-02 13:19:10 --> Final output sent to browser
DEBUG - 2025-06-02 13:19:10 --> Total execution time: 0.0697
INFO - 2025-06-02 13:19:23 --> Config Class Initialized
INFO - 2025-06-02 13:19:23 --> Hooks Class Initialized
DEBUG - 2025-06-02 13:19:23 --> UTF-8 Support Enabled
INFO - 2025-06-02 13:19:23 --> Utf8 Class Initialized
INFO - 2025-06-02 13:19:23 --> URI Class Initialized
INFO - 2025-06-02 13:19:23 --> Router Class Initialized
INFO - 2025-06-02 13:19:23 --> Output Class Initialized
INFO - 2025-06-02 13:19:23 --> Security Class Initialized
DEBUG - 2025-06-02 13:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 13:19:23 --> Input Class Initialized
INFO - 2025-06-02 13:19:23 --> Language Class Initialized
INFO - 2025-06-02 13:19:23 --> Loader Class Initialized
INFO - 2025-06-02 13:19:23 --> Helper loaded: url_helper
INFO - 2025-06-02 13:19:23 --> Helper loaded: form_helper
INFO - 2025-06-02 13:19:23 --> Database Driver Class Initialized
DEBUG - 2025-06-02 13:19:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 13:19:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 13:19:23 --> Controller Class Initialized
INFO - 2025-06-02 13:19:23 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 13:19:23 --> Model "User_model" initialized
INFO - 2025-06-02 13:19:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 13:19:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 13:19:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-06-02 13:19:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 13:19:23 --> Final output sent to browser
DEBUG - 2025-06-02 13:19:23 --> Total execution time: 0.0624
INFO - 2025-06-02 13:19:56 --> Config Class Initialized
INFO - 2025-06-02 13:19:56 --> Hooks Class Initialized
DEBUG - 2025-06-02 13:19:56 --> UTF-8 Support Enabled
INFO - 2025-06-02 13:19:56 --> Utf8 Class Initialized
INFO - 2025-06-02 13:19:56 --> URI Class Initialized
INFO - 2025-06-02 13:19:56 --> Router Class Initialized
INFO - 2025-06-02 13:19:56 --> Output Class Initialized
INFO - 2025-06-02 13:19:56 --> Security Class Initialized
DEBUG - 2025-06-02 13:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 13:19:56 --> Input Class Initialized
INFO - 2025-06-02 13:19:56 --> Language Class Initialized
INFO - 2025-06-02 13:19:56 --> Loader Class Initialized
INFO - 2025-06-02 13:19:56 --> Helper loaded: url_helper
INFO - 2025-06-02 13:19:56 --> Helper loaded: form_helper
INFO - 2025-06-02 13:19:56 --> Database Driver Class Initialized
DEBUG - 2025-06-02 13:19:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 13:19:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 13:19:56 --> Controller Class Initialized
INFO - 2025-06-02 13:19:56 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 13:19:56 --> Model "User_model" initialized
INFO - 2025-06-02 13:19:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 13:19:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 13:19:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-06-02 13:19:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 13:19:56 --> Final output sent to browser
DEBUG - 2025-06-02 13:19:56 --> Total execution time: 0.0654
INFO - 2025-06-02 13:20:24 --> Config Class Initialized
INFO - 2025-06-02 13:20:24 --> Hooks Class Initialized
DEBUG - 2025-06-02 13:20:24 --> UTF-8 Support Enabled
INFO - 2025-06-02 13:20:24 --> Utf8 Class Initialized
INFO - 2025-06-02 13:20:24 --> URI Class Initialized
INFO - 2025-06-02 13:20:24 --> Router Class Initialized
INFO - 2025-06-02 13:20:24 --> Output Class Initialized
INFO - 2025-06-02 13:20:24 --> Security Class Initialized
DEBUG - 2025-06-02 13:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 13:20:24 --> Input Class Initialized
INFO - 2025-06-02 13:20:24 --> Language Class Initialized
INFO - 2025-06-02 13:20:24 --> Loader Class Initialized
INFO - 2025-06-02 13:20:24 --> Helper loaded: url_helper
INFO - 2025-06-02 13:20:24 --> Helper loaded: form_helper
INFO - 2025-06-02 13:20:24 --> Database Driver Class Initialized
DEBUG - 2025-06-02 13:20:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 13:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 13:20:24 --> Controller Class Initialized
INFO - 2025-06-02 13:20:24 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 13:20:24 --> Model "User_model" initialized
INFO - 2025-06-02 13:20:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 13:20:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 13:20:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-06-02 13:20:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 13:20:24 --> Final output sent to browser
DEBUG - 2025-06-02 13:20:24 --> Total execution time: 0.0678
INFO - 2025-06-02 13:20:41 --> Config Class Initialized
INFO - 2025-06-02 13:20:41 --> Hooks Class Initialized
DEBUG - 2025-06-02 13:20:41 --> UTF-8 Support Enabled
INFO - 2025-06-02 13:20:41 --> Utf8 Class Initialized
INFO - 2025-06-02 13:20:41 --> URI Class Initialized
INFO - 2025-06-02 13:20:41 --> Router Class Initialized
INFO - 2025-06-02 13:20:41 --> Output Class Initialized
INFO - 2025-06-02 13:20:41 --> Security Class Initialized
DEBUG - 2025-06-02 13:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 13:20:41 --> Input Class Initialized
INFO - 2025-06-02 13:20:41 --> Language Class Initialized
INFO - 2025-06-02 13:20:41 --> Loader Class Initialized
INFO - 2025-06-02 13:20:41 --> Helper loaded: url_helper
INFO - 2025-06-02 13:20:41 --> Helper loaded: form_helper
INFO - 2025-06-02 13:20:41 --> Database Driver Class Initialized
DEBUG - 2025-06-02 13:20:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 13:20:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 13:20:41 --> Controller Class Initialized
INFO - 2025-06-02 13:20:41 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 13:20:41 --> Model "User_model" initialized
INFO - 2025-06-02 13:20:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 13:20:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 13:20:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-06-02 13:20:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 13:20:41 --> Final output sent to browser
DEBUG - 2025-06-02 13:20:41 --> Total execution time: 0.1066
INFO - 2025-06-02 13:20:52 --> Config Class Initialized
INFO - 2025-06-02 13:20:52 --> Hooks Class Initialized
DEBUG - 2025-06-02 13:20:52 --> UTF-8 Support Enabled
INFO - 2025-06-02 13:20:52 --> Utf8 Class Initialized
INFO - 2025-06-02 13:20:52 --> URI Class Initialized
INFO - 2025-06-02 13:20:52 --> Router Class Initialized
INFO - 2025-06-02 13:20:52 --> Output Class Initialized
INFO - 2025-06-02 13:20:52 --> Security Class Initialized
DEBUG - 2025-06-02 13:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 13:20:52 --> Input Class Initialized
INFO - 2025-06-02 13:20:52 --> Language Class Initialized
INFO - 2025-06-02 13:20:52 --> Loader Class Initialized
INFO - 2025-06-02 13:20:52 --> Helper loaded: url_helper
INFO - 2025-06-02 13:20:52 --> Helper loaded: form_helper
INFO - 2025-06-02 13:20:52 --> Database Driver Class Initialized
DEBUG - 2025-06-02 13:20:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 13:20:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 13:20:52 --> Controller Class Initialized
INFO - 2025-06-02 13:20:52 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 13:20:52 --> Model "User_model" initialized
INFO - 2025-06-02 13:20:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 13:20:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 13:20:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-06-02 13:20:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 13:20:52 --> Final output sent to browser
DEBUG - 2025-06-02 13:20:52 --> Total execution time: 0.0660
INFO - 2025-06-02 13:21:23 --> Config Class Initialized
INFO - 2025-06-02 13:21:23 --> Hooks Class Initialized
DEBUG - 2025-06-02 13:21:23 --> UTF-8 Support Enabled
INFO - 2025-06-02 13:21:23 --> Utf8 Class Initialized
INFO - 2025-06-02 13:21:23 --> URI Class Initialized
INFO - 2025-06-02 13:21:23 --> Router Class Initialized
INFO - 2025-06-02 13:21:23 --> Output Class Initialized
INFO - 2025-06-02 13:21:23 --> Security Class Initialized
DEBUG - 2025-06-02 13:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 13:21:23 --> Input Class Initialized
INFO - 2025-06-02 13:21:23 --> Language Class Initialized
INFO - 2025-06-02 13:21:23 --> Loader Class Initialized
INFO - 2025-06-02 13:21:23 --> Helper loaded: url_helper
INFO - 2025-06-02 13:21:23 --> Helper loaded: form_helper
INFO - 2025-06-02 13:21:23 --> Database Driver Class Initialized
DEBUG - 2025-06-02 13:21:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 13:21:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 13:21:23 --> Controller Class Initialized
INFO - 2025-06-02 13:21:23 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 13:21:23 --> Model "User_model" initialized
INFO - 2025-06-02 13:21:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 13:21:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 13:21:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-06-02 13:21:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 13:21:23 --> Final output sent to browser
DEBUG - 2025-06-02 13:21:23 --> Total execution time: 0.0831
INFO - 2025-06-02 13:23:29 --> Config Class Initialized
INFO - 2025-06-02 13:23:29 --> Hooks Class Initialized
DEBUG - 2025-06-02 13:23:29 --> UTF-8 Support Enabled
INFO - 2025-06-02 13:23:29 --> Utf8 Class Initialized
INFO - 2025-06-02 13:23:29 --> URI Class Initialized
INFO - 2025-06-02 13:23:29 --> Router Class Initialized
INFO - 2025-06-02 13:23:29 --> Output Class Initialized
INFO - 2025-06-02 13:23:29 --> Security Class Initialized
DEBUG - 2025-06-02 13:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 13:23:29 --> Input Class Initialized
INFO - 2025-06-02 13:23:29 --> Language Class Initialized
INFO - 2025-06-02 13:23:29 --> Loader Class Initialized
INFO - 2025-06-02 13:23:29 --> Helper loaded: url_helper
INFO - 2025-06-02 13:23:29 --> Helper loaded: form_helper
INFO - 2025-06-02 13:23:29 --> Database Driver Class Initialized
DEBUG - 2025-06-02 13:23:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 13:23:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 13:23:29 --> Controller Class Initialized
INFO - 2025-06-02 13:23:29 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 13:23:29 --> Model "User_model" initialized
INFO - 2025-06-02 13:23:29 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 13:23:29 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 13:23:29 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-06-02 13:23:29 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 13:23:29 --> Final output sent to browser
DEBUG - 2025-06-02 13:23:29 --> Total execution time: 0.0867
INFO - 2025-06-02 13:23:47 --> Config Class Initialized
INFO - 2025-06-02 13:23:47 --> Hooks Class Initialized
DEBUG - 2025-06-02 13:23:47 --> UTF-8 Support Enabled
INFO - 2025-06-02 13:23:47 --> Utf8 Class Initialized
INFO - 2025-06-02 13:23:47 --> URI Class Initialized
INFO - 2025-06-02 13:23:47 --> Router Class Initialized
INFO - 2025-06-02 13:23:47 --> Output Class Initialized
INFO - 2025-06-02 13:23:47 --> Security Class Initialized
DEBUG - 2025-06-02 13:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 13:23:47 --> Input Class Initialized
INFO - 2025-06-02 13:23:47 --> Language Class Initialized
INFO - 2025-06-02 13:23:47 --> Loader Class Initialized
INFO - 2025-06-02 13:23:47 --> Helper loaded: url_helper
INFO - 2025-06-02 13:23:47 --> Helper loaded: form_helper
INFO - 2025-06-02 13:23:47 --> Database Driver Class Initialized
DEBUG - 2025-06-02 13:23:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 13:23:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 13:23:47 --> Controller Class Initialized
INFO - 2025-06-02 13:23:47 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 13:23:47 --> Model "User_model" initialized
INFO - 2025-06-02 13:23:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 13:23:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 13:23:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-06-02 13:23:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 13:23:47 --> Final output sent to browser
DEBUG - 2025-06-02 13:23:47 --> Total execution time: 0.0866
INFO - 2025-06-02 13:26:04 --> Config Class Initialized
INFO - 2025-06-02 13:26:04 --> Hooks Class Initialized
DEBUG - 2025-06-02 13:26:04 --> UTF-8 Support Enabled
INFO - 2025-06-02 13:26:04 --> Utf8 Class Initialized
INFO - 2025-06-02 13:26:04 --> URI Class Initialized
INFO - 2025-06-02 13:26:04 --> Router Class Initialized
INFO - 2025-06-02 13:26:04 --> Output Class Initialized
INFO - 2025-06-02 13:26:04 --> Security Class Initialized
DEBUG - 2025-06-02 13:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 13:26:04 --> Input Class Initialized
INFO - 2025-06-02 13:26:04 --> Language Class Initialized
INFO - 2025-06-02 13:26:04 --> Loader Class Initialized
INFO - 2025-06-02 13:26:04 --> Helper loaded: url_helper
INFO - 2025-06-02 13:26:04 --> Helper loaded: form_helper
INFO - 2025-06-02 13:26:04 --> Database Driver Class Initialized
DEBUG - 2025-06-02 13:26:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 13:26:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 13:26:04 --> Controller Class Initialized
INFO - 2025-06-02 13:26:04 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 13:26:04 --> Model "User_model" initialized
INFO - 2025-06-02 13:26:04 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 13:26:04 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 13:26:04 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-06-02 13:26:04 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 13:26:04 --> Final output sent to browser
DEBUG - 2025-06-02 13:26:04 --> Total execution time: 0.0831
INFO - 2025-06-02 13:26:20 --> Config Class Initialized
INFO - 2025-06-02 13:26:20 --> Hooks Class Initialized
DEBUG - 2025-06-02 13:26:20 --> UTF-8 Support Enabled
INFO - 2025-06-02 13:26:20 --> Utf8 Class Initialized
INFO - 2025-06-02 13:26:20 --> URI Class Initialized
INFO - 2025-06-02 13:26:20 --> Router Class Initialized
INFO - 2025-06-02 13:26:20 --> Output Class Initialized
INFO - 2025-06-02 13:26:20 --> Security Class Initialized
DEBUG - 2025-06-02 13:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 13:26:20 --> Input Class Initialized
INFO - 2025-06-02 13:26:20 --> Language Class Initialized
INFO - 2025-06-02 13:26:20 --> Loader Class Initialized
INFO - 2025-06-02 13:26:20 --> Helper loaded: url_helper
INFO - 2025-06-02 13:26:20 --> Helper loaded: form_helper
INFO - 2025-06-02 13:26:20 --> Database Driver Class Initialized
DEBUG - 2025-06-02 13:26:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 13:26:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 13:26:20 --> Controller Class Initialized
INFO - 2025-06-02 13:26:20 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 13:26:20 --> Model "User_model" initialized
INFO - 2025-06-02 13:26:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 13:26:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 13:26:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-06-02 13:26:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 13:26:20 --> Final output sent to browser
DEBUG - 2025-06-02 13:26:20 --> Total execution time: 0.0640
INFO - 2025-06-02 13:26:32 --> Config Class Initialized
INFO - 2025-06-02 13:26:32 --> Hooks Class Initialized
DEBUG - 2025-06-02 13:26:32 --> UTF-8 Support Enabled
INFO - 2025-06-02 13:26:32 --> Utf8 Class Initialized
INFO - 2025-06-02 13:26:32 --> URI Class Initialized
INFO - 2025-06-02 13:26:32 --> Router Class Initialized
INFO - 2025-06-02 13:26:32 --> Output Class Initialized
INFO - 2025-06-02 13:26:32 --> Security Class Initialized
DEBUG - 2025-06-02 13:26:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 13:26:32 --> Input Class Initialized
INFO - 2025-06-02 13:26:32 --> Language Class Initialized
INFO - 2025-06-02 13:26:32 --> Loader Class Initialized
INFO - 2025-06-02 13:26:32 --> Helper loaded: url_helper
INFO - 2025-06-02 13:26:32 --> Helper loaded: form_helper
INFO - 2025-06-02 13:26:32 --> Database Driver Class Initialized
DEBUG - 2025-06-02 13:26:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 13:26:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 13:26:32 --> Controller Class Initialized
INFO - 2025-06-02 13:26:32 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 13:26:32 --> Model "User_model" initialized
INFO - 2025-06-02 13:26:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 13:26:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 13:26:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-06-02 13:26:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 13:26:32 --> Final output sent to browser
DEBUG - 2025-06-02 13:26:32 --> Total execution time: 0.0781
INFO - 2025-06-02 13:28:24 --> Config Class Initialized
INFO - 2025-06-02 13:28:24 --> Hooks Class Initialized
DEBUG - 2025-06-02 13:28:24 --> UTF-8 Support Enabled
INFO - 2025-06-02 13:28:24 --> Utf8 Class Initialized
INFO - 2025-06-02 13:28:24 --> URI Class Initialized
INFO - 2025-06-02 13:28:24 --> Router Class Initialized
INFO - 2025-06-02 13:28:24 --> Output Class Initialized
INFO - 2025-06-02 13:28:24 --> Security Class Initialized
DEBUG - 2025-06-02 13:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 13:28:24 --> Input Class Initialized
INFO - 2025-06-02 13:28:24 --> Language Class Initialized
INFO - 2025-06-02 13:28:24 --> Loader Class Initialized
INFO - 2025-06-02 13:28:24 --> Helper loaded: url_helper
INFO - 2025-06-02 13:28:24 --> Helper loaded: form_helper
INFO - 2025-06-02 13:28:24 --> Database Driver Class Initialized
DEBUG - 2025-06-02 13:28:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 13:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 13:28:24 --> Controller Class Initialized
INFO - 2025-06-02 13:28:24 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 13:28:24 --> Model "User_model" initialized
INFO - 2025-06-02 13:28:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 13:28:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 13:28:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-06-02 13:28:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 13:28:24 --> Final output sent to browser
DEBUG - 2025-06-02 13:28:24 --> Total execution time: 0.0743
INFO - 2025-06-02 13:28:26 --> Config Class Initialized
INFO - 2025-06-02 13:28:26 --> Hooks Class Initialized
DEBUG - 2025-06-02 13:28:26 --> UTF-8 Support Enabled
INFO - 2025-06-02 13:28:26 --> Utf8 Class Initialized
INFO - 2025-06-02 13:28:26 --> URI Class Initialized
INFO - 2025-06-02 13:28:26 --> Router Class Initialized
INFO - 2025-06-02 13:28:26 --> Output Class Initialized
INFO - 2025-06-02 13:28:26 --> Security Class Initialized
DEBUG - 2025-06-02 13:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 13:28:26 --> Input Class Initialized
INFO - 2025-06-02 13:28:26 --> Language Class Initialized
INFO - 2025-06-02 13:28:26 --> Loader Class Initialized
INFO - 2025-06-02 13:28:26 --> Helper loaded: url_helper
INFO - 2025-06-02 13:28:26 --> Helper loaded: form_helper
INFO - 2025-06-02 13:28:26 --> Database Driver Class Initialized
DEBUG - 2025-06-02 13:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 13:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 13:28:26 --> Controller Class Initialized
INFO - 2025-06-02 13:28:26 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 13:28:26 --> Model "User_model" initialized
INFO - 2025-06-02 13:28:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 13:28:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 13:28:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-06-02 13:28:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 13:28:26 --> Final output sent to browser
DEBUG - 2025-06-02 13:28:26 --> Total execution time: 0.0637
INFO - 2025-06-02 13:28:26 --> Config Class Initialized
INFO - 2025-06-02 13:28:26 --> Hooks Class Initialized
DEBUG - 2025-06-02 13:28:26 --> UTF-8 Support Enabled
INFO - 2025-06-02 13:28:26 --> Utf8 Class Initialized
INFO - 2025-06-02 13:28:26 --> URI Class Initialized
INFO - 2025-06-02 13:28:26 --> Router Class Initialized
INFO - 2025-06-02 13:28:26 --> Output Class Initialized
INFO - 2025-06-02 13:28:26 --> Security Class Initialized
DEBUG - 2025-06-02 13:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 13:28:26 --> Input Class Initialized
INFO - 2025-06-02 13:28:26 --> Language Class Initialized
INFO - 2025-06-02 13:28:26 --> Loader Class Initialized
INFO - 2025-06-02 13:28:26 --> Helper loaded: url_helper
INFO - 2025-06-02 13:28:26 --> Helper loaded: form_helper
INFO - 2025-06-02 13:28:26 --> Database Driver Class Initialized
DEBUG - 2025-06-02 13:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 13:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 13:28:26 --> Controller Class Initialized
INFO - 2025-06-02 13:28:26 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 13:28:26 --> Model "User_model" initialized
INFO - 2025-06-02 13:28:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 13:28:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 13:28:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-06-02 13:28:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 13:28:26 --> Final output sent to browser
DEBUG - 2025-06-02 13:28:26 --> Total execution time: 0.0693
INFO - 2025-06-02 13:28:27 --> Config Class Initialized
INFO - 2025-06-02 13:28:27 --> Hooks Class Initialized
DEBUG - 2025-06-02 13:28:27 --> UTF-8 Support Enabled
INFO - 2025-06-02 13:28:27 --> Utf8 Class Initialized
INFO - 2025-06-02 13:28:27 --> URI Class Initialized
INFO - 2025-06-02 13:28:27 --> Router Class Initialized
INFO - 2025-06-02 13:28:27 --> Output Class Initialized
INFO - 2025-06-02 13:28:27 --> Security Class Initialized
DEBUG - 2025-06-02 13:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 13:28:27 --> Input Class Initialized
INFO - 2025-06-02 13:28:27 --> Language Class Initialized
INFO - 2025-06-02 13:28:27 --> Loader Class Initialized
INFO - 2025-06-02 13:28:27 --> Helper loaded: url_helper
INFO - 2025-06-02 13:28:27 --> Helper loaded: form_helper
INFO - 2025-06-02 13:28:27 --> Database Driver Class Initialized
DEBUG - 2025-06-02 13:28:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 13:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 13:28:27 --> Controller Class Initialized
INFO - 2025-06-02 13:28:27 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 13:28:27 --> Model "User_model" initialized
INFO - 2025-06-02 13:28:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 13:28:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 13:28:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-06-02 13:28:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 13:28:27 --> Final output sent to browser
DEBUG - 2025-06-02 13:28:27 --> Total execution time: 0.0587
INFO - 2025-06-02 13:30:01 --> Config Class Initialized
INFO - 2025-06-02 13:30:01 --> Hooks Class Initialized
DEBUG - 2025-06-02 13:30:01 --> UTF-8 Support Enabled
INFO - 2025-06-02 13:30:01 --> Utf8 Class Initialized
INFO - 2025-06-02 13:30:01 --> URI Class Initialized
INFO - 2025-06-02 13:30:01 --> Router Class Initialized
INFO - 2025-06-02 13:30:01 --> Output Class Initialized
INFO - 2025-06-02 13:30:01 --> Security Class Initialized
DEBUG - 2025-06-02 13:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 13:30:01 --> Input Class Initialized
INFO - 2025-06-02 13:30:01 --> Language Class Initialized
INFO - 2025-06-02 13:30:01 --> Loader Class Initialized
INFO - 2025-06-02 13:30:01 --> Helper loaded: url_helper
INFO - 2025-06-02 13:30:01 --> Helper loaded: form_helper
INFO - 2025-06-02 13:30:01 --> Database Driver Class Initialized
DEBUG - 2025-06-02 13:30:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 13:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 13:30:01 --> Controller Class Initialized
INFO - 2025-06-02 13:30:01 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 13:30:01 --> Model "User_model" initialized
INFO - 2025-06-02 13:30:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 13:30:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 13:30:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-06-02 13:30:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 13:30:01 --> Final output sent to browser
DEBUG - 2025-06-02 13:30:01 --> Total execution time: 0.0691
INFO - 2025-06-02 13:32:09 --> Config Class Initialized
INFO - 2025-06-02 13:32:09 --> Hooks Class Initialized
DEBUG - 2025-06-02 13:32:09 --> UTF-8 Support Enabled
INFO - 2025-06-02 13:32:09 --> Utf8 Class Initialized
INFO - 2025-06-02 13:32:09 --> URI Class Initialized
INFO - 2025-06-02 13:32:09 --> Router Class Initialized
INFO - 2025-06-02 13:32:09 --> Output Class Initialized
INFO - 2025-06-02 13:32:09 --> Security Class Initialized
DEBUG - 2025-06-02 13:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 13:32:09 --> Input Class Initialized
INFO - 2025-06-02 13:32:09 --> Language Class Initialized
INFO - 2025-06-02 13:32:09 --> Loader Class Initialized
INFO - 2025-06-02 13:32:09 --> Helper loaded: url_helper
INFO - 2025-06-02 13:32:09 --> Helper loaded: form_helper
INFO - 2025-06-02 13:32:09 --> Database Driver Class Initialized
DEBUG - 2025-06-02 13:32:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 13:32:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 13:32:09 --> Controller Class Initialized
INFO - 2025-06-02 13:32:09 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 13:32:09 --> Model "User_model" initialized
INFO - 2025-06-02 13:32:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 13:32:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 13:32:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-06-02 13:32:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 13:32:10 --> Final output sent to browser
DEBUG - 2025-06-02 13:32:10 --> Total execution time: 0.0730
INFO - 2025-06-02 13:32:58 --> Config Class Initialized
INFO - 2025-06-02 13:32:58 --> Hooks Class Initialized
DEBUG - 2025-06-02 13:32:58 --> UTF-8 Support Enabled
INFO - 2025-06-02 13:32:58 --> Utf8 Class Initialized
INFO - 2025-06-02 13:32:58 --> URI Class Initialized
INFO - 2025-06-02 13:32:58 --> Router Class Initialized
INFO - 2025-06-02 13:32:58 --> Output Class Initialized
INFO - 2025-06-02 13:32:58 --> Security Class Initialized
DEBUG - 2025-06-02 13:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 13:32:58 --> Input Class Initialized
INFO - 2025-06-02 13:32:58 --> Language Class Initialized
INFO - 2025-06-02 13:32:58 --> Loader Class Initialized
INFO - 2025-06-02 13:32:58 --> Helper loaded: url_helper
INFO - 2025-06-02 13:32:58 --> Helper loaded: form_helper
INFO - 2025-06-02 13:32:58 --> Database Driver Class Initialized
DEBUG - 2025-06-02 13:32:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 13:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 13:32:58 --> Controller Class Initialized
INFO - 2025-06-02 13:32:58 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 13:32:58 --> Model "User_model" initialized
INFO - 2025-06-02 13:32:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 13:32:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 13:32:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-06-02 13:32:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 13:32:58 --> Final output sent to browser
DEBUG - 2025-06-02 13:32:58 --> Total execution time: 0.0668
INFO - 2025-06-02 13:33:36 --> Config Class Initialized
INFO - 2025-06-02 13:33:36 --> Hooks Class Initialized
DEBUG - 2025-06-02 13:33:36 --> UTF-8 Support Enabled
INFO - 2025-06-02 13:33:36 --> Utf8 Class Initialized
INFO - 2025-06-02 13:33:36 --> URI Class Initialized
INFO - 2025-06-02 13:33:36 --> Router Class Initialized
INFO - 2025-06-02 13:33:36 --> Output Class Initialized
INFO - 2025-06-02 13:33:36 --> Security Class Initialized
DEBUG - 2025-06-02 13:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 13:33:36 --> Input Class Initialized
INFO - 2025-06-02 13:33:36 --> Language Class Initialized
INFO - 2025-06-02 13:33:36 --> Loader Class Initialized
INFO - 2025-06-02 13:33:36 --> Helper loaded: url_helper
INFO - 2025-06-02 13:33:36 --> Helper loaded: form_helper
INFO - 2025-06-02 13:33:36 --> Database Driver Class Initialized
DEBUG - 2025-06-02 13:33:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 13:33:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 13:33:36 --> Controller Class Initialized
INFO - 2025-06-02 13:33:36 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 13:33:36 --> Model "User_model" initialized
INFO - 2025-06-02 13:33:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 13:33:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 13:33:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-06-02 13:33:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 13:33:36 --> Final output sent to browser
DEBUG - 2025-06-02 13:33:36 --> Total execution time: 0.0665
INFO - 2025-06-02 13:35:11 --> Config Class Initialized
INFO - 2025-06-02 13:35:11 --> Hooks Class Initialized
DEBUG - 2025-06-02 13:35:11 --> UTF-8 Support Enabled
INFO - 2025-06-02 13:35:11 --> Utf8 Class Initialized
INFO - 2025-06-02 13:35:11 --> URI Class Initialized
INFO - 2025-06-02 13:35:11 --> Router Class Initialized
INFO - 2025-06-02 13:35:11 --> Output Class Initialized
INFO - 2025-06-02 13:35:11 --> Security Class Initialized
DEBUG - 2025-06-02 13:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 13:35:11 --> Input Class Initialized
INFO - 2025-06-02 13:35:11 --> Language Class Initialized
INFO - 2025-06-02 13:35:11 --> Loader Class Initialized
INFO - 2025-06-02 13:35:11 --> Helper loaded: url_helper
INFO - 2025-06-02 13:35:11 --> Helper loaded: form_helper
INFO - 2025-06-02 13:35:11 --> Database Driver Class Initialized
DEBUG - 2025-06-02 13:35:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 13:35:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 13:35:11 --> Controller Class Initialized
INFO - 2025-06-02 13:35:11 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 13:35:11 --> Model "User_model" initialized
INFO - 2025-06-02 13:35:11 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 13:35:11 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 13:35:11 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-06-02 13:35:11 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 13:35:11 --> Final output sent to browser
DEBUG - 2025-06-02 13:35:11 --> Total execution time: 0.0668
INFO - 2025-06-02 13:35:16 --> Config Class Initialized
INFO - 2025-06-02 13:35:16 --> Hooks Class Initialized
DEBUG - 2025-06-02 13:35:16 --> UTF-8 Support Enabled
INFO - 2025-06-02 13:35:16 --> Utf8 Class Initialized
INFO - 2025-06-02 13:35:16 --> URI Class Initialized
INFO - 2025-06-02 13:35:16 --> Router Class Initialized
INFO - 2025-06-02 13:35:16 --> Output Class Initialized
INFO - 2025-06-02 13:35:16 --> Security Class Initialized
DEBUG - 2025-06-02 13:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 13:35:16 --> Input Class Initialized
INFO - 2025-06-02 13:35:16 --> Language Class Initialized
INFO - 2025-06-02 13:35:16 --> Loader Class Initialized
INFO - 2025-06-02 13:35:16 --> Helper loaded: url_helper
INFO - 2025-06-02 13:35:16 --> Helper loaded: form_helper
INFO - 2025-06-02 13:35:16 --> Database Driver Class Initialized
DEBUG - 2025-06-02 13:35:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 13:35:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 13:35:16 --> Controller Class Initialized
INFO - 2025-06-02 13:35:16 --> Model "Progress_model" initialized
INFO - 2025-06-02 13:35:16 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 13:35:16 --> Model "User_model" initialized
INFO - 2025-06-02 13:35:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 13:35:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 13:35:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-06-02 13:35:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 13:35:16 --> Final output sent to browser
DEBUG - 2025-06-02 13:35:16 --> Total execution time: 0.1393
INFO - 2025-06-02 13:35:17 --> Config Class Initialized
INFO - 2025-06-02 13:35:17 --> Hooks Class Initialized
DEBUG - 2025-06-02 13:35:17 --> UTF-8 Support Enabled
INFO - 2025-06-02 13:35:17 --> Utf8 Class Initialized
INFO - 2025-06-02 13:35:17 --> URI Class Initialized
INFO - 2025-06-02 13:35:17 --> Router Class Initialized
INFO - 2025-06-02 13:35:17 --> Output Class Initialized
INFO - 2025-06-02 13:35:17 --> Security Class Initialized
DEBUG - 2025-06-02 13:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 13:35:17 --> Input Class Initialized
INFO - 2025-06-02 13:35:17 --> Language Class Initialized
INFO - 2025-06-02 13:35:17 --> Loader Class Initialized
INFO - 2025-06-02 13:35:17 --> Helper loaded: url_helper
INFO - 2025-06-02 13:35:17 --> Helper loaded: form_helper
INFO - 2025-06-02 13:35:17 --> Database Driver Class Initialized
DEBUG - 2025-06-02 13:35:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 13:35:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 13:35:17 --> Controller Class Initialized
INFO - 2025-06-02 13:35:17 --> Model "Progress_model" initialized
INFO - 2025-06-02 13:35:17 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 13:35:17 --> Model "User_model" initialized
INFO - 2025-06-02 13:35:17 --> Final output sent to browser
DEBUG - 2025-06-02 13:35:17 --> Total execution time: 0.0732
INFO - 2025-06-02 13:35:18 --> Config Class Initialized
INFO - 2025-06-02 13:35:18 --> Hooks Class Initialized
DEBUG - 2025-06-02 13:35:18 --> UTF-8 Support Enabled
INFO - 2025-06-02 13:35:18 --> Utf8 Class Initialized
INFO - 2025-06-02 13:35:18 --> URI Class Initialized
INFO - 2025-06-02 13:35:18 --> Router Class Initialized
INFO - 2025-06-02 13:35:18 --> Output Class Initialized
INFO - 2025-06-02 13:35:18 --> Security Class Initialized
DEBUG - 2025-06-02 13:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 13:35:18 --> Input Class Initialized
INFO - 2025-06-02 13:35:18 --> Language Class Initialized
INFO - 2025-06-02 13:35:18 --> Loader Class Initialized
INFO - 2025-06-02 13:35:18 --> Helper loaded: url_helper
INFO - 2025-06-02 13:35:18 --> Helper loaded: form_helper
INFO - 2025-06-02 13:35:18 --> Database Driver Class Initialized
DEBUG - 2025-06-02 13:35:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 13:35:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 13:35:18 --> Controller Class Initialized
INFO - 2025-06-02 13:35:18 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 13:35:18 --> Model "User_model" initialized
INFO - 2025-06-02 13:35:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 13:35:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 13:35:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-06-02 13:35:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 13:35:18 --> Final output sent to browser
DEBUG - 2025-06-02 13:35:18 --> Total execution time: 0.0599
INFO - 2025-06-02 13:35:20 --> Config Class Initialized
INFO - 2025-06-02 13:35:20 --> Hooks Class Initialized
DEBUG - 2025-06-02 13:35:20 --> UTF-8 Support Enabled
INFO - 2025-06-02 13:35:20 --> Utf8 Class Initialized
INFO - 2025-06-02 13:35:20 --> URI Class Initialized
INFO - 2025-06-02 13:35:20 --> Router Class Initialized
INFO - 2025-06-02 13:35:20 --> Output Class Initialized
INFO - 2025-06-02 13:35:20 --> Security Class Initialized
DEBUG - 2025-06-02 13:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 13:35:20 --> Input Class Initialized
INFO - 2025-06-02 13:35:20 --> Language Class Initialized
INFO - 2025-06-02 13:35:20 --> Loader Class Initialized
INFO - 2025-06-02 13:35:20 --> Helper loaded: url_helper
INFO - 2025-06-02 13:35:20 --> Helper loaded: form_helper
INFO - 2025-06-02 13:35:20 --> Database Driver Class Initialized
DEBUG - 2025-06-02 13:35:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 13:35:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 13:35:20 --> Controller Class Initialized
INFO - 2025-06-02 13:35:20 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 13:35:20 --> Model "User_model" initialized
INFO - 2025-06-02 13:35:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 13:35:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 13:35:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-06-02 13:35:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 13:35:20 --> Final output sent to browser
DEBUG - 2025-06-02 13:35:20 --> Total execution time: 0.0716
INFO - 2025-06-02 13:35:24 --> Config Class Initialized
INFO - 2025-06-02 13:35:24 --> Hooks Class Initialized
DEBUG - 2025-06-02 13:35:24 --> UTF-8 Support Enabled
INFO - 2025-06-02 13:35:24 --> Utf8 Class Initialized
INFO - 2025-06-02 13:35:24 --> URI Class Initialized
INFO - 2025-06-02 13:35:24 --> Router Class Initialized
INFO - 2025-06-02 13:35:24 --> Output Class Initialized
INFO - 2025-06-02 13:35:24 --> Security Class Initialized
DEBUG - 2025-06-02 13:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 13:35:24 --> Input Class Initialized
INFO - 2025-06-02 13:35:24 --> Language Class Initialized
INFO - 2025-06-02 13:35:24 --> Loader Class Initialized
INFO - 2025-06-02 13:35:24 --> Helper loaded: url_helper
INFO - 2025-06-02 13:35:24 --> Helper loaded: form_helper
INFO - 2025-06-02 13:35:24 --> Database Driver Class Initialized
DEBUG - 2025-06-02 13:35:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 13:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 13:35:24 --> Controller Class Initialized
INFO - 2025-06-02 13:35:24 --> Model "Progress_model" initialized
INFO - 2025-06-02 13:35:24 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 13:35:24 --> Model "User_model" initialized
INFO - 2025-06-02 13:35:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 13:35:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 13:35:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-06-02 13:35:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 13:35:24 --> Final output sent to browser
DEBUG - 2025-06-02 13:35:24 --> Total execution time: 0.0688
INFO - 2025-06-02 13:35:25 --> Config Class Initialized
INFO - 2025-06-02 13:35:25 --> Hooks Class Initialized
DEBUG - 2025-06-02 13:35:25 --> UTF-8 Support Enabled
INFO - 2025-06-02 13:35:25 --> Utf8 Class Initialized
INFO - 2025-06-02 13:35:25 --> URI Class Initialized
INFO - 2025-06-02 13:35:25 --> Router Class Initialized
INFO - 2025-06-02 13:35:25 --> Output Class Initialized
INFO - 2025-06-02 13:35:25 --> Security Class Initialized
DEBUG - 2025-06-02 13:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 13:35:25 --> Input Class Initialized
INFO - 2025-06-02 13:35:25 --> Language Class Initialized
INFO - 2025-06-02 13:35:25 --> Loader Class Initialized
INFO - 2025-06-02 13:35:25 --> Helper loaded: url_helper
INFO - 2025-06-02 13:35:25 --> Helper loaded: form_helper
INFO - 2025-06-02 13:35:25 --> Database Driver Class Initialized
DEBUG - 2025-06-02 13:35:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 13:35:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 13:35:25 --> Controller Class Initialized
INFO - 2025-06-02 13:35:25 --> Model "Progress_model" initialized
INFO - 2025-06-02 13:35:25 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 13:35:25 --> Model "User_model" initialized
INFO - 2025-06-02 13:35:25 --> Final output sent to browser
DEBUG - 2025-06-02 13:35:25 --> Total execution time: 0.0778
INFO - 2025-06-02 13:35:26 --> Config Class Initialized
INFO - 2025-06-02 13:35:26 --> Hooks Class Initialized
DEBUG - 2025-06-02 13:35:26 --> UTF-8 Support Enabled
INFO - 2025-06-02 13:35:26 --> Utf8 Class Initialized
INFO - 2025-06-02 13:35:26 --> URI Class Initialized
INFO - 2025-06-02 13:35:26 --> Router Class Initialized
INFO - 2025-06-02 13:35:26 --> Output Class Initialized
INFO - 2025-06-02 13:35:26 --> Security Class Initialized
DEBUG - 2025-06-02 13:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 13:35:26 --> Input Class Initialized
INFO - 2025-06-02 13:35:26 --> Language Class Initialized
INFO - 2025-06-02 13:35:26 --> Loader Class Initialized
INFO - 2025-06-02 13:35:26 --> Helper loaded: url_helper
INFO - 2025-06-02 13:35:26 --> Helper loaded: form_helper
INFO - 2025-06-02 13:35:26 --> Database Driver Class Initialized
DEBUG - 2025-06-02 13:35:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 13:35:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 13:35:26 --> Controller Class Initialized
INFO - 2025-06-02 13:35:26 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 13:35:26 --> Model "User_model" initialized
INFO - 2025-06-02 13:35:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 13:35:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 13:35:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-06-02 13:35:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 13:35:26 --> Final output sent to browser
DEBUG - 2025-06-02 13:35:26 --> Total execution time: 0.0814
INFO - 2025-06-02 13:35:28 --> Config Class Initialized
INFO - 2025-06-02 13:35:28 --> Hooks Class Initialized
DEBUG - 2025-06-02 13:35:28 --> UTF-8 Support Enabled
INFO - 2025-06-02 13:35:28 --> Utf8 Class Initialized
INFO - 2025-06-02 13:35:28 --> URI Class Initialized
INFO - 2025-06-02 13:35:28 --> Router Class Initialized
INFO - 2025-06-02 13:35:28 --> Output Class Initialized
INFO - 2025-06-02 13:35:28 --> Security Class Initialized
DEBUG - 2025-06-02 13:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 13:35:28 --> Input Class Initialized
INFO - 2025-06-02 13:35:28 --> Language Class Initialized
INFO - 2025-06-02 13:35:28 --> Loader Class Initialized
INFO - 2025-06-02 13:35:28 --> Helper loaded: url_helper
INFO - 2025-06-02 13:35:28 --> Helper loaded: form_helper
INFO - 2025-06-02 13:35:28 --> Database Driver Class Initialized
DEBUG - 2025-06-02 13:35:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 13:35:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 13:35:28 --> Controller Class Initialized
INFO - 2025-06-02 13:35:28 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 13:35:28 --> Model "User_model" initialized
INFO - 2025-06-02 13:35:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 13:35:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 13:35:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-06-02 13:35:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 13:35:28 --> Final output sent to browser
DEBUG - 2025-06-02 13:35:28 --> Total execution time: 0.0676
INFO - 2025-06-02 13:35:43 --> Config Class Initialized
INFO - 2025-06-02 13:35:43 --> Hooks Class Initialized
DEBUG - 2025-06-02 13:35:43 --> UTF-8 Support Enabled
INFO - 2025-06-02 13:35:43 --> Utf8 Class Initialized
INFO - 2025-06-02 13:35:43 --> URI Class Initialized
INFO - 2025-06-02 13:35:43 --> Router Class Initialized
INFO - 2025-06-02 13:35:43 --> Output Class Initialized
INFO - 2025-06-02 13:35:43 --> Security Class Initialized
DEBUG - 2025-06-02 13:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 13:35:43 --> Input Class Initialized
INFO - 2025-06-02 13:35:43 --> Language Class Initialized
INFO - 2025-06-02 13:35:43 --> Loader Class Initialized
INFO - 2025-06-02 13:35:43 --> Helper loaded: url_helper
INFO - 2025-06-02 13:35:43 --> Helper loaded: form_helper
INFO - 2025-06-02 13:35:43 --> Database Driver Class Initialized
DEBUG - 2025-06-02 13:35:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 13:35:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 13:35:43 --> Controller Class Initialized
INFO - 2025-06-02 13:35:43 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 13:35:43 --> Model "User_model" initialized
INFO - 2025-06-02 13:35:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 13:35:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 13:35:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-06-02 13:35:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 13:35:43 --> Final output sent to browser
DEBUG - 2025-06-02 13:35:43 --> Total execution time: 0.0649
INFO - 2025-06-02 13:36:00 --> Config Class Initialized
INFO - 2025-06-02 13:36:00 --> Hooks Class Initialized
DEBUG - 2025-06-02 13:36:00 --> UTF-8 Support Enabled
INFO - 2025-06-02 13:36:00 --> Utf8 Class Initialized
INFO - 2025-06-02 13:36:00 --> URI Class Initialized
INFO - 2025-06-02 13:36:00 --> Router Class Initialized
INFO - 2025-06-02 13:36:00 --> Output Class Initialized
INFO - 2025-06-02 13:36:00 --> Security Class Initialized
DEBUG - 2025-06-02 13:36:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 13:36:00 --> Input Class Initialized
INFO - 2025-06-02 13:36:00 --> Language Class Initialized
INFO - 2025-06-02 13:36:00 --> Loader Class Initialized
INFO - 2025-06-02 13:36:00 --> Helper loaded: url_helper
INFO - 2025-06-02 13:36:00 --> Helper loaded: form_helper
INFO - 2025-06-02 13:36:00 --> Database Driver Class Initialized
DEBUG - 2025-06-02 13:36:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 13:36:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 13:36:00 --> Controller Class Initialized
INFO - 2025-06-02 13:36:00 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 13:36:00 --> Model "User_model" initialized
INFO - 2025-06-02 13:36:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 13:36:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 13:36:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-06-02 13:36:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 13:36:00 --> Final output sent to browser
DEBUG - 2025-06-02 13:36:00 --> Total execution time: 0.0778
INFO - 2025-06-02 13:36:11 --> Config Class Initialized
INFO - 2025-06-02 13:36:11 --> Hooks Class Initialized
DEBUG - 2025-06-02 13:36:11 --> UTF-8 Support Enabled
INFO - 2025-06-02 13:36:11 --> Utf8 Class Initialized
INFO - 2025-06-02 13:36:11 --> URI Class Initialized
INFO - 2025-06-02 13:36:11 --> Router Class Initialized
INFO - 2025-06-02 13:36:11 --> Output Class Initialized
INFO - 2025-06-02 13:36:11 --> Security Class Initialized
DEBUG - 2025-06-02 13:36:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 13:36:11 --> Input Class Initialized
INFO - 2025-06-02 13:36:11 --> Language Class Initialized
INFO - 2025-06-02 13:36:11 --> Loader Class Initialized
INFO - 2025-06-02 13:36:11 --> Helper loaded: url_helper
INFO - 2025-06-02 13:36:11 --> Helper loaded: form_helper
INFO - 2025-06-02 13:36:11 --> Database Driver Class Initialized
DEBUG - 2025-06-02 13:36:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 13:36:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 13:36:11 --> Controller Class Initialized
INFO - 2025-06-02 13:36:11 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 13:36:11 --> Model "User_model" initialized
INFO - 2025-06-02 13:36:11 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 13:36:11 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 13:36:11 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/menu.php
INFO - 2025-06-02 13:36:11 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 13:36:11 --> Final output sent to browser
DEBUG - 2025-06-02 13:36:11 --> Total execution time: 0.1487
INFO - 2025-06-02 13:38:15 --> Config Class Initialized
INFO - 2025-06-02 13:38:15 --> Hooks Class Initialized
DEBUG - 2025-06-02 13:38:15 --> UTF-8 Support Enabled
INFO - 2025-06-02 13:38:15 --> Utf8 Class Initialized
INFO - 2025-06-02 13:38:15 --> URI Class Initialized
INFO - 2025-06-02 13:38:15 --> Router Class Initialized
INFO - 2025-06-02 13:38:15 --> Output Class Initialized
INFO - 2025-06-02 13:38:15 --> Security Class Initialized
DEBUG - 2025-06-02 13:38:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 13:38:15 --> Input Class Initialized
INFO - 2025-06-02 13:38:15 --> Language Class Initialized
INFO - 2025-06-02 13:38:15 --> Loader Class Initialized
INFO - 2025-06-02 13:38:15 --> Helper loaded: url_helper
INFO - 2025-06-02 13:38:15 --> Helper loaded: form_helper
INFO - 2025-06-02 13:38:15 --> Database Driver Class Initialized
DEBUG - 2025-06-02 13:38:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 13:38:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 13:38:15 --> Controller Class Initialized
INFO - 2025-06-02 13:38:15 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 13:38:15 --> Model "User_model" initialized
INFO - 2025-06-02 13:38:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 13:38:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 13:38:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/menu.php
INFO - 2025-06-02 13:38:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 13:38:15 --> Final output sent to browser
DEBUG - 2025-06-02 13:38:15 --> Total execution time: 0.0867
INFO - 2025-06-02 13:40:15 --> Config Class Initialized
INFO - 2025-06-02 13:40:15 --> Hooks Class Initialized
DEBUG - 2025-06-02 13:40:15 --> UTF-8 Support Enabled
INFO - 2025-06-02 13:40:15 --> Utf8 Class Initialized
INFO - 2025-06-02 13:40:15 --> URI Class Initialized
INFO - 2025-06-02 13:40:15 --> Router Class Initialized
INFO - 2025-06-02 13:40:15 --> Output Class Initialized
INFO - 2025-06-02 13:40:15 --> Security Class Initialized
DEBUG - 2025-06-02 13:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 13:40:15 --> Input Class Initialized
INFO - 2025-06-02 13:40:15 --> Language Class Initialized
INFO - 2025-06-02 13:40:15 --> Loader Class Initialized
INFO - 2025-06-02 13:40:15 --> Helper loaded: url_helper
INFO - 2025-06-02 13:40:15 --> Helper loaded: form_helper
INFO - 2025-06-02 13:40:15 --> Database Driver Class Initialized
DEBUG - 2025-06-02 13:40:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 13:40:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 13:40:15 --> Controller Class Initialized
INFO - 2025-06-02 13:40:15 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 13:40:15 --> Model "User_model" initialized
INFO - 2025-06-02 13:40:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 13:40:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 13:40:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/menu.php
INFO - 2025-06-02 13:40:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 13:40:15 --> Final output sent to browser
DEBUG - 2025-06-02 13:40:15 --> Total execution time: 0.0700
INFO - 2025-06-02 13:40:19 --> Config Class Initialized
INFO - 2025-06-02 13:40:19 --> Hooks Class Initialized
DEBUG - 2025-06-02 13:40:19 --> UTF-8 Support Enabled
INFO - 2025-06-02 13:40:19 --> Utf8 Class Initialized
INFO - 2025-06-02 13:40:19 --> URI Class Initialized
INFO - 2025-06-02 13:40:19 --> Router Class Initialized
INFO - 2025-06-02 13:40:19 --> Output Class Initialized
INFO - 2025-06-02 13:40:19 --> Security Class Initialized
DEBUG - 2025-06-02 13:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 13:40:19 --> Input Class Initialized
INFO - 2025-06-02 13:40:19 --> Language Class Initialized
INFO - 2025-06-02 13:40:19 --> Loader Class Initialized
INFO - 2025-06-02 13:40:19 --> Helper loaded: url_helper
INFO - 2025-06-02 13:40:19 --> Helper loaded: form_helper
INFO - 2025-06-02 13:40:19 --> Database Driver Class Initialized
DEBUG - 2025-06-02 13:40:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 13:40:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 13:40:19 --> Controller Class Initialized
INFO - 2025-06-02 13:40:19 --> Model "Progress_model" initialized
INFO - 2025-06-02 13:40:19 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 13:40:19 --> Model "User_model" initialized
INFO - 2025-06-02 13:40:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 13:40:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 13:40:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-06-02 13:40:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 13:40:19 --> Final output sent to browser
DEBUG - 2025-06-02 13:40:19 --> Total execution time: 0.0859
INFO - 2025-06-02 13:40:20 --> Config Class Initialized
INFO - 2025-06-02 13:40:20 --> Hooks Class Initialized
DEBUG - 2025-06-02 13:40:20 --> UTF-8 Support Enabled
INFO - 2025-06-02 13:40:20 --> Utf8 Class Initialized
INFO - 2025-06-02 13:40:20 --> URI Class Initialized
INFO - 2025-06-02 13:40:20 --> Router Class Initialized
INFO - 2025-06-02 13:40:20 --> Output Class Initialized
INFO - 2025-06-02 13:40:20 --> Security Class Initialized
DEBUG - 2025-06-02 13:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 13:40:20 --> Input Class Initialized
INFO - 2025-06-02 13:40:20 --> Language Class Initialized
INFO - 2025-06-02 13:40:20 --> Loader Class Initialized
INFO - 2025-06-02 13:40:20 --> Helper loaded: url_helper
INFO - 2025-06-02 13:40:20 --> Helper loaded: form_helper
INFO - 2025-06-02 13:40:20 --> Database Driver Class Initialized
DEBUG - 2025-06-02 13:40:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 13:40:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 13:40:20 --> Controller Class Initialized
INFO - 2025-06-02 13:40:20 --> Model "Progress_model" initialized
INFO - 2025-06-02 13:40:20 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 13:40:20 --> Model "User_model" initialized
INFO - 2025-06-02 13:40:20 --> Final output sent to browser
DEBUG - 2025-06-02 13:40:20 --> Total execution time: 0.0661
INFO - 2025-06-02 13:40:20 --> Config Class Initialized
INFO - 2025-06-02 13:40:20 --> Hooks Class Initialized
DEBUG - 2025-06-02 13:40:20 --> UTF-8 Support Enabled
INFO - 2025-06-02 13:40:20 --> Utf8 Class Initialized
INFO - 2025-06-02 13:40:20 --> URI Class Initialized
INFO - 2025-06-02 13:40:20 --> Router Class Initialized
INFO - 2025-06-02 13:40:20 --> Output Class Initialized
INFO - 2025-06-02 13:40:20 --> Security Class Initialized
DEBUG - 2025-06-02 13:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 13:40:20 --> Input Class Initialized
INFO - 2025-06-02 13:40:20 --> Language Class Initialized
INFO - 2025-06-02 13:40:20 --> Loader Class Initialized
INFO - 2025-06-02 13:40:20 --> Helper loaded: url_helper
INFO - 2025-06-02 13:40:20 --> Helper loaded: form_helper
INFO - 2025-06-02 13:40:20 --> Database Driver Class Initialized
DEBUG - 2025-06-02 13:40:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 13:40:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 13:40:20 --> Controller Class Initialized
INFO - 2025-06-02 13:40:20 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 13:40:20 --> Model "User_model" initialized
INFO - 2025-06-02 13:40:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 13:40:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 13:40:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-06-02 13:40:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 13:40:20 --> Final output sent to browser
DEBUG - 2025-06-02 13:40:20 --> Total execution time: 0.0663
INFO - 2025-06-02 13:40:22 --> Config Class Initialized
INFO - 2025-06-02 13:40:22 --> Hooks Class Initialized
DEBUG - 2025-06-02 13:40:22 --> UTF-8 Support Enabled
INFO - 2025-06-02 13:40:22 --> Utf8 Class Initialized
INFO - 2025-06-02 13:40:22 --> URI Class Initialized
INFO - 2025-06-02 13:40:22 --> Router Class Initialized
INFO - 2025-06-02 13:40:22 --> Output Class Initialized
INFO - 2025-06-02 13:40:22 --> Security Class Initialized
DEBUG - 2025-06-02 13:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 13:40:22 --> Input Class Initialized
INFO - 2025-06-02 13:40:22 --> Language Class Initialized
INFO - 2025-06-02 13:40:22 --> Loader Class Initialized
INFO - 2025-06-02 13:40:22 --> Helper loaded: url_helper
INFO - 2025-06-02 13:40:22 --> Helper loaded: form_helper
INFO - 2025-06-02 13:40:22 --> Database Driver Class Initialized
DEBUG - 2025-06-02 13:40:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 13:40:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 13:40:22 --> Controller Class Initialized
INFO - 2025-06-02 13:40:22 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 13:40:22 --> Model "User_model" initialized
INFO - 2025-06-02 13:40:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 13:40:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 13:40:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-06-02 13:40:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 13:40:22 --> Final output sent to browser
DEBUG - 2025-06-02 13:40:22 --> Total execution time: 0.0682
INFO - 2025-06-02 13:40:24 --> Config Class Initialized
INFO - 2025-06-02 13:40:24 --> Hooks Class Initialized
DEBUG - 2025-06-02 13:40:24 --> UTF-8 Support Enabled
INFO - 2025-06-02 13:40:24 --> Utf8 Class Initialized
INFO - 2025-06-02 13:40:24 --> URI Class Initialized
INFO - 2025-06-02 13:40:24 --> Router Class Initialized
INFO - 2025-06-02 13:40:24 --> Output Class Initialized
INFO - 2025-06-02 13:40:24 --> Security Class Initialized
DEBUG - 2025-06-02 13:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 13:40:24 --> Input Class Initialized
INFO - 2025-06-02 13:40:24 --> Language Class Initialized
INFO - 2025-06-02 13:40:24 --> Loader Class Initialized
INFO - 2025-06-02 13:40:24 --> Helper loaded: url_helper
INFO - 2025-06-02 13:40:24 --> Helper loaded: form_helper
INFO - 2025-06-02 13:40:24 --> Database Driver Class Initialized
DEBUG - 2025-06-02 13:40:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 13:40:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 13:40:24 --> Controller Class Initialized
INFO - 2025-06-02 13:40:24 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 13:40:24 --> Model "User_model" initialized
INFO - 2025-06-02 13:40:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 13:40:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 13:40:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/menu.php
INFO - 2025-06-02 13:40:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 13:40:24 --> Final output sent to browser
DEBUG - 2025-06-02 13:40:24 --> Total execution time: 0.1053
INFO - 2025-06-02 13:53:35 --> Config Class Initialized
INFO - 2025-06-02 13:53:35 --> Hooks Class Initialized
DEBUG - 2025-06-02 13:53:35 --> UTF-8 Support Enabled
INFO - 2025-06-02 13:53:35 --> Utf8 Class Initialized
INFO - 2025-06-02 13:53:35 --> URI Class Initialized
INFO - 2025-06-02 13:53:35 --> Router Class Initialized
INFO - 2025-06-02 13:53:35 --> Output Class Initialized
INFO - 2025-06-02 13:53:35 --> Security Class Initialized
DEBUG - 2025-06-02 13:53:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 13:53:35 --> Input Class Initialized
INFO - 2025-06-02 13:53:35 --> Language Class Initialized
INFO - 2025-06-02 13:53:35 --> Loader Class Initialized
INFO - 2025-06-02 13:53:35 --> Helper loaded: url_helper
INFO - 2025-06-02 13:53:35 --> Helper loaded: form_helper
INFO - 2025-06-02 13:53:35 --> Database Driver Class Initialized
DEBUG - 2025-06-02 13:53:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 13:53:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 13:53:35 --> Controller Class Initialized
INFO - 2025-06-02 13:53:35 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 13:53:35 --> Model "User_model" initialized
INFO - 2025-06-02 13:53:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 13:53:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 13:53:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/menu.php
INFO - 2025-06-02 13:53:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 13:53:35 --> Final output sent to browser
DEBUG - 2025-06-02 13:53:35 --> Total execution time: 0.0882
INFO - 2025-06-02 13:54:04 --> Config Class Initialized
INFO - 2025-06-02 13:54:04 --> Hooks Class Initialized
DEBUG - 2025-06-02 13:54:04 --> UTF-8 Support Enabled
INFO - 2025-06-02 13:54:04 --> Utf8 Class Initialized
INFO - 2025-06-02 13:54:04 --> URI Class Initialized
INFO - 2025-06-02 13:54:04 --> Router Class Initialized
INFO - 2025-06-02 13:54:04 --> Output Class Initialized
INFO - 2025-06-02 13:54:04 --> Security Class Initialized
DEBUG - 2025-06-02 13:54:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 13:54:04 --> Input Class Initialized
INFO - 2025-06-02 13:54:04 --> Language Class Initialized
INFO - 2025-06-02 13:54:04 --> Loader Class Initialized
INFO - 2025-06-02 13:54:04 --> Helper loaded: url_helper
INFO - 2025-06-02 13:54:05 --> Helper loaded: form_helper
INFO - 2025-06-02 13:54:05 --> Database Driver Class Initialized
DEBUG - 2025-06-02 13:54:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 13:54:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 13:54:05 --> Controller Class Initialized
INFO - 2025-06-02 13:54:05 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 13:54:05 --> Model "User_model" initialized
INFO - 2025-06-02 13:54:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 13:54:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 13:54:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/menu.php
INFO - 2025-06-02 13:54:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 13:54:05 --> Final output sent to browser
DEBUG - 2025-06-02 13:54:05 --> Total execution time: 0.0755
INFO - 2025-06-02 13:55:25 --> Config Class Initialized
INFO - 2025-06-02 13:55:25 --> Hooks Class Initialized
DEBUG - 2025-06-02 13:55:25 --> UTF-8 Support Enabled
INFO - 2025-06-02 13:55:25 --> Utf8 Class Initialized
INFO - 2025-06-02 13:55:25 --> URI Class Initialized
INFO - 2025-06-02 13:55:25 --> Router Class Initialized
INFO - 2025-06-02 13:55:25 --> Output Class Initialized
INFO - 2025-06-02 13:55:25 --> Security Class Initialized
DEBUG - 2025-06-02 13:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 13:55:25 --> Input Class Initialized
INFO - 2025-06-02 13:55:25 --> Language Class Initialized
INFO - 2025-06-02 13:55:25 --> Loader Class Initialized
INFO - 2025-06-02 13:55:25 --> Helper loaded: url_helper
INFO - 2025-06-02 13:55:25 --> Helper loaded: form_helper
INFO - 2025-06-02 13:55:25 --> Database Driver Class Initialized
DEBUG - 2025-06-02 13:55:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 13:55:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 13:55:25 --> Controller Class Initialized
INFO - 2025-06-02 13:55:25 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 13:55:25 --> Model "User_model" initialized
INFO - 2025-06-02 13:55:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 13:55:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 13:55:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/menu.php
INFO - 2025-06-02 13:55:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 13:55:25 --> Final output sent to browser
DEBUG - 2025-06-02 13:55:25 --> Total execution time: 0.0907
INFO - 2025-06-02 13:55:45 --> Config Class Initialized
INFO - 2025-06-02 13:55:45 --> Hooks Class Initialized
DEBUG - 2025-06-02 13:55:45 --> UTF-8 Support Enabled
INFO - 2025-06-02 13:55:45 --> Utf8 Class Initialized
INFO - 2025-06-02 13:55:45 --> URI Class Initialized
INFO - 2025-06-02 13:55:45 --> Router Class Initialized
INFO - 2025-06-02 13:55:45 --> Output Class Initialized
INFO - 2025-06-02 13:55:45 --> Security Class Initialized
DEBUG - 2025-06-02 13:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 13:55:45 --> Input Class Initialized
INFO - 2025-06-02 13:55:45 --> Language Class Initialized
INFO - 2025-06-02 13:55:45 --> Loader Class Initialized
INFO - 2025-06-02 13:55:45 --> Helper loaded: url_helper
INFO - 2025-06-02 13:55:45 --> Helper loaded: form_helper
INFO - 2025-06-02 13:55:45 --> Database Driver Class Initialized
DEBUG - 2025-06-02 13:55:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 13:55:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 13:55:45 --> Controller Class Initialized
INFO - 2025-06-02 13:55:45 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 13:55:45 --> Model "User_model" initialized
INFO - 2025-06-02 13:55:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 13:55:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 13:55:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/menu.php
INFO - 2025-06-02 13:55:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 13:55:45 --> Final output sent to browser
DEBUG - 2025-06-02 13:55:45 --> Total execution time: 0.0654
INFO - 2025-06-02 13:57:42 --> Config Class Initialized
INFO - 2025-06-02 13:57:42 --> Hooks Class Initialized
DEBUG - 2025-06-02 13:57:42 --> UTF-8 Support Enabled
INFO - 2025-06-02 13:57:42 --> Utf8 Class Initialized
INFO - 2025-06-02 13:57:42 --> URI Class Initialized
INFO - 2025-06-02 13:57:42 --> Router Class Initialized
INFO - 2025-06-02 13:57:42 --> Output Class Initialized
INFO - 2025-06-02 13:57:42 --> Security Class Initialized
DEBUG - 2025-06-02 13:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 13:57:42 --> Input Class Initialized
INFO - 2025-06-02 13:57:42 --> Language Class Initialized
INFO - 2025-06-02 13:57:42 --> Loader Class Initialized
INFO - 2025-06-02 13:57:42 --> Helper loaded: url_helper
INFO - 2025-06-02 13:57:42 --> Helper loaded: form_helper
INFO - 2025-06-02 13:57:42 --> Database Driver Class Initialized
DEBUG - 2025-06-02 13:57:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 13:57:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 13:57:42 --> Controller Class Initialized
INFO - 2025-06-02 13:57:42 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 13:57:42 --> Model "User_model" initialized
INFO - 2025-06-02 13:57:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 13:57:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 13:57:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/menu.php
INFO - 2025-06-02 13:57:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 13:57:42 --> Final output sent to browser
DEBUG - 2025-06-02 13:57:42 --> Total execution time: 0.0926
INFO - 2025-06-02 13:59:14 --> Config Class Initialized
INFO - 2025-06-02 13:59:14 --> Hooks Class Initialized
DEBUG - 2025-06-02 13:59:14 --> UTF-8 Support Enabled
INFO - 2025-06-02 13:59:14 --> Utf8 Class Initialized
INFO - 2025-06-02 13:59:14 --> URI Class Initialized
INFO - 2025-06-02 13:59:14 --> Router Class Initialized
INFO - 2025-06-02 13:59:14 --> Output Class Initialized
INFO - 2025-06-02 13:59:14 --> Security Class Initialized
DEBUG - 2025-06-02 13:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 13:59:14 --> Input Class Initialized
INFO - 2025-06-02 13:59:14 --> Language Class Initialized
INFO - 2025-06-02 13:59:14 --> Loader Class Initialized
INFO - 2025-06-02 13:59:14 --> Helper loaded: url_helper
INFO - 2025-06-02 13:59:14 --> Helper loaded: form_helper
INFO - 2025-06-02 13:59:14 --> Database Driver Class Initialized
DEBUG - 2025-06-02 13:59:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 13:59:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 13:59:14 --> Controller Class Initialized
INFO - 2025-06-02 13:59:14 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 13:59:14 --> Model "User_model" initialized
INFO - 2025-06-02 13:59:14 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 13:59:14 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 13:59:14 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/menu.php
INFO - 2025-06-02 13:59:14 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 13:59:14 --> Final output sent to browser
DEBUG - 2025-06-02 13:59:14 --> Total execution time: 0.0742
INFO - 2025-06-02 13:59:31 --> Config Class Initialized
INFO - 2025-06-02 13:59:31 --> Hooks Class Initialized
DEBUG - 2025-06-02 13:59:31 --> UTF-8 Support Enabled
INFO - 2025-06-02 13:59:31 --> Utf8 Class Initialized
INFO - 2025-06-02 13:59:31 --> URI Class Initialized
INFO - 2025-06-02 13:59:31 --> Router Class Initialized
INFO - 2025-06-02 13:59:31 --> Output Class Initialized
INFO - 2025-06-02 13:59:31 --> Security Class Initialized
DEBUG - 2025-06-02 13:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 13:59:31 --> Input Class Initialized
INFO - 2025-06-02 13:59:31 --> Language Class Initialized
INFO - 2025-06-02 13:59:31 --> Loader Class Initialized
INFO - 2025-06-02 13:59:31 --> Helper loaded: url_helper
INFO - 2025-06-02 13:59:31 --> Helper loaded: form_helper
INFO - 2025-06-02 13:59:31 --> Database Driver Class Initialized
DEBUG - 2025-06-02 13:59:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 13:59:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 13:59:31 --> Controller Class Initialized
INFO - 2025-06-02 13:59:31 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 13:59:31 --> Model "User_model" initialized
INFO - 2025-06-02 13:59:31 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 13:59:31 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 13:59:31 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/menu.php
INFO - 2025-06-02 13:59:31 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 13:59:31 --> Final output sent to browser
DEBUG - 2025-06-02 13:59:31 --> Total execution time: 0.0636
INFO - 2025-06-02 13:59:41 --> Config Class Initialized
INFO - 2025-06-02 13:59:41 --> Hooks Class Initialized
DEBUG - 2025-06-02 13:59:41 --> UTF-8 Support Enabled
INFO - 2025-06-02 13:59:41 --> Utf8 Class Initialized
INFO - 2025-06-02 13:59:41 --> URI Class Initialized
INFO - 2025-06-02 13:59:41 --> Router Class Initialized
INFO - 2025-06-02 13:59:41 --> Output Class Initialized
INFO - 2025-06-02 13:59:41 --> Security Class Initialized
DEBUG - 2025-06-02 13:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 13:59:41 --> Input Class Initialized
INFO - 2025-06-02 13:59:41 --> Language Class Initialized
INFO - 2025-06-02 13:59:41 --> Loader Class Initialized
INFO - 2025-06-02 13:59:41 --> Helper loaded: url_helper
INFO - 2025-06-02 13:59:41 --> Helper loaded: form_helper
INFO - 2025-06-02 13:59:42 --> Database Driver Class Initialized
DEBUG - 2025-06-02 13:59:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 13:59:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 13:59:42 --> Controller Class Initialized
INFO - 2025-06-02 13:59:42 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 13:59:42 --> Model "User_model" initialized
INFO - 2025-06-02 13:59:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 13:59:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 13:59:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/menu.php
INFO - 2025-06-02 13:59:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 13:59:42 --> Final output sent to browser
DEBUG - 2025-06-02 13:59:42 --> Total execution time: 0.0860
INFO - 2025-06-02 14:00:03 --> Config Class Initialized
INFO - 2025-06-02 14:00:03 --> Hooks Class Initialized
DEBUG - 2025-06-02 14:00:03 --> UTF-8 Support Enabled
INFO - 2025-06-02 14:00:03 --> Utf8 Class Initialized
INFO - 2025-06-02 14:00:03 --> URI Class Initialized
INFO - 2025-06-02 14:00:03 --> Router Class Initialized
INFO - 2025-06-02 14:00:03 --> Output Class Initialized
INFO - 2025-06-02 14:00:03 --> Security Class Initialized
DEBUG - 2025-06-02 14:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 14:00:03 --> Input Class Initialized
INFO - 2025-06-02 14:00:03 --> Language Class Initialized
INFO - 2025-06-02 14:00:03 --> Loader Class Initialized
INFO - 2025-06-02 14:00:03 --> Helper loaded: url_helper
INFO - 2025-06-02 14:00:03 --> Helper loaded: form_helper
INFO - 2025-06-02 14:00:03 --> Database Driver Class Initialized
DEBUG - 2025-06-02 14:00:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 14:00:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 14:00:03 --> Controller Class Initialized
INFO - 2025-06-02 14:00:03 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 14:00:03 --> Model "User_model" initialized
INFO - 2025-06-02 14:00:03 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 14:00:03 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 14:00:03 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/menu.php
INFO - 2025-06-02 14:00:03 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 14:00:03 --> Final output sent to browser
DEBUG - 2025-06-02 14:00:03 --> Total execution time: 0.0703
INFO - 2025-06-02 14:01:40 --> Config Class Initialized
INFO - 2025-06-02 14:01:40 --> Hooks Class Initialized
DEBUG - 2025-06-02 14:01:40 --> UTF-8 Support Enabled
INFO - 2025-06-02 14:01:40 --> Utf8 Class Initialized
INFO - 2025-06-02 14:01:40 --> URI Class Initialized
INFO - 2025-06-02 14:01:40 --> Router Class Initialized
INFO - 2025-06-02 14:01:40 --> Output Class Initialized
INFO - 2025-06-02 14:01:40 --> Security Class Initialized
DEBUG - 2025-06-02 14:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 14:01:40 --> Input Class Initialized
INFO - 2025-06-02 14:01:40 --> Language Class Initialized
INFO - 2025-06-02 14:01:40 --> Loader Class Initialized
INFO - 2025-06-02 14:01:40 --> Helper loaded: url_helper
INFO - 2025-06-02 14:01:40 --> Helper loaded: form_helper
INFO - 2025-06-02 14:01:40 --> Database Driver Class Initialized
DEBUG - 2025-06-02 14:01:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 14:01:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 14:01:40 --> Controller Class Initialized
INFO - 2025-06-02 14:01:40 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 14:01:40 --> Model "User_model" initialized
INFO - 2025-06-02 14:01:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 14:01:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 14:01:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/menu.php
INFO - 2025-06-02 14:01:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 14:01:40 --> Final output sent to browser
DEBUG - 2025-06-02 14:01:40 --> Total execution time: 0.0824
INFO - 2025-06-02 14:02:51 --> Config Class Initialized
INFO - 2025-06-02 14:02:51 --> Hooks Class Initialized
DEBUG - 2025-06-02 14:02:51 --> UTF-8 Support Enabled
INFO - 2025-06-02 14:02:51 --> Utf8 Class Initialized
INFO - 2025-06-02 14:02:51 --> URI Class Initialized
INFO - 2025-06-02 14:02:51 --> Router Class Initialized
INFO - 2025-06-02 14:02:51 --> Output Class Initialized
INFO - 2025-06-02 14:02:51 --> Security Class Initialized
DEBUG - 2025-06-02 14:02:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 14:02:51 --> Input Class Initialized
INFO - 2025-06-02 14:02:51 --> Language Class Initialized
INFO - 2025-06-02 14:02:51 --> Loader Class Initialized
INFO - 2025-06-02 14:02:51 --> Helper loaded: url_helper
INFO - 2025-06-02 14:02:51 --> Helper loaded: form_helper
INFO - 2025-06-02 14:02:51 --> Database Driver Class Initialized
DEBUG - 2025-06-02 14:02:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 14:02:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 14:02:51 --> Controller Class Initialized
INFO - 2025-06-02 14:02:51 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 14:02:51 --> Model "User_model" initialized
INFO - 2025-06-02 14:02:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 14:02:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 14:02:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/menu.php
INFO - 2025-06-02 14:02:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 14:02:51 --> Final output sent to browser
DEBUG - 2025-06-02 14:02:51 --> Total execution time: 0.0815
INFO - 2025-06-02 14:03:22 --> Config Class Initialized
INFO - 2025-06-02 14:03:22 --> Hooks Class Initialized
DEBUG - 2025-06-02 14:03:22 --> UTF-8 Support Enabled
INFO - 2025-06-02 14:03:22 --> Utf8 Class Initialized
INFO - 2025-06-02 14:03:22 --> URI Class Initialized
INFO - 2025-06-02 14:03:22 --> Router Class Initialized
INFO - 2025-06-02 14:03:22 --> Output Class Initialized
INFO - 2025-06-02 14:03:22 --> Security Class Initialized
DEBUG - 2025-06-02 14:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 14:03:22 --> Input Class Initialized
INFO - 2025-06-02 14:03:22 --> Language Class Initialized
INFO - 2025-06-02 14:03:22 --> Loader Class Initialized
INFO - 2025-06-02 14:03:22 --> Helper loaded: url_helper
INFO - 2025-06-02 14:03:22 --> Helper loaded: form_helper
INFO - 2025-06-02 14:03:22 --> Database Driver Class Initialized
DEBUG - 2025-06-02 14:03:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 14:03:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 14:03:22 --> Controller Class Initialized
INFO - 2025-06-02 14:03:22 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 14:03:22 --> Model "User_model" initialized
INFO - 2025-06-02 14:03:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 14:03:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 14:03:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/menu.php
INFO - 2025-06-02 14:03:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 14:03:22 --> Final output sent to browser
DEBUG - 2025-06-02 14:03:22 --> Total execution time: 0.0967
INFO - 2025-06-02 14:04:15 --> Config Class Initialized
INFO - 2025-06-02 14:04:15 --> Hooks Class Initialized
DEBUG - 2025-06-02 14:04:15 --> UTF-8 Support Enabled
INFO - 2025-06-02 14:04:15 --> Utf8 Class Initialized
INFO - 2025-06-02 14:04:15 --> URI Class Initialized
INFO - 2025-06-02 14:04:15 --> Router Class Initialized
INFO - 2025-06-02 14:04:15 --> Output Class Initialized
INFO - 2025-06-02 14:04:15 --> Security Class Initialized
DEBUG - 2025-06-02 14:04:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 14:04:15 --> Input Class Initialized
INFO - 2025-06-02 14:04:15 --> Language Class Initialized
INFO - 2025-06-02 14:04:15 --> Loader Class Initialized
INFO - 2025-06-02 14:04:15 --> Helper loaded: url_helper
INFO - 2025-06-02 14:04:15 --> Helper loaded: form_helper
INFO - 2025-06-02 14:04:15 --> Database Driver Class Initialized
DEBUG - 2025-06-02 14:04:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 14:04:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 14:04:15 --> Controller Class Initialized
INFO - 2025-06-02 14:04:15 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 14:04:15 --> Model "User_model" initialized
INFO - 2025-06-02 14:04:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 14:04:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 14:04:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/menu.php
INFO - 2025-06-02 14:04:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 14:04:15 --> Final output sent to browser
DEBUG - 2025-06-02 14:04:15 --> Total execution time: 0.0777
INFO - 2025-06-02 14:06:20 --> Config Class Initialized
INFO - 2025-06-02 14:06:20 --> Hooks Class Initialized
DEBUG - 2025-06-02 14:06:20 --> UTF-8 Support Enabled
INFO - 2025-06-02 14:06:20 --> Utf8 Class Initialized
INFO - 2025-06-02 14:06:20 --> URI Class Initialized
INFO - 2025-06-02 14:06:20 --> Router Class Initialized
INFO - 2025-06-02 14:06:20 --> Output Class Initialized
INFO - 2025-06-02 14:06:20 --> Security Class Initialized
DEBUG - 2025-06-02 14:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 14:06:20 --> Input Class Initialized
INFO - 2025-06-02 14:06:20 --> Language Class Initialized
INFO - 2025-06-02 14:06:20 --> Loader Class Initialized
INFO - 2025-06-02 14:06:20 --> Helper loaded: url_helper
INFO - 2025-06-02 14:06:20 --> Helper loaded: form_helper
INFO - 2025-06-02 14:06:20 --> Database Driver Class Initialized
DEBUG - 2025-06-02 14:06:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 14:06:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 14:06:20 --> Controller Class Initialized
INFO - 2025-06-02 14:06:20 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 14:06:20 --> Model "User_model" initialized
INFO - 2025-06-02 14:06:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 14:06:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 14:06:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/menu.php
INFO - 2025-06-02 14:06:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 14:06:20 --> Final output sent to browser
DEBUG - 2025-06-02 14:06:20 --> Total execution time: 0.0871
INFO - 2025-06-02 14:07:11 --> Config Class Initialized
INFO - 2025-06-02 14:07:11 --> Hooks Class Initialized
DEBUG - 2025-06-02 14:07:11 --> UTF-8 Support Enabled
INFO - 2025-06-02 14:07:11 --> Utf8 Class Initialized
INFO - 2025-06-02 14:07:11 --> URI Class Initialized
INFO - 2025-06-02 14:07:11 --> Router Class Initialized
INFO - 2025-06-02 14:07:11 --> Output Class Initialized
INFO - 2025-06-02 14:07:11 --> Security Class Initialized
DEBUG - 2025-06-02 14:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 14:07:11 --> Input Class Initialized
INFO - 2025-06-02 14:07:11 --> Language Class Initialized
INFO - 2025-06-02 14:07:11 --> Loader Class Initialized
INFO - 2025-06-02 14:07:11 --> Helper loaded: url_helper
INFO - 2025-06-02 14:07:11 --> Helper loaded: form_helper
INFO - 2025-06-02 14:07:11 --> Database Driver Class Initialized
DEBUG - 2025-06-02 14:07:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 14:07:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 14:07:11 --> Controller Class Initialized
INFO - 2025-06-02 14:07:11 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 14:07:11 --> Model "User_model" initialized
INFO - 2025-06-02 14:07:11 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 14:07:11 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 14:07:11 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/start.php
INFO - 2025-06-02 14:07:11 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 14:07:11 --> Final output sent to browser
DEBUG - 2025-06-02 14:07:11 --> Total execution time: 0.1591
INFO - 2025-06-02 14:07:56 --> Config Class Initialized
INFO - 2025-06-02 14:07:56 --> Hooks Class Initialized
DEBUG - 2025-06-02 14:07:56 --> UTF-8 Support Enabled
INFO - 2025-06-02 14:07:56 --> Utf8 Class Initialized
INFO - 2025-06-02 14:07:56 --> URI Class Initialized
INFO - 2025-06-02 14:07:56 --> Router Class Initialized
INFO - 2025-06-02 14:07:56 --> Output Class Initialized
INFO - 2025-06-02 14:07:56 --> Security Class Initialized
DEBUG - 2025-06-02 14:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 14:07:56 --> Input Class Initialized
INFO - 2025-06-02 14:07:56 --> Language Class Initialized
INFO - 2025-06-02 14:07:56 --> Loader Class Initialized
INFO - 2025-06-02 14:07:56 --> Helper loaded: url_helper
INFO - 2025-06-02 14:07:56 --> Helper loaded: form_helper
INFO - 2025-06-02 14:07:56 --> Database Driver Class Initialized
DEBUG - 2025-06-02 14:07:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 14:07:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 14:07:56 --> Controller Class Initialized
INFO - 2025-06-02 14:07:56 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 14:07:56 --> Model "User_model" initialized
INFO - 2025-06-02 14:07:56 --> Final output sent to browser
DEBUG - 2025-06-02 14:07:56 --> Total execution time: 0.0940
INFO - 2025-06-02 14:08:06 --> Config Class Initialized
INFO - 2025-06-02 14:08:06 --> Hooks Class Initialized
DEBUG - 2025-06-02 14:08:06 --> UTF-8 Support Enabled
INFO - 2025-06-02 14:08:06 --> Utf8 Class Initialized
INFO - 2025-06-02 14:08:06 --> URI Class Initialized
INFO - 2025-06-02 14:08:06 --> Router Class Initialized
INFO - 2025-06-02 14:08:06 --> Output Class Initialized
INFO - 2025-06-02 14:08:06 --> Security Class Initialized
DEBUG - 2025-06-02 14:08:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 14:08:06 --> Input Class Initialized
INFO - 2025-06-02 14:08:06 --> Language Class Initialized
INFO - 2025-06-02 14:08:06 --> Loader Class Initialized
INFO - 2025-06-02 14:08:06 --> Helper loaded: url_helper
INFO - 2025-06-02 14:08:06 --> Helper loaded: form_helper
INFO - 2025-06-02 14:08:06 --> Database Driver Class Initialized
DEBUG - 2025-06-02 14:08:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 14:08:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 14:08:06 --> Controller Class Initialized
INFO - 2025-06-02 14:08:06 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 14:08:06 --> Model "User_model" initialized
INFO - 2025-06-02 14:08:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 14:08:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 14:08:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-06-02 14:08:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 14:08:06 --> Final output sent to browser
DEBUG - 2025-06-02 14:08:06 --> Total execution time: 0.0766
INFO - 2025-06-02 14:23:22 --> Config Class Initialized
INFO - 2025-06-02 14:23:22 --> Hooks Class Initialized
DEBUG - 2025-06-02 14:23:22 --> UTF-8 Support Enabled
INFO - 2025-06-02 14:23:22 --> Utf8 Class Initialized
INFO - 2025-06-02 14:23:22 --> URI Class Initialized
INFO - 2025-06-02 14:23:22 --> Router Class Initialized
INFO - 2025-06-02 14:23:22 --> Output Class Initialized
INFO - 2025-06-02 14:23:22 --> Security Class Initialized
DEBUG - 2025-06-02 14:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 14:23:22 --> Input Class Initialized
INFO - 2025-06-02 14:23:22 --> Language Class Initialized
INFO - 2025-06-02 14:23:22 --> Loader Class Initialized
INFO - 2025-06-02 14:23:22 --> Helper loaded: url_helper
INFO - 2025-06-02 14:23:22 --> Helper loaded: form_helper
INFO - 2025-06-02 14:23:22 --> Database Driver Class Initialized
DEBUG - 2025-06-02 14:23:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 14:23:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 14:23:22 --> Controller Class Initialized
INFO - 2025-06-02 14:23:22 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 14:23:22 --> Model "User_model" initialized
INFO - 2025-06-02 14:23:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 14:23:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 14:23:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-06-02 14:23:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 14:23:22 --> Final output sent to browser
DEBUG - 2025-06-02 14:23:22 --> Total execution time: 0.0790
INFO - 2025-06-02 14:23:25 --> Config Class Initialized
INFO - 2025-06-02 14:23:25 --> Hooks Class Initialized
DEBUG - 2025-06-02 14:23:25 --> UTF-8 Support Enabled
INFO - 2025-06-02 14:23:25 --> Utf8 Class Initialized
INFO - 2025-06-02 14:23:25 --> URI Class Initialized
INFO - 2025-06-02 14:23:25 --> Router Class Initialized
INFO - 2025-06-02 14:23:25 --> Output Class Initialized
INFO - 2025-06-02 14:23:25 --> Security Class Initialized
DEBUG - 2025-06-02 14:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 14:23:25 --> Input Class Initialized
INFO - 2025-06-02 14:23:25 --> Language Class Initialized
INFO - 2025-06-02 14:23:25 --> Loader Class Initialized
INFO - 2025-06-02 14:23:25 --> Helper loaded: url_helper
INFO - 2025-06-02 14:23:25 --> Helper loaded: form_helper
INFO - 2025-06-02 14:23:25 --> Database Driver Class Initialized
DEBUG - 2025-06-02 14:23:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 14:23:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 14:23:25 --> Controller Class Initialized
INFO - 2025-06-02 14:23:25 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 14:23:25 --> Model "User_model" initialized
INFO - 2025-06-02 14:23:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 14:23:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 14:23:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-06-02 14:23:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 14:23:25 --> Final output sent to browser
DEBUG - 2025-06-02 14:23:25 --> Total execution time: 0.0758
INFO - 2025-06-02 14:23:28 --> Config Class Initialized
INFO - 2025-06-02 14:23:28 --> Hooks Class Initialized
DEBUG - 2025-06-02 14:23:28 --> UTF-8 Support Enabled
INFO - 2025-06-02 14:23:28 --> Utf8 Class Initialized
INFO - 2025-06-02 14:23:28 --> URI Class Initialized
INFO - 2025-06-02 14:23:28 --> Router Class Initialized
INFO - 2025-06-02 14:23:28 --> Output Class Initialized
INFO - 2025-06-02 14:23:28 --> Security Class Initialized
DEBUG - 2025-06-02 14:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 14:23:28 --> Input Class Initialized
INFO - 2025-06-02 14:23:28 --> Language Class Initialized
INFO - 2025-06-02 14:23:28 --> Loader Class Initialized
INFO - 2025-06-02 14:23:28 --> Helper loaded: url_helper
INFO - 2025-06-02 14:23:28 --> Helper loaded: form_helper
INFO - 2025-06-02 14:23:28 --> Database Driver Class Initialized
DEBUG - 2025-06-02 14:23:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 14:23:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 14:23:28 --> Controller Class Initialized
INFO - 2025-06-02 14:23:28 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 14:23:28 --> Model "User_model" initialized
INFO - 2025-06-02 14:23:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 14:23:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 14:23:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/menu.php
INFO - 2025-06-02 14:23:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 14:23:28 --> Final output sent to browser
DEBUG - 2025-06-02 14:23:28 --> Total execution time: 0.1044
INFO - 2025-06-02 14:23:31 --> Config Class Initialized
INFO - 2025-06-02 14:23:31 --> Hooks Class Initialized
DEBUG - 2025-06-02 14:23:31 --> UTF-8 Support Enabled
INFO - 2025-06-02 14:23:31 --> Utf8 Class Initialized
INFO - 2025-06-02 14:23:31 --> URI Class Initialized
INFO - 2025-06-02 14:23:31 --> Router Class Initialized
INFO - 2025-06-02 14:23:31 --> Output Class Initialized
INFO - 2025-06-02 14:23:31 --> Security Class Initialized
DEBUG - 2025-06-02 14:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 14:23:31 --> Input Class Initialized
INFO - 2025-06-02 14:23:31 --> Language Class Initialized
INFO - 2025-06-02 14:23:31 --> Loader Class Initialized
INFO - 2025-06-02 14:23:31 --> Helper loaded: url_helper
INFO - 2025-06-02 14:23:31 --> Helper loaded: form_helper
INFO - 2025-06-02 14:23:31 --> Database Driver Class Initialized
DEBUG - 2025-06-02 14:23:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 14:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 14:23:31 --> Controller Class Initialized
INFO - 2025-06-02 14:23:31 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 14:23:31 --> Model "User_model" initialized
INFO - 2025-06-02 14:23:31 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 14:23:31 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 14:23:31 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/start.php
INFO - 2025-06-02 14:23:31 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 14:23:31 --> Final output sent to browser
DEBUG - 2025-06-02 14:23:31 --> Total execution time: 0.0627
INFO - 2025-06-02 14:23:45 --> Config Class Initialized
INFO - 2025-06-02 14:23:45 --> Hooks Class Initialized
DEBUG - 2025-06-02 14:23:45 --> UTF-8 Support Enabled
INFO - 2025-06-02 14:23:45 --> Utf8 Class Initialized
INFO - 2025-06-02 14:23:45 --> URI Class Initialized
INFO - 2025-06-02 14:23:45 --> Router Class Initialized
INFO - 2025-06-02 14:23:45 --> Output Class Initialized
INFO - 2025-06-02 14:23:45 --> Security Class Initialized
DEBUG - 2025-06-02 14:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 14:23:45 --> Input Class Initialized
INFO - 2025-06-02 14:23:45 --> Language Class Initialized
INFO - 2025-06-02 14:23:45 --> Loader Class Initialized
INFO - 2025-06-02 14:23:45 --> Helper loaded: url_helper
INFO - 2025-06-02 14:23:45 --> Helper loaded: form_helper
INFO - 2025-06-02 14:23:45 --> Database Driver Class Initialized
DEBUG - 2025-06-02 14:23:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 14:23:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 14:23:45 --> Controller Class Initialized
INFO - 2025-06-02 14:23:45 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 14:23:45 --> Model "User_model" initialized
INFO - 2025-06-02 14:23:45 --> Final output sent to browser
DEBUG - 2025-06-02 14:23:45 --> Total execution time: 0.0767
INFO - 2025-06-02 14:25:55 --> Config Class Initialized
INFO - 2025-06-02 14:25:55 --> Hooks Class Initialized
DEBUG - 2025-06-02 14:25:55 --> UTF-8 Support Enabled
INFO - 2025-06-02 14:25:55 --> Utf8 Class Initialized
INFO - 2025-06-02 14:25:55 --> URI Class Initialized
INFO - 2025-06-02 14:25:55 --> Router Class Initialized
INFO - 2025-06-02 14:25:55 --> Output Class Initialized
INFO - 2025-06-02 14:25:55 --> Security Class Initialized
DEBUG - 2025-06-02 14:25:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 14:25:55 --> Input Class Initialized
INFO - 2025-06-02 14:25:55 --> Language Class Initialized
INFO - 2025-06-02 14:25:55 --> Loader Class Initialized
INFO - 2025-06-02 14:25:55 --> Helper loaded: url_helper
INFO - 2025-06-02 14:25:55 --> Helper loaded: form_helper
INFO - 2025-06-02 14:25:55 --> Database Driver Class Initialized
DEBUG - 2025-06-02 14:25:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 14:25:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 14:25:55 --> Controller Class Initialized
INFO - 2025-06-02 14:25:55 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 14:25:55 --> Model "User_model" initialized
INFO - 2025-06-02 14:25:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 14:25:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 14:25:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/start.php
INFO - 2025-06-02 14:25:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 14:25:55 --> Final output sent to browser
DEBUG - 2025-06-02 14:25:55 --> Total execution time: 0.0653
INFO - 2025-06-02 14:25:59 --> Config Class Initialized
INFO - 2025-06-02 14:25:59 --> Hooks Class Initialized
DEBUG - 2025-06-02 14:25:59 --> UTF-8 Support Enabled
INFO - 2025-06-02 14:25:59 --> Utf8 Class Initialized
INFO - 2025-06-02 14:25:59 --> URI Class Initialized
INFO - 2025-06-02 14:25:59 --> Router Class Initialized
INFO - 2025-06-02 14:25:59 --> Output Class Initialized
INFO - 2025-06-02 14:25:59 --> Security Class Initialized
DEBUG - 2025-06-02 14:25:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 14:25:59 --> Input Class Initialized
INFO - 2025-06-02 14:25:59 --> Language Class Initialized
INFO - 2025-06-02 14:25:59 --> Loader Class Initialized
INFO - 2025-06-02 14:25:59 --> Helper loaded: url_helper
INFO - 2025-06-02 14:25:59 --> Helper loaded: form_helper
INFO - 2025-06-02 14:25:59 --> Database Driver Class Initialized
DEBUG - 2025-06-02 14:25:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 14:25:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 14:25:59 --> Controller Class Initialized
INFO - 2025-06-02 14:25:59 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 14:25:59 --> Model "User_model" initialized
INFO - 2025-06-02 14:25:59 --> Final output sent to browser
DEBUG - 2025-06-02 14:25:59 --> Total execution time: 0.0912
INFO - 2025-06-02 14:26:06 --> Config Class Initialized
INFO - 2025-06-02 14:26:06 --> Hooks Class Initialized
DEBUG - 2025-06-02 14:26:06 --> UTF-8 Support Enabled
INFO - 2025-06-02 14:26:06 --> Utf8 Class Initialized
INFO - 2025-06-02 14:26:06 --> URI Class Initialized
INFO - 2025-06-02 14:26:06 --> Router Class Initialized
INFO - 2025-06-02 14:26:06 --> Output Class Initialized
INFO - 2025-06-02 14:26:06 --> Security Class Initialized
DEBUG - 2025-06-02 14:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 14:26:06 --> Input Class Initialized
INFO - 2025-06-02 14:26:06 --> Language Class Initialized
INFO - 2025-06-02 14:26:06 --> Loader Class Initialized
INFO - 2025-06-02 14:26:06 --> Helper loaded: url_helper
INFO - 2025-06-02 14:26:06 --> Helper loaded: form_helper
INFO - 2025-06-02 14:26:06 --> Database Driver Class Initialized
DEBUG - 2025-06-02 14:26:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 14:26:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 14:26:06 --> Controller Class Initialized
INFO - 2025-06-02 14:26:06 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 14:26:06 --> Model "User_model" initialized
INFO - 2025-06-02 14:26:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 14:26:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 14:26:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/start.php
INFO - 2025-06-02 14:26:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 14:26:06 --> Final output sent to browser
DEBUG - 2025-06-02 14:26:06 --> Total execution time: 0.0837
INFO - 2025-06-02 14:26:09 --> Config Class Initialized
INFO - 2025-06-02 14:26:09 --> Hooks Class Initialized
DEBUG - 2025-06-02 14:26:09 --> UTF-8 Support Enabled
INFO - 2025-06-02 14:26:09 --> Utf8 Class Initialized
INFO - 2025-06-02 14:26:09 --> URI Class Initialized
INFO - 2025-06-02 14:26:09 --> Router Class Initialized
INFO - 2025-06-02 14:26:09 --> Output Class Initialized
INFO - 2025-06-02 14:26:09 --> Security Class Initialized
DEBUG - 2025-06-02 14:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 14:26:09 --> Input Class Initialized
INFO - 2025-06-02 14:26:09 --> Language Class Initialized
INFO - 2025-06-02 14:26:09 --> Loader Class Initialized
INFO - 2025-06-02 14:26:09 --> Helper loaded: url_helper
INFO - 2025-06-02 14:26:09 --> Helper loaded: form_helper
INFO - 2025-06-02 14:26:09 --> Database Driver Class Initialized
DEBUG - 2025-06-02 14:26:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 14:26:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 14:26:09 --> Controller Class Initialized
INFO - 2025-06-02 14:26:09 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 14:26:09 --> Model "User_model" initialized
INFO - 2025-06-02 14:26:09 --> Final output sent to browser
DEBUG - 2025-06-02 14:26:09 --> Total execution time: 0.0761
INFO - 2025-06-02 14:26:15 --> Config Class Initialized
INFO - 2025-06-02 14:26:15 --> Hooks Class Initialized
DEBUG - 2025-06-02 14:26:15 --> UTF-8 Support Enabled
INFO - 2025-06-02 14:26:15 --> Utf8 Class Initialized
INFO - 2025-06-02 14:26:15 --> URI Class Initialized
INFO - 2025-06-02 14:26:15 --> Router Class Initialized
INFO - 2025-06-02 14:26:15 --> Output Class Initialized
INFO - 2025-06-02 14:26:15 --> Security Class Initialized
DEBUG - 2025-06-02 14:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 14:26:15 --> Input Class Initialized
INFO - 2025-06-02 14:26:15 --> Language Class Initialized
INFO - 2025-06-02 14:26:15 --> Loader Class Initialized
INFO - 2025-06-02 14:26:15 --> Helper loaded: url_helper
INFO - 2025-06-02 14:26:15 --> Helper loaded: form_helper
INFO - 2025-06-02 14:26:15 --> Database Driver Class Initialized
DEBUG - 2025-06-02 14:26:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 14:26:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 14:26:15 --> Controller Class Initialized
INFO - 2025-06-02 14:26:15 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 14:26:15 --> Model "User_model" initialized
INFO - 2025-06-02 14:26:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 14:26:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 14:26:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/start.php
INFO - 2025-06-02 14:26:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 14:26:15 --> Final output sent to browser
DEBUG - 2025-06-02 14:26:15 --> Total execution time: 0.0626
INFO - 2025-06-02 14:34:38 --> Config Class Initialized
INFO - 2025-06-02 14:34:38 --> Hooks Class Initialized
DEBUG - 2025-06-02 14:34:38 --> UTF-8 Support Enabled
INFO - 2025-06-02 14:34:38 --> Utf8 Class Initialized
INFO - 2025-06-02 14:34:38 --> URI Class Initialized
INFO - 2025-06-02 14:34:38 --> Router Class Initialized
INFO - 2025-06-02 14:34:38 --> Output Class Initialized
INFO - 2025-06-02 14:34:38 --> Security Class Initialized
DEBUG - 2025-06-02 14:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 14:34:38 --> Input Class Initialized
INFO - 2025-06-02 14:34:38 --> Language Class Initialized
INFO - 2025-06-02 14:34:38 --> Loader Class Initialized
INFO - 2025-06-02 14:34:38 --> Helper loaded: url_helper
INFO - 2025-06-02 14:34:38 --> Helper loaded: form_helper
INFO - 2025-06-02 14:34:38 --> Database Driver Class Initialized
DEBUG - 2025-06-02 14:34:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 14:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 14:34:38 --> Controller Class Initialized
INFO - 2025-06-02 14:34:38 --> Model "User_model" initialized
INFO - 2025-06-02 14:34:38 --> Model "Community_model" initialized
INFO - 2025-06-02 14:34:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 14:34:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 14:34:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/community.php
INFO - 2025-06-02 14:34:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 14:34:38 --> Final output sent to browser
DEBUG - 2025-06-02 14:34:38 --> Total execution time: 0.2202
INFO - 2025-06-02 14:35:17 --> Config Class Initialized
INFO - 2025-06-02 14:35:17 --> Hooks Class Initialized
DEBUG - 2025-06-02 14:35:17 --> UTF-8 Support Enabled
INFO - 2025-06-02 14:35:17 --> Utf8 Class Initialized
INFO - 2025-06-02 14:35:17 --> URI Class Initialized
INFO - 2025-06-02 14:35:17 --> Router Class Initialized
INFO - 2025-06-02 14:35:17 --> Output Class Initialized
INFO - 2025-06-02 14:35:17 --> Security Class Initialized
DEBUG - 2025-06-02 14:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 14:35:17 --> Input Class Initialized
INFO - 2025-06-02 14:35:17 --> Language Class Initialized
INFO - 2025-06-02 14:35:17 --> Loader Class Initialized
INFO - 2025-06-02 14:35:17 --> Helper loaded: url_helper
INFO - 2025-06-02 14:35:17 --> Helper loaded: form_helper
INFO - 2025-06-02 14:35:17 --> Database Driver Class Initialized
DEBUG - 2025-06-02 14:35:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 14:35:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 14:35:17 --> Controller Class Initialized
INFO - 2025-06-02 14:35:17 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 14:35:17 --> Model "User_model" initialized
INFO - 2025-06-02 14:35:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 14:35:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 14:35:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-06-02 14:35:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 14:35:17 --> Final output sent to browser
DEBUG - 2025-06-02 14:35:17 --> Total execution time: 0.0701
INFO - 2025-06-02 14:35:20 --> Config Class Initialized
INFO - 2025-06-02 14:35:20 --> Hooks Class Initialized
DEBUG - 2025-06-02 14:35:20 --> UTF-8 Support Enabled
INFO - 2025-06-02 14:35:20 --> Utf8 Class Initialized
INFO - 2025-06-02 14:35:20 --> URI Class Initialized
INFO - 2025-06-02 14:35:20 --> Router Class Initialized
INFO - 2025-06-02 14:35:20 --> Output Class Initialized
INFO - 2025-06-02 14:35:20 --> Security Class Initialized
DEBUG - 2025-06-02 14:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 14:35:20 --> Input Class Initialized
INFO - 2025-06-02 14:35:20 --> Language Class Initialized
INFO - 2025-06-02 14:35:20 --> Loader Class Initialized
INFO - 2025-06-02 14:35:20 --> Helper loaded: url_helper
INFO - 2025-06-02 14:35:20 --> Helper loaded: form_helper
INFO - 2025-06-02 14:35:20 --> Database Driver Class Initialized
DEBUG - 2025-06-02 14:35:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 14:35:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 14:35:20 --> Controller Class Initialized
INFO - 2025-06-02 14:35:20 --> Model "Progress_model" initialized
INFO - 2025-06-02 14:35:20 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 14:35:20 --> Model "User_model" initialized
INFO - 2025-06-02 14:35:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 14:35:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 14:35:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-06-02 14:35:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 14:35:20 --> Final output sent to browser
DEBUG - 2025-06-02 14:35:20 --> Total execution time: 0.0772
INFO - 2025-06-02 14:35:20 --> Config Class Initialized
INFO - 2025-06-02 14:35:20 --> Hooks Class Initialized
DEBUG - 2025-06-02 14:35:20 --> UTF-8 Support Enabled
INFO - 2025-06-02 14:35:20 --> Utf8 Class Initialized
INFO - 2025-06-02 14:35:20 --> URI Class Initialized
INFO - 2025-06-02 14:35:20 --> Router Class Initialized
INFO - 2025-06-02 14:35:20 --> Output Class Initialized
INFO - 2025-06-02 14:35:20 --> Security Class Initialized
DEBUG - 2025-06-02 14:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 14:35:20 --> Input Class Initialized
INFO - 2025-06-02 14:35:20 --> Language Class Initialized
INFO - 2025-06-02 14:35:20 --> Loader Class Initialized
INFO - 2025-06-02 14:35:20 --> Helper loaded: url_helper
INFO - 2025-06-02 14:35:20 --> Helper loaded: form_helper
INFO - 2025-06-02 14:35:20 --> Database Driver Class Initialized
DEBUG - 2025-06-02 14:35:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 14:35:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 14:35:20 --> Controller Class Initialized
INFO - 2025-06-02 14:35:20 --> Model "Progress_model" initialized
INFO - 2025-06-02 14:35:20 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 14:35:20 --> Model "User_model" initialized
INFO - 2025-06-02 14:35:20 --> Final output sent to browser
DEBUG - 2025-06-02 14:35:20 --> Total execution time: 0.0844
INFO - 2025-06-02 14:35:24 --> Config Class Initialized
INFO - 2025-06-02 14:35:24 --> Hooks Class Initialized
DEBUG - 2025-06-02 14:35:24 --> UTF-8 Support Enabled
INFO - 2025-06-02 14:35:24 --> Utf8 Class Initialized
INFO - 2025-06-02 14:35:24 --> URI Class Initialized
INFO - 2025-06-02 14:35:24 --> Router Class Initialized
INFO - 2025-06-02 14:35:24 --> Output Class Initialized
INFO - 2025-06-02 14:35:24 --> Security Class Initialized
DEBUG - 2025-06-02 14:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 14:35:24 --> Input Class Initialized
INFO - 2025-06-02 14:35:24 --> Language Class Initialized
INFO - 2025-06-02 14:35:24 --> Loader Class Initialized
INFO - 2025-06-02 14:35:24 --> Helper loaded: url_helper
INFO - 2025-06-02 14:35:24 --> Helper loaded: form_helper
INFO - 2025-06-02 14:35:24 --> Database Driver Class Initialized
DEBUG - 2025-06-02 14:35:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 14:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 14:35:24 --> Controller Class Initialized
INFO - 2025-06-02 14:35:24 --> Model "Progress_model" initialized
INFO - 2025-06-02 14:35:24 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 14:35:24 --> Model "User_model" initialized
INFO - 2025-06-02 14:35:24 --> Final output sent to browser
DEBUG - 2025-06-02 14:35:24 --> Total execution time: 0.0614
INFO - 2025-06-02 14:35:25 --> Config Class Initialized
INFO - 2025-06-02 14:35:25 --> Hooks Class Initialized
DEBUG - 2025-06-02 14:35:25 --> UTF-8 Support Enabled
INFO - 2025-06-02 14:35:25 --> Utf8 Class Initialized
INFO - 2025-06-02 14:35:25 --> URI Class Initialized
INFO - 2025-06-02 14:35:25 --> Router Class Initialized
INFO - 2025-06-02 14:35:25 --> Output Class Initialized
INFO - 2025-06-02 14:35:25 --> Security Class Initialized
DEBUG - 2025-06-02 14:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 14:35:25 --> Input Class Initialized
INFO - 2025-06-02 14:35:25 --> Language Class Initialized
INFO - 2025-06-02 14:35:25 --> Loader Class Initialized
INFO - 2025-06-02 14:35:25 --> Helper loaded: url_helper
INFO - 2025-06-02 14:35:25 --> Helper loaded: form_helper
INFO - 2025-06-02 14:35:25 --> Database Driver Class Initialized
DEBUG - 2025-06-02 14:35:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 14:35:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 14:35:25 --> Controller Class Initialized
INFO - 2025-06-02 14:35:25 --> Model "Progress_model" initialized
INFO - 2025-06-02 14:35:25 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 14:35:25 --> Model "User_model" initialized
INFO - 2025-06-02 14:35:25 --> Final output sent to browser
DEBUG - 2025-06-02 14:35:25 --> Total execution time: 0.0652
INFO - 2025-06-02 14:35:26 --> Config Class Initialized
INFO - 2025-06-02 14:35:26 --> Hooks Class Initialized
DEBUG - 2025-06-02 14:35:26 --> UTF-8 Support Enabled
INFO - 2025-06-02 14:35:26 --> Utf8 Class Initialized
INFO - 2025-06-02 14:35:26 --> URI Class Initialized
INFO - 2025-06-02 14:35:26 --> Router Class Initialized
INFO - 2025-06-02 14:35:26 --> Output Class Initialized
INFO - 2025-06-02 14:35:26 --> Security Class Initialized
DEBUG - 2025-06-02 14:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 14:35:26 --> Input Class Initialized
INFO - 2025-06-02 14:35:26 --> Language Class Initialized
INFO - 2025-06-02 14:35:26 --> Loader Class Initialized
INFO - 2025-06-02 14:35:26 --> Helper loaded: url_helper
INFO - 2025-06-02 14:35:26 --> Helper loaded: form_helper
INFO - 2025-06-02 14:35:26 --> Database Driver Class Initialized
DEBUG - 2025-06-02 14:35:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 14:35:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 14:35:26 --> Controller Class Initialized
INFO - 2025-06-02 14:35:26 --> Model "User_model" initialized
INFO - 2025-06-02 14:35:26 --> Model "Progress_model" initialized
INFO - 2025-06-02 14:35:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 14:35:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 14:35:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-06-02 14:35:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 14:35:26 --> Final output sent to browser
DEBUG - 2025-06-02 14:35:26 --> Total execution time: 0.0856
INFO - 2025-06-02 14:35:32 --> Config Class Initialized
INFO - 2025-06-02 14:35:32 --> Hooks Class Initialized
DEBUG - 2025-06-02 14:35:32 --> UTF-8 Support Enabled
INFO - 2025-06-02 14:35:32 --> Utf8 Class Initialized
INFO - 2025-06-02 14:35:32 --> URI Class Initialized
INFO - 2025-06-02 14:35:32 --> Router Class Initialized
INFO - 2025-06-02 14:35:32 --> Output Class Initialized
INFO - 2025-06-02 14:35:32 --> Security Class Initialized
DEBUG - 2025-06-02 14:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 14:35:32 --> Input Class Initialized
INFO - 2025-06-02 14:35:32 --> Language Class Initialized
INFO - 2025-06-02 14:35:32 --> Loader Class Initialized
INFO - 2025-06-02 14:35:32 --> Helper loaded: url_helper
INFO - 2025-06-02 14:35:32 --> Helper loaded: form_helper
INFO - 2025-06-02 14:35:32 --> Database Driver Class Initialized
DEBUG - 2025-06-02 14:35:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 14:35:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 14:35:32 --> Controller Class Initialized
INFO - 2025-06-02 14:35:32 --> Model "User_model" initialized
INFO - 2025-06-02 14:35:32 --> Model "Progress_model" initialized
INFO - 2025-06-02 14:35:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 14:35:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 14:35:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-06-02 14:35:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 14:35:32 --> Final output sent to browser
DEBUG - 2025-06-02 14:35:32 --> Total execution time: 0.0973
INFO - 2025-06-02 14:35:34 --> Config Class Initialized
INFO - 2025-06-02 14:35:34 --> Hooks Class Initialized
DEBUG - 2025-06-02 14:35:34 --> UTF-8 Support Enabled
INFO - 2025-06-02 14:35:34 --> Utf8 Class Initialized
INFO - 2025-06-02 14:35:34 --> URI Class Initialized
INFO - 2025-06-02 14:35:34 --> Router Class Initialized
INFO - 2025-06-02 14:35:34 --> Output Class Initialized
INFO - 2025-06-02 14:35:34 --> Security Class Initialized
DEBUG - 2025-06-02 14:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 14:35:34 --> Input Class Initialized
INFO - 2025-06-02 14:35:34 --> Language Class Initialized
INFO - 2025-06-02 14:35:34 --> Loader Class Initialized
INFO - 2025-06-02 14:35:34 --> Helper loaded: url_helper
INFO - 2025-06-02 14:35:34 --> Helper loaded: form_helper
INFO - 2025-06-02 14:35:34 --> Database Driver Class Initialized
DEBUG - 2025-06-02 14:35:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 14:35:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 14:35:34 --> Controller Class Initialized
INFO - 2025-06-02 14:35:34 --> Model "User_model" initialized
INFO - 2025-06-02 14:35:34 --> Model "Progress_model" initialized
INFO - 2025-06-02 14:35:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 14:35:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 14:35:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-06-02 14:35:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 14:35:34 --> Final output sent to browser
DEBUG - 2025-06-02 14:35:34 --> Total execution time: 0.0697
INFO - 2025-06-02 14:35:42 --> Config Class Initialized
INFO - 2025-06-02 14:35:42 --> Hooks Class Initialized
DEBUG - 2025-06-02 14:35:42 --> UTF-8 Support Enabled
INFO - 2025-06-02 14:35:42 --> Utf8 Class Initialized
INFO - 2025-06-02 14:35:42 --> URI Class Initialized
INFO - 2025-06-02 14:35:42 --> Router Class Initialized
INFO - 2025-06-02 14:35:42 --> Output Class Initialized
INFO - 2025-06-02 14:35:42 --> Security Class Initialized
DEBUG - 2025-06-02 14:35:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 14:35:42 --> Input Class Initialized
INFO - 2025-06-02 14:35:42 --> Language Class Initialized
INFO - 2025-06-02 14:35:42 --> Loader Class Initialized
INFO - 2025-06-02 14:35:42 --> Helper loaded: url_helper
INFO - 2025-06-02 14:35:42 --> Helper loaded: form_helper
INFO - 2025-06-02 14:35:42 --> Database Driver Class Initialized
DEBUG - 2025-06-02 14:35:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 14:35:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 14:35:42 --> Controller Class Initialized
INFO - 2025-06-02 14:35:42 --> Model "User_model" initialized
INFO - 2025-06-02 14:35:42 --> Model "Progress_model" initialized
INFO - 2025-06-02 14:35:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 14:35:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 14:35:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-06-02 14:35:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 14:35:42 --> Final output sent to browser
DEBUG - 2025-06-02 14:35:42 --> Total execution time: 0.0930
INFO - 2025-06-02 14:35:45 --> Config Class Initialized
INFO - 2025-06-02 14:35:45 --> Hooks Class Initialized
DEBUG - 2025-06-02 14:35:45 --> UTF-8 Support Enabled
INFO - 2025-06-02 14:35:45 --> Utf8 Class Initialized
INFO - 2025-06-02 14:35:45 --> URI Class Initialized
INFO - 2025-06-02 14:35:45 --> Router Class Initialized
INFO - 2025-06-02 14:35:45 --> Output Class Initialized
INFO - 2025-06-02 14:35:45 --> Security Class Initialized
DEBUG - 2025-06-02 14:35:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 14:35:45 --> Input Class Initialized
INFO - 2025-06-02 14:35:45 --> Language Class Initialized
INFO - 2025-06-02 14:35:45 --> Loader Class Initialized
INFO - 2025-06-02 14:35:45 --> Helper loaded: url_helper
INFO - 2025-06-02 14:35:45 --> Helper loaded: form_helper
INFO - 2025-06-02 14:35:45 --> Database Driver Class Initialized
DEBUG - 2025-06-02 14:35:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 14:35:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 14:35:45 --> Controller Class Initialized
INFO - 2025-06-02 14:35:45 --> Model "User_model" initialized
INFO - 2025-06-02 14:35:45 --> Model "Progress_model" initialized
INFO - 2025-06-02 14:35:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 14:35:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 14:35:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-06-02 14:35:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 14:35:45 --> Final output sent to browser
DEBUG - 2025-06-02 14:35:45 --> Total execution time: 0.0754
INFO - 2025-06-02 14:36:06 --> Config Class Initialized
INFO - 2025-06-02 14:36:06 --> Hooks Class Initialized
DEBUG - 2025-06-02 14:36:06 --> UTF-8 Support Enabled
INFO - 2025-06-02 14:36:06 --> Utf8 Class Initialized
INFO - 2025-06-02 14:36:06 --> URI Class Initialized
INFO - 2025-06-02 14:36:06 --> Router Class Initialized
INFO - 2025-06-02 14:36:06 --> Output Class Initialized
INFO - 2025-06-02 14:36:06 --> Security Class Initialized
DEBUG - 2025-06-02 14:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 14:36:06 --> Input Class Initialized
INFO - 2025-06-02 14:36:06 --> Language Class Initialized
INFO - 2025-06-02 14:36:06 --> Loader Class Initialized
INFO - 2025-06-02 14:36:06 --> Helper loaded: url_helper
INFO - 2025-06-02 14:36:06 --> Helper loaded: form_helper
INFO - 2025-06-02 14:36:06 --> Database Driver Class Initialized
DEBUG - 2025-06-02 14:36:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 14:36:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 14:36:06 --> Controller Class Initialized
INFO - 2025-06-02 14:36:06 --> Model "User_model" initialized
INFO - 2025-06-02 14:36:06 --> Model "Progress_model" initialized
INFO - 2025-06-02 14:36:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 14:36:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 14:36:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-06-02 14:36:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 14:36:06 --> Final output sent to browser
DEBUG - 2025-06-02 14:36:06 --> Total execution time: 0.0751
INFO - 2025-06-02 14:36:11 --> Config Class Initialized
INFO - 2025-06-02 14:36:11 --> Hooks Class Initialized
DEBUG - 2025-06-02 14:36:11 --> UTF-8 Support Enabled
INFO - 2025-06-02 14:36:11 --> Utf8 Class Initialized
INFO - 2025-06-02 14:36:11 --> URI Class Initialized
INFO - 2025-06-02 14:36:11 --> Router Class Initialized
INFO - 2025-06-02 14:36:11 --> Output Class Initialized
INFO - 2025-06-02 14:36:11 --> Security Class Initialized
DEBUG - 2025-06-02 14:36:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 14:36:11 --> Input Class Initialized
INFO - 2025-06-02 14:36:11 --> Language Class Initialized
INFO - 2025-06-02 14:36:11 --> Loader Class Initialized
INFO - 2025-06-02 14:36:11 --> Helper loaded: url_helper
INFO - 2025-06-02 14:36:11 --> Helper loaded: form_helper
INFO - 2025-06-02 14:36:11 --> Database Driver Class Initialized
DEBUG - 2025-06-02 14:36:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 14:36:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 14:36:11 --> Controller Class Initialized
INFO - 2025-06-02 14:36:11 --> Model "User_model" initialized
INFO - 2025-06-02 14:36:11 --> Model "Progress_model" initialized
INFO - 2025-06-02 14:36:11 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 14:36:11 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 14:36:11 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-06-02 14:36:11 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 14:36:11 --> Final output sent to browser
DEBUG - 2025-06-02 14:36:11 --> Total execution time: 0.0754
INFO - 2025-06-02 14:36:32 --> Config Class Initialized
INFO - 2025-06-02 14:36:32 --> Hooks Class Initialized
DEBUG - 2025-06-02 14:36:32 --> UTF-8 Support Enabled
INFO - 2025-06-02 14:36:32 --> Utf8 Class Initialized
INFO - 2025-06-02 14:36:32 --> URI Class Initialized
INFO - 2025-06-02 14:36:32 --> Router Class Initialized
INFO - 2025-06-02 14:36:32 --> Output Class Initialized
INFO - 2025-06-02 14:36:32 --> Security Class Initialized
DEBUG - 2025-06-02 14:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 14:36:32 --> Input Class Initialized
INFO - 2025-06-02 14:36:32 --> Language Class Initialized
INFO - 2025-06-02 14:36:32 --> Loader Class Initialized
INFO - 2025-06-02 14:36:32 --> Helper loaded: url_helper
INFO - 2025-06-02 14:36:32 --> Helper loaded: form_helper
INFO - 2025-06-02 14:36:32 --> Database Driver Class Initialized
DEBUG - 2025-06-02 14:36:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 14:36:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 14:36:32 --> Controller Class Initialized
INFO - 2025-06-02 14:36:32 --> Model "User_model" initialized
INFO - 2025-06-02 14:36:32 --> Model "Progress_model" initialized
INFO - 2025-06-02 14:36:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 14:36:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 14:36:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-06-02 14:36:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 14:36:32 --> Final output sent to browser
DEBUG - 2025-06-02 14:36:32 --> Total execution time: 0.0740
INFO - 2025-06-02 14:36:34 --> Config Class Initialized
INFO - 2025-06-02 14:36:34 --> Hooks Class Initialized
DEBUG - 2025-06-02 14:36:34 --> UTF-8 Support Enabled
INFO - 2025-06-02 14:36:34 --> Utf8 Class Initialized
INFO - 2025-06-02 14:36:34 --> URI Class Initialized
INFO - 2025-06-02 14:36:34 --> Router Class Initialized
INFO - 2025-06-02 14:36:34 --> Output Class Initialized
INFO - 2025-06-02 14:36:34 --> Security Class Initialized
DEBUG - 2025-06-02 14:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 14:36:34 --> Input Class Initialized
INFO - 2025-06-02 14:36:34 --> Language Class Initialized
INFO - 2025-06-02 14:36:34 --> Loader Class Initialized
INFO - 2025-06-02 14:36:34 --> Helper loaded: url_helper
INFO - 2025-06-02 14:36:34 --> Helper loaded: form_helper
INFO - 2025-06-02 14:36:34 --> Database Driver Class Initialized
DEBUG - 2025-06-02 14:36:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 14:36:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 14:36:34 --> Controller Class Initialized
INFO - 2025-06-02 14:36:34 --> Model "Progress_model" initialized
INFO - 2025-06-02 14:36:34 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 14:36:34 --> Model "User_model" initialized
INFO - 2025-06-02 14:36:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 14:36:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 14:36:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-06-02 14:36:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 14:36:34 --> Final output sent to browser
DEBUG - 2025-06-02 14:36:34 --> Total execution time: 0.0684
INFO - 2025-06-02 14:36:34 --> Config Class Initialized
INFO - 2025-06-02 14:36:34 --> Hooks Class Initialized
DEBUG - 2025-06-02 14:36:34 --> UTF-8 Support Enabled
INFO - 2025-06-02 14:36:34 --> Utf8 Class Initialized
INFO - 2025-06-02 14:36:34 --> URI Class Initialized
INFO - 2025-06-02 14:36:34 --> Router Class Initialized
INFO - 2025-06-02 14:36:34 --> Output Class Initialized
INFO - 2025-06-02 14:36:34 --> Security Class Initialized
DEBUG - 2025-06-02 14:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 14:36:34 --> Input Class Initialized
INFO - 2025-06-02 14:36:34 --> Language Class Initialized
INFO - 2025-06-02 14:36:34 --> Loader Class Initialized
INFO - 2025-06-02 14:36:34 --> Helper loaded: url_helper
INFO - 2025-06-02 14:36:34 --> Helper loaded: form_helper
INFO - 2025-06-02 14:36:35 --> Database Driver Class Initialized
DEBUG - 2025-06-02 14:36:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 14:36:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 14:36:35 --> Controller Class Initialized
INFO - 2025-06-02 14:36:35 --> Model "Progress_model" initialized
INFO - 2025-06-02 14:36:35 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 14:36:35 --> Model "User_model" initialized
INFO - 2025-06-02 14:36:35 --> Final output sent to browser
DEBUG - 2025-06-02 14:36:35 --> Total execution time: 0.0769
INFO - 2025-06-02 14:37:07 --> Config Class Initialized
INFO - 2025-06-02 14:37:07 --> Hooks Class Initialized
DEBUG - 2025-06-02 14:37:07 --> UTF-8 Support Enabled
INFO - 2025-06-02 14:37:07 --> Utf8 Class Initialized
INFO - 2025-06-02 14:37:07 --> URI Class Initialized
INFO - 2025-06-02 14:37:07 --> Router Class Initialized
INFO - 2025-06-02 14:37:07 --> Output Class Initialized
INFO - 2025-06-02 14:37:07 --> Security Class Initialized
DEBUG - 2025-06-02 14:37:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 14:37:07 --> Input Class Initialized
INFO - 2025-06-02 14:37:07 --> Language Class Initialized
INFO - 2025-06-02 14:37:07 --> Loader Class Initialized
INFO - 2025-06-02 14:37:07 --> Helper loaded: url_helper
INFO - 2025-06-02 14:37:07 --> Helper loaded: form_helper
INFO - 2025-06-02 14:37:07 --> Database Driver Class Initialized
DEBUG - 2025-06-02 14:37:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 14:37:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 14:37:07 --> Controller Class Initialized
INFO - 2025-06-02 14:37:07 --> Model "Progress_model" initialized
INFO - 2025-06-02 14:37:07 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 14:37:07 --> Model "User_model" initialized
INFO - 2025-06-02 14:37:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 14:37:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 14:37:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-06-02 14:37:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 14:37:07 --> Final output sent to browser
DEBUG - 2025-06-02 14:37:07 --> Total execution time: 0.0790
INFO - 2025-06-02 14:37:08 --> Config Class Initialized
INFO - 2025-06-02 14:37:08 --> Hooks Class Initialized
DEBUG - 2025-06-02 14:37:08 --> UTF-8 Support Enabled
INFO - 2025-06-02 14:37:08 --> Utf8 Class Initialized
INFO - 2025-06-02 14:37:08 --> URI Class Initialized
INFO - 2025-06-02 14:37:08 --> Router Class Initialized
INFO - 2025-06-02 14:37:08 --> Output Class Initialized
INFO - 2025-06-02 14:37:08 --> Security Class Initialized
DEBUG - 2025-06-02 14:37:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 14:37:08 --> Input Class Initialized
INFO - 2025-06-02 14:37:08 --> Language Class Initialized
INFO - 2025-06-02 14:37:08 --> Loader Class Initialized
INFO - 2025-06-02 14:37:08 --> Helper loaded: url_helper
INFO - 2025-06-02 14:37:08 --> Helper loaded: form_helper
INFO - 2025-06-02 14:37:08 --> Database Driver Class Initialized
DEBUG - 2025-06-02 14:37:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 14:37:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 14:37:08 --> Controller Class Initialized
INFO - 2025-06-02 14:37:08 --> Model "Progress_model" initialized
INFO - 2025-06-02 14:37:08 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 14:37:08 --> Model "User_model" initialized
INFO - 2025-06-02 14:37:08 --> Final output sent to browser
DEBUG - 2025-06-02 14:37:08 --> Total execution time: 0.0765
INFO - 2025-06-02 14:37:20 --> Config Class Initialized
INFO - 2025-06-02 14:37:20 --> Hooks Class Initialized
DEBUG - 2025-06-02 14:37:20 --> UTF-8 Support Enabled
INFO - 2025-06-02 14:37:20 --> Utf8 Class Initialized
INFO - 2025-06-02 14:37:20 --> URI Class Initialized
INFO - 2025-06-02 14:37:20 --> Router Class Initialized
INFO - 2025-06-02 14:37:20 --> Output Class Initialized
INFO - 2025-06-02 14:37:20 --> Security Class Initialized
DEBUG - 2025-06-02 14:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 14:37:20 --> Input Class Initialized
INFO - 2025-06-02 14:37:20 --> Language Class Initialized
INFO - 2025-06-02 14:37:20 --> Loader Class Initialized
INFO - 2025-06-02 14:37:20 --> Helper loaded: url_helper
INFO - 2025-06-02 14:37:20 --> Helper loaded: form_helper
INFO - 2025-06-02 14:37:20 --> Database Driver Class Initialized
DEBUG - 2025-06-02 14:37:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 14:37:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 14:37:20 --> Controller Class Initialized
INFO - 2025-06-02 14:37:20 --> Model "Progress_model" initialized
INFO - 2025-06-02 14:37:20 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 14:37:20 --> Model "User_model" initialized
INFO - 2025-06-02 14:37:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 14:37:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 14:37:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-06-02 14:37:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 14:37:20 --> Final output sent to browser
DEBUG - 2025-06-02 14:37:20 --> Total execution time: 0.0788
INFO - 2025-06-02 14:37:20 --> Config Class Initialized
INFO - 2025-06-02 14:37:20 --> Hooks Class Initialized
DEBUG - 2025-06-02 14:37:20 --> UTF-8 Support Enabled
INFO - 2025-06-02 14:37:20 --> Utf8 Class Initialized
INFO - 2025-06-02 14:37:20 --> URI Class Initialized
INFO - 2025-06-02 14:37:20 --> Router Class Initialized
INFO - 2025-06-02 14:37:20 --> Output Class Initialized
INFO - 2025-06-02 14:37:20 --> Security Class Initialized
DEBUG - 2025-06-02 14:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 14:37:20 --> Input Class Initialized
INFO - 2025-06-02 14:37:20 --> Language Class Initialized
INFO - 2025-06-02 14:37:20 --> Loader Class Initialized
INFO - 2025-06-02 14:37:20 --> Helper loaded: url_helper
INFO - 2025-06-02 14:37:20 --> Helper loaded: form_helper
INFO - 2025-06-02 14:37:20 --> Database Driver Class Initialized
DEBUG - 2025-06-02 14:37:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 14:37:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 14:37:20 --> Controller Class Initialized
INFO - 2025-06-02 14:37:20 --> Model "Progress_model" initialized
INFO - 2025-06-02 14:37:20 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 14:37:20 --> Model "User_model" initialized
INFO - 2025-06-02 14:37:20 --> Final output sent to browser
DEBUG - 2025-06-02 14:37:20 --> Total execution time: 0.0834
INFO - 2025-06-02 14:37:29 --> Config Class Initialized
INFO - 2025-06-02 14:37:29 --> Hooks Class Initialized
DEBUG - 2025-06-02 14:37:29 --> UTF-8 Support Enabled
INFO - 2025-06-02 14:37:29 --> Utf8 Class Initialized
INFO - 2025-06-02 14:37:29 --> URI Class Initialized
INFO - 2025-06-02 14:37:29 --> Router Class Initialized
INFO - 2025-06-02 14:37:29 --> Output Class Initialized
INFO - 2025-06-02 14:37:29 --> Security Class Initialized
DEBUG - 2025-06-02 14:37:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 14:37:29 --> Input Class Initialized
INFO - 2025-06-02 14:37:29 --> Language Class Initialized
INFO - 2025-06-02 14:37:29 --> Loader Class Initialized
INFO - 2025-06-02 14:37:29 --> Helper loaded: url_helper
INFO - 2025-06-02 14:37:29 --> Helper loaded: form_helper
INFO - 2025-06-02 14:37:29 --> Database Driver Class Initialized
DEBUG - 2025-06-02 14:37:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 14:37:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 14:37:29 --> Controller Class Initialized
INFO - 2025-06-02 14:37:29 --> Model "Progress_model" initialized
INFO - 2025-06-02 14:37:29 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 14:37:29 --> Model "User_model" initialized
INFO - 2025-06-02 14:37:29 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 14:37:29 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 14:37:29 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-06-02 14:37:29 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 14:37:29 --> Final output sent to browser
DEBUG - 2025-06-02 14:37:29 --> Total execution time: 0.0803
INFO - 2025-06-02 14:37:29 --> Config Class Initialized
INFO - 2025-06-02 14:37:29 --> Hooks Class Initialized
DEBUG - 2025-06-02 14:37:29 --> UTF-8 Support Enabled
INFO - 2025-06-02 14:37:29 --> Utf8 Class Initialized
INFO - 2025-06-02 14:37:29 --> URI Class Initialized
INFO - 2025-06-02 14:37:29 --> Router Class Initialized
INFO - 2025-06-02 14:37:29 --> Output Class Initialized
INFO - 2025-06-02 14:37:29 --> Security Class Initialized
DEBUG - 2025-06-02 14:37:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 14:37:29 --> Input Class Initialized
INFO - 2025-06-02 14:37:29 --> Language Class Initialized
INFO - 2025-06-02 14:37:29 --> Loader Class Initialized
INFO - 2025-06-02 14:37:29 --> Helper loaded: url_helper
INFO - 2025-06-02 14:37:29 --> Helper loaded: form_helper
INFO - 2025-06-02 14:37:29 --> Database Driver Class Initialized
DEBUG - 2025-06-02 14:37:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 14:37:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 14:37:29 --> Controller Class Initialized
INFO - 2025-06-02 14:37:29 --> Model "Progress_model" initialized
INFO - 2025-06-02 14:37:29 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 14:37:29 --> Model "User_model" initialized
INFO - 2025-06-02 14:37:29 --> Final output sent to browser
DEBUG - 2025-06-02 14:37:29 --> Total execution time: 0.0774
INFO - 2025-06-02 14:37:37 --> Config Class Initialized
INFO - 2025-06-02 14:37:37 --> Hooks Class Initialized
DEBUG - 2025-06-02 14:37:37 --> UTF-8 Support Enabled
INFO - 2025-06-02 14:37:37 --> Utf8 Class Initialized
INFO - 2025-06-02 14:37:37 --> URI Class Initialized
INFO - 2025-06-02 14:37:37 --> Router Class Initialized
INFO - 2025-06-02 14:37:37 --> Output Class Initialized
INFO - 2025-06-02 14:37:37 --> Security Class Initialized
DEBUG - 2025-06-02 14:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 14:37:37 --> Input Class Initialized
INFO - 2025-06-02 14:37:37 --> Language Class Initialized
INFO - 2025-06-02 14:37:37 --> Loader Class Initialized
INFO - 2025-06-02 14:37:37 --> Helper loaded: url_helper
INFO - 2025-06-02 14:37:37 --> Helper loaded: form_helper
INFO - 2025-06-02 14:37:37 --> Database Driver Class Initialized
DEBUG - 2025-06-02 14:37:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 14:37:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 14:37:37 --> Controller Class Initialized
INFO - 2025-06-02 14:37:37 --> Model "Progress_model" initialized
INFO - 2025-06-02 14:37:37 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 14:37:37 --> Model "User_model" initialized
INFO - 2025-06-02 14:37:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 14:37:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 14:37:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-06-02 14:37:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 14:37:37 --> Final output sent to browser
DEBUG - 2025-06-02 14:37:37 --> Total execution time: 0.0670
INFO - 2025-06-02 14:37:37 --> Config Class Initialized
INFO - 2025-06-02 14:37:37 --> Hooks Class Initialized
DEBUG - 2025-06-02 14:37:37 --> UTF-8 Support Enabled
INFO - 2025-06-02 14:37:37 --> Utf8 Class Initialized
INFO - 2025-06-02 14:37:37 --> URI Class Initialized
INFO - 2025-06-02 14:37:37 --> Router Class Initialized
INFO - 2025-06-02 14:37:37 --> Output Class Initialized
INFO - 2025-06-02 14:37:37 --> Security Class Initialized
DEBUG - 2025-06-02 14:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 14:37:37 --> Input Class Initialized
INFO - 2025-06-02 14:37:37 --> Language Class Initialized
INFO - 2025-06-02 14:37:37 --> Loader Class Initialized
INFO - 2025-06-02 14:37:37 --> Helper loaded: url_helper
INFO - 2025-06-02 14:37:37 --> Helper loaded: form_helper
INFO - 2025-06-02 14:37:37 --> Database Driver Class Initialized
DEBUG - 2025-06-02 14:37:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 14:37:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 14:37:37 --> Controller Class Initialized
INFO - 2025-06-02 14:37:37 --> Model "Progress_model" initialized
INFO - 2025-06-02 14:37:37 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 14:37:37 --> Model "User_model" initialized
INFO - 2025-06-02 14:37:37 --> Final output sent to browser
DEBUG - 2025-06-02 14:37:37 --> Total execution time: 0.0764
INFO - 2025-06-02 14:41:08 --> Config Class Initialized
INFO - 2025-06-02 14:41:08 --> Hooks Class Initialized
DEBUG - 2025-06-02 14:41:08 --> UTF-8 Support Enabled
INFO - 2025-06-02 14:41:08 --> Utf8 Class Initialized
INFO - 2025-06-02 14:41:08 --> URI Class Initialized
INFO - 2025-06-02 14:41:08 --> Router Class Initialized
INFO - 2025-06-02 14:41:08 --> Output Class Initialized
INFO - 2025-06-02 14:41:08 --> Security Class Initialized
DEBUG - 2025-06-02 14:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 14:41:08 --> Input Class Initialized
INFO - 2025-06-02 14:41:08 --> Language Class Initialized
INFO - 2025-06-02 14:41:08 --> Loader Class Initialized
INFO - 2025-06-02 14:41:08 --> Helper loaded: url_helper
INFO - 2025-06-02 14:41:08 --> Helper loaded: form_helper
INFO - 2025-06-02 14:41:08 --> Database Driver Class Initialized
DEBUG - 2025-06-02 14:41:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 14:41:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 14:41:08 --> Controller Class Initialized
INFO - 2025-06-02 14:41:08 --> Model "User_model" initialized
INFO - 2025-06-02 14:41:08 --> Model "Progress_model" initialized
INFO - 2025-06-02 14:41:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 14:41:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 14:41:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-06-02 14:41:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 14:41:08 --> Final output sent to browser
DEBUG - 2025-06-02 14:41:08 --> Total execution time: 0.0932
INFO - 2025-06-02 14:46:15 --> Config Class Initialized
INFO - 2025-06-02 14:46:15 --> Hooks Class Initialized
DEBUG - 2025-06-02 14:46:15 --> UTF-8 Support Enabled
INFO - 2025-06-02 14:46:15 --> Utf8 Class Initialized
INFO - 2025-06-02 14:46:15 --> URI Class Initialized
INFO - 2025-06-02 14:46:15 --> Router Class Initialized
INFO - 2025-06-02 14:46:15 --> Output Class Initialized
INFO - 2025-06-02 14:46:15 --> Security Class Initialized
DEBUG - 2025-06-02 14:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 14:46:15 --> Input Class Initialized
INFO - 2025-06-02 14:46:15 --> Language Class Initialized
INFO - 2025-06-02 14:46:15 --> Loader Class Initialized
INFO - 2025-06-02 14:46:15 --> Helper loaded: url_helper
INFO - 2025-06-02 14:46:15 --> Helper loaded: form_helper
INFO - 2025-06-02 14:46:15 --> Database Driver Class Initialized
DEBUG - 2025-06-02 14:46:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 14:46:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 14:46:15 --> Controller Class Initialized
INFO - 2025-06-02 14:46:15 --> Model "User_model" initialized
INFO - 2025-06-02 14:46:15 --> Model "Progress_model" initialized
INFO - 2025-06-02 14:46:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 14:46:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 14:46:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-06-02 14:46:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 14:46:15 --> Final output sent to browser
DEBUG - 2025-06-02 14:46:15 --> Total execution time: 0.0869
INFO - 2025-06-02 14:46:17 --> Config Class Initialized
INFO - 2025-06-02 14:46:17 --> Hooks Class Initialized
DEBUG - 2025-06-02 14:46:17 --> UTF-8 Support Enabled
INFO - 2025-06-02 14:46:17 --> Utf8 Class Initialized
INFO - 2025-06-02 14:46:17 --> URI Class Initialized
INFO - 2025-06-02 14:46:17 --> Router Class Initialized
INFO - 2025-06-02 14:46:17 --> Output Class Initialized
INFO - 2025-06-02 14:46:17 --> Security Class Initialized
DEBUG - 2025-06-02 14:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 14:46:17 --> Input Class Initialized
INFO - 2025-06-02 14:46:17 --> Language Class Initialized
INFO - 2025-06-02 14:46:17 --> Loader Class Initialized
INFO - 2025-06-02 14:46:17 --> Helper loaded: url_helper
INFO - 2025-06-02 14:46:17 --> Helper loaded: form_helper
INFO - 2025-06-02 14:46:17 --> Database Driver Class Initialized
DEBUG - 2025-06-02 14:46:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 14:46:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 14:46:17 --> Controller Class Initialized
INFO - 2025-06-02 14:46:17 --> Model "User_model" initialized
INFO - 2025-06-02 14:46:17 --> Model "Community_model" initialized
INFO - 2025-06-02 14:46:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 14:46:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 14:46:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/community.php
INFO - 2025-06-02 14:46:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 14:46:17 --> Final output sent to browser
DEBUG - 2025-06-02 14:46:17 --> Total execution time: 0.0670
INFO - 2025-06-02 14:46:39 --> Config Class Initialized
INFO - 2025-06-02 14:46:39 --> Hooks Class Initialized
DEBUG - 2025-06-02 14:46:39 --> UTF-8 Support Enabled
INFO - 2025-06-02 14:46:39 --> Utf8 Class Initialized
INFO - 2025-06-02 14:46:39 --> URI Class Initialized
INFO - 2025-06-02 14:46:39 --> Router Class Initialized
INFO - 2025-06-02 14:46:39 --> Output Class Initialized
INFO - 2025-06-02 14:46:39 --> Security Class Initialized
DEBUG - 2025-06-02 14:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 14:46:39 --> Input Class Initialized
INFO - 2025-06-02 14:46:39 --> Language Class Initialized
INFO - 2025-06-02 14:46:39 --> Loader Class Initialized
INFO - 2025-06-02 14:46:39 --> Helper loaded: url_helper
INFO - 2025-06-02 14:46:39 --> Helper loaded: form_helper
INFO - 2025-06-02 14:46:39 --> Database Driver Class Initialized
DEBUG - 2025-06-02 14:46:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 14:46:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 14:46:39 --> Controller Class Initialized
INFO - 2025-06-02 14:46:39 --> Model "User_model" initialized
INFO - 2025-06-02 14:46:39 --> Model "Community_model" initialized
INFO - 2025-06-02 14:46:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 14:46:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 14:46:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/community.php
INFO - 2025-06-02 14:46:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 14:46:39 --> Final output sent to browser
DEBUG - 2025-06-02 14:46:39 --> Total execution time: 0.0677
INFO - 2025-06-02 14:46:44 --> Config Class Initialized
INFO - 2025-06-02 14:46:44 --> Hooks Class Initialized
DEBUG - 2025-06-02 14:46:44 --> UTF-8 Support Enabled
INFO - 2025-06-02 14:46:44 --> Utf8 Class Initialized
INFO - 2025-06-02 14:46:44 --> URI Class Initialized
INFO - 2025-06-02 14:46:44 --> Router Class Initialized
INFO - 2025-06-02 14:46:44 --> Output Class Initialized
INFO - 2025-06-02 14:46:44 --> Security Class Initialized
DEBUG - 2025-06-02 14:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 14:46:44 --> Input Class Initialized
INFO - 2025-06-02 14:46:44 --> Language Class Initialized
INFO - 2025-06-02 14:46:44 --> Loader Class Initialized
INFO - 2025-06-02 14:46:44 --> Helper loaded: url_helper
INFO - 2025-06-02 14:46:44 --> Helper loaded: form_helper
INFO - 2025-06-02 14:46:44 --> Database Driver Class Initialized
DEBUG - 2025-06-02 14:46:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 14:46:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 14:46:44 --> Controller Class Initialized
INFO - 2025-06-02 14:46:44 --> Model "User_model" initialized
INFO - 2025-06-02 14:46:44 --> Model "Community_model" initialized
ERROR - 2025-06-02 14:46:44 --> Query error: Table 'fitnessrec.community_posts' doesn't exist - Invalid query: SELECT *
FROM `community_posts`
WHERE `id` = '1'
INFO - 2025-06-02 14:46:44 --> Language file loaded: language/english/db_lang.php
INFO - 2025-06-02 14:47:57 --> Config Class Initialized
INFO - 2025-06-02 14:47:57 --> Hooks Class Initialized
DEBUG - 2025-06-02 14:47:57 --> UTF-8 Support Enabled
INFO - 2025-06-02 14:47:57 --> Utf8 Class Initialized
INFO - 2025-06-02 14:47:57 --> URI Class Initialized
INFO - 2025-06-02 14:47:57 --> Router Class Initialized
INFO - 2025-06-02 14:47:57 --> Output Class Initialized
INFO - 2025-06-02 14:47:57 --> Security Class Initialized
DEBUG - 2025-06-02 14:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 14:47:57 --> Input Class Initialized
INFO - 2025-06-02 14:47:57 --> Language Class Initialized
INFO - 2025-06-02 14:47:57 --> Loader Class Initialized
INFO - 2025-06-02 14:47:57 --> Helper loaded: url_helper
INFO - 2025-06-02 14:47:57 --> Helper loaded: form_helper
INFO - 2025-06-02 14:47:57 --> Database Driver Class Initialized
DEBUG - 2025-06-02 14:47:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 14:47:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 14:47:57 --> Controller Class Initialized
INFO - 2025-06-02 14:47:57 --> Model "User_model" initialized
INFO - 2025-06-02 14:47:57 --> Model "Community_model" initialized
INFO - 2025-06-02 14:47:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 14:47:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 14:47:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/community.php
INFO - 2025-06-02 14:47:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 14:47:57 --> Final output sent to browser
DEBUG - 2025-06-02 14:47:57 --> Total execution time: 0.0948
INFO - 2025-06-02 14:48:00 --> Config Class Initialized
INFO - 2025-06-02 14:48:00 --> Hooks Class Initialized
DEBUG - 2025-06-02 14:48:00 --> UTF-8 Support Enabled
INFO - 2025-06-02 14:48:00 --> Utf8 Class Initialized
INFO - 2025-06-02 14:48:00 --> URI Class Initialized
INFO - 2025-06-02 14:48:00 --> Router Class Initialized
INFO - 2025-06-02 14:48:00 --> Output Class Initialized
INFO - 2025-06-02 14:48:00 --> Security Class Initialized
DEBUG - 2025-06-02 14:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 14:48:00 --> Input Class Initialized
INFO - 2025-06-02 14:48:00 --> Language Class Initialized
INFO - 2025-06-02 14:48:00 --> Loader Class Initialized
INFO - 2025-06-02 14:48:00 --> Helper loaded: url_helper
INFO - 2025-06-02 14:48:00 --> Helper loaded: form_helper
INFO - 2025-06-02 14:48:00 --> Database Driver Class Initialized
DEBUG - 2025-06-02 14:48:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 14:48:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 14:48:00 --> Controller Class Initialized
INFO - 2025-06-02 14:48:00 --> Model "User_model" initialized
INFO - 2025-06-02 14:48:00 --> Model "Community_model" initialized
INFO - 2025-06-02 14:48:00 --> Config Class Initialized
INFO - 2025-06-02 14:48:00 --> Hooks Class Initialized
DEBUG - 2025-06-02 14:48:00 --> UTF-8 Support Enabled
INFO - 2025-06-02 14:48:00 --> Utf8 Class Initialized
INFO - 2025-06-02 14:48:00 --> URI Class Initialized
INFO - 2025-06-02 14:48:00 --> Router Class Initialized
INFO - 2025-06-02 14:48:00 --> Output Class Initialized
INFO - 2025-06-02 14:48:00 --> Security Class Initialized
DEBUG - 2025-06-02 14:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 14:48:00 --> Input Class Initialized
INFO - 2025-06-02 14:48:00 --> Language Class Initialized
INFO - 2025-06-02 14:48:00 --> Loader Class Initialized
INFO - 2025-06-02 14:48:00 --> Helper loaded: url_helper
INFO - 2025-06-02 14:48:00 --> Helper loaded: form_helper
INFO - 2025-06-02 14:48:00 --> Database Driver Class Initialized
DEBUG - 2025-06-02 14:48:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 14:48:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 14:48:00 --> Controller Class Initialized
INFO - 2025-06-02 14:48:00 --> Model "User_model" initialized
INFO - 2025-06-02 14:48:00 --> Model "Community_model" initialized
INFO - 2025-06-02 14:48:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 14:48:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 14:48:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/community.php
INFO - 2025-06-02 14:48:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 14:48:00 --> Final output sent to browser
DEBUG - 2025-06-02 14:48:00 --> Total execution time: 0.0817
INFO - 2025-06-02 14:48:08 --> Config Class Initialized
INFO - 2025-06-02 14:48:08 --> Hooks Class Initialized
DEBUG - 2025-06-02 14:48:08 --> UTF-8 Support Enabled
INFO - 2025-06-02 14:48:08 --> Utf8 Class Initialized
INFO - 2025-06-02 14:48:08 --> URI Class Initialized
INFO - 2025-06-02 14:48:08 --> Router Class Initialized
INFO - 2025-06-02 14:48:08 --> Output Class Initialized
INFO - 2025-06-02 14:48:08 --> Security Class Initialized
DEBUG - 2025-06-02 14:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 14:48:08 --> Input Class Initialized
INFO - 2025-06-02 14:48:08 --> Language Class Initialized
INFO - 2025-06-02 14:48:08 --> Loader Class Initialized
INFO - 2025-06-02 14:48:08 --> Helper loaded: url_helper
INFO - 2025-06-02 14:48:08 --> Helper loaded: form_helper
INFO - 2025-06-02 14:48:08 --> Database Driver Class Initialized
DEBUG - 2025-06-02 14:48:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 14:48:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 14:48:08 --> Controller Class Initialized
INFO - 2025-06-02 14:48:08 --> Model "User_model" initialized
INFO - 2025-06-02 14:48:08 --> Model "Community_model" initialized
INFO - 2025-06-02 14:48:08 --> Config Class Initialized
INFO - 2025-06-02 14:48:08 --> Hooks Class Initialized
DEBUG - 2025-06-02 14:48:08 --> UTF-8 Support Enabled
INFO - 2025-06-02 14:48:08 --> Utf8 Class Initialized
INFO - 2025-06-02 14:48:08 --> URI Class Initialized
INFO - 2025-06-02 14:48:08 --> Router Class Initialized
INFO - 2025-06-02 14:48:08 --> Output Class Initialized
INFO - 2025-06-02 14:48:08 --> Security Class Initialized
DEBUG - 2025-06-02 14:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 14:48:08 --> Input Class Initialized
INFO - 2025-06-02 14:48:08 --> Language Class Initialized
INFO - 2025-06-02 14:48:08 --> Loader Class Initialized
INFO - 2025-06-02 14:48:08 --> Helper loaded: url_helper
INFO - 2025-06-02 14:48:08 --> Helper loaded: form_helper
INFO - 2025-06-02 14:48:08 --> Database Driver Class Initialized
DEBUG - 2025-06-02 14:48:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 14:48:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 14:48:08 --> Controller Class Initialized
INFO - 2025-06-02 14:48:08 --> Model "User_model" initialized
INFO - 2025-06-02 14:48:08 --> Model "Community_model" initialized
INFO - 2025-06-02 14:48:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 14:48:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 14:48:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/community.php
INFO - 2025-06-02 14:48:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 14:48:08 --> Final output sent to browser
DEBUG - 2025-06-02 14:48:08 --> Total execution time: 0.0689
INFO - 2025-06-02 14:50:25 --> Config Class Initialized
INFO - 2025-06-02 14:50:25 --> Hooks Class Initialized
DEBUG - 2025-06-02 14:50:25 --> UTF-8 Support Enabled
INFO - 2025-06-02 14:50:25 --> Utf8 Class Initialized
INFO - 2025-06-02 14:50:25 --> URI Class Initialized
INFO - 2025-06-02 14:50:25 --> Router Class Initialized
INFO - 2025-06-02 14:50:25 --> Output Class Initialized
INFO - 2025-06-02 14:50:25 --> Security Class Initialized
DEBUG - 2025-06-02 14:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 14:50:25 --> Input Class Initialized
INFO - 2025-06-02 14:50:25 --> Language Class Initialized
INFO - 2025-06-02 14:50:25 --> Loader Class Initialized
INFO - 2025-06-02 14:50:25 --> Helper loaded: url_helper
INFO - 2025-06-02 14:50:25 --> Helper loaded: form_helper
INFO - 2025-06-02 14:50:25 --> Database Driver Class Initialized
DEBUG - 2025-06-02 14:50:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 14:50:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 14:50:25 --> Controller Class Initialized
INFO - 2025-06-02 14:50:25 --> Model "User_model" initialized
INFO - 2025-06-02 14:50:25 --> Model "Progress_model" initialized
INFO - 2025-06-02 14:50:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 14:50:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 14:50:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-06-02 14:50:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 14:50:25 --> Final output sent to browser
DEBUG - 2025-06-02 14:50:25 --> Total execution time: 0.0834
INFO - 2025-06-02 14:53:19 --> Config Class Initialized
INFO - 2025-06-02 14:53:19 --> Hooks Class Initialized
DEBUG - 2025-06-02 14:53:19 --> UTF-8 Support Enabled
INFO - 2025-06-02 14:53:19 --> Utf8 Class Initialized
INFO - 2025-06-02 14:53:19 --> URI Class Initialized
INFO - 2025-06-02 14:53:19 --> Router Class Initialized
INFO - 2025-06-02 14:53:19 --> Output Class Initialized
INFO - 2025-06-02 14:53:19 --> Security Class Initialized
DEBUG - 2025-06-02 14:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 14:53:19 --> Input Class Initialized
INFO - 2025-06-02 14:53:19 --> Language Class Initialized
INFO - 2025-06-02 14:53:19 --> Loader Class Initialized
INFO - 2025-06-02 14:53:19 --> Helper loaded: url_helper
INFO - 2025-06-02 14:53:19 --> Helper loaded: form_helper
INFO - 2025-06-02 14:53:19 --> Database Driver Class Initialized
DEBUG - 2025-06-02 14:53:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 14:53:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 14:53:19 --> Controller Class Initialized
INFO - 2025-06-02 14:53:19 --> Model "User_model" initialized
INFO - 2025-06-02 14:53:19 --> Model "Progress_model" initialized
INFO - 2025-06-02 14:53:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 14:53:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 14:53:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-06-02 14:53:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 14:53:19 --> Final output sent to browser
DEBUG - 2025-06-02 14:53:19 --> Total execution time: 0.0950
INFO - 2025-06-02 14:54:00 --> Config Class Initialized
INFO - 2025-06-02 14:54:00 --> Hooks Class Initialized
DEBUG - 2025-06-02 14:54:00 --> UTF-8 Support Enabled
INFO - 2025-06-02 14:54:00 --> Utf8 Class Initialized
INFO - 2025-06-02 14:54:00 --> URI Class Initialized
INFO - 2025-06-02 14:54:00 --> Router Class Initialized
INFO - 2025-06-02 14:54:00 --> Output Class Initialized
INFO - 2025-06-02 14:54:00 --> Security Class Initialized
DEBUG - 2025-06-02 14:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 14:54:00 --> Input Class Initialized
INFO - 2025-06-02 14:54:00 --> Language Class Initialized
INFO - 2025-06-02 14:54:00 --> Loader Class Initialized
INFO - 2025-06-02 14:54:00 --> Helper loaded: url_helper
INFO - 2025-06-02 14:54:00 --> Helper loaded: form_helper
INFO - 2025-06-02 14:54:00 --> Database Driver Class Initialized
DEBUG - 2025-06-02 14:54:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 14:54:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 14:54:00 --> Controller Class Initialized
INFO - 2025-06-02 14:54:00 --> Model "User_model" initialized
INFO - 2025-06-02 14:54:00 --> Model "Progress_model" initialized
INFO - 2025-06-02 14:54:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 14:54:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 14:54:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-06-02 14:54:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 14:54:00 --> Final output sent to browser
DEBUG - 2025-06-02 14:54:00 --> Total execution time: 0.0844
INFO - 2025-06-02 14:55:52 --> Config Class Initialized
INFO - 2025-06-02 14:55:52 --> Hooks Class Initialized
DEBUG - 2025-06-02 14:55:52 --> UTF-8 Support Enabled
INFO - 2025-06-02 14:55:52 --> Utf8 Class Initialized
INFO - 2025-06-02 14:55:52 --> URI Class Initialized
INFO - 2025-06-02 14:55:52 --> Router Class Initialized
INFO - 2025-06-02 14:55:52 --> Output Class Initialized
INFO - 2025-06-02 14:55:52 --> Security Class Initialized
DEBUG - 2025-06-02 14:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 14:55:52 --> Input Class Initialized
INFO - 2025-06-02 14:55:52 --> Language Class Initialized
INFO - 2025-06-02 14:55:52 --> Loader Class Initialized
INFO - 2025-06-02 14:55:52 --> Helper loaded: url_helper
INFO - 2025-06-02 14:55:52 --> Helper loaded: form_helper
INFO - 2025-06-02 14:55:52 --> Database Driver Class Initialized
DEBUG - 2025-06-02 14:55:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 14:55:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 14:55:52 --> Controller Class Initialized
INFO - 2025-06-02 14:55:52 --> Model "User_model" initialized
INFO - 2025-06-02 14:55:52 --> Model "Progress_model" initialized
INFO - 2025-06-02 14:55:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 14:55:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 14:55:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-06-02 14:55:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 14:55:52 --> Final output sent to browser
DEBUG - 2025-06-02 14:55:52 --> Total execution time: 0.0823
INFO - 2025-06-02 14:55:59 --> Config Class Initialized
INFO - 2025-06-02 14:55:59 --> Hooks Class Initialized
DEBUG - 2025-06-02 14:55:59 --> UTF-8 Support Enabled
INFO - 2025-06-02 14:55:59 --> Utf8 Class Initialized
INFO - 2025-06-02 14:55:59 --> URI Class Initialized
INFO - 2025-06-02 14:55:59 --> Router Class Initialized
INFO - 2025-06-02 14:55:59 --> Output Class Initialized
INFO - 2025-06-02 14:55:59 --> Security Class Initialized
DEBUG - 2025-06-02 14:55:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 14:55:59 --> Input Class Initialized
INFO - 2025-06-02 14:55:59 --> Language Class Initialized
INFO - 2025-06-02 14:55:59 --> Loader Class Initialized
INFO - 2025-06-02 14:55:59 --> Helper loaded: url_helper
INFO - 2025-06-02 14:55:59 --> Helper loaded: form_helper
INFO - 2025-06-02 14:55:59 --> Database Driver Class Initialized
DEBUG - 2025-06-02 14:55:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 14:55:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 14:55:59 --> Controller Class Initialized
INFO - 2025-06-02 14:55:59 --> Model "User_model" initialized
INFO - 2025-06-02 14:55:59 --> Model "Progress_model" initialized
INFO - 2025-06-02 14:55:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 14:55:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 14:55:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-06-02 14:55:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 14:55:59 --> Final output sent to browser
DEBUG - 2025-06-02 14:55:59 --> Total execution time: 0.0843
INFO - 2025-06-02 14:56:49 --> Config Class Initialized
INFO - 2025-06-02 14:56:49 --> Hooks Class Initialized
DEBUG - 2025-06-02 14:56:49 --> UTF-8 Support Enabled
INFO - 2025-06-02 14:56:49 --> Utf8 Class Initialized
INFO - 2025-06-02 14:56:49 --> URI Class Initialized
INFO - 2025-06-02 14:56:49 --> Router Class Initialized
INFO - 2025-06-02 14:56:49 --> Output Class Initialized
INFO - 2025-06-02 14:56:49 --> Security Class Initialized
DEBUG - 2025-06-02 14:56:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 14:56:49 --> Input Class Initialized
INFO - 2025-06-02 14:56:49 --> Language Class Initialized
INFO - 2025-06-02 14:56:49 --> Loader Class Initialized
INFO - 2025-06-02 14:56:49 --> Helper loaded: url_helper
INFO - 2025-06-02 14:56:49 --> Helper loaded: form_helper
INFO - 2025-06-02 14:56:49 --> Database Driver Class Initialized
DEBUG - 2025-06-02 14:56:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 14:56:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 14:56:49 --> Controller Class Initialized
INFO - 2025-06-02 14:56:49 --> Model "User_model" initialized
INFO - 2025-06-02 14:56:49 --> Model "Progress_model" initialized
INFO - 2025-06-02 14:56:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 14:56:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 14:56:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-06-02 14:56:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 14:56:49 --> Final output sent to browser
DEBUG - 2025-06-02 14:56:49 --> Total execution time: 0.0832
INFO - 2025-06-02 14:57:07 --> Config Class Initialized
INFO - 2025-06-02 14:57:07 --> Hooks Class Initialized
DEBUG - 2025-06-02 14:57:07 --> UTF-8 Support Enabled
INFO - 2025-06-02 14:57:07 --> Utf8 Class Initialized
INFO - 2025-06-02 14:57:07 --> URI Class Initialized
INFO - 2025-06-02 14:57:07 --> Router Class Initialized
INFO - 2025-06-02 14:57:07 --> Output Class Initialized
INFO - 2025-06-02 14:57:07 --> Security Class Initialized
DEBUG - 2025-06-02 14:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 14:57:07 --> Input Class Initialized
INFO - 2025-06-02 14:57:07 --> Language Class Initialized
INFO - 2025-06-02 14:57:07 --> Loader Class Initialized
INFO - 2025-06-02 14:57:07 --> Helper loaded: url_helper
INFO - 2025-06-02 14:57:07 --> Helper loaded: form_helper
INFO - 2025-06-02 14:57:07 --> Database Driver Class Initialized
DEBUG - 2025-06-02 14:57:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 14:57:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 14:57:07 --> Controller Class Initialized
INFO - 2025-06-02 14:57:07 --> Model "User_model" initialized
INFO - 2025-06-02 14:57:07 --> Model "Progress_model" initialized
INFO - 2025-06-02 14:57:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 14:57:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 14:57:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-06-02 14:57:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 14:57:07 --> Final output sent to browser
DEBUG - 2025-06-02 14:57:07 --> Total execution time: 0.0784
INFO - 2025-06-02 14:57:26 --> Config Class Initialized
INFO - 2025-06-02 14:57:26 --> Hooks Class Initialized
DEBUG - 2025-06-02 14:57:26 --> UTF-8 Support Enabled
INFO - 2025-06-02 14:57:26 --> Utf8 Class Initialized
INFO - 2025-06-02 14:57:26 --> URI Class Initialized
INFO - 2025-06-02 14:57:26 --> Router Class Initialized
INFO - 2025-06-02 14:57:26 --> Output Class Initialized
INFO - 2025-06-02 14:57:26 --> Security Class Initialized
DEBUG - 2025-06-02 14:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 14:57:26 --> Input Class Initialized
INFO - 2025-06-02 14:57:26 --> Language Class Initialized
INFO - 2025-06-02 14:57:26 --> Loader Class Initialized
INFO - 2025-06-02 14:57:26 --> Helper loaded: url_helper
INFO - 2025-06-02 14:57:26 --> Helper loaded: form_helper
INFO - 2025-06-02 14:57:26 --> Database Driver Class Initialized
DEBUG - 2025-06-02 14:57:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 14:57:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 14:57:26 --> Controller Class Initialized
INFO - 2025-06-02 14:57:26 --> Model "User_model" initialized
INFO - 2025-06-02 14:57:26 --> Model "Progress_model" initialized
INFO - 2025-06-02 14:57:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 14:57:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 14:57:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-06-02 14:57:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 14:57:26 --> Final output sent to browser
DEBUG - 2025-06-02 14:57:26 --> Total execution time: 0.0869
INFO - 2025-06-02 15:01:30 --> Config Class Initialized
INFO - 2025-06-02 15:01:30 --> Hooks Class Initialized
DEBUG - 2025-06-02 15:01:30 --> UTF-8 Support Enabled
INFO - 2025-06-02 15:01:30 --> Utf8 Class Initialized
INFO - 2025-06-02 15:01:30 --> URI Class Initialized
INFO - 2025-06-02 15:01:30 --> Router Class Initialized
INFO - 2025-06-02 15:01:30 --> Output Class Initialized
INFO - 2025-06-02 15:01:30 --> Security Class Initialized
DEBUG - 2025-06-02 15:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 15:01:30 --> Input Class Initialized
INFO - 2025-06-02 15:01:30 --> Language Class Initialized
INFO - 2025-06-02 15:01:30 --> Loader Class Initialized
INFO - 2025-06-02 15:01:30 --> Helper loaded: url_helper
INFO - 2025-06-02 15:01:30 --> Helper loaded: form_helper
INFO - 2025-06-02 15:01:30 --> Database Driver Class Initialized
DEBUG - 2025-06-02 15:01:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 15:01:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 15:01:30 --> Controller Class Initialized
INFO - 2025-06-02 15:01:30 --> Model "User_model" initialized
INFO - 2025-06-02 15:01:30 --> Model "Progress_model" initialized
INFO - 2025-06-02 15:01:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 15:01:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 15:01:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-06-02 15:01:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 15:01:30 --> Final output sent to browser
DEBUG - 2025-06-02 15:01:30 --> Total execution time: 0.0770
INFO - 2025-06-02 15:01:45 --> Config Class Initialized
INFO - 2025-06-02 15:01:45 --> Hooks Class Initialized
DEBUG - 2025-06-02 15:01:45 --> UTF-8 Support Enabled
INFO - 2025-06-02 15:01:45 --> Utf8 Class Initialized
INFO - 2025-06-02 15:01:45 --> URI Class Initialized
INFO - 2025-06-02 15:01:45 --> Router Class Initialized
INFO - 2025-06-02 15:01:45 --> Output Class Initialized
INFO - 2025-06-02 15:01:45 --> Security Class Initialized
DEBUG - 2025-06-02 15:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 15:01:45 --> Input Class Initialized
INFO - 2025-06-02 15:01:45 --> Language Class Initialized
INFO - 2025-06-02 15:01:45 --> Loader Class Initialized
INFO - 2025-06-02 15:01:45 --> Helper loaded: url_helper
INFO - 2025-06-02 15:01:45 --> Helper loaded: form_helper
INFO - 2025-06-02 15:01:45 --> Database Driver Class Initialized
DEBUG - 2025-06-02 15:01:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 15:01:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 15:01:45 --> Controller Class Initialized
INFO - 2025-06-02 15:01:45 --> Model "User_model" initialized
INFO - 2025-06-02 15:01:45 --> Model "Progress_model" initialized
INFO - 2025-06-02 15:01:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 15:01:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 15:01:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-06-02 15:01:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 15:01:45 --> Final output sent to browser
DEBUG - 2025-06-02 15:01:45 --> Total execution time: 0.0736
INFO - 2025-06-02 15:01:49 --> Config Class Initialized
INFO - 2025-06-02 15:01:49 --> Hooks Class Initialized
DEBUG - 2025-06-02 15:01:49 --> UTF-8 Support Enabled
INFO - 2025-06-02 15:01:49 --> Utf8 Class Initialized
INFO - 2025-06-02 15:01:49 --> URI Class Initialized
INFO - 2025-06-02 15:01:49 --> Router Class Initialized
INFO - 2025-06-02 15:01:49 --> Output Class Initialized
INFO - 2025-06-02 15:01:49 --> Security Class Initialized
DEBUG - 2025-06-02 15:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 15:01:49 --> Input Class Initialized
INFO - 2025-06-02 15:01:49 --> Language Class Initialized
INFO - 2025-06-02 15:01:49 --> Loader Class Initialized
INFO - 2025-06-02 15:01:49 --> Helper loaded: url_helper
INFO - 2025-06-02 15:01:49 --> Helper loaded: form_helper
INFO - 2025-06-02 15:01:49 --> Database Driver Class Initialized
DEBUG - 2025-06-02 15:01:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 15:01:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 15:01:49 --> Controller Class Initialized
INFO - 2025-06-02 15:01:49 --> Model "User_model" initialized
INFO - 2025-06-02 15:01:49 --> Model "Progress_model" initialized
INFO - 2025-06-02 15:01:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 15:01:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 15:01:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-06-02 15:01:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 15:01:49 --> Final output sent to browser
DEBUG - 2025-06-02 15:01:49 --> Total execution time: 0.0679
INFO - 2025-06-02 15:02:00 --> Config Class Initialized
INFO - 2025-06-02 15:02:00 --> Hooks Class Initialized
DEBUG - 2025-06-02 15:02:00 --> UTF-8 Support Enabled
INFO - 2025-06-02 15:02:00 --> Utf8 Class Initialized
INFO - 2025-06-02 15:02:00 --> URI Class Initialized
INFO - 2025-06-02 15:02:00 --> Router Class Initialized
INFO - 2025-06-02 15:02:00 --> Output Class Initialized
INFO - 2025-06-02 15:02:00 --> Security Class Initialized
DEBUG - 2025-06-02 15:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 15:02:00 --> Input Class Initialized
INFO - 2025-06-02 15:02:00 --> Language Class Initialized
INFO - 2025-06-02 15:02:00 --> Loader Class Initialized
INFO - 2025-06-02 15:02:00 --> Helper loaded: url_helper
INFO - 2025-06-02 15:02:00 --> Helper loaded: form_helper
INFO - 2025-06-02 15:02:00 --> Database Driver Class Initialized
DEBUG - 2025-06-02 15:02:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 15:02:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 15:02:00 --> Controller Class Initialized
INFO - 2025-06-02 15:02:00 --> Model "User_model" initialized
INFO - 2025-06-02 15:02:00 --> Model "Progress_model" initialized
INFO - 2025-06-02 15:02:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 15:02:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 15:02:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-06-02 15:02:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 15:02:00 --> Final output sent to browser
DEBUG - 2025-06-02 15:02:00 --> Total execution time: 0.0767
INFO - 2025-06-02 15:03:08 --> Config Class Initialized
INFO - 2025-06-02 15:03:08 --> Hooks Class Initialized
DEBUG - 2025-06-02 15:03:08 --> UTF-8 Support Enabled
INFO - 2025-06-02 15:03:08 --> Utf8 Class Initialized
INFO - 2025-06-02 15:03:08 --> URI Class Initialized
INFO - 2025-06-02 15:03:08 --> Router Class Initialized
INFO - 2025-06-02 15:03:08 --> Output Class Initialized
INFO - 2025-06-02 15:03:08 --> Security Class Initialized
DEBUG - 2025-06-02 15:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 15:03:08 --> Input Class Initialized
INFO - 2025-06-02 15:03:08 --> Language Class Initialized
INFO - 2025-06-02 15:03:08 --> Loader Class Initialized
INFO - 2025-06-02 15:03:08 --> Helper loaded: url_helper
INFO - 2025-06-02 15:03:08 --> Helper loaded: form_helper
INFO - 2025-06-02 15:03:08 --> Database Driver Class Initialized
DEBUG - 2025-06-02 15:03:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 15:03:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 15:03:08 --> Controller Class Initialized
INFO - 2025-06-02 15:03:08 --> Model "User_model" initialized
INFO - 2025-06-02 15:03:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-06-02 15:03:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-06-02 15:03:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-06-02 15:03:08 --> Final output sent to browser
DEBUG - 2025-06-02 15:03:08 --> Total execution time: 0.0661
INFO - 2025-06-02 15:28:42 --> Config Class Initialized
INFO - 2025-06-02 15:28:42 --> Hooks Class Initialized
DEBUG - 2025-06-02 15:28:43 --> UTF-8 Support Enabled
INFO - 2025-06-02 15:28:43 --> Utf8 Class Initialized
INFO - 2025-06-02 15:28:43 --> URI Class Initialized
INFO - 2025-06-02 15:28:43 --> Router Class Initialized
INFO - 2025-06-02 15:28:43 --> Output Class Initialized
INFO - 2025-06-02 15:28:43 --> Security Class Initialized
DEBUG - 2025-06-02 15:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 15:28:43 --> Input Class Initialized
INFO - 2025-06-02 15:28:43 --> Language Class Initialized
INFO - 2025-06-02 15:28:43 --> Loader Class Initialized
INFO - 2025-06-02 15:28:43 --> Helper loaded: url_helper
INFO - 2025-06-02 15:28:43 --> Helper loaded: form_helper
INFO - 2025-06-02 15:28:43 --> Database Driver Class Initialized
DEBUG - 2025-06-02 15:28:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 15:28:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 15:28:43 --> Controller Class Initialized
INFO - 2025-06-02 15:28:43 --> Model "User_model" initialized
INFO - 2025-06-02 15:28:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-06-02 15:28:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-06-02 15:28:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-06-02 15:28:43 --> Final output sent to browser
DEBUG - 2025-06-02 15:28:43 --> Total execution time: 0.1439
INFO - 2025-06-02 15:29:54 --> Config Class Initialized
INFO - 2025-06-02 15:29:54 --> Hooks Class Initialized
DEBUG - 2025-06-02 15:29:54 --> UTF-8 Support Enabled
INFO - 2025-06-02 15:29:54 --> Utf8 Class Initialized
INFO - 2025-06-02 15:29:54 --> URI Class Initialized
INFO - 2025-06-02 15:29:54 --> Router Class Initialized
INFO - 2025-06-02 15:29:54 --> Output Class Initialized
INFO - 2025-06-02 15:29:54 --> Security Class Initialized
DEBUG - 2025-06-02 15:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 15:29:54 --> Input Class Initialized
INFO - 2025-06-02 15:29:54 --> Language Class Initialized
INFO - 2025-06-02 15:29:54 --> Loader Class Initialized
INFO - 2025-06-02 15:29:54 --> Helper loaded: url_helper
INFO - 2025-06-02 15:29:54 --> Helper loaded: form_helper
INFO - 2025-06-02 15:29:54 --> Database Driver Class Initialized
DEBUG - 2025-06-02 15:29:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 15:29:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 15:29:55 --> Controller Class Initialized
INFO - 2025-06-02 15:29:55 --> Model "User_model" initialized
INFO - 2025-06-02 15:29:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-06-02 15:29:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-06-02 15:29:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-06-02 15:29:55 --> Final output sent to browser
DEBUG - 2025-06-02 15:29:55 --> Total execution time: 0.0800
INFO - 2025-06-02 15:31:01 --> Config Class Initialized
INFO - 2025-06-02 15:31:01 --> Hooks Class Initialized
DEBUG - 2025-06-02 15:31:01 --> UTF-8 Support Enabled
INFO - 2025-06-02 15:31:01 --> Utf8 Class Initialized
INFO - 2025-06-02 15:31:01 --> URI Class Initialized
INFO - 2025-06-02 15:31:01 --> Router Class Initialized
INFO - 2025-06-02 15:31:01 --> Output Class Initialized
INFO - 2025-06-02 15:31:01 --> Security Class Initialized
DEBUG - 2025-06-02 15:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 15:31:01 --> Input Class Initialized
INFO - 2025-06-02 15:31:01 --> Language Class Initialized
INFO - 2025-06-02 15:31:01 --> Loader Class Initialized
INFO - 2025-06-02 15:31:01 --> Helper loaded: url_helper
INFO - 2025-06-02 15:31:01 --> Helper loaded: form_helper
INFO - 2025-06-02 15:31:01 --> Database Driver Class Initialized
DEBUG - 2025-06-02 15:31:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 15:31:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 15:31:01 --> Controller Class Initialized
INFO - 2025-06-02 15:31:01 --> Model "User_model" initialized
INFO - 2025-06-02 15:31:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-06-02 15:31:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-06-02 15:31:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-06-02 15:31:01 --> Final output sent to browser
DEBUG - 2025-06-02 15:31:01 --> Total execution time: 0.0875
INFO - 2025-06-02 15:33:53 --> Config Class Initialized
INFO - 2025-06-02 15:33:53 --> Hooks Class Initialized
DEBUG - 2025-06-02 15:33:53 --> UTF-8 Support Enabled
INFO - 2025-06-02 15:33:53 --> Utf8 Class Initialized
INFO - 2025-06-02 15:33:53 --> URI Class Initialized
INFO - 2025-06-02 15:33:53 --> Router Class Initialized
INFO - 2025-06-02 15:33:53 --> Output Class Initialized
INFO - 2025-06-02 15:33:53 --> Security Class Initialized
DEBUG - 2025-06-02 15:33:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 15:33:53 --> Input Class Initialized
INFO - 2025-06-02 15:33:53 --> Language Class Initialized
INFO - 2025-06-02 15:33:53 --> Loader Class Initialized
INFO - 2025-06-02 15:33:53 --> Helper loaded: url_helper
INFO - 2025-06-02 15:33:53 --> Helper loaded: form_helper
INFO - 2025-06-02 15:33:53 --> Database Driver Class Initialized
DEBUG - 2025-06-02 15:33:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 15:33:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 15:33:53 --> Controller Class Initialized
INFO - 2025-06-02 15:33:53 --> Model "User_model" initialized
INFO - 2025-06-02 15:33:53 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-06-02 15:33:53 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-06-02 15:33:53 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-06-02 15:33:53 --> Final output sent to browser
DEBUG - 2025-06-02 15:33:53 --> Total execution time: 0.0781
INFO - 2025-06-02 15:35:06 --> Config Class Initialized
INFO - 2025-06-02 15:35:06 --> Hooks Class Initialized
DEBUG - 2025-06-02 15:35:06 --> UTF-8 Support Enabled
INFO - 2025-06-02 15:35:06 --> Utf8 Class Initialized
INFO - 2025-06-02 15:35:06 --> URI Class Initialized
INFO - 2025-06-02 15:35:06 --> Router Class Initialized
INFO - 2025-06-02 15:35:06 --> Output Class Initialized
INFO - 2025-06-02 15:35:06 --> Security Class Initialized
DEBUG - 2025-06-02 15:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 15:35:06 --> Input Class Initialized
INFO - 2025-06-02 15:35:06 --> Language Class Initialized
INFO - 2025-06-02 15:35:06 --> Loader Class Initialized
INFO - 2025-06-02 15:35:06 --> Helper loaded: url_helper
INFO - 2025-06-02 15:35:06 --> Helper loaded: form_helper
INFO - 2025-06-02 15:35:06 --> Database Driver Class Initialized
DEBUG - 2025-06-02 15:35:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 15:35:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 15:35:06 --> Controller Class Initialized
INFO - 2025-06-02 15:35:06 --> Model "User_model" initialized
INFO - 2025-06-02 15:35:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-06-02 15:35:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-06-02 15:35:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-06-02 15:35:06 --> Final output sent to browser
DEBUG - 2025-06-02 15:35:06 --> Total execution time: 0.0802
INFO - 2025-06-02 15:35:10 --> Config Class Initialized
INFO - 2025-06-02 15:35:10 --> Hooks Class Initialized
DEBUG - 2025-06-02 15:35:10 --> UTF-8 Support Enabled
INFO - 2025-06-02 15:35:10 --> Utf8 Class Initialized
INFO - 2025-06-02 15:35:10 --> URI Class Initialized
INFO - 2025-06-02 15:35:10 --> Router Class Initialized
INFO - 2025-06-02 15:35:10 --> Output Class Initialized
INFO - 2025-06-02 15:35:10 --> Security Class Initialized
DEBUG - 2025-06-02 15:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 15:35:10 --> Input Class Initialized
INFO - 2025-06-02 15:35:10 --> Language Class Initialized
INFO - 2025-06-02 15:35:10 --> Loader Class Initialized
INFO - 2025-06-02 15:35:10 --> Helper loaded: url_helper
INFO - 2025-06-02 15:35:10 --> Helper loaded: form_helper
INFO - 2025-06-02 15:35:10 --> Database Driver Class Initialized
DEBUG - 2025-06-02 15:35:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 15:35:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 15:35:10 --> Controller Class Initialized
INFO - 2025-06-02 15:35:10 --> Model "User_model" initialized
INFO - 2025-06-02 15:35:10 --> Form Validation Class Initialized
INFO - 2025-06-02 15:35:10 --> Config Class Initialized
INFO - 2025-06-02 15:35:10 --> Hooks Class Initialized
DEBUG - 2025-06-02 15:35:10 --> UTF-8 Support Enabled
INFO - 2025-06-02 15:35:10 --> Utf8 Class Initialized
INFO - 2025-06-02 15:35:10 --> URI Class Initialized
INFO - 2025-06-02 15:35:10 --> Router Class Initialized
INFO - 2025-06-02 15:35:10 --> Output Class Initialized
INFO - 2025-06-02 15:35:10 --> Security Class Initialized
DEBUG - 2025-06-02 15:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 15:35:10 --> Input Class Initialized
INFO - 2025-06-02 15:35:10 --> Language Class Initialized
INFO - 2025-06-02 15:35:10 --> Loader Class Initialized
INFO - 2025-06-02 15:35:10 --> Helper loaded: url_helper
INFO - 2025-06-02 15:35:10 --> Helper loaded: form_helper
INFO - 2025-06-02 15:35:10 --> Database Driver Class Initialized
DEBUG - 2025-06-02 15:35:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 15:35:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 15:35:10 --> Controller Class Initialized
INFO - 2025-06-02 15:35:10 --> Model "User_model" initialized
INFO - 2025-06-02 15:35:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-06-02 15:35:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-06-02 15:35:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-06-02 15:35:10 --> Final output sent to browser
DEBUG - 2025-06-02 15:35:10 --> Total execution time: 0.0744
INFO - 2025-06-02 15:35:13 --> Config Class Initialized
INFO - 2025-06-02 15:35:13 --> Hooks Class Initialized
DEBUG - 2025-06-02 15:35:13 --> UTF-8 Support Enabled
INFO - 2025-06-02 15:35:13 --> Utf8 Class Initialized
INFO - 2025-06-02 15:35:13 --> URI Class Initialized
INFO - 2025-06-02 15:35:13 --> Router Class Initialized
INFO - 2025-06-02 15:35:13 --> Output Class Initialized
INFO - 2025-06-02 15:35:13 --> Security Class Initialized
DEBUG - 2025-06-02 15:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 15:35:13 --> Input Class Initialized
INFO - 2025-06-02 15:35:13 --> Language Class Initialized
INFO - 2025-06-02 15:35:13 --> Loader Class Initialized
INFO - 2025-06-02 15:35:13 --> Helper loaded: url_helper
INFO - 2025-06-02 15:35:13 --> Helper loaded: form_helper
INFO - 2025-06-02 15:35:13 --> Database Driver Class Initialized
DEBUG - 2025-06-02 15:35:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 15:35:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 15:35:13 --> Controller Class Initialized
INFO - 2025-06-02 15:35:13 --> Model "User_model" initialized
INFO - 2025-06-02 15:35:13 --> Form Validation Class Initialized
INFO - 2025-06-02 15:35:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-06-02 15:35:13 --> Final output sent to browser
DEBUG - 2025-06-02 15:35:13 --> Total execution time: 0.0691
INFO - 2025-06-02 15:35:16 --> Config Class Initialized
INFO - 2025-06-02 15:35:16 --> Hooks Class Initialized
DEBUG - 2025-06-02 15:35:16 --> UTF-8 Support Enabled
INFO - 2025-06-02 15:35:16 --> Utf8 Class Initialized
INFO - 2025-06-02 15:35:16 --> URI Class Initialized
INFO - 2025-06-02 15:35:16 --> Router Class Initialized
INFO - 2025-06-02 15:35:16 --> Output Class Initialized
INFO - 2025-06-02 15:35:16 --> Security Class Initialized
DEBUG - 2025-06-02 15:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 15:35:17 --> Input Class Initialized
INFO - 2025-06-02 15:35:17 --> Language Class Initialized
INFO - 2025-06-02 15:35:17 --> Loader Class Initialized
INFO - 2025-06-02 15:35:17 --> Helper loaded: url_helper
INFO - 2025-06-02 15:35:17 --> Helper loaded: form_helper
INFO - 2025-06-02 15:35:17 --> Database Driver Class Initialized
DEBUG - 2025-06-02 15:35:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 15:35:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 15:35:17 --> Controller Class Initialized
INFO - 2025-06-02 15:35:17 --> Model "User_model" initialized
INFO - 2025-06-02 15:35:17 --> Form Validation Class Initialized
INFO - 2025-06-02 15:35:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-06-02 15:35:17 --> Final output sent to browser
DEBUG - 2025-06-02 15:35:17 --> Total execution time: 0.0822
INFO - 2025-06-02 15:35:23 --> Config Class Initialized
INFO - 2025-06-02 15:35:23 --> Hooks Class Initialized
DEBUG - 2025-06-02 15:35:23 --> UTF-8 Support Enabled
INFO - 2025-06-02 15:35:23 --> Utf8 Class Initialized
INFO - 2025-06-02 15:35:23 --> URI Class Initialized
INFO - 2025-06-02 15:35:23 --> Router Class Initialized
INFO - 2025-06-02 15:35:23 --> Output Class Initialized
INFO - 2025-06-02 15:35:23 --> Security Class Initialized
DEBUG - 2025-06-02 15:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 15:35:23 --> Input Class Initialized
INFO - 2025-06-02 15:35:23 --> Language Class Initialized
INFO - 2025-06-02 15:35:24 --> Loader Class Initialized
INFO - 2025-06-02 15:35:24 --> Helper loaded: url_helper
INFO - 2025-06-02 15:35:24 --> Helper loaded: form_helper
INFO - 2025-06-02 15:35:24 --> Database Driver Class Initialized
DEBUG - 2025-06-02 15:35:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 15:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 15:35:24 --> Controller Class Initialized
INFO - 2025-06-02 15:35:24 --> Model "User_model" initialized
INFO - 2025-06-02 15:35:24 --> Form Validation Class Initialized
INFO - 2025-06-02 15:35:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-06-02 15:35:24 --> Config Class Initialized
INFO - 2025-06-02 15:35:24 --> Hooks Class Initialized
DEBUG - 2025-06-02 15:35:24 --> UTF-8 Support Enabled
INFO - 2025-06-02 15:35:24 --> Utf8 Class Initialized
INFO - 2025-06-02 15:35:24 --> URI Class Initialized
INFO - 2025-06-02 15:35:24 --> Router Class Initialized
INFO - 2025-06-02 15:35:24 --> Output Class Initialized
INFO - 2025-06-02 15:35:24 --> Security Class Initialized
DEBUG - 2025-06-02 15:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 15:35:24 --> Input Class Initialized
INFO - 2025-06-02 15:35:24 --> Language Class Initialized
INFO - 2025-06-02 15:35:24 --> Loader Class Initialized
INFO - 2025-06-02 15:35:24 --> Helper loaded: url_helper
INFO - 2025-06-02 15:35:24 --> Helper loaded: form_helper
INFO - 2025-06-02 15:35:24 --> Database Driver Class Initialized
DEBUG - 2025-06-02 15:35:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 15:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 15:35:24 --> Controller Class Initialized
INFO - 2025-06-02 15:35:24 --> Model "User_model" initialized
INFO - 2025-06-02 15:35:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-06-02 15:35:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-06-02 15:35:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-06-02 15:35:24 --> Final output sent to browser
DEBUG - 2025-06-02 15:35:24 --> Total execution time: 0.0779
INFO - 2025-06-02 15:35:52 --> Config Class Initialized
INFO - 2025-06-02 15:35:52 --> Hooks Class Initialized
DEBUG - 2025-06-02 15:35:52 --> UTF-8 Support Enabled
INFO - 2025-06-02 15:35:52 --> Utf8 Class Initialized
INFO - 2025-06-02 15:35:52 --> URI Class Initialized
DEBUG - 2025-06-02 15:35:52 --> No URI present. Default controller set.
INFO - 2025-06-02 15:35:52 --> Router Class Initialized
INFO - 2025-06-02 15:35:52 --> Output Class Initialized
INFO - 2025-06-02 15:35:52 --> Security Class Initialized
DEBUG - 2025-06-02 15:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 15:35:52 --> Input Class Initialized
INFO - 2025-06-02 15:35:52 --> Language Class Initialized
INFO - 2025-06-02 15:35:52 --> Loader Class Initialized
INFO - 2025-06-02 15:35:52 --> Helper loaded: url_helper
INFO - 2025-06-02 15:35:52 --> Helper loaded: form_helper
INFO - 2025-06-02 15:35:52 --> Database Driver Class Initialized
DEBUG - 2025-06-02 15:35:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 15:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 15:35:52 --> Controller Class Initialized
INFO - 2025-06-02 15:35:52 --> Model "User_model" initialized
INFO - 2025-06-02 15:35:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-06-02 15:35:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-06-02 15:35:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-06-02 15:35:52 --> Final output sent to browser
DEBUG - 2025-06-02 15:35:52 --> Total execution time: 0.0834
INFO - 2025-06-02 15:36:01 --> Config Class Initialized
INFO - 2025-06-02 15:36:01 --> Hooks Class Initialized
DEBUG - 2025-06-02 15:36:01 --> UTF-8 Support Enabled
INFO - 2025-06-02 15:36:01 --> Utf8 Class Initialized
INFO - 2025-06-02 15:36:01 --> URI Class Initialized
INFO - 2025-06-02 15:36:01 --> Router Class Initialized
INFO - 2025-06-02 15:36:01 --> Output Class Initialized
INFO - 2025-06-02 15:36:01 --> Security Class Initialized
DEBUG - 2025-06-02 15:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 15:36:01 --> Input Class Initialized
INFO - 2025-06-02 15:36:01 --> Language Class Initialized
INFO - 2025-06-02 15:36:01 --> Loader Class Initialized
INFO - 2025-06-02 15:36:01 --> Helper loaded: url_helper
INFO - 2025-06-02 15:36:01 --> Helper loaded: form_helper
INFO - 2025-06-02 15:36:01 --> Database Driver Class Initialized
DEBUG - 2025-06-02 15:36:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 15:36:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 15:36:01 --> Controller Class Initialized
INFO - 2025-06-02 15:36:01 --> Model "User_model" initialized
INFO - 2025-06-02 15:36:01 --> Form Validation Class Initialized
INFO - 2025-06-02 15:36:01 --> Config Class Initialized
INFO - 2025-06-02 15:36:01 --> Hooks Class Initialized
DEBUG - 2025-06-02 15:36:01 --> UTF-8 Support Enabled
INFO - 2025-06-02 15:36:01 --> Utf8 Class Initialized
INFO - 2025-06-02 15:36:01 --> URI Class Initialized
INFO - 2025-06-02 15:36:01 --> Router Class Initialized
INFO - 2025-06-02 15:36:01 --> Output Class Initialized
INFO - 2025-06-02 15:36:01 --> Security Class Initialized
DEBUG - 2025-06-02 15:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 15:36:01 --> Input Class Initialized
INFO - 2025-06-02 15:36:01 --> Language Class Initialized
INFO - 2025-06-02 15:36:01 --> Loader Class Initialized
INFO - 2025-06-02 15:36:01 --> Helper loaded: url_helper
INFO - 2025-06-02 15:36:01 --> Helper loaded: form_helper
INFO - 2025-06-02 15:36:01 --> Database Driver Class Initialized
DEBUG - 2025-06-02 15:36:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 15:36:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 15:36:01 --> Controller Class Initialized
INFO - 2025-06-02 15:36:01 --> Model "User_model" initialized
INFO - 2025-06-02 15:36:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-06-02 15:36:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-06-02 15:36:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-06-02 15:36:01 --> Final output sent to browser
DEBUG - 2025-06-02 15:36:01 --> Total execution time: 0.0672
INFO - 2025-06-02 15:36:03 --> Config Class Initialized
INFO - 2025-06-02 15:36:03 --> Hooks Class Initialized
DEBUG - 2025-06-02 15:36:03 --> UTF-8 Support Enabled
INFO - 2025-06-02 15:36:03 --> Utf8 Class Initialized
INFO - 2025-06-02 15:36:03 --> URI Class Initialized
INFO - 2025-06-02 15:36:03 --> Router Class Initialized
INFO - 2025-06-02 15:36:03 --> Output Class Initialized
INFO - 2025-06-02 15:36:03 --> Security Class Initialized
DEBUG - 2025-06-02 15:36:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 15:36:03 --> Input Class Initialized
INFO - 2025-06-02 15:36:03 --> Language Class Initialized
INFO - 2025-06-02 15:36:03 --> Loader Class Initialized
INFO - 2025-06-02 15:36:03 --> Helper loaded: url_helper
INFO - 2025-06-02 15:36:03 --> Helper loaded: form_helper
INFO - 2025-06-02 15:36:03 --> Database Driver Class Initialized
DEBUG - 2025-06-02 15:36:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 15:36:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 15:36:03 --> Controller Class Initialized
INFO - 2025-06-02 15:36:03 --> Model "User_model" initialized
INFO - 2025-06-02 15:36:03 --> Form Validation Class Initialized
INFO - 2025-06-02 15:36:03 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-06-02 15:36:03 --> Final output sent to browser
DEBUG - 2025-06-02 15:36:03 --> Total execution time: 0.0658
INFO - 2025-06-02 15:36:09 --> Config Class Initialized
INFO - 2025-06-02 15:36:09 --> Hooks Class Initialized
DEBUG - 2025-06-02 15:36:09 --> UTF-8 Support Enabled
INFO - 2025-06-02 15:36:09 --> Utf8 Class Initialized
INFO - 2025-06-02 15:36:09 --> URI Class Initialized
INFO - 2025-06-02 15:36:09 --> Router Class Initialized
INFO - 2025-06-02 15:36:09 --> Output Class Initialized
INFO - 2025-06-02 15:36:09 --> Security Class Initialized
DEBUG - 2025-06-02 15:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 15:36:09 --> Input Class Initialized
INFO - 2025-06-02 15:36:09 --> Language Class Initialized
INFO - 2025-06-02 15:36:09 --> Loader Class Initialized
INFO - 2025-06-02 15:36:09 --> Helper loaded: url_helper
INFO - 2025-06-02 15:36:09 --> Helper loaded: form_helper
INFO - 2025-06-02 15:36:09 --> Database Driver Class Initialized
DEBUG - 2025-06-02 15:36:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 15:36:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 15:36:09 --> Controller Class Initialized
INFO - 2025-06-02 15:36:09 --> Model "User_model" initialized
INFO - 2025-06-02 15:36:09 --> Form Validation Class Initialized
INFO - 2025-06-02 15:36:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-06-02 15:36:09 --> Config Class Initialized
INFO - 2025-06-02 15:36:09 --> Hooks Class Initialized
DEBUG - 2025-06-02 15:36:09 --> UTF-8 Support Enabled
INFO - 2025-06-02 15:36:09 --> Utf8 Class Initialized
INFO - 2025-06-02 15:36:09 --> URI Class Initialized
INFO - 2025-06-02 15:36:09 --> Router Class Initialized
INFO - 2025-06-02 15:36:09 --> Output Class Initialized
INFO - 2025-06-02 15:36:09 --> Security Class Initialized
DEBUG - 2025-06-02 15:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 15:36:09 --> Input Class Initialized
INFO - 2025-06-02 15:36:09 --> Language Class Initialized
INFO - 2025-06-02 15:36:09 --> Loader Class Initialized
INFO - 2025-06-02 15:36:09 --> Helper loaded: url_helper
INFO - 2025-06-02 15:36:09 --> Helper loaded: form_helper
INFO - 2025-06-02 15:36:09 --> Database Driver Class Initialized
DEBUG - 2025-06-02 15:36:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 15:36:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 15:36:09 --> Controller Class Initialized
INFO - 2025-06-02 15:36:09 --> Model "User_model" initialized
INFO - 2025-06-02 15:36:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-06-02 15:36:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-06-02 15:36:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-06-02 15:36:09 --> Final output sent to browser
DEBUG - 2025-06-02 15:36:09 --> Total execution time: 0.0782
INFO - 2025-06-02 15:37:22 --> Config Class Initialized
INFO - 2025-06-02 15:37:22 --> Hooks Class Initialized
DEBUG - 2025-06-02 15:37:22 --> UTF-8 Support Enabled
INFO - 2025-06-02 15:37:22 --> Utf8 Class Initialized
INFO - 2025-06-02 15:37:22 --> URI Class Initialized
INFO - 2025-06-02 15:37:22 --> Router Class Initialized
INFO - 2025-06-02 15:37:22 --> Output Class Initialized
INFO - 2025-06-02 15:37:22 --> Security Class Initialized
DEBUG - 2025-06-02 15:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 15:37:22 --> Input Class Initialized
INFO - 2025-06-02 15:37:22 --> Language Class Initialized
INFO - 2025-06-02 15:37:22 --> Loader Class Initialized
INFO - 2025-06-02 15:37:22 --> Helper loaded: url_helper
INFO - 2025-06-02 15:37:22 --> Helper loaded: form_helper
INFO - 2025-06-02 15:37:22 --> Database Driver Class Initialized
DEBUG - 2025-06-02 15:37:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 15:37:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 15:37:22 --> Controller Class Initialized
INFO - 2025-06-02 15:37:22 --> Model "User_model" initialized
INFO - 2025-06-02 15:37:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-06-02 15:37:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-06-02 15:37:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-06-02 15:37:22 --> Final output sent to browser
DEBUG - 2025-06-02 15:37:22 --> Total execution time: 0.0845
INFO - 2025-06-02 15:42:19 --> Config Class Initialized
INFO - 2025-06-02 15:42:19 --> Hooks Class Initialized
DEBUG - 2025-06-02 15:42:19 --> UTF-8 Support Enabled
INFO - 2025-06-02 15:42:19 --> Utf8 Class Initialized
INFO - 2025-06-02 15:42:19 --> URI Class Initialized
INFO - 2025-06-02 15:42:19 --> Router Class Initialized
INFO - 2025-06-02 15:42:19 --> Output Class Initialized
INFO - 2025-06-02 15:42:19 --> Security Class Initialized
DEBUG - 2025-06-02 15:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 15:42:19 --> Input Class Initialized
INFO - 2025-06-02 15:42:19 --> Language Class Initialized
INFO - 2025-06-02 15:42:19 --> Loader Class Initialized
INFO - 2025-06-02 15:42:19 --> Helper loaded: url_helper
INFO - 2025-06-02 15:42:19 --> Helper loaded: form_helper
INFO - 2025-06-02 15:42:19 --> Database Driver Class Initialized
DEBUG - 2025-06-02 15:42:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 15:42:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 15:42:19 --> Controller Class Initialized
INFO - 2025-06-02 15:42:19 --> Model "User_model" initialized
INFO - 2025-06-02 15:42:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-06-02 15:42:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-06-02 15:42:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-06-02 15:42:19 --> Final output sent to browser
DEBUG - 2025-06-02 15:42:19 --> Total execution time: 0.1051
INFO - 2025-06-02 15:47:12 --> Config Class Initialized
INFO - 2025-06-02 15:47:12 --> Hooks Class Initialized
DEBUG - 2025-06-02 15:47:12 --> UTF-8 Support Enabled
INFO - 2025-06-02 15:47:12 --> Utf8 Class Initialized
INFO - 2025-06-02 15:47:12 --> URI Class Initialized
INFO - 2025-06-02 15:47:12 --> Router Class Initialized
INFO - 2025-06-02 15:47:12 --> Output Class Initialized
INFO - 2025-06-02 15:47:12 --> Security Class Initialized
DEBUG - 2025-06-02 15:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 15:47:12 --> Input Class Initialized
INFO - 2025-06-02 15:47:12 --> Language Class Initialized
INFO - 2025-06-02 15:47:12 --> Loader Class Initialized
INFO - 2025-06-02 15:47:12 --> Helper loaded: url_helper
INFO - 2025-06-02 15:47:12 --> Helper loaded: form_helper
INFO - 2025-06-02 15:47:12 --> Database Driver Class Initialized
DEBUG - 2025-06-02 15:47:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 15:47:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 15:47:12 --> Controller Class Initialized
INFO - 2025-06-02 15:47:12 --> Model "User_model" initialized
INFO - 2025-06-02 15:47:12 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-06-02 15:47:12 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-06-02 15:47:12 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-06-02 15:47:12 --> Final output sent to browser
DEBUG - 2025-06-02 15:47:12 --> Total execution time: 0.0924
INFO - 2025-06-02 15:49:50 --> Config Class Initialized
INFO - 2025-06-02 15:49:50 --> Hooks Class Initialized
DEBUG - 2025-06-02 15:49:50 --> UTF-8 Support Enabled
INFO - 2025-06-02 15:49:50 --> Utf8 Class Initialized
INFO - 2025-06-02 15:49:50 --> URI Class Initialized
INFO - 2025-06-02 15:49:50 --> Router Class Initialized
INFO - 2025-06-02 15:49:50 --> Output Class Initialized
INFO - 2025-06-02 15:49:50 --> Security Class Initialized
DEBUG - 2025-06-02 15:49:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 15:49:50 --> Input Class Initialized
INFO - 2025-06-02 15:49:50 --> Language Class Initialized
INFO - 2025-06-02 15:49:50 --> Loader Class Initialized
INFO - 2025-06-02 15:49:50 --> Helper loaded: url_helper
INFO - 2025-06-02 15:49:50 --> Helper loaded: form_helper
INFO - 2025-06-02 15:49:50 --> Database Driver Class Initialized
DEBUG - 2025-06-02 15:49:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 15:49:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 15:49:50 --> Controller Class Initialized
INFO - 2025-06-02 15:49:50 --> Model "User_model" initialized
INFO - 2025-06-02 15:49:50 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-06-02 15:49:50 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-06-02 15:49:50 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-06-02 15:49:50 --> Final output sent to browser
DEBUG - 2025-06-02 15:49:50 --> Total execution time: 0.0780
INFO - 2025-06-02 15:50:56 --> Config Class Initialized
INFO - 2025-06-02 15:50:56 --> Hooks Class Initialized
DEBUG - 2025-06-02 15:50:56 --> UTF-8 Support Enabled
INFO - 2025-06-02 15:50:56 --> Utf8 Class Initialized
INFO - 2025-06-02 15:50:56 --> URI Class Initialized
INFO - 2025-06-02 15:50:56 --> Router Class Initialized
INFO - 2025-06-02 15:50:56 --> Output Class Initialized
INFO - 2025-06-02 15:50:56 --> Security Class Initialized
DEBUG - 2025-06-02 15:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 15:50:56 --> Input Class Initialized
INFO - 2025-06-02 15:50:56 --> Language Class Initialized
INFO - 2025-06-02 15:50:56 --> Loader Class Initialized
INFO - 2025-06-02 15:50:56 --> Helper loaded: url_helper
INFO - 2025-06-02 15:50:56 --> Helper loaded: form_helper
INFO - 2025-06-02 15:50:56 --> Database Driver Class Initialized
DEBUG - 2025-06-02 15:50:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 15:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 15:50:56 --> Controller Class Initialized
INFO - 2025-06-02 15:50:56 --> Model "User_model" initialized
INFO - 2025-06-02 15:50:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-06-02 15:50:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-06-02 15:50:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-06-02 15:50:56 --> Final output sent to browser
DEBUG - 2025-06-02 15:50:56 --> Total execution time: 0.0723
INFO - 2025-06-02 15:52:12 --> Config Class Initialized
INFO - 2025-06-02 15:52:12 --> Hooks Class Initialized
DEBUG - 2025-06-02 15:52:12 --> UTF-8 Support Enabled
INFO - 2025-06-02 15:52:12 --> Utf8 Class Initialized
INFO - 2025-06-02 15:52:12 --> URI Class Initialized
INFO - 2025-06-02 15:52:12 --> Router Class Initialized
INFO - 2025-06-02 15:52:12 --> Output Class Initialized
INFO - 2025-06-02 15:52:12 --> Security Class Initialized
DEBUG - 2025-06-02 15:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 15:52:12 --> Input Class Initialized
INFO - 2025-06-02 15:52:12 --> Language Class Initialized
INFO - 2025-06-02 15:52:12 --> Loader Class Initialized
INFO - 2025-06-02 15:52:12 --> Helper loaded: url_helper
INFO - 2025-06-02 15:52:12 --> Helper loaded: form_helper
INFO - 2025-06-02 15:52:12 --> Database Driver Class Initialized
DEBUG - 2025-06-02 15:52:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 15:52:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 15:52:12 --> Controller Class Initialized
INFO - 2025-06-02 15:52:12 --> Model "User_model" initialized
INFO - 2025-06-02 15:52:12 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-06-02 15:52:12 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-06-02 15:52:12 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-06-02 15:52:12 --> Final output sent to browser
DEBUG - 2025-06-02 15:52:12 --> Total execution time: 0.0887
INFO - 2025-06-02 15:53:04 --> Config Class Initialized
INFO - 2025-06-02 15:53:04 --> Hooks Class Initialized
DEBUG - 2025-06-02 15:53:04 --> UTF-8 Support Enabled
INFO - 2025-06-02 15:53:04 --> Utf8 Class Initialized
INFO - 2025-06-02 15:53:04 --> URI Class Initialized
INFO - 2025-06-02 15:53:04 --> Router Class Initialized
INFO - 2025-06-02 15:53:04 --> Output Class Initialized
INFO - 2025-06-02 15:53:04 --> Security Class Initialized
DEBUG - 2025-06-02 15:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 15:53:04 --> Input Class Initialized
INFO - 2025-06-02 15:53:04 --> Language Class Initialized
INFO - 2025-06-02 15:53:04 --> Loader Class Initialized
INFO - 2025-06-02 15:53:04 --> Helper loaded: url_helper
INFO - 2025-06-02 15:53:04 --> Helper loaded: form_helper
INFO - 2025-06-02 15:53:04 --> Database Driver Class Initialized
DEBUG - 2025-06-02 15:53:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 15:53:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 15:53:04 --> Controller Class Initialized
INFO - 2025-06-02 15:53:04 --> Model "User_model" initialized
INFO - 2025-06-02 15:53:04 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-06-02 15:53:04 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-06-02 15:53:04 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-06-02 15:53:04 --> Final output sent to browser
DEBUG - 2025-06-02 15:53:04 --> Total execution time: 0.0810
INFO - 2025-06-02 15:53:08 --> Config Class Initialized
INFO - 2025-06-02 15:53:08 --> Hooks Class Initialized
DEBUG - 2025-06-02 15:53:08 --> UTF-8 Support Enabled
INFO - 2025-06-02 15:53:08 --> Utf8 Class Initialized
INFO - 2025-06-02 15:53:08 --> URI Class Initialized
INFO - 2025-06-02 15:53:08 --> Router Class Initialized
INFO - 2025-06-02 15:53:08 --> Output Class Initialized
INFO - 2025-06-02 15:53:08 --> Security Class Initialized
DEBUG - 2025-06-02 15:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 15:53:08 --> Input Class Initialized
INFO - 2025-06-02 15:53:08 --> Language Class Initialized
INFO - 2025-06-02 15:53:08 --> Loader Class Initialized
INFO - 2025-06-02 15:53:08 --> Helper loaded: url_helper
INFO - 2025-06-02 15:53:08 --> Helper loaded: form_helper
INFO - 2025-06-02 15:53:08 --> Database Driver Class Initialized
DEBUG - 2025-06-02 15:53:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 15:53:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 15:53:08 --> Controller Class Initialized
INFO - 2025-06-02 15:53:08 --> Model "User_model" initialized
INFO - 2025-06-02 15:53:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-06-02 15:53:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/artikel.php
INFO - 2025-06-02 15:53:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-06-02 15:53:09 --> Final output sent to browser
DEBUG - 2025-06-02 15:53:09 --> Total execution time: 0.1141
INFO - 2025-06-02 15:53:47 --> Config Class Initialized
INFO - 2025-06-02 15:53:47 --> Hooks Class Initialized
DEBUG - 2025-06-02 15:53:47 --> UTF-8 Support Enabled
INFO - 2025-06-02 15:53:47 --> Utf8 Class Initialized
INFO - 2025-06-02 15:53:47 --> URI Class Initialized
INFO - 2025-06-02 15:53:47 --> Router Class Initialized
INFO - 2025-06-02 15:53:47 --> Output Class Initialized
INFO - 2025-06-02 15:53:47 --> Security Class Initialized
DEBUG - 2025-06-02 15:53:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 15:53:47 --> Input Class Initialized
INFO - 2025-06-02 15:53:47 --> Language Class Initialized
INFO - 2025-06-02 15:53:47 --> Loader Class Initialized
INFO - 2025-06-02 15:53:47 --> Helper loaded: url_helper
INFO - 2025-06-02 15:53:47 --> Helper loaded: form_helper
INFO - 2025-06-02 15:53:47 --> Database Driver Class Initialized
DEBUG - 2025-06-02 15:53:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 15:53:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 15:53:47 --> Controller Class Initialized
INFO - 2025-06-02 15:53:47 --> Model "User_model" initialized
INFO - 2025-06-02 15:53:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-06-02 15:53:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/artikel.php
INFO - 2025-06-02 15:53:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-06-02 15:53:47 --> Final output sent to browser
DEBUG - 2025-06-02 15:53:47 --> Total execution time: 0.0871
INFO - 2025-06-02 15:59:00 --> Config Class Initialized
INFO - 2025-06-02 15:59:00 --> Hooks Class Initialized
DEBUG - 2025-06-02 15:59:00 --> UTF-8 Support Enabled
INFO - 2025-06-02 15:59:00 --> Utf8 Class Initialized
INFO - 2025-06-02 15:59:00 --> URI Class Initialized
INFO - 2025-06-02 15:59:00 --> Router Class Initialized
INFO - 2025-06-02 15:59:00 --> Output Class Initialized
INFO - 2025-06-02 15:59:00 --> Security Class Initialized
DEBUG - 2025-06-02 15:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 15:59:00 --> Input Class Initialized
INFO - 2025-06-02 15:59:00 --> Language Class Initialized
INFO - 2025-06-02 15:59:00 --> Loader Class Initialized
INFO - 2025-06-02 15:59:00 --> Helper loaded: url_helper
INFO - 2025-06-02 15:59:00 --> Helper loaded: form_helper
INFO - 2025-06-02 15:59:00 --> Database Driver Class Initialized
DEBUG - 2025-06-02 15:59:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 15:59:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 15:59:00 --> Controller Class Initialized
INFO - 2025-06-02 15:59:00 --> Model "User_model" initialized
INFO - 2025-06-02 15:59:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-06-02 15:59:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/artikel.php
INFO - 2025-06-02 15:59:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-06-02 15:59:00 --> Final output sent to browser
DEBUG - 2025-06-02 15:59:00 --> Total execution time: 0.0695
INFO - 2025-06-02 16:01:53 --> Config Class Initialized
INFO - 2025-06-02 16:01:53 --> Hooks Class Initialized
DEBUG - 2025-06-02 16:01:53 --> UTF-8 Support Enabled
INFO - 2025-06-02 16:01:53 --> Utf8 Class Initialized
INFO - 2025-06-02 16:01:53 --> URI Class Initialized
INFO - 2025-06-02 16:01:53 --> Router Class Initialized
INFO - 2025-06-02 16:01:53 --> Output Class Initialized
INFO - 2025-06-02 16:01:53 --> Security Class Initialized
DEBUG - 2025-06-02 16:01:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 16:01:53 --> Input Class Initialized
INFO - 2025-06-02 16:01:53 --> Language Class Initialized
INFO - 2025-06-02 16:01:53 --> Loader Class Initialized
INFO - 2025-06-02 16:01:53 --> Helper loaded: url_helper
INFO - 2025-06-02 16:01:53 --> Helper loaded: form_helper
INFO - 2025-06-02 16:01:53 --> Database Driver Class Initialized
DEBUG - 2025-06-02 16:01:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 16:01:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 16:01:53 --> Controller Class Initialized
INFO - 2025-06-02 16:01:53 --> Model "User_model" initialized
INFO - 2025-06-02 16:01:53 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-06-02 16:01:53 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/artikel.php
INFO - 2025-06-02 16:01:53 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-06-02 16:01:53 --> Final output sent to browser
DEBUG - 2025-06-02 16:01:53 --> Total execution time: 0.0809
INFO - 2025-06-02 16:01:59 --> Config Class Initialized
INFO - 2025-06-02 16:01:59 --> Hooks Class Initialized
DEBUG - 2025-06-02 16:01:59 --> UTF-8 Support Enabled
INFO - 2025-06-02 16:01:59 --> Utf8 Class Initialized
INFO - 2025-06-02 16:01:59 --> URI Class Initialized
INFO - 2025-06-02 16:01:59 --> Router Class Initialized
INFO - 2025-06-02 16:01:59 --> Output Class Initialized
INFO - 2025-06-02 16:01:59 --> Security Class Initialized
DEBUG - 2025-06-02 16:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 16:01:59 --> Input Class Initialized
INFO - 2025-06-02 16:01:59 --> Language Class Initialized
INFO - 2025-06-02 16:01:59 --> Loader Class Initialized
INFO - 2025-06-02 16:01:59 --> Helper loaded: url_helper
INFO - 2025-06-02 16:01:59 --> Helper loaded: form_helper
INFO - 2025-06-02 16:01:59 --> Database Driver Class Initialized
DEBUG - 2025-06-02 16:01:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 16:01:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 16:01:59 --> Controller Class Initialized
INFO - 2025-06-02 16:01:59 --> Model "User_model" initialized
INFO - 2025-06-02 16:01:59 --> Form Validation Class Initialized
INFO - 2025-06-02 16:01:59 --> Config Class Initialized
INFO - 2025-06-02 16:01:59 --> Hooks Class Initialized
DEBUG - 2025-06-02 16:01:59 --> UTF-8 Support Enabled
INFO - 2025-06-02 16:01:59 --> Utf8 Class Initialized
INFO - 2025-06-02 16:01:59 --> URI Class Initialized
INFO - 2025-06-02 16:01:59 --> Router Class Initialized
INFO - 2025-06-02 16:01:59 --> Output Class Initialized
INFO - 2025-06-02 16:01:59 --> Security Class Initialized
DEBUG - 2025-06-02 16:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 16:01:59 --> Input Class Initialized
INFO - 2025-06-02 16:01:59 --> Language Class Initialized
INFO - 2025-06-02 16:01:59 --> Loader Class Initialized
INFO - 2025-06-02 16:01:59 --> Helper loaded: url_helper
INFO - 2025-06-02 16:01:59 --> Helper loaded: form_helper
INFO - 2025-06-02 16:01:59 --> Database Driver Class Initialized
DEBUG - 2025-06-02 16:01:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 16:01:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 16:01:59 --> Controller Class Initialized
INFO - 2025-06-02 16:01:59 --> Model "User_model" initialized
INFO - 2025-06-02 16:01:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-06-02 16:01:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-06-02 16:01:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-06-02 16:01:59 --> Final output sent to browser
DEBUG - 2025-06-02 16:01:59 --> Total execution time: 0.0546
INFO - 2025-06-02 16:02:02 --> Config Class Initialized
INFO - 2025-06-02 16:02:02 --> Hooks Class Initialized
DEBUG - 2025-06-02 16:02:02 --> UTF-8 Support Enabled
INFO - 2025-06-02 16:02:02 --> Utf8 Class Initialized
INFO - 2025-06-02 16:02:02 --> URI Class Initialized
INFO - 2025-06-02 16:02:02 --> Router Class Initialized
INFO - 2025-06-02 16:02:02 --> Output Class Initialized
INFO - 2025-06-02 16:02:02 --> Security Class Initialized
DEBUG - 2025-06-02 16:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 16:02:02 --> Input Class Initialized
INFO - 2025-06-02 16:02:02 --> Language Class Initialized
INFO - 2025-06-02 16:02:02 --> Loader Class Initialized
INFO - 2025-06-02 16:02:02 --> Helper loaded: url_helper
INFO - 2025-06-02 16:02:02 --> Helper loaded: form_helper
INFO - 2025-06-02 16:02:02 --> Database Driver Class Initialized
DEBUG - 2025-06-02 16:02:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 16:02:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 16:02:03 --> Controller Class Initialized
INFO - 2025-06-02 16:02:03 --> Model "User_model" initialized
INFO - 2025-06-02 16:02:03 --> Form Validation Class Initialized
INFO - 2025-06-02 16:02:03 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-06-02 16:02:03 --> Final output sent to browser
DEBUG - 2025-06-02 16:02:03 --> Total execution time: 0.0656
INFO - 2025-06-02 16:02:08 --> Config Class Initialized
INFO - 2025-06-02 16:02:08 --> Hooks Class Initialized
DEBUG - 2025-06-02 16:02:08 --> UTF-8 Support Enabled
INFO - 2025-06-02 16:02:08 --> Utf8 Class Initialized
INFO - 2025-06-02 16:02:08 --> URI Class Initialized
INFO - 2025-06-02 16:02:08 --> Router Class Initialized
INFO - 2025-06-02 16:02:08 --> Output Class Initialized
INFO - 2025-06-02 16:02:08 --> Security Class Initialized
DEBUG - 2025-06-02 16:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 16:02:08 --> Input Class Initialized
INFO - 2025-06-02 16:02:08 --> Language Class Initialized
INFO - 2025-06-02 16:02:08 --> Loader Class Initialized
INFO - 2025-06-02 16:02:08 --> Helper loaded: url_helper
INFO - 2025-06-02 16:02:08 --> Helper loaded: form_helper
INFO - 2025-06-02 16:02:08 --> Database Driver Class Initialized
DEBUG - 2025-06-02 16:02:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 16:02:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 16:02:08 --> Controller Class Initialized
INFO - 2025-06-02 16:02:08 --> Model "User_model" initialized
INFO - 2025-06-02 16:02:08 --> Form Validation Class Initialized
DEBUG - 2025-06-02 16:02:08 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-06-02 16:02:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/register.php
INFO - 2025-06-02 16:02:08 --> Final output sent to browser
DEBUG - 2025-06-02 16:02:08 --> Total execution time: 0.0793
INFO - 2025-06-02 16:02:13 --> Config Class Initialized
INFO - 2025-06-02 16:02:13 --> Hooks Class Initialized
DEBUG - 2025-06-02 16:02:13 --> UTF-8 Support Enabled
INFO - 2025-06-02 16:02:13 --> Utf8 Class Initialized
INFO - 2025-06-02 16:02:13 --> URI Class Initialized
INFO - 2025-06-02 16:02:13 --> Router Class Initialized
INFO - 2025-06-02 16:02:13 --> Output Class Initialized
INFO - 2025-06-02 16:02:13 --> Security Class Initialized
DEBUG - 2025-06-02 16:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 16:02:13 --> Input Class Initialized
INFO - 2025-06-02 16:02:13 --> Language Class Initialized
INFO - 2025-06-02 16:02:13 --> Loader Class Initialized
INFO - 2025-06-02 16:02:13 --> Helper loaded: url_helper
INFO - 2025-06-02 16:02:13 --> Helper loaded: form_helper
INFO - 2025-06-02 16:02:13 --> Database Driver Class Initialized
DEBUG - 2025-06-02 16:02:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 16:02:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 16:02:13 --> Controller Class Initialized
INFO - 2025-06-02 16:02:13 --> Model "User_model" initialized
INFO - 2025-06-02 16:02:13 --> Form Validation Class Initialized
INFO - 2025-06-02 16:02:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-06-02 16:02:13 --> Final output sent to browser
DEBUG - 2025-06-02 16:02:13 --> Total execution time: 0.0661
INFO - 2025-06-02 16:03:37 --> Config Class Initialized
INFO - 2025-06-02 16:03:37 --> Hooks Class Initialized
DEBUG - 2025-06-02 16:03:37 --> UTF-8 Support Enabled
INFO - 2025-06-02 16:03:37 --> Utf8 Class Initialized
INFO - 2025-06-02 16:03:37 --> URI Class Initialized
INFO - 2025-06-02 16:03:37 --> Router Class Initialized
INFO - 2025-06-02 16:03:37 --> Output Class Initialized
INFO - 2025-06-02 16:03:37 --> Security Class Initialized
DEBUG - 2025-06-02 16:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 16:03:37 --> Input Class Initialized
INFO - 2025-06-02 16:03:37 --> Language Class Initialized
INFO - 2025-06-02 16:03:37 --> Loader Class Initialized
INFO - 2025-06-02 16:03:37 --> Helper loaded: url_helper
INFO - 2025-06-02 16:03:37 --> Helper loaded: form_helper
INFO - 2025-06-02 16:03:37 --> Database Driver Class Initialized
DEBUG - 2025-06-02 16:03:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 16:03:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 16:03:37 --> Controller Class Initialized
INFO - 2025-06-02 16:03:37 --> Model "User_model" initialized
INFO - 2025-06-02 16:03:37 --> Form Validation Class Initialized
INFO - 2025-06-02 16:03:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-06-02 16:03:37 --> Config Class Initialized
INFO - 2025-06-02 16:03:37 --> Hooks Class Initialized
DEBUG - 2025-06-02 16:03:37 --> UTF-8 Support Enabled
INFO - 2025-06-02 16:03:37 --> Utf8 Class Initialized
INFO - 2025-06-02 16:03:37 --> URI Class Initialized
INFO - 2025-06-02 16:03:37 --> Router Class Initialized
INFO - 2025-06-02 16:03:37 --> Output Class Initialized
INFO - 2025-06-02 16:03:37 --> Security Class Initialized
DEBUG - 2025-06-02 16:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 16:03:37 --> Input Class Initialized
INFO - 2025-06-02 16:03:37 --> Language Class Initialized
INFO - 2025-06-02 16:03:37 --> Loader Class Initialized
INFO - 2025-06-02 16:03:37 --> Helper loaded: url_helper
INFO - 2025-06-02 16:03:37 --> Helper loaded: form_helper
INFO - 2025-06-02 16:03:37 --> Database Driver Class Initialized
DEBUG - 2025-06-02 16:03:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 16:03:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 16:03:37 --> Controller Class Initialized
INFO - 2025-06-02 16:03:37 --> Model "User_model" initialized
INFO - 2025-06-02 16:03:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-06-02 16:03:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-06-02 16:03:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-06-02 16:03:37 --> Final output sent to browser
DEBUG - 2025-06-02 16:03:37 --> Total execution time: 0.0769
INFO - 2025-06-02 16:03:39 --> Config Class Initialized
INFO - 2025-06-02 16:03:39 --> Hooks Class Initialized
DEBUG - 2025-06-02 16:03:39 --> UTF-8 Support Enabled
INFO - 2025-06-02 16:03:39 --> Utf8 Class Initialized
INFO - 2025-06-02 16:03:39 --> URI Class Initialized
INFO - 2025-06-02 16:03:39 --> Router Class Initialized
INFO - 2025-06-02 16:03:39 --> Output Class Initialized
INFO - 2025-06-02 16:03:39 --> Security Class Initialized
DEBUG - 2025-06-02 16:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 16:03:39 --> Input Class Initialized
INFO - 2025-06-02 16:03:39 --> Language Class Initialized
INFO - 2025-06-02 16:03:39 --> Loader Class Initialized
INFO - 2025-06-02 16:03:39 --> Helper loaded: url_helper
INFO - 2025-06-02 16:03:39 --> Helper loaded: form_helper
INFO - 2025-06-02 16:03:40 --> Database Driver Class Initialized
DEBUG - 2025-06-02 16:03:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 16:03:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 16:03:40 --> Controller Class Initialized
INFO - 2025-06-02 16:03:40 --> Model "User_model" initialized
INFO - 2025-06-02 16:03:40 --> Model "Progress_model" initialized
INFO - 2025-06-02 16:03:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 16:03:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 16:03:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-06-02 16:03:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 16:03:40 --> Final output sent to browser
DEBUG - 2025-06-02 16:03:40 --> Total execution time: 0.1068
INFO - 2025-06-02 16:03:42 --> Config Class Initialized
INFO - 2025-06-02 16:03:42 --> Hooks Class Initialized
DEBUG - 2025-06-02 16:03:42 --> UTF-8 Support Enabled
INFO - 2025-06-02 16:03:42 --> Utf8 Class Initialized
INFO - 2025-06-02 16:03:42 --> URI Class Initialized
INFO - 2025-06-02 16:03:42 --> Router Class Initialized
INFO - 2025-06-02 16:03:42 --> Output Class Initialized
INFO - 2025-06-02 16:03:42 --> Security Class Initialized
DEBUG - 2025-06-02 16:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 16:03:42 --> Input Class Initialized
INFO - 2025-06-02 16:03:42 --> Language Class Initialized
INFO - 2025-06-02 16:03:42 --> Loader Class Initialized
INFO - 2025-06-02 16:03:42 --> Helper loaded: url_helper
INFO - 2025-06-02 16:03:42 --> Helper loaded: form_helper
INFO - 2025-06-02 16:03:42 --> Database Driver Class Initialized
DEBUG - 2025-06-02 16:03:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 16:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 16:03:42 --> Controller Class Initialized
INFO - 2025-06-02 16:03:42 --> Model "User_model" initialized
INFO - 2025-06-02 16:03:42 --> Model "Progress_model" initialized
INFO - 2025-06-02 16:03:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 16:03:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 16:03:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-06-02 16:03:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 16:03:42 --> Final output sent to browser
DEBUG - 2025-06-02 16:03:42 --> Total execution time: 0.0601
INFO - 2025-06-02 16:05:17 --> Config Class Initialized
INFO - 2025-06-02 16:05:17 --> Hooks Class Initialized
DEBUG - 2025-06-02 16:05:17 --> UTF-8 Support Enabled
INFO - 2025-06-02 16:05:17 --> Utf8 Class Initialized
INFO - 2025-06-02 16:05:17 --> URI Class Initialized
INFO - 2025-06-02 16:05:17 --> Router Class Initialized
INFO - 2025-06-02 16:05:17 --> Output Class Initialized
INFO - 2025-06-02 16:05:17 --> Security Class Initialized
DEBUG - 2025-06-02 16:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 16:05:17 --> Input Class Initialized
INFO - 2025-06-02 16:05:17 --> Language Class Initialized
INFO - 2025-06-02 16:05:17 --> Loader Class Initialized
INFO - 2025-06-02 16:05:17 --> Helper loaded: url_helper
INFO - 2025-06-02 16:05:17 --> Helper loaded: form_helper
INFO - 2025-06-02 16:05:17 --> Database Driver Class Initialized
DEBUG - 2025-06-02 16:05:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 16:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 16:05:17 --> Controller Class Initialized
INFO - 2025-06-02 16:05:17 --> Model "User_model" initialized
INFO - 2025-06-02 16:05:17 --> Model "Progress_model" initialized
INFO - 2025-06-02 16:05:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 16:05:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 16:05:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-06-02 16:05:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 16:05:17 --> Final output sent to browser
DEBUG - 2025-06-02 16:05:17 --> Total execution time: 0.0712
INFO - 2025-06-02 16:09:25 --> Config Class Initialized
INFO - 2025-06-02 16:09:25 --> Hooks Class Initialized
DEBUG - 2025-06-02 16:09:25 --> UTF-8 Support Enabled
INFO - 2025-06-02 16:09:25 --> Utf8 Class Initialized
INFO - 2025-06-02 16:09:25 --> URI Class Initialized
INFO - 2025-06-02 16:09:25 --> Router Class Initialized
INFO - 2025-06-02 16:09:25 --> Output Class Initialized
INFO - 2025-06-02 16:09:25 --> Security Class Initialized
DEBUG - 2025-06-02 16:09:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 16:09:25 --> Input Class Initialized
INFO - 2025-06-02 16:09:25 --> Language Class Initialized
INFO - 2025-06-02 16:09:25 --> Loader Class Initialized
INFO - 2025-06-02 16:09:25 --> Helper loaded: url_helper
INFO - 2025-06-02 16:09:25 --> Helper loaded: form_helper
INFO - 2025-06-02 16:09:25 --> Database Driver Class Initialized
DEBUG - 2025-06-02 16:09:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 16:09:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 16:09:25 --> Controller Class Initialized
INFO - 2025-06-02 16:09:25 --> Model "User_model" initialized
INFO - 2025-06-02 16:09:25 --> Model "Progress_model" initialized
INFO - 2025-06-02 16:09:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 16:09:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 16:09:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-06-02 16:09:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 16:09:25 --> Final output sent to browser
DEBUG - 2025-06-02 16:09:25 --> Total execution time: 0.0964
INFO - 2025-06-02 16:10:15 --> Config Class Initialized
INFO - 2025-06-02 16:10:15 --> Hooks Class Initialized
DEBUG - 2025-06-02 16:10:15 --> UTF-8 Support Enabled
INFO - 2025-06-02 16:10:15 --> Utf8 Class Initialized
INFO - 2025-06-02 16:10:15 --> URI Class Initialized
INFO - 2025-06-02 16:10:15 --> Router Class Initialized
INFO - 2025-06-02 16:10:15 --> Output Class Initialized
INFO - 2025-06-02 16:10:15 --> Security Class Initialized
DEBUG - 2025-06-02 16:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 16:10:15 --> Input Class Initialized
INFO - 2025-06-02 16:10:15 --> Language Class Initialized
INFO - 2025-06-02 16:10:15 --> Loader Class Initialized
INFO - 2025-06-02 16:10:15 --> Helper loaded: url_helper
INFO - 2025-06-02 16:10:15 --> Helper loaded: form_helper
INFO - 2025-06-02 16:10:15 --> Database Driver Class Initialized
DEBUG - 2025-06-02 16:10:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 16:10:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 16:10:15 --> Controller Class Initialized
INFO - 2025-06-02 16:10:15 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 16:10:15 --> Model "User_model" initialized
INFO - 2025-06-02 16:10:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 16:10:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 16:10:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-06-02 16:10:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 16:10:15 --> Final output sent to browser
DEBUG - 2025-06-02 16:10:15 --> Total execution time: 0.0960
INFO - 2025-06-02 16:12:38 --> Config Class Initialized
INFO - 2025-06-02 16:12:38 --> Hooks Class Initialized
DEBUG - 2025-06-02 16:12:38 --> UTF-8 Support Enabled
INFO - 2025-06-02 16:12:38 --> Utf8 Class Initialized
INFO - 2025-06-02 16:12:38 --> URI Class Initialized
INFO - 2025-06-02 16:12:38 --> Router Class Initialized
INFO - 2025-06-02 16:12:38 --> Output Class Initialized
INFO - 2025-06-02 16:12:38 --> Security Class Initialized
DEBUG - 2025-06-02 16:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 16:12:38 --> Input Class Initialized
INFO - 2025-06-02 16:12:38 --> Language Class Initialized
INFO - 2025-06-02 16:12:38 --> Loader Class Initialized
INFO - 2025-06-02 16:12:38 --> Helper loaded: url_helper
INFO - 2025-06-02 16:12:38 --> Helper loaded: form_helper
INFO - 2025-06-02 16:12:38 --> Database Driver Class Initialized
DEBUG - 2025-06-02 16:12:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 16:12:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 16:12:38 --> Controller Class Initialized
INFO - 2025-06-02 16:12:38 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 16:12:38 --> Model "User_model" initialized
INFO - 2025-06-02 16:12:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 16:12:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 16:12:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-06-02 16:12:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 16:12:38 --> Final output sent to browser
DEBUG - 2025-06-02 16:12:38 --> Total execution time: 0.0639
INFO - 2025-06-02 16:13:16 --> Config Class Initialized
INFO - 2025-06-02 16:13:16 --> Hooks Class Initialized
DEBUG - 2025-06-02 16:13:16 --> UTF-8 Support Enabled
INFO - 2025-06-02 16:13:16 --> Utf8 Class Initialized
INFO - 2025-06-02 16:13:16 --> URI Class Initialized
INFO - 2025-06-02 16:13:16 --> Router Class Initialized
INFO - 2025-06-02 16:13:16 --> Output Class Initialized
INFO - 2025-06-02 16:13:16 --> Security Class Initialized
DEBUG - 2025-06-02 16:13:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 16:13:16 --> Input Class Initialized
INFO - 2025-06-02 16:13:16 --> Language Class Initialized
INFO - 2025-06-02 16:13:16 --> Loader Class Initialized
INFO - 2025-06-02 16:13:16 --> Helper loaded: url_helper
INFO - 2025-06-02 16:13:16 --> Helper loaded: form_helper
INFO - 2025-06-02 16:13:16 --> Database Driver Class Initialized
DEBUG - 2025-06-02 16:13:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 16:13:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 16:13:16 --> Controller Class Initialized
INFO - 2025-06-02 16:13:16 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 16:13:16 --> Model "User_model" initialized
INFO - 2025-06-02 16:13:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 16:13:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 16:13:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-06-02 16:13:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 16:13:16 --> Final output sent to browser
DEBUG - 2025-06-02 16:13:16 --> Total execution time: 0.0858
INFO - 2025-06-02 16:13:18 --> Config Class Initialized
INFO - 2025-06-02 16:13:18 --> Hooks Class Initialized
DEBUG - 2025-06-02 16:13:18 --> UTF-8 Support Enabled
INFO - 2025-06-02 16:13:18 --> Utf8 Class Initialized
INFO - 2025-06-02 16:13:18 --> URI Class Initialized
INFO - 2025-06-02 16:13:18 --> Router Class Initialized
INFO - 2025-06-02 16:13:18 --> Output Class Initialized
INFO - 2025-06-02 16:13:18 --> Security Class Initialized
DEBUG - 2025-06-02 16:13:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 16:13:18 --> Input Class Initialized
INFO - 2025-06-02 16:13:18 --> Language Class Initialized
INFO - 2025-06-02 16:13:18 --> Loader Class Initialized
INFO - 2025-06-02 16:13:18 --> Helper loaded: url_helper
INFO - 2025-06-02 16:13:18 --> Helper loaded: form_helper
INFO - 2025-06-02 16:13:18 --> Database Driver Class Initialized
DEBUG - 2025-06-02 16:13:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 16:13:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 16:13:18 --> Controller Class Initialized
INFO - 2025-06-02 16:13:18 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 16:13:18 --> Model "User_model" initialized
INFO - 2025-06-02 16:13:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 16:13:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 16:13:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/menu.php
INFO - 2025-06-02 16:13:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 16:13:18 --> Final output sent to browser
DEBUG - 2025-06-02 16:13:18 --> Total execution time: 0.0990
INFO - 2025-06-02 16:13:24 --> Config Class Initialized
INFO - 2025-06-02 16:13:24 --> Hooks Class Initialized
DEBUG - 2025-06-02 16:13:24 --> UTF-8 Support Enabled
INFO - 2025-06-02 16:13:24 --> Utf8 Class Initialized
INFO - 2025-06-02 16:13:24 --> URI Class Initialized
INFO - 2025-06-02 16:13:24 --> Router Class Initialized
INFO - 2025-06-02 16:13:24 --> Output Class Initialized
INFO - 2025-06-02 16:13:24 --> Security Class Initialized
DEBUG - 2025-06-02 16:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 16:13:24 --> Input Class Initialized
INFO - 2025-06-02 16:13:24 --> Language Class Initialized
INFO - 2025-06-02 16:13:24 --> Loader Class Initialized
INFO - 2025-06-02 16:13:24 --> Helper loaded: url_helper
INFO - 2025-06-02 16:13:24 --> Helper loaded: form_helper
INFO - 2025-06-02 16:13:24 --> Database Driver Class Initialized
DEBUG - 2025-06-02 16:13:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 16:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 16:13:24 --> Controller Class Initialized
INFO - 2025-06-02 16:13:24 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 16:13:24 --> Model "User_model" initialized
INFO - 2025-06-02 16:13:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 16:13:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 16:13:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/menu.php
INFO - 2025-06-02 16:13:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 16:13:24 --> Final output sent to browser
DEBUG - 2025-06-02 16:13:24 --> Total execution time: 0.0838
INFO - 2025-06-02 16:13:52 --> Config Class Initialized
INFO - 2025-06-02 16:13:52 --> Hooks Class Initialized
DEBUG - 2025-06-02 16:13:52 --> UTF-8 Support Enabled
INFO - 2025-06-02 16:13:52 --> Utf8 Class Initialized
INFO - 2025-06-02 16:13:52 --> URI Class Initialized
INFO - 2025-06-02 16:13:52 --> Router Class Initialized
INFO - 2025-06-02 16:13:52 --> Output Class Initialized
INFO - 2025-06-02 16:13:52 --> Security Class Initialized
DEBUG - 2025-06-02 16:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 16:13:52 --> Input Class Initialized
INFO - 2025-06-02 16:13:52 --> Language Class Initialized
INFO - 2025-06-02 16:13:52 --> Loader Class Initialized
INFO - 2025-06-02 16:13:52 --> Helper loaded: url_helper
INFO - 2025-06-02 16:13:52 --> Helper loaded: form_helper
INFO - 2025-06-02 16:13:52 --> Database Driver Class Initialized
DEBUG - 2025-06-02 16:13:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 16:13:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 16:13:52 --> Controller Class Initialized
INFO - 2025-06-02 16:13:52 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 16:13:52 --> Model "User_model" initialized
INFO - 2025-06-02 16:13:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 16:13:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 16:13:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/menu.php
INFO - 2025-06-02 16:13:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 16:13:52 --> Final output sent to browser
DEBUG - 2025-06-02 16:13:52 --> Total execution time: 0.0740
INFO - 2025-06-02 16:14:42 --> Config Class Initialized
INFO - 2025-06-02 16:14:42 --> Hooks Class Initialized
DEBUG - 2025-06-02 16:14:42 --> UTF-8 Support Enabled
INFO - 2025-06-02 16:14:42 --> Utf8 Class Initialized
INFO - 2025-06-02 16:14:42 --> URI Class Initialized
INFO - 2025-06-02 16:14:42 --> Router Class Initialized
INFO - 2025-06-02 16:14:42 --> Output Class Initialized
INFO - 2025-06-02 16:14:42 --> Security Class Initialized
DEBUG - 2025-06-02 16:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 16:14:42 --> Input Class Initialized
INFO - 2025-06-02 16:14:42 --> Language Class Initialized
INFO - 2025-06-02 16:14:42 --> Loader Class Initialized
INFO - 2025-06-02 16:14:42 --> Helper loaded: url_helper
INFO - 2025-06-02 16:14:42 --> Helper loaded: form_helper
INFO - 2025-06-02 16:14:42 --> Database Driver Class Initialized
DEBUG - 2025-06-02 16:14:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 16:14:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 16:14:42 --> Controller Class Initialized
INFO - 2025-06-02 16:14:42 --> Model "User_model" initialized
INFO - 2025-06-02 16:14:42 --> Model "Community_model" initialized
INFO - 2025-06-02 16:14:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 16:14:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 16:14:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/community.php
INFO - 2025-06-02 16:14:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 16:14:42 --> Final output sent to browser
DEBUG - 2025-06-02 16:14:42 --> Total execution time: 0.1139
INFO - 2025-06-02 16:14:45 --> Config Class Initialized
INFO - 2025-06-02 16:14:45 --> Hooks Class Initialized
DEBUG - 2025-06-02 16:14:45 --> UTF-8 Support Enabled
INFO - 2025-06-02 16:14:45 --> Utf8 Class Initialized
INFO - 2025-06-02 16:14:45 --> URI Class Initialized
INFO - 2025-06-02 16:14:45 --> Router Class Initialized
INFO - 2025-06-02 16:14:45 --> Output Class Initialized
INFO - 2025-06-02 16:14:45 --> Security Class Initialized
DEBUG - 2025-06-02 16:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 16:14:45 --> Input Class Initialized
INFO - 2025-06-02 16:14:45 --> Language Class Initialized
INFO - 2025-06-02 16:14:45 --> Loader Class Initialized
INFO - 2025-06-02 16:14:45 --> Helper loaded: url_helper
INFO - 2025-06-02 16:14:45 --> Helper loaded: form_helper
INFO - 2025-06-02 16:14:45 --> Database Driver Class Initialized
DEBUG - 2025-06-02 16:14:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 16:14:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 16:14:45 --> Controller Class Initialized
INFO - 2025-06-02 16:14:45 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 16:14:45 --> Model "User_model" initialized
INFO - 2025-06-02 16:14:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 16:14:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 16:14:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-06-02 16:14:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 16:14:45 --> Final output sent to browser
DEBUG - 2025-06-02 16:14:45 --> Total execution time: 0.0671
INFO - 2025-06-02 16:14:47 --> Config Class Initialized
INFO - 2025-06-02 16:14:47 --> Hooks Class Initialized
DEBUG - 2025-06-02 16:14:47 --> UTF-8 Support Enabled
INFO - 2025-06-02 16:14:47 --> Utf8 Class Initialized
INFO - 2025-06-02 16:14:47 --> URI Class Initialized
INFO - 2025-06-02 16:14:47 --> Router Class Initialized
INFO - 2025-06-02 16:14:47 --> Output Class Initialized
INFO - 2025-06-02 16:14:47 --> Security Class Initialized
DEBUG - 2025-06-02 16:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 16:14:47 --> Input Class Initialized
INFO - 2025-06-02 16:14:47 --> Language Class Initialized
INFO - 2025-06-02 16:14:47 --> Loader Class Initialized
INFO - 2025-06-02 16:14:47 --> Helper loaded: url_helper
INFO - 2025-06-02 16:14:47 --> Helper loaded: form_helper
INFO - 2025-06-02 16:14:47 --> Database Driver Class Initialized
DEBUG - 2025-06-02 16:14:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 16:14:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 16:14:47 --> Controller Class Initialized
INFO - 2025-06-02 16:14:47 --> Model "Progress_model" initialized
INFO - 2025-06-02 16:14:47 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 16:14:47 --> Model "User_model" initialized
INFO - 2025-06-02 16:14:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 16:14:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 16:14:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-06-02 16:14:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 16:14:47 --> Final output sent to browser
DEBUG - 2025-06-02 16:14:47 --> Total execution time: 0.0935
INFO - 2025-06-02 16:14:47 --> Config Class Initialized
INFO - 2025-06-02 16:14:47 --> Hooks Class Initialized
DEBUG - 2025-06-02 16:14:47 --> UTF-8 Support Enabled
INFO - 2025-06-02 16:14:47 --> Utf8 Class Initialized
INFO - 2025-06-02 16:14:47 --> URI Class Initialized
INFO - 2025-06-02 16:14:47 --> Router Class Initialized
INFO - 2025-06-02 16:14:47 --> Output Class Initialized
INFO - 2025-06-02 16:14:47 --> Security Class Initialized
DEBUG - 2025-06-02 16:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 16:14:47 --> Input Class Initialized
INFO - 2025-06-02 16:14:47 --> Language Class Initialized
INFO - 2025-06-02 16:14:47 --> Loader Class Initialized
INFO - 2025-06-02 16:14:47 --> Helper loaded: url_helper
INFO - 2025-06-02 16:14:47 --> Helper loaded: form_helper
INFO - 2025-06-02 16:14:47 --> Database Driver Class Initialized
DEBUG - 2025-06-02 16:14:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 16:14:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 16:14:47 --> Controller Class Initialized
INFO - 2025-06-02 16:14:47 --> Model "Progress_model" initialized
INFO - 2025-06-02 16:14:47 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 16:14:47 --> Model "User_model" initialized
INFO - 2025-06-02 16:14:47 --> Final output sent to browser
DEBUG - 2025-06-02 16:14:47 --> Total execution time: 0.0812
INFO - 2025-06-02 16:14:56 --> Config Class Initialized
INFO - 2025-06-02 16:14:56 --> Hooks Class Initialized
DEBUG - 2025-06-02 16:14:56 --> UTF-8 Support Enabled
INFO - 2025-06-02 16:14:56 --> Utf8 Class Initialized
INFO - 2025-06-02 16:14:56 --> URI Class Initialized
INFO - 2025-06-02 16:14:56 --> Router Class Initialized
INFO - 2025-06-02 16:14:56 --> Output Class Initialized
INFO - 2025-06-02 16:14:56 --> Security Class Initialized
DEBUG - 2025-06-02 16:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 16:14:56 --> Input Class Initialized
INFO - 2025-06-02 16:14:56 --> Language Class Initialized
INFO - 2025-06-02 16:14:56 --> Loader Class Initialized
INFO - 2025-06-02 16:14:56 --> Helper loaded: url_helper
INFO - 2025-06-02 16:14:56 --> Helper loaded: form_helper
INFO - 2025-06-02 16:14:56 --> Database Driver Class Initialized
DEBUG - 2025-06-02 16:14:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 16:14:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 16:14:56 --> Controller Class Initialized
INFO - 2025-06-02 16:14:56 --> Model "User_model" initialized
INFO - 2025-06-02 16:14:56 --> Model "Progress_model" initialized
INFO - 2025-06-02 16:14:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 16:14:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 16:14:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-06-02 16:14:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 16:14:56 --> Final output sent to browser
DEBUG - 2025-06-02 16:14:56 --> Total execution time: 0.0865
INFO - 2025-06-02 16:15:06 --> Config Class Initialized
INFO - 2025-06-02 16:15:06 --> Hooks Class Initialized
DEBUG - 2025-06-02 16:15:06 --> UTF-8 Support Enabled
INFO - 2025-06-02 16:15:06 --> Utf8 Class Initialized
INFO - 2025-06-02 16:15:06 --> URI Class Initialized
INFO - 2025-06-02 16:15:06 --> Router Class Initialized
INFO - 2025-06-02 16:15:06 --> Output Class Initialized
INFO - 2025-06-02 16:15:06 --> Security Class Initialized
DEBUG - 2025-06-02 16:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 16:15:06 --> Input Class Initialized
INFO - 2025-06-02 16:15:06 --> Language Class Initialized
INFO - 2025-06-02 16:15:06 --> Loader Class Initialized
INFO - 2025-06-02 16:15:06 --> Helper loaded: url_helper
INFO - 2025-06-02 16:15:06 --> Helper loaded: form_helper
INFO - 2025-06-02 16:15:06 --> Database Driver Class Initialized
DEBUG - 2025-06-02 16:15:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 16:15:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 16:15:06 --> Controller Class Initialized
INFO - 2025-06-02 16:15:06 --> Model "Progress_model" initialized
INFO - 2025-06-02 16:15:06 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 16:15:06 --> Model "User_model" initialized
INFO - 2025-06-02 16:15:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 16:15:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 16:15:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-06-02 16:15:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 16:15:06 --> Final output sent to browser
DEBUG - 2025-06-02 16:15:06 --> Total execution time: 0.0660
INFO - 2025-06-02 16:15:07 --> Config Class Initialized
INFO - 2025-06-02 16:15:07 --> Hooks Class Initialized
DEBUG - 2025-06-02 16:15:07 --> UTF-8 Support Enabled
INFO - 2025-06-02 16:15:07 --> Utf8 Class Initialized
INFO - 2025-06-02 16:15:07 --> URI Class Initialized
INFO - 2025-06-02 16:15:07 --> Router Class Initialized
INFO - 2025-06-02 16:15:07 --> Output Class Initialized
INFO - 2025-06-02 16:15:07 --> Security Class Initialized
DEBUG - 2025-06-02 16:15:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 16:15:07 --> Input Class Initialized
INFO - 2025-06-02 16:15:07 --> Language Class Initialized
INFO - 2025-06-02 16:15:07 --> Loader Class Initialized
INFO - 2025-06-02 16:15:07 --> Helper loaded: url_helper
INFO - 2025-06-02 16:15:07 --> Helper loaded: form_helper
INFO - 2025-06-02 16:15:07 --> Database Driver Class Initialized
DEBUG - 2025-06-02 16:15:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 16:15:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 16:15:07 --> Controller Class Initialized
INFO - 2025-06-02 16:15:07 --> Model "Progress_model" initialized
INFO - 2025-06-02 16:15:07 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 16:15:07 --> Model "User_model" initialized
INFO - 2025-06-02 16:15:07 --> Final output sent to browser
DEBUG - 2025-06-02 16:15:07 --> Total execution time: 0.0687
INFO - 2025-06-02 16:15:10 --> Config Class Initialized
INFO - 2025-06-02 16:15:10 --> Hooks Class Initialized
DEBUG - 2025-06-02 16:15:10 --> UTF-8 Support Enabled
INFO - 2025-06-02 16:15:10 --> Utf8 Class Initialized
INFO - 2025-06-02 16:15:10 --> URI Class Initialized
INFO - 2025-06-02 16:15:10 --> Router Class Initialized
INFO - 2025-06-02 16:15:10 --> Output Class Initialized
INFO - 2025-06-02 16:15:10 --> Security Class Initialized
DEBUG - 2025-06-02 16:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 16:15:10 --> Input Class Initialized
INFO - 2025-06-02 16:15:10 --> Language Class Initialized
INFO - 2025-06-02 16:15:10 --> Loader Class Initialized
INFO - 2025-06-02 16:15:10 --> Helper loaded: url_helper
INFO - 2025-06-02 16:15:10 --> Helper loaded: form_helper
INFO - 2025-06-02 16:15:10 --> Database Driver Class Initialized
DEBUG - 2025-06-02 16:15:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 16:15:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 16:15:10 --> Controller Class Initialized
INFO - 2025-06-02 16:15:10 --> Model "User_model" initialized
INFO - 2025-06-02 16:15:10 --> Model "Progress_model" initialized
INFO - 2025-06-02 16:15:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 16:15:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 16:15:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-06-02 16:15:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 16:15:10 --> Final output sent to browser
DEBUG - 2025-06-02 16:15:10 --> Total execution time: 0.0774
INFO - 2025-06-02 16:16:00 --> Config Class Initialized
INFO - 2025-06-02 16:16:00 --> Hooks Class Initialized
DEBUG - 2025-06-02 16:16:00 --> UTF-8 Support Enabled
INFO - 2025-06-02 16:16:00 --> Utf8 Class Initialized
INFO - 2025-06-02 16:16:00 --> URI Class Initialized
INFO - 2025-06-02 16:16:00 --> Router Class Initialized
INFO - 2025-06-02 16:16:00 --> Output Class Initialized
INFO - 2025-06-02 16:16:00 --> Security Class Initialized
DEBUG - 2025-06-02 16:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 16:16:00 --> Input Class Initialized
INFO - 2025-06-02 16:16:00 --> Language Class Initialized
INFO - 2025-06-02 16:16:00 --> Loader Class Initialized
INFO - 2025-06-02 16:16:00 --> Helper loaded: url_helper
INFO - 2025-06-02 16:16:00 --> Helper loaded: form_helper
INFO - 2025-06-02 16:16:00 --> Database Driver Class Initialized
DEBUG - 2025-06-02 16:16:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 16:16:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 16:16:00 --> Controller Class Initialized
INFO - 2025-06-02 16:16:00 --> Model "User_model" initialized
INFO - 2025-06-02 16:16:00 --> Model "Progress_model" initialized
INFO - 2025-06-02 16:16:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 16:16:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 16:16:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-06-02 16:16:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 16:16:00 --> Final output sent to browser
DEBUG - 2025-06-02 16:16:00 --> Total execution time: 0.0739
INFO - 2025-06-02 16:16:01 --> Config Class Initialized
INFO - 2025-06-02 16:16:01 --> Hooks Class Initialized
DEBUG - 2025-06-02 16:16:01 --> UTF-8 Support Enabled
INFO - 2025-06-02 16:16:01 --> Utf8 Class Initialized
INFO - 2025-06-02 16:16:01 --> URI Class Initialized
INFO - 2025-06-02 16:16:02 --> Router Class Initialized
INFO - 2025-06-02 16:16:02 --> Output Class Initialized
INFO - 2025-06-02 16:16:02 --> Security Class Initialized
DEBUG - 2025-06-02 16:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 16:16:02 --> Input Class Initialized
INFO - 2025-06-02 16:16:02 --> Language Class Initialized
INFO - 2025-06-02 16:16:02 --> Loader Class Initialized
INFO - 2025-06-02 16:16:02 --> Helper loaded: url_helper
INFO - 2025-06-02 16:16:02 --> Helper loaded: form_helper
INFO - 2025-06-02 16:16:02 --> Database Driver Class Initialized
DEBUG - 2025-06-02 16:16:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 16:16:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 16:16:02 --> Controller Class Initialized
INFO - 2025-06-02 16:16:02 --> Model "Progress_model" initialized
INFO - 2025-06-02 16:16:02 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 16:16:02 --> Model "User_model" initialized
INFO - 2025-06-02 16:16:02 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 16:16:02 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 16:16:02 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-06-02 16:16:02 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 16:16:02 --> Final output sent to browser
DEBUG - 2025-06-02 16:16:02 --> Total execution time: 0.0658
INFO - 2025-06-02 16:16:02 --> Config Class Initialized
INFO - 2025-06-02 16:16:02 --> Hooks Class Initialized
DEBUG - 2025-06-02 16:16:02 --> UTF-8 Support Enabled
INFO - 2025-06-02 16:16:02 --> Utf8 Class Initialized
INFO - 2025-06-02 16:16:02 --> URI Class Initialized
INFO - 2025-06-02 16:16:02 --> Router Class Initialized
INFO - 2025-06-02 16:16:02 --> Output Class Initialized
INFO - 2025-06-02 16:16:02 --> Security Class Initialized
DEBUG - 2025-06-02 16:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 16:16:02 --> Input Class Initialized
INFO - 2025-06-02 16:16:02 --> Language Class Initialized
INFO - 2025-06-02 16:16:02 --> Loader Class Initialized
INFO - 2025-06-02 16:16:02 --> Helper loaded: url_helper
INFO - 2025-06-02 16:16:02 --> Helper loaded: form_helper
INFO - 2025-06-02 16:16:02 --> Database Driver Class Initialized
DEBUG - 2025-06-02 16:16:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 16:16:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 16:16:02 --> Controller Class Initialized
INFO - 2025-06-02 16:16:02 --> Model "Progress_model" initialized
INFO - 2025-06-02 16:16:02 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 16:16:02 --> Model "User_model" initialized
INFO - 2025-06-02 16:16:02 --> Final output sent to browser
DEBUG - 2025-06-02 16:16:02 --> Total execution time: 0.1025
INFO - 2025-06-02 16:16:03 --> Config Class Initialized
INFO - 2025-06-02 16:16:03 --> Hooks Class Initialized
DEBUG - 2025-06-02 16:16:03 --> UTF-8 Support Enabled
INFO - 2025-06-02 16:16:03 --> Utf8 Class Initialized
INFO - 2025-06-02 16:16:03 --> URI Class Initialized
INFO - 2025-06-02 16:16:03 --> Router Class Initialized
INFO - 2025-06-02 16:16:03 --> Output Class Initialized
INFO - 2025-06-02 16:16:03 --> Security Class Initialized
DEBUG - 2025-06-02 16:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 16:16:03 --> Input Class Initialized
INFO - 2025-06-02 16:16:03 --> Language Class Initialized
INFO - 2025-06-02 16:16:03 --> Loader Class Initialized
INFO - 2025-06-02 16:16:03 --> Helper loaded: url_helper
INFO - 2025-06-02 16:16:03 --> Helper loaded: form_helper
INFO - 2025-06-02 16:16:03 --> Database Driver Class Initialized
DEBUG - 2025-06-02 16:16:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 16:16:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 16:16:03 --> Controller Class Initialized
INFO - 2025-06-02 16:16:03 --> Model "Olahraga_model" initialized
INFO - 2025-06-02 16:16:03 --> Model "User_model" initialized
INFO - 2025-06-02 16:16:03 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 16:16:03 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 16:16:03 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-06-02 16:16:03 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 16:16:03 --> Final output sent to browser
DEBUG - 2025-06-02 16:16:03 --> Total execution time: 0.0689
INFO - 2025-06-02 16:16:05 --> Config Class Initialized
INFO - 2025-06-02 16:16:05 --> Hooks Class Initialized
DEBUG - 2025-06-02 16:16:05 --> UTF-8 Support Enabled
INFO - 2025-06-02 16:16:05 --> Utf8 Class Initialized
INFO - 2025-06-02 16:16:05 --> URI Class Initialized
INFO - 2025-06-02 16:16:05 --> Router Class Initialized
INFO - 2025-06-02 16:16:05 --> Output Class Initialized
INFO - 2025-06-02 16:16:05 --> Security Class Initialized
DEBUG - 2025-06-02 16:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 16:16:05 --> Input Class Initialized
INFO - 2025-06-02 16:16:05 --> Language Class Initialized
INFO - 2025-06-02 16:16:05 --> Loader Class Initialized
INFO - 2025-06-02 16:16:05 --> Helper loaded: url_helper
INFO - 2025-06-02 16:16:05 --> Helper loaded: form_helper
INFO - 2025-06-02 16:16:05 --> Database Driver Class Initialized
DEBUG - 2025-06-02 16:16:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 16:16:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 16:16:05 --> Controller Class Initialized
INFO - 2025-06-02 16:16:05 --> Model "User_model" initialized
INFO - 2025-06-02 16:16:05 --> Model "Community_model" initialized
INFO - 2025-06-02 16:16:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 16:16:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 16:16:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/community.php
INFO - 2025-06-02 16:16:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 16:16:05 --> Final output sent to browser
DEBUG - 2025-06-02 16:16:05 --> Total execution time: 0.0808
INFO - 2025-06-02 16:16:07 --> Config Class Initialized
INFO - 2025-06-02 16:16:07 --> Hooks Class Initialized
DEBUG - 2025-06-02 16:16:07 --> UTF-8 Support Enabled
INFO - 2025-06-02 16:16:07 --> Utf8 Class Initialized
INFO - 2025-06-02 16:16:07 --> URI Class Initialized
INFO - 2025-06-02 16:16:07 --> Router Class Initialized
INFO - 2025-06-02 16:16:07 --> Output Class Initialized
INFO - 2025-06-02 16:16:07 --> Security Class Initialized
DEBUG - 2025-06-02 16:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 16:16:07 --> Input Class Initialized
INFO - 2025-06-02 16:16:07 --> Language Class Initialized
INFO - 2025-06-02 16:16:07 --> Loader Class Initialized
INFO - 2025-06-02 16:16:07 --> Helper loaded: url_helper
INFO - 2025-06-02 16:16:07 --> Helper loaded: form_helper
INFO - 2025-06-02 16:16:07 --> Database Driver Class Initialized
DEBUG - 2025-06-02 16:16:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 16:16:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 16:16:07 --> Controller Class Initialized
INFO - 2025-06-02 16:16:07 --> Model "User_model" initialized
INFO - 2025-06-02 16:16:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-06-02 16:16:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-06-02 16:16:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-06-02 16:16:07 --> Final output sent to browser
DEBUG - 2025-06-02 16:16:07 --> Total execution time: 0.0592
INFO - 2025-06-02 16:18:27 --> Config Class Initialized
INFO - 2025-06-02 16:18:27 --> Hooks Class Initialized
DEBUG - 2025-06-02 16:18:27 --> UTF-8 Support Enabled
INFO - 2025-06-02 16:18:27 --> Utf8 Class Initialized
INFO - 2025-06-02 16:18:27 --> URI Class Initialized
INFO - 2025-06-02 16:18:27 --> Router Class Initialized
INFO - 2025-06-02 16:18:27 --> Output Class Initialized
INFO - 2025-06-02 16:18:27 --> Security Class Initialized
DEBUG - 2025-06-02 16:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 16:18:27 --> Input Class Initialized
INFO - 2025-06-02 16:18:27 --> Language Class Initialized
INFO - 2025-06-02 16:18:27 --> Loader Class Initialized
INFO - 2025-06-02 16:18:27 --> Helper loaded: url_helper
INFO - 2025-06-02 16:18:27 --> Helper loaded: form_helper
INFO - 2025-06-02 16:18:27 --> Database Driver Class Initialized
DEBUG - 2025-06-02 16:18:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 16:18:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 16:18:27 --> Controller Class Initialized
INFO - 2025-06-02 16:18:27 --> Model "User_model" initialized
INFO - 2025-06-02 16:18:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-06-02 16:18:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-06-02 16:18:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-06-02 16:18:27 --> Final output sent to browser
DEBUG - 2025-06-02 16:18:27 --> Total execution time: 0.0670
INFO - 2025-06-02 16:18:48 --> Config Class Initialized
INFO - 2025-06-02 16:18:48 --> Hooks Class Initialized
DEBUG - 2025-06-02 16:18:48 --> UTF-8 Support Enabled
INFO - 2025-06-02 16:18:48 --> Utf8 Class Initialized
INFO - 2025-06-02 16:18:48 --> URI Class Initialized
INFO - 2025-06-02 16:18:48 --> Router Class Initialized
INFO - 2025-06-02 16:18:48 --> Output Class Initialized
INFO - 2025-06-02 16:18:48 --> Security Class Initialized
DEBUG - 2025-06-02 16:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 16:18:48 --> Input Class Initialized
INFO - 2025-06-02 16:18:48 --> Language Class Initialized
INFO - 2025-06-02 16:18:48 --> Loader Class Initialized
INFO - 2025-06-02 16:18:48 --> Helper loaded: url_helper
INFO - 2025-06-02 16:18:48 --> Helper loaded: form_helper
INFO - 2025-06-02 16:18:48 --> Database Driver Class Initialized
DEBUG - 2025-06-02 16:18:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 16:18:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 16:18:48 --> Controller Class Initialized
INFO - 2025-06-02 16:18:48 --> Model "User_model" initialized
INFO - 2025-06-02 16:18:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-06-02 16:18:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-06-02 16:18:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-06-02 16:18:48 --> Final output sent to browser
DEBUG - 2025-06-02 16:18:48 --> Total execution time: 0.0618
INFO - 2025-06-02 16:18:52 --> Config Class Initialized
INFO - 2025-06-02 16:18:52 --> Hooks Class Initialized
DEBUG - 2025-06-02 16:18:52 --> UTF-8 Support Enabled
INFO - 2025-06-02 16:18:52 --> Utf8 Class Initialized
INFO - 2025-06-02 16:18:52 --> URI Class Initialized
INFO - 2025-06-02 16:18:52 --> Router Class Initialized
INFO - 2025-06-02 16:18:52 --> Output Class Initialized
INFO - 2025-06-02 16:18:52 --> Security Class Initialized
DEBUG - 2025-06-02 16:18:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 16:18:52 --> Input Class Initialized
INFO - 2025-06-02 16:18:52 --> Language Class Initialized
INFO - 2025-06-02 16:18:52 --> Loader Class Initialized
INFO - 2025-06-02 16:18:52 --> Helper loaded: url_helper
INFO - 2025-06-02 16:18:52 --> Helper loaded: form_helper
INFO - 2025-06-02 16:18:52 --> Database Driver Class Initialized
DEBUG - 2025-06-02 16:18:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 16:18:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 16:18:52 --> Controller Class Initialized
INFO - 2025-06-02 16:18:52 --> Model "User_model" initialized
INFO - 2025-06-02 16:18:52 --> Model "Progress_model" initialized
INFO - 2025-06-02 16:18:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 16:18:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 16:18:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-06-02 16:18:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 16:18:52 --> Final output sent to browser
DEBUG - 2025-06-02 16:18:52 --> Total execution time: 0.0897
INFO - 2025-06-02 16:19:55 --> Config Class Initialized
INFO - 2025-06-02 16:19:55 --> Hooks Class Initialized
DEBUG - 2025-06-02 16:19:55 --> UTF-8 Support Enabled
INFO - 2025-06-02 16:19:55 --> Utf8 Class Initialized
INFO - 2025-06-02 16:19:55 --> URI Class Initialized
INFO - 2025-06-02 16:19:55 --> Router Class Initialized
INFO - 2025-06-02 16:19:55 --> Output Class Initialized
INFO - 2025-06-02 16:19:55 --> Security Class Initialized
DEBUG - 2025-06-02 16:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 16:19:55 --> Input Class Initialized
INFO - 2025-06-02 16:19:55 --> Language Class Initialized
INFO - 2025-06-02 16:19:55 --> Loader Class Initialized
INFO - 2025-06-02 16:19:55 --> Helper loaded: url_helper
INFO - 2025-06-02 16:19:55 --> Helper loaded: form_helper
INFO - 2025-06-02 16:19:55 --> Database Driver Class Initialized
DEBUG - 2025-06-02 16:19:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 16:19:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 16:19:55 --> Controller Class Initialized
INFO - 2025-06-02 16:19:55 --> Model "User_model" initialized
INFO - 2025-06-02 16:19:55 --> Model "Progress_model" initialized
INFO - 2025-06-02 16:19:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 16:19:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 16:19:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-06-02 16:19:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 16:19:55 --> Final output sent to browser
DEBUG - 2025-06-02 16:19:55 --> Total execution time: 0.1022
INFO - 2025-06-02 16:20:08 --> Config Class Initialized
INFO - 2025-06-02 16:20:08 --> Hooks Class Initialized
DEBUG - 2025-06-02 16:20:08 --> UTF-8 Support Enabled
INFO - 2025-06-02 16:20:08 --> Utf8 Class Initialized
INFO - 2025-06-02 16:20:08 --> URI Class Initialized
INFO - 2025-06-02 16:20:08 --> Router Class Initialized
INFO - 2025-06-02 16:20:08 --> Output Class Initialized
INFO - 2025-06-02 16:20:08 --> Security Class Initialized
DEBUG - 2025-06-02 16:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 16:20:08 --> Input Class Initialized
INFO - 2025-06-02 16:20:08 --> Language Class Initialized
INFO - 2025-06-02 16:20:08 --> Loader Class Initialized
INFO - 2025-06-02 16:20:08 --> Helper loaded: url_helper
INFO - 2025-06-02 16:20:08 --> Helper loaded: form_helper
INFO - 2025-06-02 16:20:08 --> Database Driver Class Initialized
DEBUG - 2025-06-02 16:20:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 16:20:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 16:20:08 --> Controller Class Initialized
INFO - 2025-06-02 16:20:08 --> Model "User_model" initialized
INFO - 2025-06-02 16:20:08 --> Model "Progress_model" initialized
INFO - 2025-06-02 16:20:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-06-02 16:20:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-02 16:20:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-06-02 16:20:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-06-02 16:20:08 --> Final output sent to browser
DEBUG - 2025-06-02 16:20:08 --> Total execution time: 0.0932
INFO - 2025-06-02 16:23:43 --> Config Class Initialized
INFO - 2025-06-02 16:23:43 --> Hooks Class Initialized
DEBUG - 2025-06-02 16:23:43 --> UTF-8 Support Enabled
INFO - 2025-06-02 16:23:43 --> Utf8 Class Initialized
INFO - 2025-06-02 16:23:43 --> URI Class Initialized
INFO - 2025-06-02 16:23:43 --> Router Class Initialized
INFO - 2025-06-02 16:23:43 --> Output Class Initialized
INFO - 2025-06-02 16:23:43 --> Security Class Initialized
DEBUG - 2025-06-02 16:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 16:23:43 --> Input Class Initialized
INFO - 2025-06-02 16:23:43 --> Language Class Initialized
INFO - 2025-06-02 16:23:43 --> Loader Class Initialized
INFO - 2025-06-02 16:23:43 --> Helper loaded: url_helper
INFO - 2025-06-02 16:23:43 --> Helper loaded: form_helper
INFO - 2025-06-02 16:23:43 --> Database Driver Class Initialized
DEBUG - 2025-06-02 16:23:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 16:23:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 16:23:43 --> Controller Class Initialized
INFO - 2025-06-02 16:23:43 --> Model "User_model" initialized
INFO - 2025-06-02 16:23:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-06-02 16:23:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-06-02 16:23:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-06-02 16:23:43 --> Final output sent to browser
DEBUG - 2025-06-02 16:23:43 --> Total execution time: 0.0749
INFO - 2025-06-02 16:23:45 --> Config Class Initialized
INFO - 2025-06-02 16:23:45 --> Hooks Class Initialized
DEBUG - 2025-06-02 16:23:45 --> UTF-8 Support Enabled
INFO - 2025-06-02 16:23:45 --> Utf8 Class Initialized
INFO - 2025-06-02 16:23:45 --> URI Class Initialized
INFO - 2025-06-02 16:23:45 --> Router Class Initialized
INFO - 2025-06-02 16:23:45 --> Output Class Initialized
INFO - 2025-06-02 16:23:45 --> Security Class Initialized
DEBUG - 2025-06-02 16:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 16:23:45 --> Input Class Initialized
INFO - 2025-06-02 16:23:45 --> Language Class Initialized
INFO - 2025-06-02 16:23:45 --> Loader Class Initialized
INFO - 2025-06-02 16:23:45 --> Helper loaded: url_helper
INFO - 2025-06-02 16:23:45 --> Helper loaded: form_helper
INFO - 2025-06-02 16:23:45 --> Database Driver Class Initialized
DEBUG - 2025-06-02 16:23:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 16:23:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 16:23:45 --> Controller Class Initialized
INFO - 2025-06-02 16:23:45 --> Model "User_model" initialized
INFO - 2025-06-02 16:23:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-06-02 16:23:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-06-02 16:23:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-06-02 16:23:45 --> Final output sent to browser
DEBUG - 2025-06-02 16:23:45 --> Total execution time: 0.0643
INFO - 2025-06-02 16:24:29 --> Config Class Initialized
INFO - 2025-06-02 16:24:29 --> Hooks Class Initialized
DEBUG - 2025-06-02 16:24:29 --> UTF-8 Support Enabled
INFO - 2025-06-02 16:24:29 --> Utf8 Class Initialized
INFO - 2025-06-02 16:24:29 --> URI Class Initialized
INFO - 2025-06-02 16:24:29 --> Router Class Initialized
INFO - 2025-06-02 16:24:29 --> Output Class Initialized
INFO - 2025-06-02 16:24:29 --> Security Class Initialized
DEBUG - 2025-06-02 16:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 16:24:29 --> Input Class Initialized
INFO - 2025-06-02 16:24:29 --> Language Class Initialized
INFO - 2025-06-02 16:24:29 --> Loader Class Initialized
INFO - 2025-06-02 16:24:29 --> Helper loaded: url_helper
INFO - 2025-06-02 16:24:29 --> Helper loaded: form_helper
INFO - 2025-06-02 16:24:29 --> Database Driver Class Initialized
DEBUG - 2025-06-02 16:24:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 16:24:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 16:24:29 --> Controller Class Initialized
INFO - 2025-06-02 16:24:29 --> Model "User_model" initialized
INFO - 2025-06-02 16:24:29 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-06-02 16:24:29 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-06-02 16:24:29 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-06-02 16:24:29 --> Final output sent to browser
DEBUG - 2025-06-02 16:24:29 --> Total execution time: 0.0773
INFO - 2025-06-02 16:25:20 --> Config Class Initialized
INFO - 2025-06-02 16:25:20 --> Hooks Class Initialized
DEBUG - 2025-06-02 16:25:20 --> UTF-8 Support Enabled
INFO - 2025-06-02 16:25:20 --> Utf8 Class Initialized
INFO - 2025-06-02 16:25:20 --> URI Class Initialized
INFO - 2025-06-02 16:25:20 --> Router Class Initialized
INFO - 2025-06-02 16:25:20 --> Output Class Initialized
INFO - 2025-06-02 16:25:20 --> Security Class Initialized
DEBUG - 2025-06-02 16:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 16:25:20 --> Input Class Initialized
INFO - 2025-06-02 16:25:20 --> Language Class Initialized
INFO - 2025-06-02 16:25:20 --> Loader Class Initialized
INFO - 2025-06-02 16:25:20 --> Helper loaded: url_helper
INFO - 2025-06-02 16:25:20 --> Helper loaded: form_helper
INFO - 2025-06-02 16:25:20 --> Database Driver Class Initialized
DEBUG - 2025-06-02 16:25:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 16:25:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 16:25:20 --> Controller Class Initialized
INFO - 2025-06-02 16:25:20 --> Model "User_model" initialized
INFO - 2025-06-02 16:25:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-06-02 16:25:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-06-02 16:25:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-06-02 16:25:20 --> Final output sent to browser
DEBUG - 2025-06-02 16:25:20 --> Total execution time: 0.0598
INFO - 2025-06-02 16:25:49 --> Config Class Initialized
INFO - 2025-06-02 16:25:49 --> Hooks Class Initialized
DEBUG - 2025-06-02 16:25:49 --> UTF-8 Support Enabled
INFO - 2025-06-02 16:25:49 --> Utf8 Class Initialized
INFO - 2025-06-02 16:25:49 --> URI Class Initialized
INFO - 2025-06-02 16:25:49 --> Router Class Initialized
INFO - 2025-06-02 16:25:49 --> Output Class Initialized
INFO - 2025-06-02 16:25:49 --> Security Class Initialized
DEBUG - 2025-06-02 16:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 16:25:49 --> Input Class Initialized
INFO - 2025-06-02 16:25:49 --> Language Class Initialized
INFO - 2025-06-02 16:25:49 --> Loader Class Initialized
INFO - 2025-06-02 16:25:49 --> Helper loaded: url_helper
INFO - 2025-06-02 16:25:49 --> Helper loaded: form_helper
INFO - 2025-06-02 16:25:49 --> Database Driver Class Initialized
DEBUG - 2025-06-02 16:25:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 16:25:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 16:25:49 --> Controller Class Initialized
INFO - 2025-06-02 16:25:49 --> Model "User_model" initialized
INFO - 2025-06-02 16:25:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-06-02 16:25:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-06-02 16:25:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-06-02 16:25:49 --> Final output sent to browser
DEBUG - 2025-06-02 16:25:49 --> Total execution time: 0.0802
INFO - 2025-06-02 16:26:21 --> Config Class Initialized
INFO - 2025-06-02 16:26:21 --> Hooks Class Initialized
DEBUG - 2025-06-02 16:26:21 --> UTF-8 Support Enabled
INFO - 2025-06-02 16:26:21 --> Utf8 Class Initialized
INFO - 2025-06-02 16:26:21 --> URI Class Initialized
INFO - 2025-06-02 16:26:21 --> Router Class Initialized
INFO - 2025-06-02 16:26:21 --> Output Class Initialized
INFO - 2025-06-02 16:26:21 --> Security Class Initialized
DEBUG - 2025-06-02 16:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-02 16:26:21 --> Input Class Initialized
INFO - 2025-06-02 16:26:21 --> Language Class Initialized
INFO - 2025-06-02 16:26:21 --> Loader Class Initialized
INFO - 2025-06-02 16:26:21 --> Helper loaded: url_helper
INFO - 2025-06-02 16:26:21 --> Helper loaded: form_helper
INFO - 2025-06-02 16:26:21 --> Database Driver Class Initialized
DEBUG - 2025-06-02 16:26:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-02 16:26:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-02 16:26:21 --> Controller Class Initialized
INFO - 2025-06-02 16:26:21 --> Model "User_model" initialized
INFO - 2025-06-02 16:26:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-06-02 16:26:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-06-02 16:26:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-06-02 16:26:21 --> Final output sent to browser
DEBUG - 2025-06-02 16:26:21 --> Total execution time: 0.0616
