<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-06-11 01:32:37 --> Config Class Initialized
INFO - 2025-06-11 01:32:37 --> Hooks Class Initialized
DEBUG - 2025-06-11 01:32:37 --> UTF-8 Support Enabled
INFO - 2025-06-11 01:32:37 --> Utf8 Class Initialized
INFO - 2025-06-11 01:32:37 --> URI Class Initialized
DEBUG - 2025-06-11 01:32:37 --> No URI present. Default controller set.
INFO - 2025-06-11 01:32:37 --> Router Class Initialized
INFO - 2025-06-11 01:32:38 --> Output Class Initialized
INFO - 2025-06-11 01:32:38 --> Security Class Initialized
DEBUG - 2025-06-11 01:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-11 01:32:38 --> Input Class Initialized
INFO - 2025-06-11 01:32:38 --> Language Class Initialized
INFO - 2025-06-11 01:32:38 --> Loader Class Initialized
INFO - 2025-06-11 01:32:38 --> Helper loaded: url_helper
INFO - 2025-06-11 01:32:38 --> Helper loaded: form_helper
INFO - 2025-06-11 01:32:38 --> Database Driver Class Initialized
DEBUG - 2025-06-11 01:32:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-11 01:32:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-11 01:32:39 --> Controller Class Initialized
INFO - 2025-06-11 01:32:39 --> Model "User_model" initialized
INFO - 2025-06-11 01:32:39 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-06-11 01:32:39 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/home.php
INFO - 2025-06-11 01:32:39 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-06-11 01:32:39 --> Final output sent to browser
DEBUG - 2025-06-11 01:32:39 --> Total execution time: 2.3742
INFO - 2025-06-11 01:32:42 --> Config Class Initialized
INFO - 2025-06-11 01:32:42 --> Hooks Class Initialized
DEBUG - 2025-06-11 01:32:42 --> UTF-8 Support Enabled
INFO - 2025-06-11 01:32:42 --> Utf8 Class Initialized
INFO - 2025-06-11 01:32:42 --> URI Class Initialized
INFO - 2025-06-11 01:32:42 --> Router Class Initialized
INFO - 2025-06-11 01:32:42 --> Output Class Initialized
INFO - 2025-06-11 01:32:42 --> Security Class Initialized
DEBUG - 2025-06-11 01:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-11 01:32:42 --> Input Class Initialized
INFO - 2025-06-11 01:32:42 --> Language Class Initialized
INFO - 2025-06-11 01:32:42 --> Loader Class Initialized
INFO - 2025-06-11 01:32:42 --> Helper loaded: url_helper
INFO - 2025-06-11 01:32:42 --> Helper loaded: form_helper
INFO - 2025-06-11 01:32:42 --> Database Driver Class Initialized
DEBUG - 2025-06-11 01:32:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-11 01:32:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-11 01:32:42 --> Controller Class Initialized
INFO - 2025-06-11 01:32:42 --> Model "User_model" initialized
INFO - 2025-06-11 01:32:42 --> Form Validation Class Initialized
INFO - 2025-06-11 01:32:42 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\auth/login.php
INFO - 2025-06-11 01:32:42 --> Final output sent to browser
DEBUG - 2025-06-11 01:32:42 --> Total execution time: 0.3908
INFO - 2025-06-11 01:33:33 --> Config Class Initialized
INFO - 2025-06-11 01:33:33 --> Hooks Class Initialized
DEBUG - 2025-06-11 01:33:33 --> UTF-8 Support Enabled
INFO - 2025-06-11 01:33:33 --> Utf8 Class Initialized
INFO - 2025-06-11 01:33:33 --> URI Class Initialized
INFO - 2025-06-11 01:33:33 --> Router Class Initialized
INFO - 2025-06-11 01:33:33 --> Output Class Initialized
INFO - 2025-06-11 01:33:33 --> Security Class Initialized
DEBUG - 2025-06-11 01:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-11 01:33:33 --> Input Class Initialized
INFO - 2025-06-11 01:33:33 --> Language Class Initialized
INFO - 2025-06-11 01:33:33 --> Loader Class Initialized
INFO - 2025-06-11 01:33:33 --> Helper loaded: url_helper
INFO - 2025-06-11 01:33:33 --> Helper loaded: form_helper
INFO - 2025-06-11 01:33:33 --> Database Driver Class Initialized
DEBUG - 2025-06-11 01:33:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-11 01:33:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-11 01:33:33 --> Controller Class Initialized
INFO - 2025-06-11 01:33:33 --> Model "User_model" initialized
INFO - 2025-06-11 01:33:33 --> Form Validation Class Initialized
INFO - 2025-06-11 01:33:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-06-11 01:33:33 --> Config Class Initialized
INFO - 2025-06-11 01:33:33 --> Hooks Class Initialized
DEBUG - 2025-06-11 01:33:33 --> UTF-8 Support Enabled
INFO - 2025-06-11 01:33:33 --> Utf8 Class Initialized
INFO - 2025-06-11 01:33:33 --> URI Class Initialized
INFO - 2025-06-11 01:33:33 --> Router Class Initialized
INFO - 2025-06-11 01:33:33 --> Output Class Initialized
INFO - 2025-06-11 01:33:33 --> Security Class Initialized
DEBUG - 2025-06-11 01:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-11 01:33:33 --> Input Class Initialized
INFO - 2025-06-11 01:33:33 --> Language Class Initialized
INFO - 2025-06-11 01:33:33 --> Loader Class Initialized
INFO - 2025-06-11 01:33:33 --> Helper loaded: url_helper
INFO - 2025-06-11 01:33:33 --> Helper loaded: form_helper
INFO - 2025-06-11 01:33:33 --> Database Driver Class Initialized
DEBUG - 2025-06-11 01:33:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-11 01:33:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-11 01:33:33 --> Controller Class Initialized
INFO - 2025-06-11 01:33:33 --> Model "User_model" initialized
INFO - 2025-06-11 01:33:33 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-06-11 01:33:33 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/home.php
INFO - 2025-06-11 01:33:33 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-06-11 01:33:33 --> Final output sent to browser
DEBUG - 2025-06-11 01:33:33 --> Total execution time: 0.0827
INFO - 2025-06-11 01:33:38 --> Config Class Initialized
INFO - 2025-06-11 01:33:38 --> Hooks Class Initialized
DEBUG - 2025-06-11 01:33:38 --> UTF-8 Support Enabled
INFO - 2025-06-11 01:33:38 --> Utf8 Class Initialized
INFO - 2025-06-11 01:33:38 --> URI Class Initialized
INFO - 2025-06-11 01:33:38 --> Router Class Initialized
INFO - 2025-06-11 01:33:38 --> Output Class Initialized
INFO - 2025-06-11 01:33:38 --> Security Class Initialized
DEBUG - 2025-06-11 01:33:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-11 01:33:38 --> Input Class Initialized
INFO - 2025-06-11 01:33:38 --> Language Class Initialized
INFO - 2025-06-11 01:33:38 --> Loader Class Initialized
INFO - 2025-06-11 01:33:38 --> Helper loaded: url_helper
INFO - 2025-06-11 01:33:38 --> Helper loaded: form_helper
INFO - 2025-06-11 01:33:38 --> Database Driver Class Initialized
DEBUG - 2025-06-11 01:33:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-11 01:33:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-11 01:33:38 --> Controller Class Initialized
INFO - 2025-06-11 01:33:38 --> Model "User_model" initialized
INFO - 2025-06-11 01:33:38 --> Model "Progress_model" initialized
INFO - 2025-06-11 01:33:38 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-11 01:33:38 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-11 01:33:38 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/dashboard.php
INFO - 2025-06-11 01:33:38 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-11 01:33:38 --> Final output sent to browser
DEBUG - 2025-06-11 01:33:38 --> Total execution time: 0.4772
INFO - 2025-06-11 03:50:02 --> Config Class Initialized
INFO - 2025-06-11 03:50:02 --> Hooks Class Initialized
DEBUG - 2025-06-11 03:50:02 --> UTF-8 Support Enabled
INFO - 2025-06-11 03:50:02 --> Utf8 Class Initialized
INFO - 2025-06-11 03:50:02 --> URI Class Initialized
INFO - 2025-06-11 03:50:02 --> Router Class Initialized
INFO - 2025-06-11 03:50:02 --> Output Class Initialized
INFO - 2025-06-11 03:50:02 --> Security Class Initialized
DEBUG - 2025-06-11 03:50:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-11 03:50:02 --> Input Class Initialized
INFO - 2025-06-11 03:50:02 --> Language Class Initialized
INFO - 2025-06-11 03:50:02 --> Loader Class Initialized
INFO - 2025-06-11 03:50:02 --> Helper loaded: url_helper
INFO - 2025-06-11 03:50:02 --> Helper loaded: form_helper
INFO - 2025-06-11 03:50:02 --> Database Driver Class Initialized
DEBUG - 2025-06-11 03:50:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-11 03:50:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-11 03:50:03 --> Controller Class Initialized
INFO - 2025-06-11 03:50:03 --> Config Class Initialized
INFO - 2025-06-11 03:50:03 --> Hooks Class Initialized
DEBUG - 2025-06-11 03:50:03 --> UTF-8 Support Enabled
INFO - 2025-06-11 03:50:03 --> Utf8 Class Initialized
INFO - 2025-06-11 03:50:03 --> URI Class Initialized
INFO - 2025-06-11 03:50:03 --> Router Class Initialized
INFO - 2025-06-11 03:50:03 --> Output Class Initialized
INFO - 2025-06-11 03:50:03 --> Security Class Initialized
DEBUG - 2025-06-11 03:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-11 03:50:03 --> Input Class Initialized
INFO - 2025-06-11 03:50:03 --> Language Class Initialized
INFO - 2025-06-11 03:50:03 --> Loader Class Initialized
INFO - 2025-06-11 03:50:03 --> Helper loaded: url_helper
INFO - 2025-06-11 03:50:03 --> Helper loaded: form_helper
INFO - 2025-06-11 03:50:03 --> Database Driver Class Initialized
DEBUG - 2025-06-11 03:50:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-11 03:50:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-11 03:50:03 --> Controller Class Initialized
INFO - 2025-06-11 03:50:03 --> Model "User_model" initialized
INFO - 2025-06-11 03:50:03 --> Form Validation Class Initialized
INFO - 2025-06-11 03:50:03 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\auth/login.php
INFO - 2025-06-11 03:50:03 --> Final output sent to browser
DEBUG - 2025-06-11 03:50:03 --> Total execution time: 0.1449
INFO - 2025-06-11 03:50:10 --> Config Class Initialized
INFO - 2025-06-11 03:50:10 --> Hooks Class Initialized
DEBUG - 2025-06-11 03:50:10 --> UTF-8 Support Enabled
INFO - 2025-06-11 03:50:10 --> Utf8 Class Initialized
INFO - 2025-06-11 03:50:10 --> URI Class Initialized
INFO - 2025-06-11 03:50:10 --> Router Class Initialized
INFO - 2025-06-11 03:50:10 --> Output Class Initialized
INFO - 2025-06-11 03:50:10 --> Security Class Initialized
DEBUG - 2025-06-11 03:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-11 03:50:10 --> Input Class Initialized
INFO - 2025-06-11 03:50:10 --> Language Class Initialized
INFO - 2025-06-11 03:50:10 --> Loader Class Initialized
INFO - 2025-06-11 03:50:10 --> Helper loaded: url_helper
INFO - 2025-06-11 03:50:10 --> Helper loaded: form_helper
INFO - 2025-06-11 03:50:10 --> Database Driver Class Initialized
DEBUG - 2025-06-11 03:50:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-11 03:50:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-11 03:50:10 --> Controller Class Initialized
INFO - 2025-06-11 03:50:10 --> Model "User_model" initialized
INFO - 2025-06-11 03:50:10 --> Form Validation Class Initialized
INFO - 2025-06-11 03:50:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-06-11 03:50:10 --> Config Class Initialized
INFO - 2025-06-11 03:50:10 --> Hooks Class Initialized
DEBUG - 2025-06-11 03:50:10 --> UTF-8 Support Enabled
INFO - 2025-06-11 03:50:10 --> Utf8 Class Initialized
INFO - 2025-06-11 03:50:10 --> URI Class Initialized
INFO - 2025-06-11 03:50:10 --> Router Class Initialized
INFO - 2025-06-11 03:50:10 --> Output Class Initialized
INFO - 2025-06-11 03:50:10 --> Security Class Initialized
DEBUG - 2025-06-11 03:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-11 03:50:10 --> Input Class Initialized
INFO - 2025-06-11 03:50:10 --> Language Class Initialized
INFO - 2025-06-11 03:50:10 --> Loader Class Initialized
INFO - 2025-06-11 03:50:10 --> Helper loaded: url_helper
INFO - 2025-06-11 03:50:10 --> Helper loaded: form_helper
INFO - 2025-06-11 03:50:10 --> Database Driver Class Initialized
DEBUG - 2025-06-11 03:50:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-11 03:50:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-11 03:50:10 --> Controller Class Initialized
INFO - 2025-06-11 03:50:10 --> Model "User_model" initialized
INFO - 2025-06-11 03:50:10 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-06-11 03:50:10 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/home.php
INFO - 2025-06-11 03:50:10 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-06-11 03:50:10 --> Final output sent to browser
DEBUG - 2025-06-11 03:50:10 --> Total execution time: 0.2222
INFO - 2025-06-11 03:50:13 --> Config Class Initialized
INFO - 2025-06-11 03:50:13 --> Hooks Class Initialized
DEBUG - 2025-06-11 03:50:13 --> UTF-8 Support Enabled
INFO - 2025-06-11 03:50:13 --> Utf8 Class Initialized
INFO - 2025-06-11 03:50:13 --> URI Class Initialized
INFO - 2025-06-11 03:50:13 --> Router Class Initialized
INFO - 2025-06-11 03:50:13 --> Output Class Initialized
INFO - 2025-06-11 03:50:13 --> Security Class Initialized
DEBUG - 2025-06-11 03:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-11 03:50:13 --> Input Class Initialized
INFO - 2025-06-11 03:50:13 --> Language Class Initialized
INFO - 2025-06-11 03:50:13 --> Loader Class Initialized
INFO - 2025-06-11 03:50:13 --> Helper loaded: url_helper
INFO - 2025-06-11 03:50:13 --> Helper loaded: form_helper
INFO - 2025-06-11 03:50:13 --> Database Driver Class Initialized
DEBUG - 2025-06-11 03:50:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-11 03:50:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-11 03:50:13 --> Controller Class Initialized
INFO - 2025-06-11 03:50:13 --> Model "User_model" initialized
INFO - 2025-06-11 03:50:13 --> Model "Progress_model" initialized
INFO - 2025-06-11 03:50:13 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-11 03:50:13 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-11 03:50:14 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/dashboard.php
INFO - 2025-06-11 03:50:14 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-11 03:50:14 --> Final output sent to browser
DEBUG - 2025-06-11 03:50:14 --> Total execution time: 0.2893
INFO - 2025-06-11 03:50:16 --> Config Class Initialized
INFO - 2025-06-11 03:50:16 --> Hooks Class Initialized
DEBUG - 2025-06-11 03:50:16 --> UTF-8 Support Enabled
INFO - 2025-06-11 03:50:16 --> Utf8 Class Initialized
INFO - 2025-06-11 03:50:16 --> URI Class Initialized
INFO - 2025-06-11 03:50:16 --> Router Class Initialized
INFO - 2025-06-11 03:50:16 --> Output Class Initialized
INFO - 2025-06-11 03:50:16 --> Security Class Initialized
DEBUG - 2025-06-11 03:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-11 03:50:16 --> Input Class Initialized
INFO - 2025-06-11 03:50:16 --> Language Class Initialized
INFO - 2025-06-11 03:50:16 --> Loader Class Initialized
INFO - 2025-06-11 03:50:16 --> Helper loaded: url_helper
INFO - 2025-06-11 03:50:16 --> Helper loaded: form_helper
INFO - 2025-06-11 03:50:16 --> Database Driver Class Initialized
DEBUG - 2025-06-11 03:50:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-11 03:50:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-11 03:50:16 --> Controller Class Initialized
INFO - 2025-06-11 03:50:16 --> Model "Olahraga_model" initialized
INFO - 2025-06-11 03:50:16 --> Model "User_model" initialized
INFO - 2025-06-11 03:50:16 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-11 03:50:16 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-11 03:50:16 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-06-11 03:50:16 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-11 03:50:16 --> Final output sent to browser
DEBUG - 2025-06-11 03:50:16 --> Total execution time: 0.2672
INFO - 2025-06-11 03:54:14 --> Config Class Initialized
INFO - 2025-06-11 03:54:14 --> Hooks Class Initialized
DEBUG - 2025-06-11 03:54:14 --> UTF-8 Support Enabled
INFO - 2025-06-11 03:54:14 --> Utf8 Class Initialized
INFO - 2025-06-11 03:54:14 --> URI Class Initialized
INFO - 2025-06-11 03:54:14 --> Router Class Initialized
INFO - 2025-06-11 03:54:14 --> Output Class Initialized
INFO - 2025-06-11 03:54:14 --> Security Class Initialized
DEBUG - 2025-06-11 03:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-11 03:54:14 --> Input Class Initialized
INFO - 2025-06-11 03:54:14 --> Language Class Initialized
INFO - 2025-06-11 03:54:14 --> Loader Class Initialized
INFO - 2025-06-11 03:54:14 --> Helper loaded: url_helper
INFO - 2025-06-11 03:54:14 --> Helper loaded: form_helper
INFO - 2025-06-11 03:54:14 --> Database Driver Class Initialized
DEBUG - 2025-06-11 03:54:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-11 03:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-11 03:54:14 --> Controller Class Initialized
INFO - 2025-06-11 03:54:14 --> Model "Olahraga_model" initialized
INFO - 2025-06-11 03:54:14 --> Model "User_model" initialized
INFO - 2025-06-11 03:54:14 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-11 03:54:14 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-11 03:54:14 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-06-11 03:54:14 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-11 03:54:14 --> Final output sent to browser
DEBUG - 2025-06-11 03:54:14 --> Total execution time: 0.0950
INFO - 2025-06-11 03:57:47 --> Config Class Initialized
INFO - 2025-06-11 03:57:47 --> Hooks Class Initialized
DEBUG - 2025-06-11 03:57:48 --> UTF-8 Support Enabled
INFO - 2025-06-11 03:57:48 --> Utf8 Class Initialized
INFO - 2025-06-11 03:57:48 --> URI Class Initialized
INFO - 2025-06-11 03:57:48 --> Router Class Initialized
INFO - 2025-06-11 03:57:48 --> Output Class Initialized
INFO - 2025-06-11 03:57:48 --> Security Class Initialized
DEBUG - 2025-06-11 03:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-11 03:57:48 --> Input Class Initialized
INFO - 2025-06-11 03:57:48 --> Language Class Initialized
INFO - 2025-06-11 03:57:48 --> Loader Class Initialized
INFO - 2025-06-11 03:57:48 --> Helper loaded: url_helper
INFO - 2025-06-11 03:57:48 --> Helper loaded: form_helper
INFO - 2025-06-11 03:57:49 --> Database Driver Class Initialized
DEBUG - 2025-06-11 03:57:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-11 03:57:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-11 03:57:49 --> Controller Class Initialized
INFO - 2025-06-11 03:57:49 --> Model "User_model" initialized
INFO - 2025-06-11 03:57:49 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-11 03:57:50 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-11 03:57:50 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/profile.php
INFO - 2025-06-11 03:57:50 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-11 03:57:50 --> Final output sent to browser
DEBUG - 2025-06-11 03:57:50 --> Total execution time: 2.4854
INFO - 2025-06-11 03:57:53 --> Config Class Initialized
INFO - 2025-06-11 03:57:53 --> Hooks Class Initialized
DEBUG - 2025-06-11 03:57:53 --> UTF-8 Support Enabled
INFO - 2025-06-11 03:57:53 --> Utf8 Class Initialized
INFO - 2025-06-11 03:57:53 --> URI Class Initialized
INFO - 2025-06-11 03:57:53 --> Router Class Initialized
INFO - 2025-06-11 03:57:53 --> Output Class Initialized
INFO - 2025-06-11 03:57:53 --> Security Class Initialized
DEBUG - 2025-06-11 03:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-11 03:57:53 --> Input Class Initialized
INFO - 2025-06-11 03:57:53 --> Language Class Initialized
INFO - 2025-06-11 03:57:53 --> Loader Class Initialized
INFO - 2025-06-11 03:57:53 --> Helper loaded: url_helper
INFO - 2025-06-11 03:57:53 --> Helper loaded: form_helper
INFO - 2025-06-11 03:57:53 --> Database Driver Class Initialized
DEBUG - 2025-06-11 03:57:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-11 03:57:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-11 03:57:53 --> Controller Class Initialized
INFO - 2025-06-11 03:57:53 --> Model "User_model" initialized
INFO - 2025-06-11 03:57:53 --> Form Validation Class Initialized
INFO - 2025-06-11 03:57:53 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-11 03:57:53 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-11 03:57:53 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/edit_profile.php
INFO - 2025-06-11 03:57:53 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-11 03:57:53 --> Final output sent to browser
DEBUG - 2025-06-11 03:57:53 --> Total execution time: 0.2416
INFO - 2025-06-11 03:58:02 --> Config Class Initialized
INFO - 2025-06-11 03:58:02 --> Hooks Class Initialized
DEBUG - 2025-06-11 03:58:02 --> UTF-8 Support Enabled
INFO - 2025-06-11 03:58:02 --> Utf8 Class Initialized
INFO - 2025-06-11 03:58:02 --> URI Class Initialized
INFO - 2025-06-11 03:58:02 --> Router Class Initialized
INFO - 2025-06-11 03:58:02 --> Output Class Initialized
INFO - 2025-06-11 03:58:02 --> Security Class Initialized
DEBUG - 2025-06-11 03:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-11 03:58:02 --> Input Class Initialized
INFO - 2025-06-11 03:58:02 --> Language Class Initialized
INFO - 2025-06-11 03:58:02 --> Loader Class Initialized
INFO - 2025-06-11 03:58:02 --> Helper loaded: url_helper
INFO - 2025-06-11 03:58:02 --> Helper loaded: form_helper
INFO - 2025-06-11 03:58:02 --> Database Driver Class Initialized
DEBUG - 2025-06-11 03:58:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-11 03:58:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-11 03:58:02 --> Controller Class Initialized
INFO - 2025-06-11 03:58:02 --> Model "User_model" initialized
INFO - 2025-06-11 03:58:02 --> Form Validation Class Initialized
INFO - 2025-06-11 03:58:02 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-06-11 03:58:02 --> Config Class Initialized
INFO - 2025-06-11 03:58:02 --> Hooks Class Initialized
DEBUG - 2025-06-11 03:58:02 --> UTF-8 Support Enabled
INFO - 2025-06-11 03:58:02 --> Utf8 Class Initialized
INFO - 2025-06-11 03:58:02 --> URI Class Initialized
INFO - 2025-06-11 03:58:02 --> Router Class Initialized
INFO - 2025-06-11 03:58:02 --> Output Class Initialized
INFO - 2025-06-11 03:58:02 --> Security Class Initialized
DEBUG - 2025-06-11 03:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-11 03:58:02 --> Input Class Initialized
INFO - 2025-06-11 03:58:02 --> Language Class Initialized
INFO - 2025-06-11 03:58:02 --> Loader Class Initialized
INFO - 2025-06-11 03:58:02 --> Helper loaded: url_helper
INFO - 2025-06-11 03:58:02 --> Helper loaded: form_helper
INFO - 2025-06-11 03:58:02 --> Database Driver Class Initialized
DEBUG - 2025-06-11 03:58:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-11 03:58:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-11 03:58:02 --> Controller Class Initialized
INFO - 2025-06-11 03:58:02 --> Model "User_model" initialized
INFO - 2025-06-11 03:58:02 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-11 03:58:02 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-11 03:58:02 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/profile.php
INFO - 2025-06-11 03:58:02 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-11 03:58:02 --> Final output sent to browser
DEBUG - 2025-06-11 03:58:02 --> Total execution time: 0.0761
INFO - 2025-06-11 03:58:35 --> Config Class Initialized
INFO - 2025-06-11 03:58:35 --> Hooks Class Initialized
DEBUG - 2025-06-11 03:58:35 --> UTF-8 Support Enabled
INFO - 2025-06-11 03:58:35 --> Utf8 Class Initialized
INFO - 2025-06-11 03:58:35 --> URI Class Initialized
INFO - 2025-06-11 03:58:35 --> Router Class Initialized
INFO - 2025-06-11 03:58:35 --> Output Class Initialized
INFO - 2025-06-11 03:58:35 --> Security Class Initialized
DEBUG - 2025-06-11 03:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-11 03:58:35 --> Input Class Initialized
INFO - 2025-06-11 03:58:35 --> Language Class Initialized
INFO - 2025-06-11 03:58:35 --> Loader Class Initialized
INFO - 2025-06-11 03:58:35 --> Helper loaded: url_helper
INFO - 2025-06-11 03:58:35 --> Helper loaded: form_helper
INFO - 2025-06-11 03:58:35 --> Database Driver Class Initialized
DEBUG - 2025-06-11 03:58:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-11 03:58:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-11 03:58:35 --> Controller Class Initialized
INFO - 2025-06-11 03:58:35 --> Model "User_model" initialized
INFO - 2025-06-11 03:58:35 --> Form Validation Class Initialized
INFO - 2025-06-11 03:58:35 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-11 03:58:35 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-11 03:58:35 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/edit_profile.php
INFO - 2025-06-11 03:58:35 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-11 03:58:35 --> Final output sent to browser
DEBUG - 2025-06-11 03:58:35 --> Total execution time: 0.1117
INFO - 2025-06-11 03:58:37 --> Config Class Initialized
INFO - 2025-06-11 03:58:37 --> Hooks Class Initialized
DEBUG - 2025-06-11 03:58:37 --> UTF-8 Support Enabled
INFO - 2025-06-11 03:58:37 --> Utf8 Class Initialized
INFO - 2025-06-11 03:58:37 --> URI Class Initialized
INFO - 2025-06-11 03:58:37 --> Router Class Initialized
INFO - 2025-06-11 03:58:37 --> Output Class Initialized
INFO - 2025-06-11 03:58:37 --> Security Class Initialized
DEBUG - 2025-06-11 03:58:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-11 03:58:37 --> Input Class Initialized
INFO - 2025-06-11 03:58:37 --> Language Class Initialized
INFO - 2025-06-11 03:58:37 --> Loader Class Initialized
INFO - 2025-06-11 03:58:37 --> Helper loaded: url_helper
INFO - 2025-06-11 03:58:37 --> Helper loaded: form_helper
INFO - 2025-06-11 03:58:37 --> Database Driver Class Initialized
DEBUG - 2025-06-11 03:58:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-11 03:58:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-11 03:58:37 --> Controller Class Initialized
INFO - 2025-06-11 03:58:37 --> Model "User_model" initialized
INFO - 2025-06-11 03:58:37 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-11 03:58:37 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-11 03:58:37 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/profile.php
INFO - 2025-06-11 03:58:37 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-11 03:58:37 --> Final output sent to browser
DEBUG - 2025-06-11 03:58:37 --> Total execution time: 0.0898
INFO - 2025-06-11 03:58:41 --> Config Class Initialized
INFO - 2025-06-11 03:58:41 --> Hooks Class Initialized
DEBUG - 2025-06-11 03:58:41 --> UTF-8 Support Enabled
INFO - 2025-06-11 03:58:41 --> Utf8 Class Initialized
INFO - 2025-06-11 03:58:41 --> URI Class Initialized
INFO - 2025-06-11 03:58:41 --> Router Class Initialized
INFO - 2025-06-11 03:58:41 --> Output Class Initialized
INFO - 2025-06-11 03:58:41 --> Security Class Initialized
DEBUG - 2025-06-11 03:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-11 03:58:41 --> Input Class Initialized
INFO - 2025-06-11 03:58:41 --> Language Class Initialized
INFO - 2025-06-11 03:58:41 --> Loader Class Initialized
INFO - 2025-06-11 03:58:41 --> Helper loaded: url_helper
INFO - 2025-06-11 03:58:41 --> Helper loaded: form_helper
INFO - 2025-06-11 03:58:41 --> Database Driver Class Initialized
DEBUG - 2025-06-11 03:58:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-11 03:58:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-11 03:58:41 --> Controller Class Initialized
INFO - 2025-06-11 03:58:41 --> Model "User_model" initialized
INFO - 2025-06-11 03:58:41 --> Form Validation Class Initialized
INFO - 2025-06-11 03:58:41 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-11 03:58:41 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-11 03:58:41 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/edit_profile.php
INFO - 2025-06-11 03:58:41 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-11 03:58:41 --> Final output sent to browser
DEBUG - 2025-06-11 03:58:41 --> Total execution time: 0.0815
INFO - 2025-06-11 03:59:09 --> Config Class Initialized
INFO - 2025-06-11 03:59:09 --> Hooks Class Initialized
DEBUG - 2025-06-11 03:59:09 --> UTF-8 Support Enabled
INFO - 2025-06-11 03:59:09 --> Utf8 Class Initialized
INFO - 2025-06-11 03:59:09 --> URI Class Initialized
INFO - 2025-06-11 03:59:09 --> Router Class Initialized
INFO - 2025-06-11 03:59:09 --> Output Class Initialized
INFO - 2025-06-11 03:59:09 --> Security Class Initialized
DEBUG - 2025-06-11 03:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-11 03:59:09 --> Input Class Initialized
INFO - 2025-06-11 03:59:09 --> Language Class Initialized
INFO - 2025-06-11 03:59:09 --> Loader Class Initialized
INFO - 2025-06-11 03:59:09 --> Helper loaded: url_helper
INFO - 2025-06-11 03:59:09 --> Helper loaded: form_helper
INFO - 2025-06-11 03:59:09 --> Database Driver Class Initialized
DEBUG - 2025-06-11 03:59:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-11 03:59:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-11 03:59:09 --> Controller Class Initialized
INFO - 2025-06-11 03:59:09 --> Model "User_model" initialized
INFO - 2025-06-11 03:59:09 --> Form Validation Class Initialized
INFO - 2025-06-11 03:59:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-06-11 03:59:09 --> Config Class Initialized
INFO - 2025-06-11 03:59:09 --> Hooks Class Initialized
DEBUG - 2025-06-11 03:59:09 --> UTF-8 Support Enabled
INFO - 2025-06-11 03:59:09 --> Utf8 Class Initialized
INFO - 2025-06-11 03:59:09 --> URI Class Initialized
INFO - 2025-06-11 03:59:09 --> Router Class Initialized
INFO - 2025-06-11 03:59:09 --> Output Class Initialized
INFO - 2025-06-11 03:59:09 --> Security Class Initialized
DEBUG - 2025-06-11 03:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-11 03:59:09 --> Input Class Initialized
INFO - 2025-06-11 03:59:09 --> Language Class Initialized
ERROR - 2025-06-11 03:59:10 --> 404 Page Not Found: Account/dashboard
INFO - 2025-06-11 03:59:33 --> Config Class Initialized
INFO - 2025-06-11 03:59:33 --> Hooks Class Initialized
DEBUG - 2025-06-11 03:59:33 --> UTF-8 Support Enabled
INFO - 2025-06-11 03:59:33 --> Utf8 Class Initialized
INFO - 2025-06-11 03:59:33 --> URI Class Initialized
INFO - 2025-06-11 03:59:33 --> Router Class Initialized
INFO - 2025-06-11 03:59:33 --> Output Class Initialized
INFO - 2025-06-11 03:59:33 --> Security Class Initialized
DEBUG - 2025-06-11 03:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-11 03:59:33 --> Input Class Initialized
INFO - 2025-06-11 03:59:33 --> Language Class Initialized
INFO - 2025-06-11 03:59:33 --> Loader Class Initialized
INFO - 2025-06-11 03:59:33 --> Helper loaded: url_helper
INFO - 2025-06-11 03:59:33 --> Helper loaded: form_helper
INFO - 2025-06-11 03:59:34 --> Database Driver Class Initialized
DEBUG - 2025-06-11 03:59:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-11 03:59:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-11 03:59:34 --> Controller Class Initialized
INFO - 2025-06-11 03:59:34 --> Model "User_model" initialized
INFO - 2025-06-11 03:59:34 --> Model "Progress_model" initialized
INFO - 2025-06-11 03:59:34 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-11 03:59:34 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-11 03:59:34 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/dashboard.php
INFO - 2025-06-11 03:59:34 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-11 03:59:34 --> Final output sent to browser
DEBUG - 2025-06-11 03:59:34 --> Total execution time: 0.2751
INFO - 2025-06-11 03:59:45 --> Config Class Initialized
INFO - 2025-06-11 03:59:45 --> Hooks Class Initialized
DEBUG - 2025-06-11 03:59:45 --> UTF-8 Support Enabled
INFO - 2025-06-11 03:59:45 --> Utf8 Class Initialized
INFO - 2025-06-11 03:59:45 --> URI Class Initialized
INFO - 2025-06-11 03:59:45 --> Router Class Initialized
INFO - 2025-06-11 03:59:45 --> Output Class Initialized
INFO - 2025-06-11 03:59:45 --> Security Class Initialized
DEBUG - 2025-06-11 03:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-11 03:59:45 --> Input Class Initialized
INFO - 2025-06-11 03:59:45 --> Language Class Initialized
INFO - 2025-06-11 03:59:45 --> Loader Class Initialized
INFO - 2025-06-11 03:59:45 --> Helper loaded: url_helper
INFO - 2025-06-11 03:59:45 --> Helper loaded: form_helper
INFO - 2025-06-11 03:59:45 --> Database Driver Class Initialized
DEBUG - 2025-06-11 03:59:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-11 03:59:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-11 03:59:45 --> Controller Class Initialized
INFO - 2025-06-11 03:59:45 --> Model "User_model" initialized
INFO - 2025-06-11 03:59:45 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-11 03:59:45 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-11 03:59:45 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/profile.php
INFO - 2025-06-11 03:59:45 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-11 03:59:45 --> Final output sent to browser
DEBUG - 2025-06-11 03:59:45 --> Total execution time: 0.1919
INFO - 2025-06-11 03:59:47 --> Config Class Initialized
INFO - 2025-06-11 03:59:47 --> Hooks Class Initialized
DEBUG - 2025-06-11 03:59:47 --> UTF-8 Support Enabled
INFO - 2025-06-11 03:59:47 --> Utf8 Class Initialized
INFO - 2025-06-11 03:59:47 --> URI Class Initialized
INFO - 2025-06-11 03:59:47 --> Router Class Initialized
INFO - 2025-06-11 03:59:47 --> Output Class Initialized
INFO - 2025-06-11 03:59:47 --> Security Class Initialized
DEBUG - 2025-06-11 03:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-11 03:59:47 --> Input Class Initialized
INFO - 2025-06-11 03:59:47 --> Language Class Initialized
INFO - 2025-06-11 03:59:47 --> Loader Class Initialized
INFO - 2025-06-11 03:59:47 --> Helper loaded: url_helper
INFO - 2025-06-11 03:59:47 --> Helper loaded: form_helper
INFO - 2025-06-11 03:59:47 --> Database Driver Class Initialized
DEBUG - 2025-06-11 03:59:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-11 03:59:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-11 03:59:47 --> Controller Class Initialized
INFO - 2025-06-11 03:59:47 --> Model "User_model" initialized
INFO - 2025-06-11 03:59:47 --> Form Validation Class Initialized
INFO - 2025-06-11 03:59:47 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-11 03:59:47 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-11 03:59:47 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/edit_profile.php
INFO - 2025-06-11 03:59:47 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-11 03:59:47 --> Final output sent to browser
DEBUG - 2025-06-11 03:59:47 --> Total execution time: 0.0890
INFO - 2025-06-11 03:59:51 --> Config Class Initialized
INFO - 2025-06-11 03:59:51 --> Hooks Class Initialized
DEBUG - 2025-06-11 03:59:51 --> UTF-8 Support Enabled
INFO - 2025-06-11 03:59:51 --> Utf8 Class Initialized
INFO - 2025-06-11 03:59:51 --> URI Class Initialized
INFO - 2025-06-11 03:59:51 --> Router Class Initialized
INFO - 2025-06-11 03:59:51 --> Output Class Initialized
INFO - 2025-06-11 03:59:51 --> Security Class Initialized
DEBUG - 2025-06-11 03:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-11 03:59:51 --> Input Class Initialized
INFO - 2025-06-11 03:59:51 --> Language Class Initialized
INFO - 2025-06-11 03:59:51 --> Loader Class Initialized
INFO - 2025-06-11 03:59:51 --> Helper loaded: url_helper
INFO - 2025-06-11 03:59:51 --> Helper loaded: form_helper
INFO - 2025-06-11 03:59:51 --> Database Driver Class Initialized
DEBUG - 2025-06-11 03:59:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-11 03:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-11 03:59:51 --> Controller Class Initialized
INFO - 2025-06-11 03:59:51 --> Model "User_model" initialized
INFO - 2025-06-11 03:59:51 --> Form Validation Class Initialized
INFO - 2025-06-11 03:59:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-06-11 03:59:51 --> Config Class Initialized
INFO - 2025-06-11 03:59:51 --> Hooks Class Initialized
DEBUG - 2025-06-11 03:59:51 --> UTF-8 Support Enabled
INFO - 2025-06-11 03:59:51 --> Utf8 Class Initialized
INFO - 2025-06-11 03:59:51 --> URI Class Initialized
INFO - 2025-06-11 03:59:51 --> Router Class Initialized
INFO - 2025-06-11 03:59:51 --> Output Class Initialized
INFO - 2025-06-11 03:59:51 --> Security Class Initialized
DEBUG - 2025-06-11 03:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-11 03:59:51 --> Input Class Initialized
INFO - 2025-06-11 03:59:51 --> Language Class Initialized
ERROR - 2025-06-11 03:59:51 --> 404 Page Not Found: Account/Dashboard
INFO - 2025-06-11 04:09:42 --> Config Class Initialized
INFO - 2025-06-11 04:09:42 --> Hooks Class Initialized
DEBUG - 2025-06-11 04:09:42 --> UTF-8 Support Enabled
INFO - 2025-06-11 04:09:42 --> Utf8 Class Initialized
INFO - 2025-06-11 04:09:42 --> URI Class Initialized
INFO - 2025-06-11 04:09:42 --> Router Class Initialized
INFO - 2025-06-11 04:09:42 --> Output Class Initialized
INFO - 2025-06-11 04:09:42 --> Security Class Initialized
DEBUG - 2025-06-11 04:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-11 04:09:42 --> Input Class Initialized
INFO - 2025-06-11 04:09:42 --> Language Class Initialized
INFO - 2025-06-11 04:09:42 --> Loader Class Initialized
INFO - 2025-06-11 04:09:42 --> Helper loaded: url_helper
INFO - 2025-06-11 04:09:42 --> Helper loaded: form_helper
INFO - 2025-06-11 04:09:42 --> Database Driver Class Initialized
DEBUG - 2025-06-11 04:09:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-11 04:09:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-11 04:09:42 --> Controller Class Initialized
INFO - 2025-06-11 04:09:42 --> Model "User_model" initialized
INFO - 2025-06-11 04:09:42 --> Form Validation Class Initialized
INFO - 2025-06-11 04:09:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-06-11 04:09:42 --> Config Class Initialized
INFO - 2025-06-11 04:09:42 --> Hooks Class Initialized
DEBUG - 2025-06-11 04:09:42 --> UTF-8 Support Enabled
INFO - 2025-06-11 04:09:42 --> Utf8 Class Initialized
INFO - 2025-06-11 04:09:42 --> URI Class Initialized
INFO - 2025-06-11 04:09:42 --> Router Class Initialized
INFO - 2025-06-11 04:09:42 --> Output Class Initialized
INFO - 2025-06-11 04:09:42 --> Security Class Initialized
DEBUG - 2025-06-11 04:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-11 04:09:42 --> Input Class Initialized
INFO - 2025-06-11 04:09:42 --> Language Class Initialized
INFO - 2025-06-11 04:09:42 --> Loader Class Initialized
INFO - 2025-06-11 04:09:42 --> Helper loaded: url_helper
INFO - 2025-06-11 04:09:42 --> Helper loaded: form_helper
INFO - 2025-06-11 04:09:42 --> Database Driver Class Initialized
DEBUG - 2025-06-11 04:09:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-11 04:09:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-11 04:09:42 --> Controller Class Initialized
INFO - 2025-06-11 04:09:42 --> Model "User_model" initialized
INFO - 2025-06-11 04:09:42 --> Model "Progress_model" initialized
INFO - 2025-06-11 04:09:42 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-11 04:09:42 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-11 04:09:42 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/dashboard.php
INFO - 2025-06-11 04:09:42 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-11 04:09:42 --> Final output sent to browser
DEBUG - 2025-06-11 04:09:42 --> Total execution time: 0.0941
INFO - 2025-06-11 04:12:02 --> Config Class Initialized
INFO - 2025-06-11 04:12:02 --> Hooks Class Initialized
DEBUG - 2025-06-11 04:12:02 --> UTF-8 Support Enabled
INFO - 2025-06-11 04:12:02 --> Utf8 Class Initialized
INFO - 2025-06-11 04:12:02 --> URI Class Initialized
INFO - 2025-06-11 04:12:02 --> Router Class Initialized
INFO - 2025-06-11 04:12:02 --> Output Class Initialized
INFO - 2025-06-11 04:12:02 --> Security Class Initialized
DEBUG - 2025-06-11 04:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-11 04:12:02 --> Input Class Initialized
INFO - 2025-06-11 04:12:02 --> Language Class Initialized
INFO - 2025-06-11 04:12:02 --> Loader Class Initialized
INFO - 2025-06-11 04:12:02 --> Helper loaded: url_helper
INFO - 2025-06-11 04:12:02 --> Helper loaded: form_helper
INFO - 2025-06-11 04:12:02 --> Database Driver Class Initialized
DEBUG - 2025-06-11 04:12:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-11 04:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-11 04:12:02 --> Controller Class Initialized
INFO - 2025-06-11 04:12:02 --> Model "User_model" initialized
INFO - 2025-06-11 04:12:02 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-11 04:12:02 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-11 04:12:02 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/profile.php
INFO - 2025-06-11 04:12:02 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-11 04:12:02 --> Final output sent to browser
DEBUG - 2025-06-11 04:12:02 --> Total execution time: 0.1353
INFO - 2025-06-11 04:12:04 --> Config Class Initialized
INFO - 2025-06-11 04:12:04 --> Hooks Class Initialized
DEBUG - 2025-06-11 04:12:04 --> UTF-8 Support Enabled
INFO - 2025-06-11 04:12:04 --> Utf8 Class Initialized
INFO - 2025-06-11 04:12:04 --> URI Class Initialized
INFO - 2025-06-11 04:12:04 --> Router Class Initialized
INFO - 2025-06-11 04:12:04 --> Output Class Initialized
INFO - 2025-06-11 04:12:04 --> Security Class Initialized
DEBUG - 2025-06-11 04:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-11 04:12:04 --> Input Class Initialized
INFO - 2025-06-11 04:12:04 --> Language Class Initialized
INFO - 2025-06-11 04:12:04 --> Loader Class Initialized
INFO - 2025-06-11 04:12:04 --> Helper loaded: url_helper
INFO - 2025-06-11 04:12:04 --> Helper loaded: form_helper
INFO - 2025-06-11 04:12:04 --> Database Driver Class Initialized
DEBUG - 2025-06-11 04:12:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-11 04:12:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-11 04:12:04 --> Controller Class Initialized
INFO - 2025-06-11 04:12:04 --> Model "User_model" initialized
INFO - 2025-06-11 04:12:05 --> Form Validation Class Initialized
INFO - 2025-06-11 04:12:05 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-11 04:12:05 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-11 04:12:05 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/edit_profile.php
INFO - 2025-06-11 04:12:05 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-11 04:12:05 --> Final output sent to browser
DEBUG - 2025-06-11 04:12:05 --> Total execution time: 0.2348
INFO - 2025-06-11 04:12:12 --> Config Class Initialized
INFO - 2025-06-11 04:12:12 --> Hooks Class Initialized
DEBUG - 2025-06-11 04:12:12 --> UTF-8 Support Enabled
INFO - 2025-06-11 04:12:12 --> Utf8 Class Initialized
INFO - 2025-06-11 04:12:12 --> URI Class Initialized
INFO - 2025-06-11 04:12:12 --> Router Class Initialized
INFO - 2025-06-11 04:12:12 --> Output Class Initialized
INFO - 2025-06-11 04:12:12 --> Security Class Initialized
DEBUG - 2025-06-11 04:12:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-11 04:12:12 --> Input Class Initialized
INFO - 2025-06-11 04:12:12 --> Language Class Initialized
INFO - 2025-06-11 04:12:12 --> Loader Class Initialized
INFO - 2025-06-11 04:12:12 --> Helper loaded: url_helper
INFO - 2025-06-11 04:12:12 --> Helper loaded: form_helper
INFO - 2025-06-11 04:12:12 --> Database Driver Class Initialized
DEBUG - 2025-06-11 04:12:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-11 04:12:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-11 04:12:12 --> Controller Class Initialized
INFO - 2025-06-11 04:12:12 --> Model "User_model" initialized
INFO - 2025-06-11 04:12:12 --> Form Validation Class Initialized
INFO - 2025-06-11 04:12:12 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-06-11 04:12:13 --> Config Class Initialized
INFO - 2025-06-11 04:12:13 --> Hooks Class Initialized
DEBUG - 2025-06-11 04:12:13 --> UTF-8 Support Enabled
INFO - 2025-06-11 04:12:13 --> Utf8 Class Initialized
INFO - 2025-06-11 04:12:13 --> URI Class Initialized
INFO - 2025-06-11 04:12:13 --> Router Class Initialized
INFO - 2025-06-11 04:12:13 --> Output Class Initialized
INFO - 2025-06-11 04:12:13 --> Security Class Initialized
DEBUG - 2025-06-11 04:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-11 04:12:13 --> Input Class Initialized
INFO - 2025-06-11 04:12:13 --> Language Class Initialized
INFO - 2025-06-11 04:12:13 --> Loader Class Initialized
INFO - 2025-06-11 04:12:13 --> Helper loaded: url_helper
INFO - 2025-06-11 04:12:13 --> Helper loaded: form_helper
INFO - 2025-06-11 04:12:13 --> Database Driver Class Initialized
DEBUG - 2025-06-11 04:12:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-11 04:12:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-11 04:12:13 --> Controller Class Initialized
INFO - 2025-06-11 04:12:13 --> Model "User_model" initialized
INFO - 2025-06-11 04:12:13 --> Model "Progress_model" initialized
INFO - 2025-06-11 04:12:13 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-11 04:12:13 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-11 04:12:13 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/dashboard.php
INFO - 2025-06-11 04:12:13 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-11 04:12:13 --> Final output sent to browser
DEBUG - 2025-06-11 04:12:13 --> Total execution time: 0.1544
INFO - 2025-06-11 04:13:21 --> Config Class Initialized
INFO - 2025-06-11 04:13:21 --> Hooks Class Initialized
DEBUG - 2025-06-11 04:13:21 --> UTF-8 Support Enabled
INFO - 2025-06-11 04:13:21 --> Utf8 Class Initialized
INFO - 2025-06-11 04:13:21 --> URI Class Initialized
INFO - 2025-06-11 04:13:21 --> Router Class Initialized
INFO - 2025-06-11 04:13:21 --> Output Class Initialized
INFO - 2025-06-11 04:13:21 --> Security Class Initialized
DEBUG - 2025-06-11 04:13:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-11 04:13:21 --> Input Class Initialized
INFO - 2025-06-11 04:13:21 --> Language Class Initialized
INFO - 2025-06-11 04:13:21 --> Loader Class Initialized
INFO - 2025-06-11 04:13:21 --> Helper loaded: url_helper
INFO - 2025-06-11 04:13:21 --> Helper loaded: form_helper
INFO - 2025-06-11 04:13:21 --> Database Driver Class Initialized
DEBUG - 2025-06-11 04:13:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-11 04:13:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-11 04:13:21 --> Controller Class Initialized
INFO - 2025-06-11 04:13:21 --> Model "User_model" initialized
INFO - 2025-06-11 04:13:21 --> Model "Progress_model" initialized
INFO - 2025-06-11 04:13:21 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-11 04:13:21 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-11 04:13:21 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/dashboard.php
INFO - 2025-06-11 04:13:21 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-11 04:13:21 --> Final output sent to browser
DEBUG - 2025-06-11 04:13:21 --> Total execution time: 0.1930
INFO - 2025-06-11 04:13:42 --> Config Class Initialized
INFO - 2025-06-11 04:13:42 --> Hooks Class Initialized
DEBUG - 2025-06-11 04:13:42 --> UTF-8 Support Enabled
INFO - 2025-06-11 04:13:42 --> Utf8 Class Initialized
INFO - 2025-06-11 04:13:42 --> URI Class Initialized
INFO - 2025-06-11 04:13:42 --> Router Class Initialized
INFO - 2025-06-11 04:13:42 --> Output Class Initialized
INFO - 2025-06-11 04:13:42 --> Security Class Initialized
DEBUG - 2025-06-11 04:13:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-11 04:13:42 --> Input Class Initialized
INFO - 2025-06-11 04:13:42 --> Language Class Initialized
INFO - 2025-06-11 04:13:42 --> Loader Class Initialized
INFO - 2025-06-11 04:13:42 --> Helper loaded: url_helper
INFO - 2025-06-11 04:13:42 --> Helper loaded: form_helper
INFO - 2025-06-11 04:13:42 --> Database Driver Class Initialized
DEBUG - 2025-06-11 04:13:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-11 04:13:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-11 04:13:42 --> Controller Class Initialized
INFO - 2025-06-11 04:13:42 --> Model "User_model" initialized
INFO - 2025-06-11 04:13:42 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-11 04:13:42 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-11 04:13:42 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/profile.php
INFO - 2025-06-11 04:13:42 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-11 04:13:42 --> Final output sent to browser
DEBUG - 2025-06-11 04:13:42 --> Total execution time: 0.0868
INFO - 2025-06-11 04:13:44 --> Config Class Initialized
INFO - 2025-06-11 04:13:44 --> Hooks Class Initialized
DEBUG - 2025-06-11 04:13:44 --> UTF-8 Support Enabled
INFO - 2025-06-11 04:13:44 --> Utf8 Class Initialized
INFO - 2025-06-11 04:13:44 --> URI Class Initialized
INFO - 2025-06-11 04:13:44 --> Router Class Initialized
INFO - 2025-06-11 04:13:44 --> Output Class Initialized
INFO - 2025-06-11 04:13:44 --> Security Class Initialized
DEBUG - 2025-06-11 04:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-11 04:13:44 --> Input Class Initialized
INFO - 2025-06-11 04:13:44 --> Language Class Initialized
INFO - 2025-06-11 04:13:44 --> Loader Class Initialized
INFO - 2025-06-11 04:13:44 --> Helper loaded: url_helper
INFO - 2025-06-11 04:13:44 --> Helper loaded: form_helper
INFO - 2025-06-11 04:13:44 --> Database Driver Class Initialized
DEBUG - 2025-06-11 04:13:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-11 04:13:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-11 04:13:44 --> Controller Class Initialized
INFO - 2025-06-11 04:13:44 --> Model "User_model" initialized
INFO - 2025-06-11 04:13:44 --> Form Validation Class Initialized
INFO - 2025-06-11 04:13:44 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-11 04:13:44 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-11 04:13:44 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/edit_profile.php
INFO - 2025-06-11 04:13:44 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-11 04:13:44 --> Final output sent to browser
DEBUG - 2025-06-11 04:13:44 --> Total execution time: 0.0954
INFO - 2025-06-11 04:13:50 --> Config Class Initialized
INFO - 2025-06-11 04:13:50 --> Hooks Class Initialized
DEBUG - 2025-06-11 04:13:50 --> UTF-8 Support Enabled
INFO - 2025-06-11 04:13:50 --> Utf8 Class Initialized
INFO - 2025-06-11 04:13:50 --> URI Class Initialized
INFO - 2025-06-11 04:13:50 --> Router Class Initialized
INFO - 2025-06-11 04:13:50 --> Output Class Initialized
INFO - 2025-06-11 04:13:50 --> Security Class Initialized
DEBUG - 2025-06-11 04:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-11 04:13:50 --> Input Class Initialized
INFO - 2025-06-11 04:13:50 --> Language Class Initialized
INFO - 2025-06-11 04:13:50 --> Loader Class Initialized
INFO - 2025-06-11 04:13:50 --> Helper loaded: url_helper
INFO - 2025-06-11 04:13:50 --> Helper loaded: form_helper
INFO - 2025-06-11 04:13:50 --> Database Driver Class Initialized
DEBUG - 2025-06-11 04:13:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-11 04:13:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-11 04:13:50 --> Controller Class Initialized
INFO - 2025-06-11 04:13:50 --> Model "User_model" initialized
INFO - 2025-06-11 04:13:50 --> Form Validation Class Initialized
INFO - 2025-06-11 04:13:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-06-11 04:13:50 --> Config Class Initialized
INFO - 2025-06-11 04:13:50 --> Hooks Class Initialized
DEBUG - 2025-06-11 04:13:50 --> UTF-8 Support Enabled
INFO - 2025-06-11 04:13:50 --> Utf8 Class Initialized
INFO - 2025-06-11 04:13:50 --> URI Class Initialized
INFO - 2025-06-11 04:13:50 --> Router Class Initialized
INFO - 2025-06-11 04:13:50 --> Output Class Initialized
INFO - 2025-06-11 04:13:50 --> Security Class Initialized
DEBUG - 2025-06-11 04:13:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-11 04:13:50 --> Input Class Initialized
INFO - 2025-06-11 04:13:50 --> Language Class Initialized
INFO - 2025-06-11 04:13:50 --> Loader Class Initialized
INFO - 2025-06-11 04:13:50 --> Helper loaded: url_helper
INFO - 2025-06-11 04:13:50 --> Helper loaded: form_helper
INFO - 2025-06-11 04:13:50 --> Database Driver Class Initialized
DEBUG - 2025-06-11 04:13:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-11 04:13:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-11 04:13:50 --> Controller Class Initialized
INFO - 2025-06-11 04:13:50 --> Model "User_model" initialized
INFO - 2025-06-11 04:13:50 --> Model "Progress_model" initialized
INFO - 2025-06-11 04:13:50 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-11 04:13:50 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-11 04:13:50 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/dashboard.php
INFO - 2025-06-11 04:13:50 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-11 04:13:50 --> Final output sent to browser
DEBUG - 2025-06-11 04:13:50 --> Total execution time: 0.1227
INFO - 2025-06-11 04:22:50 --> Config Class Initialized
INFO - 2025-06-11 04:22:50 --> Hooks Class Initialized
DEBUG - 2025-06-11 04:22:50 --> UTF-8 Support Enabled
INFO - 2025-06-11 04:22:50 --> Utf8 Class Initialized
INFO - 2025-06-11 04:22:50 --> URI Class Initialized
INFO - 2025-06-11 04:22:50 --> Router Class Initialized
INFO - 2025-06-11 04:22:50 --> Output Class Initialized
INFO - 2025-06-11 04:22:50 --> Security Class Initialized
DEBUG - 2025-06-11 04:22:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-11 04:22:50 --> Input Class Initialized
INFO - 2025-06-11 04:22:50 --> Language Class Initialized
INFO - 2025-06-11 04:22:50 --> Loader Class Initialized
INFO - 2025-06-11 04:22:50 --> Helper loaded: url_helper
INFO - 2025-06-11 04:22:50 --> Helper loaded: form_helper
INFO - 2025-06-11 04:22:50 --> Database Driver Class Initialized
DEBUG - 2025-06-11 04:22:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-11 04:22:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-11 04:22:50 --> Controller Class Initialized
INFO - 2025-06-11 04:22:50 --> Model "User_model" initialized
INFO - 2025-06-11 04:22:50 --> Model "Progress_model" initialized
INFO - 2025-06-11 04:22:50 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-11 04:22:50 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-11 04:22:50 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/dashboard.php
INFO - 2025-06-11 04:22:50 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-11 04:22:50 --> Final output sent to browser
DEBUG - 2025-06-11 04:22:50 --> Total execution time: 0.1754
INFO - 2025-06-11 04:31:39 --> Config Class Initialized
INFO - 2025-06-11 04:31:39 --> Hooks Class Initialized
DEBUG - 2025-06-11 04:31:39 --> UTF-8 Support Enabled
INFO - 2025-06-11 04:31:39 --> Utf8 Class Initialized
INFO - 2025-06-11 04:31:39 --> URI Class Initialized
INFO - 2025-06-11 04:31:39 --> Router Class Initialized
INFO - 2025-06-11 04:31:39 --> Output Class Initialized
INFO - 2025-06-11 04:31:39 --> Security Class Initialized
DEBUG - 2025-06-11 04:31:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-11 04:31:39 --> Input Class Initialized
INFO - 2025-06-11 04:31:39 --> Language Class Initialized
INFO - 2025-06-11 04:31:39 --> Loader Class Initialized
INFO - 2025-06-11 04:31:39 --> Helper loaded: url_helper
INFO - 2025-06-11 04:31:39 --> Helper loaded: form_helper
INFO - 2025-06-11 04:31:39 --> Database Driver Class Initialized
DEBUG - 2025-06-11 04:31:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-11 04:31:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-11 04:31:39 --> Controller Class Initialized
INFO - 2025-06-11 04:31:39 --> Model "User_model" initialized
INFO - 2025-06-11 04:31:39 --> Form Validation Class Initialized
INFO - 2025-06-11 04:31:39 --> Config Class Initialized
INFO - 2025-06-11 04:31:39 --> Hooks Class Initialized
DEBUG - 2025-06-11 04:31:39 --> UTF-8 Support Enabled
INFO - 2025-06-11 04:31:39 --> Utf8 Class Initialized
INFO - 2025-06-11 04:31:39 --> URI Class Initialized
INFO - 2025-06-11 04:31:39 --> Router Class Initialized
INFO - 2025-06-11 04:31:39 --> Output Class Initialized
INFO - 2025-06-11 04:31:39 --> Security Class Initialized
DEBUG - 2025-06-11 04:31:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-11 04:31:39 --> Input Class Initialized
INFO - 2025-06-11 04:31:39 --> Language Class Initialized
INFO - 2025-06-11 04:31:39 --> Loader Class Initialized
INFO - 2025-06-11 04:31:39 --> Helper loaded: url_helper
INFO - 2025-06-11 04:31:39 --> Helper loaded: form_helper
INFO - 2025-06-11 04:31:39 --> Database Driver Class Initialized
DEBUG - 2025-06-11 04:31:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-11 04:31:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-11 04:31:39 --> Controller Class Initialized
INFO - 2025-06-11 04:31:39 --> Model "User_model" initialized
INFO - 2025-06-11 04:31:39 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-06-11 04:31:39 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/home.php
INFO - 2025-06-11 04:31:39 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-06-11 04:31:39 --> Final output sent to browser
DEBUG - 2025-06-11 04:31:39 --> Total execution time: 0.4401
INFO - 2025-06-11 14:54:51 --> Config Class Initialized
INFO - 2025-06-11 14:54:51 --> Hooks Class Initialized
DEBUG - 2025-06-11 14:54:51 --> UTF-8 Support Enabled
INFO - 2025-06-11 14:54:51 --> Utf8 Class Initialized
INFO - 2025-06-11 14:54:51 --> URI Class Initialized
DEBUG - 2025-06-11 14:54:51 --> No URI present. Default controller set.
INFO - 2025-06-11 14:54:51 --> Router Class Initialized
INFO - 2025-06-11 14:54:52 --> Output Class Initialized
INFO - 2025-06-11 14:54:52 --> Security Class Initialized
DEBUG - 2025-06-11 14:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-11 14:54:52 --> Input Class Initialized
INFO - 2025-06-11 14:54:52 --> Language Class Initialized
INFO - 2025-06-11 14:54:52 --> Loader Class Initialized
INFO - 2025-06-11 14:54:52 --> Helper loaded: url_helper
INFO - 2025-06-11 14:54:52 --> Helper loaded: form_helper
INFO - 2025-06-11 14:54:52 --> Database Driver Class Initialized
DEBUG - 2025-06-11 14:54:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-11 14:54:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-11 14:54:53 --> Controller Class Initialized
INFO - 2025-06-11 14:54:53 --> Model "User_model" initialized
INFO - 2025-06-11 14:54:53 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-06-11 14:54:53 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/home.php
INFO - 2025-06-11 14:54:53 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-06-11 14:54:53 --> Final output sent to browser
DEBUG - 2025-06-11 14:54:53 --> Total execution time: 2.3049
INFO - 2025-06-11 14:58:46 --> Config Class Initialized
INFO - 2025-06-11 14:58:46 --> Hooks Class Initialized
DEBUG - 2025-06-11 14:58:46 --> UTF-8 Support Enabled
INFO - 2025-06-11 14:58:46 --> Utf8 Class Initialized
INFO - 2025-06-11 14:58:46 --> URI Class Initialized
INFO - 2025-06-11 14:58:46 --> Router Class Initialized
INFO - 2025-06-11 14:58:46 --> Output Class Initialized
INFO - 2025-06-11 14:58:46 --> Security Class Initialized
DEBUG - 2025-06-11 14:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-11 14:58:46 --> Input Class Initialized
INFO - 2025-06-11 14:58:46 --> Language Class Initialized
INFO - 2025-06-11 14:58:47 --> Loader Class Initialized
INFO - 2025-06-11 14:58:47 --> Helper loaded: url_helper
INFO - 2025-06-11 14:58:47 --> Helper loaded: form_helper
INFO - 2025-06-11 14:58:47 --> Database Driver Class Initialized
DEBUG - 2025-06-11 14:58:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-11 14:58:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-11 14:58:47 --> Controller Class Initialized
INFO - 2025-06-11 14:58:47 --> Model "User_model" initialized
INFO - 2025-06-11 14:58:47 --> Form Validation Class Initialized
INFO - 2025-06-11 14:58:47 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\auth/login.php
INFO - 2025-06-11 14:58:47 --> Final output sent to browser
DEBUG - 2025-06-11 14:58:47 --> Total execution time: 0.3864
INFO - 2025-06-11 14:58:57 --> Config Class Initialized
INFO - 2025-06-11 14:58:57 --> Hooks Class Initialized
DEBUG - 2025-06-11 14:58:57 --> UTF-8 Support Enabled
INFO - 2025-06-11 14:58:57 --> Utf8 Class Initialized
INFO - 2025-06-11 14:58:57 --> URI Class Initialized
INFO - 2025-06-11 14:58:57 --> Router Class Initialized
INFO - 2025-06-11 14:58:57 --> Output Class Initialized
INFO - 2025-06-11 14:58:57 --> Security Class Initialized
DEBUG - 2025-06-11 14:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-11 14:58:57 --> Input Class Initialized
INFO - 2025-06-11 14:58:57 --> Language Class Initialized
INFO - 2025-06-11 14:58:57 --> Loader Class Initialized
INFO - 2025-06-11 14:58:57 --> Helper loaded: url_helper
INFO - 2025-06-11 14:58:57 --> Helper loaded: form_helper
INFO - 2025-06-11 14:58:57 --> Database Driver Class Initialized
DEBUG - 2025-06-11 14:58:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-11 14:58:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-11 14:58:57 --> Controller Class Initialized
INFO - 2025-06-11 14:58:57 --> Model "User_model" initialized
INFO - 2025-06-11 14:58:57 --> Form Validation Class Initialized
INFO - 2025-06-11 14:58:57 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-06-11 14:58:57 --> Config Class Initialized
INFO - 2025-06-11 14:58:57 --> Hooks Class Initialized
DEBUG - 2025-06-11 14:58:57 --> UTF-8 Support Enabled
INFO - 2025-06-11 14:58:57 --> Utf8 Class Initialized
INFO - 2025-06-11 14:58:57 --> URI Class Initialized
INFO - 2025-06-11 14:58:57 --> Router Class Initialized
INFO - 2025-06-11 14:58:57 --> Output Class Initialized
INFO - 2025-06-11 14:58:57 --> Security Class Initialized
DEBUG - 2025-06-11 14:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-11 14:58:57 --> Input Class Initialized
INFO - 2025-06-11 14:58:57 --> Language Class Initialized
INFO - 2025-06-11 14:58:57 --> Loader Class Initialized
INFO - 2025-06-11 14:58:57 --> Helper loaded: url_helper
INFO - 2025-06-11 14:58:57 --> Helper loaded: form_helper
INFO - 2025-06-11 14:58:57 --> Database Driver Class Initialized
DEBUG - 2025-06-11 14:58:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-11 14:58:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-11 14:58:57 --> Controller Class Initialized
INFO - 2025-06-11 14:58:57 --> Model "User_model" initialized
INFO - 2025-06-11 14:58:57 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-06-11 14:58:57 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/home.php
INFO - 2025-06-11 14:58:57 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-06-11 14:58:57 --> Final output sent to browser
DEBUG - 2025-06-11 14:58:57 --> Total execution time: 0.1038
INFO - 2025-06-11 14:58:59 --> Config Class Initialized
INFO - 2025-06-11 14:58:59 --> Hooks Class Initialized
DEBUG - 2025-06-11 14:58:59 --> UTF-8 Support Enabled
INFO - 2025-06-11 14:58:59 --> Utf8 Class Initialized
INFO - 2025-06-11 14:58:59 --> URI Class Initialized
INFO - 2025-06-11 14:58:59 --> Router Class Initialized
INFO - 2025-06-11 14:59:00 --> Output Class Initialized
INFO - 2025-06-11 14:59:00 --> Security Class Initialized
DEBUG - 2025-06-11 14:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-11 14:59:00 --> Input Class Initialized
INFO - 2025-06-11 14:59:00 --> Language Class Initialized
INFO - 2025-06-11 14:59:00 --> Loader Class Initialized
INFO - 2025-06-11 14:59:00 --> Helper loaded: url_helper
INFO - 2025-06-11 14:59:00 --> Helper loaded: form_helper
INFO - 2025-06-11 14:59:00 --> Database Driver Class Initialized
DEBUG - 2025-06-11 14:59:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-11 14:59:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-11 14:59:00 --> Controller Class Initialized
INFO - 2025-06-11 14:59:00 --> Model "User_model" initialized
INFO - 2025-06-11 14:59:00 --> Model "Progress_model" initialized
INFO - 2025-06-11 14:59:00 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-11 14:59:00 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-11 14:59:00 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/dashboard.php
INFO - 2025-06-11 14:59:00 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-11 14:59:00 --> Final output sent to browser
DEBUG - 2025-06-11 14:59:00 --> Total execution time: 0.6676
INFO - 2025-06-11 14:59:05 --> Config Class Initialized
INFO - 2025-06-11 14:59:05 --> Hooks Class Initialized
DEBUG - 2025-06-11 14:59:05 --> UTF-8 Support Enabled
INFO - 2025-06-11 14:59:05 --> Utf8 Class Initialized
INFO - 2025-06-11 14:59:05 --> URI Class Initialized
INFO - 2025-06-11 14:59:05 --> Router Class Initialized
INFO - 2025-06-11 14:59:05 --> Output Class Initialized
INFO - 2025-06-11 14:59:05 --> Security Class Initialized
DEBUG - 2025-06-11 14:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-11 14:59:05 --> Input Class Initialized
INFO - 2025-06-11 14:59:05 --> Language Class Initialized
INFO - 2025-06-11 14:59:05 --> Loader Class Initialized
INFO - 2025-06-11 14:59:05 --> Helper loaded: url_helper
INFO - 2025-06-11 14:59:05 --> Helper loaded: form_helper
INFO - 2025-06-11 14:59:05 --> Database Driver Class Initialized
DEBUG - 2025-06-11 14:59:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-11 14:59:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-11 14:59:05 --> Controller Class Initialized
INFO - 2025-06-11 14:59:05 --> Model "User_model" initialized
INFO - 2025-06-11 14:59:05 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-11 14:59:05 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-11 14:59:05 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/profile.php
INFO - 2025-06-11 14:59:05 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-11 14:59:05 --> Final output sent to browser
DEBUG - 2025-06-11 14:59:05 --> Total execution time: 0.1656
INFO - 2025-06-11 14:59:07 --> Config Class Initialized
INFO - 2025-06-11 14:59:07 --> Hooks Class Initialized
DEBUG - 2025-06-11 14:59:07 --> UTF-8 Support Enabled
INFO - 2025-06-11 14:59:07 --> Utf8 Class Initialized
INFO - 2025-06-11 14:59:07 --> URI Class Initialized
INFO - 2025-06-11 14:59:07 --> Router Class Initialized
INFO - 2025-06-11 14:59:07 --> Output Class Initialized
INFO - 2025-06-11 14:59:07 --> Security Class Initialized
DEBUG - 2025-06-11 14:59:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-11 14:59:07 --> Input Class Initialized
INFO - 2025-06-11 14:59:07 --> Language Class Initialized
INFO - 2025-06-11 14:59:07 --> Loader Class Initialized
INFO - 2025-06-11 14:59:07 --> Helper loaded: url_helper
INFO - 2025-06-11 14:59:07 --> Helper loaded: form_helper
INFO - 2025-06-11 14:59:07 --> Database Driver Class Initialized
DEBUG - 2025-06-11 14:59:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-11 14:59:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-11 14:59:07 --> Controller Class Initialized
INFO - 2025-06-11 14:59:07 --> Model "User_model" initialized
INFO - 2025-06-11 14:59:07 --> Form Validation Class Initialized
INFO - 2025-06-11 14:59:07 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-11 14:59:07 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-11 14:59:07 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/edit_profile.php
INFO - 2025-06-11 14:59:07 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-11 14:59:07 --> Final output sent to browser
DEBUG - 2025-06-11 14:59:07 --> Total execution time: 0.1026
INFO - 2025-06-11 14:59:09 --> Config Class Initialized
INFO - 2025-06-11 14:59:09 --> Hooks Class Initialized
DEBUG - 2025-06-11 14:59:09 --> UTF-8 Support Enabled
INFO - 2025-06-11 14:59:09 --> Utf8 Class Initialized
INFO - 2025-06-11 14:59:09 --> URI Class Initialized
INFO - 2025-06-11 14:59:09 --> Router Class Initialized
INFO - 2025-06-11 14:59:09 --> Output Class Initialized
INFO - 2025-06-11 14:59:09 --> Security Class Initialized
DEBUG - 2025-06-11 14:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-11 14:59:09 --> Input Class Initialized
INFO - 2025-06-11 14:59:09 --> Language Class Initialized
INFO - 2025-06-11 14:59:09 --> Loader Class Initialized
INFO - 2025-06-11 14:59:09 --> Helper loaded: url_helper
INFO - 2025-06-11 14:59:09 --> Helper loaded: form_helper
INFO - 2025-06-11 14:59:09 --> Database Driver Class Initialized
DEBUG - 2025-06-11 14:59:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-11 14:59:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-11 14:59:09 --> Controller Class Initialized
INFO - 2025-06-11 14:59:09 --> Model "User_model" initialized
INFO - 2025-06-11 14:59:09 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-11 14:59:09 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-11 14:59:09 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/profile.php
INFO - 2025-06-11 14:59:09 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-11 14:59:09 --> Final output sent to browser
DEBUG - 2025-06-11 14:59:09 --> Total execution time: 0.0880
INFO - 2025-06-11 14:59:11 --> Config Class Initialized
INFO - 2025-06-11 14:59:11 --> Hooks Class Initialized
DEBUG - 2025-06-11 14:59:11 --> UTF-8 Support Enabled
INFO - 2025-06-11 14:59:11 --> Utf8 Class Initialized
INFO - 2025-06-11 14:59:11 --> URI Class Initialized
INFO - 2025-06-11 14:59:11 --> Router Class Initialized
INFO - 2025-06-11 14:59:11 --> Output Class Initialized
INFO - 2025-06-11 14:59:11 --> Security Class Initialized
DEBUG - 2025-06-11 14:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-11 14:59:11 --> Input Class Initialized
INFO - 2025-06-11 14:59:11 --> Language Class Initialized
INFO - 2025-06-11 14:59:11 --> Loader Class Initialized
INFO - 2025-06-11 14:59:11 --> Helper loaded: url_helper
INFO - 2025-06-11 14:59:11 --> Helper loaded: form_helper
INFO - 2025-06-11 14:59:11 --> Database Driver Class Initialized
DEBUG - 2025-06-11 14:59:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-11 14:59:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-11 14:59:11 --> Controller Class Initialized
INFO - 2025-06-11 14:59:11 --> Model "User_model" initialized
INFO - 2025-06-11 14:59:11 --> Form Validation Class Initialized
INFO - 2025-06-11 14:59:11 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-11 14:59:11 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-11 14:59:11 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/edit_profile.php
INFO - 2025-06-11 14:59:11 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-11 14:59:11 --> Final output sent to browser
DEBUG - 2025-06-11 14:59:11 --> Total execution time: 0.0944
INFO - 2025-06-11 14:59:15 --> Config Class Initialized
INFO - 2025-06-11 14:59:15 --> Hooks Class Initialized
DEBUG - 2025-06-11 14:59:15 --> UTF-8 Support Enabled
INFO - 2025-06-11 14:59:15 --> Utf8 Class Initialized
INFO - 2025-06-11 14:59:15 --> URI Class Initialized
INFO - 2025-06-11 14:59:15 --> Router Class Initialized
INFO - 2025-06-11 14:59:15 --> Output Class Initialized
INFO - 2025-06-11 14:59:15 --> Security Class Initialized
DEBUG - 2025-06-11 14:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-11 14:59:15 --> Input Class Initialized
INFO - 2025-06-11 14:59:15 --> Language Class Initialized
INFO - 2025-06-11 14:59:15 --> Loader Class Initialized
INFO - 2025-06-11 14:59:15 --> Helper loaded: url_helper
INFO - 2025-06-11 14:59:15 --> Helper loaded: form_helper
INFO - 2025-06-11 14:59:15 --> Database Driver Class Initialized
DEBUG - 2025-06-11 14:59:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-11 14:59:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-11 14:59:15 --> Controller Class Initialized
INFO - 2025-06-11 14:59:15 --> Model "User_model" initialized
INFO - 2025-06-11 14:59:15 --> Form Validation Class Initialized
INFO - 2025-06-11 14:59:15 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-06-11 14:59:16 --> Config Class Initialized
INFO - 2025-06-11 14:59:16 --> Hooks Class Initialized
DEBUG - 2025-06-11 14:59:16 --> UTF-8 Support Enabled
INFO - 2025-06-11 14:59:16 --> Utf8 Class Initialized
INFO - 2025-06-11 14:59:16 --> URI Class Initialized
INFO - 2025-06-11 14:59:16 --> Router Class Initialized
INFO - 2025-06-11 14:59:16 --> Output Class Initialized
INFO - 2025-06-11 14:59:16 --> Security Class Initialized
DEBUG - 2025-06-11 14:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-11 14:59:16 --> Input Class Initialized
INFO - 2025-06-11 14:59:16 --> Language Class Initialized
INFO - 2025-06-11 14:59:16 --> Loader Class Initialized
INFO - 2025-06-11 14:59:16 --> Helper loaded: url_helper
INFO - 2025-06-11 14:59:16 --> Helper loaded: form_helper
INFO - 2025-06-11 14:59:16 --> Database Driver Class Initialized
DEBUG - 2025-06-11 14:59:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-11 14:59:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-11 14:59:16 --> Controller Class Initialized
INFO - 2025-06-11 14:59:16 --> Model "User_model" initialized
INFO - 2025-06-11 14:59:16 --> Model "Progress_model" initialized
INFO - 2025-06-11 14:59:16 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-11 14:59:16 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-11 14:59:16 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/dashboard.php
INFO - 2025-06-11 14:59:16 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-11 14:59:16 --> Final output sent to browser
DEBUG - 2025-06-11 14:59:16 --> Total execution time: 0.1038
INFO - 2025-06-11 14:59:31 --> Config Class Initialized
INFO - 2025-06-11 14:59:31 --> Hooks Class Initialized
DEBUG - 2025-06-11 14:59:31 --> UTF-8 Support Enabled
INFO - 2025-06-11 14:59:31 --> Utf8 Class Initialized
INFO - 2025-06-11 14:59:31 --> URI Class Initialized
INFO - 2025-06-11 14:59:31 --> Router Class Initialized
INFO - 2025-06-11 14:59:31 --> Output Class Initialized
INFO - 2025-06-11 14:59:31 --> Security Class Initialized
DEBUG - 2025-06-11 14:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-11 14:59:31 --> Input Class Initialized
INFO - 2025-06-11 14:59:31 --> Language Class Initialized
INFO - 2025-06-11 14:59:31 --> Loader Class Initialized
INFO - 2025-06-11 14:59:31 --> Helper loaded: url_helper
INFO - 2025-06-11 14:59:31 --> Helper loaded: form_helper
INFO - 2025-06-11 14:59:31 --> Database Driver Class Initialized
DEBUG - 2025-06-11 14:59:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-11 14:59:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-11 14:59:31 --> Controller Class Initialized
INFO - 2025-06-11 14:59:31 --> Model "User_model" initialized
INFO - 2025-06-11 14:59:31 --> Form Validation Class Initialized
INFO - 2025-06-11 14:59:31 --> Config Class Initialized
INFO - 2025-06-11 14:59:31 --> Hooks Class Initialized
DEBUG - 2025-06-11 14:59:31 --> UTF-8 Support Enabled
INFO - 2025-06-11 14:59:31 --> Utf8 Class Initialized
INFO - 2025-06-11 14:59:31 --> URI Class Initialized
INFO - 2025-06-11 14:59:31 --> Router Class Initialized
INFO - 2025-06-11 14:59:31 --> Output Class Initialized
INFO - 2025-06-11 14:59:31 --> Security Class Initialized
DEBUG - 2025-06-11 14:59:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-11 14:59:31 --> Input Class Initialized
INFO - 2025-06-11 14:59:31 --> Language Class Initialized
INFO - 2025-06-11 14:59:31 --> Loader Class Initialized
INFO - 2025-06-11 14:59:31 --> Helper loaded: url_helper
INFO - 2025-06-11 14:59:31 --> Helper loaded: form_helper
INFO - 2025-06-11 14:59:31 --> Database Driver Class Initialized
DEBUG - 2025-06-11 14:59:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-11 14:59:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-11 14:59:31 --> Controller Class Initialized
INFO - 2025-06-11 14:59:31 --> Model "User_model" initialized
INFO - 2025-06-11 14:59:31 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-06-11 14:59:31 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/home.php
INFO - 2025-06-11 14:59:31 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-06-11 14:59:31 --> Final output sent to browser
DEBUG - 2025-06-11 14:59:31 --> Total execution time: 0.0996
