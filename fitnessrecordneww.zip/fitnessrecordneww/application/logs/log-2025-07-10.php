<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-07-10 04:43:48 --> Config Class Initialized
INFO - 2025-07-10 04:43:48 --> Hooks Class Initialized
DEBUG - 2025-07-10 04:43:48 --> UTF-8 Support Enabled
INFO - 2025-07-10 04:43:48 --> Utf8 Class Initialized
INFO - 2025-07-10 04:43:48 --> URI Class Initialized
DEBUG - 2025-07-10 04:43:48 --> No URI present. Default controller set.
INFO - 2025-07-10 04:43:48 --> Router Class Initialized
INFO - 2025-07-10 04:43:49 --> Output Class Initialized
INFO - 2025-07-10 04:43:49 --> Security Class Initialized
DEBUG - 2025-07-10 04:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-10 04:43:49 --> Input Class Initialized
INFO - 2025-07-10 04:43:49 --> Language Class Initialized
INFO - 2025-07-10 04:43:49 --> Loader Class Initialized
INFO - 2025-07-10 04:43:49 --> Helper loaded: url_helper
INFO - 2025-07-10 04:43:49 --> Helper loaded: form_helper
INFO - 2025-07-10 04:43:50 --> Database Driver Class Initialized
DEBUG - 2025-07-10 04:43:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-10 04:43:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-10 04:43:50 --> Controller Class Initialized
INFO - 2025-07-10 04:43:50 --> Model "User_model" initialized
INFO - 2025-07-10 04:43:50 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-07-10 04:43:51 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\landing_page/home.php
INFO - 2025-07-10 04:43:51 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-07-10 04:43:51 --> Final output sent to browser
DEBUG - 2025-07-10 04:43:51 --> Total execution time: 2.9815
INFO - 2025-07-10 04:44:00 --> Config Class Initialized
INFO - 2025-07-10 04:44:00 --> Hooks Class Initialized
DEBUG - 2025-07-10 04:44:00 --> UTF-8 Support Enabled
INFO - 2025-07-10 04:44:00 --> Utf8 Class Initialized
INFO - 2025-07-10 04:44:00 --> URI Class Initialized
INFO - 2025-07-10 04:44:00 --> Router Class Initialized
INFO - 2025-07-10 04:44:00 --> Output Class Initialized
INFO - 2025-07-10 04:44:00 --> Security Class Initialized
DEBUG - 2025-07-10 04:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-10 04:44:00 --> Input Class Initialized
INFO - 2025-07-10 04:44:00 --> Language Class Initialized
INFO - 2025-07-10 04:44:00 --> Loader Class Initialized
INFO - 2025-07-10 04:44:00 --> Helper loaded: url_helper
INFO - 2025-07-10 04:44:00 --> Helper loaded: form_helper
INFO - 2025-07-10 04:44:00 --> Database Driver Class Initialized
DEBUG - 2025-07-10 04:44:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-10 04:44:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-10 04:44:00 --> Controller Class Initialized
INFO - 2025-07-10 04:44:00 --> Model "User_model" initialized
INFO - 2025-07-10 04:44:00 --> Form Validation Class Initialized
INFO - 2025-07-10 04:44:01 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\auth/login.php
INFO - 2025-07-10 04:44:01 --> Final output sent to browser
DEBUG - 2025-07-10 04:44:01 --> Total execution time: 0.3126
INFO - 2025-07-10 04:44:08 --> Config Class Initialized
INFO - 2025-07-10 04:44:08 --> Hooks Class Initialized
DEBUG - 2025-07-10 04:44:08 --> UTF-8 Support Enabled
INFO - 2025-07-10 04:44:08 --> Utf8 Class Initialized
INFO - 2025-07-10 04:44:08 --> URI Class Initialized
INFO - 2025-07-10 04:44:08 --> Router Class Initialized
INFO - 2025-07-10 04:44:08 --> Output Class Initialized
INFO - 2025-07-10 04:44:08 --> Security Class Initialized
DEBUG - 2025-07-10 04:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-10 04:44:08 --> Input Class Initialized
INFO - 2025-07-10 04:44:08 --> Language Class Initialized
INFO - 2025-07-10 04:44:08 --> Loader Class Initialized
INFO - 2025-07-10 04:44:08 --> Helper loaded: url_helper
INFO - 2025-07-10 04:44:08 --> Helper loaded: form_helper
INFO - 2025-07-10 04:44:08 --> Database Driver Class Initialized
DEBUG - 2025-07-10 04:44:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-10 04:44:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-10 04:44:08 --> Controller Class Initialized
INFO - 2025-07-10 04:44:08 --> Model "User_model" initialized
INFO - 2025-07-10 04:44:08 --> Form Validation Class Initialized
INFO - 2025-07-10 04:44:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-07-10 04:44:08 --> Config Class Initialized
INFO - 2025-07-10 04:44:08 --> Hooks Class Initialized
DEBUG - 2025-07-10 04:44:08 --> UTF-8 Support Enabled
INFO - 2025-07-10 04:44:08 --> Utf8 Class Initialized
INFO - 2025-07-10 04:44:08 --> URI Class Initialized
INFO - 2025-07-10 04:44:08 --> Router Class Initialized
INFO - 2025-07-10 04:44:08 --> Output Class Initialized
INFO - 2025-07-10 04:44:08 --> Security Class Initialized
DEBUG - 2025-07-10 04:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-10 04:44:08 --> Input Class Initialized
INFO - 2025-07-10 04:44:08 --> Language Class Initialized
INFO - 2025-07-10 04:44:08 --> Loader Class Initialized
INFO - 2025-07-10 04:44:08 --> Helper loaded: url_helper
INFO - 2025-07-10 04:44:08 --> Helper loaded: form_helper
INFO - 2025-07-10 04:44:08 --> Database Driver Class Initialized
DEBUG - 2025-07-10 04:44:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-10 04:44:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-10 04:44:08 --> Controller Class Initialized
INFO - 2025-07-10 04:44:08 --> Model "User_model" initialized
INFO - 2025-07-10 04:44:08 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-07-10 04:44:08 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\landing_page/home.php
INFO - 2025-07-10 04:44:08 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-07-10 04:44:08 --> Final output sent to browser
DEBUG - 2025-07-10 04:44:08 --> Total execution time: 0.0499
INFO - 2025-07-10 04:44:14 --> Config Class Initialized
INFO - 2025-07-10 04:44:14 --> Hooks Class Initialized
DEBUG - 2025-07-10 04:44:14 --> UTF-8 Support Enabled
INFO - 2025-07-10 04:44:14 --> Utf8 Class Initialized
INFO - 2025-07-10 04:44:14 --> URI Class Initialized
INFO - 2025-07-10 04:44:14 --> Router Class Initialized
INFO - 2025-07-10 04:44:14 --> Output Class Initialized
INFO - 2025-07-10 04:44:14 --> Security Class Initialized
DEBUG - 2025-07-10 04:44:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-10 04:44:14 --> Input Class Initialized
INFO - 2025-07-10 04:44:14 --> Language Class Initialized
INFO - 2025-07-10 04:44:14 --> Loader Class Initialized
INFO - 2025-07-10 04:44:14 --> Helper loaded: url_helper
INFO - 2025-07-10 04:44:14 --> Helper loaded: form_helper
INFO - 2025-07-10 04:44:14 --> Database Driver Class Initialized
DEBUG - 2025-07-10 04:44:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-10 04:44:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-10 04:44:14 --> Controller Class Initialized
INFO - 2025-07-10 04:44:14 --> Model "User_model" initialized
INFO - 2025-07-10 04:44:14 --> Model "Progress_model" initialized
INFO - 2025-07-10 04:44:14 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-10 04:44:14 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-10 04:44:14 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/dashboard.php
INFO - 2025-07-10 04:44:14 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-10 04:44:14 --> Final output sent to browser
DEBUG - 2025-07-10 04:44:14 --> Total execution time: 0.4416
INFO - 2025-07-10 04:44:19 --> Config Class Initialized
INFO - 2025-07-10 04:44:19 --> Hooks Class Initialized
DEBUG - 2025-07-10 04:44:19 --> UTF-8 Support Enabled
INFO - 2025-07-10 04:44:19 --> Utf8 Class Initialized
INFO - 2025-07-10 04:44:19 --> URI Class Initialized
INFO - 2025-07-10 04:44:19 --> Router Class Initialized
INFO - 2025-07-10 04:44:19 --> Output Class Initialized
INFO - 2025-07-10 04:44:19 --> Security Class Initialized
DEBUG - 2025-07-10 04:44:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-10 04:44:19 --> Input Class Initialized
INFO - 2025-07-10 04:44:19 --> Language Class Initialized
INFO - 2025-07-10 04:44:19 --> Loader Class Initialized
INFO - 2025-07-10 04:44:19 --> Helper loaded: url_helper
INFO - 2025-07-10 04:44:19 --> Helper loaded: form_helper
INFO - 2025-07-10 04:44:19 --> Database Driver Class Initialized
DEBUG - 2025-07-10 04:44:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-10 04:44:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-10 04:44:19 --> Controller Class Initialized
INFO - 2025-07-10 04:44:19 --> Model "Olahraga_model" initialized
INFO - 2025-07-10 04:44:19 --> Model "User_model" initialized
INFO - 2025-07-10 04:44:19 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-10 04:44:19 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-10 04:44:19 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-07-10 04:44:19 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-10 04:44:19 --> Final output sent to browser
DEBUG - 2025-07-10 04:44:19 --> Total execution time: 0.1305
INFO - 2025-07-10 04:44:22 --> Config Class Initialized
INFO - 2025-07-10 04:44:22 --> Hooks Class Initialized
DEBUG - 2025-07-10 04:44:22 --> UTF-8 Support Enabled
INFO - 2025-07-10 04:44:22 --> Utf8 Class Initialized
INFO - 2025-07-10 04:44:22 --> URI Class Initialized
INFO - 2025-07-10 04:44:22 --> Router Class Initialized
INFO - 2025-07-10 04:44:22 --> Output Class Initialized
INFO - 2025-07-10 04:44:22 --> Security Class Initialized
DEBUG - 2025-07-10 04:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-10 04:44:22 --> Input Class Initialized
INFO - 2025-07-10 04:44:22 --> Language Class Initialized
INFO - 2025-07-10 04:44:22 --> Loader Class Initialized
INFO - 2025-07-10 04:44:22 --> Helper loaded: url_helper
INFO - 2025-07-10 04:44:22 --> Helper loaded: form_helper
INFO - 2025-07-10 04:44:22 --> Database Driver Class Initialized
DEBUG - 2025-07-10 04:44:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-10 04:44:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-10 04:44:22 --> Controller Class Initialized
INFO - 2025-07-10 04:44:22 --> Model "Olahraga_model" initialized
INFO - 2025-07-10 04:44:22 --> Model "User_model" initialized
INFO - 2025-07-10 04:44:22 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-10 04:44:22 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-10 04:44:22 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/level.php
INFO - 2025-07-10 04:44:22 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-10 04:44:22 --> Final output sent to browser
DEBUG - 2025-07-10 04:44:22 --> Total execution time: 0.0608
INFO - 2025-07-10 04:45:01 --> Config Class Initialized
INFO - 2025-07-10 04:45:01 --> Hooks Class Initialized
DEBUG - 2025-07-10 04:45:01 --> UTF-8 Support Enabled
INFO - 2025-07-10 04:45:01 --> Utf8 Class Initialized
INFO - 2025-07-10 04:45:01 --> URI Class Initialized
INFO - 2025-07-10 04:45:01 --> Router Class Initialized
INFO - 2025-07-10 04:45:01 --> Output Class Initialized
INFO - 2025-07-10 04:45:01 --> Security Class Initialized
DEBUG - 2025-07-10 04:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-10 04:45:01 --> Input Class Initialized
INFO - 2025-07-10 04:45:01 --> Language Class Initialized
INFO - 2025-07-10 04:45:01 --> Loader Class Initialized
INFO - 2025-07-10 04:45:01 --> Helper loaded: url_helper
INFO - 2025-07-10 04:45:01 --> Helper loaded: form_helper
INFO - 2025-07-10 04:45:01 --> Database Driver Class Initialized
DEBUG - 2025-07-10 04:45:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-10 04:45:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-10 04:45:01 --> Controller Class Initialized
INFO - 2025-07-10 04:45:01 --> Model "Olahraga_model" initialized
INFO - 2025-07-10 04:45:01 --> Model "User_model" initialized
INFO - 2025-07-10 04:45:01 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-10 04:45:01 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-10 04:45:01 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/level.php
INFO - 2025-07-10 04:45:01 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-10 04:45:01 --> Final output sent to browser
DEBUG - 2025-07-10 04:45:01 --> Total execution time: 0.0443
INFO - 2025-07-10 04:45:03 --> Config Class Initialized
INFO - 2025-07-10 04:45:03 --> Hooks Class Initialized
DEBUG - 2025-07-10 04:45:03 --> UTF-8 Support Enabled
INFO - 2025-07-10 04:45:03 --> Utf8 Class Initialized
INFO - 2025-07-10 04:45:03 --> URI Class Initialized
INFO - 2025-07-10 04:45:03 --> Router Class Initialized
INFO - 2025-07-10 04:45:03 --> Output Class Initialized
INFO - 2025-07-10 04:45:03 --> Security Class Initialized
DEBUG - 2025-07-10 04:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-10 04:45:03 --> Input Class Initialized
INFO - 2025-07-10 04:45:03 --> Language Class Initialized
INFO - 2025-07-10 04:45:03 --> Loader Class Initialized
INFO - 2025-07-10 04:45:03 --> Helper loaded: url_helper
INFO - 2025-07-10 04:45:03 --> Helper loaded: form_helper
INFO - 2025-07-10 04:45:03 --> Database Driver Class Initialized
DEBUG - 2025-07-10 04:45:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-10 04:45:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-10 04:45:03 --> Controller Class Initialized
INFO - 2025-07-10 04:45:03 --> Model "Olahraga_model" initialized
INFO - 2025-07-10 04:45:03 --> Model "User_model" initialized
INFO - 2025-07-10 04:45:03 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-10 04:45:03 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-10 04:45:03 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-07-10 04:45:03 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-10 04:45:03 --> Final output sent to browser
DEBUG - 2025-07-10 04:45:03 --> Total execution time: 0.1082
INFO - 2025-07-10 04:45:25 --> Config Class Initialized
INFO - 2025-07-10 04:45:25 --> Hooks Class Initialized
DEBUG - 2025-07-10 04:45:25 --> UTF-8 Support Enabled
INFO - 2025-07-10 04:45:25 --> Utf8 Class Initialized
INFO - 2025-07-10 04:45:25 --> URI Class Initialized
INFO - 2025-07-10 04:45:25 --> Router Class Initialized
INFO - 2025-07-10 04:45:25 --> Output Class Initialized
INFO - 2025-07-10 04:45:25 --> Security Class Initialized
DEBUG - 2025-07-10 04:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-10 04:45:25 --> Input Class Initialized
INFO - 2025-07-10 04:45:25 --> Language Class Initialized
INFO - 2025-07-10 04:45:26 --> Loader Class Initialized
INFO - 2025-07-10 04:45:26 --> Helper loaded: url_helper
INFO - 2025-07-10 04:45:26 --> Helper loaded: form_helper
INFO - 2025-07-10 04:45:26 --> Database Driver Class Initialized
DEBUG - 2025-07-10 04:45:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-10 04:45:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-10 04:45:26 --> Controller Class Initialized
INFO - 2025-07-10 04:45:26 --> Model "Progress_model" initialized
INFO - 2025-07-10 04:45:26 --> Model "Olahraga_model" initialized
INFO - 2025-07-10 04:45:26 --> Model "User_model" initialized
INFO - 2025-07-10 04:45:26 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-10 04:45:26 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-10 04:45:26 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/progress_view.php
INFO - 2025-07-10 04:45:26 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-10 04:45:26 --> Final output sent to browser
DEBUG - 2025-07-10 04:45:26 --> Total execution time: 0.1268
INFO - 2025-07-10 04:45:26 --> Config Class Initialized
INFO - 2025-07-10 04:45:26 --> Hooks Class Initialized
DEBUG - 2025-07-10 04:45:26 --> UTF-8 Support Enabled
INFO - 2025-07-10 04:45:26 --> Utf8 Class Initialized
INFO - 2025-07-10 04:45:26 --> URI Class Initialized
INFO - 2025-07-10 04:45:26 --> Router Class Initialized
INFO - 2025-07-10 04:45:26 --> Output Class Initialized
INFO - 2025-07-10 04:45:26 --> Security Class Initialized
DEBUG - 2025-07-10 04:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-10 04:45:26 --> Input Class Initialized
INFO - 2025-07-10 04:45:26 --> Language Class Initialized
INFO - 2025-07-10 04:45:26 --> Loader Class Initialized
INFO - 2025-07-10 04:45:26 --> Helper loaded: url_helper
INFO - 2025-07-10 04:45:26 --> Helper loaded: form_helper
INFO - 2025-07-10 04:45:26 --> Database Driver Class Initialized
DEBUG - 2025-07-10 04:45:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-10 04:45:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-10 04:45:26 --> Controller Class Initialized
INFO - 2025-07-10 04:45:26 --> Model "Progress_model" initialized
INFO - 2025-07-10 04:45:26 --> Model "Olahraga_model" initialized
INFO - 2025-07-10 04:45:26 --> Model "User_model" initialized
INFO - 2025-07-10 04:45:26 --> Final output sent to browser
DEBUG - 2025-07-10 04:45:26 --> Total execution time: 0.0586
INFO - 2025-07-10 04:45:29 --> Config Class Initialized
INFO - 2025-07-10 04:45:29 --> Hooks Class Initialized
DEBUG - 2025-07-10 04:45:29 --> UTF-8 Support Enabled
INFO - 2025-07-10 04:45:29 --> Utf8 Class Initialized
INFO - 2025-07-10 04:45:29 --> URI Class Initialized
INFO - 2025-07-10 04:45:29 --> Router Class Initialized
INFO - 2025-07-10 04:45:29 --> Output Class Initialized
INFO - 2025-07-10 04:45:29 --> Security Class Initialized
DEBUG - 2025-07-10 04:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-10 04:45:29 --> Input Class Initialized
INFO - 2025-07-10 04:45:29 --> Language Class Initialized
INFO - 2025-07-10 04:45:29 --> Loader Class Initialized
INFO - 2025-07-10 04:45:29 --> Helper loaded: url_helper
INFO - 2025-07-10 04:45:29 --> Helper loaded: form_helper
INFO - 2025-07-10 04:45:29 --> Database Driver Class Initialized
DEBUG - 2025-07-10 04:45:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-10 04:45:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-10 04:45:29 --> Controller Class Initialized
INFO - 2025-07-10 04:45:29 --> Model "User_model" initialized
INFO - 2025-07-10 04:45:29 --> Model "Progress_model" initialized
INFO - 2025-07-10 04:45:29 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-10 04:45:29 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-10 04:45:29 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/guide.php
INFO - 2025-07-10 04:45:29 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-10 04:45:29 --> Final output sent to browser
DEBUG - 2025-07-10 04:45:29 --> Total execution time: 0.0698
INFO - 2025-07-10 04:45:33 --> Config Class Initialized
INFO - 2025-07-10 04:45:33 --> Hooks Class Initialized
DEBUG - 2025-07-10 04:45:33 --> UTF-8 Support Enabled
INFO - 2025-07-10 04:45:33 --> Utf8 Class Initialized
INFO - 2025-07-10 04:45:33 --> URI Class Initialized
INFO - 2025-07-10 04:45:33 --> Router Class Initialized
INFO - 2025-07-10 04:45:33 --> Output Class Initialized
INFO - 2025-07-10 04:45:33 --> Security Class Initialized
DEBUG - 2025-07-10 04:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-10 04:45:33 --> Input Class Initialized
INFO - 2025-07-10 04:45:33 --> Language Class Initialized
INFO - 2025-07-10 04:45:33 --> Loader Class Initialized
INFO - 2025-07-10 04:45:33 --> Helper loaded: url_helper
INFO - 2025-07-10 04:45:33 --> Helper loaded: form_helper
INFO - 2025-07-10 04:45:33 --> Database Driver Class Initialized
DEBUG - 2025-07-10 04:45:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-10 04:45:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-10 04:45:33 --> Controller Class Initialized
INFO - 2025-07-10 04:45:33 --> Model "Progress_model" initialized
INFO - 2025-07-10 04:45:33 --> Model "Olahraga_model" initialized
INFO - 2025-07-10 04:45:33 --> Model "User_model" initialized
INFO - 2025-07-10 04:45:33 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-10 04:45:33 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-10 04:45:33 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/progress_view.php
INFO - 2025-07-10 04:45:33 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-10 04:45:33 --> Final output sent to browser
DEBUG - 2025-07-10 04:45:33 --> Total execution time: 0.0541
INFO - 2025-07-10 04:45:34 --> Config Class Initialized
INFO - 2025-07-10 04:45:34 --> Hooks Class Initialized
DEBUG - 2025-07-10 04:45:34 --> UTF-8 Support Enabled
INFO - 2025-07-10 04:45:34 --> Utf8 Class Initialized
INFO - 2025-07-10 04:45:34 --> URI Class Initialized
INFO - 2025-07-10 04:45:34 --> Router Class Initialized
INFO - 2025-07-10 04:45:34 --> Output Class Initialized
INFO - 2025-07-10 04:45:34 --> Security Class Initialized
DEBUG - 2025-07-10 04:45:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-10 04:45:34 --> Input Class Initialized
INFO - 2025-07-10 04:45:34 --> Language Class Initialized
INFO - 2025-07-10 04:45:34 --> Loader Class Initialized
INFO - 2025-07-10 04:45:34 --> Helper loaded: url_helper
INFO - 2025-07-10 04:45:34 --> Helper loaded: form_helper
INFO - 2025-07-10 04:45:34 --> Database Driver Class Initialized
DEBUG - 2025-07-10 04:45:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-10 04:45:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-10 04:45:34 --> Controller Class Initialized
INFO - 2025-07-10 04:45:34 --> Model "Progress_model" initialized
INFO - 2025-07-10 04:45:34 --> Model "Olahraga_model" initialized
INFO - 2025-07-10 04:45:34 --> Model "User_model" initialized
INFO - 2025-07-10 04:45:34 --> Final output sent to browser
DEBUG - 2025-07-10 04:45:34 --> Total execution time: 0.0591
INFO - 2025-07-10 04:45:35 --> Config Class Initialized
INFO - 2025-07-10 04:45:35 --> Hooks Class Initialized
DEBUG - 2025-07-10 04:45:35 --> UTF-8 Support Enabled
INFO - 2025-07-10 04:45:35 --> Utf8 Class Initialized
INFO - 2025-07-10 04:45:35 --> URI Class Initialized
INFO - 2025-07-10 04:45:35 --> Router Class Initialized
INFO - 2025-07-10 04:45:35 --> Output Class Initialized
INFO - 2025-07-10 04:45:35 --> Security Class Initialized
DEBUG - 2025-07-10 04:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-10 04:45:35 --> Input Class Initialized
INFO - 2025-07-10 04:45:35 --> Language Class Initialized
INFO - 2025-07-10 04:45:35 --> Loader Class Initialized
INFO - 2025-07-10 04:45:35 --> Helper loaded: url_helper
INFO - 2025-07-10 04:45:35 --> Helper loaded: form_helper
INFO - 2025-07-10 04:45:35 --> Database Driver Class Initialized
DEBUG - 2025-07-10 04:45:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-10 04:45:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-10 04:45:35 --> Controller Class Initialized
INFO - 2025-07-10 04:45:35 --> Model "Olahraga_model" initialized
INFO - 2025-07-10 04:45:35 --> Model "User_model" initialized
INFO - 2025-07-10 04:45:35 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-10 04:45:35 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-10 04:45:35 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-07-10 04:45:35 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-10 04:45:35 --> Final output sent to browser
DEBUG - 2025-07-10 04:45:35 --> Total execution time: 0.0562
INFO - 2025-07-10 04:45:38 --> Config Class Initialized
INFO - 2025-07-10 04:45:38 --> Hooks Class Initialized
DEBUG - 2025-07-10 04:45:38 --> UTF-8 Support Enabled
INFO - 2025-07-10 04:45:38 --> Utf8 Class Initialized
INFO - 2025-07-10 04:45:38 --> URI Class Initialized
INFO - 2025-07-10 04:45:38 --> Router Class Initialized
INFO - 2025-07-10 04:45:38 --> Output Class Initialized
INFO - 2025-07-10 04:45:38 --> Security Class Initialized
DEBUG - 2025-07-10 04:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-10 04:45:38 --> Input Class Initialized
INFO - 2025-07-10 04:45:38 --> Language Class Initialized
INFO - 2025-07-10 04:45:38 --> Loader Class Initialized
INFO - 2025-07-10 04:45:38 --> Helper loaded: url_helper
INFO - 2025-07-10 04:45:38 --> Helper loaded: form_helper
INFO - 2025-07-10 04:45:38 --> Database Driver Class Initialized
DEBUG - 2025-07-10 04:45:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-10 04:45:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-10 04:45:38 --> Controller Class Initialized
INFO - 2025-07-10 04:45:38 --> Model "User_model" initialized
INFO - 2025-07-10 04:45:38 --> Model "Community_model" initialized
INFO - 2025-07-10 04:45:38 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-10 04:45:38 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-10 04:45:38 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/community.php
INFO - 2025-07-10 04:45:38 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-10 04:45:38 --> Final output sent to browser
DEBUG - 2025-07-10 04:45:38 --> Total execution time: 0.1843
INFO - 2025-07-10 04:45:48 --> Config Class Initialized
INFO - 2025-07-10 04:45:48 --> Hooks Class Initialized
DEBUG - 2025-07-10 04:45:48 --> UTF-8 Support Enabled
INFO - 2025-07-10 04:45:48 --> Utf8 Class Initialized
INFO - 2025-07-10 04:45:48 --> URI Class Initialized
INFO - 2025-07-10 04:45:48 --> Router Class Initialized
INFO - 2025-07-10 04:45:48 --> Output Class Initialized
INFO - 2025-07-10 04:45:48 --> Security Class Initialized
DEBUG - 2025-07-10 04:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-10 04:45:48 --> Input Class Initialized
INFO - 2025-07-10 04:45:48 --> Language Class Initialized
INFO - 2025-07-10 04:45:48 --> Loader Class Initialized
INFO - 2025-07-10 04:45:48 --> Helper loaded: url_helper
INFO - 2025-07-10 04:45:48 --> Helper loaded: form_helper
INFO - 2025-07-10 04:45:48 --> Database Driver Class Initialized
DEBUG - 2025-07-10 04:45:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-10 04:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-10 04:45:48 --> Controller Class Initialized
INFO - 2025-07-10 04:45:48 --> Model "User_model" initialized
INFO - 2025-07-10 04:45:48 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-10 04:45:48 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-10 04:45:48 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/profile.php
INFO - 2025-07-10 04:45:48 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-10 04:45:48 --> Final output sent to browser
DEBUG - 2025-07-10 04:45:48 --> Total execution time: 0.1119
INFO - 2025-07-10 04:45:51 --> Config Class Initialized
INFO - 2025-07-10 04:45:51 --> Hooks Class Initialized
DEBUG - 2025-07-10 04:45:51 --> UTF-8 Support Enabled
INFO - 2025-07-10 04:45:51 --> Utf8 Class Initialized
INFO - 2025-07-10 04:45:51 --> URI Class Initialized
INFO - 2025-07-10 04:45:51 --> Router Class Initialized
INFO - 2025-07-10 04:45:51 --> Output Class Initialized
INFO - 2025-07-10 04:45:51 --> Security Class Initialized
DEBUG - 2025-07-10 04:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-10 04:45:51 --> Input Class Initialized
INFO - 2025-07-10 04:45:51 --> Language Class Initialized
INFO - 2025-07-10 04:45:51 --> Loader Class Initialized
INFO - 2025-07-10 04:45:51 --> Helper loaded: url_helper
INFO - 2025-07-10 04:45:51 --> Helper loaded: form_helper
INFO - 2025-07-10 04:45:51 --> Database Driver Class Initialized
DEBUG - 2025-07-10 04:45:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-10 04:45:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-10 04:45:51 --> Controller Class Initialized
INFO - 2025-07-10 04:45:51 --> Model "User_model" initialized
INFO - 2025-07-10 04:45:51 --> Form Validation Class Initialized
INFO - 2025-07-10 04:45:51 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-10 04:45:51 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-10 04:45:51 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/edit_profile.php
INFO - 2025-07-10 04:45:51 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-10 04:45:51 --> Final output sent to browser
DEBUG - 2025-07-10 04:45:51 --> Total execution time: 0.0843
INFO - 2025-07-10 04:45:54 --> Config Class Initialized
INFO - 2025-07-10 04:45:54 --> Hooks Class Initialized
DEBUG - 2025-07-10 04:45:54 --> UTF-8 Support Enabled
INFO - 2025-07-10 04:45:54 --> Utf8 Class Initialized
INFO - 2025-07-10 04:45:54 --> URI Class Initialized
INFO - 2025-07-10 04:45:54 --> Router Class Initialized
INFO - 2025-07-10 04:45:54 --> Output Class Initialized
INFO - 2025-07-10 04:45:54 --> Security Class Initialized
DEBUG - 2025-07-10 04:45:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-10 04:45:54 --> Input Class Initialized
INFO - 2025-07-10 04:45:54 --> Language Class Initialized
INFO - 2025-07-10 04:45:54 --> Loader Class Initialized
INFO - 2025-07-10 04:45:54 --> Helper loaded: url_helper
INFO - 2025-07-10 04:45:54 --> Helper loaded: form_helper
INFO - 2025-07-10 04:45:54 --> Database Driver Class Initialized
DEBUG - 2025-07-10 04:45:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-10 04:45:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-10 04:45:54 --> Controller Class Initialized
INFO - 2025-07-10 04:45:54 --> Model "Olahraga_model" initialized
INFO - 2025-07-10 04:45:54 --> Model "User_model" initialized
INFO - 2025-07-10 04:45:54 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-10 04:45:54 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-10 04:45:54 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-07-10 04:45:54 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-10 04:45:54 --> Final output sent to browser
DEBUG - 2025-07-10 04:45:54 --> Total execution time: 0.0579
INFO - 2025-07-10 04:45:57 --> Config Class Initialized
INFO - 2025-07-10 04:45:57 --> Hooks Class Initialized
DEBUG - 2025-07-10 04:45:57 --> UTF-8 Support Enabled
INFO - 2025-07-10 04:45:57 --> Utf8 Class Initialized
INFO - 2025-07-10 04:45:57 --> URI Class Initialized
INFO - 2025-07-10 04:45:57 --> Router Class Initialized
INFO - 2025-07-10 04:45:57 --> Output Class Initialized
INFO - 2025-07-10 04:45:57 --> Security Class Initialized
DEBUG - 2025-07-10 04:45:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-10 04:45:57 --> Input Class Initialized
INFO - 2025-07-10 04:45:57 --> Language Class Initialized
INFO - 2025-07-10 04:45:57 --> Loader Class Initialized
INFO - 2025-07-10 04:45:57 --> Helper loaded: url_helper
INFO - 2025-07-10 04:45:57 --> Helper loaded: form_helper
INFO - 2025-07-10 04:45:57 --> Database Driver Class Initialized
DEBUG - 2025-07-10 04:45:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-10 04:45:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-10 04:45:57 --> Controller Class Initialized
INFO - 2025-07-10 04:45:57 --> Model "Olahraga_model" initialized
INFO - 2025-07-10 04:45:57 --> Model "User_model" initialized
INFO - 2025-07-10 04:45:57 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-10 04:45:57 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-10 04:45:57 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/level.php
INFO - 2025-07-10 04:45:57 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-10 04:45:57 --> Final output sent to browser
DEBUG - 2025-07-10 04:45:57 --> Total execution time: 0.0588
INFO - 2025-07-10 04:45:58 --> Config Class Initialized
INFO - 2025-07-10 04:45:58 --> Hooks Class Initialized
DEBUG - 2025-07-10 04:45:58 --> UTF-8 Support Enabled
INFO - 2025-07-10 04:45:58 --> Utf8 Class Initialized
INFO - 2025-07-10 04:45:58 --> URI Class Initialized
INFO - 2025-07-10 04:45:58 --> Router Class Initialized
INFO - 2025-07-10 04:45:58 --> Output Class Initialized
INFO - 2025-07-10 04:45:58 --> Security Class Initialized
DEBUG - 2025-07-10 04:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-10 04:45:58 --> Input Class Initialized
INFO - 2025-07-10 04:45:58 --> Language Class Initialized
INFO - 2025-07-10 04:45:58 --> Loader Class Initialized
INFO - 2025-07-10 04:45:58 --> Helper loaded: url_helper
INFO - 2025-07-10 04:45:58 --> Helper loaded: form_helper
INFO - 2025-07-10 04:45:58 --> Database Driver Class Initialized
DEBUG - 2025-07-10 04:45:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-10 04:45:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-10 04:45:58 --> Controller Class Initialized
INFO - 2025-07-10 04:45:58 --> Model "Olahraga_model" initialized
INFO - 2025-07-10 04:45:58 --> Model "User_model" initialized
INFO - 2025-07-10 04:45:58 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-10 04:45:58 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-10 04:45:58 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-07-10 04:45:58 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-10 04:45:58 --> Final output sent to browser
DEBUG - 2025-07-10 04:45:58 --> Total execution time: 0.0589
INFO - 2025-07-10 05:56:07 --> Config Class Initialized
INFO - 2025-07-10 05:56:07 --> Hooks Class Initialized
DEBUG - 2025-07-10 05:56:08 --> UTF-8 Support Enabled
INFO - 2025-07-10 05:56:08 --> Utf8 Class Initialized
INFO - 2025-07-10 05:56:08 --> URI Class Initialized
INFO - 2025-07-10 05:56:08 --> Router Class Initialized
INFO - 2025-07-10 05:56:08 --> Output Class Initialized
INFO - 2025-07-10 05:56:08 --> Security Class Initialized
DEBUG - 2025-07-10 05:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-10 05:56:08 --> Input Class Initialized
INFO - 2025-07-10 05:56:08 --> Language Class Initialized
INFO - 2025-07-10 05:56:09 --> Loader Class Initialized
INFO - 2025-07-10 05:56:09 --> Helper loaded: url_helper
INFO - 2025-07-10 05:56:09 --> Helper loaded: form_helper
INFO - 2025-07-10 05:56:09 --> Database Driver Class Initialized
DEBUG - 2025-07-10 05:56:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-10 05:56:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-10 05:56:10 --> Controller Class Initialized
INFO - 2025-07-10 05:56:10 --> Model "User_model" initialized
INFO - 2025-07-10 05:56:10 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-07-10 05:56:10 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\landing_page/home.php
INFO - 2025-07-10 05:56:10 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-07-10 05:56:10 --> Final output sent to browser
DEBUG - 2025-07-10 05:56:10 --> Total execution time: 3.2590
INFO - 2025-07-10 05:56:16 --> Config Class Initialized
INFO - 2025-07-10 05:56:16 --> Hooks Class Initialized
DEBUG - 2025-07-10 05:56:16 --> UTF-8 Support Enabled
INFO - 2025-07-10 05:56:16 --> Utf8 Class Initialized
INFO - 2025-07-10 05:56:16 --> URI Class Initialized
INFO - 2025-07-10 05:56:16 --> Router Class Initialized
INFO - 2025-07-10 05:56:16 --> Output Class Initialized
INFO - 2025-07-10 05:56:16 --> Security Class Initialized
DEBUG - 2025-07-10 05:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-10 05:56:16 --> Input Class Initialized
INFO - 2025-07-10 05:56:16 --> Language Class Initialized
INFO - 2025-07-10 05:56:16 --> Loader Class Initialized
INFO - 2025-07-10 05:56:16 --> Helper loaded: url_helper
INFO - 2025-07-10 05:56:16 --> Helper loaded: form_helper
INFO - 2025-07-10 05:56:16 --> Database Driver Class Initialized
DEBUG - 2025-07-10 05:56:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-10 05:56:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-10 05:56:16 --> Controller Class Initialized
INFO - 2025-07-10 05:56:17 --> Model "User_model" initialized
INFO - 2025-07-10 05:56:17 --> Form Validation Class Initialized
INFO - 2025-07-10 05:56:17 --> Config Class Initialized
INFO - 2025-07-10 05:56:17 --> Hooks Class Initialized
DEBUG - 2025-07-10 05:56:17 --> UTF-8 Support Enabled
INFO - 2025-07-10 05:56:17 --> Utf8 Class Initialized
INFO - 2025-07-10 05:56:17 --> URI Class Initialized
INFO - 2025-07-10 05:56:17 --> Router Class Initialized
INFO - 2025-07-10 05:56:17 --> Output Class Initialized
INFO - 2025-07-10 05:56:17 --> Security Class Initialized
DEBUG - 2025-07-10 05:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-10 05:56:17 --> Input Class Initialized
INFO - 2025-07-10 05:56:17 --> Language Class Initialized
INFO - 2025-07-10 05:56:17 --> Loader Class Initialized
INFO - 2025-07-10 05:56:17 --> Helper loaded: url_helper
INFO - 2025-07-10 05:56:17 --> Helper loaded: form_helper
INFO - 2025-07-10 05:56:17 --> Database Driver Class Initialized
DEBUG - 2025-07-10 05:56:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-10 05:56:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-10 05:56:17 --> Controller Class Initialized
INFO - 2025-07-10 05:56:17 --> Model "User_model" initialized
INFO - 2025-07-10 05:56:17 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-07-10 05:56:17 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\landing_page/home.php
INFO - 2025-07-10 05:56:17 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-07-10 05:56:17 --> Final output sent to browser
DEBUG - 2025-07-10 05:56:17 --> Total execution time: 0.0460
INFO - 2025-07-10 06:28:42 --> Config Class Initialized
INFO - 2025-07-10 06:28:42 --> Hooks Class Initialized
DEBUG - 2025-07-10 06:28:42 --> UTF-8 Support Enabled
INFO - 2025-07-10 06:28:42 --> Utf8 Class Initialized
INFO - 2025-07-10 06:28:42 --> URI Class Initialized
INFO - 2025-07-10 06:28:42 --> Router Class Initialized
INFO - 2025-07-10 06:28:42 --> Output Class Initialized
INFO - 2025-07-10 06:28:43 --> Security Class Initialized
DEBUG - 2025-07-10 06:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-10 06:28:43 --> Input Class Initialized
INFO - 2025-07-10 06:28:43 --> Language Class Initialized
INFO - 2025-07-10 06:28:43 --> Loader Class Initialized
INFO - 2025-07-10 06:28:43 --> Helper loaded: url_helper
INFO - 2025-07-10 06:28:43 --> Helper loaded: form_helper
INFO - 2025-07-10 06:28:43 --> Database Driver Class Initialized
DEBUG - 2025-07-10 06:28:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-10 06:28:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-10 06:28:43 --> Controller Class Initialized
INFO - 2025-07-10 06:28:43 --> Model "User_model" initialized
INFO - 2025-07-10 06:28:43 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-07-10 06:28:43 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\landing_page/artikel.php
INFO - 2025-07-10 06:28:43 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-07-10 06:28:43 --> Final output sent to browser
DEBUG - 2025-07-10 06:28:43 --> Total execution time: 1.4829
INFO - 2025-07-10 06:29:08 --> Config Class Initialized
INFO - 2025-07-10 06:29:08 --> Hooks Class Initialized
DEBUG - 2025-07-10 06:29:08 --> UTF-8 Support Enabled
INFO - 2025-07-10 06:29:08 --> Utf8 Class Initialized
INFO - 2025-07-10 06:29:08 --> URI Class Initialized
INFO - 2025-07-10 06:29:08 --> Router Class Initialized
INFO - 2025-07-10 06:29:08 --> Output Class Initialized
INFO - 2025-07-10 06:29:08 --> Security Class Initialized
DEBUG - 2025-07-10 06:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-10 06:29:08 --> Input Class Initialized
INFO - 2025-07-10 06:29:08 --> Language Class Initialized
INFO - 2025-07-10 06:29:08 --> Loader Class Initialized
INFO - 2025-07-10 06:29:08 --> Helper loaded: url_helper
INFO - 2025-07-10 06:29:08 --> Helper loaded: form_helper
INFO - 2025-07-10 06:29:08 --> Database Driver Class Initialized
DEBUG - 2025-07-10 06:29:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-10 06:29:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-10 06:29:08 --> Controller Class Initialized
INFO - 2025-07-10 06:29:08 --> Model "User_model" initialized
INFO - 2025-07-10 06:29:08 --> Form Validation Class Initialized
INFO - 2025-07-10 06:29:08 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\auth/login.php
INFO - 2025-07-10 06:29:08 --> Final output sent to browser
DEBUG - 2025-07-10 06:29:08 --> Total execution time: 0.2201
INFO - 2025-07-10 06:29:14 --> Config Class Initialized
INFO - 2025-07-10 06:29:14 --> Hooks Class Initialized
DEBUG - 2025-07-10 06:29:14 --> UTF-8 Support Enabled
INFO - 2025-07-10 06:29:14 --> Utf8 Class Initialized
INFO - 2025-07-10 06:29:14 --> URI Class Initialized
INFO - 2025-07-10 06:29:14 --> Router Class Initialized
INFO - 2025-07-10 06:29:14 --> Output Class Initialized
INFO - 2025-07-10 06:29:14 --> Security Class Initialized
DEBUG - 2025-07-10 06:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-10 06:29:14 --> Input Class Initialized
INFO - 2025-07-10 06:29:14 --> Language Class Initialized
INFO - 2025-07-10 06:29:14 --> Loader Class Initialized
INFO - 2025-07-10 06:29:14 --> Helper loaded: url_helper
INFO - 2025-07-10 06:29:14 --> Helper loaded: form_helper
INFO - 2025-07-10 06:29:14 --> Database Driver Class Initialized
DEBUG - 2025-07-10 06:29:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-10 06:29:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-10 06:29:14 --> Controller Class Initialized
INFO - 2025-07-10 06:29:14 --> Model "User_model" initialized
INFO - 2025-07-10 06:29:14 --> Form Validation Class Initialized
DEBUG - 2025-07-10 06:29:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-07-10 06:29:14 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\auth/register.php
INFO - 2025-07-10 06:29:14 --> Final output sent to browser
DEBUG - 2025-07-10 06:29:14 --> Total execution time: 0.0928
INFO - 2025-07-10 06:29:22 --> Config Class Initialized
INFO - 2025-07-10 06:29:22 --> Hooks Class Initialized
DEBUG - 2025-07-10 06:29:22 --> UTF-8 Support Enabled
INFO - 2025-07-10 06:29:22 --> Utf8 Class Initialized
INFO - 2025-07-10 06:29:22 --> URI Class Initialized
INFO - 2025-07-10 06:29:22 --> Router Class Initialized
INFO - 2025-07-10 06:29:22 --> Output Class Initialized
INFO - 2025-07-10 06:29:22 --> Security Class Initialized
DEBUG - 2025-07-10 06:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-10 06:29:22 --> Input Class Initialized
INFO - 2025-07-10 06:29:22 --> Language Class Initialized
INFO - 2025-07-10 06:29:22 --> Loader Class Initialized
INFO - 2025-07-10 06:29:22 --> Helper loaded: url_helper
INFO - 2025-07-10 06:29:22 --> Helper loaded: form_helper
INFO - 2025-07-10 06:29:22 --> Database Driver Class Initialized
DEBUG - 2025-07-10 06:29:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-10 06:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-10 06:29:22 --> Controller Class Initialized
INFO - 2025-07-10 06:29:22 --> Model "User_model" initialized
INFO - 2025-07-10 06:29:22 --> Form Validation Class Initialized
INFO - 2025-07-10 06:29:22 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\auth/login.php
INFO - 2025-07-10 06:29:22 --> Final output sent to browser
DEBUG - 2025-07-10 06:29:22 --> Total execution time: 0.0379
INFO - 2025-07-10 06:29:29 --> Config Class Initialized
INFO - 2025-07-10 06:29:29 --> Hooks Class Initialized
DEBUG - 2025-07-10 06:29:29 --> UTF-8 Support Enabled
INFO - 2025-07-10 06:29:29 --> Utf8 Class Initialized
INFO - 2025-07-10 06:29:29 --> URI Class Initialized
INFO - 2025-07-10 06:29:29 --> Router Class Initialized
INFO - 2025-07-10 06:29:29 --> Output Class Initialized
INFO - 2025-07-10 06:29:29 --> Security Class Initialized
DEBUG - 2025-07-10 06:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-10 06:29:29 --> Input Class Initialized
INFO - 2025-07-10 06:29:29 --> Language Class Initialized
INFO - 2025-07-10 06:29:29 --> Loader Class Initialized
INFO - 2025-07-10 06:29:29 --> Helper loaded: url_helper
INFO - 2025-07-10 06:29:29 --> Helper loaded: form_helper
INFO - 2025-07-10 06:29:29 --> Database Driver Class Initialized
DEBUG - 2025-07-10 06:29:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-10 06:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-10 06:29:29 --> Controller Class Initialized
INFO - 2025-07-10 06:29:29 --> Model "User_model" initialized
INFO - 2025-07-10 06:29:29 --> Form Validation Class Initialized
INFO - 2025-07-10 06:29:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-07-10 06:29:29 --> Config Class Initialized
INFO - 2025-07-10 06:29:29 --> Hooks Class Initialized
DEBUG - 2025-07-10 06:29:29 --> UTF-8 Support Enabled
INFO - 2025-07-10 06:29:29 --> Utf8 Class Initialized
INFO - 2025-07-10 06:29:29 --> URI Class Initialized
INFO - 2025-07-10 06:29:29 --> Router Class Initialized
INFO - 2025-07-10 06:29:29 --> Output Class Initialized
INFO - 2025-07-10 06:29:29 --> Security Class Initialized
DEBUG - 2025-07-10 06:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-10 06:29:29 --> Input Class Initialized
INFO - 2025-07-10 06:29:29 --> Language Class Initialized
INFO - 2025-07-10 06:29:29 --> Loader Class Initialized
INFO - 2025-07-10 06:29:29 --> Helper loaded: url_helper
INFO - 2025-07-10 06:29:29 --> Helper loaded: form_helper
INFO - 2025-07-10 06:29:29 --> Database Driver Class Initialized
DEBUG - 2025-07-10 06:29:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-10 06:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-10 06:29:29 --> Controller Class Initialized
INFO - 2025-07-10 06:29:29 --> Model "User_model" initialized
INFO - 2025-07-10 06:29:29 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-07-10 06:29:29 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\landing_page/home.php
INFO - 2025-07-10 06:29:29 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-07-10 06:29:29 --> Final output sent to browser
DEBUG - 2025-07-10 06:29:29 --> Total execution time: 0.0558
INFO - 2025-07-10 06:29:34 --> Config Class Initialized
INFO - 2025-07-10 06:29:34 --> Hooks Class Initialized
DEBUG - 2025-07-10 06:29:34 --> UTF-8 Support Enabled
INFO - 2025-07-10 06:29:34 --> Utf8 Class Initialized
INFO - 2025-07-10 06:29:34 --> URI Class Initialized
INFO - 2025-07-10 06:29:34 --> Router Class Initialized
INFO - 2025-07-10 06:29:34 --> Output Class Initialized
INFO - 2025-07-10 06:29:34 --> Security Class Initialized
DEBUG - 2025-07-10 06:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-10 06:29:34 --> Input Class Initialized
INFO - 2025-07-10 06:29:34 --> Language Class Initialized
INFO - 2025-07-10 06:29:34 --> Loader Class Initialized
INFO - 2025-07-10 06:29:34 --> Helper loaded: url_helper
INFO - 2025-07-10 06:29:34 --> Helper loaded: form_helper
INFO - 2025-07-10 06:29:34 --> Database Driver Class Initialized
DEBUG - 2025-07-10 06:29:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-10 06:29:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-10 06:29:34 --> Controller Class Initialized
INFO - 2025-07-10 06:29:34 --> Model "User_model" initialized
INFO - 2025-07-10 06:29:34 --> Model "Progress_model" initialized
INFO - 2025-07-10 06:29:34 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-10 06:29:34 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-10 06:29:34 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/dashboard.php
INFO - 2025-07-10 06:29:34 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-10 06:29:34 --> Final output sent to browser
DEBUG - 2025-07-10 06:29:34 --> Total execution time: 0.3147
INFO - 2025-07-10 06:29:47 --> Config Class Initialized
INFO - 2025-07-10 06:29:47 --> Hooks Class Initialized
DEBUG - 2025-07-10 06:29:47 --> UTF-8 Support Enabled
INFO - 2025-07-10 06:29:47 --> Utf8 Class Initialized
INFO - 2025-07-10 06:29:47 --> URI Class Initialized
INFO - 2025-07-10 06:29:47 --> Router Class Initialized
INFO - 2025-07-10 06:29:47 --> Output Class Initialized
INFO - 2025-07-10 06:29:47 --> Security Class Initialized
DEBUG - 2025-07-10 06:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-10 06:29:47 --> Input Class Initialized
INFO - 2025-07-10 06:29:47 --> Language Class Initialized
INFO - 2025-07-10 06:29:47 --> Loader Class Initialized
INFO - 2025-07-10 06:29:47 --> Helper loaded: url_helper
INFO - 2025-07-10 06:29:47 --> Helper loaded: form_helper
INFO - 2025-07-10 06:29:47 --> Database Driver Class Initialized
DEBUG - 2025-07-10 06:29:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-10 06:29:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-10 06:29:47 --> Controller Class Initialized
INFO - 2025-07-10 06:29:47 --> Model "User_model" initialized
INFO - 2025-07-10 06:29:47 --> Model "Progress_model" initialized
INFO - 2025-07-10 06:29:47 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-10 06:29:47 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-10 06:29:47 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/dashboard.php
INFO - 2025-07-10 06:29:47 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-10 06:29:47 --> Final output sent to browser
DEBUG - 2025-07-10 06:29:47 --> Total execution time: 0.0534
INFO - 2025-07-10 06:29:49 --> Config Class Initialized
INFO - 2025-07-10 06:29:49 --> Hooks Class Initialized
DEBUG - 2025-07-10 06:29:49 --> UTF-8 Support Enabled
INFO - 2025-07-10 06:29:49 --> Utf8 Class Initialized
INFO - 2025-07-10 06:29:49 --> URI Class Initialized
INFO - 2025-07-10 06:29:49 --> Router Class Initialized
INFO - 2025-07-10 06:29:49 --> Output Class Initialized
INFO - 2025-07-10 06:29:49 --> Security Class Initialized
DEBUG - 2025-07-10 06:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-10 06:29:49 --> Input Class Initialized
INFO - 2025-07-10 06:29:49 --> Language Class Initialized
INFO - 2025-07-10 06:29:49 --> Loader Class Initialized
INFO - 2025-07-10 06:29:49 --> Helper loaded: url_helper
INFO - 2025-07-10 06:29:49 --> Helper loaded: form_helper
INFO - 2025-07-10 06:29:49 --> Database Driver Class Initialized
DEBUG - 2025-07-10 06:29:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-10 06:29:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-10 06:29:49 --> Controller Class Initialized
INFO - 2025-07-10 06:29:49 --> Model "User_model" initialized
INFO - 2025-07-10 06:29:49 --> Model "Progress_model" initialized
INFO - 2025-07-10 06:29:49 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-10 06:29:49 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-10 06:29:49 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/dashboard.php
INFO - 2025-07-10 06:29:49 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-10 06:29:49 --> Final output sent to browser
DEBUG - 2025-07-10 06:29:49 --> Total execution time: 0.0922
INFO - 2025-07-10 06:30:21 --> Config Class Initialized
INFO - 2025-07-10 06:30:21 --> Hooks Class Initialized
DEBUG - 2025-07-10 06:30:21 --> UTF-8 Support Enabled
INFO - 2025-07-10 06:30:21 --> Utf8 Class Initialized
INFO - 2025-07-10 06:30:21 --> URI Class Initialized
INFO - 2025-07-10 06:30:21 --> Router Class Initialized
INFO - 2025-07-10 06:30:21 --> Output Class Initialized
INFO - 2025-07-10 06:30:21 --> Security Class Initialized
DEBUG - 2025-07-10 06:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-10 06:30:21 --> Input Class Initialized
INFO - 2025-07-10 06:30:21 --> Language Class Initialized
INFO - 2025-07-10 06:30:21 --> Loader Class Initialized
INFO - 2025-07-10 06:30:21 --> Helper loaded: url_helper
INFO - 2025-07-10 06:30:21 --> Helper loaded: form_helper
INFO - 2025-07-10 06:30:21 --> Database Driver Class Initialized
DEBUG - 2025-07-10 06:30:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-10 06:30:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-10 06:30:21 --> Controller Class Initialized
INFO - 2025-07-10 06:30:21 --> Model "User_model" initialized
INFO - 2025-07-10 06:30:21 --> Model "Progress_model" initialized
INFO - 2025-07-10 06:30:21 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-10 06:30:21 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-10 06:30:21 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/guide.php
INFO - 2025-07-10 06:30:21 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-10 06:30:21 --> Final output sent to browser
DEBUG - 2025-07-10 06:30:21 --> Total execution time: 0.0592
INFO - 2025-07-10 06:30:38 --> Config Class Initialized
INFO - 2025-07-10 06:30:38 --> Hooks Class Initialized
DEBUG - 2025-07-10 06:30:38 --> UTF-8 Support Enabled
INFO - 2025-07-10 06:30:38 --> Utf8 Class Initialized
INFO - 2025-07-10 06:30:38 --> URI Class Initialized
INFO - 2025-07-10 06:30:38 --> Router Class Initialized
INFO - 2025-07-10 06:30:38 --> Output Class Initialized
INFO - 2025-07-10 06:30:38 --> Security Class Initialized
DEBUG - 2025-07-10 06:30:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-10 06:30:38 --> Input Class Initialized
INFO - 2025-07-10 06:30:38 --> Language Class Initialized
INFO - 2025-07-10 06:30:38 --> Loader Class Initialized
INFO - 2025-07-10 06:30:38 --> Helper loaded: url_helper
INFO - 2025-07-10 06:30:38 --> Helper loaded: form_helper
INFO - 2025-07-10 06:30:38 --> Database Driver Class Initialized
DEBUG - 2025-07-10 06:30:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-10 06:30:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-10 06:30:38 --> Controller Class Initialized
INFO - 2025-07-10 06:30:38 --> Model "Progress_model" initialized
INFO - 2025-07-10 06:30:39 --> Model "Olahraga_model" initialized
INFO - 2025-07-10 06:30:39 --> Model "User_model" initialized
INFO - 2025-07-10 06:30:39 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-10 06:30:39 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-10 06:30:39 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/progress_view.php
INFO - 2025-07-10 06:30:39 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-10 06:30:39 --> Final output sent to browser
DEBUG - 2025-07-10 06:30:39 --> Total execution time: 0.1465
INFO - 2025-07-10 06:30:39 --> Config Class Initialized
INFO - 2025-07-10 06:30:39 --> Hooks Class Initialized
DEBUG - 2025-07-10 06:30:39 --> UTF-8 Support Enabled
INFO - 2025-07-10 06:30:39 --> Utf8 Class Initialized
INFO - 2025-07-10 06:30:39 --> URI Class Initialized
INFO - 2025-07-10 06:30:39 --> Router Class Initialized
INFO - 2025-07-10 06:30:39 --> Output Class Initialized
INFO - 2025-07-10 06:30:39 --> Security Class Initialized
DEBUG - 2025-07-10 06:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-10 06:30:39 --> Input Class Initialized
INFO - 2025-07-10 06:30:39 --> Language Class Initialized
INFO - 2025-07-10 06:30:39 --> Loader Class Initialized
INFO - 2025-07-10 06:30:39 --> Helper loaded: url_helper
INFO - 2025-07-10 06:30:39 --> Helper loaded: form_helper
INFO - 2025-07-10 06:30:39 --> Database Driver Class Initialized
DEBUG - 2025-07-10 06:30:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-10 06:30:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-10 06:30:39 --> Controller Class Initialized
INFO - 2025-07-10 06:30:39 --> Model "Progress_model" initialized
INFO - 2025-07-10 06:30:39 --> Model "Olahraga_model" initialized
INFO - 2025-07-10 06:30:39 --> Model "User_model" initialized
INFO - 2025-07-10 06:30:39 --> Final output sent to browser
DEBUG - 2025-07-10 06:30:39 --> Total execution time: 0.0427
INFO - 2025-07-10 06:30:45 --> Config Class Initialized
INFO - 2025-07-10 06:30:45 --> Hooks Class Initialized
DEBUG - 2025-07-10 06:30:45 --> UTF-8 Support Enabled
INFO - 2025-07-10 06:30:45 --> Utf8 Class Initialized
INFO - 2025-07-10 06:30:45 --> URI Class Initialized
INFO - 2025-07-10 06:30:45 --> Router Class Initialized
INFO - 2025-07-10 06:30:45 --> Output Class Initialized
INFO - 2025-07-10 06:30:45 --> Security Class Initialized
DEBUG - 2025-07-10 06:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-10 06:30:45 --> Input Class Initialized
INFO - 2025-07-10 06:30:45 --> Language Class Initialized
INFO - 2025-07-10 06:30:45 --> Loader Class Initialized
INFO - 2025-07-10 06:30:45 --> Helper loaded: url_helper
INFO - 2025-07-10 06:30:45 --> Helper loaded: form_helper
INFO - 2025-07-10 06:30:45 --> Database Driver Class Initialized
DEBUG - 2025-07-10 06:30:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-10 06:30:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-10 06:30:45 --> Controller Class Initialized
INFO - 2025-07-10 06:30:45 --> Model "Progress_model" initialized
INFO - 2025-07-10 06:30:45 --> Model "Olahraga_model" initialized
INFO - 2025-07-10 06:30:45 --> Model "User_model" initialized
INFO - 2025-07-10 06:30:45 --> Final output sent to browser
DEBUG - 2025-07-10 06:30:45 --> Total execution time: 0.0461
INFO - 2025-07-10 06:30:55 --> Config Class Initialized
INFO - 2025-07-10 06:30:55 --> Hooks Class Initialized
DEBUG - 2025-07-10 06:30:55 --> UTF-8 Support Enabled
INFO - 2025-07-10 06:30:55 --> Utf8 Class Initialized
INFO - 2025-07-10 06:30:55 --> URI Class Initialized
INFO - 2025-07-10 06:30:55 --> Router Class Initialized
INFO - 2025-07-10 06:30:55 --> Output Class Initialized
INFO - 2025-07-10 06:30:55 --> Security Class Initialized
DEBUG - 2025-07-10 06:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-10 06:30:55 --> Input Class Initialized
INFO - 2025-07-10 06:30:55 --> Language Class Initialized
INFO - 2025-07-10 06:30:55 --> Loader Class Initialized
INFO - 2025-07-10 06:30:55 --> Helper loaded: url_helper
INFO - 2025-07-10 06:30:55 --> Helper loaded: form_helper
INFO - 2025-07-10 06:30:55 --> Database Driver Class Initialized
DEBUG - 2025-07-10 06:30:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-10 06:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-10 06:30:55 --> Controller Class Initialized
INFO - 2025-07-10 06:30:55 --> Model "Progress_model" initialized
INFO - 2025-07-10 06:30:55 --> Model "Olahraga_model" initialized
INFO - 2025-07-10 06:30:55 --> Model "User_model" initialized
INFO - 2025-07-10 06:30:55 --> Final output sent to browser
DEBUG - 2025-07-10 06:30:55 --> Total execution time: 0.0470
INFO - 2025-07-10 06:30:58 --> Config Class Initialized
INFO - 2025-07-10 06:30:58 --> Hooks Class Initialized
DEBUG - 2025-07-10 06:30:58 --> UTF-8 Support Enabled
INFO - 2025-07-10 06:30:58 --> Utf8 Class Initialized
INFO - 2025-07-10 06:30:58 --> URI Class Initialized
INFO - 2025-07-10 06:30:58 --> Router Class Initialized
INFO - 2025-07-10 06:30:58 --> Output Class Initialized
INFO - 2025-07-10 06:30:58 --> Security Class Initialized
DEBUG - 2025-07-10 06:30:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-10 06:30:58 --> Input Class Initialized
INFO - 2025-07-10 06:30:58 --> Language Class Initialized
INFO - 2025-07-10 06:30:58 --> Loader Class Initialized
INFO - 2025-07-10 06:30:58 --> Helper loaded: url_helper
INFO - 2025-07-10 06:30:58 --> Helper loaded: form_helper
INFO - 2025-07-10 06:30:58 --> Database Driver Class Initialized
DEBUG - 2025-07-10 06:30:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-10 06:30:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-10 06:30:58 --> Controller Class Initialized
INFO - 2025-07-10 06:30:58 --> Model "Progress_model" initialized
INFO - 2025-07-10 06:30:58 --> Model "Olahraga_model" initialized
INFO - 2025-07-10 06:30:58 --> Model "User_model" initialized
INFO - 2025-07-10 06:30:58 --> Final output sent to browser
DEBUG - 2025-07-10 06:30:58 --> Total execution time: 0.0409
INFO - 2025-07-10 06:30:59 --> Config Class Initialized
INFO - 2025-07-10 06:30:59 --> Hooks Class Initialized
DEBUG - 2025-07-10 06:30:59 --> UTF-8 Support Enabled
INFO - 2025-07-10 06:30:59 --> Utf8 Class Initialized
INFO - 2025-07-10 06:30:59 --> URI Class Initialized
INFO - 2025-07-10 06:30:59 --> Router Class Initialized
INFO - 2025-07-10 06:30:59 --> Output Class Initialized
INFO - 2025-07-10 06:30:59 --> Security Class Initialized
DEBUG - 2025-07-10 06:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-10 06:30:59 --> Input Class Initialized
INFO - 2025-07-10 06:30:59 --> Language Class Initialized
INFO - 2025-07-10 06:30:59 --> Loader Class Initialized
INFO - 2025-07-10 06:30:59 --> Helper loaded: url_helper
INFO - 2025-07-10 06:30:59 --> Helper loaded: form_helper
INFO - 2025-07-10 06:30:59 --> Database Driver Class Initialized
DEBUG - 2025-07-10 06:30:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-10 06:30:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-10 06:30:59 --> Controller Class Initialized
INFO - 2025-07-10 06:30:59 --> Model "Olahraga_model" initialized
INFO - 2025-07-10 06:30:59 --> Model "User_model" initialized
INFO - 2025-07-10 06:30:59 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-10 06:30:59 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-10 06:30:59 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-07-10 06:30:59 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-10 06:30:59 --> Final output sent to browser
DEBUG - 2025-07-10 06:30:59 --> Total execution time: 0.2600
INFO - 2025-07-10 06:31:07 --> Config Class Initialized
INFO - 2025-07-10 06:31:07 --> Hooks Class Initialized
DEBUG - 2025-07-10 06:31:07 --> UTF-8 Support Enabled
INFO - 2025-07-10 06:31:07 --> Utf8 Class Initialized
INFO - 2025-07-10 06:31:07 --> URI Class Initialized
INFO - 2025-07-10 06:31:07 --> Router Class Initialized
INFO - 2025-07-10 06:31:07 --> Output Class Initialized
INFO - 2025-07-10 06:31:07 --> Security Class Initialized
DEBUG - 2025-07-10 06:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-10 06:31:07 --> Input Class Initialized
INFO - 2025-07-10 06:31:07 --> Language Class Initialized
INFO - 2025-07-10 06:31:07 --> Loader Class Initialized
INFO - 2025-07-10 06:31:07 --> Helper loaded: url_helper
INFO - 2025-07-10 06:31:07 --> Helper loaded: form_helper
INFO - 2025-07-10 06:31:07 --> Database Driver Class Initialized
DEBUG - 2025-07-10 06:31:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-10 06:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-10 06:31:07 --> Controller Class Initialized
INFO - 2025-07-10 06:31:07 --> Model "Olahraga_model" initialized
INFO - 2025-07-10 06:31:07 --> Model "User_model" initialized
INFO - 2025-07-10 06:31:07 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-10 06:31:07 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-10 06:31:07 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/level.php
INFO - 2025-07-10 06:31:07 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-10 06:31:07 --> Final output sent to browser
DEBUG - 2025-07-10 06:31:07 --> Total execution time: 0.0530
INFO - 2025-07-10 06:31:13 --> Config Class Initialized
INFO - 2025-07-10 06:31:13 --> Hooks Class Initialized
DEBUG - 2025-07-10 06:31:13 --> UTF-8 Support Enabled
INFO - 2025-07-10 06:31:13 --> Utf8 Class Initialized
INFO - 2025-07-10 06:31:13 --> URI Class Initialized
INFO - 2025-07-10 06:31:13 --> Router Class Initialized
INFO - 2025-07-10 06:31:13 --> Output Class Initialized
INFO - 2025-07-10 06:31:13 --> Security Class Initialized
DEBUG - 2025-07-10 06:31:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-10 06:31:13 --> Input Class Initialized
INFO - 2025-07-10 06:31:13 --> Language Class Initialized
INFO - 2025-07-10 06:31:13 --> Loader Class Initialized
INFO - 2025-07-10 06:31:13 --> Helper loaded: url_helper
INFO - 2025-07-10 06:31:13 --> Helper loaded: form_helper
INFO - 2025-07-10 06:31:13 --> Database Driver Class Initialized
DEBUG - 2025-07-10 06:31:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-10 06:31:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-10 06:31:13 --> Controller Class Initialized
INFO - 2025-07-10 06:31:13 --> Model "Olahraga_model" initialized
INFO - 2025-07-10 06:31:13 --> Model "User_model" initialized
INFO - 2025-07-10 06:31:13 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-10 06:31:13 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-10 06:31:13 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-07-10 06:31:13 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-10 06:31:13 --> Final output sent to browser
DEBUG - 2025-07-10 06:31:13 --> Total execution time: 0.0630
INFO - 2025-07-10 06:31:17 --> Config Class Initialized
INFO - 2025-07-10 06:31:17 --> Hooks Class Initialized
DEBUG - 2025-07-10 06:31:17 --> UTF-8 Support Enabled
INFO - 2025-07-10 06:31:17 --> Utf8 Class Initialized
INFO - 2025-07-10 06:31:17 --> URI Class Initialized
INFO - 2025-07-10 06:31:17 --> Router Class Initialized
INFO - 2025-07-10 06:31:17 --> Output Class Initialized
INFO - 2025-07-10 06:31:17 --> Security Class Initialized
DEBUG - 2025-07-10 06:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-10 06:31:17 --> Input Class Initialized
INFO - 2025-07-10 06:31:17 --> Language Class Initialized
INFO - 2025-07-10 06:31:17 --> Loader Class Initialized
INFO - 2025-07-10 06:31:17 --> Helper loaded: url_helper
INFO - 2025-07-10 06:31:17 --> Helper loaded: form_helper
INFO - 2025-07-10 06:31:17 --> Database Driver Class Initialized
DEBUG - 2025-07-10 06:31:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-10 06:31:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-10 06:31:17 --> Controller Class Initialized
INFO - 2025-07-10 06:31:17 --> Model "Olahraga_model" initialized
INFO - 2025-07-10 06:31:17 --> Model "User_model" initialized
INFO - 2025-07-10 06:31:17 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-10 06:31:17 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-10 06:31:17 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/start.php
INFO - 2025-07-10 06:31:17 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-10 06:31:17 --> Final output sent to browser
DEBUG - 2025-07-10 06:31:17 --> Total execution time: 0.2995
INFO - 2025-07-10 06:31:40 --> Config Class Initialized
INFO - 2025-07-10 06:31:40 --> Hooks Class Initialized
DEBUG - 2025-07-10 06:31:40 --> UTF-8 Support Enabled
INFO - 2025-07-10 06:31:40 --> Utf8 Class Initialized
INFO - 2025-07-10 06:31:40 --> URI Class Initialized
INFO - 2025-07-10 06:31:40 --> Router Class Initialized
INFO - 2025-07-10 06:31:40 --> Output Class Initialized
INFO - 2025-07-10 06:31:40 --> Security Class Initialized
DEBUG - 2025-07-10 06:31:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-10 06:31:40 --> Input Class Initialized
INFO - 2025-07-10 06:31:40 --> Language Class Initialized
INFO - 2025-07-10 06:31:40 --> Loader Class Initialized
INFO - 2025-07-10 06:31:40 --> Helper loaded: url_helper
INFO - 2025-07-10 06:31:40 --> Helper loaded: form_helper
INFO - 2025-07-10 06:31:40 --> Database Driver Class Initialized
DEBUG - 2025-07-10 06:31:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-10 06:31:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-10 06:31:40 --> Controller Class Initialized
INFO - 2025-07-10 06:31:40 --> Model "Olahraga_model" initialized
INFO - 2025-07-10 06:31:40 --> Model "User_model" initialized
INFO - 2025-07-10 06:31:40 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-10 06:31:40 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-10 06:31:40 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/start.php
INFO - 2025-07-10 06:31:40 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-10 06:31:40 --> Final output sent to browser
DEBUG - 2025-07-10 06:31:40 --> Total execution time: 0.0470
INFO - 2025-07-10 06:31:47 --> Config Class Initialized
INFO - 2025-07-10 06:31:47 --> Hooks Class Initialized
DEBUG - 2025-07-10 06:31:47 --> UTF-8 Support Enabled
INFO - 2025-07-10 06:31:47 --> Utf8 Class Initialized
INFO - 2025-07-10 06:31:47 --> URI Class Initialized
INFO - 2025-07-10 06:31:47 --> Router Class Initialized
INFO - 2025-07-10 06:31:47 --> Output Class Initialized
INFO - 2025-07-10 06:31:47 --> Security Class Initialized
DEBUG - 2025-07-10 06:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-10 06:31:47 --> Input Class Initialized
INFO - 2025-07-10 06:31:47 --> Language Class Initialized
INFO - 2025-07-10 06:31:47 --> Loader Class Initialized
INFO - 2025-07-10 06:31:47 --> Helper loaded: url_helper
INFO - 2025-07-10 06:31:47 --> Helper loaded: form_helper
INFO - 2025-07-10 06:31:47 --> Database Driver Class Initialized
DEBUG - 2025-07-10 06:31:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-10 06:31:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-10 06:31:47 --> Controller Class Initialized
INFO - 2025-07-10 06:31:47 --> Model "Olahraga_model" initialized
INFO - 2025-07-10 06:31:47 --> Model "User_model" initialized
INFO - 2025-07-10 06:31:47 --> Final output sent to browser
DEBUG - 2025-07-10 06:31:47 --> Total execution time: 0.0799
INFO - 2025-07-10 06:31:54 --> Config Class Initialized
INFO - 2025-07-10 06:31:54 --> Hooks Class Initialized
DEBUG - 2025-07-10 06:31:54 --> UTF-8 Support Enabled
INFO - 2025-07-10 06:31:54 --> Utf8 Class Initialized
INFO - 2025-07-10 06:31:54 --> URI Class Initialized
INFO - 2025-07-10 06:31:54 --> Router Class Initialized
INFO - 2025-07-10 06:31:54 --> Output Class Initialized
INFO - 2025-07-10 06:31:54 --> Security Class Initialized
DEBUG - 2025-07-10 06:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-10 06:31:54 --> Input Class Initialized
INFO - 2025-07-10 06:31:54 --> Language Class Initialized
INFO - 2025-07-10 06:31:54 --> Loader Class Initialized
INFO - 2025-07-10 06:31:54 --> Helper loaded: url_helper
INFO - 2025-07-10 06:31:54 --> Helper loaded: form_helper
INFO - 2025-07-10 06:31:54 --> Database Driver Class Initialized
DEBUG - 2025-07-10 06:31:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-10 06:31:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-10 06:31:54 --> Controller Class Initialized
INFO - 2025-07-10 06:31:54 --> Model "User_model" initialized
INFO - 2025-07-10 06:31:54 --> Model "Community_model" initialized
INFO - 2025-07-10 06:31:54 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-10 06:31:54 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-10 06:31:54 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/community.php
INFO - 2025-07-10 06:31:54 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-10 06:31:54 --> Final output sent to browser
DEBUG - 2025-07-10 06:31:54 --> Total execution time: 0.1422
INFO - 2025-07-10 06:32:06 --> Config Class Initialized
INFO - 2025-07-10 06:32:06 --> Hooks Class Initialized
DEBUG - 2025-07-10 06:32:06 --> UTF-8 Support Enabled
INFO - 2025-07-10 06:32:06 --> Utf8 Class Initialized
INFO - 2025-07-10 06:32:06 --> URI Class Initialized
INFO - 2025-07-10 06:32:06 --> Router Class Initialized
INFO - 2025-07-10 06:32:06 --> Output Class Initialized
INFO - 2025-07-10 06:32:06 --> Security Class Initialized
DEBUG - 2025-07-10 06:32:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-10 06:32:06 --> Input Class Initialized
INFO - 2025-07-10 06:32:06 --> Language Class Initialized
INFO - 2025-07-10 06:32:06 --> Loader Class Initialized
INFO - 2025-07-10 06:32:06 --> Helper loaded: url_helper
INFO - 2025-07-10 06:32:06 --> Helper loaded: form_helper
INFO - 2025-07-10 06:32:06 --> Database Driver Class Initialized
DEBUG - 2025-07-10 06:32:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-10 06:32:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-10 06:32:06 --> Controller Class Initialized
INFO - 2025-07-10 06:32:06 --> Model "User_model" initialized
INFO - 2025-07-10 06:32:06 --> Model "Community_model" initialized
INFO - 2025-07-10 06:32:06 --> Config Class Initialized
INFO - 2025-07-10 06:32:06 --> Hooks Class Initialized
DEBUG - 2025-07-10 06:32:06 --> UTF-8 Support Enabled
INFO - 2025-07-10 06:32:06 --> Utf8 Class Initialized
INFO - 2025-07-10 06:32:06 --> URI Class Initialized
INFO - 2025-07-10 06:32:06 --> Router Class Initialized
INFO - 2025-07-10 06:32:06 --> Output Class Initialized
INFO - 2025-07-10 06:32:06 --> Security Class Initialized
DEBUG - 2025-07-10 06:32:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-10 06:32:06 --> Input Class Initialized
INFO - 2025-07-10 06:32:06 --> Language Class Initialized
INFO - 2025-07-10 06:32:06 --> Loader Class Initialized
INFO - 2025-07-10 06:32:06 --> Helper loaded: url_helper
INFO - 2025-07-10 06:32:06 --> Helper loaded: form_helper
INFO - 2025-07-10 06:32:06 --> Database Driver Class Initialized
DEBUG - 2025-07-10 06:32:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-10 06:32:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-10 06:32:06 --> Controller Class Initialized
INFO - 2025-07-10 06:32:06 --> Model "User_model" initialized
INFO - 2025-07-10 06:32:06 --> Model "Community_model" initialized
INFO - 2025-07-10 06:32:06 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-10 06:32:06 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-10 06:32:06 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/community.php
INFO - 2025-07-10 06:32:06 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-10 06:32:06 --> Final output sent to browser
DEBUG - 2025-07-10 06:32:06 --> Total execution time: 0.0596
INFO - 2025-07-10 06:32:21 --> Config Class Initialized
INFO - 2025-07-10 06:32:21 --> Hooks Class Initialized
DEBUG - 2025-07-10 06:32:21 --> UTF-8 Support Enabled
INFO - 2025-07-10 06:32:21 --> Utf8 Class Initialized
INFO - 2025-07-10 06:32:21 --> URI Class Initialized
INFO - 2025-07-10 06:32:21 --> Router Class Initialized
INFO - 2025-07-10 06:32:21 --> Output Class Initialized
INFO - 2025-07-10 06:32:21 --> Security Class Initialized
DEBUG - 2025-07-10 06:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-10 06:32:21 --> Input Class Initialized
INFO - 2025-07-10 06:32:21 --> Language Class Initialized
INFO - 2025-07-10 06:32:21 --> Loader Class Initialized
INFO - 2025-07-10 06:32:21 --> Helper loaded: url_helper
INFO - 2025-07-10 06:32:21 --> Helper loaded: form_helper
INFO - 2025-07-10 06:32:21 --> Database Driver Class Initialized
DEBUG - 2025-07-10 06:32:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-10 06:32:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-10 06:32:21 --> Controller Class Initialized
INFO - 2025-07-10 06:32:21 --> Model "User_model" initialized
INFO - 2025-07-10 06:32:21 --> Model "Community_model" initialized
INFO - 2025-07-10 06:32:21 --> Config Class Initialized
INFO - 2025-07-10 06:32:21 --> Hooks Class Initialized
DEBUG - 2025-07-10 06:32:21 --> UTF-8 Support Enabled
INFO - 2025-07-10 06:32:21 --> Utf8 Class Initialized
INFO - 2025-07-10 06:32:21 --> URI Class Initialized
INFO - 2025-07-10 06:32:21 --> Router Class Initialized
INFO - 2025-07-10 06:32:21 --> Output Class Initialized
INFO - 2025-07-10 06:32:21 --> Security Class Initialized
DEBUG - 2025-07-10 06:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-10 06:32:21 --> Input Class Initialized
INFO - 2025-07-10 06:32:21 --> Language Class Initialized
INFO - 2025-07-10 06:32:21 --> Loader Class Initialized
INFO - 2025-07-10 06:32:21 --> Helper loaded: url_helper
INFO - 2025-07-10 06:32:21 --> Helper loaded: form_helper
INFO - 2025-07-10 06:32:21 --> Database Driver Class Initialized
DEBUG - 2025-07-10 06:32:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-10 06:32:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-10 06:32:21 --> Controller Class Initialized
INFO - 2025-07-10 06:32:21 --> Model "User_model" initialized
INFO - 2025-07-10 06:32:21 --> Model "Community_model" initialized
INFO - 2025-07-10 06:32:21 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-10 06:32:21 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-10 06:32:21 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/community.php
INFO - 2025-07-10 06:32:21 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-10 06:32:21 --> Final output sent to browser
DEBUG - 2025-07-10 06:32:21 --> Total execution time: 0.0538
INFO - 2025-07-10 06:32:29 --> Config Class Initialized
INFO - 2025-07-10 06:32:29 --> Hooks Class Initialized
DEBUG - 2025-07-10 06:32:29 --> UTF-8 Support Enabled
INFO - 2025-07-10 06:32:29 --> Utf8 Class Initialized
INFO - 2025-07-10 06:32:29 --> URI Class Initialized
INFO - 2025-07-10 06:32:29 --> Router Class Initialized
INFO - 2025-07-10 06:32:29 --> Output Class Initialized
INFO - 2025-07-10 06:32:29 --> Security Class Initialized
DEBUG - 2025-07-10 06:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-10 06:32:29 --> Input Class Initialized
INFO - 2025-07-10 06:32:29 --> Language Class Initialized
INFO - 2025-07-10 06:32:29 --> Loader Class Initialized
INFO - 2025-07-10 06:32:29 --> Helper loaded: url_helper
INFO - 2025-07-10 06:32:29 --> Helper loaded: form_helper
INFO - 2025-07-10 06:32:29 --> Database Driver Class Initialized
DEBUG - 2025-07-10 06:32:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-10 06:32:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-10 06:32:29 --> Controller Class Initialized
INFO - 2025-07-10 06:32:29 --> Model "User_model" initialized
INFO - 2025-07-10 06:32:29 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-10 06:32:29 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-10 06:32:29 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/profile.php
INFO - 2025-07-10 06:32:29 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-10 06:32:29 --> Final output sent to browser
DEBUG - 2025-07-10 06:32:29 --> Total execution time: 0.0798
INFO - 2025-07-10 06:32:32 --> Config Class Initialized
INFO - 2025-07-10 06:32:32 --> Hooks Class Initialized
DEBUG - 2025-07-10 06:32:32 --> UTF-8 Support Enabled
INFO - 2025-07-10 06:32:32 --> Utf8 Class Initialized
INFO - 2025-07-10 06:32:32 --> URI Class Initialized
INFO - 2025-07-10 06:32:32 --> Router Class Initialized
INFO - 2025-07-10 06:32:32 --> Output Class Initialized
INFO - 2025-07-10 06:32:32 --> Security Class Initialized
DEBUG - 2025-07-10 06:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-10 06:32:32 --> Input Class Initialized
INFO - 2025-07-10 06:32:32 --> Language Class Initialized
INFO - 2025-07-10 06:32:32 --> Loader Class Initialized
INFO - 2025-07-10 06:32:32 --> Helper loaded: url_helper
INFO - 2025-07-10 06:32:32 --> Helper loaded: form_helper
INFO - 2025-07-10 06:32:32 --> Database Driver Class Initialized
DEBUG - 2025-07-10 06:32:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-10 06:32:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-10 06:32:32 --> Controller Class Initialized
INFO - 2025-07-10 06:32:32 --> Model "User_model" initialized
INFO - 2025-07-10 06:32:32 --> Form Validation Class Initialized
INFO - 2025-07-10 06:32:32 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-10 06:32:32 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-10 06:32:32 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/edit_profile.php
INFO - 2025-07-10 06:32:32 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-10 06:32:32 --> Final output sent to browser
DEBUG - 2025-07-10 06:32:32 --> Total execution time: 0.0569
INFO - 2025-07-10 06:33:00 --> Config Class Initialized
INFO - 2025-07-10 06:33:00 --> Hooks Class Initialized
DEBUG - 2025-07-10 06:33:00 --> UTF-8 Support Enabled
INFO - 2025-07-10 06:33:00 --> Utf8 Class Initialized
INFO - 2025-07-10 06:33:00 --> URI Class Initialized
INFO - 2025-07-10 06:33:00 --> Router Class Initialized
INFO - 2025-07-10 06:33:00 --> Output Class Initialized
INFO - 2025-07-10 06:33:00 --> Security Class Initialized
DEBUG - 2025-07-10 06:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-10 06:33:00 --> Input Class Initialized
INFO - 2025-07-10 06:33:00 --> Language Class Initialized
INFO - 2025-07-10 06:33:00 --> Loader Class Initialized
INFO - 2025-07-10 06:33:00 --> Helper loaded: url_helper
INFO - 2025-07-10 06:33:00 --> Helper loaded: form_helper
INFO - 2025-07-10 06:33:00 --> Database Driver Class Initialized
DEBUG - 2025-07-10 06:33:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-10 06:33:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-10 06:33:00 --> Controller Class Initialized
INFO - 2025-07-10 06:33:00 --> Model "User_model" initialized
INFO - 2025-07-10 06:33:00 --> Form Validation Class Initialized
INFO - 2025-07-10 06:33:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-07-10 06:33:00 --> Config Class Initialized
INFO - 2025-07-10 06:33:00 --> Hooks Class Initialized
DEBUG - 2025-07-10 06:33:00 --> UTF-8 Support Enabled
INFO - 2025-07-10 06:33:00 --> Utf8 Class Initialized
INFO - 2025-07-10 06:33:00 --> URI Class Initialized
INFO - 2025-07-10 06:33:00 --> Router Class Initialized
INFO - 2025-07-10 06:33:00 --> Output Class Initialized
INFO - 2025-07-10 06:33:00 --> Security Class Initialized
DEBUG - 2025-07-10 06:33:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-10 06:33:00 --> Input Class Initialized
INFO - 2025-07-10 06:33:00 --> Language Class Initialized
INFO - 2025-07-10 06:33:00 --> Loader Class Initialized
INFO - 2025-07-10 06:33:00 --> Helper loaded: url_helper
INFO - 2025-07-10 06:33:00 --> Helper loaded: form_helper
INFO - 2025-07-10 06:33:00 --> Database Driver Class Initialized
DEBUG - 2025-07-10 06:33:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-10 06:33:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-10 06:33:00 --> Controller Class Initialized
INFO - 2025-07-10 06:33:00 --> Model "User_model" initialized
INFO - 2025-07-10 06:33:00 --> Model "Progress_model" initialized
INFO - 2025-07-10 06:33:00 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-10 06:33:00 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-10 06:33:00 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/dashboard.php
INFO - 2025-07-10 06:33:00 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-10 06:33:00 --> Final output sent to browser
DEBUG - 2025-07-10 06:33:00 --> Total execution time: 0.0444
INFO - 2025-07-10 06:33:16 --> Config Class Initialized
INFO - 2025-07-10 06:33:16 --> Hooks Class Initialized
DEBUG - 2025-07-10 06:33:16 --> UTF-8 Support Enabled
INFO - 2025-07-10 06:33:16 --> Utf8 Class Initialized
INFO - 2025-07-10 06:33:16 --> URI Class Initialized
INFO - 2025-07-10 06:33:16 --> Router Class Initialized
INFO - 2025-07-10 06:33:16 --> Output Class Initialized
INFO - 2025-07-10 06:33:16 --> Security Class Initialized
DEBUG - 2025-07-10 06:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-10 06:33:16 --> Input Class Initialized
INFO - 2025-07-10 06:33:16 --> Language Class Initialized
INFO - 2025-07-10 06:33:16 --> Loader Class Initialized
INFO - 2025-07-10 06:33:16 --> Helper loaded: url_helper
INFO - 2025-07-10 06:33:16 --> Helper loaded: form_helper
INFO - 2025-07-10 06:33:16 --> Database Driver Class Initialized
DEBUG - 2025-07-10 06:33:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-10 06:33:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-10 06:33:16 --> Controller Class Initialized
INFO - 2025-07-10 06:33:16 --> Model "User_model" initialized
INFO - 2025-07-10 06:33:16 --> Form Validation Class Initialized
INFO - 2025-07-10 06:33:16 --> Config Class Initialized
INFO - 2025-07-10 06:33:16 --> Hooks Class Initialized
DEBUG - 2025-07-10 06:33:16 --> UTF-8 Support Enabled
INFO - 2025-07-10 06:33:16 --> Utf8 Class Initialized
INFO - 2025-07-10 06:33:16 --> URI Class Initialized
INFO - 2025-07-10 06:33:16 --> Router Class Initialized
INFO - 2025-07-10 06:33:16 --> Output Class Initialized
INFO - 2025-07-10 06:33:16 --> Security Class Initialized
DEBUG - 2025-07-10 06:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-10 06:33:16 --> Input Class Initialized
INFO - 2025-07-10 06:33:16 --> Language Class Initialized
INFO - 2025-07-10 06:33:16 --> Loader Class Initialized
INFO - 2025-07-10 06:33:16 --> Helper loaded: url_helper
INFO - 2025-07-10 06:33:16 --> Helper loaded: form_helper
INFO - 2025-07-10 06:33:16 --> Database Driver Class Initialized
DEBUG - 2025-07-10 06:33:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-10 06:33:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-10 06:33:16 --> Controller Class Initialized
INFO - 2025-07-10 06:33:16 --> Model "User_model" initialized
INFO - 2025-07-10 06:33:16 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-07-10 06:33:16 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\landing_page/home.php
INFO - 2025-07-10 06:33:16 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-07-10 06:33:16 --> Final output sent to browser
DEBUG - 2025-07-10 06:33:16 --> Total execution time: 0.0364
INFO - 2025-07-10 06:33:18 --> Config Class Initialized
INFO - 2025-07-10 06:33:18 --> Hooks Class Initialized
DEBUG - 2025-07-10 06:33:18 --> UTF-8 Support Enabled
INFO - 2025-07-10 06:33:18 --> Utf8 Class Initialized
INFO - 2025-07-10 06:33:18 --> URI Class Initialized
INFO - 2025-07-10 06:33:18 --> Router Class Initialized
INFO - 2025-07-10 06:33:18 --> Output Class Initialized
INFO - 2025-07-10 06:33:18 --> Security Class Initialized
DEBUG - 2025-07-10 06:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-10 06:33:18 --> Input Class Initialized
INFO - 2025-07-10 06:33:18 --> Language Class Initialized
INFO - 2025-07-10 06:33:18 --> Loader Class Initialized
INFO - 2025-07-10 06:33:18 --> Helper loaded: url_helper
INFO - 2025-07-10 06:33:18 --> Helper loaded: form_helper
INFO - 2025-07-10 06:33:18 --> Database Driver Class Initialized
DEBUG - 2025-07-10 06:33:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-10 06:33:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-10 06:33:18 --> Controller Class Initialized
INFO - 2025-07-10 06:33:18 --> Model "User_model" initialized
INFO - 2025-07-10 06:33:18 --> Form Validation Class Initialized
INFO - 2025-07-10 06:33:18 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\auth/login.php
INFO - 2025-07-10 06:33:18 --> Final output sent to browser
DEBUG - 2025-07-10 06:33:18 --> Total execution time: 0.0387
INFO - 2025-07-10 06:33:29 --> Config Class Initialized
INFO - 2025-07-10 06:33:29 --> Hooks Class Initialized
DEBUG - 2025-07-10 06:33:29 --> UTF-8 Support Enabled
INFO - 2025-07-10 06:33:29 --> Utf8 Class Initialized
INFO - 2025-07-10 06:33:29 --> URI Class Initialized
INFO - 2025-07-10 06:33:29 --> Router Class Initialized
INFO - 2025-07-10 06:33:29 --> Output Class Initialized
INFO - 2025-07-10 06:33:29 --> Security Class Initialized
DEBUG - 2025-07-10 06:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-10 06:33:29 --> Input Class Initialized
INFO - 2025-07-10 06:33:29 --> Language Class Initialized
INFO - 2025-07-10 06:33:29 --> Loader Class Initialized
INFO - 2025-07-10 06:33:29 --> Helper loaded: url_helper
INFO - 2025-07-10 06:33:29 --> Helper loaded: form_helper
INFO - 2025-07-10 06:33:29 --> Database Driver Class Initialized
DEBUG - 2025-07-10 06:33:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-10 06:33:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-10 06:33:29 --> Controller Class Initialized
INFO - 2025-07-10 06:33:29 --> Model "User_model" initialized
INFO - 2025-07-10 06:33:29 --> Form Validation Class Initialized
INFO - 2025-07-10 06:33:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-07-10 06:33:29 --> Config Class Initialized
INFO - 2025-07-10 06:33:29 --> Hooks Class Initialized
DEBUG - 2025-07-10 06:33:29 --> UTF-8 Support Enabled
INFO - 2025-07-10 06:33:29 --> Utf8 Class Initialized
INFO - 2025-07-10 06:33:29 --> URI Class Initialized
INFO - 2025-07-10 06:33:29 --> Router Class Initialized
INFO - 2025-07-10 06:33:29 --> Output Class Initialized
INFO - 2025-07-10 06:33:29 --> Security Class Initialized
DEBUG - 2025-07-10 06:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-10 06:33:29 --> Input Class Initialized
INFO - 2025-07-10 06:33:29 --> Language Class Initialized
INFO - 2025-07-10 06:33:29 --> Loader Class Initialized
INFO - 2025-07-10 06:33:29 --> Helper loaded: url_helper
INFO - 2025-07-10 06:33:29 --> Helper loaded: form_helper
INFO - 2025-07-10 06:33:29 --> Database Driver Class Initialized
DEBUG - 2025-07-10 06:33:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-10 06:33:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-10 06:33:29 --> Controller Class Initialized
INFO - 2025-07-10 06:33:29 --> Model "User_model" initialized
INFO - 2025-07-10 06:33:29 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-07-10 06:33:29 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\landing_page/home.php
INFO - 2025-07-10 06:33:29 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-07-10 06:33:29 --> Final output sent to browser
DEBUG - 2025-07-10 06:33:29 --> Total execution time: 0.0391
