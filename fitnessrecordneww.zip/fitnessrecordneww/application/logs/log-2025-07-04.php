<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-07-04 15:08:56 --> Config Class Initialized
INFO - 2025-07-04 15:08:56 --> Hooks Class Initialized
DEBUG - 2025-07-04 15:08:56 --> UTF-8 Support Enabled
INFO - 2025-07-04 15:08:56 --> Utf8 Class Initialized
INFO - 2025-07-04 15:08:56 --> URI Class Initialized
DEBUG - 2025-07-04 15:08:56 --> No URI present. Default controller set.
INFO - 2025-07-04 15:08:56 --> Router Class Initialized
INFO - 2025-07-04 15:08:56 --> Output Class Initialized
INFO - 2025-07-04 15:08:56 --> Security Class Initialized
DEBUG - 2025-07-04 15:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-04 15:08:57 --> Input Class Initialized
INFO - 2025-07-04 15:08:57 --> Language Class Initialized
INFO - 2025-07-04 15:08:57 --> Loader Class Initialized
INFO - 2025-07-04 15:08:57 --> Helper loaded: url_helper
INFO - 2025-07-04 15:08:57 --> Helper loaded: form_helper
INFO - 2025-07-04 15:08:57 --> Database Driver Class Initialized
DEBUG - 2025-07-04 15:08:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-04 15:08:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-04 15:08:57 --> Controller Class Initialized
INFO - 2025-07-04 15:08:57 --> Model "User_model" initialized
INFO - 2025-07-04 15:08:57 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-07-04 15:08:57 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\landing_page/home.php
INFO - 2025-07-04 15:08:57 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-07-04 15:08:57 --> Final output sent to browser
DEBUG - 2025-07-04 15:08:57 --> Total execution time: 1.1190
INFO - 2025-07-04 15:09:16 --> Config Class Initialized
INFO - 2025-07-04 15:09:16 --> Hooks Class Initialized
DEBUG - 2025-07-04 15:09:16 --> UTF-8 Support Enabled
INFO - 2025-07-04 15:09:16 --> Utf8 Class Initialized
INFO - 2025-07-04 15:09:16 --> URI Class Initialized
INFO - 2025-07-04 15:09:16 --> Router Class Initialized
INFO - 2025-07-04 15:09:16 --> Output Class Initialized
INFO - 2025-07-04 15:09:16 --> Security Class Initialized
DEBUG - 2025-07-04 15:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-04 15:09:16 --> Input Class Initialized
INFO - 2025-07-04 15:09:16 --> Language Class Initialized
INFO - 2025-07-04 15:09:16 --> Loader Class Initialized
INFO - 2025-07-04 15:09:16 --> Helper loaded: url_helper
INFO - 2025-07-04 15:09:16 --> Helper loaded: form_helper
INFO - 2025-07-04 15:09:16 --> Database Driver Class Initialized
DEBUG - 2025-07-04 15:09:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-04 15:09:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-04 15:09:16 --> Controller Class Initialized
INFO - 2025-07-04 15:09:16 --> Model "User_model" initialized
INFO - 2025-07-04 15:09:16 --> Form Validation Class Initialized
INFO - 2025-07-04 15:09:16 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\auth/login.php
INFO - 2025-07-04 15:09:16 --> Final output sent to browser
DEBUG - 2025-07-04 15:09:16 --> Total execution time: 0.2124
INFO - 2025-07-04 15:09:38 --> Config Class Initialized
INFO - 2025-07-04 15:09:38 --> Hooks Class Initialized
DEBUG - 2025-07-04 15:09:38 --> UTF-8 Support Enabled
INFO - 2025-07-04 15:09:38 --> Utf8 Class Initialized
INFO - 2025-07-04 15:09:38 --> URI Class Initialized
INFO - 2025-07-04 15:09:38 --> Router Class Initialized
INFO - 2025-07-04 15:09:38 --> Output Class Initialized
INFO - 2025-07-04 15:09:38 --> Security Class Initialized
DEBUG - 2025-07-04 15:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-04 15:09:38 --> Input Class Initialized
INFO - 2025-07-04 15:09:38 --> Language Class Initialized
INFO - 2025-07-04 15:09:38 --> Loader Class Initialized
INFO - 2025-07-04 15:09:38 --> Helper loaded: url_helper
INFO - 2025-07-04 15:09:38 --> Helper loaded: form_helper
INFO - 2025-07-04 15:09:38 --> Database Driver Class Initialized
DEBUG - 2025-07-04 15:09:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-04 15:09:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-04 15:09:38 --> Controller Class Initialized
INFO - 2025-07-04 15:09:38 --> Model "User_model" initialized
INFO - 2025-07-04 15:09:38 --> Form Validation Class Initialized
INFO - 2025-07-04 15:09:38 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-07-04 15:09:38 --> Config Class Initialized
INFO - 2025-07-04 15:09:38 --> Hooks Class Initialized
DEBUG - 2025-07-04 15:09:38 --> UTF-8 Support Enabled
INFO - 2025-07-04 15:09:38 --> Utf8 Class Initialized
INFO - 2025-07-04 15:09:38 --> URI Class Initialized
INFO - 2025-07-04 15:09:38 --> Router Class Initialized
INFO - 2025-07-04 15:09:38 --> Output Class Initialized
INFO - 2025-07-04 15:09:38 --> Security Class Initialized
DEBUG - 2025-07-04 15:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-04 15:09:38 --> Input Class Initialized
INFO - 2025-07-04 15:09:38 --> Language Class Initialized
INFO - 2025-07-04 15:09:38 --> Loader Class Initialized
INFO - 2025-07-04 15:09:38 --> Helper loaded: url_helper
INFO - 2025-07-04 15:09:38 --> Helper loaded: form_helper
INFO - 2025-07-04 15:09:38 --> Database Driver Class Initialized
DEBUG - 2025-07-04 15:09:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-04 15:09:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-04 15:09:38 --> Controller Class Initialized
INFO - 2025-07-04 15:09:38 --> Model "User_model" initialized
INFO - 2025-07-04 15:09:38 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-07-04 15:09:38 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\landing_page/home.php
INFO - 2025-07-04 15:09:38 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-07-04 15:09:38 --> Final output sent to browser
DEBUG - 2025-07-04 15:09:38 --> Total execution time: 0.0321
INFO - 2025-07-04 15:09:46 --> Config Class Initialized
INFO - 2025-07-04 15:09:46 --> Hooks Class Initialized
DEBUG - 2025-07-04 15:09:46 --> UTF-8 Support Enabled
INFO - 2025-07-04 15:09:46 --> Utf8 Class Initialized
INFO - 2025-07-04 15:09:46 --> URI Class Initialized
INFO - 2025-07-04 15:09:46 --> Router Class Initialized
INFO - 2025-07-04 15:09:46 --> Output Class Initialized
INFO - 2025-07-04 15:09:46 --> Security Class Initialized
DEBUG - 2025-07-04 15:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-04 15:09:46 --> Input Class Initialized
INFO - 2025-07-04 15:09:46 --> Language Class Initialized
INFO - 2025-07-04 15:09:46 --> Loader Class Initialized
INFO - 2025-07-04 15:09:46 --> Helper loaded: url_helper
INFO - 2025-07-04 15:09:46 --> Helper loaded: form_helper
INFO - 2025-07-04 15:09:46 --> Database Driver Class Initialized
DEBUG - 2025-07-04 15:09:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-04 15:09:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-04 15:09:46 --> Controller Class Initialized
INFO - 2025-07-04 15:09:46 --> Model "User_model" initialized
INFO - 2025-07-04 15:09:46 --> Model "Progress_model" initialized
INFO - 2025-07-04 15:09:46 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-04 15:09:46 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-04 15:09:46 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/dashboard.php
INFO - 2025-07-04 15:09:46 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-04 15:09:46 --> Final output sent to browser
DEBUG - 2025-07-04 15:09:46 --> Total execution time: 0.2228
INFO - 2025-07-04 15:09:50 --> Config Class Initialized
INFO - 2025-07-04 15:09:50 --> Hooks Class Initialized
DEBUG - 2025-07-04 15:09:50 --> UTF-8 Support Enabled
INFO - 2025-07-04 15:09:50 --> Utf8 Class Initialized
INFO - 2025-07-04 15:09:50 --> URI Class Initialized
INFO - 2025-07-04 15:09:50 --> Router Class Initialized
INFO - 2025-07-04 15:09:51 --> Output Class Initialized
INFO - 2025-07-04 15:09:51 --> Security Class Initialized
DEBUG - 2025-07-04 15:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-04 15:09:51 --> Input Class Initialized
INFO - 2025-07-04 15:09:51 --> Language Class Initialized
INFO - 2025-07-04 15:09:51 --> Loader Class Initialized
INFO - 2025-07-04 15:09:51 --> Helper loaded: url_helper
INFO - 2025-07-04 15:09:51 --> Helper loaded: form_helper
INFO - 2025-07-04 15:09:51 --> Database Driver Class Initialized
DEBUG - 2025-07-04 15:09:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-04 15:09:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-04 15:09:51 --> Controller Class Initialized
INFO - 2025-07-04 15:09:51 --> Model "User_model" initialized
INFO - 2025-07-04 15:09:51 --> Model "Progress_model" initialized
INFO - 2025-07-04 15:09:51 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-04 15:09:51 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-04 15:09:51 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/guide.php
INFO - 2025-07-04 15:09:51 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-04 15:09:51 --> Final output sent to browser
DEBUG - 2025-07-04 15:09:51 --> Total execution time: 0.0433
INFO - 2025-07-04 15:09:53 --> Config Class Initialized
INFO - 2025-07-04 15:09:53 --> Hooks Class Initialized
DEBUG - 2025-07-04 15:09:53 --> UTF-8 Support Enabled
INFO - 2025-07-04 15:09:53 --> Utf8 Class Initialized
INFO - 2025-07-04 15:09:53 --> URI Class Initialized
INFO - 2025-07-04 15:09:53 --> Router Class Initialized
INFO - 2025-07-04 15:09:53 --> Output Class Initialized
INFO - 2025-07-04 15:09:53 --> Security Class Initialized
DEBUG - 2025-07-04 15:09:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-04 15:09:53 --> Input Class Initialized
INFO - 2025-07-04 15:09:53 --> Language Class Initialized
INFO - 2025-07-04 15:09:53 --> Loader Class Initialized
INFO - 2025-07-04 15:09:53 --> Helper loaded: url_helper
INFO - 2025-07-04 15:09:53 --> Helper loaded: form_helper
INFO - 2025-07-04 15:09:53 --> Database Driver Class Initialized
DEBUG - 2025-07-04 15:09:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-04 15:09:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-04 15:09:53 --> Controller Class Initialized
INFO - 2025-07-04 15:09:53 --> Model "Progress_model" initialized
INFO - 2025-07-04 15:09:53 --> Model "Olahraga_model" initialized
INFO - 2025-07-04 15:09:53 --> Model "User_model" initialized
INFO - 2025-07-04 15:09:53 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-04 15:09:53 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-04 15:09:53 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/progress_view.php
INFO - 2025-07-04 15:09:53 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-04 15:09:53 --> Final output sent to browser
DEBUG - 2025-07-04 15:09:53 --> Total execution time: 0.0943
INFO - 2025-07-04 15:10:16 --> Config Class Initialized
INFO - 2025-07-04 15:10:16 --> Hooks Class Initialized
DEBUG - 2025-07-04 15:10:16 --> UTF-8 Support Enabled
INFO - 2025-07-04 15:10:16 --> Utf8 Class Initialized
INFO - 2025-07-04 15:10:16 --> URI Class Initialized
INFO - 2025-07-04 15:10:16 --> Router Class Initialized
INFO - 2025-07-04 15:10:16 --> Output Class Initialized
INFO - 2025-07-04 15:10:16 --> Security Class Initialized
DEBUG - 2025-07-04 15:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-04 15:10:16 --> Input Class Initialized
INFO - 2025-07-04 15:10:16 --> Language Class Initialized
INFO - 2025-07-04 15:10:16 --> Loader Class Initialized
INFO - 2025-07-04 15:10:16 --> Helper loaded: url_helper
INFO - 2025-07-04 15:10:16 --> Helper loaded: form_helper
INFO - 2025-07-04 15:10:16 --> Database Driver Class Initialized
DEBUG - 2025-07-04 15:10:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-04 15:10:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-04 15:10:16 --> Controller Class Initialized
INFO - 2025-07-04 15:10:16 --> Model "Progress_model" initialized
INFO - 2025-07-04 15:10:16 --> Model "Olahraga_model" initialized
INFO - 2025-07-04 15:10:16 --> Model "User_model" initialized
INFO - 2025-07-04 15:10:16 --> Final output sent to browser
DEBUG - 2025-07-04 15:10:16 --> Total execution time: 0.0403
INFO - 2025-07-04 15:10:21 --> Config Class Initialized
INFO - 2025-07-04 15:10:21 --> Hooks Class Initialized
DEBUG - 2025-07-04 15:10:21 --> UTF-8 Support Enabled
INFO - 2025-07-04 15:10:21 --> Utf8 Class Initialized
INFO - 2025-07-04 15:10:21 --> URI Class Initialized
INFO - 2025-07-04 15:10:21 --> Router Class Initialized
INFO - 2025-07-04 15:10:21 --> Output Class Initialized
INFO - 2025-07-04 15:10:21 --> Security Class Initialized
DEBUG - 2025-07-04 15:10:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-04 15:10:21 --> Input Class Initialized
INFO - 2025-07-04 15:10:21 --> Language Class Initialized
INFO - 2025-07-04 15:10:21 --> Loader Class Initialized
INFO - 2025-07-04 15:10:21 --> Helper loaded: url_helper
INFO - 2025-07-04 15:10:21 --> Helper loaded: form_helper
INFO - 2025-07-04 15:10:21 --> Database Driver Class Initialized
DEBUG - 2025-07-04 15:10:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-04 15:10:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-04 15:10:21 --> Controller Class Initialized
INFO - 2025-07-04 15:10:21 --> Model "Olahraga_model" initialized
INFO - 2025-07-04 15:10:21 --> Model "User_model" initialized
INFO - 2025-07-04 15:10:21 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-04 15:10:21 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-04 15:10:21 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-07-04 15:10:21 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-04 15:10:21 --> Final output sent to browser
DEBUG - 2025-07-04 15:10:21 --> Total execution time: 0.0625
INFO - 2025-07-04 15:10:42 --> Config Class Initialized
INFO - 2025-07-04 15:10:42 --> Hooks Class Initialized
DEBUG - 2025-07-04 15:10:42 --> UTF-8 Support Enabled
INFO - 2025-07-04 15:10:42 --> Utf8 Class Initialized
INFO - 2025-07-04 15:10:42 --> URI Class Initialized
INFO - 2025-07-04 15:10:42 --> Router Class Initialized
INFO - 2025-07-04 15:10:42 --> Output Class Initialized
INFO - 2025-07-04 15:10:42 --> Security Class Initialized
DEBUG - 2025-07-04 15:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-04 15:10:42 --> Input Class Initialized
INFO - 2025-07-04 15:10:42 --> Language Class Initialized
INFO - 2025-07-04 15:10:42 --> Loader Class Initialized
INFO - 2025-07-04 15:10:42 --> Helper loaded: url_helper
INFO - 2025-07-04 15:10:42 --> Helper loaded: form_helper
INFO - 2025-07-04 15:10:42 --> Database Driver Class Initialized
DEBUG - 2025-07-04 15:10:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-04 15:10:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-04 15:10:42 --> Controller Class Initialized
INFO - 2025-07-04 15:10:42 --> Model "Olahraga_model" initialized
INFO - 2025-07-04 15:10:42 --> Model "User_model" initialized
INFO - 2025-07-04 15:10:42 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-04 15:10:42 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-04 15:10:42 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/level.php
INFO - 2025-07-04 15:10:42 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-04 15:10:42 --> Final output sent to browser
DEBUG - 2025-07-04 15:10:42 --> Total execution time: 0.0497
INFO - 2025-07-04 15:10:52 --> Config Class Initialized
INFO - 2025-07-04 15:10:52 --> Hooks Class Initialized
DEBUG - 2025-07-04 15:10:52 --> UTF-8 Support Enabled
INFO - 2025-07-04 15:10:52 --> Utf8 Class Initialized
INFO - 2025-07-04 15:10:52 --> URI Class Initialized
INFO - 2025-07-04 15:10:52 --> Router Class Initialized
INFO - 2025-07-04 15:10:52 --> Output Class Initialized
INFO - 2025-07-04 15:10:52 --> Security Class Initialized
DEBUG - 2025-07-04 15:10:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-04 15:10:52 --> Input Class Initialized
INFO - 2025-07-04 15:10:52 --> Language Class Initialized
INFO - 2025-07-04 15:10:52 --> Loader Class Initialized
INFO - 2025-07-04 15:10:52 --> Helper loaded: url_helper
INFO - 2025-07-04 15:10:52 --> Helper loaded: form_helper
INFO - 2025-07-04 15:10:52 --> Database Driver Class Initialized
DEBUG - 2025-07-04 15:10:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-04 15:10:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-04 15:10:52 --> Controller Class Initialized
INFO - 2025-07-04 15:10:52 --> Model "Olahraga_model" initialized
INFO - 2025-07-04 15:10:52 --> Model "User_model" initialized
INFO - 2025-07-04 15:10:52 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-04 15:10:52 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-04 15:10:52 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-07-04 15:10:52 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-04 15:10:52 --> Final output sent to browser
DEBUG - 2025-07-04 15:10:52 --> Total execution time: 0.0628
INFO - 2025-07-04 15:11:01 --> Config Class Initialized
INFO - 2025-07-04 15:11:01 --> Hooks Class Initialized
DEBUG - 2025-07-04 15:11:01 --> UTF-8 Support Enabled
INFO - 2025-07-04 15:11:01 --> Utf8 Class Initialized
INFO - 2025-07-04 15:11:01 --> URI Class Initialized
INFO - 2025-07-04 15:11:01 --> Router Class Initialized
INFO - 2025-07-04 15:11:01 --> Output Class Initialized
INFO - 2025-07-04 15:11:01 --> Security Class Initialized
DEBUG - 2025-07-04 15:11:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-04 15:11:01 --> Input Class Initialized
INFO - 2025-07-04 15:11:01 --> Language Class Initialized
INFO - 2025-07-04 15:11:01 --> Loader Class Initialized
INFO - 2025-07-04 15:11:01 --> Helper loaded: url_helper
INFO - 2025-07-04 15:11:01 --> Helper loaded: form_helper
INFO - 2025-07-04 15:11:01 --> Database Driver Class Initialized
DEBUG - 2025-07-04 15:11:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-04 15:11:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-04 15:11:01 --> Controller Class Initialized
INFO - 2025-07-04 15:11:01 --> Model "Olahraga_model" initialized
INFO - 2025-07-04 15:11:01 --> Model "User_model" initialized
INFO - 2025-07-04 15:11:01 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-04 15:11:01 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-04 15:11:01 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/start.php
INFO - 2025-07-04 15:11:01 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-04 15:11:01 --> Final output sent to browser
DEBUG - 2025-07-04 15:11:01 --> Total execution time: 0.0833
INFO - 2025-07-04 15:11:31 --> Config Class Initialized
INFO - 2025-07-04 15:11:31 --> Hooks Class Initialized
DEBUG - 2025-07-04 15:11:31 --> UTF-8 Support Enabled
INFO - 2025-07-04 15:11:31 --> Utf8 Class Initialized
INFO - 2025-07-04 15:11:31 --> URI Class Initialized
INFO - 2025-07-04 15:11:31 --> Router Class Initialized
INFO - 2025-07-04 15:11:31 --> Output Class Initialized
INFO - 2025-07-04 15:11:31 --> Security Class Initialized
DEBUG - 2025-07-04 15:11:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-04 15:11:31 --> Input Class Initialized
INFO - 2025-07-04 15:11:31 --> Language Class Initialized
INFO - 2025-07-04 15:11:31 --> Loader Class Initialized
INFO - 2025-07-04 15:11:31 --> Helper loaded: url_helper
INFO - 2025-07-04 15:11:31 --> Helper loaded: form_helper
INFO - 2025-07-04 15:11:31 --> Database Driver Class Initialized
DEBUG - 2025-07-04 15:11:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-04 15:11:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-04 15:11:31 --> Controller Class Initialized
INFO - 2025-07-04 15:11:31 --> Model "Olahraga_model" initialized
INFO - 2025-07-04 15:11:31 --> Model "User_model" initialized
INFO - 2025-07-04 15:11:31 --> Final output sent to browser
DEBUG - 2025-07-04 15:11:31 --> Total execution time: 0.0870
INFO - 2025-07-04 15:11:40 --> Config Class Initialized
INFO - 2025-07-04 15:11:40 --> Hooks Class Initialized
DEBUG - 2025-07-04 15:11:40 --> UTF-8 Support Enabled
INFO - 2025-07-04 15:11:40 --> Utf8 Class Initialized
INFO - 2025-07-04 15:11:40 --> URI Class Initialized
INFO - 2025-07-04 15:11:40 --> Router Class Initialized
INFO - 2025-07-04 15:11:40 --> Output Class Initialized
INFO - 2025-07-04 15:11:40 --> Security Class Initialized
DEBUG - 2025-07-04 15:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-04 15:11:40 --> Input Class Initialized
INFO - 2025-07-04 15:11:40 --> Language Class Initialized
INFO - 2025-07-04 15:11:40 --> Loader Class Initialized
INFO - 2025-07-04 15:11:40 --> Helper loaded: url_helper
INFO - 2025-07-04 15:11:40 --> Helper loaded: form_helper
INFO - 2025-07-04 15:11:40 --> Database Driver Class Initialized
DEBUG - 2025-07-04 15:11:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-04 15:11:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-04 15:11:40 --> Controller Class Initialized
INFO - 2025-07-04 15:11:40 --> Model "Olahraga_model" initialized
INFO - 2025-07-04 15:11:40 --> Model "User_model" initialized
INFO - 2025-07-04 15:11:40 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-04 15:11:40 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-04 15:11:40 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-07-04 15:11:40 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-04 15:11:40 --> Final output sent to browser
DEBUG - 2025-07-04 15:11:40 --> Total execution time: 0.0571
INFO - 2025-07-04 15:29:51 --> Config Class Initialized
INFO - 2025-07-04 15:29:51 --> Hooks Class Initialized
DEBUG - 2025-07-04 15:29:51 --> UTF-8 Support Enabled
INFO - 2025-07-04 15:29:51 --> Utf8 Class Initialized
INFO - 2025-07-04 15:29:51 --> URI Class Initialized
INFO - 2025-07-04 15:29:51 --> Router Class Initialized
INFO - 2025-07-04 15:29:52 --> Output Class Initialized
INFO - 2025-07-04 15:29:52 --> Security Class Initialized
DEBUG - 2025-07-04 15:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-04 15:29:52 --> Input Class Initialized
INFO - 2025-07-04 15:29:52 --> Language Class Initialized
INFO - 2025-07-04 15:29:52 --> Loader Class Initialized
INFO - 2025-07-04 15:29:52 --> Helper loaded: url_helper
INFO - 2025-07-04 15:29:52 --> Helper loaded: form_helper
INFO - 2025-07-04 15:29:52 --> Database Driver Class Initialized
DEBUG - 2025-07-04 15:29:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-04 15:29:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-04 15:29:52 --> Controller Class Initialized
INFO - 2025-07-04 15:29:52 --> Model "Olahraga_model" initialized
INFO - 2025-07-04 15:29:52 --> Model "User_model" initialized
INFO - 2025-07-04 15:29:52 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-04 15:29:52 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-04 15:29:52 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/level.php
INFO - 2025-07-04 15:29:52 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-04 15:29:52 --> Final output sent to browser
DEBUG - 2025-07-04 15:29:52 --> Total execution time: 1.2641
INFO - 2025-07-04 15:29:58 --> Config Class Initialized
INFO - 2025-07-04 15:29:58 --> Hooks Class Initialized
DEBUG - 2025-07-04 15:29:58 --> UTF-8 Support Enabled
INFO - 2025-07-04 15:29:58 --> Utf8 Class Initialized
INFO - 2025-07-04 15:29:58 --> URI Class Initialized
INFO - 2025-07-04 15:29:58 --> Router Class Initialized
INFO - 2025-07-04 15:29:58 --> Output Class Initialized
INFO - 2025-07-04 15:29:58 --> Security Class Initialized
DEBUG - 2025-07-04 15:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-04 15:29:58 --> Input Class Initialized
INFO - 2025-07-04 15:29:58 --> Language Class Initialized
INFO - 2025-07-04 15:29:58 --> Loader Class Initialized
INFO - 2025-07-04 15:29:58 --> Helper loaded: url_helper
INFO - 2025-07-04 15:29:58 --> Helper loaded: form_helper
INFO - 2025-07-04 15:29:58 --> Database Driver Class Initialized
DEBUG - 2025-07-04 15:29:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-04 15:29:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-04 15:29:58 --> Controller Class Initialized
INFO - 2025-07-04 15:29:58 --> Model "Olahraga_model" initialized
INFO - 2025-07-04 15:29:58 --> Model "User_model" initialized
INFO - 2025-07-04 15:29:58 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-04 15:29:58 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-04 15:29:58 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-07-04 15:29:58 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-04 15:29:58 --> Final output sent to browser
DEBUG - 2025-07-04 15:29:58 --> Total execution time: 0.0513
INFO - 2025-07-04 15:30:01 --> Config Class Initialized
INFO - 2025-07-04 15:30:01 --> Hooks Class Initialized
DEBUG - 2025-07-04 15:30:01 --> UTF-8 Support Enabled
INFO - 2025-07-04 15:30:01 --> Utf8 Class Initialized
INFO - 2025-07-04 15:30:01 --> URI Class Initialized
INFO - 2025-07-04 15:30:01 --> Router Class Initialized
INFO - 2025-07-04 15:30:01 --> Output Class Initialized
INFO - 2025-07-04 15:30:01 --> Security Class Initialized
DEBUG - 2025-07-04 15:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-04 15:30:01 --> Input Class Initialized
INFO - 2025-07-04 15:30:01 --> Language Class Initialized
INFO - 2025-07-04 15:30:01 --> Loader Class Initialized
INFO - 2025-07-04 15:30:01 --> Helper loaded: url_helper
INFO - 2025-07-04 15:30:01 --> Helper loaded: form_helper
INFO - 2025-07-04 15:30:01 --> Database Driver Class Initialized
DEBUG - 2025-07-04 15:30:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-04 15:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-04 15:30:01 --> Controller Class Initialized
INFO - 2025-07-04 15:30:01 --> Model "Olahraga_model" initialized
INFO - 2025-07-04 15:30:01 --> Model "User_model" initialized
INFO - 2025-07-04 15:30:01 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-04 15:30:01 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-04 15:30:01 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/start.php
INFO - 2025-07-04 15:30:01 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-04 15:30:01 --> Final output sent to browser
DEBUG - 2025-07-04 15:30:01 --> Total execution time: 0.0731
INFO - 2025-07-04 15:30:25 --> Config Class Initialized
INFO - 2025-07-04 15:30:25 --> Hooks Class Initialized
DEBUG - 2025-07-04 15:30:25 --> UTF-8 Support Enabled
INFO - 2025-07-04 15:30:25 --> Utf8 Class Initialized
INFO - 2025-07-04 15:30:25 --> URI Class Initialized
INFO - 2025-07-04 15:30:25 --> Router Class Initialized
INFO - 2025-07-04 15:30:25 --> Output Class Initialized
INFO - 2025-07-04 15:30:25 --> Security Class Initialized
DEBUG - 2025-07-04 15:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-04 15:30:25 --> Input Class Initialized
INFO - 2025-07-04 15:30:25 --> Language Class Initialized
INFO - 2025-07-04 15:30:25 --> Loader Class Initialized
INFO - 2025-07-04 15:30:25 --> Helper loaded: url_helper
INFO - 2025-07-04 15:30:25 --> Helper loaded: form_helper
INFO - 2025-07-04 15:30:25 --> Database Driver Class Initialized
DEBUG - 2025-07-04 15:30:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-04 15:30:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-04 15:30:25 --> Controller Class Initialized
INFO - 2025-07-04 15:30:25 --> Model "Olahraga_model" initialized
INFO - 2025-07-04 15:30:25 --> Model "User_model" initialized
INFO - 2025-07-04 15:30:25 --> Final output sent to browser
DEBUG - 2025-07-04 15:30:25 --> Total execution time: 0.0584
INFO - 2025-07-04 15:30:29 --> Config Class Initialized
INFO - 2025-07-04 15:30:29 --> Hooks Class Initialized
DEBUG - 2025-07-04 15:30:29 --> UTF-8 Support Enabled
INFO - 2025-07-04 15:30:29 --> Utf8 Class Initialized
INFO - 2025-07-04 15:30:29 --> URI Class Initialized
INFO - 2025-07-04 15:30:29 --> Router Class Initialized
INFO - 2025-07-04 15:30:29 --> Output Class Initialized
INFO - 2025-07-04 15:30:29 --> Security Class Initialized
DEBUG - 2025-07-04 15:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-04 15:30:29 --> Input Class Initialized
INFO - 2025-07-04 15:30:29 --> Language Class Initialized
INFO - 2025-07-04 15:30:29 --> Loader Class Initialized
INFO - 2025-07-04 15:30:29 --> Helper loaded: url_helper
INFO - 2025-07-04 15:30:29 --> Helper loaded: form_helper
INFO - 2025-07-04 15:30:29 --> Database Driver Class Initialized
DEBUG - 2025-07-04 15:30:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-04 15:30:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-04 15:30:29 --> Controller Class Initialized
INFO - 2025-07-04 15:30:29 --> Model "Olahraga_model" initialized
INFO - 2025-07-04 15:30:29 --> Model "User_model" initialized
INFO - 2025-07-04 15:30:29 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-04 15:30:29 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-04 15:30:29 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/level.php
INFO - 2025-07-04 15:30:29 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-04 15:30:29 --> Final output sent to browser
DEBUG - 2025-07-04 15:30:29 --> Total execution time: 0.0427
INFO - 2025-07-04 15:40:27 --> Config Class Initialized
INFO - 2025-07-04 15:40:27 --> Hooks Class Initialized
DEBUG - 2025-07-04 15:40:27 --> UTF-8 Support Enabled
INFO - 2025-07-04 15:40:27 --> Utf8 Class Initialized
INFO - 2025-07-04 15:40:27 --> URI Class Initialized
INFO - 2025-07-04 15:40:27 --> Router Class Initialized
INFO - 2025-07-04 15:40:27 --> Output Class Initialized
INFO - 2025-07-04 15:40:27 --> Security Class Initialized
DEBUG - 2025-07-04 15:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-04 15:40:27 --> Input Class Initialized
INFO - 2025-07-04 15:40:27 --> Language Class Initialized
INFO - 2025-07-04 15:40:27 --> Loader Class Initialized
INFO - 2025-07-04 15:40:27 --> Helper loaded: url_helper
INFO - 2025-07-04 15:40:27 --> Helper loaded: form_helper
INFO - 2025-07-04 15:40:27 --> Database Driver Class Initialized
DEBUG - 2025-07-04 15:40:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-04 15:40:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-04 15:40:27 --> Controller Class Initialized
INFO - 2025-07-04 15:40:27 --> Model "Olahraga_model" initialized
INFO - 2025-07-04 15:40:27 --> Model "User_model" initialized
INFO - 2025-07-04 15:40:27 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-04 15:40:27 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-04 15:40:27 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-07-04 15:40:27 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-04 15:40:27 --> Final output sent to browser
DEBUG - 2025-07-04 15:40:27 --> Total execution time: 0.0597
INFO - 2025-07-04 15:40:30 --> Config Class Initialized
INFO - 2025-07-04 15:40:30 --> Hooks Class Initialized
DEBUG - 2025-07-04 15:40:30 --> UTF-8 Support Enabled
INFO - 2025-07-04 15:40:30 --> Utf8 Class Initialized
INFO - 2025-07-04 15:40:30 --> URI Class Initialized
INFO - 2025-07-04 15:40:30 --> Router Class Initialized
INFO - 2025-07-04 15:40:30 --> Output Class Initialized
INFO - 2025-07-04 15:40:30 --> Security Class Initialized
DEBUG - 2025-07-04 15:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-04 15:40:30 --> Input Class Initialized
INFO - 2025-07-04 15:40:30 --> Language Class Initialized
INFO - 2025-07-04 15:40:30 --> Loader Class Initialized
INFO - 2025-07-04 15:40:30 --> Helper loaded: url_helper
INFO - 2025-07-04 15:40:30 --> Helper loaded: form_helper
INFO - 2025-07-04 15:40:30 --> Database Driver Class Initialized
DEBUG - 2025-07-04 15:40:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-04 15:40:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-04 15:40:30 --> Controller Class Initialized
INFO - 2025-07-04 15:40:30 --> Model "Olahraga_model" initialized
INFO - 2025-07-04 15:40:30 --> Model "User_model" initialized
INFO - 2025-07-04 15:40:30 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-04 15:40:30 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-04 15:40:30 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/level.php
INFO - 2025-07-04 15:40:30 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-04 15:40:30 --> Final output sent to browser
DEBUG - 2025-07-04 15:40:30 --> Total execution time: 0.0439
INFO - 2025-07-04 15:40:30 --> Config Class Initialized
INFO - 2025-07-04 15:40:30 --> Hooks Class Initialized
DEBUG - 2025-07-04 15:40:30 --> UTF-8 Support Enabled
INFO - 2025-07-04 15:40:30 --> Utf8 Class Initialized
INFO - 2025-07-04 15:40:30 --> URI Class Initialized
INFO - 2025-07-04 15:40:30 --> Router Class Initialized
INFO - 2025-07-04 15:40:30 --> Output Class Initialized
INFO - 2025-07-04 15:40:30 --> Security Class Initialized
DEBUG - 2025-07-04 15:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-04 15:40:30 --> Input Class Initialized
INFO - 2025-07-04 15:40:30 --> Language Class Initialized
INFO - 2025-07-04 15:40:30 --> Loader Class Initialized
INFO - 2025-07-04 15:40:30 --> Helper loaded: url_helper
INFO - 2025-07-04 15:40:30 --> Helper loaded: form_helper
INFO - 2025-07-04 15:40:30 --> Database Driver Class Initialized
DEBUG - 2025-07-04 15:40:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-04 15:40:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-04 15:40:30 --> Controller Class Initialized
INFO - 2025-07-04 15:40:30 --> Model "Olahraga_model" initialized
INFO - 2025-07-04 15:40:30 --> Model "User_model" initialized
INFO - 2025-07-04 15:40:31 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-04 15:40:31 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-04 15:40:31 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-07-04 15:40:31 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-04 15:40:31 --> Final output sent to browser
DEBUG - 2025-07-04 15:40:31 --> Total execution time: 0.0537
INFO - 2025-07-04 15:40:32 --> Config Class Initialized
INFO - 2025-07-04 15:40:32 --> Hooks Class Initialized
DEBUG - 2025-07-04 15:40:32 --> UTF-8 Support Enabled
INFO - 2025-07-04 15:40:32 --> Utf8 Class Initialized
INFO - 2025-07-04 15:40:32 --> URI Class Initialized
INFO - 2025-07-04 15:40:32 --> Router Class Initialized
INFO - 2025-07-04 15:40:32 --> Output Class Initialized
INFO - 2025-07-04 15:40:32 --> Security Class Initialized
DEBUG - 2025-07-04 15:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-04 15:40:32 --> Input Class Initialized
INFO - 2025-07-04 15:40:32 --> Language Class Initialized
INFO - 2025-07-04 15:40:32 --> Loader Class Initialized
INFO - 2025-07-04 15:40:32 --> Helper loaded: url_helper
INFO - 2025-07-04 15:40:32 --> Helper loaded: form_helper
INFO - 2025-07-04 15:40:32 --> Database Driver Class Initialized
DEBUG - 2025-07-04 15:40:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-04 15:40:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-04 15:40:32 --> Controller Class Initialized
INFO - 2025-07-04 15:40:32 --> Model "Olahraga_model" initialized
INFO - 2025-07-04 15:40:32 --> Model "User_model" initialized
INFO - 2025-07-04 15:40:32 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-04 15:40:32 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-04 15:40:32 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/start.php
INFO - 2025-07-04 15:40:32 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-04 15:40:32 --> Final output sent to browser
DEBUG - 2025-07-04 15:40:32 --> Total execution time: 0.0333
INFO - 2025-07-04 16:05:55 --> Config Class Initialized
INFO - 2025-07-04 16:05:55 --> Hooks Class Initialized
DEBUG - 2025-07-04 16:05:55 --> UTF-8 Support Enabled
INFO - 2025-07-04 16:05:55 --> Utf8 Class Initialized
INFO - 2025-07-04 16:05:55 --> URI Class Initialized
INFO - 2025-07-04 16:05:55 --> Router Class Initialized
INFO - 2025-07-04 16:05:55 --> Output Class Initialized
INFO - 2025-07-04 16:05:55 --> Security Class Initialized
DEBUG - 2025-07-04 16:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-04 16:05:55 --> Input Class Initialized
INFO - 2025-07-04 16:05:55 --> Language Class Initialized
INFO - 2025-07-04 16:05:55 --> Loader Class Initialized
INFO - 2025-07-04 16:05:55 --> Helper loaded: url_helper
INFO - 2025-07-04 16:05:55 --> Helper loaded: form_helper
INFO - 2025-07-04 16:05:55 --> Database Driver Class Initialized
DEBUG - 2025-07-04 16:05:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-04 16:05:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-04 16:05:55 --> Controller Class Initialized
INFO - 2025-07-04 16:05:55 --> Model "Olahraga_model" initialized
INFO - 2025-07-04 16:05:55 --> Model "User_model" initialized
INFO - 2025-07-04 16:05:55 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-04 16:05:55 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-04 16:05:55 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/level.php
INFO - 2025-07-04 16:05:55 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-04 16:05:55 --> Final output sent to browser
DEBUG - 2025-07-04 16:05:55 --> Total execution time: 0.0421
