<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-05-23 14:20:56 --> Config Class Initialized
INFO - 2025-05-23 14:20:56 --> Hooks Class Initialized
DEBUG - 2025-05-23 14:20:56 --> UTF-8 Support Enabled
INFO - 2025-05-23 14:20:56 --> Utf8 Class Initialized
INFO - 2025-05-23 14:20:56 --> URI Class Initialized
DEBUG - 2025-05-23 14:20:56 --> No URI present. Default controller set.
INFO - 2025-05-23 14:20:56 --> Router Class Initialized
INFO - 2025-05-23 14:20:56 --> Output Class Initialized
INFO - 2025-05-23 14:20:56 --> Security Class Initialized
DEBUG - 2025-05-23 14:20:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 14:20:56 --> Input Class Initialized
INFO - 2025-05-23 14:20:56 --> Language Class Initialized
INFO - 2025-05-23 14:20:57 --> Loader Class Initialized
INFO - 2025-05-23 14:20:57 --> Helper loaded: url_helper
INFO - 2025-05-23 14:20:57 --> Helper loaded: form_helper
INFO - 2025-05-23 14:20:57 --> Database Driver Class Initialized
DEBUG - 2025-05-23 14:20:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 14:20:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 14:20:57 --> Controller Class Initialized
INFO - 2025-05-23 14:20:57 --> Model "User_model" initialized
INFO - 2025-05-23 14:20:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-23 14:20:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-23 14:20:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-23 14:20:57 --> Final output sent to browser
DEBUG - 2025-05-23 14:20:58 --> Total execution time: 1.7709
INFO - 2025-05-23 14:21:00 --> Config Class Initialized
INFO - 2025-05-23 14:21:00 --> Hooks Class Initialized
DEBUG - 2025-05-23 14:21:00 --> UTF-8 Support Enabled
INFO - 2025-05-23 14:21:00 --> Utf8 Class Initialized
INFO - 2025-05-23 14:21:00 --> URI Class Initialized
INFO - 2025-05-23 14:21:00 --> Router Class Initialized
INFO - 2025-05-23 14:21:00 --> Output Class Initialized
INFO - 2025-05-23 14:21:00 --> Security Class Initialized
DEBUG - 2025-05-23 14:21:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 14:21:00 --> Input Class Initialized
INFO - 2025-05-23 14:21:00 --> Language Class Initialized
INFO - 2025-05-23 14:21:00 --> Loader Class Initialized
INFO - 2025-05-23 14:21:00 --> Helper loaded: url_helper
INFO - 2025-05-23 14:21:00 --> Helper loaded: form_helper
INFO - 2025-05-23 14:21:00 --> Database Driver Class Initialized
DEBUG - 2025-05-23 14:21:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 14:21:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 14:21:00 --> Controller Class Initialized
INFO - 2025-05-23 14:21:00 --> Model "User_model" initialized
INFO - 2025-05-23 14:21:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-23 14:21:00 --> Final output sent to browser
DEBUG - 2025-05-23 14:21:00 --> Total execution time: 0.1772
INFO - 2025-05-23 14:21:06 --> Config Class Initialized
INFO - 2025-05-23 14:21:06 --> Hooks Class Initialized
DEBUG - 2025-05-23 14:21:06 --> UTF-8 Support Enabled
INFO - 2025-05-23 14:21:06 --> Utf8 Class Initialized
INFO - 2025-05-23 14:21:06 --> URI Class Initialized
INFO - 2025-05-23 14:21:06 --> Router Class Initialized
INFO - 2025-05-23 14:21:06 --> Output Class Initialized
INFO - 2025-05-23 14:21:06 --> Security Class Initialized
DEBUG - 2025-05-23 14:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 14:21:06 --> Input Class Initialized
INFO - 2025-05-23 14:21:06 --> Language Class Initialized
INFO - 2025-05-23 14:21:06 --> Loader Class Initialized
INFO - 2025-05-23 14:21:06 --> Helper loaded: url_helper
INFO - 2025-05-23 14:21:06 --> Helper loaded: form_helper
INFO - 2025-05-23 14:21:06 --> Database Driver Class Initialized
DEBUG - 2025-05-23 14:21:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 14:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 14:21:07 --> Controller Class Initialized
INFO - 2025-05-23 14:21:07 --> Model "User_model" initialized
INFO - 2025-05-23 14:21:07 --> Config Class Initialized
INFO - 2025-05-23 14:21:07 --> Hooks Class Initialized
DEBUG - 2025-05-23 14:21:07 --> UTF-8 Support Enabled
INFO - 2025-05-23 14:21:07 --> Utf8 Class Initialized
INFO - 2025-05-23 14:21:07 --> URI Class Initialized
INFO - 2025-05-23 14:21:07 --> Router Class Initialized
INFO - 2025-05-23 14:21:07 --> Output Class Initialized
INFO - 2025-05-23 14:21:07 --> Security Class Initialized
DEBUG - 2025-05-23 14:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 14:21:07 --> Input Class Initialized
INFO - 2025-05-23 14:21:07 --> Language Class Initialized
INFO - 2025-05-23 14:21:07 --> Loader Class Initialized
INFO - 2025-05-23 14:21:07 --> Helper loaded: url_helper
INFO - 2025-05-23 14:21:07 --> Helper loaded: form_helper
INFO - 2025-05-23 14:21:07 --> Database Driver Class Initialized
DEBUG - 2025-05-23 14:21:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 14:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 14:21:07 --> Controller Class Initialized
INFO - 2025-05-23 14:21:07 --> Model "User_model" initialized
INFO - 2025-05-23 14:21:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-23 14:21:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-23 14:21:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-23 14:21:07 --> Final output sent to browser
DEBUG - 2025-05-23 14:21:07 --> Total execution time: 0.0856
INFO - 2025-05-23 14:21:09 --> Config Class Initialized
INFO - 2025-05-23 14:21:09 --> Hooks Class Initialized
DEBUG - 2025-05-23 14:21:09 --> UTF-8 Support Enabled
INFO - 2025-05-23 14:21:09 --> Utf8 Class Initialized
INFO - 2025-05-23 14:21:09 --> URI Class Initialized
INFO - 2025-05-23 14:21:09 --> Router Class Initialized
INFO - 2025-05-23 14:21:09 --> Output Class Initialized
INFO - 2025-05-23 14:21:09 --> Security Class Initialized
DEBUG - 2025-05-23 14:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 14:21:09 --> Input Class Initialized
INFO - 2025-05-23 14:21:09 --> Language Class Initialized
INFO - 2025-05-23 14:21:09 --> Loader Class Initialized
INFO - 2025-05-23 14:21:09 --> Helper loaded: url_helper
INFO - 2025-05-23 14:21:09 --> Helper loaded: form_helper
INFO - 2025-05-23 14:21:09 --> Database Driver Class Initialized
DEBUG - 2025-05-23 14:21:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 14:21:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 14:21:09 --> Controller Class Initialized
INFO - 2025-05-23 14:21:09 --> Model "User_model" initialized
INFO - 2025-05-23 14:21:09 --> Model "Workout_model" initialized
INFO - 2025-05-23 14:21:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-23 14:21:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-23 14:21:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-23 14:21:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-23 14:21:10 --> Final output sent to browser
DEBUG - 2025-05-23 14:21:10 --> Total execution time: 0.2846
INFO - 2025-05-23 14:21:12 --> Config Class Initialized
INFO - 2025-05-23 14:21:12 --> Hooks Class Initialized
DEBUG - 2025-05-23 14:21:12 --> UTF-8 Support Enabled
INFO - 2025-05-23 14:21:12 --> Utf8 Class Initialized
INFO - 2025-05-23 14:21:12 --> URI Class Initialized
INFO - 2025-05-23 14:21:12 --> Router Class Initialized
INFO - 2025-05-23 14:21:12 --> Output Class Initialized
INFO - 2025-05-23 14:21:12 --> Security Class Initialized
DEBUG - 2025-05-23 14:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 14:21:12 --> Input Class Initialized
INFO - 2025-05-23 14:21:12 --> Language Class Initialized
ERROR - 2025-05-23 14:21:12 --> 404 Page Not Found: Olahraga/index
INFO - 2025-05-23 14:21:43 --> Config Class Initialized
INFO - 2025-05-23 14:21:43 --> Hooks Class Initialized
DEBUG - 2025-05-23 14:21:43 --> UTF-8 Support Enabled
INFO - 2025-05-23 14:21:43 --> Utf8 Class Initialized
INFO - 2025-05-23 14:21:43 --> URI Class Initialized
INFO - 2025-05-23 14:21:43 --> Router Class Initialized
INFO - 2025-05-23 14:21:43 --> Output Class Initialized
INFO - 2025-05-23 14:21:43 --> Security Class Initialized
DEBUG - 2025-05-23 14:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 14:21:43 --> Input Class Initialized
INFO - 2025-05-23 14:21:43 --> Language Class Initialized
INFO - 2025-05-23 14:21:43 --> Loader Class Initialized
INFO - 2025-05-23 14:21:43 --> Helper loaded: url_helper
INFO - 2025-05-23 14:21:43 --> Helper loaded: form_helper
INFO - 2025-05-23 14:21:43 --> Database Driver Class Initialized
DEBUG - 2025-05-23 14:21:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 14:21:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 14:21:43 --> Controller Class Initialized
INFO - 2025-05-23 14:21:43 --> Model "Workout_model" initialized
INFO - 2025-05-23 14:21:43 --> Model "User_model" initialized
INFO - 2025-05-23 14:21:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-23 14:21:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-23 14:21:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/olahraga1.php
INFO - 2025-05-23 14:21:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-23 14:21:43 --> Final output sent to browser
DEBUG - 2025-05-23 14:21:43 --> Total execution time: 0.0776
INFO - 2025-05-23 14:21:49 --> Config Class Initialized
INFO - 2025-05-23 14:21:49 --> Hooks Class Initialized
DEBUG - 2025-05-23 14:21:49 --> UTF-8 Support Enabled
INFO - 2025-05-23 14:21:49 --> Utf8 Class Initialized
INFO - 2025-05-23 14:21:49 --> URI Class Initialized
INFO - 2025-05-23 14:21:49 --> Router Class Initialized
INFO - 2025-05-23 14:21:49 --> Output Class Initialized
INFO - 2025-05-23 14:21:49 --> Security Class Initialized
DEBUG - 2025-05-23 14:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 14:21:49 --> Input Class Initialized
INFO - 2025-05-23 14:21:49 --> Language Class Initialized
INFO - 2025-05-23 14:21:49 --> Loader Class Initialized
INFO - 2025-05-23 14:21:49 --> Helper loaded: url_helper
INFO - 2025-05-23 14:21:49 --> Helper loaded: form_helper
INFO - 2025-05-23 14:21:49 --> Database Driver Class Initialized
DEBUG - 2025-05-23 14:21:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 14:21:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 14:21:49 --> Controller Class Initialized
INFO - 2025-05-23 14:21:50 --> Model "Progress_model" initialized
INFO - 2025-05-23 14:21:50 --> Model "User_model" initialized
INFO - 2025-05-23 14:21:50 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-23 14:21:50 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-23 14:21:50 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-23 14:21:50 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-23 14:21:50 --> Final output sent to browser
DEBUG - 2025-05-23 14:21:50 --> Total execution time: 0.1784
INFO - 2025-05-23 14:21:50 --> Config Class Initialized
INFO - 2025-05-23 14:21:50 --> Hooks Class Initialized
DEBUG - 2025-05-23 14:21:50 --> UTF-8 Support Enabled
INFO - 2025-05-23 14:21:50 --> Utf8 Class Initialized
INFO - 2025-05-23 14:21:50 --> URI Class Initialized
INFO - 2025-05-23 14:21:50 --> Router Class Initialized
INFO - 2025-05-23 14:21:50 --> Output Class Initialized
INFO - 2025-05-23 14:21:50 --> Security Class Initialized
DEBUG - 2025-05-23 14:21:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 14:21:50 --> Input Class Initialized
INFO - 2025-05-23 14:21:50 --> Language Class Initialized
INFO - 2025-05-23 14:21:50 --> Loader Class Initialized
INFO - 2025-05-23 14:21:50 --> Helper loaded: url_helper
INFO - 2025-05-23 14:21:50 --> Helper loaded: form_helper
INFO - 2025-05-23 14:21:50 --> Database Driver Class Initialized
DEBUG - 2025-05-23 14:21:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 14:21:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 14:21:50 --> Controller Class Initialized
INFO - 2025-05-23 14:21:50 --> Model "Progress_model" initialized
INFO - 2025-05-23 14:21:50 --> Model "User_model" initialized
INFO - 2025-05-23 14:21:50 --> Final output sent to browser
DEBUG - 2025-05-23 14:21:50 --> Total execution time: 0.0831
INFO - 2025-05-23 14:21:51 --> Config Class Initialized
INFO - 2025-05-23 14:21:51 --> Hooks Class Initialized
DEBUG - 2025-05-23 14:21:51 --> UTF-8 Support Enabled
INFO - 2025-05-23 14:21:51 --> Utf8 Class Initialized
INFO - 2025-05-23 14:21:51 --> URI Class Initialized
INFO - 2025-05-23 14:21:51 --> Router Class Initialized
INFO - 2025-05-23 14:21:51 --> Output Class Initialized
INFO - 2025-05-23 14:21:51 --> Security Class Initialized
DEBUG - 2025-05-23 14:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 14:21:51 --> Input Class Initialized
INFO - 2025-05-23 14:21:51 --> Language Class Initialized
INFO - 2025-05-23 14:21:51 --> Loader Class Initialized
INFO - 2025-05-23 14:21:51 --> Helper loaded: url_helper
INFO - 2025-05-23 14:21:51 --> Helper loaded: form_helper
INFO - 2025-05-23 14:21:51 --> Database Driver Class Initialized
DEBUG - 2025-05-23 14:21:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 14:21:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 14:21:51 --> Controller Class Initialized
INFO - 2025-05-23 14:21:51 --> Model "Workout_model" initialized
INFO - 2025-05-23 14:21:51 --> Model "User_model" initialized
INFO - 2025-05-23 14:21:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-23 14:21:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-23 14:21:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/olahraga1.php
INFO - 2025-05-23 14:21:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-23 14:21:51 --> Final output sent to browser
DEBUG - 2025-05-23 14:21:51 --> Total execution time: 0.0662
INFO - 2025-05-23 14:22:42 --> Config Class Initialized
INFO - 2025-05-23 14:22:42 --> Hooks Class Initialized
DEBUG - 2025-05-23 14:22:42 --> UTF-8 Support Enabled
INFO - 2025-05-23 14:22:42 --> Utf8 Class Initialized
INFO - 2025-05-23 14:22:42 --> URI Class Initialized
INFO - 2025-05-23 14:22:42 --> Router Class Initialized
INFO - 2025-05-23 14:22:42 --> Output Class Initialized
INFO - 2025-05-23 14:22:42 --> Security Class Initialized
DEBUG - 2025-05-23 14:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 14:22:42 --> Input Class Initialized
INFO - 2025-05-23 14:22:42 --> Language Class Initialized
INFO - 2025-05-23 14:22:42 --> Loader Class Initialized
INFO - 2025-05-23 14:22:42 --> Helper loaded: url_helper
INFO - 2025-05-23 14:22:42 --> Helper loaded: form_helper
INFO - 2025-05-23 14:22:42 --> Database Driver Class Initialized
DEBUG - 2025-05-23 14:22:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 14:22:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 14:22:42 --> Controller Class Initialized
INFO - 2025-05-23 14:22:42 --> Model "Workout_model" initialized
INFO - 2025-05-23 14:22:42 --> Model "User_model" initialized
INFO - 2025-05-23 14:22:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-23 14:22:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-23 14:22:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/olahraga1.php
INFO - 2025-05-23 14:22:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-23 14:22:42 --> Final output sent to browser
DEBUG - 2025-05-23 14:22:42 --> Total execution time: 0.0896
INFO - 2025-05-23 14:23:34 --> Config Class Initialized
INFO - 2025-05-23 14:23:34 --> Hooks Class Initialized
DEBUG - 2025-05-23 14:23:34 --> UTF-8 Support Enabled
INFO - 2025-05-23 14:23:34 --> Utf8 Class Initialized
INFO - 2025-05-23 14:23:34 --> URI Class Initialized
INFO - 2025-05-23 14:23:34 --> Router Class Initialized
INFO - 2025-05-23 14:23:34 --> Output Class Initialized
INFO - 2025-05-23 14:23:34 --> Security Class Initialized
DEBUG - 2025-05-23 14:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 14:23:34 --> Input Class Initialized
INFO - 2025-05-23 14:23:34 --> Language Class Initialized
INFO - 2025-05-23 14:23:34 --> Loader Class Initialized
INFO - 2025-05-23 14:23:34 --> Helper loaded: url_helper
INFO - 2025-05-23 14:23:34 --> Helper loaded: form_helper
INFO - 2025-05-23 14:23:34 --> Database Driver Class Initialized
DEBUG - 2025-05-23 14:23:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 14:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 14:23:35 --> Controller Class Initialized
INFO - 2025-05-23 14:23:35 --> Model "Workout_model" initialized
INFO - 2025-05-23 14:23:35 --> Model "User_model" initialized
INFO - 2025-05-23 14:23:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-23 14:23:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-23 14:23:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/olahraga1.php
INFO - 2025-05-23 14:23:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-23 14:23:35 --> Final output sent to browser
DEBUG - 2025-05-23 14:23:35 --> Total execution time: 0.0716
INFO - 2025-05-23 14:59:30 --> Config Class Initialized
INFO - 2025-05-23 14:59:30 --> Hooks Class Initialized
DEBUG - 2025-05-23 14:59:30 --> UTF-8 Support Enabled
INFO - 2025-05-23 14:59:30 --> Utf8 Class Initialized
INFO - 2025-05-23 14:59:30 --> URI Class Initialized
INFO - 2025-05-23 14:59:30 --> Router Class Initialized
INFO - 2025-05-23 14:59:30 --> Output Class Initialized
INFO - 2025-05-23 14:59:30 --> Security Class Initialized
DEBUG - 2025-05-23 14:59:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 14:59:30 --> Input Class Initialized
INFO - 2025-05-23 14:59:30 --> Language Class Initialized
INFO - 2025-05-23 14:59:30 --> Loader Class Initialized
INFO - 2025-05-23 14:59:30 --> Helper loaded: url_helper
INFO - 2025-05-23 14:59:30 --> Helper loaded: form_helper
INFO - 2025-05-23 14:59:30 --> Database Driver Class Initialized
DEBUG - 2025-05-23 14:59:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 14:59:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 14:59:30 --> Controller Class Initialized
INFO - 2025-05-23 14:59:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\beta.php
INFO - 2025-05-23 14:59:30 --> Final output sent to browser
DEBUG - 2025-05-23 14:59:30 --> Total execution time: 0.0689
INFO - 2025-05-23 14:59:33 --> Config Class Initialized
INFO - 2025-05-23 14:59:33 --> Hooks Class Initialized
DEBUG - 2025-05-23 14:59:33 --> UTF-8 Support Enabled
INFO - 2025-05-23 14:59:33 --> Utf8 Class Initialized
INFO - 2025-05-23 14:59:33 --> URI Class Initialized
INFO - 2025-05-23 14:59:33 --> Router Class Initialized
INFO - 2025-05-23 14:59:33 --> Output Class Initialized
INFO - 2025-05-23 14:59:33 --> Security Class Initialized
DEBUG - 2025-05-23 14:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 14:59:33 --> Input Class Initialized
INFO - 2025-05-23 14:59:33 --> Language Class Initialized
ERROR - 2025-05-23 14:59:33 --> 404 Page Not Found: Workout/select_level
INFO - 2025-05-23 15:00:41 --> Config Class Initialized
INFO - 2025-05-23 15:00:41 --> Hooks Class Initialized
DEBUG - 2025-05-23 15:00:41 --> UTF-8 Support Enabled
INFO - 2025-05-23 15:00:41 --> Utf8 Class Initialized
INFO - 2025-05-23 15:00:41 --> URI Class Initialized
INFO - 2025-05-23 15:00:41 --> Router Class Initialized
INFO - 2025-05-23 15:00:41 --> Output Class Initialized
INFO - 2025-05-23 15:00:41 --> Security Class Initialized
DEBUG - 2025-05-23 15:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 15:00:41 --> Input Class Initialized
INFO - 2025-05-23 15:00:41 --> Language Class Initialized
INFO - 2025-05-23 15:00:41 --> Loader Class Initialized
INFO - 2025-05-23 15:00:41 --> Helper loaded: url_helper
INFO - 2025-05-23 15:00:41 --> Helper loaded: form_helper
INFO - 2025-05-23 15:00:41 --> Database Driver Class Initialized
DEBUG - 2025-05-23 15:00:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 15:00:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 15:00:41 --> Controller Class Initialized
INFO - 2025-05-23 15:00:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\beta.php
INFO - 2025-05-23 15:00:41 --> Final output sent to browser
DEBUG - 2025-05-23 15:00:41 --> Total execution time: 0.0694
INFO - 2025-05-23 15:00:42 --> Config Class Initialized
INFO - 2025-05-23 15:00:42 --> Hooks Class Initialized
DEBUG - 2025-05-23 15:00:42 --> UTF-8 Support Enabled
INFO - 2025-05-23 15:00:42 --> Utf8 Class Initialized
INFO - 2025-05-23 15:00:42 --> URI Class Initialized
INFO - 2025-05-23 15:00:42 --> Router Class Initialized
INFO - 2025-05-23 15:00:43 --> Output Class Initialized
INFO - 2025-05-23 15:00:43 --> Security Class Initialized
DEBUG - 2025-05-23 15:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 15:00:43 --> Input Class Initialized
INFO - 2025-05-23 15:00:43 --> Language Class Initialized
ERROR - 2025-05-23 15:00:43 --> 404 Page Not Found: Level/perut
INFO - 2025-05-23 15:00:45 --> Config Class Initialized
INFO - 2025-05-23 15:00:45 --> Hooks Class Initialized
DEBUG - 2025-05-23 15:00:45 --> UTF-8 Support Enabled
INFO - 2025-05-23 15:00:45 --> Utf8 Class Initialized
INFO - 2025-05-23 15:00:45 --> URI Class Initialized
INFO - 2025-05-23 15:00:45 --> Router Class Initialized
INFO - 2025-05-23 15:00:45 --> Output Class Initialized
INFO - 2025-05-23 15:00:45 --> Security Class Initialized
DEBUG - 2025-05-23 15:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 15:00:45 --> Input Class Initialized
INFO - 2025-05-23 15:00:45 --> Language Class Initialized
ERROR - 2025-05-23 15:00:45 --> 404 Page Not Found: Level/perut
INFO - 2025-05-23 15:00:46 --> Config Class Initialized
INFO - 2025-05-23 15:00:46 --> Hooks Class Initialized
DEBUG - 2025-05-23 15:00:46 --> UTF-8 Support Enabled
INFO - 2025-05-23 15:00:46 --> Utf8 Class Initialized
INFO - 2025-05-23 15:00:46 --> URI Class Initialized
INFO - 2025-05-23 15:00:46 --> Router Class Initialized
INFO - 2025-05-23 15:00:46 --> Output Class Initialized
INFO - 2025-05-23 15:00:46 --> Security Class Initialized
DEBUG - 2025-05-23 15:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 15:00:46 --> Input Class Initialized
INFO - 2025-05-23 15:00:46 --> Language Class Initialized
ERROR - 2025-05-23 15:00:46 --> 404 Page Not Found: Level/perut
INFO - 2025-05-23 15:00:46 --> Config Class Initialized
INFO - 2025-05-23 15:00:46 --> Hooks Class Initialized
DEBUG - 2025-05-23 15:00:46 --> UTF-8 Support Enabled
INFO - 2025-05-23 15:00:46 --> Utf8 Class Initialized
INFO - 2025-05-23 15:00:46 --> URI Class Initialized
INFO - 2025-05-23 15:00:46 --> Router Class Initialized
INFO - 2025-05-23 15:00:46 --> Output Class Initialized
INFO - 2025-05-23 15:00:46 --> Security Class Initialized
DEBUG - 2025-05-23 15:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 15:00:46 --> Input Class Initialized
INFO - 2025-05-23 15:00:46 --> Language Class Initialized
ERROR - 2025-05-23 15:00:46 --> 404 Page Not Found: Level/perut
INFO - 2025-05-23 15:00:46 --> Config Class Initialized
INFO - 2025-05-23 15:00:46 --> Hooks Class Initialized
DEBUG - 2025-05-23 15:00:46 --> UTF-8 Support Enabled
INFO - 2025-05-23 15:00:46 --> Utf8 Class Initialized
INFO - 2025-05-23 15:00:46 --> URI Class Initialized
INFO - 2025-05-23 15:00:46 --> Router Class Initialized
INFO - 2025-05-23 15:00:46 --> Output Class Initialized
INFO - 2025-05-23 15:00:46 --> Security Class Initialized
DEBUG - 2025-05-23 15:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 15:00:46 --> Input Class Initialized
INFO - 2025-05-23 15:00:46 --> Language Class Initialized
ERROR - 2025-05-23 15:00:46 --> 404 Page Not Found: Level/perut
INFO - 2025-05-23 15:00:46 --> Config Class Initialized
INFO - 2025-05-23 15:00:46 --> Hooks Class Initialized
DEBUG - 2025-05-23 15:00:46 --> UTF-8 Support Enabled
INFO - 2025-05-23 15:00:46 --> Utf8 Class Initialized
INFO - 2025-05-23 15:00:46 --> URI Class Initialized
INFO - 2025-05-23 15:00:46 --> Router Class Initialized
INFO - 2025-05-23 15:00:46 --> Output Class Initialized
INFO - 2025-05-23 15:00:46 --> Security Class Initialized
DEBUG - 2025-05-23 15:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 15:00:46 --> Input Class Initialized
INFO - 2025-05-23 15:00:46 --> Language Class Initialized
ERROR - 2025-05-23 15:00:46 --> 404 Page Not Found: Level/perut
INFO - 2025-05-23 15:00:46 --> Config Class Initialized
INFO - 2025-05-23 15:00:46 --> Hooks Class Initialized
DEBUG - 2025-05-23 15:00:46 --> UTF-8 Support Enabled
INFO - 2025-05-23 15:00:46 --> Utf8 Class Initialized
INFO - 2025-05-23 15:00:46 --> URI Class Initialized
INFO - 2025-05-23 15:00:46 --> Router Class Initialized
INFO - 2025-05-23 15:00:46 --> Output Class Initialized
INFO - 2025-05-23 15:00:46 --> Security Class Initialized
DEBUG - 2025-05-23 15:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 15:00:46 --> Input Class Initialized
INFO - 2025-05-23 15:00:46 --> Language Class Initialized
ERROR - 2025-05-23 15:00:46 --> 404 Page Not Found: Level/perut
INFO - 2025-05-23 15:00:47 --> Config Class Initialized
INFO - 2025-05-23 15:00:47 --> Hooks Class Initialized
DEBUG - 2025-05-23 15:00:47 --> UTF-8 Support Enabled
INFO - 2025-05-23 15:00:47 --> Utf8 Class Initialized
INFO - 2025-05-23 15:00:47 --> URI Class Initialized
INFO - 2025-05-23 15:00:47 --> Router Class Initialized
INFO - 2025-05-23 15:00:47 --> Output Class Initialized
INFO - 2025-05-23 15:00:47 --> Security Class Initialized
DEBUG - 2025-05-23 15:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 15:00:47 --> Input Class Initialized
INFO - 2025-05-23 15:00:47 --> Language Class Initialized
ERROR - 2025-05-23 15:00:47 --> 404 Page Not Found: Level/perut
INFO - 2025-05-23 15:02:10 --> Config Class Initialized
INFO - 2025-05-23 15:02:10 --> Hooks Class Initialized
DEBUG - 2025-05-23 15:02:10 --> UTF-8 Support Enabled
INFO - 2025-05-23 15:02:10 --> Utf8 Class Initialized
INFO - 2025-05-23 15:02:10 --> URI Class Initialized
INFO - 2025-05-23 15:02:10 --> Router Class Initialized
INFO - 2025-05-23 15:02:10 --> Output Class Initialized
INFO - 2025-05-23 15:02:10 --> Security Class Initialized
DEBUG - 2025-05-23 15:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 15:02:10 --> Input Class Initialized
INFO - 2025-05-23 15:02:10 --> Language Class Initialized
INFO - 2025-05-23 15:02:10 --> Loader Class Initialized
INFO - 2025-05-23 15:02:10 --> Helper loaded: url_helper
INFO - 2025-05-23 15:02:10 --> Helper loaded: form_helper
INFO - 2025-05-23 15:02:10 --> Database Driver Class Initialized
DEBUG - 2025-05-23 15:02:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 15:02:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 15:02:10 --> Controller Class Initialized
INFO - 2025-05-23 15:02:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\beta.php
INFO - 2025-05-23 15:02:10 --> Final output sent to browser
DEBUG - 2025-05-23 15:02:10 --> Total execution time: 0.0521
INFO - 2025-05-23 15:02:11 --> Config Class Initialized
INFO - 2025-05-23 15:02:11 --> Hooks Class Initialized
DEBUG - 2025-05-23 15:02:11 --> UTF-8 Support Enabled
INFO - 2025-05-23 15:02:11 --> Utf8 Class Initialized
INFO - 2025-05-23 15:02:11 --> URI Class Initialized
INFO - 2025-05-23 15:02:11 --> Router Class Initialized
INFO - 2025-05-23 15:02:11 --> Output Class Initialized
INFO - 2025-05-23 15:02:11 --> Security Class Initialized
DEBUG - 2025-05-23 15:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 15:02:12 --> Input Class Initialized
INFO - 2025-05-23 15:02:12 --> Language Class Initialized
ERROR - 2025-05-23 15:02:12 --> 404 Page Not Found: Level/index
INFO - 2025-05-23 15:03:34 --> Config Class Initialized
INFO - 2025-05-23 15:03:34 --> Hooks Class Initialized
DEBUG - 2025-05-23 15:03:34 --> UTF-8 Support Enabled
INFO - 2025-05-23 15:03:34 --> Utf8 Class Initialized
INFO - 2025-05-23 15:03:34 --> URI Class Initialized
INFO - 2025-05-23 15:03:34 --> Router Class Initialized
INFO - 2025-05-23 15:03:35 --> Output Class Initialized
INFO - 2025-05-23 15:03:35 --> Security Class Initialized
DEBUG - 2025-05-23 15:03:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 15:03:35 --> Input Class Initialized
INFO - 2025-05-23 15:03:35 --> Language Class Initialized
ERROR - 2025-05-23 15:03:35 --> 404 Page Not Found: Level/index
INFO - 2025-05-23 15:03:37 --> Config Class Initialized
INFO - 2025-05-23 15:03:37 --> Hooks Class Initialized
DEBUG - 2025-05-23 15:03:37 --> UTF-8 Support Enabled
INFO - 2025-05-23 15:03:37 --> Utf8 Class Initialized
INFO - 2025-05-23 15:03:37 --> URI Class Initialized
INFO - 2025-05-23 15:03:37 --> Router Class Initialized
INFO - 2025-05-23 15:03:37 --> Output Class Initialized
INFO - 2025-05-23 15:03:37 --> Security Class Initialized
DEBUG - 2025-05-23 15:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 15:03:37 --> Input Class Initialized
INFO - 2025-05-23 15:03:37 --> Language Class Initialized
ERROR - 2025-05-23 15:03:37 --> 404 Page Not Found: Level/index
INFO - 2025-05-23 15:03:39 --> Config Class Initialized
INFO - 2025-05-23 15:03:39 --> Hooks Class Initialized
DEBUG - 2025-05-23 15:03:39 --> UTF-8 Support Enabled
INFO - 2025-05-23 15:03:39 --> Utf8 Class Initialized
INFO - 2025-05-23 15:03:39 --> URI Class Initialized
INFO - 2025-05-23 15:03:39 --> Router Class Initialized
INFO - 2025-05-23 15:03:39 --> Output Class Initialized
INFO - 2025-05-23 15:03:39 --> Security Class Initialized
DEBUG - 2025-05-23 15:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 15:03:39 --> Input Class Initialized
INFO - 2025-05-23 15:03:39 --> Language Class Initialized
INFO - 2025-05-23 15:03:39 --> Loader Class Initialized
INFO - 2025-05-23 15:03:39 --> Helper loaded: url_helper
INFO - 2025-05-23 15:03:39 --> Helper loaded: form_helper
INFO - 2025-05-23 15:03:39 --> Database Driver Class Initialized
DEBUG - 2025-05-23 15:03:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 15:03:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 15:03:39 --> Controller Class Initialized
INFO - 2025-05-23 15:03:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\beta.php
INFO - 2025-05-23 15:03:39 --> Final output sent to browser
DEBUG - 2025-05-23 15:03:39 --> Total execution time: 0.0665
INFO - 2025-05-23 15:03:40 --> Config Class Initialized
INFO - 2025-05-23 15:03:40 --> Hooks Class Initialized
DEBUG - 2025-05-23 15:03:40 --> UTF-8 Support Enabled
INFO - 2025-05-23 15:03:40 --> Utf8 Class Initialized
INFO - 2025-05-23 15:03:40 --> URI Class Initialized
INFO - 2025-05-23 15:03:40 --> Router Class Initialized
INFO - 2025-05-23 15:03:40 --> Output Class Initialized
INFO - 2025-05-23 15:03:40 --> Security Class Initialized
DEBUG - 2025-05-23 15:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 15:03:40 --> Input Class Initialized
INFO - 2025-05-23 15:03:40 --> Language Class Initialized
INFO - 2025-05-23 15:03:40 --> Loader Class Initialized
INFO - 2025-05-23 15:03:40 --> Helper loaded: url_helper
INFO - 2025-05-23 15:03:40 --> Helper loaded: form_helper
INFO - 2025-05-23 15:03:40 --> Database Driver Class Initialized
DEBUG - 2025-05-23 15:03:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 15:03:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 15:03:40 --> Controller Class Initialized
INFO - 2025-05-23 15:03:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\beta.php
INFO - 2025-05-23 15:03:40 --> Final output sent to browser
DEBUG - 2025-05-23 15:03:40 --> Total execution time: 0.0769
INFO - 2025-05-23 15:03:41 --> Config Class Initialized
INFO - 2025-05-23 15:03:41 --> Hooks Class Initialized
DEBUG - 2025-05-23 15:03:41 --> UTF-8 Support Enabled
INFO - 2025-05-23 15:03:41 --> Utf8 Class Initialized
INFO - 2025-05-23 15:03:41 --> URI Class Initialized
INFO - 2025-05-23 15:03:41 --> Router Class Initialized
INFO - 2025-05-23 15:03:41 --> Output Class Initialized
INFO - 2025-05-23 15:03:41 --> Security Class Initialized
DEBUG - 2025-05-23 15:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 15:03:41 --> Input Class Initialized
INFO - 2025-05-23 15:03:41 --> Language Class Initialized
INFO - 2025-05-23 15:03:41 --> Loader Class Initialized
INFO - 2025-05-23 15:03:41 --> Helper loaded: url_helper
INFO - 2025-05-23 15:03:41 --> Helper loaded: form_helper
INFO - 2025-05-23 15:03:41 --> Database Driver Class Initialized
DEBUG - 2025-05-23 15:03:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 15:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 15:03:42 --> Controller Class Initialized
INFO - 2025-05-23 15:03:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\level.php
INFO - 2025-05-23 15:03:42 --> Final output sent to browser
DEBUG - 2025-05-23 15:03:42 --> Total execution time: 0.0679
INFO - 2025-05-23 15:03:44 --> Config Class Initialized
INFO - 2025-05-23 15:03:44 --> Hooks Class Initialized
DEBUG - 2025-05-23 15:03:44 --> UTF-8 Support Enabled
INFO - 2025-05-23 15:03:44 --> Utf8 Class Initialized
INFO - 2025-05-23 15:03:44 --> URI Class Initialized
INFO - 2025-05-23 15:03:44 --> Router Class Initialized
INFO - 2025-05-23 15:03:44 --> Output Class Initialized
INFO - 2025-05-23 15:03:44 --> Security Class Initialized
DEBUG - 2025-05-23 15:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 15:03:44 --> Input Class Initialized
INFO - 2025-05-23 15:03:44 --> Language Class Initialized
INFO - 2025-05-23 15:03:44 --> Loader Class Initialized
INFO - 2025-05-23 15:03:44 --> Helper loaded: url_helper
INFO - 2025-05-23 15:03:44 --> Helper loaded: form_helper
INFO - 2025-05-23 15:03:44 --> Database Driver Class Initialized
DEBUG - 2025-05-23 15:03:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 15:03:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 15:03:44 --> Controller Class Initialized
INFO - 2025-05-23 15:03:44 --> Model "Beta_model" initialized
INFO - 2025-05-23 15:03:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\menu.php
INFO - 2025-05-23 15:03:44 --> Final output sent to browser
DEBUG - 2025-05-23 15:03:44 --> Total execution time: 0.0769
INFO - 2025-05-23 15:03:48 --> Config Class Initialized
INFO - 2025-05-23 15:03:48 --> Hooks Class Initialized
DEBUG - 2025-05-23 15:03:48 --> UTF-8 Support Enabled
INFO - 2025-05-23 15:03:48 --> Utf8 Class Initialized
INFO - 2025-05-23 15:03:48 --> URI Class Initialized
INFO - 2025-05-23 15:03:48 --> Router Class Initialized
INFO - 2025-05-23 15:03:48 --> Output Class Initialized
INFO - 2025-05-23 15:03:48 --> Security Class Initialized
DEBUG - 2025-05-23 15:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 15:03:48 --> Input Class Initialized
INFO - 2025-05-23 15:03:48 --> Language Class Initialized
INFO - 2025-05-23 15:03:48 --> Loader Class Initialized
INFO - 2025-05-23 15:03:48 --> Helper loaded: url_helper
INFO - 2025-05-23 15:03:48 --> Helper loaded: form_helper
INFO - 2025-05-23 15:03:48 --> Database Driver Class Initialized
DEBUG - 2025-05-23 15:03:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 15:03:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 15:03:48 --> Controller Class Initialized
INFO - 2025-05-23 15:03:48 --> Model "Beta_model" initialized
INFO - 2025-05-23 15:03:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\menu.php
INFO - 2025-05-23 15:03:48 --> Final output sent to browser
DEBUG - 2025-05-23 15:03:48 --> Total execution time: 0.0631
INFO - 2025-05-23 15:03:52 --> Config Class Initialized
INFO - 2025-05-23 15:03:52 --> Hooks Class Initialized
DEBUG - 2025-05-23 15:03:52 --> UTF-8 Support Enabled
INFO - 2025-05-23 15:03:52 --> Utf8 Class Initialized
INFO - 2025-05-23 15:03:52 --> URI Class Initialized
INFO - 2025-05-23 15:03:52 --> Router Class Initialized
INFO - 2025-05-23 15:03:52 --> Output Class Initialized
INFO - 2025-05-23 15:03:52 --> Security Class Initialized
DEBUG - 2025-05-23 15:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 15:03:52 --> Input Class Initialized
INFO - 2025-05-23 15:03:52 --> Language Class Initialized
INFO - 2025-05-23 15:03:52 --> Loader Class Initialized
INFO - 2025-05-23 15:03:52 --> Helper loaded: url_helper
INFO - 2025-05-23 15:03:52 --> Helper loaded: form_helper
INFO - 2025-05-23 15:03:52 --> Database Driver Class Initialized
DEBUG - 2025-05-23 15:03:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 15:03:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 15:03:52 --> Controller Class Initialized
INFO - 2025-05-23 15:03:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\level.php
INFO - 2025-05-23 15:03:52 --> Final output sent to browser
DEBUG - 2025-05-23 15:03:52 --> Total execution time: 0.0524
INFO - 2025-05-23 15:03:53 --> Config Class Initialized
INFO - 2025-05-23 15:03:53 --> Hooks Class Initialized
DEBUG - 2025-05-23 15:03:53 --> UTF-8 Support Enabled
INFO - 2025-05-23 15:03:53 --> Utf8 Class Initialized
INFO - 2025-05-23 15:03:53 --> URI Class Initialized
INFO - 2025-05-23 15:03:53 --> Router Class Initialized
INFO - 2025-05-23 15:03:53 --> Output Class Initialized
INFO - 2025-05-23 15:03:53 --> Security Class Initialized
DEBUG - 2025-05-23 15:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 15:03:53 --> Input Class Initialized
INFO - 2025-05-23 15:03:53 --> Language Class Initialized
INFO - 2025-05-23 15:03:53 --> Loader Class Initialized
INFO - 2025-05-23 15:03:53 --> Helper loaded: url_helper
INFO - 2025-05-23 15:03:53 --> Helper loaded: form_helper
INFO - 2025-05-23 15:03:53 --> Database Driver Class Initialized
DEBUG - 2025-05-23 15:03:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 15:03:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 15:03:54 --> Controller Class Initialized
INFO - 2025-05-23 15:03:54 --> Model "Beta_model" initialized
INFO - 2025-05-23 15:03:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\menu.php
INFO - 2025-05-23 15:03:54 --> Final output sent to browser
DEBUG - 2025-05-23 15:03:54 --> Total execution time: 0.0766
INFO - 2025-05-23 15:03:56 --> Config Class Initialized
INFO - 2025-05-23 15:03:56 --> Hooks Class Initialized
DEBUG - 2025-05-23 15:03:56 --> UTF-8 Support Enabled
INFO - 2025-05-23 15:03:56 --> Utf8 Class Initialized
INFO - 2025-05-23 15:03:56 --> URI Class Initialized
INFO - 2025-05-23 15:03:56 --> Router Class Initialized
INFO - 2025-05-23 15:03:56 --> Output Class Initialized
INFO - 2025-05-23 15:03:56 --> Security Class Initialized
DEBUG - 2025-05-23 15:03:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 15:03:56 --> Input Class Initialized
INFO - 2025-05-23 15:03:56 --> Language Class Initialized
INFO - 2025-05-23 15:03:56 --> Loader Class Initialized
INFO - 2025-05-23 15:03:56 --> Helper loaded: url_helper
INFO - 2025-05-23 15:03:56 --> Helper loaded: form_helper
INFO - 2025-05-23 15:03:56 --> Database Driver Class Initialized
DEBUG - 2025-05-23 15:03:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 15:03:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 15:03:56 --> Controller Class Initialized
INFO - 2025-05-23 15:03:56 --> Model "Beta_model" initialized
INFO - 2025-05-23 15:03:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\menu.php
INFO - 2025-05-23 15:03:56 --> Final output sent to browser
DEBUG - 2025-05-23 15:03:56 --> Total execution time: 0.0755
INFO - 2025-05-23 15:11:18 --> Config Class Initialized
INFO - 2025-05-23 15:11:18 --> Hooks Class Initialized
DEBUG - 2025-05-23 15:11:18 --> UTF-8 Support Enabled
INFO - 2025-05-23 15:11:18 --> Utf8 Class Initialized
INFO - 2025-05-23 15:11:18 --> URI Class Initialized
INFO - 2025-05-23 15:11:18 --> Router Class Initialized
INFO - 2025-05-23 15:11:18 --> Output Class Initialized
INFO - 2025-05-23 15:11:18 --> Security Class Initialized
DEBUG - 2025-05-23 15:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 15:11:18 --> Input Class Initialized
INFO - 2025-05-23 15:11:18 --> Language Class Initialized
INFO - 2025-05-23 15:11:18 --> Loader Class Initialized
INFO - 2025-05-23 15:11:18 --> Helper loaded: url_helper
INFO - 2025-05-23 15:11:18 --> Helper loaded: form_helper
INFO - 2025-05-23 15:11:18 --> Database Driver Class Initialized
DEBUG - 2025-05-23 15:11:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 15:11:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 15:11:18 --> Controller Class Initialized
INFO - 2025-05-23 15:11:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\beta.php
INFO - 2025-05-23 15:11:18 --> Final output sent to browser
DEBUG - 2025-05-23 15:11:18 --> Total execution time: 0.0631
INFO - 2025-05-23 15:11:19 --> Config Class Initialized
INFO - 2025-05-23 15:11:19 --> Hooks Class Initialized
DEBUG - 2025-05-23 15:11:19 --> UTF-8 Support Enabled
INFO - 2025-05-23 15:11:19 --> Utf8 Class Initialized
INFO - 2025-05-23 15:11:19 --> URI Class Initialized
INFO - 2025-05-23 15:11:19 --> Router Class Initialized
INFO - 2025-05-23 15:11:19 --> Output Class Initialized
INFO - 2025-05-23 15:11:19 --> Security Class Initialized
DEBUG - 2025-05-23 15:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 15:11:19 --> Input Class Initialized
INFO - 2025-05-23 15:11:19 --> Language Class Initialized
INFO - 2025-05-23 15:11:19 --> Loader Class Initialized
INFO - 2025-05-23 15:11:19 --> Helper loaded: url_helper
INFO - 2025-05-23 15:11:19 --> Helper loaded: form_helper
INFO - 2025-05-23 15:11:19 --> Database Driver Class Initialized
DEBUG - 2025-05-23 15:11:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 15:11:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 15:11:19 --> Controller Class Initialized
INFO - 2025-05-23 15:11:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\level.php
INFO - 2025-05-23 15:11:19 --> Final output sent to browser
DEBUG - 2025-05-23 15:11:19 --> Total execution time: 0.0720
INFO - 2025-05-23 15:11:21 --> Config Class Initialized
INFO - 2025-05-23 15:11:21 --> Hooks Class Initialized
DEBUG - 2025-05-23 15:11:21 --> UTF-8 Support Enabled
INFO - 2025-05-23 15:11:21 --> Utf8 Class Initialized
INFO - 2025-05-23 15:11:21 --> URI Class Initialized
INFO - 2025-05-23 15:11:21 --> Router Class Initialized
INFO - 2025-05-23 15:11:21 --> Output Class Initialized
INFO - 2025-05-23 15:11:21 --> Security Class Initialized
DEBUG - 2025-05-23 15:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 15:11:21 --> Input Class Initialized
INFO - 2025-05-23 15:11:21 --> Language Class Initialized
INFO - 2025-05-23 15:11:21 --> Loader Class Initialized
INFO - 2025-05-23 15:11:21 --> Helper loaded: url_helper
INFO - 2025-05-23 15:11:21 --> Helper loaded: form_helper
INFO - 2025-05-23 15:11:21 --> Database Driver Class Initialized
DEBUG - 2025-05-23 15:11:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 15:11:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 15:11:21 --> Controller Class Initialized
INFO - 2025-05-23 15:11:21 --> Model "Beta_model" initialized
INFO - 2025-05-23 15:11:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\menu.php
INFO - 2025-05-23 15:11:21 --> Final output sent to browser
DEBUG - 2025-05-23 15:11:21 --> Total execution time: 0.0584
INFO - 2025-05-23 15:11:31 --> Config Class Initialized
INFO - 2025-05-23 15:11:31 --> Hooks Class Initialized
DEBUG - 2025-05-23 15:11:31 --> UTF-8 Support Enabled
INFO - 2025-05-23 15:11:31 --> Utf8 Class Initialized
INFO - 2025-05-23 15:11:31 --> URI Class Initialized
INFO - 2025-05-23 15:11:31 --> Router Class Initialized
INFO - 2025-05-23 15:11:31 --> Output Class Initialized
INFO - 2025-05-23 15:11:31 --> Security Class Initialized
DEBUG - 2025-05-23 15:11:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 15:11:31 --> Input Class Initialized
INFO - 2025-05-23 15:11:31 --> Language Class Initialized
INFO - 2025-05-23 15:11:31 --> Loader Class Initialized
INFO - 2025-05-23 15:11:31 --> Helper loaded: url_helper
INFO - 2025-05-23 15:11:31 --> Helper loaded: form_helper
INFO - 2025-05-23 15:11:31 --> Database Driver Class Initialized
DEBUG - 2025-05-23 15:11:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 15:11:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 15:11:31 --> Controller Class Initialized
INFO - 2025-05-23 15:11:31 --> Model "Beta_model" initialized
INFO - 2025-05-23 15:11:31 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\menu.php
INFO - 2025-05-23 15:11:31 --> Final output sent to browser
DEBUG - 2025-05-23 15:11:31 --> Total execution time: 0.0929
INFO - 2025-05-23 15:11:42 --> Config Class Initialized
INFO - 2025-05-23 15:11:42 --> Hooks Class Initialized
DEBUG - 2025-05-23 15:11:42 --> UTF-8 Support Enabled
INFO - 2025-05-23 15:11:42 --> Utf8 Class Initialized
INFO - 2025-05-23 15:11:42 --> URI Class Initialized
INFO - 2025-05-23 15:11:42 --> Router Class Initialized
INFO - 2025-05-23 15:11:42 --> Output Class Initialized
INFO - 2025-05-23 15:11:42 --> Security Class Initialized
DEBUG - 2025-05-23 15:11:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 15:11:42 --> Input Class Initialized
INFO - 2025-05-23 15:11:42 --> Language Class Initialized
INFO - 2025-05-23 15:11:42 --> Loader Class Initialized
INFO - 2025-05-23 15:11:42 --> Helper loaded: url_helper
INFO - 2025-05-23 15:11:42 --> Helper loaded: form_helper
INFO - 2025-05-23 15:11:42 --> Database Driver Class Initialized
DEBUG - 2025-05-23 15:11:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 15:11:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 15:11:42 --> Controller Class Initialized
INFO - 2025-05-23 15:11:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\beta.php
INFO - 2025-05-23 15:11:42 --> Final output sent to browser
DEBUG - 2025-05-23 15:11:42 --> Total execution time: 0.0636
INFO - 2025-05-23 15:11:44 --> Config Class Initialized
INFO - 2025-05-23 15:11:44 --> Hooks Class Initialized
DEBUG - 2025-05-23 15:11:44 --> UTF-8 Support Enabled
INFO - 2025-05-23 15:11:44 --> Utf8 Class Initialized
INFO - 2025-05-23 15:11:44 --> URI Class Initialized
INFO - 2025-05-23 15:11:44 --> Router Class Initialized
INFO - 2025-05-23 15:11:44 --> Output Class Initialized
INFO - 2025-05-23 15:11:44 --> Security Class Initialized
DEBUG - 2025-05-23 15:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 15:11:44 --> Input Class Initialized
INFO - 2025-05-23 15:11:44 --> Language Class Initialized
INFO - 2025-05-23 15:11:44 --> Loader Class Initialized
INFO - 2025-05-23 15:11:44 --> Helper loaded: url_helper
INFO - 2025-05-23 15:11:44 --> Helper loaded: form_helper
INFO - 2025-05-23 15:11:44 --> Database Driver Class Initialized
DEBUG - 2025-05-23 15:11:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 15:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 15:11:45 --> Controller Class Initialized
INFO - 2025-05-23 15:11:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\level.php
INFO - 2025-05-23 15:11:45 --> Final output sent to browser
DEBUG - 2025-05-23 15:11:45 --> Total execution time: 0.0535
INFO - 2025-05-23 15:11:46 --> Config Class Initialized
INFO - 2025-05-23 15:11:46 --> Hooks Class Initialized
DEBUG - 2025-05-23 15:11:46 --> UTF-8 Support Enabled
INFO - 2025-05-23 15:11:46 --> Utf8 Class Initialized
INFO - 2025-05-23 15:11:46 --> URI Class Initialized
INFO - 2025-05-23 15:11:46 --> Router Class Initialized
INFO - 2025-05-23 15:11:46 --> Output Class Initialized
INFO - 2025-05-23 15:11:46 --> Security Class Initialized
DEBUG - 2025-05-23 15:11:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 15:11:46 --> Input Class Initialized
INFO - 2025-05-23 15:11:46 --> Language Class Initialized
INFO - 2025-05-23 15:11:46 --> Loader Class Initialized
INFO - 2025-05-23 15:11:46 --> Helper loaded: url_helper
INFO - 2025-05-23 15:11:46 --> Helper loaded: form_helper
INFO - 2025-05-23 15:11:46 --> Database Driver Class Initialized
DEBUG - 2025-05-23 15:11:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 15:11:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 15:11:46 --> Controller Class Initialized
INFO - 2025-05-23 15:11:46 --> Model "Beta_model" initialized
INFO - 2025-05-23 15:11:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\menu.php
INFO - 2025-05-23 15:11:46 --> Final output sent to browser
DEBUG - 2025-05-23 15:11:46 --> Total execution time: 0.0770
INFO - 2025-05-23 15:11:49 --> Config Class Initialized
INFO - 2025-05-23 15:11:49 --> Hooks Class Initialized
DEBUG - 2025-05-23 15:11:49 --> UTF-8 Support Enabled
INFO - 2025-05-23 15:11:49 --> Utf8 Class Initialized
INFO - 2025-05-23 15:11:49 --> URI Class Initialized
INFO - 2025-05-23 15:11:49 --> Router Class Initialized
INFO - 2025-05-23 15:11:49 --> Output Class Initialized
INFO - 2025-05-23 15:11:49 --> Security Class Initialized
DEBUG - 2025-05-23 15:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 15:11:49 --> Input Class Initialized
INFO - 2025-05-23 15:11:49 --> Language Class Initialized
INFO - 2025-05-23 15:11:49 --> Loader Class Initialized
INFO - 2025-05-23 15:11:49 --> Helper loaded: url_helper
INFO - 2025-05-23 15:11:49 --> Helper loaded: form_helper
INFO - 2025-05-23 15:11:49 --> Database Driver Class Initialized
DEBUG - 2025-05-23 15:11:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 15:11:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 15:11:49 --> Controller Class Initialized
INFO - 2025-05-23 15:11:49 --> Model "Beta_model" initialized
INFO - 2025-05-23 15:11:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\menu.php
INFO - 2025-05-23 15:11:49 --> Final output sent to browser
DEBUG - 2025-05-23 15:11:49 --> Total execution time: 0.0589
INFO - 2025-05-23 15:11:52 --> Config Class Initialized
INFO - 2025-05-23 15:11:52 --> Hooks Class Initialized
DEBUG - 2025-05-23 15:11:52 --> UTF-8 Support Enabled
INFO - 2025-05-23 15:11:52 --> Utf8 Class Initialized
INFO - 2025-05-23 15:11:52 --> URI Class Initialized
INFO - 2025-05-23 15:11:52 --> Router Class Initialized
INFO - 2025-05-23 15:11:53 --> Output Class Initialized
INFO - 2025-05-23 15:11:53 --> Security Class Initialized
DEBUG - 2025-05-23 15:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 15:11:53 --> Input Class Initialized
INFO - 2025-05-23 15:11:53 --> Language Class Initialized
INFO - 2025-05-23 15:11:53 --> Loader Class Initialized
INFO - 2025-05-23 15:11:53 --> Helper loaded: url_helper
INFO - 2025-05-23 15:11:53 --> Helper loaded: form_helper
INFO - 2025-05-23 15:11:53 --> Database Driver Class Initialized
DEBUG - 2025-05-23 15:11:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 15:11:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 15:11:53 --> Controller Class Initialized
INFO - 2025-05-23 15:11:53 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\level.php
INFO - 2025-05-23 15:11:53 --> Final output sent to browser
DEBUG - 2025-05-23 15:11:53 --> Total execution time: 0.0786
INFO - 2025-05-23 15:11:55 --> Config Class Initialized
INFO - 2025-05-23 15:11:55 --> Hooks Class Initialized
DEBUG - 2025-05-23 15:11:55 --> UTF-8 Support Enabled
INFO - 2025-05-23 15:11:55 --> Utf8 Class Initialized
INFO - 2025-05-23 15:11:55 --> URI Class Initialized
INFO - 2025-05-23 15:11:55 --> Router Class Initialized
INFO - 2025-05-23 15:11:55 --> Output Class Initialized
INFO - 2025-05-23 15:11:55 --> Security Class Initialized
DEBUG - 2025-05-23 15:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 15:11:55 --> Input Class Initialized
INFO - 2025-05-23 15:11:55 --> Language Class Initialized
INFO - 2025-05-23 15:11:55 --> Loader Class Initialized
INFO - 2025-05-23 15:11:55 --> Helper loaded: url_helper
INFO - 2025-05-23 15:11:55 --> Helper loaded: form_helper
INFO - 2025-05-23 15:11:55 --> Database Driver Class Initialized
DEBUG - 2025-05-23 15:11:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 15:11:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 15:11:55 --> Controller Class Initialized
INFO - 2025-05-23 15:11:55 --> Model "Beta_model" initialized
INFO - 2025-05-23 15:11:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\menu.php
INFO - 2025-05-23 15:11:55 --> Final output sent to browser
DEBUG - 2025-05-23 15:11:55 --> Total execution time: 0.0595
INFO - 2025-05-23 15:11:58 --> Config Class Initialized
INFO - 2025-05-23 15:11:58 --> Hooks Class Initialized
DEBUG - 2025-05-23 15:11:58 --> UTF-8 Support Enabled
INFO - 2025-05-23 15:11:58 --> Utf8 Class Initialized
INFO - 2025-05-23 15:11:58 --> URI Class Initialized
INFO - 2025-05-23 15:11:58 --> Router Class Initialized
INFO - 2025-05-23 15:11:58 --> Output Class Initialized
INFO - 2025-05-23 15:11:58 --> Security Class Initialized
DEBUG - 2025-05-23 15:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 15:11:58 --> Input Class Initialized
INFO - 2025-05-23 15:11:58 --> Language Class Initialized
INFO - 2025-05-23 15:11:58 --> Loader Class Initialized
INFO - 2025-05-23 15:11:58 --> Helper loaded: url_helper
INFO - 2025-05-23 15:11:58 --> Helper loaded: form_helper
INFO - 2025-05-23 15:11:59 --> Database Driver Class Initialized
DEBUG - 2025-05-23 15:11:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 15:11:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 15:11:59 --> Controller Class Initialized
INFO - 2025-05-23 15:11:59 --> Model "Beta_model" initialized
INFO - 2025-05-23 15:11:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\menu.php
INFO - 2025-05-23 15:11:59 --> Final output sent to browser
DEBUG - 2025-05-23 15:11:59 --> Total execution time: 0.0728
INFO - 2025-05-23 15:40:23 --> Config Class Initialized
INFO - 2025-05-23 15:40:23 --> Hooks Class Initialized
DEBUG - 2025-05-23 15:40:23 --> UTF-8 Support Enabled
INFO - 2025-05-23 15:40:23 --> Utf8 Class Initialized
INFO - 2025-05-23 15:40:23 --> URI Class Initialized
DEBUG - 2025-05-23 15:40:23 --> No URI present. Default controller set.
INFO - 2025-05-23 15:40:23 --> Router Class Initialized
INFO - 2025-05-23 15:40:23 --> Output Class Initialized
INFO - 2025-05-23 15:40:23 --> Security Class Initialized
DEBUG - 2025-05-23 15:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 15:40:23 --> Input Class Initialized
INFO - 2025-05-23 15:40:23 --> Language Class Initialized
INFO - 2025-05-23 15:40:23 --> Loader Class Initialized
INFO - 2025-05-23 15:40:23 --> Helper loaded: url_helper
INFO - 2025-05-23 15:40:23 --> Helper loaded: form_helper
INFO - 2025-05-23 15:40:23 --> Database Driver Class Initialized
DEBUG - 2025-05-23 15:40:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 15:40:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 15:40:23 --> Controller Class Initialized
INFO - 2025-05-23 15:40:23 --> Model "User_model" initialized
INFO - 2025-05-23 15:40:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-23 15:40:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-23 15:40:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-23 15:40:23 --> Final output sent to browser
DEBUG - 2025-05-23 15:40:23 --> Total execution time: 0.0823
INFO - 2025-05-23 15:40:25 --> Config Class Initialized
INFO - 2025-05-23 15:40:25 --> Hooks Class Initialized
DEBUG - 2025-05-23 15:40:25 --> UTF-8 Support Enabled
INFO - 2025-05-23 15:40:25 --> Utf8 Class Initialized
INFO - 2025-05-23 15:40:25 --> URI Class Initialized
INFO - 2025-05-23 15:40:25 --> Router Class Initialized
INFO - 2025-05-23 15:40:25 --> Output Class Initialized
INFO - 2025-05-23 15:40:25 --> Security Class Initialized
DEBUG - 2025-05-23 15:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 15:40:25 --> Input Class Initialized
INFO - 2025-05-23 15:40:25 --> Language Class Initialized
INFO - 2025-05-23 15:40:25 --> Loader Class Initialized
INFO - 2025-05-23 15:40:25 --> Helper loaded: url_helper
INFO - 2025-05-23 15:40:25 --> Helper loaded: form_helper
INFO - 2025-05-23 15:40:25 --> Database Driver Class Initialized
DEBUG - 2025-05-23 15:40:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 15:40:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 15:40:25 --> Controller Class Initialized
INFO - 2025-05-23 15:40:25 --> Model "User_model" initialized
INFO - 2025-05-23 15:40:25 --> Model "Workout_model" initialized
INFO - 2025-05-23 15:40:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-23 15:40:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-23 15:40:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-23 15:40:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-23 15:40:25 --> Final output sent to browser
DEBUG - 2025-05-23 15:40:25 --> Total execution time: 0.0824
INFO - 2025-05-23 15:40:27 --> Config Class Initialized
INFO - 2025-05-23 15:40:27 --> Hooks Class Initialized
DEBUG - 2025-05-23 15:40:27 --> UTF-8 Support Enabled
INFO - 2025-05-23 15:40:27 --> Utf8 Class Initialized
INFO - 2025-05-23 15:40:27 --> URI Class Initialized
INFO - 2025-05-23 15:40:27 --> Router Class Initialized
INFO - 2025-05-23 15:40:27 --> Output Class Initialized
INFO - 2025-05-23 15:40:27 --> Security Class Initialized
DEBUG - 2025-05-23 15:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 15:40:27 --> Input Class Initialized
INFO - 2025-05-23 15:40:27 --> Language Class Initialized
INFO - 2025-05-23 15:40:27 --> Loader Class Initialized
INFO - 2025-05-23 15:40:27 --> Helper loaded: url_helper
INFO - 2025-05-23 15:40:27 --> Helper loaded: form_helper
INFO - 2025-05-23 15:40:27 --> Database Driver Class Initialized
DEBUG - 2025-05-23 15:40:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 15:40:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 15:40:27 --> Controller Class Initialized
INFO - 2025-05-23 15:40:27 --> Model "Olahraga_model" initialized
INFO - 2025-05-23 15:40:27 --> Model "User_model" initialized
INFO - 2025-05-23 15:40:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-23 15:40:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-23 15:40:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-05-23 15:40:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-23 15:40:27 --> Final output sent to browser
DEBUG - 2025-05-23 15:40:27 --> Total execution time: 0.0591
INFO - 2025-05-23 15:40:31 --> Config Class Initialized
INFO - 2025-05-23 15:40:31 --> Hooks Class Initialized
DEBUG - 2025-05-23 15:40:31 --> UTF-8 Support Enabled
INFO - 2025-05-23 15:40:31 --> Utf8 Class Initialized
INFO - 2025-05-23 15:40:31 --> URI Class Initialized
INFO - 2025-05-23 15:40:31 --> Router Class Initialized
INFO - 2025-05-23 15:40:31 --> Output Class Initialized
INFO - 2025-05-23 15:40:31 --> Security Class Initialized
DEBUG - 2025-05-23 15:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 15:40:31 --> Input Class Initialized
INFO - 2025-05-23 15:40:31 --> Language Class Initialized
INFO - 2025-05-23 15:40:31 --> Loader Class Initialized
INFO - 2025-05-23 15:40:31 --> Helper loaded: url_helper
INFO - 2025-05-23 15:40:31 --> Helper loaded: form_helper
INFO - 2025-05-23 15:40:31 --> Database Driver Class Initialized
DEBUG - 2025-05-23 15:40:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 15:40:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 15:40:31 --> Controller Class Initialized
INFO - 2025-05-23 15:40:31 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\level.php
INFO - 2025-05-23 15:40:31 --> Final output sent to browser
DEBUG - 2025-05-23 15:40:31 --> Total execution time: 0.0610
INFO - 2025-05-23 15:41:27 --> Config Class Initialized
INFO - 2025-05-23 15:41:27 --> Hooks Class Initialized
DEBUG - 2025-05-23 15:41:27 --> UTF-8 Support Enabled
INFO - 2025-05-23 15:41:27 --> Utf8 Class Initialized
INFO - 2025-05-23 15:41:27 --> URI Class Initialized
INFO - 2025-05-23 15:41:27 --> Router Class Initialized
INFO - 2025-05-23 15:41:27 --> Output Class Initialized
INFO - 2025-05-23 15:41:27 --> Security Class Initialized
DEBUG - 2025-05-23 15:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 15:41:27 --> Input Class Initialized
INFO - 2025-05-23 15:41:27 --> Language Class Initialized
INFO - 2025-05-23 15:41:27 --> Loader Class Initialized
INFO - 2025-05-23 15:41:27 --> Helper loaded: url_helper
INFO - 2025-05-23 15:41:27 --> Helper loaded: form_helper
INFO - 2025-05-23 15:41:27 --> Database Driver Class Initialized
DEBUG - 2025-05-23 15:41:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 15:41:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 15:41:27 --> Controller Class Initialized
INFO - 2025-05-23 15:41:27 --> Model "Olahraga_model" initialized
INFO - 2025-05-23 15:41:27 --> Model "User_model" initialized
INFO - 2025-05-23 15:41:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-23 15:41:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-23 15:41:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-05-23 15:41:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-23 15:41:27 --> Final output sent to browser
DEBUG - 2025-05-23 15:41:27 --> Total execution time: 0.0718
INFO - 2025-05-23 15:41:28 --> Config Class Initialized
INFO - 2025-05-23 15:41:28 --> Hooks Class Initialized
DEBUG - 2025-05-23 15:41:28 --> UTF-8 Support Enabled
INFO - 2025-05-23 15:41:28 --> Utf8 Class Initialized
INFO - 2025-05-23 15:41:28 --> URI Class Initialized
INFO - 2025-05-23 15:41:28 --> Router Class Initialized
INFO - 2025-05-23 15:41:28 --> Output Class Initialized
INFO - 2025-05-23 15:41:28 --> Security Class Initialized
DEBUG - 2025-05-23 15:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 15:41:28 --> Input Class Initialized
INFO - 2025-05-23 15:41:28 --> Language Class Initialized
INFO - 2025-05-23 15:41:28 --> Loader Class Initialized
INFO - 2025-05-23 15:41:28 --> Helper loaded: url_helper
INFO - 2025-05-23 15:41:28 --> Helper loaded: form_helper
INFO - 2025-05-23 15:41:28 --> Database Driver Class Initialized
DEBUG - 2025-05-23 15:41:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 15:41:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 15:41:28 --> Controller Class Initialized
INFO - 2025-05-23 15:41:28 --> Model "Olahraga_model" initialized
INFO - 2025-05-23 15:41:28 --> Model "User_model" initialized
INFO - 2025-05-23 15:41:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-23 15:41:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-23 15:41:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-05-23 15:41:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-23 15:41:28 --> Final output sent to browser
DEBUG - 2025-05-23 15:41:28 --> Total execution time: 0.0847
INFO - 2025-05-23 15:41:30 --> Config Class Initialized
INFO - 2025-05-23 15:41:30 --> Hooks Class Initialized
DEBUG - 2025-05-23 15:41:30 --> UTF-8 Support Enabled
INFO - 2025-05-23 15:41:30 --> Utf8 Class Initialized
INFO - 2025-05-23 15:41:30 --> URI Class Initialized
INFO - 2025-05-23 15:41:30 --> Router Class Initialized
INFO - 2025-05-23 15:41:30 --> Output Class Initialized
INFO - 2025-05-23 15:41:30 --> Security Class Initialized
DEBUG - 2025-05-23 15:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 15:41:30 --> Input Class Initialized
INFO - 2025-05-23 15:41:30 --> Language Class Initialized
INFO - 2025-05-23 15:41:30 --> Loader Class Initialized
INFO - 2025-05-23 15:41:30 --> Helper loaded: url_helper
INFO - 2025-05-23 15:41:30 --> Helper loaded: form_helper
INFO - 2025-05-23 15:41:30 --> Database Driver Class Initialized
DEBUG - 2025-05-23 15:41:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 15:41:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 15:41:30 --> Controller Class Initialized
INFO - 2025-05-23 15:41:30 --> Model "Olahraga_model" initialized
INFO - 2025-05-23 15:41:30 --> Model "User_model" initialized
INFO - 2025-05-23 15:41:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-23 15:41:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-23 15:41:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-05-23 15:41:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-23 15:41:30 --> Final output sent to browser
DEBUG - 2025-05-23 15:41:30 --> Total execution time: 0.0687
INFO - 2025-05-23 15:42:45 --> Config Class Initialized
INFO - 2025-05-23 15:42:45 --> Hooks Class Initialized
DEBUG - 2025-05-23 15:42:45 --> UTF-8 Support Enabled
INFO - 2025-05-23 15:42:45 --> Utf8 Class Initialized
INFO - 2025-05-23 15:42:45 --> URI Class Initialized
INFO - 2025-05-23 15:42:45 --> Router Class Initialized
INFO - 2025-05-23 15:42:45 --> Output Class Initialized
INFO - 2025-05-23 15:42:45 --> Security Class Initialized
DEBUG - 2025-05-23 15:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 15:42:45 --> Input Class Initialized
INFO - 2025-05-23 15:42:45 --> Language Class Initialized
INFO - 2025-05-23 15:42:45 --> Loader Class Initialized
INFO - 2025-05-23 15:42:45 --> Helper loaded: url_helper
INFO - 2025-05-23 15:42:45 --> Helper loaded: form_helper
INFO - 2025-05-23 15:42:45 --> Database Driver Class Initialized
DEBUG - 2025-05-23 15:42:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 15:42:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 15:42:45 --> Controller Class Initialized
INFO - 2025-05-23 15:42:45 --> Model "Progress_model" initialized
INFO - 2025-05-23 15:42:45 --> Model "User_model" initialized
INFO - 2025-05-23 15:42:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-23 15:42:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-23 15:42:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-23 15:42:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-23 15:42:45 --> Final output sent to browser
DEBUG - 2025-05-23 15:42:45 --> Total execution time: 0.0710
INFO - 2025-05-23 15:42:45 --> Config Class Initialized
INFO - 2025-05-23 15:42:45 --> Hooks Class Initialized
DEBUG - 2025-05-23 15:42:45 --> UTF-8 Support Enabled
INFO - 2025-05-23 15:42:45 --> Utf8 Class Initialized
INFO - 2025-05-23 15:42:45 --> URI Class Initialized
INFO - 2025-05-23 15:42:45 --> Router Class Initialized
INFO - 2025-05-23 15:42:45 --> Output Class Initialized
INFO - 2025-05-23 15:42:45 --> Security Class Initialized
DEBUG - 2025-05-23 15:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 15:42:45 --> Input Class Initialized
INFO - 2025-05-23 15:42:45 --> Language Class Initialized
INFO - 2025-05-23 15:42:45 --> Loader Class Initialized
INFO - 2025-05-23 15:42:45 --> Helper loaded: url_helper
INFO - 2025-05-23 15:42:45 --> Helper loaded: form_helper
INFO - 2025-05-23 15:42:45 --> Database Driver Class Initialized
DEBUG - 2025-05-23 15:42:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 15:42:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 15:42:46 --> Controller Class Initialized
INFO - 2025-05-23 15:42:46 --> Model "Progress_model" initialized
INFO - 2025-05-23 15:42:46 --> Model "User_model" initialized
INFO - 2025-05-23 15:42:46 --> Final output sent to browser
DEBUG - 2025-05-23 15:42:46 --> Total execution time: 0.0882
INFO - 2025-05-23 15:42:46 --> Config Class Initialized
INFO - 2025-05-23 15:42:46 --> Hooks Class Initialized
DEBUG - 2025-05-23 15:42:46 --> UTF-8 Support Enabled
INFO - 2025-05-23 15:42:46 --> Utf8 Class Initialized
INFO - 2025-05-23 15:42:46 --> URI Class Initialized
INFO - 2025-05-23 15:42:46 --> Router Class Initialized
INFO - 2025-05-23 15:42:46 --> Output Class Initialized
INFO - 2025-05-23 15:42:46 --> Security Class Initialized
DEBUG - 2025-05-23 15:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 15:42:46 --> Input Class Initialized
INFO - 2025-05-23 15:42:46 --> Language Class Initialized
INFO - 2025-05-23 15:42:46 --> Loader Class Initialized
INFO - 2025-05-23 15:42:46 --> Helper loaded: url_helper
INFO - 2025-05-23 15:42:46 --> Helper loaded: form_helper
INFO - 2025-05-23 15:42:46 --> Database Driver Class Initialized
DEBUG - 2025-05-23 15:42:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 15:42:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 15:42:46 --> Controller Class Initialized
INFO - 2025-05-23 15:42:46 --> Model "Olahraga_model" initialized
INFO - 2025-05-23 15:42:46 --> Model "User_model" initialized
INFO - 2025-05-23 15:42:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-23 15:42:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-23 15:42:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-05-23 15:42:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-23 15:42:46 --> Final output sent to browser
DEBUG - 2025-05-23 15:42:46 --> Total execution time: 0.0727
INFO - 2025-05-23 15:42:49 --> Config Class Initialized
INFO - 2025-05-23 15:42:49 --> Hooks Class Initialized
DEBUG - 2025-05-23 15:42:49 --> UTF-8 Support Enabled
INFO - 2025-05-23 15:42:49 --> Utf8 Class Initialized
INFO - 2025-05-23 15:42:49 --> URI Class Initialized
INFO - 2025-05-23 15:42:49 --> Router Class Initialized
INFO - 2025-05-23 15:42:49 --> Output Class Initialized
INFO - 2025-05-23 15:42:49 --> Security Class Initialized
DEBUG - 2025-05-23 15:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 15:42:49 --> Input Class Initialized
INFO - 2025-05-23 15:42:49 --> Language Class Initialized
INFO - 2025-05-23 15:42:49 --> Loader Class Initialized
INFO - 2025-05-23 15:42:49 --> Helper loaded: url_helper
INFO - 2025-05-23 15:42:49 --> Helper loaded: form_helper
INFO - 2025-05-23 15:42:49 --> Database Driver Class Initialized
DEBUG - 2025-05-23 15:42:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 15:42:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 15:42:49 --> Controller Class Initialized
INFO - 2025-05-23 15:42:49 --> Model "Olahraga_model" initialized
INFO - 2025-05-23 15:42:49 --> Model "User_model" initialized
INFO - 2025-05-23 15:42:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-23 15:42:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-23 15:42:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-05-23 15:42:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-23 15:42:49 --> Final output sent to browser
DEBUG - 2025-05-23 15:42:49 --> Total execution time: 0.0668
INFO - 2025-05-23 15:43:26 --> Config Class Initialized
INFO - 2025-05-23 15:43:26 --> Hooks Class Initialized
DEBUG - 2025-05-23 15:43:26 --> UTF-8 Support Enabled
INFO - 2025-05-23 15:43:26 --> Utf8 Class Initialized
INFO - 2025-05-23 15:43:26 --> URI Class Initialized
INFO - 2025-05-23 15:43:26 --> Router Class Initialized
INFO - 2025-05-23 15:43:26 --> Output Class Initialized
INFO - 2025-05-23 15:43:26 --> Security Class Initialized
DEBUG - 2025-05-23 15:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 15:43:26 --> Input Class Initialized
INFO - 2025-05-23 15:43:26 --> Language Class Initialized
INFO - 2025-05-23 15:43:26 --> Loader Class Initialized
INFO - 2025-05-23 15:43:26 --> Helper loaded: url_helper
INFO - 2025-05-23 15:43:26 --> Helper loaded: form_helper
INFO - 2025-05-23 15:43:26 --> Database Driver Class Initialized
DEBUG - 2025-05-23 15:43:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 15:43:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 15:43:26 --> Controller Class Initialized
INFO - 2025-05-23 15:43:26 --> Model "Olahraga_model" initialized
INFO - 2025-05-23 15:43:26 --> Model "User_model" initialized
INFO - 2025-05-23 15:43:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-23 15:43:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-23 15:43:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-05-23 15:43:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-23 15:43:26 --> Final output sent to browser
DEBUG - 2025-05-23 15:43:26 --> Total execution time: 0.0756
INFO - 2025-05-23 15:43:44 --> Config Class Initialized
INFO - 2025-05-23 15:43:44 --> Hooks Class Initialized
DEBUG - 2025-05-23 15:43:44 --> UTF-8 Support Enabled
INFO - 2025-05-23 15:43:44 --> Utf8 Class Initialized
INFO - 2025-05-23 15:43:44 --> URI Class Initialized
INFO - 2025-05-23 15:43:44 --> Router Class Initialized
INFO - 2025-05-23 15:43:44 --> Output Class Initialized
INFO - 2025-05-23 15:43:44 --> Security Class Initialized
DEBUG - 2025-05-23 15:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 15:43:44 --> Input Class Initialized
INFO - 2025-05-23 15:43:44 --> Language Class Initialized
INFO - 2025-05-23 15:43:44 --> Loader Class Initialized
INFO - 2025-05-23 15:43:44 --> Helper loaded: url_helper
INFO - 2025-05-23 15:43:44 --> Helper loaded: form_helper
INFO - 2025-05-23 15:43:44 --> Database Driver Class Initialized
DEBUG - 2025-05-23 15:43:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 15:43:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 15:43:44 --> Controller Class Initialized
INFO - 2025-05-23 15:43:44 --> Model "Olahraga_model" initialized
INFO - 2025-05-23 15:43:44 --> Model "User_model" initialized
INFO - 2025-05-23 15:43:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-23 15:43:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-23 15:43:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-05-23 15:43:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-23 15:43:44 --> Final output sent to browser
DEBUG - 2025-05-23 15:43:44 --> Total execution time: 0.0660
INFO - 2025-05-23 15:44:13 --> Config Class Initialized
INFO - 2025-05-23 15:44:13 --> Hooks Class Initialized
DEBUG - 2025-05-23 15:44:13 --> UTF-8 Support Enabled
INFO - 2025-05-23 15:44:13 --> Utf8 Class Initialized
INFO - 2025-05-23 15:44:13 --> URI Class Initialized
INFO - 2025-05-23 15:44:13 --> Router Class Initialized
INFO - 2025-05-23 15:44:13 --> Output Class Initialized
INFO - 2025-05-23 15:44:13 --> Security Class Initialized
DEBUG - 2025-05-23 15:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 15:44:13 --> Input Class Initialized
INFO - 2025-05-23 15:44:13 --> Language Class Initialized
INFO - 2025-05-23 15:44:13 --> Loader Class Initialized
INFO - 2025-05-23 15:44:13 --> Helper loaded: url_helper
INFO - 2025-05-23 15:44:13 --> Helper loaded: form_helper
INFO - 2025-05-23 15:44:13 --> Database Driver Class Initialized
DEBUG - 2025-05-23 15:44:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 15:44:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 15:44:13 --> Controller Class Initialized
INFO - 2025-05-23 15:44:13 --> Model "Olahraga_model" initialized
INFO - 2025-05-23 15:44:13 --> Model "User_model" initialized
INFO - 2025-05-23 15:44:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-23 15:44:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-23 15:44:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-05-23 15:44:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-23 15:44:13 --> Final output sent to browser
DEBUG - 2025-05-23 15:44:13 --> Total execution time: 0.0779
INFO - 2025-05-23 15:46:54 --> Config Class Initialized
INFO - 2025-05-23 15:46:54 --> Hooks Class Initialized
DEBUG - 2025-05-23 15:46:54 --> UTF-8 Support Enabled
INFO - 2025-05-23 15:46:54 --> Utf8 Class Initialized
INFO - 2025-05-23 15:46:54 --> URI Class Initialized
INFO - 2025-05-23 15:46:54 --> Router Class Initialized
INFO - 2025-05-23 15:46:54 --> Output Class Initialized
INFO - 2025-05-23 15:46:54 --> Security Class Initialized
DEBUG - 2025-05-23 15:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 15:46:54 --> Input Class Initialized
INFO - 2025-05-23 15:46:54 --> Language Class Initialized
INFO - 2025-05-23 15:46:54 --> Loader Class Initialized
INFO - 2025-05-23 15:46:54 --> Helper loaded: url_helper
INFO - 2025-05-23 15:46:54 --> Helper loaded: form_helper
INFO - 2025-05-23 15:46:54 --> Database Driver Class Initialized
DEBUG - 2025-05-23 15:46:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 15:46:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 15:46:54 --> Controller Class Initialized
INFO - 2025-05-23 15:46:54 --> Model "Olahraga_model" initialized
INFO - 2025-05-23 15:46:54 --> Model "User_model" initialized
INFO - 2025-05-23 15:46:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-23 15:46:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-23 15:46:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-05-23 15:46:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-23 15:46:54 --> Final output sent to browser
DEBUG - 2025-05-23 15:46:54 --> Total execution time: 0.0929
INFO - 2025-05-23 15:46:58 --> Config Class Initialized
INFO - 2025-05-23 15:46:58 --> Hooks Class Initialized
DEBUG - 2025-05-23 15:46:58 --> UTF-8 Support Enabled
INFO - 2025-05-23 15:46:58 --> Utf8 Class Initialized
INFO - 2025-05-23 15:46:58 --> URI Class Initialized
INFO - 2025-05-23 15:46:58 --> Router Class Initialized
INFO - 2025-05-23 15:46:58 --> Output Class Initialized
INFO - 2025-05-23 15:46:58 --> Security Class Initialized
DEBUG - 2025-05-23 15:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 15:46:58 --> Input Class Initialized
INFO - 2025-05-23 15:46:58 --> Language Class Initialized
INFO - 2025-05-23 15:46:58 --> Loader Class Initialized
INFO - 2025-05-23 15:46:58 --> Helper loaded: url_helper
INFO - 2025-05-23 15:46:58 --> Helper loaded: form_helper
INFO - 2025-05-23 15:46:58 --> Database Driver Class Initialized
DEBUG - 2025-05-23 15:46:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 15:46:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 15:46:58 --> Controller Class Initialized
INFO - 2025-05-23 15:46:58 --> Model "Olahraga_model" initialized
INFO - 2025-05-23 15:46:58 --> Model "User_model" initialized
INFO - 2025-05-23 15:46:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-23 15:46:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-23 15:46:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-05-23 15:46:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-23 15:46:58 --> Final output sent to browser
DEBUG - 2025-05-23 15:46:58 --> Total execution time: 0.0758
INFO - 2025-05-23 15:47:01 --> Config Class Initialized
INFO - 2025-05-23 15:47:01 --> Hooks Class Initialized
DEBUG - 2025-05-23 15:47:01 --> UTF-8 Support Enabled
INFO - 2025-05-23 15:47:01 --> Utf8 Class Initialized
INFO - 2025-05-23 15:47:01 --> URI Class Initialized
INFO - 2025-05-23 15:47:01 --> Router Class Initialized
INFO - 2025-05-23 15:47:01 --> Output Class Initialized
INFO - 2025-05-23 15:47:01 --> Security Class Initialized
DEBUG - 2025-05-23 15:47:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 15:47:01 --> Input Class Initialized
INFO - 2025-05-23 15:47:01 --> Language Class Initialized
INFO - 2025-05-23 15:47:01 --> Loader Class Initialized
INFO - 2025-05-23 15:47:01 --> Helper loaded: url_helper
INFO - 2025-05-23 15:47:01 --> Helper loaded: form_helper
INFO - 2025-05-23 15:47:01 --> Database Driver Class Initialized
DEBUG - 2025-05-23 15:47:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 15:47:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 15:47:01 --> Controller Class Initialized
INFO - 2025-05-23 15:47:01 --> Model "Olahraga_model" initialized
INFO - 2025-05-23 15:47:01 --> Model "User_model" initialized
INFO - 2025-05-23 15:47:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-23 15:47:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-23 15:47:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-05-23 15:47:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-23 15:47:01 --> Final output sent to browser
DEBUG - 2025-05-23 15:47:01 --> Total execution time: 0.0985
INFO - 2025-05-23 15:47:04 --> Config Class Initialized
INFO - 2025-05-23 15:47:04 --> Hooks Class Initialized
DEBUG - 2025-05-23 15:47:04 --> UTF-8 Support Enabled
INFO - 2025-05-23 15:47:04 --> Utf8 Class Initialized
INFO - 2025-05-23 15:47:04 --> URI Class Initialized
INFO - 2025-05-23 15:47:04 --> Router Class Initialized
INFO - 2025-05-23 15:47:04 --> Output Class Initialized
INFO - 2025-05-23 15:47:04 --> Security Class Initialized
DEBUG - 2025-05-23 15:47:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 15:47:04 --> Input Class Initialized
INFO - 2025-05-23 15:47:04 --> Language Class Initialized
INFO - 2025-05-23 15:47:04 --> Loader Class Initialized
INFO - 2025-05-23 15:47:04 --> Helper loaded: url_helper
INFO - 2025-05-23 15:47:04 --> Helper loaded: form_helper
INFO - 2025-05-23 15:47:04 --> Database Driver Class Initialized
DEBUG - 2025-05-23 15:47:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 15:47:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 15:47:04 --> Controller Class Initialized
INFO - 2025-05-23 15:47:04 --> Model "Olahraga_model" initialized
INFO - 2025-05-23 15:47:04 --> Model "User_model" initialized
INFO - 2025-05-23 15:47:04 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\menu.php
INFO - 2025-05-23 15:47:04 --> Final output sent to browser
DEBUG - 2025-05-23 15:47:04 --> Total execution time: 0.0594
INFO - 2025-05-23 15:47:08 --> Config Class Initialized
INFO - 2025-05-23 15:47:08 --> Hooks Class Initialized
DEBUG - 2025-05-23 15:47:08 --> UTF-8 Support Enabled
INFO - 2025-05-23 15:47:08 --> Utf8 Class Initialized
INFO - 2025-05-23 15:47:08 --> URI Class Initialized
INFO - 2025-05-23 15:47:08 --> Router Class Initialized
INFO - 2025-05-23 15:47:08 --> Output Class Initialized
INFO - 2025-05-23 15:47:08 --> Security Class Initialized
DEBUG - 2025-05-23 15:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 15:47:08 --> Input Class Initialized
INFO - 2025-05-23 15:47:08 --> Language Class Initialized
INFO - 2025-05-23 15:47:08 --> Loader Class Initialized
INFO - 2025-05-23 15:47:08 --> Helper loaded: url_helper
INFO - 2025-05-23 15:47:08 --> Helper loaded: form_helper
INFO - 2025-05-23 15:47:08 --> Database Driver Class Initialized
DEBUG - 2025-05-23 15:47:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 15:47:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 15:47:08 --> Controller Class Initialized
INFO - 2025-05-23 15:47:08 --> Model "Olahraga_model" initialized
INFO - 2025-05-23 15:47:08 --> Model "User_model" initialized
INFO - 2025-05-23 15:47:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\menu.php
INFO - 2025-05-23 15:47:08 --> Final output sent to browser
DEBUG - 2025-05-23 15:47:08 --> Total execution time: 0.0589
INFO - 2025-05-23 15:47:12 --> Config Class Initialized
INFO - 2025-05-23 15:47:12 --> Hooks Class Initialized
DEBUG - 2025-05-23 15:47:12 --> UTF-8 Support Enabled
INFO - 2025-05-23 15:47:12 --> Utf8 Class Initialized
INFO - 2025-05-23 15:47:12 --> URI Class Initialized
INFO - 2025-05-23 15:47:12 --> Router Class Initialized
INFO - 2025-05-23 15:47:12 --> Output Class Initialized
INFO - 2025-05-23 15:47:12 --> Security Class Initialized
DEBUG - 2025-05-23 15:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 15:47:12 --> Input Class Initialized
INFO - 2025-05-23 15:47:12 --> Language Class Initialized
INFO - 2025-05-23 15:47:12 --> Loader Class Initialized
INFO - 2025-05-23 15:47:12 --> Helper loaded: url_helper
INFO - 2025-05-23 15:47:12 --> Helper loaded: form_helper
INFO - 2025-05-23 15:47:12 --> Database Driver Class Initialized
DEBUG - 2025-05-23 15:47:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 15:47:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 15:47:12 --> Controller Class Initialized
INFO - 2025-05-23 15:47:12 --> Model "Olahraga_model" initialized
INFO - 2025-05-23 15:47:12 --> Model "User_model" initialized
INFO - 2025-05-23 15:47:12 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-23 15:47:12 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-23 15:47:12 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-05-23 15:47:12 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-23 15:47:12 --> Final output sent to browser
DEBUG - 2025-05-23 15:47:12 --> Total execution time: 0.0664
INFO - 2025-05-23 15:47:14 --> Config Class Initialized
INFO - 2025-05-23 15:47:14 --> Hooks Class Initialized
DEBUG - 2025-05-23 15:47:14 --> UTF-8 Support Enabled
INFO - 2025-05-23 15:47:14 --> Utf8 Class Initialized
INFO - 2025-05-23 15:47:14 --> URI Class Initialized
INFO - 2025-05-23 15:47:14 --> Router Class Initialized
INFO - 2025-05-23 15:47:14 --> Output Class Initialized
INFO - 2025-05-23 15:47:14 --> Security Class Initialized
DEBUG - 2025-05-23 15:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 15:47:14 --> Input Class Initialized
INFO - 2025-05-23 15:47:14 --> Language Class Initialized
INFO - 2025-05-23 15:47:14 --> Loader Class Initialized
INFO - 2025-05-23 15:47:14 --> Helper loaded: url_helper
INFO - 2025-05-23 15:47:14 --> Helper loaded: form_helper
INFO - 2025-05-23 15:47:14 --> Database Driver Class Initialized
DEBUG - 2025-05-23 15:47:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 15:47:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 15:47:14 --> Controller Class Initialized
INFO - 2025-05-23 15:47:14 --> Model "Olahraga_model" initialized
INFO - 2025-05-23 15:47:14 --> Model "User_model" initialized
INFO - 2025-05-23 15:47:14 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\menu.php
INFO - 2025-05-23 15:47:14 --> Final output sent to browser
DEBUG - 2025-05-23 15:47:14 --> Total execution time: 0.0545
INFO - 2025-05-23 15:47:17 --> Config Class Initialized
INFO - 2025-05-23 15:47:17 --> Hooks Class Initialized
DEBUG - 2025-05-23 15:47:17 --> UTF-8 Support Enabled
INFO - 2025-05-23 15:47:17 --> Utf8 Class Initialized
INFO - 2025-05-23 15:47:17 --> URI Class Initialized
INFO - 2025-05-23 15:47:17 --> Router Class Initialized
INFO - 2025-05-23 15:47:17 --> Output Class Initialized
INFO - 2025-05-23 15:47:17 --> Security Class Initialized
DEBUG - 2025-05-23 15:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 15:47:17 --> Input Class Initialized
INFO - 2025-05-23 15:47:17 --> Language Class Initialized
INFO - 2025-05-23 15:47:17 --> Loader Class Initialized
INFO - 2025-05-23 15:47:17 --> Helper loaded: url_helper
INFO - 2025-05-23 15:47:17 --> Helper loaded: form_helper
INFO - 2025-05-23 15:47:17 --> Database Driver Class Initialized
DEBUG - 2025-05-23 15:47:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 15:47:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 15:47:17 --> Controller Class Initialized
INFO - 2025-05-23 15:47:17 --> Model "Olahraga_model" initialized
INFO - 2025-05-23 15:47:17 --> Model "User_model" initialized
INFO - 2025-05-23 15:47:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\menu.php
INFO - 2025-05-23 15:47:17 --> Final output sent to browser
DEBUG - 2025-05-23 15:47:17 --> Total execution time: 0.0750
INFO - 2025-05-23 15:54:25 --> Config Class Initialized
INFO - 2025-05-23 15:54:25 --> Hooks Class Initialized
DEBUG - 2025-05-23 15:54:25 --> UTF-8 Support Enabled
INFO - 2025-05-23 15:54:25 --> Utf8 Class Initialized
INFO - 2025-05-23 15:54:25 --> URI Class Initialized
INFO - 2025-05-23 15:54:25 --> Router Class Initialized
INFO - 2025-05-23 15:54:25 --> Output Class Initialized
INFO - 2025-05-23 15:54:25 --> Security Class Initialized
DEBUG - 2025-05-23 15:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 15:54:25 --> Input Class Initialized
INFO - 2025-05-23 15:54:25 --> Language Class Initialized
INFO - 2025-05-23 15:54:25 --> Loader Class Initialized
INFO - 2025-05-23 15:54:25 --> Helper loaded: url_helper
INFO - 2025-05-23 15:54:25 --> Helper loaded: form_helper
INFO - 2025-05-23 15:54:25 --> Database Driver Class Initialized
DEBUG - 2025-05-23 15:54:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 15:54:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 15:54:25 --> Controller Class Initialized
INFO - 2025-05-23 15:54:25 --> Model "Olahraga_model" initialized
INFO - 2025-05-23 15:54:25 --> Model "User_model" initialized
INFO - 2025-05-23 15:54:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-23 15:54:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-23 15:54:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-05-23 15:54:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-23 15:54:25 --> Final output sent to browser
DEBUG - 2025-05-23 15:54:25 --> Total execution time: 0.0786
INFO - 2025-05-23 15:54:26 --> Config Class Initialized
INFO - 2025-05-23 15:54:26 --> Hooks Class Initialized
DEBUG - 2025-05-23 15:54:26 --> UTF-8 Support Enabled
INFO - 2025-05-23 15:54:26 --> Utf8 Class Initialized
INFO - 2025-05-23 15:54:26 --> URI Class Initialized
INFO - 2025-05-23 15:54:26 --> Router Class Initialized
INFO - 2025-05-23 15:54:26 --> Output Class Initialized
INFO - 2025-05-23 15:54:26 --> Security Class Initialized
DEBUG - 2025-05-23 15:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 15:54:26 --> Input Class Initialized
INFO - 2025-05-23 15:54:26 --> Language Class Initialized
INFO - 2025-05-23 15:54:26 --> Loader Class Initialized
INFO - 2025-05-23 15:54:26 --> Helper loaded: url_helper
INFO - 2025-05-23 15:54:26 --> Helper loaded: form_helper
INFO - 2025-05-23 15:54:26 --> Database Driver Class Initialized
DEBUG - 2025-05-23 15:54:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 15:54:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 15:54:26 --> Controller Class Initialized
INFO - 2025-05-23 15:54:26 --> Model "Olahraga_model" initialized
INFO - 2025-05-23 15:54:26 --> Model "User_model" initialized
INFO - 2025-05-23 15:54:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-23 15:54:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-23 15:54:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/menu.php
INFO - 2025-05-23 15:54:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-23 15:54:26 --> Final output sent to browser
DEBUG - 2025-05-23 15:54:26 --> Total execution time: 0.0701
INFO - 2025-05-23 15:55:46 --> Config Class Initialized
INFO - 2025-05-23 15:55:46 --> Hooks Class Initialized
DEBUG - 2025-05-23 15:55:46 --> UTF-8 Support Enabled
INFO - 2025-05-23 15:55:46 --> Utf8 Class Initialized
INFO - 2025-05-23 15:55:46 --> URI Class Initialized
INFO - 2025-05-23 15:55:46 --> Router Class Initialized
INFO - 2025-05-23 15:55:46 --> Output Class Initialized
INFO - 2025-05-23 15:55:46 --> Security Class Initialized
DEBUG - 2025-05-23 15:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 15:55:46 --> Input Class Initialized
INFO - 2025-05-23 15:55:46 --> Language Class Initialized
INFO - 2025-05-23 15:55:46 --> Loader Class Initialized
INFO - 2025-05-23 15:55:46 --> Helper loaded: url_helper
INFO - 2025-05-23 15:55:46 --> Helper loaded: form_helper
INFO - 2025-05-23 15:55:46 --> Database Driver Class Initialized
DEBUG - 2025-05-23 15:55:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 15:55:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 15:55:46 --> Controller Class Initialized
INFO - 2025-05-23 15:55:46 --> Model "Olahraga_model" initialized
INFO - 2025-05-23 15:55:46 --> Model "User_model" initialized
INFO - 2025-05-23 15:55:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-23 15:55:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-23 15:55:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/menu.php
INFO - 2025-05-23 15:55:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-23 15:55:46 --> Final output sent to browser
DEBUG - 2025-05-23 15:55:46 --> Total execution time: 0.0828
INFO - 2025-05-23 15:55:59 --> Config Class Initialized
INFO - 2025-05-23 15:55:59 --> Hooks Class Initialized
DEBUG - 2025-05-23 15:55:59 --> UTF-8 Support Enabled
INFO - 2025-05-23 15:55:59 --> Utf8 Class Initialized
INFO - 2025-05-23 15:55:59 --> URI Class Initialized
INFO - 2025-05-23 15:55:59 --> Router Class Initialized
INFO - 2025-05-23 15:55:59 --> Output Class Initialized
INFO - 2025-05-23 15:55:59 --> Security Class Initialized
DEBUG - 2025-05-23 15:55:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 15:55:59 --> Input Class Initialized
INFO - 2025-05-23 15:55:59 --> Language Class Initialized
INFO - 2025-05-23 15:55:59 --> Loader Class Initialized
INFO - 2025-05-23 15:55:59 --> Helper loaded: url_helper
INFO - 2025-05-23 15:55:59 --> Helper loaded: form_helper
INFO - 2025-05-23 15:55:59 --> Database Driver Class Initialized
DEBUG - 2025-05-23 15:55:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 15:55:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 15:55:59 --> Controller Class Initialized
INFO - 2025-05-23 15:55:59 --> Model "Olahraga_model" initialized
INFO - 2025-05-23 15:55:59 --> Model "User_model" initialized
INFO - 2025-05-23 15:55:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-23 15:55:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-23 15:55:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-05-23 15:55:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-23 15:55:59 --> Final output sent to browser
DEBUG - 2025-05-23 15:55:59 --> Total execution time: 0.0773
INFO - 2025-05-23 15:56:01 --> Config Class Initialized
INFO - 2025-05-23 15:56:01 --> Hooks Class Initialized
DEBUG - 2025-05-23 15:56:01 --> UTF-8 Support Enabled
INFO - 2025-05-23 15:56:01 --> Utf8 Class Initialized
INFO - 2025-05-23 15:56:01 --> URI Class Initialized
INFO - 2025-05-23 15:56:01 --> Router Class Initialized
INFO - 2025-05-23 15:56:01 --> Output Class Initialized
INFO - 2025-05-23 15:56:01 --> Security Class Initialized
DEBUG - 2025-05-23 15:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 15:56:01 --> Input Class Initialized
INFO - 2025-05-23 15:56:01 --> Language Class Initialized
INFO - 2025-05-23 15:56:01 --> Loader Class Initialized
INFO - 2025-05-23 15:56:01 --> Helper loaded: url_helper
INFO - 2025-05-23 15:56:01 --> Helper loaded: form_helper
INFO - 2025-05-23 15:56:01 --> Database Driver Class Initialized
DEBUG - 2025-05-23 15:56:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 15:56:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 15:56:01 --> Controller Class Initialized
INFO - 2025-05-23 15:56:01 --> Model "Olahraga_model" initialized
INFO - 2025-05-23 15:56:01 --> Model "User_model" initialized
INFO - 2025-05-23 15:56:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-23 15:56:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-23 15:56:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-05-23 15:56:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-23 15:56:01 --> Final output sent to browser
DEBUG - 2025-05-23 15:56:01 --> Total execution time: 0.0757
INFO - 2025-05-23 15:56:03 --> Config Class Initialized
INFO - 2025-05-23 15:56:03 --> Hooks Class Initialized
DEBUG - 2025-05-23 15:56:03 --> UTF-8 Support Enabled
INFO - 2025-05-23 15:56:03 --> Utf8 Class Initialized
INFO - 2025-05-23 15:56:03 --> URI Class Initialized
INFO - 2025-05-23 15:56:03 --> Router Class Initialized
INFO - 2025-05-23 15:56:03 --> Output Class Initialized
INFO - 2025-05-23 15:56:03 --> Security Class Initialized
DEBUG - 2025-05-23 15:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 15:56:03 --> Input Class Initialized
INFO - 2025-05-23 15:56:03 --> Language Class Initialized
INFO - 2025-05-23 15:56:03 --> Loader Class Initialized
INFO - 2025-05-23 15:56:03 --> Helper loaded: url_helper
INFO - 2025-05-23 15:56:03 --> Helper loaded: form_helper
INFO - 2025-05-23 15:56:03 --> Database Driver Class Initialized
DEBUG - 2025-05-23 15:56:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 15:56:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 15:56:03 --> Controller Class Initialized
INFO - 2025-05-23 15:56:03 --> Model "Olahraga_model" initialized
INFO - 2025-05-23 15:56:03 --> Model "User_model" initialized
INFO - 2025-05-23 15:56:03 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-23 15:56:03 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-23 15:56:03 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-05-23 15:56:03 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-23 15:56:03 --> Final output sent to browser
DEBUG - 2025-05-23 15:56:03 --> Total execution time: 0.0763
INFO - 2025-05-23 15:56:06 --> Config Class Initialized
INFO - 2025-05-23 15:56:06 --> Hooks Class Initialized
DEBUG - 2025-05-23 15:56:06 --> UTF-8 Support Enabled
INFO - 2025-05-23 15:56:06 --> Utf8 Class Initialized
INFO - 2025-05-23 15:56:06 --> URI Class Initialized
INFO - 2025-05-23 15:56:06 --> Router Class Initialized
INFO - 2025-05-23 15:56:06 --> Output Class Initialized
INFO - 2025-05-23 15:56:06 --> Security Class Initialized
DEBUG - 2025-05-23 15:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 15:56:06 --> Input Class Initialized
INFO - 2025-05-23 15:56:06 --> Language Class Initialized
INFO - 2025-05-23 15:56:06 --> Loader Class Initialized
INFO - 2025-05-23 15:56:06 --> Helper loaded: url_helper
INFO - 2025-05-23 15:56:06 --> Helper loaded: form_helper
INFO - 2025-05-23 15:56:06 --> Database Driver Class Initialized
DEBUG - 2025-05-23 15:56:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 15:56:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 15:56:06 --> Controller Class Initialized
INFO - 2025-05-23 15:56:06 --> Model "Olahraga_model" initialized
INFO - 2025-05-23 15:56:06 --> Model "User_model" initialized
INFO - 2025-05-23 15:56:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-23 15:56:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-23 15:56:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/menu.php
INFO - 2025-05-23 15:56:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-23 15:56:06 --> Final output sent to browser
DEBUG - 2025-05-23 15:56:06 --> Total execution time: 0.0694
INFO - 2025-05-23 16:07:25 --> Config Class Initialized
INFO - 2025-05-23 16:07:25 --> Hooks Class Initialized
DEBUG - 2025-05-23 16:07:25 --> UTF-8 Support Enabled
INFO - 2025-05-23 16:07:25 --> Utf8 Class Initialized
INFO - 2025-05-23 16:07:25 --> URI Class Initialized
INFO - 2025-05-23 16:07:25 --> Router Class Initialized
INFO - 2025-05-23 16:07:25 --> Output Class Initialized
INFO - 2025-05-23 16:07:25 --> Security Class Initialized
DEBUG - 2025-05-23 16:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 16:07:25 --> Input Class Initialized
INFO - 2025-05-23 16:07:25 --> Language Class Initialized
INFO - 2025-05-23 16:07:25 --> Loader Class Initialized
INFO - 2025-05-23 16:07:25 --> Helper loaded: url_helper
INFO - 2025-05-23 16:07:25 --> Helper loaded: form_helper
INFO - 2025-05-23 16:07:25 --> Database Driver Class Initialized
DEBUG - 2025-05-23 16:07:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 16:07:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 16:07:25 --> Controller Class Initialized
INFO - 2025-05-23 16:07:25 --> Model "Olahraga_model" initialized
INFO - 2025-05-23 16:07:25 --> Model "User_model" initialized
INFO - 2025-05-23 16:07:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-23 16:07:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-23 16:07:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/menu.php
INFO - 2025-05-23 16:07:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-23 16:07:25 --> Final output sent to browser
DEBUG - 2025-05-23 16:07:25 --> Total execution time: 0.0798
INFO - 2025-05-23 16:09:27 --> Config Class Initialized
INFO - 2025-05-23 16:09:27 --> Hooks Class Initialized
DEBUG - 2025-05-23 16:09:27 --> UTF-8 Support Enabled
INFO - 2025-05-23 16:09:27 --> Utf8 Class Initialized
INFO - 2025-05-23 16:09:27 --> URI Class Initialized
INFO - 2025-05-23 16:09:27 --> Router Class Initialized
INFO - 2025-05-23 16:09:27 --> Output Class Initialized
INFO - 2025-05-23 16:09:27 --> Security Class Initialized
DEBUG - 2025-05-23 16:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 16:09:27 --> Input Class Initialized
INFO - 2025-05-23 16:09:27 --> Language Class Initialized
INFO - 2025-05-23 16:09:27 --> Loader Class Initialized
INFO - 2025-05-23 16:09:27 --> Helper loaded: url_helper
INFO - 2025-05-23 16:09:27 --> Helper loaded: form_helper
INFO - 2025-05-23 16:09:27 --> Database Driver Class Initialized
DEBUG - 2025-05-23 16:09:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 16:09:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 16:09:27 --> Controller Class Initialized
INFO - 2025-05-23 16:09:27 --> Model "Olahraga_model" initialized
INFO - 2025-05-23 16:09:27 --> Model "User_model" initialized
INFO - 2025-05-23 16:09:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-23 16:09:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-23 16:09:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/menu.php
INFO - 2025-05-23 16:09:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-23 16:09:27 --> Final output sent to browser
DEBUG - 2025-05-23 16:09:27 --> Total execution time: 0.0794
INFO - 2025-05-23 16:19:20 --> Config Class Initialized
INFO - 2025-05-23 16:19:20 --> Hooks Class Initialized
DEBUG - 2025-05-23 16:19:20 --> UTF-8 Support Enabled
INFO - 2025-05-23 16:19:20 --> Utf8 Class Initialized
INFO - 2025-05-23 16:19:20 --> URI Class Initialized
INFO - 2025-05-23 16:19:20 --> Router Class Initialized
INFO - 2025-05-23 16:19:20 --> Output Class Initialized
INFO - 2025-05-23 16:19:20 --> Security Class Initialized
DEBUG - 2025-05-23 16:19:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 16:19:20 --> Input Class Initialized
INFO - 2025-05-23 16:19:20 --> Language Class Initialized
INFO - 2025-05-23 16:19:20 --> Loader Class Initialized
INFO - 2025-05-23 16:19:20 --> Helper loaded: url_helper
INFO - 2025-05-23 16:19:20 --> Helper loaded: form_helper
INFO - 2025-05-23 16:19:20 --> Database Driver Class Initialized
DEBUG - 2025-05-23 16:19:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 16:19:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 16:19:20 --> Controller Class Initialized
INFO - 2025-05-23 16:19:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\beta.php
INFO - 2025-05-23 16:19:20 --> Final output sent to browser
DEBUG - 2025-05-23 16:19:20 --> Total execution time: 0.0651
INFO - 2025-05-23 16:19:23 --> Config Class Initialized
INFO - 2025-05-23 16:19:23 --> Hooks Class Initialized
DEBUG - 2025-05-23 16:19:23 --> UTF-8 Support Enabled
INFO - 2025-05-23 16:19:23 --> Utf8 Class Initialized
INFO - 2025-05-23 16:19:23 --> URI Class Initialized
INFO - 2025-05-23 16:19:23 --> Router Class Initialized
INFO - 2025-05-23 16:19:23 --> Output Class Initialized
INFO - 2025-05-23 16:19:23 --> Security Class Initialized
DEBUG - 2025-05-23 16:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 16:19:23 --> Input Class Initialized
INFO - 2025-05-23 16:19:23 --> Language Class Initialized
INFO - 2025-05-23 16:19:23 --> Loader Class Initialized
INFO - 2025-05-23 16:19:23 --> Helper loaded: url_helper
INFO - 2025-05-23 16:19:23 --> Helper loaded: form_helper
INFO - 2025-05-23 16:19:23 --> Database Driver Class Initialized
DEBUG - 2025-05-23 16:19:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 16:19:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 16:19:23 --> Controller Class Initialized
INFO - 2025-05-23 16:19:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\level.php
INFO - 2025-05-23 16:19:23 --> Final output sent to browser
DEBUG - 2025-05-23 16:19:23 --> Total execution time: 0.0731
INFO - 2025-05-23 16:19:25 --> Config Class Initialized
INFO - 2025-05-23 16:19:25 --> Hooks Class Initialized
DEBUG - 2025-05-23 16:19:25 --> UTF-8 Support Enabled
INFO - 2025-05-23 16:19:25 --> Utf8 Class Initialized
INFO - 2025-05-23 16:19:25 --> URI Class Initialized
INFO - 2025-05-23 16:19:25 --> Router Class Initialized
INFO - 2025-05-23 16:19:25 --> Output Class Initialized
INFO - 2025-05-23 16:19:25 --> Security Class Initialized
DEBUG - 2025-05-23 16:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 16:19:25 --> Input Class Initialized
INFO - 2025-05-23 16:19:25 --> Language Class Initialized
INFO - 2025-05-23 16:19:25 --> Loader Class Initialized
INFO - 2025-05-23 16:19:25 --> Helper loaded: url_helper
INFO - 2025-05-23 16:19:25 --> Helper loaded: form_helper
INFO - 2025-05-23 16:19:25 --> Database Driver Class Initialized
DEBUG - 2025-05-23 16:19:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 16:19:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 16:19:25 --> Controller Class Initialized
INFO - 2025-05-23 16:19:25 --> Model "Beta_model" initialized
INFO - 2025-05-23 16:19:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\menu.php
INFO - 2025-05-23 16:19:25 --> Final output sent to browser
DEBUG - 2025-05-23 16:19:25 --> Total execution time: 0.0615
INFO - 2025-05-23 16:19:27 --> Config Class Initialized
INFO - 2025-05-23 16:19:27 --> Hooks Class Initialized
DEBUG - 2025-05-23 16:19:27 --> UTF-8 Support Enabled
INFO - 2025-05-23 16:19:27 --> Utf8 Class Initialized
INFO - 2025-05-23 16:19:27 --> URI Class Initialized
INFO - 2025-05-23 16:19:27 --> Router Class Initialized
INFO - 2025-05-23 16:19:27 --> Output Class Initialized
INFO - 2025-05-23 16:19:27 --> Security Class Initialized
DEBUG - 2025-05-23 16:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 16:19:27 --> Input Class Initialized
INFO - 2025-05-23 16:19:27 --> Language Class Initialized
INFO - 2025-05-23 16:19:27 --> Loader Class Initialized
INFO - 2025-05-23 16:19:27 --> Helper loaded: url_helper
INFO - 2025-05-23 16:19:27 --> Helper loaded: form_helper
INFO - 2025-05-23 16:19:27 --> Database Driver Class Initialized
DEBUG - 2025-05-23 16:19:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 16:19:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 16:19:27 --> Controller Class Initialized
INFO - 2025-05-23 16:19:27 --> Model "Beta_model" initialized
INFO - 2025-05-23 16:19:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\timer.php
INFO - 2025-05-23 16:19:27 --> Final output sent to browser
DEBUG - 2025-05-23 16:19:27 --> Total execution time: 0.0619
INFO - 2025-05-23 16:19:58 --> Config Class Initialized
INFO - 2025-05-23 16:19:58 --> Hooks Class Initialized
DEBUG - 2025-05-23 16:19:58 --> UTF-8 Support Enabled
INFO - 2025-05-23 16:19:58 --> Utf8 Class Initialized
INFO - 2025-05-23 16:19:58 --> URI Class Initialized
INFO - 2025-05-23 16:19:58 --> Router Class Initialized
INFO - 2025-05-23 16:19:58 --> Output Class Initialized
INFO - 2025-05-23 16:19:58 --> Security Class Initialized
DEBUG - 2025-05-23 16:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 16:19:58 --> Input Class Initialized
INFO - 2025-05-23 16:19:58 --> Language Class Initialized
INFO - 2025-05-23 16:19:58 --> Loader Class Initialized
INFO - 2025-05-23 16:19:58 --> Helper loaded: url_helper
INFO - 2025-05-23 16:19:58 --> Helper loaded: form_helper
INFO - 2025-05-23 16:19:58 --> Database Driver Class Initialized
DEBUG - 2025-05-23 16:19:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 16:19:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 16:19:58 --> Controller Class Initialized
INFO - 2025-05-23 16:19:58 --> Model "Beta_model" initialized
INFO - 2025-05-23 16:19:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\timer.php
INFO - 2025-05-23 16:19:58 --> Final output sent to browser
DEBUG - 2025-05-23 16:19:58 --> Total execution time: 0.0559
INFO - 2025-05-23 16:19:58 --> Config Class Initialized
INFO - 2025-05-23 16:19:58 --> Hooks Class Initialized
DEBUG - 2025-05-23 16:19:58 --> UTF-8 Support Enabled
INFO - 2025-05-23 16:19:58 --> Utf8 Class Initialized
INFO - 2025-05-23 16:19:58 --> URI Class Initialized
INFO - 2025-05-23 16:19:58 --> Router Class Initialized
INFO - 2025-05-23 16:19:58 --> Output Class Initialized
INFO - 2025-05-23 16:19:58 --> Security Class Initialized
DEBUG - 2025-05-23 16:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 16:19:58 --> Input Class Initialized
INFO - 2025-05-23 16:19:58 --> Language Class Initialized
INFO - 2025-05-23 16:19:58 --> Loader Class Initialized
INFO - 2025-05-23 16:19:58 --> Helper loaded: url_helper
INFO - 2025-05-23 16:19:58 --> Helper loaded: form_helper
INFO - 2025-05-23 16:19:58 --> Database Driver Class Initialized
DEBUG - 2025-05-23 16:19:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 16:19:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 16:19:58 --> Controller Class Initialized
INFO - 2025-05-23 16:19:58 --> Model "Beta_model" initialized
INFO - 2025-05-23 16:19:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\timer.php
INFO - 2025-05-23 16:19:58 --> Final output sent to browser
DEBUG - 2025-05-23 16:19:58 --> Total execution time: 0.0658
INFO - 2025-05-23 16:19:58 --> Config Class Initialized
INFO - 2025-05-23 16:19:58 --> Hooks Class Initialized
DEBUG - 2025-05-23 16:19:58 --> UTF-8 Support Enabled
INFO - 2025-05-23 16:19:58 --> Utf8 Class Initialized
INFO - 2025-05-23 16:19:58 --> URI Class Initialized
INFO - 2025-05-23 16:19:58 --> Router Class Initialized
INFO - 2025-05-23 16:19:58 --> Output Class Initialized
INFO - 2025-05-23 16:19:58 --> Security Class Initialized
DEBUG - 2025-05-23 16:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 16:19:58 --> Input Class Initialized
INFO - 2025-05-23 16:19:58 --> Language Class Initialized
INFO - 2025-05-23 16:19:58 --> Loader Class Initialized
INFO - 2025-05-23 16:19:58 --> Helper loaded: url_helper
INFO - 2025-05-23 16:19:58 --> Helper loaded: form_helper
INFO - 2025-05-23 16:19:58 --> Database Driver Class Initialized
DEBUG - 2025-05-23 16:19:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 16:19:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 16:19:58 --> Controller Class Initialized
INFO - 2025-05-23 16:19:58 --> Model "Beta_model" initialized
INFO - 2025-05-23 16:19:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\timer.php
INFO - 2025-05-23 16:19:58 --> Final output sent to browser
DEBUG - 2025-05-23 16:19:58 --> Total execution time: 0.0545
INFO - 2025-05-23 16:20:09 --> Config Class Initialized
INFO - 2025-05-23 16:20:09 --> Hooks Class Initialized
DEBUG - 2025-05-23 16:20:09 --> UTF-8 Support Enabled
INFO - 2025-05-23 16:20:09 --> Utf8 Class Initialized
INFO - 2025-05-23 16:20:09 --> URI Class Initialized
INFO - 2025-05-23 16:20:09 --> Router Class Initialized
INFO - 2025-05-23 16:20:09 --> Output Class Initialized
INFO - 2025-05-23 16:20:09 --> Security Class Initialized
DEBUG - 2025-05-23 16:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 16:20:09 --> Input Class Initialized
INFO - 2025-05-23 16:20:09 --> Language Class Initialized
INFO - 2025-05-23 16:20:09 --> Loader Class Initialized
INFO - 2025-05-23 16:20:09 --> Helper loaded: url_helper
INFO - 2025-05-23 16:20:09 --> Helper loaded: form_helper
INFO - 2025-05-23 16:20:09 --> Database Driver Class Initialized
DEBUG - 2025-05-23 16:20:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 16:20:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 16:20:09 --> Controller Class Initialized
INFO - 2025-05-23 16:20:09 --> Model "Beta_model" initialized
INFO - 2025-05-23 16:20:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\timer.php
INFO - 2025-05-23 16:20:09 --> Final output sent to browser
DEBUG - 2025-05-23 16:20:09 --> Total execution time: 0.0711
INFO - 2025-05-23 16:22:00 --> Config Class Initialized
INFO - 2025-05-23 16:22:00 --> Hooks Class Initialized
DEBUG - 2025-05-23 16:22:00 --> UTF-8 Support Enabled
INFO - 2025-05-23 16:22:00 --> Utf8 Class Initialized
INFO - 2025-05-23 16:22:00 --> URI Class Initialized
INFO - 2025-05-23 16:22:00 --> Router Class Initialized
INFO - 2025-05-23 16:22:00 --> Output Class Initialized
INFO - 2025-05-23 16:22:00 --> Security Class Initialized
DEBUG - 2025-05-23 16:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 16:22:00 --> Input Class Initialized
INFO - 2025-05-23 16:22:00 --> Language Class Initialized
INFO - 2025-05-23 16:22:00 --> Loader Class Initialized
INFO - 2025-05-23 16:22:00 --> Helper loaded: url_helper
INFO - 2025-05-23 16:22:00 --> Helper loaded: form_helper
INFO - 2025-05-23 16:22:00 --> Database Driver Class Initialized
DEBUG - 2025-05-23 16:22:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 16:22:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 16:22:00 --> Controller Class Initialized
INFO - 2025-05-23 16:22:00 --> Model "Beta_model" initialized
INFO - 2025-05-23 16:22:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\timer.php
INFO - 2025-05-23 16:22:00 --> Final output sent to browser
DEBUG - 2025-05-23 16:22:00 --> Total execution time: 0.0860
INFO - 2025-05-23 16:35:16 --> Config Class Initialized
INFO - 2025-05-23 16:35:16 --> Hooks Class Initialized
DEBUG - 2025-05-23 16:35:16 --> UTF-8 Support Enabled
INFO - 2025-05-23 16:35:16 --> Utf8 Class Initialized
INFO - 2025-05-23 16:35:16 --> URI Class Initialized
DEBUG - 2025-05-23 16:35:16 --> No URI present. Default controller set.
INFO - 2025-05-23 16:35:16 --> Router Class Initialized
INFO - 2025-05-23 16:35:16 --> Output Class Initialized
INFO - 2025-05-23 16:35:16 --> Security Class Initialized
DEBUG - 2025-05-23 16:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 16:35:16 --> Input Class Initialized
INFO - 2025-05-23 16:35:16 --> Language Class Initialized
INFO - 2025-05-23 16:35:16 --> Loader Class Initialized
INFO - 2025-05-23 16:35:16 --> Helper loaded: url_helper
INFO - 2025-05-23 16:35:16 --> Helper loaded: form_helper
INFO - 2025-05-23 16:35:16 --> Database Driver Class Initialized
DEBUG - 2025-05-23 16:35:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 16:35:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 16:35:16 --> Controller Class Initialized
INFO - 2025-05-23 16:35:16 --> Model "User_model" initialized
INFO - 2025-05-23 16:35:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-23 16:35:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-23 16:35:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-23 16:35:16 --> Final output sent to browser
DEBUG - 2025-05-23 16:35:16 --> Total execution time: 0.0962
INFO - 2025-05-23 16:35:18 --> Config Class Initialized
INFO - 2025-05-23 16:35:18 --> Hooks Class Initialized
DEBUG - 2025-05-23 16:35:18 --> UTF-8 Support Enabled
INFO - 2025-05-23 16:35:18 --> Utf8 Class Initialized
INFO - 2025-05-23 16:35:18 --> URI Class Initialized
INFO - 2025-05-23 16:35:18 --> Router Class Initialized
INFO - 2025-05-23 16:35:18 --> Output Class Initialized
INFO - 2025-05-23 16:35:18 --> Security Class Initialized
DEBUG - 2025-05-23 16:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 16:35:18 --> Input Class Initialized
INFO - 2025-05-23 16:35:18 --> Language Class Initialized
INFO - 2025-05-23 16:35:18 --> Loader Class Initialized
INFO - 2025-05-23 16:35:18 --> Helper loaded: url_helper
INFO - 2025-05-23 16:35:18 --> Helper loaded: form_helper
INFO - 2025-05-23 16:35:18 --> Database Driver Class Initialized
DEBUG - 2025-05-23 16:35:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 16:35:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 16:35:18 --> Controller Class Initialized
INFO - 2025-05-23 16:35:18 --> Model "User_model" initialized
INFO - 2025-05-23 16:35:18 --> Model "Workout_model" initialized
INFO - 2025-05-23 16:35:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-23 16:35:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-23 16:35:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-23 16:35:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-23 16:35:18 --> Final output sent to browser
DEBUG - 2025-05-23 16:35:18 --> Total execution time: 0.0745
INFO - 2025-05-23 16:35:20 --> Config Class Initialized
INFO - 2025-05-23 16:35:20 --> Hooks Class Initialized
DEBUG - 2025-05-23 16:35:20 --> UTF-8 Support Enabled
INFO - 2025-05-23 16:35:20 --> Utf8 Class Initialized
INFO - 2025-05-23 16:35:20 --> URI Class Initialized
INFO - 2025-05-23 16:35:20 --> Router Class Initialized
INFO - 2025-05-23 16:35:20 --> Output Class Initialized
INFO - 2025-05-23 16:35:20 --> Security Class Initialized
DEBUG - 2025-05-23 16:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 16:35:20 --> Input Class Initialized
INFO - 2025-05-23 16:35:20 --> Language Class Initialized
INFO - 2025-05-23 16:35:20 --> Loader Class Initialized
INFO - 2025-05-23 16:35:20 --> Helper loaded: url_helper
INFO - 2025-05-23 16:35:20 --> Helper loaded: form_helper
INFO - 2025-05-23 16:35:20 --> Database Driver Class Initialized
DEBUG - 2025-05-23 16:35:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 16:35:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 16:35:20 --> Controller Class Initialized
INFO - 2025-05-23 16:35:20 --> Model "Olahraga_model" initialized
INFO - 2025-05-23 16:35:20 --> Model "User_model" initialized
INFO - 2025-05-23 16:35:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-23 16:35:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-23 16:35:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-05-23 16:35:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-23 16:35:20 --> Final output sent to browser
DEBUG - 2025-05-23 16:35:20 --> Total execution time: 0.0781
INFO - 2025-05-23 16:35:25 --> Config Class Initialized
INFO - 2025-05-23 16:35:25 --> Hooks Class Initialized
DEBUG - 2025-05-23 16:35:25 --> UTF-8 Support Enabled
INFO - 2025-05-23 16:35:25 --> Utf8 Class Initialized
INFO - 2025-05-23 16:35:25 --> URI Class Initialized
INFO - 2025-05-23 16:35:25 --> Router Class Initialized
INFO - 2025-05-23 16:35:25 --> Output Class Initialized
INFO - 2025-05-23 16:35:25 --> Security Class Initialized
DEBUG - 2025-05-23 16:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 16:35:25 --> Input Class Initialized
INFO - 2025-05-23 16:35:25 --> Language Class Initialized
INFO - 2025-05-23 16:35:25 --> Loader Class Initialized
INFO - 2025-05-23 16:35:25 --> Helper loaded: url_helper
INFO - 2025-05-23 16:35:25 --> Helper loaded: form_helper
INFO - 2025-05-23 16:35:25 --> Database Driver Class Initialized
DEBUG - 2025-05-23 16:35:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 16:35:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 16:35:25 --> Controller Class Initialized
INFO - 2025-05-23 16:35:25 --> Model "Olahraga_model" initialized
INFO - 2025-05-23 16:35:25 --> Model "User_model" initialized
INFO - 2025-05-23 16:35:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-23 16:35:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-23 16:35:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-05-23 16:35:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-23 16:35:25 --> Final output sent to browser
DEBUG - 2025-05-23 16:35:25 --> Total execution time: 0.0647
INFO - 2025-05-23 16:35:27 --> Config Class Initialized
INFO - 2025-05-23 16:35:27 --> Hooks Class Initialized
DEBUG - 2025-05-23 16:35:27 --> UTF-8 Support Enabled
INFO - 2025-05-23 16:35:27 --> Utf8 Class Initialized
INFO - 2025-05-23 16:35:27 --> URI Class Initialized
INFO - 2025-05-23 16:35:27 --> Router Class Initialized
INFO - 2025-05-23 16:35:27 --> Output Class Initialized
INFO - 2025-05-23 16:35:27 --> Security Class Initialized
DEBUG - 2025-05-23 16:35:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 16:35:27 --> Input Class Initialized
INFO - 2025-05-23 16:35:27 --> Language Class Initialized
INFO - 2025-05-23 16:35:27 --> Loader Class Initialized
INFO - 2025-05-23 16:35:27 --> Helper loaded: url_helper
INFO - 2025-05-23 16:35:27 --> Helper loaded: form_helper
INFO - 2025-05-23 16:35:27 --> Database Driver Class Initialized
DEBUG - 2025-05-23 16:35:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 16:35:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 16:35:27 --> Controller Class Initialized
INFO - 2025-05-23 16:35:27 --> Model "Olahraga_model" initialized
INFO - 2025-05-23 16:35:27 --> Model "User_model" initialized
INFO - 2025-05-23 16:35:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-23 16:35:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-23 16:35:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/menu.php
INFO - 2025-05-23 16:35:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-23 16:35:28 --> Final output sent to browser
DEBUG - 2025-05-23 16:35:28 --> Total execution time: 0.0641
INFO - 2025-05-23 16:35:31 --> Config Class Initialized
INFO - 2025-05-23 16:35:31 --> Hooks Class Initialized
DEBUG - 2025-05-23 16:35:31 --> UTF-8 Support Enabled
INFO - 2025-05-23 16:35:31 --> Utf8 Class Initialized
INFO - 2025-05-23 16:35:31 --> URI Class Initialized
INFO - 2025-05-23 16:35:31 --> Router Class Initialized
INFO - 2025-05-23 16:35:31 --> Output Class Initialized
INFO - 2025-05-23 16:35:31 --> Security Class Initialized
DEBUG - 2025-05-23 16:35:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 16:35:31 --> Input Class Initialized
INFO - 2025-05-23 16:35:31 --> Language Class Initialized
INFO - 2025-05-23 16:35:31 --> Loader Class Initialized
INFO - 2025-05-23 16:35:31 --> Helper loaded: url_helper
INFO - 2025-05-23 16:35:31 --> Helper loaded: form_helper
INFO - 2025-05-23 16:35:31 --> Database Driver Class Initialized
DEBUG - 2025-05-23 16:35:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 16:35:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 16:35:31 --> Controller Class Initialized
INFO - 2025-05-23 16:35:31 --> Model "Olahraga_model" initialized
INFO - 2025-05-23 16:35:31 --> Model "User_model" initialized
ERROR - 2025-05-23 16:35:31 --> Severity: error --> Exception: Too few arguments to function Olahraga::timer(), 1 passed in C:\laragon\www\Project\fitnessrecord\system\core\CodeIgniter.php on line 533 and exactly 3 expected C:\laragon\www\Project\fitnessrecord\application\controllers\Olahraga.php 67
INFO - 2025-05-23 16:37:02 --> Config Class Initialized
INFO - 2025-05-23 16:37:02 --> Hooks Class Initialized
DEBUG - 2025-05-23 16:37:02 --> UTF-8 Support Enabled
INFO - 2025-05-23 16:37:02 --> Utf8 Class Initialized
INFO - 2025-05-23 16:37:02 --> URI Class Initialized
INFO - 2025-05-23 16:37:02 --> Router Class Initialized
INFO - 2025-05-23 16:37:02 --> Output Class Initialized
INFO - 2025-05-23 16:37:02 --> Security Class Initialized
DEBUG - 2025-05-23 16:37:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 16:37:02 --> Input Class Initialized
INFO - 2025-05-23 16:37:02 --> Language Class Initialized
INFO - 2025-05-23 16:37:02 --> Loader Class Initialized
INFO - 2025-05-23 16:37:02 --> Helper loaded: url_helper
INFO - 2025-05-23 16:37:02 --> Helper loaded: form_helper
INFO - 2025-05-23 16:37:02 --> Database Driver Class Initialized
DEBUG - 2025-05-23 16:37:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 16:37:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 16:37:02 --> Controller Class Initialized
INFO - 2025-05-23 16:37:02 --> Model "Olahraga_model" initialized
INFO - 2025-05-23 16:37:02 --> Model "User_model" initialized
ERROR - 2025-05-23 16:37:02 --> Severity: error --> Exception: Too few arguments to function Olahraga::timer(), 1 passed in C:\laragon\www\Project\fitnessrecord\system\core\CodeIgniter.php on line 533 and exactly 3 expected C:\laragon\www\Project\fitnessrecord\application\controllers\Olahraga.php 67
INFO - 2025-05-23 16:37:04 --> Config Class Initialized
INFO - 2025-05-23 16:37:04 --> Hooks Class Initialized
DEBUG - 2025-05-23 16:37:04 --> UTF-8 Support Enabled
INFO - 2025-05-23 16:37:04 --> Utf8 Class Initialized
INFO - 2025-05-23 16:37:04 --> URI Class Initialized
INFO - 2025-05-23 16:37:04 --> Router Class Initialized
INFO - 2025-05-23 16:37:04 --> Output Class Initialized
INFO - 2025-05-23 16:37:04 --> Security Class Initialized
DEBUG - 2025-05-23 16:37:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 16:37:04 --> Input Class Initialized
INFO - 2025-05-23 16:37:04 --> Language Class Initialized
INFO - 2025-05-23 16:37:04 --> Loader Class Initialized
INFO - 2025-05-23 16:37:04 --> Helper loaded: url_helper
INFO - 2025-05-23 16:37:04 --> Helper loaded: form_helper
INFO - 2025-05-23 16:37:04 --> Database Driver Class Initialized
DEBUG - 2025-05-23 16:37:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 16:37:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 16:37:04 --> Controller Class Initialized
INFO - 2025-05-23 16:37:04 --> Model "Olahraga_model" initialized
INFO - 2025-05-23 16:37:04 --> Model "User_model" initialized
INFO - 2025-05-23 16:37:04 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-23 16:37:04 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-23 16:37:04 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/menu.php
INFO - 2025-05-23 16:37:04 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-23 16:37:04 --> Final output sent to browser
DEBUG - 2025-05-23 16:37:04 --> Total execution time: 0.0660
INFO - 2025-05-23 16:37:07 --> Config Class Initialized
INFO - 2025-05-23 16:37:07 --> Hooks Class Initialized
DEBUG - 2025-05-23 16:37:07 --> UTF-8 Support Enabled
INFO - 2025-05-23 16:37:07 --> Utf8 Class Initialized
INFO - 2025-05-23 16:37:07 --> URI Class Initialized
INFO - 2025-05-23 16:37:07 --> Router Class Initialized
INFO - 2025-05-23 16:37:07 --> Output Class Initialized
INFO - 2025-05-23 16:37:07 --> Security Class Initialized
DEBUG - 2025-05-23 16:37:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 16:37:07 --> Input Class Initialized
INFO - 2025-05-23 16:37:07 --> Language Class Initialized
INFO - 2025-05-23 16:37:07 --> Loader Class Initialized
INFO - 2025-05-23 16:37:07 --> Helper loaded: url_helper
INFO - 2025-05-23 16:37:07 --> Helper loaded: form_helper
INFO - 2025-05-23 16:37:07 --> Database Driver Class Initialized
DEBUG - 2025-05-23 16:37:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 16:37:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 16:37:07 --> Controller Class Initialized
INFO - 2025-05-23 16:37:07 --> Model "Olahraga_model" initialized
INFO - 2025-05-23 16:37:07 --> Model "User_model" initialized
ERROR - 2025-05-23 16:37:07 --> Severity: error --> Exception: Too few arguments to function Olahraga::timer(), 1 passed in C:\laragon\www\Project\fitnessrecord\system\core\CodeIgniter.php on line 533 and exactly 3 expected C:\laragon\www\Project\fitnessrecord\application\controllers\Olahraga.php 67
INFO - 2025-05-23 16:37:10 --> Config Class Initialized
INFO - 2025-05-23 16:37:10 --> Hooks Class Initialized
DEBUG - 2025-05-23 16:37:10 --> UTF-8 Support Enabled
INFO - 2025-05-23 16:37:10 --> Utf8 Class Initialized
INFO - 2025-05-23 16:37:10 --> URI Class Initialized
INFO - 2025-05-23 16:37:10 --> Router Class Initialized
INFO - 2025-05-23 16:37:10 --> Output Class Initialized
INFO - 2025-05-23 16:37:10 --> Security Class Initialized
DEBUG - 2025-05-23 16:37:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 16:37:10 --> Input Class Initialized
INFO - 2025-05-23 16:37:10 --> Language Class Initialized
INFO - 2025-05-23 16:37:10 --> Loader Class Initialized
INFO - 2025-05-23 16:37:10 --> Helper loaded: url_helper
INFO - 2025-05-23 16:37:10 --> Helper loaded: form_helper
INFO - 2025-05-23 16:37:10 --> Database Driver Class Initialized
DEBUG - 2025-05-23 16:37:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 16:37:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 16:37:10 --> Controller Class Initialized
INFO - 2025-05-23 16:37:10 --> Model "Olahraga_model" initialized
INFO - 2025-05-23 16:37:10 --> Model "User_model" initialized
ERROR - 2025-05-23 16:37:10 --> Severity: error --> Exception: Too few arguments to function Olahraga::timer(), 1 passed in C:\laragon\www\Project\fitnessrecord\system\core\CodeIgniter.php on line 533 and exactly 3 expected C:\laragon\www\Project\fitnessrecord\application\controllers\Olahraga.php 67
INFO - 2025-05-23 16:39:38 --> Config Class Initialized
INFO - 2025-05-23 16:39:38 --> Hooks Class Initialized
DEBUG - 2025-05-23 16:39:38 --> UTF-8 Support Enabled
INFO - 2025-05-23 16:39:38 --> Utf8 Class Initialized
INFO - 2025-05-23 16:39:38 --> URI Class Initialized
INFO - 2025-05-23 16:39:38 --> Router Class Initialized
INFO - 2025-05-23 16:39:38 --> Output Class Initialized
INFO - 2025-05-23 16:39:38 --> Security Class Initialized
DEBUG - 2025-05-23 16:39:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 16:39:38 --> Input Class Initialized
INFO - 2025-05-23 16:39:38 --> Language Class Initialized
INFO - 2025-05-23 16:39:38 --> Loader Class Initialized
INFO - 2025-05-23 16:39:38 --> Helper loaded: url_helper
INFO - 2025-05-23 16:39:38 --> Helper loaded: form_helper
INFO - 2025-05-23 16:39:38 --> Database Driver Class Initialized
DEBUG - 2025-05-23 16:39:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 16:39:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 16:39:38 --> Controller Class Initialized
INFO - 2025-05-23 16:39:38 --> Model "Olahraga_model" initialized
INFO - 2025-05-23 16:39:38 --> Model "User_model" initialized
INFO - 2025-05-23 16:39:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-23 16:39:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-23 16:39:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/menu.php
INFO - 2025-05-23 16:39:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-23 16:39:38 --> Final output sent to browser
DEBUG - 2025-05-23 16:39:38 --> Total execution time: 0.0870
INFO - 2025-05-23 16:39:39 --> Config Class Initialized
INFO - 2025-05-23 16:39:39 --> Hooks Class Initialized
DEBUG - 2025-05-23 16:39:39 --> UTF-8 Support Enabled
INFO - 2025-05-23 16:39:39 --> Utf8 Class Initialized
INFO - 2025-05-23 16:39:39 --> URI Class Initialized
INFO - 2025-05-23 16:39:39 --> Router Class Initialized
INFO - 2025-05-23 16:39:39 --> Output Class Initialized
INFO - 2025-05-23 16:39:39 --> Security Class Initialized
DEBUG - 2025-05-23 16:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 16:39:39 --> Input Class Initialized
INFO - 2025-05-23 16:39:39 --> Language Class Initialized
INFO - 2025-05-23 16:39:39 --> Loader Class Initialized
INFO - 2025-05-23 16:39:39 --> Helper loaded: url_helper
INFO - 2025-05-23 16:39:39 --> Helper loaded: form_helper
INFO - 2025-05-23 16:39:39 --> Database Driver Class Initialized
DEBUG - 2025-05-23 16:39:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 16:39:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 16:39:39 --> Controller Class Initialized
INFO - 2025-05-23 16:39:39 --> Model "Olahraga_model" initialized
INFO - 2025-05-23 16:39:39 --> Model "User_model" initialized
INFO - 2025-05-23 16:39:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-23 16:39:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-23 16:39:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/start.php
INFO - 2025-05-23 16:39:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-23 16:39:39 --> Final output sent to browser
DEBUG - 2025-05-23 16:39:39 --> Total execution time: 0.0890
INFO - 2025-05-23 16:41:37 --> Config Class Initialized
INFO - 2025-05-23 16:41:37 --> Hooks Class Initialized
DEBUG - 2025-05-23 16:41:37 --> UTF-8 Support Enabled
INFO - 2025-05-23 16:41:37 --> Utf8 Class Initialized
INFO - 2025-05-23 16:41:37 --> URI Class Initialized
INFO - 2025-05-23 16:41:37 --> Router Class Initialized
INFO - 2025-05-23 16:41:37 --> Output Class Initialized
INFO - 2025-05-23 16:41:37 --> Security Class Initialized
DEBUG - 2025-05-23 16:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 16:41:37 --> Input Class Initialized
INFO - 2025-05-23 16:41:37 --> Language Class Initialized
INFO - 2025-05-23 16:41:37 --> Loader Class Initialized
INFO - 2025-05-23 16:41:37 --> Helper loaded: url_helper
INFO - 2025-05-23 16:41:37 --> Helper loaded: form_helper
INFO - 2025-05-23 16:41:37 --> Database Driver Class Initialized
DEBUG - 2025-05-23 16:41:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 16:41:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 16:41:38 --> Controller Class Initialized
INFO - 2025-05-23 16:41:38 --> Model "Olahraga_model" initialized
INFO - 2025-05-23 16:41:38 --> Model "User_model" initialized
INFO - 2025-05-23 16:41:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-23 16:41:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-23 16:41:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/menu.php
INFO - 2025-05-23 16:41:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-23 16:41:38 --> Final output sent to browser
DEBUG - 2025-05-23 16:41:38 --> Total execution time: 0.0734
INFO - 2025-05-23 16:41:39 --> Config Class Initialized
INFO - 2025-05-23 16:41:39 --> Hooks Class Initialized
DEBUG - 2025-05-23 16:41:39 --> UTF-8 Support Enabled
INFO - 2025-05-23 16:41:39 --> Utf8 Class Initialized
INFO - 2025-05-23 16:41:39 --> URI Class Initialized
INFO - 2025-05-23 16:41:39 --> Router Class Initialized
INFO - 2025-05-23 16:41:39 --> Output Class Initialized
INFO - 2025-05-23 16:41:39 --> Security Class Initialized
DEBUG - 2025-05-23 16:41:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 16:41:39 --> Input Class Initialized
INFO - 2025-05-23 16:41:39 --> Language Class Initialized
INFO - 2025-05-23 16:41:39 --> Loader Class Initialized
INFO - 2025-05-23 16:41:39 --> Helper loaded: url_helper
INFO - 2025-05-23 16:41:39 --> Helper loaded: form_helper
INFO - 2025-05-23 16:41:39 --> Database Driver Class Initialized
DEBUG - 2025-05-23 16:41:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 16:41:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 16:41:39 --> Controller Class Initialized
INFO - 2025-05-23 16:41:39 --> Model "Olahraga_model" initialized
INFO - 2025-05-23 16:41:39 --> Model "User_model" initialized
INFO - 2025-05-23 16:41:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-23 16:41:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-23 16:41:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/start.php
INFO - 2025-05-23 16:41:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-23 16:41:39 --> Final output sent to browser
DEBUG - 2025-05-23 16:41:39 --> Total execution time: 0.0771
INFO - 2025-05-23 16:41:59 --> Config Class Initialized
INFO - 2025-05-23 16:41:59 --> Hooks Class Initialized
DEBUG - 2025-05-23 16:41:59 --> UTF-8 Support Enabled
INFO - 2025-05-23 16:41:59 --> Utf8 Class Initialized
INFO - 2025-05-23 16:41:59 --> URI Class Initialized
INFO - 2025-05-23 16:41:59 --> Router Class Initialized
INFO - 2025-05-23 16:41:59 --> Output Class Initialized
INFO - 2025-05-23 16:41:59 --> Security Class Initialized
DEBUG - 2025-05-23 16:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 16:41:59 --> Input Class Initialized
INFO - 2025-05-23 16:41:59 --> Language Class Initialized
INFO - 2025-05-23 16:41:59 --> Loader Class Initialized
INFO - 2025-05-23 16:41:59 --> Helper loaded: url_helper
INFO - 2025-05-23 16:41:59 --> Helper loaded: form_helper
INFO - 2025-05-23 16:41:59 --> Database Driver Class Initialized
DEBUG - 2025-05-23 16:41:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 16:41:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 16:41:59 --> Controller Class Initialized
INFO - 2025-05-23 16:41:59 --> Model "Olahraga_model" initialized
INFO - 2025-05-23 16:41:59 --> Model "User_model" initialized
INFO - 2025-05-23 16:41:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-23 16:41:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-23 16:41:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/menu.php
INFO - 2025-05-23 16:41:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-23 16:41:59 --> Final output sent to browser
DEBUG - 2025-05-23 16:41:59 --> Total execution time: 0.0654
INFO - 2025-05-23 16:42:37 --> Config Class Initialized
INFO - 2025-05-23 16:42:37 --> Hooks Class Initialized
DEBUG - 2025-05-23 16:42:37 --> UTF-8 Support Enabled
INFO - 2025-05-23 16:42:37 --> Utf8 Class Initialized
INFO - 2025-05-23 16:42:37 --> URI Class Initialized
INFO - 2025-05-23 16:42:37 --> Router Class Initialized
INFO - 2025-05-23 16:42:37 --> Output Class Initialized
INFO - 2025-05-23 16:42:37 --> Security Class Initialized
DEBUG - 2025-05-23 16:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 16:42:37 --> Input Class Initialized
INFO - 2025-05-23 16:42:37 --> Language Class Initialized
INFO - 2025-05-23 16:42:37 --> Loader Class Initialized
INFO - 2025-05-23 16:42:37 --> Helper loaded: url_helper
INFO - 2025-05-23 16:42:37 --> Helper loaded: form_helper
INFO - 2025-05-23 16:42:37 --> Database Driver Class Initialized
DEBUG - 2025-05-23 16:42:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 16:42:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 16:42:37 --> Controller Class Initialized
INFO - 2025-05-23 16:42:37 --> Model "Olahraga_model" initialized
INFO - 2025-05-23 16:42:37 --> Model "User_model" initialized
INFO - 2025-05-23 16:42:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-23 16:42:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-23 16:42:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/menu.php
INFO - 2025-05-23 16:42:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-23 16:42:37 --> Final output sent to browser
DEBUG - 2025-05-23 16:42:37 --> Total execution time: 0.0681
INFO - 2025-05-23 16:42:38 --> Config Class Initialized
INFO - 2025-05-23 16:42:38 --> Hooks Class Initialized
DEBUG - 2025-05-23 16:42:38 --> UTF-8 Support Enabled
INFO - 2025-05-23 16:42:38 --> Utf8 Class Initialized
INFO - 2025-05-23 16:42:38 --> URI Class Initialized
INFO - 2025-05-23 16:42:38 --> Router Class Initialized
INFO - 2025-05-23 16:42:38 --> Output Class Initialized
INFO - 2025-05-23 16:42:38 --> Security Class Initialized
DEBUG - 2025-05-23 16:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 16:42:38 --> Input Class Initialized
INFO - 2025-05-23 16:42:38 --> Language Class Initialized
INFO - 2025-05-23 16:42:38 --> Loader Class Initialized
INFO - 2025-05-23 16:42:38 --> Helper loaded: url_helper
INFO - 2025-05-23 16:42:38 --> Helper loaded: form_helper
INFO - 2025-05-23 16:42:38 --> Database Driver Class Initialized
DEBUG - 2025-05-23 16:42:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 16:42:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 16:42:38 --> Controller Class Initialized
INFO - 2025-05-23 16:42:38 --> Model "Olahraga_model" initialized
INFO - 2025-05-23 16:42:38 --> Model "User_model" initialized
INFO - 2025-05-23 16:42:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-23 16:42:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-23 16:42:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/start.php
INFO - 2025-05-23 16:42:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-23 16:42:38 --> Final output sent to browser
DEBUG - 2025-05-23 16:42:38 --> Total execution time: 0.0708
INFO - 2025-05-23 16:43:08 --> Config Class Initialized
INFO - 2025-05-23 16:43:08 --> Hooks Class Initialized
DEBUG - 2025-05-23 16:43:08 --> UTF-8 Support Enabled
INFO - 2025-05-23 16:43:08 --> Utf8 Class Initialized
INFO - 2025-05-23 16:43:08 --> URI Class Initialized
INFO - 2025-05-23 16:43:08 --> Router Class Initialized
INFO - 2025-05-23 16:43:08 --> Output Class Initialized
INFO - 2025-05-23 16:43:08 --> Security Class Initialized
DEBUG - 2025-05-23 16:43:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 16:43:08 --> Input Class Initialized
INFO - 2025-05-23 16:43:08 --> Language Class Initialized
INFO - 2025-05-23 16:43:08 --> Loader Class Initialized
INFO - 2025-05-23 16:43:08 --> Helper loaded: url_helper
INFO - 2025-05-23 16:43:08 --> Helper loaded: form_helper
INFO - 2025-05-23 16:43:08 --> Database Driver Class Initialized
DEBUG - 2025-05-23 16:43:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 16:43:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 16:43:08 --> Controller Class Initialized
INFO - 2025-05-23 16:43:08 --> Model "Olahraga_model" initialized
INFO - 2025-05-23 16:43:08 --> Model "User_model" initialized
INFO - 2025-05-23 16:43:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-23 16:43:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-23 16:43:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/menu.php
INFO - 2025-05-23 16:43:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-23 16:43:08 --> Final output sent to browser
DEBUG - 2025-05-23 16:43:08 --> Total execution time: 0.0785
INFO - 2025-05-23 16:43:09 --> Config Class Initialized
INFO - 2025-05-23 16:43:09 --> Hooks Class Initialized
DEBUG - 2025-05-23 16:43:09 --> UTF-8 Support Enabled
INFO - 2025-05-23 16:43:09 --> Utf8 Class Initialized
INFO - 2025-05-23 16:43:09 --> URI Class Initialized
INFO - 2025-05-23 16:43:09 --> Router Class Initialized
INFO - 2025-05-23 16:43:09 --> Output Class Initialized
INFO - 2025-05-23 16:43:09 --> Security Class Initialized
DEBUG - 2025-05-23 16:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 16:43:09 --> Input Class Initialized
INFO - 2025-05-23 16:43:09 --> Language Class Initialized
INFO - 2025-05-23 16:43:09 --> Loader Class Initialized
INFO - 2025-05-23 16:43:09 --> Helper loaded: url_helper
INFO - 2025-05-23 16:43:09 --> Helper loaded: form_helper
INFO - 2025-05-23 16:43:09 --> Database Driver Class Initialized
DEBUG - 2025-05-23 16:43:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 16:43:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 16:43:09 --> Controller Class Initialized
INFO - 2025-05-23 16:43:09 --> Model "Olahraga_model" initialized
INFO - 2025-05-23 16:43:09 --> Model "User_model" initialized
INFO - 2025-05-23 16:43:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-23 16:43:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-23 16:43:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/start.php
INFO - 2025-05-23 16:43:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-23 16:43:09 --> Final output sent to browser
DEBUG - 2025-05-23 16:43:09 --> Total execution time: 0.0614
INFO - 2025-05-23 16:43:16 --> Config Class Initialized
INFO - 2025-05-23 16:43:16 --> Hooks Class Initialized
DEBUG - 2025-05-23 16:43:16 --> UTF-8 Support Enabled
INFO - 2025-05-23 16:43:16 --> Utf8 Class Initialized
INFO - 2025-05-23 16:43:16 --> URI Class Initialized
INFO - 2025-05-23 16:43:16 --> Router Class Initialized
INFO - 2025-05-23 16:43:16 --> Output Class Initialized
INFO - 2025-05-23 16:43:16 --> Security Class Initialized
DEBUG - 2025-05-23 16:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 16:43:16 --> Input Class Initialized
INFO - 2025-05-23 16:43:16 --> Language Class Initialized
INFO - 2025-05-23 16:43:16 --> Loader Class Initialized
INFO - 2025-05-23 16:43:16 --> Helper loaded: url_helper
INFO - 2025-05-23 16:43:16 --> Helper loaded: form_helper
INFO - 2025-05-23 16:43:16 --> Database Driver Class Initialized
DEBUG - 2025-05-23 16:43:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 16:43:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 16:43:16 --> Controller Class Initialized
INFO - 2025-05-23 16:43:16 --> Model "Olahraga_model" initialized
INFO - 2025-05-23 16:43:16 --> Model "User_model" initialized
INFO - 2025-05-23 16:43:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-23 16:43:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-23 16:43:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/start.php
INFO - 2025-05-23 16:43:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-23 16:43:16 --> Final output sent to browser
DEBUG - 2025-05-23 16:43:16 --> Total execution time: 0.0724
INFO - 2025-05-23 16:43:55 --> Config Class Initialized
INFO - 2025-05-23 16:43:55 --> Hooks Class Initialized
DEBUG - 2025-05-23 16:43:55 --> UTF-8 Support Enabled
INFO - 2025-05-23 16:43:55 --> Utf8 Class Initialized
INFO - 2025-05-23 16:43:55 --> URI Class Initialized
INFO - 2025-05-23 16:43:55 --> Router Class Initialized
INFO - 2025-05-23 16:43:55 --> Output Class Initialized
INFO - 2025-05-23 16:43:55 --> Security Class Initialized
DEBUG - 2025-05-23 16:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 16:43:55 --> Input Class Initialized
INFO - 2025-05-23 16:43:55 --> Language Class Initialized
INFO - 2025-05-23 16:43:55 --> Loader Class Initialized
INFO - 2025-05-23 16:43:55 --> Helper loaded: url_helper
INFO - 2025-05-23 16:43:55 --> Helper loaded: form_helper
INFO - 2025-05-23 16:43:55 --> Database Driver Class Initialized
DEBUG - 2025-05-23 16:43:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 16:43:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 16:43:55 --> Controller Class Initialized
INFO - 2025-05-23 16:43:55 --> Model "Olahraga_model" initialized
INFO - 2025-05-23 16:43:55 --> Model "User_model" initialized
INFO - 2025-05-23 16:43:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-23 16:43:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-23 16:43:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/menu.php
INFO - 2025-05-23 16:43:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-23 16:43:55 --> Final output sent to browser
DEBUG - 2025-05-23 16:43:55 --> Total execution time: 0.0963
INFO - 2025-05-23 16:43:56 --> Config Class Initialized
INFO - 2025-05-23 16:43:56 --> Hooks Class Initialized
DEBUG - 2025-05-23 16:43:56 --> UTF-8 Support Enabled
INFO - 2025-05-23 16:43:56 --> Utf8 Class Initialized
INFO - 2025-05-23 16:43:56 --> URI Class Initialized
INFO - 2025-05-23 16:43:56 --> Router Class Initialized
INFO - 2025-05-23 16:43:56 --> Output Class Initialized
INFO - 2025-05-23 16:43:56 --> Security Class Initialized
DEBUG - 2025-05-23 16:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 16:43:56 --> Input Class Initialized
INFO - 2025-05-23 16:43:56 --> Language Class Initialized
INFO - 2025-05-23 16:43:56 --> Loader Class Initialized
INFO - 2025-05-23 16:43:56 --> Helper loaded: url_helper
INFO - 2025-05-23 16:43:56 --> Helper loaded: form_helper
INFO - 2025-05-23 16:43:56 --> Database Driver Class Initialized
DEBUG - 2025-05-23 16:43:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 16:43:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 16:43:56 --> Controller Class Initialized
INFO - 2025-05-23 16:43:56 --> Model "Olahraga_model" initialized
INFO - 2025-05-23 16:43:56 --> Model "User_model" initialized
INFO - 2025-05-23 16:43:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-23 16:43:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-23 16:43:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/start.php
INFO - 2025-05-23 16:43:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-23 16:43:56 --> Final output sent to browser
DEBUG - 2025-05-23 16:43:56 --> Total execution time: 0.0621
INFO - 2025-05-23 16:44:11 --> Config Class Initialized
INFO - 2025-05-23 16:44:11 --> Hooks Class Initialized
DEBUG - 2025-05-23 16:44:11 --> UTF-8 Support Enabled
INFO - 2025-05-23 16:44:11 --> Utf8 Class Initialized
INFO - 2025-05-23 16:44:11 --> URI Class Initialized
INFO - 2025-05-23 16:44:11 --> Router Class Initialized
INFO - 2025-05-23 16:44:11 --> Output Class Initialized
INFO - 2025-05-23 16:44:11 --> Security Class Initialized
DEBUG - 2025-05-23 16:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 16:44:11 --> Input Class Initialized
INFO - 2025-05-23 16:44:11 --> Language Class Initialized
INFO - 2025-05-23 16:44:11 --> Loader Class Initialized
INFO - 2025-05-23 16:44:11 --> Helper loaded: url_helper
INFO - 2025-05-23 16:44:11 --> Helper loaded: form_helper
INFO - 2025-05-23 16:44:11 --> Database Driver Class Initialized
DEBUG - 2025-05-23 16:44:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 16:44:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 16:44:11 --> Controller Class Initialized
INFO - 2025-05-23 16:44:11 --> Model "Olahraga_model" initialized
INFO - 2025-05-23 16:44:11 --> Model "User_model" initialized
INFO - 2025-05-23 16:44:11 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-23 16:44:11 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-23 16:44:11 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/start.php
INFO - 2025-05-23 16:44:11 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-23 16:44:11 --> Final output sent to browser
DEBUG - 2025-05-23 16:44:11 --> Total execution time: 0.0779
INFO - 2025-05-23 16:44:19 --> Config Class Initialized
INFO - 2025-05-23 16:44:19 --> Hooks Class Initialized
DEBUG - 2025-05-23 16:44:19 --> UTF-8 Support Enabled
INFO - 2025-05-23 16:44:19 --> Utf8 Class Initialized
INFO - 2025-05-23 16:44:19 --> URI Class Initialized
INFO - 2025-05-23 16:44:19 --> Router Class Initialized
INFO - 2025-05-23 16:44:19 --> Output Class Initialized
INFO - 2025-05-23 16:44:20 --> Security Class Initialized
DEBUG - 2025-05-23 16:44:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-23 16:44:20 --> Input Class Initialized
INFO - 2025-05-23 16:44:20 --> Language Class Initialized
INFO - 2025-05-23 16:44:20 --> Loader Class Initialized
INFO - 2025-05-23 16:44:20 --> Helper loaded: url_helper
INFO - 2025-05-23 16:44:20 --> Helper loaded: form_helper
INFO - 2025-05-23 16:44:20 --> Database Driver Class Initialized
DEBUG - 2025-05-23 16:44:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-23 16:44:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-23 16:44:20 --> Controller Class Initialized
INFO - 2025-05-23 16:44:20 --> Model "Olahraga_model" initialized
INFO - 2025-05-23 16:44:20 --> Model "User_model" initialized
INFO - 2025-05-23 16:44:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-23 16:44:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-23 16:44:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/start.php
INFO - 2025-05-23 16:44:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-23 16:44:20 --> Final output sent to browser
DEBUG - 2025-05-23 16:44:20 --> Total execution time: 0.0631
