<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-05-25 12:43:41 --> Config Class Initialized
INFO - 2025-05-25 12:43:41 --> Hooks Class Initialized
DEBUG - 2025-05-25 12:43:41 --> UTF-8 Support Enabled
INFO - 2025-05-25 12:43:41 --> Utf8 Class Initialized
INFO - 2025-05-25 12:43:41 --> URI Class Initialized
DEBUG - 2025-05-25 12:43:41 --> No URI present. Default controller set.
INFO - 2025-05-25 12:43:41 --> Router Class Initialized
INFO - 2025-05-25 12:43:41 --> Output Class Initialized
INFO - 2025-05-25 12:43:41 --> Security Class Initialized
DEBUG - 2025-05-25 12:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 12:43:41 --> Input Class Initialized
INFO - 2025-05-25 12:43:41 --> Language Class Initialized
INFO - 2025-05-25 12:43:41 --> Loader Class Initialized
INFO - 2025-05-25 12:43:41 --> Helper loaded: url_helper
INFO - 2025-05-25 12:43:41 --> Helper loaded: form_helper
INFO - 2025-05-25 12:43:41 --> Database Driver Class Initialized
DEBUG - 2025-05-25 12:43:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 12:43:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 12:43:41 --> Controller Class Initialized
INFO - 2025-05-25 12:43:41 --> Model "User_model" initialized
INFO - 2025-05-25 12:43:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-25 12:43:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-25 12:43:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-25 12:43:41 --> Final output sent to browser
DEBUG - 2025-05-25 12:43:41 --> Total execution time: 0.1289
INFO - 2025-05-25 12:43:50 --> Config Class Initialized
INFO - 2025-05-25 12:43:50 --> Hooks Class Initialized
DEBUG - 2025-05-25 12:43:50 --> UTF-8 Support Enabled
INFO - 2025-05-25 12:43:50 --> Utf8 Class Initialized
INFO - 2025-05-25 12:43:50 --> URI Class Initialized
INFO - 2025-05-25 12:43:50 --> Router Class Initialized
INFO - 2025-05-25 12:43:50 --> Output Class Initialized
INFO - 2025-05-25 12:43:50 --> Security Class Initialized
DEBUG - 2025-05-25 12:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 12:43:50 --> Input Class Initialized
INFO - 2025-05-25 12:43:50 --> Language Class Initialized
INFO - 2025-05-25 12:43:50 --> Loader Class Initialized
INFO - 2025-05-25 12:43:50 --> Helper loaded: url_helper
INFO - 2025-05-25 12:43:50 --> Helper loaded: form_helper
INFO - 2025-05-25 12:43:50 --> Database Driver Class Initialized
DEBUG - 2025-05-25 12:43:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 12:43:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 12:43:50 --> Controller Class Initialized
INFO - 2025-05-25 12:43:50 --> Model "User_model" initialized
INFO - 2025-05-25 12:43:50 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-25 12:43:50 --> Final output sent to browser
DEBUG - 2025-05-25 12:43:50 --> Total execution time: 0.0690
INFO - 2025-05-25 12:44:02 --> Config Class Initialized
INFO - 2025-05-25 12:44:02 --> Hooks Class Initialized
DEBUG - 2025-05-25 12:44:02 --> UTF-8 Support Enabled
INFO - 2025-05-25 12:44:02 --> Utf8 Class Initialized
INFO - 2025-05-25 12:44:02 --> URI Class Initialized
INFO - 2025-05-25 12:44:02 --> Router Class Initialized
INFO - 2025-05-25 12:44:02 --> Output Class Initialized
INFO - 2025-05-25 12:44:02 --> Security Class Initialized
DEBUG - 2025-05-25 12:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 12:44:02 --> Input Class Initialized
INFO - 2025-05-25 12:44:02 --> Language Class Initialized
INFO - 2025-05-25 12:44:02 --> Loader Class Initialized
INFO - 2025-05-25 12:44:02 --> Helper loaded: url_helper
INFO - 2025-05-25 12:44:02 --> Helper loaded: form_helper
INFO - 2025-05-25 12:44:02 --> Database Driver Class Initialized
DEBUG - 2025-05-25 12:44:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 12:44:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 12:44:02 --> Controller Class Initialized
INFO - 2025-05-25 12:44:02 --> Model "User_model" initialized
INFO - 2025-05-25 12:44:02 --> Config Class Initialized
INFO - 2025-05-25 12:44:02 --> Hooks Class Initialized
DEBUG - 2025-05-25 12:44:03 --> UTF-8 Support Enabled
INFO - 2025-05-25 12:44:03 --> Utf8 Class Initialized
INFO - 2025-05-25 12:44:03 --> URI Class Initialized
INFO - 2025-05-25 12:44:03 --> Router Class Initialized
INFO - 2025-05-25 12:44:03 --> Output Class Initialized
INFO - 2025-05-25 12:44:03 --> Security Class Initialized
DEBUG - 2025-05-25 12:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 12:44:03 --> Input Class Initialized
INFO - 2025-05-25 12:44:03 --> Language Class Initialized
INFO - 2025-05-25 12:44:03 --> Loader Class Initialized
INFO - 2025-05-25 12:44:03 --> Helper loaded: url_helper
INFO - 2025-05-25 12:44:03 --> Helper loaded: form_helper
INFO - 2025-05-25 12:44:03 --> Database Driver Class Initialized
DEBUG - 2025-05-25 12:44:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 12:44:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 12:44:03 --> Controller Class Initialized
INFO - 2025-05-25 12:44:03 --> Model "User_model" initialized
INFO - 2025-05-25 12:44:03 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-25 12:44:03 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-25 12:44:03 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-25 12:44:03 --> Final output sent to browser
DEBUG - 2025-05-25 12:44:03 --> Total execution time: 0.0878
INFO - 2025-05-25 12:44:06 --> Config Class Initialized
INFO - 2025-05-25 12:44:06 --> Hooks Class Initialized
DEBUG - 2025-05-25 12:44:06 --> UTF-8 Support Enabled
INFO - 2025-05-25 12:44:06 --> Utf8 Class Initialized
INFO - 2025-05-25 12:44:06 --> URI Class Initialized
INFO - 2025-05-25 12:44:06 --> Router Class Initialized
INFO - 2025-05-25 12:44:06 --> Output Class Initialized
INFO - 2025-05-25 12:44:06 --> Security Class Initialized
DEBUG - 2025-05-25 12:44:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 12:44:06 --> Input Class Initialized
INFO - 2025-05-25 12:44:06 --> Language Class Initialized
INFO - 2025-05-25 12:44:06 --> Loader Class Initialized
INFO - 2025-05-25 12:44:06 --> Helper loaded: url_helper
INFO - 2025-05-25 12:44:06 --> Helper loaded: form_helper
INFO - 2025-05-25 12:44:06 --> Database Driver Class Initialized
DEBUG - 2025-05-25 12:44:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 12:44:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 12:44:06 --> Controller Class Initialized
INFO - 2025-05-25 12:44:06 --> Model "User_model" initialized
INFO - 2025-05-25 12:44:06 --> Model "Workout_model" initialized
INFO - 2025-05-25 12:44:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 12:44:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
ERROR - 2025-05-25 12:44:06 --> Severity: Warning --> Undefined variable $labels C:\laragon\www\Project\fitnessrecord\application\views\dashboard\dashboard.php 135
ERROR - 2025-05-25 12:44:06 --> Severity: Warning --> Undefined variable $latihan C:\laragon\www\Project\fitnessrecord\application\views\dashboard\dashboard.php 136
ERROR - 2025-05-25 12:44:06 --> Severity: Warning --> Undefined variable $kalori C:\laragon\www\Project\fitnessrecord\application\views\dashboard\dashboard.php 137
INFO - 2025-05-25 12:44:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-25 12:44:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 12:44:06 --> Final output sent to browser
DEBUG - 2025-05-25 12:44:06 --> Total execution time: 0.1055
INFO - 2025-05-25 12:44:40 --> Config Class Initialized
INFO - 2025-05-25 12:44:40 --> Hooks Class Initialized
DEBUG - 2025-05-25 12:44:40 --> UTF-8 Support Enabled
INFO - 2025-05-25 12:44:40 --> Utf8 Class Initialized
INFO - 2025-05-25 12:44:40 --> URI Class Initialized
INFO - 2025-05-25 12:44:40 --> Router Class Initialized
INFO - 2025-05-25 12:44:40 --> Output Class Initialized
INFO - 2025-05-25 12:44:40 --> Security Class Initialized
DEBUG - 2025-05-25 12:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 12:44:40 --> Input Class Initialized
INFO - 2025-05-25 12:44:40 --> Language Class Initialized
INFO - 2025-05-25 12:44:40 --> Loader Class Initialized
INFO - 2025-05-25 12:44:40 --> Helper loaded: url_helper
INFO - 2025-05-25 12:44:40 --> Helper loaded: form_helper
INFO - 2025-05-25 12:44:40 --> Database Driver Class Initialized
DEBUG - 2025-05-25 12:44:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 12:44:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 12:44:40 --> Controller Class Initialized
INFO - 2025-05-25 12:44:40 --> Model "User_model" initialized
INFO - 2025-05-25 12:44:40 --> Model "Workout_model" initialized
INFO - 2025-05-25 12:44:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 12:44:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
ERROR - 2025-05-25 12:44:40 --> Severity: Warning --> Undefined variable $labels C:\laragon\www\Project\fitnessrecord\application\views\dashboard\dashboard.php 135
ERROR - 2025-05-25 12:44:40 --> Severity: Warning --> Undefined variable $latihan C:\laragon\www\Project\fitnessrecord\application\views\dashboard\dashboard.php 136
ERROR - 2025-05-25 12:44:40 --> Severity: Warning --> Undefined variable $kalori C:\laragon\www\Project\fitnessrecord\application\views\dashboard\dashboard.php 137
INFO - 2025-05-25 12:44:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-25 12:44:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 12:44:40 --> Final output sent to browser
DEBUG - 2025-05-25 12:44:40 --> Total execution time: 0.0883
INFO - 2025-05-25 12:50:20 --> Config Class Initialized
INFO - 2025-05-25 12:50:20 --> Hooks Class Initialized
DEBUG - 2025-05-25 12:50:20 --> UTF-8 Support Enabled
INFO - 2025-05-25 12:50:20 --> Utf8 Class Initialized
INFO - 2025-05-25 12:50:20 --> URI Class Initialized
INFO - 2025-05-25 12:50:20 --> Router Class Initialized
INFO - 2025-05-25 12:50:20 --> Output Class Initialized
INFO - 2025-05-25 12:50:20 --> Security Class Initialized
DEBUG - 2025-05-25 12:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 12:50:20 --> Input Class Initialized
INFO - 2025-05-25 12:50:20 --> Language Class Initialized
INFO - 2025-05-25 12:50:20 --> Loader Class Initialized
INFO - 2025-05-25 12:50:20 --> Helper loaded: url_helper
INFO - 2025-05-25 12:50:20 --> Helper loaded: form_helper
INFO - 2025-05-25 12:50:20 --> Database Driver Class Initialized
DEBUG - 2025-05-25 12:50:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 12:50:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 12:50:20 --> Controller Class Initialized
INFO - 2025-05-25 12:50:20 --> Model "User_model" initialized
INFO - 2025-05-25 12:50:20 --> Model "Workout_model" initialized
ERROR - 2025-05-25 12:50:20 --> Severity: error --> Exception: Too few arguments to function Dashboard::index(), 0 passed in C:\laragon\www\Project\fitnessrecord\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\Project\fitnessrecord\application\controllers\Dashboard.php 28
INFO - 2025-05-25 12:52:56 --> Config Class Initialized
INFO - 2025-05-25 12:52:56 --> Hooks Class Initialized
DEBUG - 2025-05-25 12:52:56 --> UTF-8 Support Enabled
INFO - 2025-05-25 12:52:56 --> Utf8 Class Initialized
INFO - 2025-05-25 12:52:56 --> URI Class Initialized
INFO - 2025-05-25 12:52:56 --> Router Class Initialized
INFO - 2025-05-25 12:52:56 --> Output Class Initialized
INFO - 2025-05-25 12:52:56 --> Security Class Initialized
DEBUG - 2025-05-25 12:52:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 12:52:56 --> Input Class Initialized
INFO - 2025-05-25 12:52:56 --> Language Class Initialized
INFO - 2025-05-25 12:52:56 --> Loader Class Initialized
INFO - 2025-05-25 12:52:56 --> Helper loaded: url_helper
INFO - 2025-05-25 12:52:56 --> Helper loaded: form_helper
INFO - 2025-05-25 12:52:56 --> Database Driver Class Initialized
DEBUG - 2025-05-25 12:52:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 12:52:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 12:52:56 --> Controller Class Initialized
INFO - 2025-05-25 12:52:56 --> Model "User_model" initialized
INFO - 2025-05-25 12:52:56 --> Model "Workout_model" initialized
INFO - 2025-05-25 12:52:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 12:52:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
ERROR - 2025-05-25 12:52:56 --> Severity: Warning --> Undefined variable $labels C:\laragon\www\Project\fitnessrecord\application\views\dashboard\dashboard.php 122
ERROR - 2025-05-25 12:52:56 --> Severity: Warning --> Undefined variable $latihan C:\laragon\www\Project\fitnessrecord\application\views\dashboard\dashboard.php 123
ERROR - 2025-05-25 12:52:56 --> Severity: Warning --> Undefined variable $kalori C:\laragon\www\Project\fitnessrecord\application\views\dashboard\dashboard.php 124
INFO - 2025-05-25 12:52:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-25 12:52:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 12:52:56 --> Final output sent to browser
DEBUG - 2025-05-25 12:52:56 --> Total execution time: 0.0738
INFO - 2025-05-25 12:54:27 --> Config Class Initialized
INFO - 2025-05-25 12:54:27 --> Hooks Class Initialized
DEBUG - 2025-05-25 12:54:27 --> UTF-8 Support Enabled
INFO - 2025-05-25 12:54:27 --> Utf8 Class Initialized
INFO - 2025-05-25 12:54:27 --> URI Class Initialized
INFO - 2025-05-25 12:54:27 --> Router Class Initialized
INFO - 2025-05-25 12:54:27 --> Output Class Initialized
INFO - 2025-05-25 12:54:27 --> Security Class Initialized
DEBUG - 2025-05-25 12:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 12:54:27 --> Input Class Initialized
INFO - 2025-05-25 12:54:27 --> Language Class Initialized
INFO - 2025-05-25 12:54:27 --> Loader Class Initialized
INFO - 2025-05-25 12:54:27 --> Helper loaded: url_helper
INFO - 2025-05-25 12:54:27 --> Helper loaded: form_helper
INFO - 2025-05-25 12:54:27 --> Database Driver Class Initialized
DEBUG - 2025-05-25 12:54:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 12:54:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 12:54:27 --> Controller Class Initialized
INFO - 2025-05-25 12:54:27 --> Model "Progress_model" initialized
INFO - 2025-05-25 12:54:27 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 12:54:27 --> Model "User_model" initialized
INFO - 2025-05-25 12:54:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 12:54:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 12:54:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-25 12:54:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 12:54:27 --> Final output sent to browser
DEBUG - 2025-05-25 12:54:27 --> Total execution time: 0.0724
INFO - 2025-05-25 12:54:28 --> Config Class Initialized
INFO - 2025-05-25 12:54:28 --> Hooks Class Initialized
DEBUG - 2025-05-25 12:54:28 --> UTF-8 Support Enabled
INFO - 2025-05-25 12:54:28 --> Utf8 Class Initialized
INFO - 2025-05-25 12:54:28 --> URI Class Initialized
INFO - 2025-05-25 12:54:28 --> Router Class Initialized
INFO - 2025-05-25 12:54:28 --> Output Class Initialized
INFO - 2025-05-25 12:54:28 --> Security Class Initialized
DEBUG - 2025-05-25 12:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 12:54:28 --> Input Class Initialized
INFO - 2025-05-25 12:54:28 --> Language Class Initialized
INFO - 2025-05-25 12:54:28 --> Loader Class Initialized
INFO - 2025-05-25 12:54:28 --> Helper loaded: url_helper
INFO - 2025-05-25 12:54:28 --> Helper loaded: form_helper
INFO - 2025-05-25 12:54:28 --> Database Driver Class Initialized
DEBUG - 2025-05-25 12:54:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 12:54:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 12:54:28 --> Controller Class Initialized
INFO - 2025-05-25 12:54:28 --> Model "Progress_model" initialized
INFO - 2025-05-25 12:54:28 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 12:54:28 --> Model "User_model" initialized
INFO - 2025-05-25 12:54:28 --> Final output sent to browser
DEBUG - 2025-05-25 12:54:28 --> Total execution time: 0.0691
INFO - 2025-05-25 12:55:16 --> Config Class Initialized
INFO - 2025-05-25 12:55:16 --> Hooks Class Initialized
DEBUG - 2025-05-25 12:55:16 --> UTF-8 Support Enabled
INFO - 2025-05-25 12:55:16 --> Utf8 Class Initialized
INFO - 2025-05-25 12:55:16 --> URI Class Initialized
INFO - 2025-05-25 12:55:16 --> Router Class Initialized
INFO - 2025-05-25 12:55:16 --> Output Class Initialized
INFO - 2025-05-25 12:55:16 --> Security Class Initialized
DEBUG - 2025-05-25 12:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 12:55:16 --> Input Class Initialized
INFO - 2025-05-25 12:55:16 --> Language Class Initialized
INFO - 2025-05-25 12:55:16 --> Loader Class Initialized
INFO - 2025-05-25 12:55:16 --> Helper loaded: url_helper
INFO - 2025-05-25 12:55:16 --> Helper loaded: form_helper
INFO - 2025-05-25 12:55:16 --> Database Driver Class Initialized
DEBUG - 2025-05-25 12:55:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 12:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 12:55:16 --> Controller Class Initialized
INFO - 2025-05-25 12:55:16 --> Model "Progress_model" initialized
INFO - 2025-05-25 12:55:16 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 12:55:16 --> Model "User_model" initialized
INFO - 2025-05-25 12:55:16 --> Final output sent to browser
DEBUG - 2025-05-25 12:55:16 --> Total execution time: 0.0832
INFO - 2025-05-25 12:55:53 --> Config Class Initialized
INFO - 2025-05-25 12:55:53 --> Hooks Class Initialized
DEBUG - 2025-05-25 12:55:53 --> UTF-8 Support Enabled
INFO - 2025-05-25 12:55:53 --> Utf8 Class Initialized
INFO - 2025-05-25 12:55:53 --> URI Class Initialized
INFO - 2025-05-25 12:55:53 --> Router Class Initialized
INFO - 2025-05-25 12:55:53 --> Output Class Initialized
INFO - 2025-05-25 12:55:53 --> Security Class Initialized
DEBUG - 2025-05-25 12:55:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 12:55:53 --> Input Class Initialized
INFO - 2025-05-25 12:55:53 --> Language Class Initialized
INFO - 2025-05-25 12:55:53 --> Loader Class Initialized
INFO - 2025-05-25 12:55:53 --> Helper loaded: url_helper
INFO - 2025-05-25 12:55:53 --> Helper loaded: form_helper
INFO - 2025-05-25 12:55:53 --> Database Driver Class Initialized
DEBUG - 2025-05-25 12:55:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 12:55:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 12:55:53 --> Controller Class Initialized
INFO - 2025-05-25 12:55:53 --> Model "Progress_model" initialized
INFO - 2025-05-25 12:55:53 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 12:55:53 --> Model "User_model" initialized
INFO - 2025-05-25 12:55:53 --> Final output sent to browser
DEBUG - 2025-05-25 12:55:53 --> Total execution time: 0.0847
INFO - 2025-05-25 12:58:13 --> Config Class Initialized
INFO - 2025-05-25 12:58:13 --> Hooks Class Initialized
DEBUG - 2025-05-25 12:58:13 --> UTF-8 Support Enabled
INFO - 2025-05-25 12:58:13 --> Utf8 Class Initialized
INFO - 2025-05-25 12:58:13 --> URI Class Initialized
INFO - 2025-05-25 12:58:13 --> Router Class Initialized
INFO - 2025-05-25 12:58:13 --> Output Class Initialized
INFO - 2025-05-25 12:58:13 --> Security Class Initialized
DEBUG - 2025-05-25 12:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 12:58:13 --> Input Class Initialized
INFO - 2025-05-25 12:58:13 --> Language Class Initialized
INFO - 2025-05-25 12:58:13 --> Loader Class Initialized
INFO - 2025-05-25 12:58:13 --> Helper loaded: url_helper
INFO - 2025-05-25 12:58:13 --> Helper loaded: form_helper
INFO - 2025-05-25 12:58:13 --> Database Driver Class Initialized
DEBUG - 2025-05-25 12:58:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 12:58:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 12:58:13 --> Controller Class Initialized
INFO - 2025-05-25 12:58:13 --> Model "User_model" initialized
INFO - 2025-05-25 12:58:13 --> Model "Workout_model" initialized
INFO - 2025-05-25 12:58:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 12:58:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
ERROR - 2025-05-25 12:58:13 --> Severity: Warning --> Undefined variable $labels C:\laragon\www\Project\fitnessrecord\application\views\dashboard\dashboard.php 94
ERROR - 2025-05-25 12:58:13 --> Severity: Warning --> Undefined variable $latihan C:\laragon\www\Project\fitnessrecord\application\views\dashboard\dashboard.php 95
ERROR - 2025-05-25 12:58:13 --> Severity: Warning --> Undefined variable $kalori C:\laragon\www\Project\fitnessrecord\application\views\dashboard\dashboard.php 96
INFO - 2025-05-25 12:58:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-25 12:58:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 12:58:13 --> Final output sent to browser
DEBUG - 2025-05-25 12:58:13 --> Total execution time: 0.0874
INFO - 2025-05-25 13:06:08 --> Config Class Initialized
INFO - 2025-05-25 13:06:08 --> Hooks Class Initialized
DEBUG - 2025-05-25 13:06:08 --> UTF-8 Support Enabled
INFO - 2025-05-25 13:06:08 --> Utf8 Class Initialized
INFO - 2025-05-25 13:06:08 --> URI Class Initialized
INFO - 2025-05-25 13:06:08 --> Router Class Initialized
INFO - 2025-05-25 13:06:08 --> Output Class Initialized
INFO - 2025-05-25 13:06:08 --> Security Class Initialized
DEBUG - 2025-05-25 13:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 13:06:08 --> Input Class Initialized
INFO - 2025-05-25 13:06:08 --> Language Class Initialized
INFO - 2025-05-25 13:06:08 --> Loader Class Initialized
INFO - 2025-05-25 13:06:08 --> Helper loaded: url_helper
INFO - 2025-05-25 13:06:08 --> Helper loaded: form_helper
INFO - 2025-05-25 13:06:08 --> Database Driver Class Initialized
DEBUG - 2025-05-25 13:06:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 13:06:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 13:06:08 --> Controller Class Initialized
INFO - 2025-05-25 13:06:08 --> Model "User_model" initialized
INFO - 2025-05-25 13:06:08 --> Model "Workout_model" initialized
ERROR - 2025-05-25 13:06:08 --> Severity: Warning --> Undefined property: Dashboard::$Progress_model C:\laragon\www\Project\fitnessrecord\application\controllers\Dashboard.php 31
ERROR - 2025-05-25 13:06:08 --> Severity: error --> Exception: Call to a member function get_weekly_summary() on null C:\laragon\www\Project\fitnessrecord\application\controllers\Dashboard.php 31
INFO - 2025-05-25 13:06:38 --> Config Class Initialized
INFO - 2025-05-25 13:06:38 --> Hooks Class Initialized
DEBUG - 2025-05-25 13:06:38 --> UTF-8 Support Enabled
INFO - 2025-05-25 13:06:38 --> Utf8 Class Initialized
INFO - 2025-05-25 13:06:38 --> URI Class Initialized
INFO - 2025-05-25 13:06:38 --> Router Class Initialized
INFO - 2025-05-25 13:06:38 --> Output Class Initialized
INFO - 2025-05-25 13:06:38 --> Security Class Initialized
DEBUG - 2025-05-25 13:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 13:06:38 --> Input Class Initialized
INFO - 2025-05-25 13:06:38 --> Language Class Initialized
INFO - 2025-05-25 13:06:38 --> Loader Class Initialized
INFO - 2025-05-25 13:06:38 --> Helper loaded: url_helper
INFO - 2025-05-25 13:06:38 --> Helper loaded: form_helper
INFO - 2025-05-25 13:06:38 --> Database Driver Class Initialized
DEBUG - 2025-05-25 13:06:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 13:06:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 13:06:38 --> Controller Class Initialized
INFO - 2025-05-25 13:06:38 --> Model "User_model" initialized
INFO - 2025-05-25 13:06:38 --> Model "Progress_model" initialized
ERROR - 2025-05-25 13:06:38 --> Severity: Warning --> Undefined variable $user C:\laragon\www\Project\fitnessrecord\application\views\dashboard\layout\header.php 50
ERROR - 2025-05-25 13:06:38 --> Severity: Warning --> Attempt to read property "name" on null C:\laragon\www\Project\fitnessrecord\application\views\dashboard\layout\header.php 50
INFO - 2025-05-25 13:06:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
ERROR - 2025-05-25 13:06:38 --> Severity: Warning --> Undefined variable $user C:\laragon\www\Project\fitnessrecord\application\views\dashboard\layout\sidebar.php 68
ERROR - 2025-05-25 13:06:38 --> Severity: Warning --> Attempt to read property "name" on null C:\laragon\www\Project\fitnessrecord\application\views\dashboard\layout\sidebar.php 68
INFO - 2025-05-25 13:06:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
ERROR - 2025-05-25 13:06:38 --> Severity: Warning --> Undefined property: stdClass::$target_otot C:\laragon\www\Project\fitnessrecord\application\views\dashboard\dashboard.php 71
ERROR - 2025-05-25 13:06:38 --> Severity: 8192 --> ucfirst(): Passing null to parameter #1 ($string) of type string is deprecated C:\laragon\www\Project\fitnessrecord\application\views\dashboard\dashboard.php 71
ERROR - 2025-05-25 13:06:38 --> Severity: Warning --> Undefined variable $labels C:\laragon\www\Project\fitnessrecord\application\views\dashboard\dashboard.php 96
ERROR - 2025-05-25 13:06:38 --> Severity: Warning --> Undefined variable $latihan C:\laragon\www\Project\fitnessrecord\application\views\dashboard\dashboard.php 97
ERROR - 2025-05-25 13:06:38 --> Severity: Warning --> Undefined variable $kalori C:\laragon\www\Project\fitnessrecord\application\views\dashboard\dashboard.php 98
INFO - 2025-05-25 13:06:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-25 13:06:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 13:06:39 --> Final output sent to browser
DEBUG - 2025-05-25 13:06:39 --> Total execution time: 0.1127
INFO - 2025-05-25 13:08:09 --> Config Class Initialized
INFO - 2025-05-25 13:08:09 --> Hooks Class Initialized
DEBUG - 2025-05-25 13:08:09 --> UTF-8 Support Enabled
INFO - 2025-05-25 13:08:09 --> Utf8 Class Initialized
INFO - 2025-05-25 13:08:09 --> URI Class Initialized
INFO - 2025-05-25 13:08:09 --> Router Class Initialized
INFO - 2025-05-25 13:08:09 --> Output Class Initialized
INFO - 2025-05-25 13:08:09 --> Security Class Initialized
DEBUG - 2025-05-25 13:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 13:08:09 --> Input Class Initialized
INFO - 2025-05-25 13:08:09 --> Language Class Initialized
INFO - 2025-05-25 13:08:09 --> Loader Class Initialized
INFO - 2025-05-25 13:08:09 --> Helper loaded: url_helper
INFO - 2025-05-25 13:08:09 --> Helper loaded: form_helper
INFO - 2025-05-25 13:08:09 --> Database Driver Class Initialized
DEBUG - 2025-05-25 13:08:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 13:08:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 13:08:09 --> Controller Class Initialized
INFO - 2025-05-25 13:08:09 --> Model "User_model" initialized
INFO - 2025-05-25 13:08:09 --> Model "Progress_model" initialized
INFO - 2025-05-25 13:08:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 13:08:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
ERROR - 2025-05-25 13:08:09 --> Severity: Warning --> Undefined property: stdClass::$target_otot C:\laragon\www\Project\fitnessrecord\application\views\dashboard\dashboard.php 71
ERROR - 2025-05-25 13:08:09 --> Severity: 8192 --> ucfirst(): Passing null to parameter #1 ($string) of type string is deprecated C:\laragon\www\Project\fitnessrecord\application\views\dashboard\dashboard.php 71
ERROR - 2025-05-25 13:08:09 --> Severity: Warning --> Undefined variable $labels C:\laragon\www\Project\fitnessrecord\application\views\dashboard\dashboard.php 96
ERROR - 2025-05-25 13:08:09 --> Severity: Warning --> Undefined variable $latihan C:\laragon\www\Project\fitnessrecord\application\views\dashboard\dashboard.php 97
ERROR - 2025-05-25 13:08:09 --> Severity: Warning --> Undefined variable $kalori C:\laragon\www\Project\fitnessrecord\application\views\dashboard\dashboard.php 98
INFO - 2025-05-25 13:08:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-25 13:08:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 13:08:09 --> Final output sent to browser
DEBUG - 2025-05-25 13:08:09 --> Total execution time: 0.0700
INFO - 2025-05-25 13:09:22 --> Config Class Initialized
INFO - 2025-05-25 13:09:22 --> Hooks Class Initialized
DEBUG - 2025-05-25 13:09:22 --> UTF-8 Support Enabled
INFO - 2025-05-25 13:09:22 --> Utf8 Class Initialized
INFO - 2025-05-25 13:09:22 --> URI Class Initialized
INFO - 2025-05-25 13:09:22 --> Router Class Initialized
INFO - 2025-05-25 13:09:22 --> Output Class Initialized
INFO - 2025-05-25 13:09:22 --> Security Class Initialized
DEBUG - 2025-05-25 13:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 13:09:22 --> Input Class Initialized
INFO - 2025-05-25 13:09:22 --> Language Class Initialized
INFO - 2025-05-25 13:09:22 --> Loader Class Initialized
INFO - 2025-05-25 13:09:22 --> Helper loaded: url_helper
INFO - 2025-05-25 13:09:22 --> Helper loaded: form_helper
INFO - 2025-05-25 13:09:22 --> Database Driver Class Initialized
DEBUG - 2025-05-25 13:09:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 13:09:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 13:09:22 --> Controller Class Initialized
INFO - 2025-05-25 13:09:22 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 13:09:22 --> Model "User_model" initialized
INFO - 2025-05-25 13:09:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 13:09:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 13:09:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-05-25 13:09:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 13:09:22 --> Final output sent to browser
DEBUG - 2025-05-25 13:09:22 --> Total execution time: 0.0735
INFO - 2025-05-25 13:09:24 --> Config Class Initialized
INFO - 2025-05-25 13:09:24 --> Hooks Class Initialized
DEBUG - 2025-05-25 13:09:24 --> UTF-8 Support Enabled
INFO - 2025-05-25 13:09:24 --> Utf8 Class Initialized
INFO - 2025-05-25 13:09:24 --> URI Class Initialized
INFO - 2025-05-25 13:09:24 --> Router Class Initialized
INFO - 2025-05-25 13:09:24 --> Output Class Initialized
INFO - 2025-05-25 13:09:24 --> Security Class Initialized
DEBUG - 2025-05-25 13:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 13:09:24 --> Input Class Initialized
INFO - 2025-05-25 13:09:24 --> Language Class Initialized
INFO - 2025-05-25 13:09:24 --> Loader Class Initialized
INFO - 2025-05-25 13:09:24 --> Helper loaded: url_helper
INFO - 2025-05-25 13:09:24 --> Helper loaded: form_helper
INFO - 2025-05-25 13:09:24 --> Database Driver Class Initialized
DEBUG - 2025-05-25 13:09:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 13:09:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 13:09:24 --> Controller Class Initialized
INFO - 2025-05-25 13:09:24 --> Model "Progress_model" initialized
INFO - 2025-05-25 13:09:24 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 13:09:24 --> Model "User_model" initialized
INFO - 2025-05-25 13:09:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 13:09:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 13:09:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-25 13:09:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 13:09:24 --> Final output sent to browser
DEBUG - 2025-05-25 13:09:24 --> Total execution time: 0.0641
INFO - 2025-05-25 13:09:24 --> Config Class Initialized
INFO - 2025-05-25 13:09:24 --> Hooks Class Initialized
DEBUG - 2025-05-25 13:09:24 --> UTF-8 Support Enabled
INFO - 2025-05-25 13:09:24 --> Utf8 Class Initialized
INFO - 2025-05-25 13:09:24 --> URI Class Initialized
INFO - 2025-05-25 13:09:24 --> Router Class Initialized
INFO - 2025-05-25 13:09:24 --> Output Class Initialized
INFO - 2025-05-25 13:09:24 --> Security Class Initialized
DEBUG - 2025-05-25 13:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 13:09:24 --> Input Class Initialized
INFO - 2025-05-25 13:09:24 --> Language Class Initialized
INFO - 2025-05-25 13:09:24 --> Loader Class Initialized
INFO - 2025-05-25 13:09:24 --> Helper loaded: url_helper
INFO - 2025-05-25 13:09:24 --> Helper loaded: form_helper
INFO - 2025-05-25 13:09:24 --> Database Driver Class Initialized
DEBUG - 2025-05-25 13:09:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 13:09:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 13:09:24 --> Controller Class Initialized
INFO - 2025-05-25 13:09:24 --> Model "Progress_model" initialized
INFO - 2025-05-25 13:09:24 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 13:09:24 --> Model "User_model" initialized
INFO - 2025-05-25 13:09:24 --> Final output sent to browser
DEBUG - 2025-05-25 13:09:24 --> Total execution time: 0.0819
INFO - 2025-05-25 13:09:27 --> Config Class Initialized
INFO - 2025-05-25 13:09:27 --> Hooks Class Initialized
DEBUG - 2025-05-25 13:09:27 --> UTF-8 Support Enabled
INFO - 2025-05-25 13:09:27 --> Utf8 Class Initialized
INFO - 2025-05-25 13:09:27 --> URI Class Initialized
INFO - 2025-05-25 13:09:27 --> Router Class Initialized
INFO - 2025-05-25 13:09:27 --> Output Class Initialized
INFO - 2025-05-25 13:09:27 --> Security Class Initialized
DEBUG - 2025-05-25 13:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 13:09:27 --> Input Class Initialized
INFO - 2025-05-25 13:09:27 --> Language Class Initialized
INFO - 2025-05-25 13:09:27 --> Loader Class Initialized
INFO - 2025-05-25 13:09:27 --> Helper loaded: url_helper
INFO - 2025-05-25 13:09:27 --> Helper loaded: form_helper
INFO - 2025-05-25 13:09:27 --> Database Driver Class Initialized
DEBUG - 2025-05-25 13:09:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 13:09:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 13:09:27 --> Controller Class Initialized
INFO - 2025-05-25 13:09:27 --> Model "Progress_model" initialized
INFO - 2025-05-25 13:09:27 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 13:09:27 --> Model "User_model" initialized
INFO - 2025-05-25 13:09:27 --> Final output sent to browser
DEBUG - 2025-05-25 13:09:27 --> Total execution time: 0.0846
INFO - 2025-05-25 13:09:32 --> Config Class Initialized
INFO - 2025-05-25 13:09:32 --> Hooks Class Initialized
DEBUG - 2025-05-25 13:09:32 --> UTF-8 Support Enabled
INFO - 2025-05-25 13:09:32 --> Utf8 Class Initialized
INFO - 2025-05-25 13:09:32 --> URI Class Initialized
INFO - 2025-05-25 13:09:32 --> Router Class Initialized
INFO - 2025-05-25 13:09:32 --> Output Class Initialized
INFO - 2025-05-25 13:09:32 --> Security Class Initialized
DEBUG - 2025-05-25 13:09:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 13:09:32 --> Input Class Initialized
INFO - 2025-05-25 13:09:32 --> Language Class Initialized
INFO - 2025-05-25 13:09:32 --> Loader Class Initialized
INFO - 2025-05-25 13:09:32 --> Helper loaded: url_helper
INFO - 2025-05-25 13:09:32 --> Helper loaded: form_helper
INFO - 2025-05-25 13:09:32 --> Database Driver Class Initialized
DEBUG - 2025-05-25 13:09:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 13:09:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 13:09:32 --> Controller Class Initialized
INFO - 2025-05-25 13:09:32 --> Model "User_model" initialized
INFO - 2025-05-25 13:09:32 --> Model "Progress_model" initialized
INFO - 2025-05-25 13:09:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 13:09:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
ERROR - 2025-05-25 13:09:32 --> Severity: Warning --> Undefined property: stdClass::$target_otot C:\laragon\www\Project\fitnessrecord\application\views\dashboard\dashboard.php 71
ERROR - 2025-05-25 13:09:32 --> Severity: 8192 --> ucfirst(): Passing null to parameter #1 ($string) of type string is deprecated C:\laragon\www\Project\fitnessrecord\application\views\dashboard\dashboard.php 71
ERROR - 2025-05-25 13:09:32 --> Severity: Warning --> Undefined variable $labels C:\laragon\www\Project\fitnessrecord\application\views\dashboard\dashboard.php 96
ERROR - 2025-05-25 13:09:32 --> Severity: Warning --> Undefined variable $latihan C:\laragon\www\Project\fitnessrecord\application\views\dashboard\dashboard.php 97
ERROR - 2025-05-25 13:09:32 --> Severity: Warning --> Undefined variable $kalori C:\laragon\www\Project\fitnessrecord\application\views\dashboard\dashboard.php 98
INFO - 2025-05-25 13:09:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-25 13:09:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 13:09:32 --> Final output sent to browser
DEBUG - 2025-05-25 13:09:32 --> Total execution time: 0.0830
INFO - 2025-05-25 13:11:51 --> Config Class Initialized
INFO - 2025-05-25 13:11:51 --> Hooks Class Initialized
DEBUG - 2025-05-25 13:11:51 --> UTF-8 Support Enabled
INFO - 2025-05-25 13:11:51 --> Utf8 Class Initialized
INFO - 2025-05-25 13:11:51 --> URI Class Initialized
INFO - 2025-05-25 13:11:51 --> Router Class Initialized
INFO - 2025-05-25 13:11:51 --> Output Class Initialized
INFO - 2025-05-25 13:11:51 --> Security Class Initialized
DEBUG - 2025-05-25 13:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 13:11:51 --> Input Class Initialized
INFO - 2025-05-25 13:11:51 --> Language Class Initialized
INFO - 2025-05-25 13:11:51 --> Loader Class Initialized
INFO - 2025-05-25 13:11:51 --> Helper loaded: url_helper
INFO - 2025-05-25 13:11:51 --> Helper loaded: form_helper
INFO - 2025-05-25 13:11:51 --> Database Driver Class Initialized
DEBUG - 2025-05-25 13:11:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 13:11:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 13:11:51 --> Controller Class Initialized
INFO - 2025-05-25 13:11:51 --> Model "User_model" initialized
INFO - 2025-05-25 13:11:51 --> Model "Progress_model" initialized
ERROR - 2025-05-25 13:11:51 --> Query error: Unknown column 'fp.id_latihan' in 'on clause' - Invalid query: SELECT `fp`.*, `ml`.`target_otot`, `ml`.`level`
FROM `fitness_progress` `fp`
LEFT JOIN `menu_latihan` `ml` ON `fp`.`id_latihan` = `ml`.`id`
WHERE `fp`.`user_id` = '2'
AND `fp`.`status` = 'selesai'
ORDER BY `fp`.`progress_date` DESC
 LIMIT 5
INFO - 2025-05-25 13:11:51 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-25 13:12:39 --> Config Class Initialized
INFO - 2025-05-25 13:12:39 --> Hooks Class Initialized
DEBUG - 2025-05-25 13:12:39 --> UTF-8 Support Enabled
INFO - 2025-05-25 13:12:39 --> Utf8 Class Initialized
INFO - 2025-05-25 13:12:39 --> URI Class Initialized
INFO - 2025-05-25 13:12:39 --> Router Class Initialized
INFO - 2025-05-25 13:12:39 --> Output Class Initialized
INFO - 2025-05-25 13:12:39 --> Security Class Initialized
DEBUG - 2025-05-25 13:12:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 13:12:39 --> Input Class Initialized
INFO - 2025-05-25 13:12:40 --> Language Class Initialized
INFO - 2025-05-25 13:12:40 --> Loader Class Initialized
INFO - 2025-05-25 13:12:40 --> Helper loaded: url_helper
INFO - 2025-05-25 13:12:40 --> Helper loaded: form_helper
INFO - 2025-05-25 13:12:40 --> Database Driver Class Initialized
DEBUG - 2025-05-25 13:12:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 13:12:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 13:12:40 --> Controller Class Initialized
INFO - 2025-05-25 13:12:40 --> Model "User_model" initialized
INFO - 2025-05-25 13:12:40 --> Model "Progress_model" initialized
INFO - 2025-05-25 13:12:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 13:12:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
ERROR - 2025-05-25 13:12:40 --> Severity: Warning --> Undefined variable $labels C:\laragon\www\Project\fitnessrecord\application\views\dashboard\dashboard.php 96
ERROR - 2025-05-25 13:12:40 --> Severity: Warning --> Undefined variable $latihan C:\laragon\www\Project\fitnessrecord\application\views\dashboard\dashboard.php 97
ERROR - 2025-05-25 13:12:40 --> Severity: Warning --> Undefined variable $kalori C:\laragon\www\Project\fitnessrecord\application\views\dashboard\dashboard.php 98
INFO - 2025-05-25 13:12:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-25 13:12:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 13:12:40 --> Final output sent to browser
DEBUG - 2025-05-25 13:12:40 --> Total execution time: 0.0713
INFO - 2025-05-25 13:20:14 --> Config Class Initialized
INFO - 2025-05-25 13:20:14 --> Hooks Class Initialized
DEBUG - 2025-05-25 13:20:14 --> UTF-8 Support Enabled
INFO - 2025-05-25 13:20:14 --> Utf8 Class Initialized
INFO - 2025-05-25 13:20:14 --> URI Class Initialized
INFO - 2025-05-25 13:20:14 --> Router Class Initialized
INFO - 2025-05-25 13:20:14 --> Output Class Initialized
INFO - 2025-05-25 13:20:14 --> Security Class Initialized
DEBUG - 2025-05-25 13:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 13:20:14 --> Input Class Initialized
INFO - 2025-05-25 13:20:14 --> Language Class Initialized
INFO - 2025-05-25 13:20:14 --> Loader Class Initialized
INFO - 2025-05-25 13:20:14 --> Helper loaded: url_helper
INFO - 2025-05-25 13:20:14 --> Helper loaded: form_helper
INFO - 2025-05-25 13:20:14 --> Database Driver Class Initialized
DEBUG - 2025-05-25 13:20:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 13:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 13:20:14 --> Controller Class Initialized
INFO - 2025-05-25 13:20:14 --> Model "User_model" initialized
INFO - 2025-05-25 13:20:14 --> Model "Progress_model" initialized
ERROR - 2025-05-25 13:20:14 --> Query error: Unknown column 'ml.muscle' in 'field list' - Invalid query: SELECT `fp`.*, `ml`.`muscle`, `ml`.`level`
FROM `fitness_progress` `fp`
LEFT JOIN `menu_latihan` `ml` ON `fp`.`id` = `ml`.`id`
WHERE `fp`.`user_id` = '2'
AND `fp`.`status` = 'selesai'
ORDER BY `fp`.`progress_date` DESC
 LIMIT 5
INFO - 2025-05-25 13:20:14 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-25 13:23:13 --> Config Class Initialized
INFO - 2025-05-25 13:23:13 --> Hooks Class Initialized
DEBUG - 2025-05-25 13:23:13 --> UTF-8 Support Enabled
INFO - 2025-05-25 13:23:13 --> Utf8 Class Initialized
INFO - 2025-05-25 13:23:13 --> URI Class Initialized
INFO - 2025-05-25 13:23:13 --> Router Class Initialized
INFO - 2025-05-25 13:23:13 --> Output Class Initialized
INFO - 2025-05-25 13:23:13 --> Security Class Initialized
DEBUG - 2025-05-25 13:23:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 13:23:13 --> Input Class Initialized
INFO - 2025-05-25 13:23:13 --> Language Class Initialized
INFO - 2025-05-25 13:23:13 --> Loader Class Initialized
INFO - 2025-05-25 13:23:13 --> Helper loaded: url_helper
INFO - 2025-05-25 13:23:13 --> Helper loaded: form_helper
INFO - 2025-05-25 13:23:13 --> Database Driver Class Initialized
DEBUG - 2025-05-25 13:23:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 13:23:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 13:23:13 --> Controller Class Initialized
INFO - 2025-05-25 13:23:13 --> Model "User_model" initialized
INFO - 2025-05-25 13:23:13 --> Model "Progress_model" initialized
INFO - 2025-05-25 13:23:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 13:23:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
ERROR - 2025-05-25 13:23:13 --> Severity: Warning --> Undefined variable $recent_workouts C:\laragon\www\Project\fitnessrecord\application\views\dashboard\dashboard.php 65
ERROR - 2025-05-25 13:23:13 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\laragon\www\Project\fitnessrecord\application\views\dashboard\dashboard.php 65
ERROR - 2025-05-25 13:23:13 --> Severity: Warning --> Undefined variable $labels C:\laragon\www\Project\fitnessrecord\application\views\dashboard\dashboard.php 96
ERROR - 2025-05-25 13:23:13 --> Severity: Warning --> Undefined variable $latihan C:\laragon\www\Project\fitnessrecord\application\views\dashboard\dashboard.php 97
ERROR - 2025-05-25 13:23:13 --> Severity: Warning --> Undefined variable $kalori C:\laragon\www\Project\fitnessrecord\application\views\dashboard\dashboard.php 98
INFO - 2025-05-25 13:23:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-25 13:23:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 13:23:13 --> Final output sent to browser
DEBUG - 2025-05-25 13:23:13 --> Total execution time: 0.0768
INFO - 2025-05-25 13:23:32 --> Config Class Initialized
INFO - 2025-05-25 13:23:32 --> Hooks Class Initialized
DEBUG - 2025-05-25 13:23:32 --> UTF-8 Support Enabled
INFO - 2025-05-25 13:23:32 --> Utf8 Class Initialized
INFO - 2025-05-25 13:23:32 --> URI Class Initialized
INFO - 2025-05-25 13:23:33 --> Router Class Initialized
INFO - 2025-05-25 13:23:33 --> Output Class Initialized
INFO - 2025-05-25 13:23:33 --> Security Class Initialized
DEBUG - 2025-05-25 13:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 13:23:33 --> Input Class Initialized
INFO - 2025-05-25 13:23:33 --> Language Class Initialized
INFO - 2025-05-25 13:23:33 --> Loader Class Initialized
INFO - 2025-05-25 13:23:33 --> Helper loaded: url_helper
INFO - 2025-05-25 13:23:33 --> Helper loaded: form_helper
INFO - 2025-05-25 13:23:33 --> Database Driver Class Initialized
DEBUG - 2025-05-25 13:23:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 13:23:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 13:23:33 --> Controller Class Initialized
INFO - 2025-05-25 13:23:33 --> Model "User_model" initialized
INFO - 2025-05-25 13:23:33 --> Model "Progress_model" initialized
INFO - 2025-05-25 13:23:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 13:23:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
ERROR - 2025-05-25 13:23:33 --> Severity: Warning --> Attempt to read property "activity" on int C:\laragon\www\Project\fitnessrecord\application\views\dashboard\dashboard.php 68
ERROR - 2025-05-25 13:23:33 --> Severity: Warning --> Attempt to read property "duration_minutes" on int C:\laragon\www\Project\fitnessrecord\application\views\dashboard\dashboard.php 77
ERROR - 2025-05-25 13:23:33 --> Severity: Warning --> Attempt to read property "calories" on int C:\laragon\www\Project\fitnessrecord\application\views\dashboard\dashboard.php 80
ERROR - 2025-05-25 13:23:33 --> Severity: Warning --> Attempt to read property "progress_date" on int C:\laragon\www\Project\fitnessrecord\application\views\dashboard\dashboard.php 83
ERROR - 2025-05-25 13:23:33 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\laragon\www\Project\fitnessrecord\application\views\dashboard\dashboard.php 83
ERROR - 2025-05-25 13:23:33 --> Severity: Warning --> Attempt to read property "activity" on int C:\laragon\www\Project\fitnessrecord\application\views\dashboard\dashboard.php 68
ERROR - 2025-05-25 13:23:33 --> Severity: Warning --> Attempt to read property "duration_minutes" on int C:\laragon\www\Project\fitnessrecord\application\views\dashboard\dashboard.php 77
ERROR - 2025-05-25 13:23:33 --> Severity: Warning --> Attempt to read property "calories" on int C:\laragon\www\Project\fitnessrecord\application\views\dashboard\dashboard.php 80
ERROR - 2025-05-25 13:23:33 --> Severity: Warning --> Attempt to read property "progress_date" on int C:\laragon\www\Project\fitnessrecord\application\views\dashboard\dashboard.php 83
ERROR - 2025-05-25 13:23:33 --> Severity: 8192 --> strtotime(): Passing null to parameter #1 ($datetime) of type string is deprecated C:\laragon\www\Project\fitnessrecord\application\views\dashboard\dashboard.php 83
ERROR - 2025-05-25 13:23:33 --> Severity: Warning --> Undefined variable $labels C:\laragon\www\Project\fitnessrecord\application\views\dashboard\dashboard.php 96
ERROR - 2025-05-25 13:23:33 --> Severity: Warning --> Undefined variable $latihan C:\laragon\www\Project\fitnessrecord\application\views\dashboard\dashboard.php 97
ERROR - 2025-05-25 13:23:33 --> Severity: Warning --> Undefined variable $kalori C:\laragon\www\Project\fitnessrecord\application\views\dashboard\dashboard.php 98
INFO - 2025-05-25 13:23:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-25 13:23:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 13:23:33 --> Final output sent to browser
DEBUG - 2025-05-25 13:23:33 --> Total execution time: 0.0815
INFO - 2025-05-25 13:26:50 --> Config Class Initialized
INFO - 2025-05-25 13:26:50 --> Hooks Class Initialized
DEBUG - 2025-05-25 13:26:50 --> UTF-8 Support Enabled
INFO - 2025-05-25 13:26:50 --> Utf8 Class Initialized
INFO - 2025-05-25 13:26:50 --> URI Class Initialized
INFO - 2025-05-25 13:26:50 --> Router Class Initialized
INFO - 2025-05-25 13:26:50 --> Output Class Initialized
INFO - 2025-05-25 13:26:50 --> Security Class Initialized
DEBUG - 2025-05-25 13:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 13:26:50 --> Input Class Initialized
INFO - 2025-05-25 13:26:50 --> Language Class Initialized
INFO - 2025-05-25 13:26:50 --> Loader Class Initialized
INFO - 2025-05-25 13:26:50 --> Helper loaded: url_helper
INFO - 2025-05-25 13:26:50 --> Helper loaded: form_helper
INFO - 2025-05-25 13:26:50 --> Database Driver Class Initialized
DEBUG - 2025-05-25 13:26:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 13:26:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 13:26:50 --> Controller Class Initialized
INFO - 2025-05-25 13:26:50 --> Model "User_model" initialized
INFO - 2025-05-25 13:26:50 --> Model "Progress_model" initialized
INFO - 2025-05-25 13:26:50 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 13:26:50 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
ERROR - 2025-05-25 13:26:50 --> Severity: Warning --> Undefined variable $labels C:\laragon\www\Project\fitnessrecord\application\views\dashboard\dashboard.php 96
ERROR - 2025-05-25 13:26:50 --> Severity: Warning --> Undefined variable $latihan C:\laragon\www\Project\fitnessrecord\application\views\dashboard\dashboard.php 97
ERROR - 2025-05-25 13:26:50 --> Severity: Warning --> Undefined variable $kalori C:\laragon\www\Project\fitnessrecord\application\views\dashboard\dashboard.php 98
INFO - 2025-05-25 13:26:50 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-25 13:26:50 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 13:26:50 --> Final output sent to browser
DEBUG - 2025-05-25 13:26:50 --> Total execution time: 0.0867
INFO - 2025-05-25 13:26:56 --> Config Class Initialized
INFO - 2025-05-25 13:26:56 --> Hooks Class Initialized
DEBUG - 2025-05-25 13:26:56 --> UTF-8 Support Enabled
INFO - 2025-05-25 13:26:56 --> Utf8 Class Initialized
INFO - 2025-05-25 13:26:56 --> URI Class Initialized
INFO - 2025-05-25 13:26:56 --> Router Class Initialized
INFO - 2025-05-25 13:26:56 --> Output Class Initialized
INFO - 2025-05-25 13:26:56 --> Security Class Initialized
DEBUG - 2025-05-25 13:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 13:26:56 --> Input Class Initialized
INFO - 2025-05-25 13:26:56 --> Language Class Initialized
INFO - 2025-05-25 13:26:56 --> Loader Class Initialized
INFO - 2025-05-25 13:26:56 --> Helper loaded: url_helper
INFO - 2025-05-25 13:26:56 --> Helper loaded: form_helper
INFO - 2025-05-25 13:26:56 --> Database Driver Class Initialized
DEBUG - 2025-05-25 13:26:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 13:26:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 13:26:56 --> Controller Class Initialized
INFO - 2025-05-25 13:26:56 --> Model "Progress_model" initialized
INFO - 2025-05-25 13:26:56 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 13:26:56 --> Model "User_model" initialized
INFO - 2025-05-25 13:26:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 13:26:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 13:26:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-25 13:26:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 13:26:56 --> Final output sent to browser
DEBUG - 2025-05-25 13:26:56 --> Total execution time: 0.0573
INFO - 2025-05-25 13:26:56 --> Config Class Initialized
INFO - 2025-05-25 13:26:56 --> Hooks Class Initialized
DEBUG - 2025-05-25 13:26:56 --> UTF-8 Support Enabled
INFO - 2025-05-25 13:26:56 --> Utf8 Class Initialized
INFO - 2025-05-25 13:26:56 --> URI Class Initialized
INFO - 2025-05-25 13:26:56 --> Router Class Initialized
INFO - 2025-05-25 13:26:56 --> Output Class Initialized
INFO - 2025-05-25 13:26:56 --> Security Class Initialized
DEBUG - 2025-05-25 13:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 13:26:56 --> Input Class Initialized
INFO - 2025-05-25 13:26:56 --> Language Class Initialized
INFO - 2025-05-25 13:26:56 --> Loader Class Initialized
INFO - 2025-05-25 13:26:56 --> Helper loaded: url_helper
INFO - 2025-05-25 13:26:56 --> Helper loaded: form_helper
INFO - 2025-05-25 13:26:56 --> Database Driver Class Initialized
DEBUG - 2025-05-25 13:26:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 13:26:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 13:26:56 --> Controller Class Initialized
INFO - 2025-05-25 13:26:56 --> Model "Progress_model" initialized
INFO - 2025-05-25 13:26:56 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 13:26:56 --> Model "User_model" initialized
INFO - 2025-05-25 13:26:56 --> Final output sent to browser
DEBUG - 2025-05-25 13:26:56 --> Total execution time: 0.0570
INFO - 2025-05-25 13:26:58 --> Config Class Initialized
INFO - 2025-05-25 13:26:58 --> Hooks Class Initialized
DEBUG - 2025-05-25 13:26:58 --> UTF-8 Support Enabled
INFO - 2025-05-25 13:26:58 --> Utf8 Class Initialized
INFO - 2025-05-25 13:26:58 --> URI Class Initialized
INFO - 2025-05-25 13:26:58 --> Router Class Initialized
INFO - 2025-05-25 13:26:58 --> Output Class Initialized
INFO - 2025-05-25 13:26:58 --> Security Class Initialized
DEBUG - 2025-05-25 13:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 13:26:58 --> Input Class Initialized
INFO - 2025-05-25 13:26:58 --> Language Class Initialized
INFO - 2025-05-25 13:26:58 --> Loader Class Initialized
INFO - 2025-05-25 13:26:58 --> Helper loaded: url_helper
INFO - 2025-05-25 13:26:58 --> Helper loaded: form_helper
INFO - 2025-05-25 13:26:59 --> Database Driver Class Initialized
DEBUG - 2025-05-25 13:26:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 13:26:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 13:26:59 --> Controller Class Initialized
INFO - 2025-05-25 13:26:59 --> Model "User_model" initialized
INFO - 2025-05-25 13:26:59 --> Model "Progress_model" initialized
INFO - 2025-05-25 13:26:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 13:26:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
ERROR - 2025-05-25 13:26:59 --> Severity: Warning --> Undefined variable $labels C:\laragon\www\Project\fitnessrecord\application\views\dashboard\dashboard.php 96
ERROR - 2025-05-25 13:26:59 --> Severity: Warning --> Undefined variable $latihan C:\laragon\www\Project\fitnessrecord\application\views\dashboard\dashboard.php 97
ERROR - 2025-05-25 13:26:59 --> Severity: Warning --> Undefined variable $kalori C:\laragon\www\Project\fitnessrecord\application\views\dashboard\dashboard.php 98
INFO - 2025-05-25 13:26:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-25 13:26:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 13:26:59 --> Final output sent to browser
DEBUG - 2025-05-25 13:26:59 --> Total execution time: 0.0785
INFO - 2025-05-25 13:28:25 --> Config Class Initialized
INFO - 2025-05-25 13:28:25 --> Hooks Class Initialized
DEBUG - 2025-05-25 13:28:25 --> UTF-8 Support Enabled
INFO - 2025-05-25 13:28:25 --> Utf8 Class Initialized
INFO - 2025-05-25 13:28:25 --> URI Class Initialized
INFO - 2025-05-25 13:28:25 --> Router Class Initialized
INFO - 2025-05-25 13:28:25 --> Output Class Initialized
INFO - 2025-05-25 13:28:25 --> Security Class Initialized
DEBUG - 2025-05-25 13:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 13:28:25 --> Input Class Initialized
INFO - 2025-05-25 13:28:25 --> Language Class Initialized
INFO - 2025-05-25 13:28:25 --> Loader Class Initialized
INFO - 2025-05-25 13:28:25 --> Helper loaded: url_helper
INFO - 2025-05-25 13:28:25 --> Helper loaded: form_helper
INFO - 2025-05-25 13:28:25 --> Database Driver Class Initialized
DEBUG - 2025-05-25 13:28:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 13:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 13:28:25 --> Controller Class Initialized
INFO - 2025-05-25 13:28:25 --> Model "User_model" initialized
INFO - 2025-05-25 13:28:25 --> Model "Progress_model" initialized
INFO - 2025-05-25 13:28:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 13:28:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
ERROR - 2025-05-25 13:28:25 --> Severity: Warning --> Undefined variable $labels C:\laragon\www\Project\fitnessrecord\application\views\dashboard\dashboard.php 96
ERROR - 2025-05-25 13:28:25 --> Severity: Warning --> Undefined variable $latihan C:\laragon\www\Project\fitnessrecord\application\views\dashboard\dashboard.php 97
ERROR - 2025-05-25 13:28:25 --> Severity: Warning --> Undefined variable $kalori C:\laragon\www\Project\fitnessrecord\application\views\dashboard\dashboard.php 98
INFO - 2025-05-25 13:28:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-25 13:28:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 13:28:25 --> Final output sent to browser
DEBUG - 2025-05-25 13:28:25 --> Total execution time: 0.0724
INFO - 2025-05-25 13:28:33 --> Config Class Initialized
INFO - 2025-05-25 13:28:33 --> Hooks Class Initialized
DEBUG - 2025-05-25 13:28:33 --> UTF-8 Support Enabled
INFO - 2025-05-25 13:28:33 --> Utf8 Class Initialized
INFO - 2025-05-25 13:28:33 --> URI Class Initialized
INFO - 2025-05-25 13:28:33 --> Router Class Initialized
INFO - 2025-05-25 13:28:33 --> Output Class Initialized
INFO - 2025-05-25 13:28:33 --> Security Class Initialized
DEBUG - 2025-05-25 13:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 13:28:33 --> Input Class Initialized
INFO - 2025-05-25 13:28:33 --> Language Class Initialized
INFO - 2025-05-25 13:28:33 --> Loader Class Initialized
INFO - 2025-05-25 13:28:33 --> Helper loaded: url_helper
INFO - 2025-05-25 13:28:33 --> Helper loaded: form_helper
INFO - 2025-05-25 13:28:33 --> Database Driver Class Initialized
DEBUG - 2025-05-25 13:28:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 13:28:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 13:28:33 --> Controller Class Initialized
INFO - 2025-05-25 13:28:33 --> Model "Progress_model" initialized
INFO - 2025-05-25 13:28:33 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 13:28:33 --> Model "User_model" initialized
INFO - 2025-05-25 13:28:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 13:28:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 13:28:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-25 13:28:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 13:28:33 --> Final output sent to browser
DEBUG - 2025-05-25 13:28:33 --> Total execution time: 0.0734
INFO - 2025-05-25 13:28:34 --> Config Class Initialized
INFO - 2025-05-25 13:28:34 --> Hooks Class Initialized
DEBUG - 2025-05-25 13:28:34 --> UTF-8 Support Enabled
INFO - 2025-05-25 13:28:34 --> Utf8 Class Initialized
INFO - 2025-05-25 13:28:34 --> URI Class Initialized
INFO - 2025-05-25 13:28:34 --> Router Class Initialized
INFO - 2025-05-25 13:28:34 --> Output Class Initialized
INFO - 2025-05-25 13:28:34 --> Security Class Initialized
DEBUG - 2025-05-25 13:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 13:28:34 --> Input Class Initialized
INFO - 2025-05-25 13:28:34 --> Language Class Initialized
INFO - 2025-05-25 13:28:34 --> Loader Class Initialized
INFO - 2025-05-25 13:28:34 --> Helper loaded: url_helper
INFO - 2025-05-25 13:28:34 --> Helper loaded: form_helper
INFO - 2025-05-25 13:28:34 --> Database Driver Class Initialized
DEBUG - 2025-05-25 13:28:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 13:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 13:28:34 --> Controller Class Initialized
INFO - 2025-05-25 13:28:34 --> Model "Progress_model" initialized
INFO - 2025-05-25 13:28:34 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 13:28:34 --> Model "User_model" initialized
INFO - 2025-05-25 13:28:34 --> Final output sent to browser
DEBUG - 2025-05-25 13:28:34 --> Total execution time: 0.0709
INFO - 2025-05-25 13:28:36 --> Config Class Initialized
INFO - 2025-05-25 13:28:36 --> Hooks Class Initialized
DEBUG - 2025-05-25 13:28:36 --> UTF-8 Support Enabled
INFO - 2025-05-25 13:28:36 --> Utf8 Class Initialized
INFO - 2025-05-25 13:28:36 --> URI Class Initialized
INFO - 2025-05-25 13:28:36 --> Router Class Initialized
INFO - 2025-05-25 13:28:36 --> Output Class Initialized
INFO - 2025-05-25 13:28:36 --> Security Class Initialized
DEBUG - 2025-05-25 13:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 13:28:36 --> Input Class Initialized
INFO - 2025-05-25 13:28:36 --> Language Class Initialized
INFO - 2025-05-25 13:28:36 --> Loader Class Initialized
INFO - 2025-05-25 13:28:36 --> Helper loaded: url_helper
INFO - 2025-05-25 13:28:36 --> Helper loaded: form_helper
INFO - 2025-05-25 13:28:36 --> Database Driver Class Initialized
DEBUG - 2025-05-25 13:28:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 13:28:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 13:28:36 --> Controller Class Initialized
INFO - 2025-05-25 13:28:36 --> Model "Progress_model" initialized
INFO - 2025-05-25 13:28:36 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 13:28:36 --> Model "User_model" initialized
INFO - 2025-05-25 13:28:36 --> Final output sent to browser
DEBUG - 2025-05-25 13:28:36 --> Total execution time: 0.0530
INFO - 2025-05-25 13:28:42 --> Config Class Initialized
INFO - 2025-05-25 13:28:42 --> Hooks Class Initialized
DEBUG - 2025-05-25 13:28:42 --> UTF-8 Support Enabled
INFO - 2025-05-25 13:28:42 --> Utf8 Class Initialized
INFO - 2025-05-25 13:28:42 --> URI Class Initialized
INFO - 2025-05-25 13:28:42 --> Router Class Initialized
INFO - 2025-05-25 13:28:42 --> Output Class Initialized
INFO - 2025-05-25 13:28:42 --> Security Class Initialized
DEBUG - 2025-05-25 13:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 13:28:42 --> Input Class Initialized
INFO - 2025-05-25 13:28:42 --> Language Class Initialized
INFO - 2025-05-25 13:28:42 --> Loader Class Initialized
INFO - 2025-05-25 13:28:42 --> Helper loaded: url_helper
INFO - 2025-05-25 13:28:42 --> Helper loaded: form_helper
INFO - 2025-05-25 13:28:42 --> Database Driver Class Initialized
DEBUG - 2025-05-25 13:28:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 13:28:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 13:28:42 --> Controller Class Initialized
INFO - 2025-05-25 13:28:42 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 13:28:42 --> Model "User_model" initialized
INFO - 2025-05-25 13:28:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 13:28:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 13:28:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-05-25 13:28:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 13:28:42 --> Final output sent to browser
DEBUG - 2025-05-25 13:28:42 --> Total execution time: 0.0678
INFO - 2025-05-25 13:28:46 --> Config Class Initialized
INFO - 2025-05-25 13:28:46 --> Hooks Class Initialized
DEBUG - 2025-05-25 13:28:46 --> UTF-8 Support Enabled
INFO - 2025-05-25 13:28:46 --> Utf8 Class Initialized
INFO - 2025-05-25 13:28:46 --> URI Class Initialized
INFO - 2025-05-25 13:28:46 --> Router Class Initialized
INFO - 2025-05-25 13:28:46 --> Output Class Initialized
INFO - 2025-05-25 13:28:46 --> Security Class Initialized
DEBUG - 2025-05-25 13:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 13:28:46 --> Input Class Initialized
INFO - 2025-05-25 13:28:46 --> Language Class Initialized
INFO - 2025-05-25 13:28:46 --> Loader Class Initialized
INFO - 2025-05-25 13:28:46 --> Helper loaded: url_helper
INFO - 2025-05-25 13:28:46 --> Helper loaded: form_helper
INFO - 2025-05-25 13:28:46 --> Database Driver Class Initialized
DEBUG - 2025-05-25 13:28:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 13:28:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 13:28:46 --> Controller Class Initialized
INFO - 2025-05-25 13:28:46 --> Model "Progress_model" initialized
INFO - 2025-05-25 13:28:46 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 13:28:46 --> Model "User_model" initialized
INFO - 2025-05-25 13:28:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 13:28:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 13:28:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-25 13:28:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 13:28:46 --> Final output sent to browser
DEBUG - 2025-05-25 13:28:46 --> Total execution time: 0.0746
INFO - 2025-05-25 13:28:47 --> Config Class Initialized
INFO - 2025-05-25 13:28:47 --> Hooks Class Initialized
DEBUG - 2025-05-25 13:28:47 --> UTF-8 Support Enabled
INFO - 2025-05-25 13:28:47 --> Utf8 Class Initialized
INFO - 2025-05-25 13:28:47 --> URI Class Initialized
INFO - 2025-05-25 13:28:47 --> Router Class Initialized
INFO - 2025-05-25 13:28:47 --> Output Class Initialized
INFO - 2025-05-25 13:28:47 --> Security Class Initialized
DEBUG - 2025-05-25 13:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 13:28:47 --> Input Class Initialized
INFO - 2025-05-25 13:28:47 --> Language Class Initialized
INFO - 2025-05-25 13:28:47 --> Loader Class Initialized
INFO - 2025-05-25 13:28:47 --> Helper loaded: url_helper
INFO - 2025-05-25 13:28:47 --> Helper loaded: form_helper
INFO - 2025-05-25 13:28:47 --> Database Driver Class Initialized
DEBUG - 2025-05-25 13:28:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 13:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 13:28:47 --> Controller Class Initialized
INFO - 2025-05-25 13:28:47 --> Model "Progress_model" initialized
INFO - 2025-05-25 13:28:47 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 13:28:47 --> Model "User_model" initialized
INFO - 2025-05-25 13:28:47 --> Final output sent to browser
DEBUG - 2025-05-25 13:28:47 --> Total execution time: 0.0849
INFO - 2025-05-25 13:28:48 --> Config Class Initialized
INFO - 2025-05-25 13:28:48 --> Hooks Class Initialized
DEBUG - 2025-05-25 13:28:48 --> UTF-8 Support Enabled
INFO - 2025-05-25 13:28:48 --> Utf8 Class Initialized
INFO - 2025-05-25 13:28:48 --> URI Class Initialized
INFO - 2025-05-25 13:28:48 --> Router Class Initialized
INFO - 2025-05-25 13:28:48 --> Output Class Initialized
INFO - 2025-05-25 13:28:48 --> Security Class Initialized
DEBUG - 2025-05-25 13:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 13:28:48 --> Input Class Initialized
INFO - 2025-05-25 13:28:48 --> Language Class Initialized
INFO - 2025-05-25 13:28:48 --> Loader Class Initialized
INFO - 2025-05-25 13:28:48 --> Helper loaded: url_helper
INFO - 2025-05-25 13:28:48 --> Helper loaded: form_helper
INFO - 2025-05-25 13:28:48 --> Database Driver Class Initialized
DEBUG - 2025-05-25 13:28:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 13:28:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 13:28:48 --> Controller Class Initialized
INFO - 2025-05-25 13:28:48 --> Model "User_model" initialized
INFO - 2025-05-25 13:28:48 --> Model "Progress_model" initialized
INFO - 2025-05-25 13:28:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 13:28:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 13:28:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-25 13:28:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 13:28:48 --> Final output sent to browser
DEBUG - 2025-05-25 13:28:48 --> Total execution time: 0.0806
INFO - 2025-05-25 13:28:52 --> Config Class Initialized
INFO - 2025-05-25 13:28:52 --> Hooks Class Initialized
DEBUG - 2025-05-25 13:28:52 --> UTF-8 Support Enabled
INFO - 2025-05-25 13:28:52 --> Utf8 Class Initialized
INFO - 2025-05-25 13:28:52 --> URI Class Initialized
INFO - 2025-05-25 13:28:52 --> Router Class Initialized
INFO - 2025-05-25 13:28:52 --> Output Class Initialized
INFO - 2025-05-25 13:28:52 --> Security Class Initialized
DEBUG - 2025-05-25 13:28:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 13:28:52 --> Input Class Initialized
INFO - 2025-05-25 13:28:52 --> Language Class Initialized
INFO - 2025-05-25 13:28:52 --> Loader Class Initialized
INFO - 2025-05-25 13:28:52 --> Helper loaded: url_helper
INFO - 2025-05-25 13:28:52 --> Helper loaded: form_helper
INFO - 2025-05-25 13:28:52 --> Database Driver Class Initialized
DEBUG - 2025-05-25 13:28:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 13:28:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 13:28:52 --> Controller Class Initialized
INFO - 2025-05-25 13:28:52 --> Model "Progress_model" initialized
INFO - 2025-05-25 13:28:52 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 13:28:52 --> Model "User_model" initialized
INFO - 2025-05-25 13:28:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 13:28:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 13:28:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-25 13:28:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 13:28:52 --> Final output sent to browser
DEBUG - 2025-05-25 13:28:52 --> Total execution time: 0.0604
INFO - 2025-05-25 13:28:52 --> Config Class Initialized
INFO - 2025-05-25 13:28:52 --> Hooks Class Initialized
DEBUG - 2025-05-25 13:28:52 --> UTF-8 Support Enabled
INFO - 2025-05-25 13:28:52 --> Utf8 Class Initialized
INFO - 2025-05-25 13:28:52 --> URI Class Initialized
INFO - 2025-05-25 13:28:52 --> Router Class Initialized
INFO - 2025-05-25 13:28:52 --> Output Class Initialized
INFO - 2025-05-25 13:28:52 --> Security Class Initialized
DEBUG - 2025-05-25 13:28:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 13:28:52 --> Input Class Initialized
INFO - 2025-05-25 13:28:52 --> Language Class Initialized
INFO - 2025-05-25 13:28:52 --> Loader Class Initialized
INFO - 2025-05-25 13:28:52 --> Helper loaded: url_helper
INFO - 2025-05-25 13:28:52 --> Helper loaded: form_helper
INFO - 2025-05-25 13:28:52 --> Database Driver Class Initialized
DEBUG - 2025-05-25 13:28:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 13:28:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 13:28:52 --> Controller Class Initialized
INFO - 2025-05-25 13:28:52 --> Model "Progress_model" initialized
INFO - 2025-05-25 13:28:52 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 13:28:52 --> Model "User_model" initialized
INFO - 2025-05-25 13:28:52 --> Final output sent to browser
DEBUG - 2025-05-25 13:28:52 --> Total execution time: 0.0661
INFO - 2025-05-25 13:29:34 --> Config Class Initialized
INFO - 2025-05-25 13:29:34 --> Hooks Class Initialized
DEBUG - 2025-05-25 13:29:34 --> UTF-8 Support Enabled
INFO - 2025-05-25 13:29:34 --> Utf8 Class Initialized
INFO - 2025-05-25 13:29:34 --> URI Class Initialized
INFO - 2025-05-25 13:29:34 --> Router Class Initialized
INFO - 2025-05-25 13:29:34 --> Output Class Initialized
INFO - 2025-05-25 13:29:34 --> Security Class Initialized
DEBUG - 2025-05-25 13:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 13:29:34 --> Input Class Initialized
INFO - 2025-05-25 13:29:34 --> Language Class Initialized
INFO - 2025-05-25 13:29:34 --> Loader Class Initialized
INFO - 2025-05-25 13:29:34 --> Helper loaded: url_helper
INFO - 2025-05-25 13:29:34 --> Helper loaded: form_helper
INFO - 2025-05-25 13:29:34 --> Database Driver Class Initialized
DEBUG - 2025-05-25 13:29:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 13:29:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 13:29:35 --> Controller Class Initialized
INFO - 2025-05-25 13:29:35 --> Model "Progress_model" initialized
INFO - 2025-05-25 13:29:35 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 13:29:35 --> Model "User_model" initialized
INFO - 2025-05-25 13:29:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 13:29:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 13:29:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-25 13:29:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 13:29:35 --> Final output sent to browser
DEBUG - 2025-05-25 13:29:35 --> Total execution time: 0.1102
INFO - 2025-05-25 13:29:37 --> Config Class Initialized
INFO - 2025-05-25 13:29:37 --> Hooks Class Initialized
DEBUG - 2025-05-25 13:29:37 --> UTF-8 Support Enabled
INFO - 2025-05-25 13:29:37 --> Utf8 Class Initialized
INFO - 2025-05-25 13:29:37 --> URI Class Initialized
INFO - 2025-05-25 13:29:37 --> Router Class Initialized
INFO - 2025-05-25 13:29:37 --> Output Class Initialized
INFO - 2025-05-25 13:29:37 --> Security Class Initialized
DEBUG - 2025-05-25 13:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 13:29:37 --> Input Class Initialized
INFO - 2025-05-25 13:29:37 --> Language Class Initialized
INFO - 2025-05-25 13:29:37 --> Loader Class Initialized
INFO - 2025-05-25 13:29:37 --> Helper loaded: url_helper
INFO - 2025-05-25 13:29:37 --> Helper loaded: form_helper
INFO - 2025-05-25 13:29:37 --> Database Driver Class Initialized
DEBUG - 2025-05-25 13:29:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 13:29:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 13:29:37 --> Controller Class Initialized
INFO - 2025-05-25 13:29:37 --> Model "Progress_model" initialized
INFO - 2025-05-25 13:29:37 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 13:29:37 --> Model "User_model" initialized
INFO - 2025-05-25 13:29:37 --> Final output sent to browser
DEBUG - 2025-05-25 13:29:37 --> Total execution time: 0.0793
INFO - 2025-05-25 13:29:58 --> Config Class Initialized
INFO - 2025-05-25 13:29:58 --> Hooks Class Initialized
DEBUG - 2025-05-25 13:29:58 --> UTF-8 Support Enabled
INFO - 2025-05-25 13:29:58 --> Utf8 Class Initialized
INFO - 2025-05-25 13:29:58 --> URI Class Initialized
INFO - 2025-05-25 13:29:58 --> Router Class Initialized
INFO - 2025-05-25 13:29:58 --> Output Class Initialized
INFO - 2025-05-25 13:29:58 --> Security Class Initialized
DEBUG - 2025-05-25 13:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 13:29:58 --> Input Class Initialized
INFO - 2025-05-25 13:29:58 --> Language Class Initialized
INFO - 2025-05-25 13:29:58 --> Loader Class Initialized
INFO - 2025-05-25 13:29:58 --> Helper loaded: url_helper
INFO - 2025-05-25 13:29:58 --> Helper loaded: form_helper
INFO - 2025-05-25 13:29:58 --> Database Driver Class Initialized
DEBUG - 2025-05-25 13:29:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 13:29:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 13:29:58 --> Controller Class Initialized
INFO - 2025-05-25 13:29:58 --> Model "Progress_model" initialized
INFO - 2025-05-25 13:29:58 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 13:29:58 --> Model "User_model" initialized
INFO - 2025-05-25 13:29:58 --> Final output sent to browser
DEBUG - 2025-05-25 13:29:58 --> Total execution time: 0.0826
INFO - 2025-05-25 13:30:42 --> Config Class Initialized
INFO - 2025-05-25 13:30:42 --> Hooks Class Initialized
DEBUG - 2025-05-25 13:30:42 --> UTF-8 Support Enabled
INFO - 2025-05-25 13:30:42 --> Utf8 Class Initialized
INFO - 2025-05-25 13:30:42 --> URI Class Initialized
INFO - 2025-05-25 13:30:42 --> Router Class Initialized
INFO - 2025-05-25 13:30:42 --> Output Class Initialized
INFO - 2025-05-25 13:30:42 --> Security Class Initialized
DEBUG - 2025-05-25 13:30:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 13:30:42 --> Input Class Initialized
INFO - 2025-05-25 13:30:42 --> Language Class Initialized
INFO - 2025-05-25 13:30:42 --> Loader Class Initialized
INFO - 2025-05-25 13:30:42 --> Helper loaded: url_helper
INFO - 2025-05-25 13:30:42 --> Helper loaded: form_helper
INFO - 2025-05-25 13:30:42 --> Database Driver Class Initialized
DEBUG - 2025-05-25 13:30:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 13:30:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 13:30:42 --> Controller Class Initialized
INFO - 2025-05-25 13:30:42 --> Model "Progress_model" initialized
INFO - 2025-05-25 13:30:42 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 13:30:42 --> Model "User_model" initialized
INFO - 2025-05-25 13:30:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 13:30:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 13:30:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-25 13:30:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 13:30:42 --> Final output sent to browser
DEBUG - 2025-05-25 13:30:42 --> Total execution time: 0.0716
INFO - 2025-05-25 13:30:43 --> Config Class Initialized
INFO - 2025-05-25 13:30:43 --> Hooks Class Initialized
DEBUG - 2025-05-25 13:30:43 --> UTF-8 Support Enabled
INFO - 2025-05-25 13:30:43 --> Utf8 Class Initialized
INFO - 2025-05-25 13:30:43 --> URI Class Initialized
INFO - 2025-05-25 13:30:43 --> Router Class Initialized
INFO - 2025-05-25 13:30:43 --> Output Class Initialized
INFO - 2025-05-25 13:30:43 --> Security Class Initialized
DEBUG - 2025-05-25 13:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 13:30:43 --> Input Class Initialized
INFO - 2025-05-25 13:30:43 --> Language Class Initialized
INFO - 2025-05-25 13:30:43 --> Loader Class Initialized
INFO - 2025-05-25 13:30:43 --> Helper loaded: url_helper
INFO - 2025-05-25 13:30:43 --> Helper loaded: form_helper
INFO - 2025-05-25 13:30:43 --> Database Driver Class Initialized
DEBUG - 2025-05-25 13:30:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 13:30:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 13:30:43 --> Controller Class Initialized
INFO - 2025-05-25 13:30:43 --> Model "Progress_model" initialized
INFO - 2025-05-25 13:30:43 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 13:30:43 --> Model "User_model" initialized
INFO - 2025-05-25 13:30:43 --> Final output sent to browser
DEBUG - 2025-05-25 13:30:43 --> Total execution time: 0.0808
INFO - 2025-05-25 13:30:45 --> Config Class Initialized
INFO - 2025-05-25 13:30:45 --> Hooks Class Initialized
DEBUG - 2025-05-25 13:30:45 --> UTF-8 Support Enabled
INFO - 2025-05-25 13:30:45 --> Utf8 Class Initialized
INFO - 2025-05-25 13:30:45 --> URI Class Initialized
INFO - 2025-05-25 13:30:45 --> Router Class Initialized
INFO - 2025-05-25 13:30:45 --> Output Class Initialized
INFO - 2025-05-25 13:30:45 --> Security Class Initialized
DEBUG - 2025-05-25 13:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 13:30:45 --> Input Class Initialized
INFO - 2025-05-25 13:30:45 --> Language Class Initialized
INFO - 2025-05-25 13:30:45 --> Loader Class Initialized
INFO - 2025-05-25 13:30:45 --> Helper loaded: url_helper
INFO - 2025-05-25 13:30:45 --> Helper loaded: form_helper
INFO - 2025-05-25 13:30:45 --> Database Driver Class Initialized
DEBUG - 2025-05-25 13:30:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 13:30:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 13:30:45 --> Controller Class Initialized
INFO - 2025-05-25 13:30:45 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 13:30:45 --> Model "User_model" initialized
INFO - 2025-05-25 13:30:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 13:30:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 13:30:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-05-25 13:30:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 13:30:45 --> Final output sent to browser
DEBUG - 2025-05-25 13:30:45 --> Total execution time: 0.0919
INFO - 2025-05-25 13:30:50 --> Config Class Initialized
INFO - 2025-05-25 13:30:50 --> Hooks Class Initialized
DEBUG - 2025-05-25 13:30:50 --> UTF-8 Support Enabled
INFO - 2025-05-25 13:30:50 --> Utf8 Class Initialized
INFO - 2025-05-25 13:30:50 --> URI Class Initialized
INFO - 2025-05-25 13:30:50 --> Router Class Initialized
INFO - 2025-05-25 13:30:50 --> Output Class Initialized
INFO - 2025-05-25 13:30:50 --> Security Class Initialized
DEBUG - 2025-05-25 13:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 13:30:50 --> Input Class Initialized
INFO - 2025-05-25 13:30:50 --> Language Class Initialized
INFO - 2025-05-25 13:30:50 --> Loader Class Initialized
INFO - 2025-05-25 13:30:50 --> Helper loaded: url_helper
INFO - 2025-05-25 13:30:50 --> Helper loaded: form_helper
INFO - 2025-05-25 13:30:50 --> Database Driver Class Initialized
DEBUG - 2025-05-25 13:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 13:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 13:30:51 --> Controller Class Initialized
INFO - 2025-05-25 13:30:51 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 13:30:51 --> Model "User_model" initialized
INFO - 2025-05-25 13:30:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 13:30:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 13:30:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-05-25 13:30:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 13:30:51 --> Final output sent to browser
DEBUG - 2025-05-25 13:30:51 --> Total execution time: 0.0824
INFO - 2025-05-25 13:31:00 --> Config Class Initialized
INFO - 2025-05-25 13:31:00 --> Hooks Class Initialized
DEBUG - 2025-05-25 13:31:00 --> UTF-8 Support Enabled
INFO - 2025-05-25 13:31:00 --> Utf8 Class Initialized
INFO - 2025-05-25 13:31:00 --> URI Class Initialized
INFO - 2025-05-25 13:31:00 --> Router Class Initialized
INFO - 2025-05-25 13:31:00 --> Output Class Initialized
INFO - 2025-05-25 13:31:00 --> Security Class Initialized
DEBUG - 2025-05-25 13:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 13:31:00 --> Input Class Initialized
INFO - 2025-05-25 13:31:00 --> Language Class Initialized
INFO - 2025-05-25 13:31:00 --> Loader Class Initialized
INFO - 2025-05-25 13:31:00 --> Helper loaded: url_helper
INFO - 2025-05-25 13:31:00 --> Helper loaded: form_helper
INFO - 2025-05-25 13:31:00 --> Database Driver Class Initialized
DEBUG - 2025-05-25 13:31:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 13:31:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 13:31:00 --> Controller Class Initialized
INFO - 2025-05-25 13:31:00 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 13:31:00 --> Model "User_model" initialized
INFO - 2025-05-25 13:31:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 13:31:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 13:31:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-05-25 13:31:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 13:31:00 --> Final output sent to browser
DEBUG - 2025-05-25 13:31:00 --> Total execution time: 0.0745
INFO - 2025-05-25 13:31:04 --> Config Class Initialized
INFO - 2025-05-25 13:31:04 --> Hooks Class Initialized
DEBUG - 2025-05-25 13:31:04 --> UTF-8 Support Enabled
INFO - 2025-05-25 13:31:04 --> Utf8 Class Initialized
INFO - 2025-05-25 13:31:04 --> URI Class Initialized
INFO - 2025-05-25 13:31:04 --> Router Class Initialized
INFO - 2025-05-25 13:31:04 --> Output Class Initialized
INFO - 2025-05-25 13:31:04 --> Security Class Initialized
DEBUG - 2025-05-25 13:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 13:31:04 --> Input Class Initialized
INFO - 2025-05-25 13:31:04 --> Language Class Initialized
INFO - 2025-05-25 13:31:04 --> Loader Class Initialized
INFO - 2025-05-25 13:31:04 --> Helper loaded: url_helper
INFO - 2025-05-25 13:31:04 --> Helper loaded: form_helper
INFO - 2025-05-25 13:31:04 --> Database Driver Class Initialized
DEBUG - 2025-05-25 13:31:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 13:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 13:31:04 --> Controller Class Initialized
INFO - 2025-05-25 13:31:04 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 13:31:04 --> Model "User_model" initialized
INFO - 2025-05-25 13:31:04 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 13:31:04 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 13:31:04 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/menu.php
INFO - 2025-05-25 13:31:04 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 13:31:04 --> Final output sent to browser
DEBUG - 2025-05-25 13:31:04 --> Total execution time: 0.0622
INFO - 2025-05-25 13:31:09 --> Config Class Initialized
INFO - 2025-05-25 13:31:09 --> Hooks Class Initialized
DEBUG - 2025-05-25 13:31:09 --> UTF-8 Support Enabled
INFO - 2025-05-25 13:31:09 --> Utf8 Class Initialized
INFO - 2025-05-25 13:31:09 --> URI Class Initialized
INFO - 2025-05-25 13:31:09 --> Router Class Initialized
INFO - 2025-05-25 13:31:09 --> Output Class Initialized
INFO - 2025-05-25 13:31:09 --> Security Class Initialized
DEBUG - 2025-05-25 13:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 13:31:09 --> Input Class Initialized
INFO - 2025-05-25 13:31:09 --> Language Class Initialized
INFO - 2025-05-25 13:31:09 --> Loader Class Initialized
INFO - 2025-05-25 13:31:09 --> Helper loaded: url_helper
INFO - 2025-05-25 13:31:09 --> Helper loaded: form_helper
INFO - 2025-05-25 13:31:09 --> Database Driver Class Initialized
DEBUG - 2025-05-25 13:31:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 13:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 13:31:09 --> Controller Class Initialized
INFO - 2025-05-25 13:31:09 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 13:31:09 --> Model "User_model" initialized
INFO - 2025-05-25 13:31:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 13:31:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 13:31:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/start.php
INFO - 2025-05-25 13:31:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 13:31:09 --> Final output sent to browser
DEBUG - 2025-05-25 13:31:09 --> Total execution time: 0.0597
INFO - 2025-05-25 13:31:25 --> Config Class Initialized
INFO - 2025-05-25 13:31:25 --> Hooks Class Initialized
DEBUG - 2025-05-25 13:31:25 --> UTF-8 Support Enabled
INFO - 2025-05-25 13:31:25 --> Utf8 Class Initialized
INFO - 2025-05-25 13:31:25 --> URI Class Initialized
INFO - 2025-05-25 13:31:25 --> Router Class Initialized
INFO - 2025-05-25 13:31:25 --> Output Class Initialized
INFO - 2025-05-25 13:31:25 --> Security Class Initialized
DEBUG - 2025-05-25 13:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 13:31:25 --> Input Class Initialized
INFO - 2025-05-25 13:31:25 --> Language Class Initialized
INFO - 2025-05-25 13:31:25 --> Loader Class Initialized
INFO - 2025-05-25 13:31:25 --> Helper loaded: url_helper
INFO - 2025-05-25 13:31:25 --> Helper loaded: form_helper
INFO - 2025-05-25 13:31:25 --> Database Driver Class Initialized
DEBUG - 2025-05-25 13:31:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 13:31:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 13:31:25 --> Controller Class Initialized
INFO - 2025-05-25 13:31:25 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 13:31:25 --> Model "User_model" initialized
INFO - 2025-05-25 13:31:25 --> Final output sent to browser
DEBUG - 2025-05-25 13:31:25 --> Total execution time: 0.0624
INFO - 2025-05-25 13:31:31 --> Config Class Initialized
INFO - 2025-05-25 13:31:31 --> Hooks Class Initialized
DEBUG - 2025-05-25 13:31:31 --> UTF-8 Support Enabled
INFO - 2025-05-25 13:31:31 --> Utf8 Class Initialized
INFO - 2025-05-25 13:31:31 --> URI Class Initialized
INFO - 2025-05-25 13:31:31 --> Router Class Initialized
INFO - 2025-05-25 13:31:31 --> Output Class Initialized
INFO - 2025-05-25 13:31:31 --> Security Class Initialized
DEBUG - 2025-05-25 13:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 13:31:31 --> Input Class Initialized
INFO - 2025-05-25 13:31:31 --> Language Class Initialized
INFO - 2025-05-25 13:31:31 --> Loader Class Initialized
INFO - 2025-05-25 13:31:31 --> Helper loaded: url_helper
INFO - 2025-05-25 13:31:31 --> Helper loaded: form_helper
INFO - 2025-05-25 13:31:31 --> Database Driver Class Initialized
DEBUG - 2025-05-25 13:31:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 13:31:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 13:31:31 --> Controller Class Initialized
INFO - 2025-05-25 13:31:31 --> Model "Progress_model" initialized
INFO - 2025-05-25 13:31:31 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 13:31:31 --> Model "User_model" initialized
INFO - 2025-05-25 13:31:31 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 13:31:31 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 13:31:31 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-25 13:31:31 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 13:31:31 --> Final output sent to browser
DEBUG - 2025-05-25 13:31:31 --> Total execution time: 0.0760
INFO - 2025-05-25 13:31:31 --> Config Class Initialized
INFO - 2025-05-25 13:31:31 --> Hooks Class Initialized
DEBUG - 2025-05-25 13:31:31 --> UTF-8 Support Enabled
INFO - 2025-05-25 13:31:31 --> Utf8 Class Initialized
INFO - 2025-05-25 13:31:31 --> URI Class Initialized
INFO - 2025-05-25 13:31:31 --> Router Class Initialized
INFO - 2025-05-25 13:31:31 --> Output Class Initialized
INFO - 2025-05-25 13:31:31 --> Security Class Initialized
DEBUG - 2025-05-25 13:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 13:31:31 --> Input Class Initialized
INFO - 2025-05-25 13:31:31 --> Language Class Initialized
INFO - 2025-05-25 13:31:31 --> Loader Class Initialized
INFO - 2025-05-25 13:31:31 --> Helper loaded: url_helper
INFO - 2025-05-25 13:31:31 --> Helper loaded: form_helper
INFO - 2025-05-25 13:31:31 --> Database Driver Class Initialized
DEBUG - 2025-05-25 13:31:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 13:31:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 13:31:31 --> Controller Class Initialized
INFO - 2025-05-25 13:31:32 --> Model "Progress_model" initialized
INFO - 2025-05-25 13:31:32 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 13:31:32 --> Model "User_model" initialized
INFO - 2025-05-25 13:31:32 --> Final output sent to browser
DEBUG - 2025-05-25 13:31:32 --> Total execution time: 0.0793
INFO - 2025-05-25 13:31:50 --> Config Class Initialized
INFO - 2025-05-25 13:31:50 --> Hooks Class Initialized
DEBUG - 2025-05-25 13:31:50 --> UTF-8 Support Enabled
INFO - 2025-05-25 13:31:50 --> Utf8 Class Initialized
INFO - 2025-05-25 13:31:50 --> URI Class Initialized
INFO - 2025-05-25 13:31:50 --> Router Class Initialized
INFO - 2025-05-25 13:31:50 --> Output Class Initialized
INFO - 2025-05-25 13:31:50 --> Security Class Initialized
DEBUG - 2025-05-25 13:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 13:31:50 --> Input Class Initialized
INFO - 2025-05-25 13:31:50 --> Language Class Initialized
INFO - 2025-05-25 13:31:50 --> Loader Class Initialized
INFO - 2025-05-25 13:31:50 --> Helper loaded: url_helper
INFO - 2025-05-25 13:31:50 --> Helper loaded: form_helper
INFO - 2025-05-25 13:31:50 --> Database Driver Class Initialized
DEBUG - 2025-05-25 13:31:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 13:31:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 13:31:50 --> Controller Class Initialized
INFO - 2025-05-25 13:31:50 --> Model "Workout_model" initialized
INFO - 2025-05-25 13:31:50 --> Model "User_model" initialized
INFO - 2025-05-25 13:31:50 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 13:31:50 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 13:32:00 --> Config Class Initialized
INFO - 2025-05-25 13:32:00 --> Hooks Class Initialized
DEBUG - 2025-05-25 13:32:00 --> UTF-8 Support Enabled
INFO - 2025-05-25 13:32:00 --> Utf8 Class Initialized
INFO - 2025-05-25 13:32:00 --> URI Class Initialized
INFO - 2025-05-25 13:32:00 --> Router Class Initialized
INFO - 2025-05-25 13:32:00 --> Output Class Initialized
INFO - 2025-05-25 13:32:00 --> Security Class Initialized
DEBUG - 2025-05-25 13:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 13:32:00 --> Input Class Initialized
INFO - 2025-05-25 13:32:00 --> Language Class Initialized
INFO - 2025-05-25 13:32:00 --> Loader Class Initialized
INFO - 2025-05-25 13:32:00 --> Helper loaded: url_helper
INFO - 2025-05-25 13:32:00 --> Helper loaded: form_helper
INFO - 2025-05-25 13:32:00 --> Database Driver Class Initialized
DEBUG - 2025-05-25 13:32:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 13:32:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 13:32:00 --> Controller Class Initialized
INFO - 2025-05-25 13:32:00 --> Model "Workout_model" initialized
INFO - 2025-05-25 13:32:00 --> Model "User_model" initialized
INFO - 2025-05-25 13:32:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 13:32:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 13:32:02 --> Config Class Initialized
INFO - 2025-05-25 13:32:02 --> Hooks Class Initialized
DEBUG - 2025-05-25 13:32:02 --> UTF-8 Support Enabled
INFO - 2025-05-25 13:32:02 --> Utf8 Class Initialized
INFO - 2025-05-25 13:32:02 --> URI Class Initialized
INFO - 2025-05-25 13:32:02 --> Router Class Initialized
INFO - 2025-05-25 13:32:02 --> Output Class Initialized
INFO - 2025-05-25 13:32:02 --> Security Class Initialized
DEBUG - 2025-05-25 13:32:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 13:32:02 --> Input Class Initialized
INFO - 2025-05-25 13:32:02 --> Language Class Initialized
INFO - 2025-05-25 13:32:02 --> Loader Class Initialized
INFO - 2025-05-25 13:32:02 --> Helper loaded: url_helper
INFO - 2025-05-25 13:32:02 --> Helper loaded: form_helper
INFO - 2025-05-25 13:32:02 --> Database Driver Class Initialized
DEBUG - 2025-05-25 13:32:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 13:32:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 13:32:02 --> Controller Class Initialized
INFO - 2025-05-25 13:32:02 --> Model "Workout_model" initialized
INFO - 2025-05-25 13:32:02 --> Model "User_model" initialized
INFO - 2025-05-25 13:32:02 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 13:32:02 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 13:32:07 --> Config Class Initialized
INFO - 2025-05-25 13:32:07 --> Hooks Class Initialized
DEBUG - 2025-05-25 13:32:07 --> UTF-8 Support Enabled
INFO - 2025-05-25 13:32:07 --> Utf8 Class Initialized
INFO - 2025-05-25 13:32:07 --> URI Class Initialized
INFO - 2025-05-25 13:32:07 --> Router Class Initialized
INFO - 2025-05-25 13:32:07 --> Output Class Initialized
INFO - 2025-05-25 13:32:07 --> Security Class Initialized
DEBUG - 2025-05-25 13:32:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 13:32:07 --> Input Class Initialized
INFO - 2025-05-25 13:32:07 --> Language Class Initialized
INFO - 2025-05-25 13:32:07 --> Loader Class Initialized
INFO - 2025-05-25 13:32:07 --> Helper loaded: url_helper
INFO - 2025-05-25 13:32:07 --> Helper loaded: form_helper
INFO - 2025-05-25 13:32:07 --> Database Driver Class Initialized
DEBUG - 2025-05-25 13:32:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 13:32:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 13:32:07 --> Controller Class Initialized
INFO - 2025-05-25 13:32:07 --> Model "Workout_model" initialized
INFO - 2025-05-25 13:32:07 --> Model "User_model" initialized
INFO - 2025-05-25 13:32:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 13:32:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 13:32:14 --> Config Class Initialized
INFO - 2025-05-25 13:32:14 --> Hooks Class Initialized
DEBUG - 2025-05-25 13:32:14 --> UTF-8 Support Enabled
INFO - 2025-05-25 13:32:14 --> Utf8 Class Initialized
INFO - 2025-05-25 13:32:14 --> URI Class Initialized
INFO - 2025-05-25 13:32:14 --> Router Class Initialized
INFO - 2025-05-25 13:32:14 --> Output Class Initialized
INFO - 2025-05-25 13:32:14 --> Security Class Initialized
DEBUG - 2025-05-25 13:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 13:32:14 --> Input Class Initialized
INFO - 2025-05-25 13:32:14 --> Language Class Initialized
INFO - 2025-05-25 13:32:14 --> Loader Class Initialized
INFO - 2025-05-25 13:32:14 --> Helper loaded: url_helper
INFO - 2025-05-25 13:32:14 --> Helper loaded: form_helper
INFO - 2025-05-25 13:32:14 --> Database Driver Class Initialized
DEBUG - 2025-05-25 13:32:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 13:32:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 13:32:15 --> Controller Class Initialized
INFO - 2025-05-25 13:32:15 --> Model "User_model" initialized
INFO - 2025-05-25 13:32:15 --> Model "Progress_model" initialized
INFO - 2025-05-25 13:32:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 13:32:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
ERROR - 2025-05-25 13:32:15 --> Severity: Warning --> Undefined variable $labels C:\laragon\www\Project\fitnessrecord\application\views\dashboard\dashboard.php 96
ERROR - 2025-05-25 13:32:15 --> Severity: Warning --> Undefined variable $latihan C:\laragon\www\Project\fitnessrecord\application\views\dashboard\dashboard.php 97
ERROR - 2025-05-25 13:32:15 --> Severity: Warning --> Undefined variable $kalori C:\laragon\www\Project\fitnessrecord\application\views\dashboard\dashboard.php 98
INFO - 2025-05-25 13:32:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-25 13:32:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 13:32:15 --> Final output sent to browser
DEBUG - 2025-05-25 13:32:15 --> Total execution time: 0.0783
INFO - 2025-05-25 13:32:17 --> Config Class Initialized
INFO - 2025-05-25 13:32:17 --> Hooks Class Initialized
DEBUG - 2025-05-25 13:32:17 --> UTF-8 Support Enabled
INFO - 2025-05-25 13:32:17 --> Utf8 Class Initialized
INFO - 2025-05-25 13:32:17 --> URI Class Initialized
INFO - 2025-05-25 13:32:17 --> Router Class Initialized
INFO - 2025-05-25 13:32:17 --> Output Class Initialized
INFO - 2025-05-25 13:32:17 --> Security Class Initialized
DEBUG - 2025-05-25 13:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 13:32:17 --> Input Class Initialized
INFO - 2025-05-25 13:32:17 --> Language Class Initialized
INFO - 2025-05-25 13:32:17 --> Loader Class Initialized
INFO - 2025-05-25 13:32:17 --> Helper loaded: url_helper
INFO - 2025-05-25 13:32:17 --> Helper loaded: form_helper
INFO - 2025-05-25 13:32:17 --> Database Driver Class Initialized
DEBUG - 2025-05-25 13:32:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 13:32:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 13:32:17 --> Controller Class Initialized
INFO - 2025-05-25 13:32:17 --> Model "Progress_model" initialized
INFO - 2025-05-25 13:32:17 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 13:32:17 --> Model "User_model" initialized
INFO - 2025-05-25 13:32:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 13:32:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 13:32:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-25 13:32:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 13:32:17 --> Final output sent to browser
DEBUG - 2025-05-25 13:32:17 --> Total execution time: 0.0923
INFO - 2025-05-25 13:32:18 --> Config Class Initialized
INFO - 2025-05-25 13:32:18 --> Hooks Class Initialized
DEBUG - 2025-05-25 13:32:18 --> UTF-8 Support Enabled
INFO - 2025-05-25 13:32:18 --> Utf8 Class Initialized
INFO - 2025-05-25 13:32:18 --> URI Class Initialized
INFO - 2025-05-25 13:32:18 --> Router Class Initialized
INFO - 2025-05-25 13:32:18 --> Output Class Initialized
INFO - 2025-05-25 13:32:18 --> Security Class Initialized
DEBUG - 2025-05-25 13:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 13:32:18 --> Input Class Initialized
INFO - 2025-05-25 13:32:18 --> Language Class Initialized
INFO - 2025-05-25 13:32:18 --> Loader Class Initialized
INFO - 2025-05-25 13:32:18 --> Helper loaded: url_helper
INFO - 2025-05-25 13:32:18 --> Helper loaded: form_helper
INFO - 2025-05-25 13:32:18 --> Database Driver Class Initialized
DEBUG - 2025-05-25 13:32:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 13:32:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 13:32:18 --> Controller Class Initialized
INFO - 2025-05-25 13:32:18 --> Model "Progress_model" initialized
INFO - 2025-05-25 13:32:18 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 13:32:18 --> Model "User_model" initialized
INFO - 2025-05-25 13:32:18 --> Final output sent to browser
DEBUG - 2025-05-25 13:32:18 --> Total execution time: 0.0711
INFO - 2025-05-25 13:32:25 --> Config Class Initialized
INFO - 2025-05-25 13:32:25 --> Hooks Class Initialized
DEBUG - 2025-05-25 13:32:25 --> UTF-8 Support Enabled
INFO - 2025-05-25 13:32:25 --> Utf8 Class Initialized
INFO - 2025-05-25 13:32:25 --> URI Class Initialized
INFO - 2025-05-25 13:32:25 --> Router Class Initialized
INFO - 2025-05-25 13:32:25 --> Output Class Initialized
INFO - 2025-05-25 13:32:25 --> Security Class Initialized
DEBUG - 2025-05-25 13:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 13:32:25 --> Input Class Initialized
INFO - 2025-05-25 13:32:25 --> Language Class Initialized
INFO - 2025-05-25 13:32:25 --> Loader Class Initialized
INFO - 2025-05-25 13:32:25 --> Helper loaded: url_helper
INFO - 2025-05-25 13:32:25 --> Helper loaded: form_helper
INFO - 2025-05-25 13:32:25 --> Database Driver Class Initialized
DEBUG - 2025-05-25 13:32:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 13:32:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 13:32:25 --> Controller Class Initialized
INFO - 2025-05-25 13:32:25 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 13:32:25 --> Model "User_model" initialized
INFO - 2025-05-25 13:32:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 13:32:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 13:32:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-05-25 13:32:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 13:32:25 --> Final output sent to browser
DEBUG - 2025-05-25 13:32:25 --> Total execution time: 0.0610
INFO - 2025-05-25 13:32:29 --> Config Class Initialized
INFO - 2025-05-25 13:32:29 --> Hooks Class Initialized
DEBUG - 2025-05-25 13:32:29 --> UTF-8 Support Enabled
INFO - 2025-05-25 13:32:29 --> Utf8 Class Initialized
INFO - 2025-05-25 13:32:29 --> URI Class Initialized
INFO - 2025-05-25 13:32:29 --> Router Class Initialized
INFO - 2025-05-25 13:32:29 --> Output Class Initialized
INFO - 2025-05-25 13:32:29 --> Security Class Initialized
DEBUG - 2025-05-25 13:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 13:32:29 --> Input Class Initialized
INFO - 2025-05-25 13:32:29 --> Language Class Initialized
INFO - 2025-05-25 13:32:29 --> Loader Class Initialized
INFO - 2025-05-25 13:32:29 --> Helper loaded: url_helper
INFO - 2025-05-25 13:32:29 --> Helper loaded: form_helper
INFO - 2025-05-25 13:32:29 --> Database Driver Class Initialized
DEBUG - 2025-05-25 13:32:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 13:32:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 13:32:29 --> Controller Class Initialized
INFO - 2025-05-25 13:32:29 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 13:32:29 --> Model "User_model" initialized
INFO - 2025-05-25 13:32:29 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 13:32:29 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 13:32:29 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-05-25 13:32:29 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 13:32:29 --> Final output sent to browser
DEBUG - 2025-05-25 13:32:29 --> Total execution time: 0.0769
INFO - 2025-05-25 13:32:30 --> Config Class Initialized
INFO - 2025-05-25 13:32:30 --> Hooks Class Initialized
DEBUG - 2025-05-25 13:32:30 --> UTF-8 Support Enabled
INFO - 2025-05-25 13:32:30 --> Utf8 Class Initialized
INFO - 2025-05-25 13:32:30 --> URI Class Initialized
INFO - 2025-05-25 13:32:30 --> Router Class Initialized
INFO - 2025-05-25 13:32:30 --> Output Class Initialized
INFO - 2025-05-25 13:32:30 --> Security Class Initialized
DEBUG - 2025-05-25 13:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 13:32:30 --> Input Class Initialized
INFO - 2025-05-25 13:32:30 --> Language Class Initialized
INFO - 2025-05-25 13:32:30 --> Loader Class Initialized
INFO - 2025-05-25 13:32:30 --> Helper loaded: url_helper
INFO - 2025-05-25 13:32:30 --> Helper loaded: form_helper
INFO - 2025-05-25 13:32:30 --> Database Driver Class Initialized
DEBUG - 2025-05-25 13:32:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 13:32:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 13:32:30 --> Controller Class Initialized
INFO - 2025-05-25 13:32:30 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 13:32:30 --> Model "User_model" initialized
INFO - 2025-05-25 13:32:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 13:32:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 13:32:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/menu.php
INFO - 2025-05-25 13:32:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 13:32:30 --> Final output sent to browser
DEBUG - 2025-05-25 13:32:30 --> Total execution time: 0.0757
INFO - 2025-05-25 13:32:33 --> Config Class Initialized
INFO - 2025-05-25 13:32:33 --> Hooks Class Initialized
DEBUG - 2025-05-25 13:32:33 --> UTF-8 Support Enabled
INFO - 2025-05-25 13:32:33 --> Utf8 Class Initialized
INFO - 2025-05-25 13:32:33 --> URI Class Initialized
INFO - 2025-05-25 13:32:33 --> Router Class Initialized
INFO - 2025-05-25 13:32:33 --> Output Class Initialized
INFO - 2025-05-25 13:32:33 --> Security Class Initialized
DEBUG - 2025-05-25 13:32:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 13:32:33 --> Input Class Initialized
INFO - 2025-05-25 13:32:33 --> Language Class Initialized
INFO - 2025-05-25 13:32:33 --> Loader Class Initialized
INFO - 2025-05-25 13:32:33 --> Helper loaded: url_helper
INFO - 2025-05-25 13:32:33 --> Helper loaded: form_helper
INFO - 2025-05-25 13:32:33 --> Database Driver Class Initialized
DEBUG - 2025-05-25 13:32:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 13:32:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 13:32:33 --> Controller Class Initialized
INFO - 2025-05-25 13:32:33 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 13:32:33 --> Model "User_model" initialized
INFO - 2025-05-25 13:32:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 13:32:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 13:32:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/start.php
INFO - 2025-05-25 13:32:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 13:32:33 --> Final output sent to browser
DEBUG - 2025-05-25 13:32:33 --> Total execution time: 0.0727
INFO - 2025-05-25 13:33:08 --> Config Class Initialized
INFO - 2025-05-25 13:33:08 --> Hooks Class Initialized
DEBUG - 2025-05-25 13:33:08 --> UTF-8 Support Enabled
INFO - 2025-05-25 13:33:08 --> Utf8 Class Initialized
INFO - 2025-05-25 13:33:08 --> URI Class Initialized
INFO - 2025-05-25 13:33:08 --> Router Class Initialized
INFO - 2025-05-25 13:33:08 --> Output Class Initialized
INFO - 2025-05-25 13:33:08 --> Security Class Initialized
DEBUG - 2025-05-25 13:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 13:33:08 --> Input Class Initialized
INFO - 2025-05-25 13:33:08 --> Language Class Initialized
INFO - 2025-05-25 13:33:08 --> Loader Class Initialized
INFO - 2025-05-25 13:33:08 --> Helper loaded: url_helper
INFO - 2025-05-25 13:33:08 --> Helper loaded: form_helper
INFO - 2025-05-25 13:33:08 --> Database Driver Class Initialized
DEBUG - 2025-05-25 13:33:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 13:33:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 13:33:08 --> Controller Class Initialized
INFO - 2025-05-25 13:33:08 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 13:33:08 --> Model "User_model" initialized
INFO - 2025-05-25 13:33:08 --> Final output sent to browser
DEBUG - 2025-05-25 13:33:08 --> Total execution time: 0.0823
INFO - 2025-05-25 13:33:30 --> Config Class Initialized
INFO - 2025-05-25 13:33:30 --> Hooks Class Initialized
DEBUG - 2025-05-25 13:33:30 --> UTF-8 Support Enabled
INFO - 2025-05-25 13:33:30 --> Utf8 Class Initialized
INFO - 2025-05-25 13:33:30 --> URI Class Initialized
INFO - 2025-05-25 13:33:30 --> Router Class Initialized
INFO - 2025-05-25 13:33:30 --> Output Class Initialized
INFO - 2025-05-25 13:33:30 --> Security Class Initialized
DEBUG - 2025-05-25 13:33:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 13:33:30 --> Input Class Initialized
INFO - 2025-05-25 13:33:30 --> Language Class Initialized
INFO - 2025-05-25 13:33:30 --> Loader Class Initialized
INFO - 2025-05-25 13:33:30 --> Helper loaded: url_helper
INFO - 2025-05-25 13:33:30 --> Helper loaded: form_helper
INFO - 2025-05-25 13:33:30 --> Database Driver Class Initialized
DEBUG - 2025-05-25 13:33:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 13:33:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 13:33:30 --> Controller Class Initialized
INFO - 2025-05-25 13:33:30 --> Model "Progress_model" initialized
INFO - 2025-05-25 13:33:30 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 13:33:30 --> Model "User_model" initialized
INFO - 2025-05-25 13:33:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 13:33:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 13:33:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-25 13:33:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 13:33:30 --> Final output sent to browser
DEBUG - 2025-05-25 13:33:30 --> Total execution time: 0.0771
INFO - 2025-05-25 13:33:31 --> Config Class Initialized
INFO - 2025-05-25 13:33:31 --> Hooks Class Initialized
DEBUG - 2025-05-25 13:33:31 --> UTF-8 Support Enabled
INFO - 2025-05-25 13:33:31 --> Utf8 Class Initialized
INFO - 2025-05-25 13:33:31 --> URI Class Initialized
INFO - 2025-05-25 13:33:31 --> Router Class Initialized
INFO - 2025-05-25 13:33:31 --> Output Class Initialized
INFO - 2025-05-25 13:33:31 --> Security Class Initialized
DEBUG - 2025-05-25 13:33:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 13:33:31 --> Input Class Initialized
INFO - 2025-05-25 13:33:31 --> Language Class Initialized
INFO - 2025-05-25 13:33:31 --> Loader Class Initialized
INFO - 2025-05-25 13:33:31 --> Helper loaded: url_helper
INFO - 2025-05-25 13:33:31 --> Helper loaded: form_helper
INFO - 2025-05-25 13:33:31 --> Database Driver Class Initialized
DEBUG - 2025-05-25 13:33:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 13:33:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 13:33:31 --> Controller Class Initialized
INFO - 2025-05-25 13:33:31 --> Model "Progress_model" initialized
INFO - 2025-05-25 13:33:31 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 13:33:31 --> Model "User_model" initialized
INFO - 2025-05-25 13:33:31 --> Final output sent to browser
DEBUG - 2025-05-25 13:33:31 --> Total execution time: 0.0844
INFO - 2025-05-25 13:33:33 --> Config Class Initialized
INFO - 2025-05-25 13:33:33 --> Hooks Class Initialized
DEBUG - 2025-05-25 13:33:33 --> UTF-8 Support Enabled
INFO - 2025-05-25 13:33:33 --> Utf8 Class Initialized
INFO - 2025-05-25 13:33:33 --> URI Class Initialized
INFO - 2025-05-25 13:33:33 --> Router Class Initialized
INFO - 2025-05-25 13:33:33 --> Output Class Initialized
INFO - 2025-05-25 13:33:33 --> Security Class Initialized
DEBUG - 2025-05-25 13:33:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 13:33:33 --> Input Class Initialized
INFO - 2025-05-25 13:33:33 --> Language Class Initialized
INFO - 2025-05-25 13:33:33 --> Loader Class Initialized
INFO - 2025-05-25 13:33:33 --> Helper loaded: url_helper
INFO - 2025-05-25 13:33:33 --> Helper loaded: form_helper
INFO - 2025-05-25 13:33:33 --> Database Driver Class Initialized
DEBUG - 2025-05-25 13:33:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 13:33:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 13:33:33 --> Controller Class Initialized
INFO - 2025-05-25 13:33:33 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 13:33:33 --> Model "User_model" initialized
INFO - 2025-05-25 13:33:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 13:33:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 13:33:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-05-25 13:33:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 13:33:33 --> Final output sent to browser
DEBUG - 2025-05-25 13:33:33 --> Total execution time: 0.0732
INFO - 2025-05-25 13:33:36 --> Config Class Initialized
INFO - 2025-05-25 13:33:36 --> Hooks Class Initialized
DEBUG - 2025-05-25 13:33:36 --> UTF-8 Support Enabled
INFO - 2025-05-25 13:33:36 --> Utf8 Class Initialized
INFO - 2025-05-25 13:33:36 --> URI Class Initialized
INFO - 2025-05-25 13:33:36 --> Router Class Initialized
INFO - 2025-05-25 13:33:36 --> Output Class Initialized
INFO - 2025-05-25 13:33:36 --> Security Class Initialized
DEBUG - 2025-05-25 13:33:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 13:33:36 --> Input Class Initialized
INFO - 2025-05-25 13:33:36 --> Language Class Initialized
INFO - 2025-05-25 13:33:36 --> Loader Class Initialized
INFO - 2025-05-25 13:33:36 --> Helper loaded: url_helper
INFO - 2025-05-25 13:33:36 --> Helper loaded: form_helper
INFO - 2025-05-25 13:33:36 --> Database Driver Class Initialized
DEBUG - 2025-05-25 13:33:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 13:33:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 13:33:37 --> Controller Class Initialized
INFO - 2025-05-25 13:33:37 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 13:33:37 --> Model "User_model" initialized
INFO - 2025-05-25 13:33:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 13:33:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 13:33:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-05-25 13:33:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 13:33:37 --> Final output sent to browser
DEBUG - 2025-05-25 13:33:37 --> Total execution time: 0.0781
INFO - 2025-05-25 13:33:39 --> Config Class Initialized
INFO - 2025-05-25 13:33:39 --> Hooks Class Initialized
DEBUG - 2025-05-25 13:33:39 --> UTF-8 Support Enabled
INFO - 2025-05-25 13:33:39 --> Utf8 Class Initialized
INFO - 2025-05-25 13:33:39 --> URI Class Initialized
INFO - 2025-05-25 13:33:39 --> Router Class Initialized
INFO - 2025-05-25 13:33:39 --> Output Class Initialized
INFO - 2025-05-25 13:33:39 --> Security Class Initialized
DEBUG - 2025-05-25 13:33:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 13:33:39 --> Input Class Initialized
INFO - 2025-05-25 13:33:39 --> Language Class Initialized
INFO - 2025-05-25 13:33:39 --> Loader Class Initialized
INFO - 2025-05-25 13:33:39 --> Helper loaded: url_helper
INFO - 2025-05-25 13:33:39 --> Helper loaded: form_helper
INFO - 2025-05-25 13:33:39 --> Database Driver Class Initialized
DEBUG - 2025-05-25 13:33:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 13:33:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 13:33:39 --> Controller Class Initialized
INFO - 2025-05-25 13:33:39 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 13:33:39 --> Model "User_model" initialized
INFO - 2025-05-25 13:33:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 13:33:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 13:33:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/menu.php
INFO - 2025-05-25 13:33:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 13:33:39 --> Final output sent to browser
DEBUG - 2025-05-25 13:33:39 --> Total execution time: 0.0862
INFO - 2025-05-25 13:33:41 --> Config Class Initialized
INFO - 2025-05-25 13:33:41 --> Hooks Class Initialized
DEBUG - 2025-05-25 13:33:41 --> UTF-8 Support Enabled
INFO - 2025-05-25 13:33:41 --> Utf8 Class Initialized
INFO - 2025-05-25 13:33:41 --> URI Class Initialized
INFO - 2025-05-25 13:33:41 --> Router Class Initialized
INFO - 2025-05-25 13:33:41 --> Output Class Initialized
INFO - 2025-05-25 13:33:41 --> Security Class Initialized
DEBUG - 2025-05-25 13:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 13:33:41 --> Input Class Initialized
INFO - 2025-05-25 13:33:41 --> Language Class Initialized
INFO - 2025-05-25 13:33:41 --> Loader Class Initialized
INFO - 2025-05-25 13:33:41 --> Helper loaded: url_helper
INFO - 2025-05-25 13:33:41 --> Helper loaded: form_helper
INFO - 2025-05-25 13:33:41 --> Database Driver Class Initialized
DEBUG - 2025-05-25 13:33:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 13:33:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 13:33:41 --> Controller Class Initialized
INFO - 2025-05-25 13:33:41 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 13:33:41 --> Model "User_model" initialized
INFO - 2025-05-25 13:33:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 13:33:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 13:33:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/start.php
INFO - 2025-05-25 13:33:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 13:33:41 --> Final output sent to browser
DEBUG - 2025-05-25 13:33:41 --> Total execution time: 0.0585
INFO - 2025-05-25 13:39:06 --> Config Class Initialized
INFO - 2025-05-25 13:39:06 --> Hooks Class Initialized
DEBUG - 2025-05-25 13:39:06 --> UTF-8 Support Enabled
INFO - 2025-05-25 13:39:06 --> Utf8 Class Initialized
INFO - 2025-05-25 13:39:06 --> URI Class Initialized
INFO - 2025-05-25 13:39:06 --> Router Class Initialized
INFO - 2025-05-25 13:39:06 --> Output Class Initialized
INFO - 2025-05-25 13:39:06 --> Security Class Initialized
DEBUG - 2025-05-25 13:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 13:39:06 --> Input Class Initialized
INFO - 2025-05-25 13:39:06 --> Language Class Initialized
INFO - 2025-05-25 13:39:06 --> Loader Class Initialized
INFO - 2025-05-25 13:39:06 --> Helper loaded: url_helper
INFO - 2025-05-25 13:39:06 --> Helper loaded: form_helper
INFO - 2025-05-25 13:39:06 --> Database Driver Class Initialized
DEBUG - 2025-05-25 13:39:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 13:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 13:39:06 --> Controller Class Initialized
INFO - 2025-05-25 13:39:06 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 13:39:06 --> Model "User_model" initialized
INFO - 2025-05-25 13:39:06 --> Final output sent to browser
DEBUG - 2025-05-25 13:39:07 --> Total execution time: 0.0618
INFO - 2025-05-25 13:39:10 --> Config Class Initialized
INFO - 2025-05-25 13:39:10 --> Hooks Class Initialized
DEBUG - 2025-05-25 13:39:10 --> UTF-8 Support Enabled
INFO - 2025-05-25 13:39:10 --> Utf8 Class Initialized
INFO - 2025-05-25 13:39:10 --> URI Class Initialized
INFO - 2025-05-25 13:39:10 --> Router Class Initialized
INFO - 2025-05-25 13:39:10 --> Output Class Initialized
INFO - 2025-05-25 13:39:10 --> Security Class Initialized
DEBUG - 2025-05-25 13:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 13:39:10 --> Input Class Initialized
INFO - 2025-05-25 13:39:10 --> Language Class Initialized
INFO - 2025-05-25 13:39:10 --> Loader Class Initialized
INFO - 2025-05-25 13:39:10 --> Helper loaded: url_helper
INFO - 2025-05-25 13:39:10 --> Helper loaded: form_helper
INFO - 2025-05-25 13:39:10 --> Database Driver Class Initialized
DEBUG - 2025-05-25 13:39:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 13:39:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 13:39:10 --> Controller Class Initialized
INFO - 2025-05-25 13:39:10 --> Model "Progress_model" initialized
INFO - 2025-05-25 13:39:10 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 13:39:10 --> Model "User_model" initialized
INFO - 2025-05-25 13:39:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 13:39:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 13:39:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-25 13:39:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 13:39:10 --> Final output sent to browser
DEBUG - 2025-05-25 13:39:10 --> Total execution time: 0.0822
INFO - 2025-05-25 13:39:11 --> Config Class Initialized
INFO - 2025-05-25 13:39:11 --> Hooks Class Initialized
DEBUG - 2025-05-25 13:39:11 --> UTF-8 Support Enabled
INFO - 2025-05-25 13:39:11 --> Utf8 Class Initialized
INFO - 2025-05-25 13:39:11 --> URI Class Initialized
INFO - 2025-05-25 13:39:11 --> Router Class Initialized
INFO - 2025-05-25 13:39:11 --> Output Class Initialized
INFO - 2025-05-25 13:39:11 --> Security Class Initialized
DEBUG - 2025-05-25 13:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 13:39:11 --> Input Class Initialized
INFO - 2025-05-25 13:39:11 --> Language Class Initialized
INFO - 2025-05-25 13:39:11 --> Loader Class Initialized
INFO - 2025-05-25 13:39:11 --> Helper loaded: url_helper
INFO - 2025-05-25 13:39:11 --> Helper loaded: form_helper
INFO - 2025-05-25 13:39:11 --> Database Driver Class Initialized
DEBUG - 2025-05-25 13:39:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 13:39:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 13:39:11 --> Controller Class Initialized
INFO - 2025-05-25 13:39:11 --> Model "Progress_model" initialized
INFO - 2025-05-25 13:39:11 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 13:39:11 --> Model "User_model" initialized
INFO - 2025-05-25 13:39:11 --> Final output sent to browser
DEBUG - 2025-05-25 13:39:11 --> Total execution time: 0.0646
INFO - 2025-05-25 13:39:15 --> Config Class Initialized
INFO - 2025-05-25 13:39:15 --> Hooks Class Initialized
DEBUG - 2025-05-25 13:39:15 --> UTF-8 Support Enabled
INFO - 2025-05-25 13:39:15 --> Utf8 Class Initialized
INFO - 2025-05-25 13:39:15 --> URI Class Initialized
INFO - 2025-05-25 13:39:15 --> Router Class Initialized
INFO - 2025-05-25 13:39:15 --> Output Class Initialized
INFO - 2025-05-25 13:39:15 --> Security Class Initialized
DEBUG - 2025-05-25 13:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 13:39:15 --> Input Class Initialized
INFO - 2025-05-25 13:39:15 --> Language Class Initialized
INFO - 2025-05-25 13:39:15 --> Loader Class Initialized
INFO - 2025-05-25 13:39:15 --> Helper loaded: url_helper
INFO - 2025-05-25 13:39:15 --> Helper loaded: form_helper
INFO - 2025-05-25 13:39:15 --> Database Driver Class Initialized
DEBUG - 2025-05-25 13:39:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 13:39:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 13:39:15 --> Controller Class Initialized
INFO - 2025-05-25 13:39:15 --> Model "Progress_model" initialized
INFO - 2025-05-25 13:39:15 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 13:39:15 --> Model "User_model" initialized
INFO - 2025-05-25 13:39:15 --> Final output sent to browser
DEBUG - 2025-05-25 13:39:15 --> Total execution time: 0.0846
INFO - 2025-05-25 13:39:20 --> Config Class Initialized
INFO - 2025-05-25 13:39:20 --> Hooks Class Initialized
DEBUG - 2025-05-25 13:39:20 --> UTF-8 Support Enabled
INFO - 2025-05-25 13:39:20 --> Utf8 Class Initialized
INFO - 2025-05-25 13:39:20 --> URI Class Initialized
INFO - 2025-05-25 13:39:20 --> Router Class Initialized
INFO - 2025-05-25 13:39:20 --> Output Class Initialized
INFO - 2025-05-25 13:39:20 --> Security Class Initialized
DEBUG - 2025-05-25 13:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 13:39:20 --> Input Class Initialized
INFO - 2025-05-25 13:39:20 --> Language Class Initialized
INFO - 2025-05-25 13:39:20 --> Loader Class Initialized
INFO - 2025-05-25 13:39:20 --> Helper loaded: url_helper
INFO - 2025-05-25 13:39:20 --> Helper loaded: form_helper
INFO - 2025-05-25 13:39:20 --> Database Driver Class Initialized
DEBUG - 2025-05-25 13:39:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 13:39:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 13:39:20 --> Controller Class Initialized
INFO - 2025-05-25 13:39:20 --> Model "User_model" initialized
INFO - 2025-05-25 13:39:20 --> Model "Progress_model" initialized
INFO - 2025-05-25 13:39:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 13:39:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
ERROR - 2025-05-25 13:39:20 --> Severity: Warning --> Undefined variable $labels C:\laragon\www\Project\fitnessrecord\application\views\dashboard\dashboard.php 96
ERROR - 2025-05-25 13:39:20 --> Severity: Warning --> Undefined variable $latihan C:\laragon\www\Project\fitnessrecord\application\views\dashboard\dashboard.php 97
ERROR - 2025-05-25 13:39:20 --> Severity: Warning --> Undefined variable $kalori C:\laragon\www\Project\fitnessrecord\application\views\dashboard\dashboard.php 98
INFO - 2025-05-25 13:39:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-25 13:39:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 13:39:20 --> Final output sent to browser
DEBUG - 2025-05-25 13:39:20 --> Total execution time: 0.0698
INFO - 2025-05-25 13:50:26 --> Config Class Initialized
INFO - 2025-05-25 13:50:26 --> Hooks Class Initialized
DEBUG - 2025-05-25 13:50:26 --> UTF-8 Support Enabled
INFO - 2025-05-25 13:50:26 --> Utf8 Class Initialized
INFO - 2025-05-25 13:50:26 --> URI Class Initialized
INFO - 2025-05-25 13:50:26 --> Router Class Initialized
INFO - 2025-05-25 13:50:26 --> Output Class Initialized
INFO - 2025-05-25 13:50:26 --> Security Class Initialized
DEBUG - 2025-05-25 13:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 13:50:26 --> Input Class Initialized
INFO - 2025-05-25 13:50:26 --> Language Class Initialized
INFO - 2025-05-25 13:50:26 --> Loader Class Initialized
INFO - 2025-05-25 13:50:26 --> Helper loaded: url_helper
INFO - 2025-05-25 13:50:26 --> Helper loaded: form_helper
INFO - 2025-05-25 13:50:26 --> Database Driver Class Initialized
DEBUG - 2025-05-25 13:50:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 13:50:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 13:50:26 --> Controller Class Initialized
INFO - 2025-05-25 13:50:26 --> Model "User_model" initialized
INFO - 2025-05-25 13:50:26 --> Model "Progress_model" initialized
INFO - 2025-05-25 13:50:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 13:50:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 13:50:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-25 13:50:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 13:50:26 --> Final output sent to browser
DEBUG - 2025-05-25 13:50:26 --> Total execution time: 0.0715
INFO - 2025-05-25 13:50:49 --> Config Class Initialized
INFO - 2025-05-25 13:50:49 --> Hooks Class Initialized
DEBUG - 2025-05-25 13:50:49 --> UTF-8 Support Enabled
INFO - 2025-05-25 13:50:49 --> Utf8 Class Initialized
INFO - 2025-05-25 13:50:49 --> URI Class Initialized
INFO - 2025-05-25 13:50:49 --> Router Class Initialized
INFO - 2025-05-25 13:50:49 --> Output Class Initialized
INFO - 2025-05-25 13:50:49 --> Security Class Initialized
DEBUG - 2025-05-25 13:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 13:50:49 --> Input Class Initialized
INFO - 2025-05-25 13:50:49 --> Language Class Initialized
INFO - 2025-05-25 13:50:49 --> Loader Class Initialized
INFO - 2025-05-25 13:50:49 --> Helper loaded: url_helper
INFO - 2025-05-25 13:50:49 --> Helper loaded: form_helper
INFO - 2025-05-25 13:50:49 --> Database Driver Class Initialized
DEBUG - 2025-05-25 13:50:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 13:50:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 13:50:49 --> Controller Class Initialized
INFO - 2025-05-25 13:50:49 --> Model "User_model" initialized
INFO - 2025-05-25 13:50:49 --> Model "Progress_model" initialized
INFO - 2025-05-25 13:50:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 13:50:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 13:50:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-25 13:50:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 13:50:49 --> Final output sent to browser
DEBUG - 2025-05-25 13:50:49 --> Total execution time: 0.0862
INFO - 2025-05-25 13:50:52 --> Config Class Initialized
INFO - 2025-05-25 13:50:52 --> Hooks Class Initialized
DEBUG - 2025-05-25 13:50:52 --> UTF-8 Support Enabled
INFO - 2025-05-25 13:50:52 --> Utf8 Class Initialized
INFO - 2025-05-25 13:50:52 --> URI Class Initialized
INFO - 2025-05-25 13:50:52 --> Router Class Initialized
INFO - 2025-05-25 13:50:52 --> Output Class Initialized
INFO - 2025-05-25 13:50:52 --> Security Class Initialized
DEBUG - 2025-05-25 13:50:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 13:50:52 --> Input Class Initialized
INFO - 2025-05-25 13:50:52 --> Language Class Initialized
INFO - 2025-05-25 13:50:52 --> Loader Class Initialized
INFO - 2025-05-25 13:50:52 --> Helper loaded: url_helper
INFO - 2025-05-25 13:50:52 --> Helper loaded: form_helper
INFO - 2025-05-25 13:50:52 --> Database Driver Class Initialized
DEBUG - 2025-05-25 13:50:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 13:50:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 13:50:52 --> Controller Class Initialized
INFO - 2025-05-25 13:50:52 --> Model "User_model" initialized
INFO - 2025-05-25 13:50:52 --> Model "Progress_model" initialized
INFO - 2025-05-25 13:50:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 13:50:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 13:50:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-25 13:50:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 13:50:52 --> Final output sent to browser
DEBUG - 2025-05-25 13:50:52 --> Total execution time: 0.0805
INFO - 2025-05-25 13:55:55 --> Config Class Initialized
INFO - 2025-05-25 13:55:55 --> Hooks Class Initialized
DEBUG - 2025-05-25 13:55:55 --> UTF-8 Support Enabled
INFO - 2025-05-25 13:55:55 --> Utf8 Class Initialized
INFO - 2025-05-25 13:55:55 --> URI Class Initialized
INFO - 2025-05-25 13:55:55 --> Router Class Initialized
INFO - 2025-05-25 13:55:55 --> Output Class Initialized
INFO - 2025-05-25 13:55:55 --> Security Class Initialized
DEBUG - 2025-05-25 13:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 13:55:55 --> Input Class Initialized
INFO - 2025-05-25 13:55:55 --> Language Class Initialized
INFO - 2025-05-25 13:55:55 --> Loader Class Initialized
INFO - 2025-05-25 13:55:55 --> Helper loaded: url_helper
INFO - 2025-05-25 13:55:55 --> Helper loaded: form_helper
INFO - 2025-05-25 13:55:55 --> Database Driver Class Initialized
DEBUG - 2025-05-25 13:55:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 13:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 13:55:55 --> Controller Class Initialized
INFO - 2025-05-25 13:55:55 --> Model "User_model" initialized
INFO - 2025-05-25 13:55:55 --> Model "Progress_model" initialized
INFO - 2025-05-25 13:55:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 13:55:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 13:55:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-25 13:55:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 13:55:55 --> Final output sent to browser
DEBUG - 2025-05-25 13:55:55 --> Total execution time: 0.0733
INFO - 2025-05-25 13:56:00 --> Config Class Initialized
INFO - 2025-05-25 13:56:00 --> Hooks Class Initialized
DEBUG - 2025-05-25 13:56:00 --> UTF-8 Support Enabled
INFO - 2025-05-25 13:56:00 --> Utf8 Class Initialized
INFO - 2025-05-25 13:56:00 --> URI Class Initialized
INFO - 2025-05-25 13:56:00 --> Router Class Initialized
INFO - 2025-05-25 13:56:00 --> Output Class Initialized
INFO - 2025-05-25 13:56:00 --> Security Class Initialized
DEBUG - 2025-05-25 13:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 13:56:00 --> Input Class Initialized
INFO - 2025-05-25 13:56:00 --> Language Class Initialized
INFO - 2025-05-25 13:56:00 --> Loader Class Initialized
INFO - 2025-05-25 13:56:00 --> Helper loaded: url_helper
INFO - 2025-05-25 13:56:00 --> Helper loaded: form_helper
INFO - 2025-05-25 13:56:00 --> Database Driver Class Initialized
DEBUG - 2025-05-25 13:56:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 13:56:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 13:56:00 --> Controller Class Initialized
INFO - 2025-05-25 13:56:00 --> Model "User_model" initialized
INFO - 2025-05-25 13:56:00 --> Model "Progress_model" initialized
INFO - 2025-05-25 13:56:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 13:56:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 13:56:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-25 13:56:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 13:56:00 --> Final output sent to browser
DEBUG - 2025-05-25 13:56:00 --> Total execution time: 0.0773
INFO - 2025-05-25 13:56:02 --> Config Class Initialized
INFO - 2025-05-25 13:56:02 --> Hooks Class Initialized
DEBUG - 2025-05-25 13:56:02 --> UTF-8 Support Enabled
INFO - 2025-05-25 13:56:02 --> Utf8 Class Initialized
INFO - 2025-05-25 13:56:02 --> URI Class Initialized
INFO - 2025-05-25 13:56:02 --> Router Class Initialized
INFO - 2025-05-25 13:56:02 --> Output Class Initialized
INFO - 2025-05-25 13:56:02 --> Security Class Initialized
DEBUG - 2025-05-25 13:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 13:56:02 --> Input Class Initialized
INFO - 2025-05-25 13:56:02 --> Language Class Initialized
INFO - 2025-05-25 13:56:02 --> Loader Class Initialized
INFO - 2025-05-25 13:56:02 --> Helper loaded: url_helper
INFO - 2025-05-25 13:56:02 --> Helper loaded: form_helper
INFO - 2025-05-25 13:56:02 --> Database Driver Class Initialized
DEBUG - 2025-05-25 13:56:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 13:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 13:56:02 --> Controller Class Initialized
INFO - 2025-05-25 13:56:02 --> Model "User_model" initialized
INFO - 2025-05-25 13:56:02 --> Model "Progress_model" initialized
INFO - 2025-05-25 13:56:02 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 13:56:02 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 13:56:02 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-25 13:56:02 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 13:56:02 --> Final output sent to browser
DEBUG - 2025-05-25 13:56:02 --> Total execution time: 0.0637
INFO - 2025-05-25 13:59:05 --> Config Class Initialized
INFO - 2025-05-25 13:59:05 --> Hooks Class Initialized
DEBUG - 2025-05-25 13:59:05 --> UTF-8 Support Enabled
INFO - 2025-05-25 13:59:05 --> Utf8 Class Initialized
INFO - 2025-05-25 13:59:05 --> URI Class Initialized
INFO - 2025-05-25 13:59:05 --> Router Class Initialized
INFO - 2025-05-25 13:59:05 --> Output Class Initialized
INFO - 2025-05-25 13:59:05 --> Security Class Initialized
DEBUG - 2025-05-25 13:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 13:59:05 --> Input Class Initialized
INFO - 2025-05-25 13:59:05 --> Language Class Initialized
INFO - 2025-05-25 13:59:05 --> Loader Class Initialized
INFO - 2025-05-25 13:59:05 --> Helper loaded: url_helper
INFO - 2025-05-25 13:59:05 --> Helper loaded: form_helper
INFO - 2025-05-25 13:59:05 --> Database Driver Class Initialized
DEBUG - 2025-05-25 13:59:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 13:59:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 13:59:05 --> Controller Class Initialized
INFO - 2025-05-25 13:59:05 --> Model "User_model" initialized
INFO - 2025-05-25 13:59:05 --> Model "Progress_model" initialized
INFO - 2025-05-25 13:59:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 13:59:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 13:59:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-25 13:59:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 13:59:05 --> Final output sent to browser
DEBUG - 2025-05-25 13:59:05 --> Total execution time: 0.0770
INFO - 2025-05-25 13:59:06 --> Config Class Initialized
INFO - 2025-05-25 13:59:06 --> Hooks Class Initialized
DEBUG - 2025-05-25 13:59:06 --> UTF-8 Support Enabled
INFO - 2025-05-25 13:59:06 --> Utf8 Class Initialized
INFO - 2025-05-25 13:59:06 --> URI Class Initialized
INFO - 2025-05-25 13:59:06 --> Router Class Initialized
INFO - 2025-05-25 13:59:06 --> Output Class Initialized
INFO - 2025-05-25 13:59:06 --> Security Class Initialized
DEBUG - 2025-05-25 13:59:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 13:59:06 --> Input Class Initialized
INFO - 2025-05-25 13:59:06 --> Language Class Initialized
INFO - 2025-05-25 13:59:06 --> Loader Class Initialized
INFO - 2025-05-25 13:59:06 --> Helper loaded: url_helper
INFO - 2025-05-25 13:59:06 --> Helper loaded: form_helper
INFO - 2025-05-25 13:59:06 --> Database Driver Class Initialized
DEBUG - 2025-05-25 13:59:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 13:59:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 13:59:06 --> Controller Class Initialized
INFO - 2025-05-25 13:59:06 --> Model "Progress_model" initialized
INFO - 2025-05-25 13:59:06 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 13:59:06 --> Model "User_model" initialized
INFO - 2025-05-25 13:59:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 13:59:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 13:59:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-25 13:59:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 13:59:06 --> Final output sent to browser
DEBUG - 2025-05-25 13:59:06 --> Total execution time: 0.0615
INFO - 2025-05-25 13:59:07 --> Config Class Initialized
INFO - 2025-05-25 13:59:07 --> Hooks Class Initialized
DEBUG - 2025-05-25 13:59:07 --> UTF-8 Support Enabled
INFO - 2025-05-25 13:59:07 --> Utf8 Class Initialized
INFO - 2025-05-25 13:59:07 --> URI Class Initialized
INFO - 2025-05-25 13:59:07 --> Router Class Initialized
INFO - 2025-05-25 13:59:07 --> Output Class Initialized
INFO - 2025-05-25 13:59:07 --> Security Class Initialized
DEBUG - 2025-05-25 13:59:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 13:59:07 --> Input Class Initialized
INFO - 2025-05-25 13:59:07 --> Language Class Initialized
INFO - 2025-05-25 13:59:07 --> Loader Class Initialized
INFO - 2025-05-25 13:59:07 --> Helper loaded: url_helper
INFO - 2025-05-25 13:59:07 --> Helper loaded: form_helper
INFO - 2025-05-25 13:59:07 --> Database Driver Class Initialized
DEBUG - 2025-05-25 13:59:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 13:59:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 13:59:07 --> Controller Class Initialized
INFO - 2025-05-25 13:59:07 --> Model "Progress_model" initialized
INFO - 2025-05-25 13:59:07 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 13:59:07 --> Model "User_model" initialized
INFO - 2025-05-25 13:59:07 --> Final output sent to browser
DEBUG - 2025-05-25 13:59:07 --> Total execution time: 0.0765
INFO - 2025-05-25 14:00:35 --> Config Class Initialized
INFO - 2025-05-25 14:00:35 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:00:35 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:00:35 --> Utf8 Class Initialized
INFO - 2025-05-25 14:00:35 --> URI Class Initialized
INFO - 2025-05-25 14:00:35 --> Router Class Initialized
INFO - 2025-05-25 14:00:35 --> Output Class Initialized
INFO - 2025-05-25 14:00:35 --> Security Class Initialized
DEBUG - 2025-05-25 14:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:00:35 --> Input Class Initialized
INFO - 2025-05-25 14:00:35 --> Language Class Initialized
INFO - 2025-05-25 14:00:35 --> Loader Class Initialized
INFO - 2025-05-25 14:00:35 --> Helper loaded: url_helper
INFO - 2025-05-25 14:00:35 --> Helper loaded: form_helper
INFO - 2025-05-25 14:00:35 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:00:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:00:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:00:35 --> Controller Class Initialized
INFO - 2025-05-25 14:00:35 --> Model "Progress_model" initialized
INFO - 2025-05-25 14:00:35 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:00:35 --> Model "User_model" initialized
INFO - 2025-05-25 14:00:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:00:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:00:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-25 14:00:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:00:35 --> Final output sent to browser
DEBUG - 2025-05-25 14:00:35 --> Total execution time: 0.0758
INFO - 2025-05-25 14:00:36 --> Config Class Initialized
INFO - 2025-05-25 14:00:36 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:00:36 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:00:36 --> Utf8 Class Initialized
INFO - 2025-05-25 14:00:36 --> URI Class Initialized
INFO - 2025-05-25 14:00:36 --> Router Class Initialized
INFO - 2025-05-25 14:00:36 --> Output Class Initialized
INFO - 2025-05-25 14:00:36 --> Security Class Initialized
DEBUG - 2025-05-25 14:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:00:36 --> Input Class Initialized
INFO - 2025-05-25 14:00:36 --> Language Class Initialized
INFO - 2025-05-25 14:00:36 --> Loader Class Initialized
INFO - 2025-05-25 14:00:36 --> Helper loaded: url_helper
INFO - 2025-05-25 14:00:36 --> Helper loaded: form_helper
INFO - 2025-05-25 14:00:36 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:00:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:00:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:00:36 --> Controller Class Initialized
INFO - 2025-05-25 14:00:36 --> Model "Progress_model" initialized
INFO - 2025-05-25 14:00:36 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:00:36 --> Model "User_model" initialized
INFO - 2025-05-25 14:00:36 --> Final output sent to browser
DEBUG - 2025-05-25 14:00:36 --> Total execution time: 0.0633
INFO - 2025-05-25 14:01:20 --> Config Class Initialized
INFO - 2025-05-25 14:01:20 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:01:20 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:01:20 --> Utf8 Class Initialized
INFO - 2025-05-25 14:01:20 --> URI Class Initialized
INFO - 2025-05-25 14:01:20 --> Router Class Initialized
INFO - 2025-05-25 14:01:20 --> Output Class Initialized
INFO - 2025-05-25 14:01:20 --> Security Class Initialized
DEBUG - 2025-05-25 14:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:01:20 --> Input Class Initialized
INFO - 2025-05-25 14:01:20 --> Language Class Initialized
INFO - 2025-05-25 14:01:20 --> Loader Class Initialized
INFO - 2025-05-25 14:01:20 --> Helper loaded: url_helper
INFO - 2025-05-25 14:01:20 --> Helper loaded: form_helper
INFO - 2025-05-25 14:01:20 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:01:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:01:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:01:20 --> Controller Class Initialized
INFO - 2025-05-25 14:01:20 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:01:20 --> Model "User_model" initialized
INFO - 2025-05-25 14:01:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:01:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:01:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-05-25 14:01:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:01:20 --> Final output sent to browser
DEBUG - 2025-05-25 14:01:20 --> Total execution time: 0.0901
INFO - 2025-05-25 14:01:22 --> Config Class Initialized
INFO - 2025-05-25 14:01:22 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:01:22 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:01:22 --> Utf8 Class Initialized
INFO - 2025-05-25 14:01:22 --> URI Class Initialized
INFO - 2025-05-25 14:01:22 --> Router Class Initialized
INFO - 2025-05-25 14:01:22 --> Output Class Initialized
INFO - 2025-05-25 14:01:22 --> Security Class Initialized
DEBUG - 2025-05-25 14:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:01:22 --> Input Class Initialized
INFO - 2025-05-25 14:01:22 --> Language Class Initialized
INFO - 2025-05-25 14:01:22 --> Loader Class Initialized
INFO - 2025-05-25 14:01:22 --> Helper loaded: url_helper
INFO - 2025-05-25 14:01:22 --> Helper loaded: form_helper
INFO - 2025-05-25 14:01:23 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:01:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:01:23 --> Controller Class Initialized
INFO - 2025-05-25 14:01:23 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:01:23 --> Model "User_model" initialized
INFO - 2025-05-25 14:01:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:01:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:01:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-05-25 14:01:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:01:23 --> Final output sent to browser
DEBUG - 2025-05-25 14:01:23 --> Total execution time: 0.0605
INFO - 2025-05-25 14:01:25 --> Config Class Initialized
INFO - 2025-05-25 14:01:25 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:01:25 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:01:25 --> Utf8 Class Initialized
INFO - 2025-05-25 14:01:25 --> URI Class Initialized
INFO - 2025-05-25 14:01:25 --> Router Class Initialized
INFO - 2025-05-25 14:01:25 --> Output Class Initialized
INFO - 2025-05-25 14:01:25 --> Security Class Initialized
DEBUG - 2025-05-25 14:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:01:25 --> Input Class Initialized
INFO - 2025-05-25 14:01:25 --> Language Class Initialized
INFO - 2025-05-25 14:01:25 --> Loader Class Initialized
INFO - 2025-05-25 14:01:25 --> Helper loaded: url_helper
INFO - 2025-05-25 14:01:25 --> Helper loaded: form_helper
INFO - 2025-05-25 14:01:25 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:01:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:01:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:01:25 --> Controller Class Initialized
INFO - 2025-05-25 14:01:25 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:01:25 --> Model "User_model" initialized
INFO - 2025-05-25 14:01:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:01:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:01:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/menu.php
INFO - 2025-05-25 14:01:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:01:25 --> Final output sent to browser
DEBUG - 2025-05-25 14:01:25 --> Total execution time: 0.0788
INFO - 2025-05-25 14:01:28 --> Config Class Initialized
INFO - 2025-05-25 14:01:28 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:01:28 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:01:28 --> Utf8 Class Initialized
INFO - 2025-05-25 14:01:28 --> URI Class Initialized
INFO - 2025-05-25 14:01:28 --> Router Class Initialized
INFO - 2025-05-25 14:01:28 --> Output Class Initialized
INFO - 2025-05-25 14:01:28 --> Security Class Initialized
DEBUG - 2025-05-25 14:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:01:28 --> Input Class Initialized
INFO - 2025-05-25 14:01:28 --> Language Class Initialized
INFO - 2025-05-25 14:01:28 --> Loader Class Initialized
INFO - 2025-05-25 14:01:28 --> Helper loaded: url_helper
INFO - 2025-05-25 14:01:28 --> Helper loaded: form_helper
INFO - 2025-05-25 14:01:28 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:01:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:01:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:01:28 --> Controller Class Initialized
INFO - 2025-05-25 14:01:28 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:01:28 --> Model "User_model" initialized
INFO - 2025-05-25 14:01:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:01:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:01:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/menu.php
INFO - 2025-05-25 14:01:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:01:28 --> Final output sent to browser
DEBUG - 2025-05-25 14:01:28 --> Total execution time: 0.0616
INFO - 2025-05-25 14:03:07 --> Config Class Initialized
INFO - 2025-05-25 14:03:07 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:03:07 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:03:07 --> Utf8 Class Initialized
INFO - 2025-05-25 14:03:07 --> URI Class Initialized
INFO - 2025-05-25 14:03:07 --> Router Class Initialized
INFO - 2025-05-25 14:03:07 --> Output Class Initialized
INFO - 2025-05-25 14:03:07 --> Security Class Initialized
DEBUG - 2025-05-25 14:03:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:03:07 --> Input Class Initialized
INFO - 2025-05-25 14:03:07 --> Language Class Initialized
INFO - 2025-05-25 14:03:07 --> Loader Class Initialized
INFO - 2025-05-25 14:03:07 --> Helper loaded: url_helper
INFO - 2025-05-25 14:03:07 --> Helper loaded: form_helper
INFO - 2025-05-25 14:03:07 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:03:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:03:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:03:07 --> Controller Class Initialized
INFO - 2025-05-25 14:03:07 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:03:07 --> Model "User_model" initialized
INFO - 2025-05-25 14:03:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:03:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:03:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/menu.php
INFO - 2025-05-25 14:03:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:03:07 --> Final output sent to browser
DEBUG - 2025-05-25 14:03:07 --> Total execution time: 0.0642
INFO - 2025-05-25 14:03:10 --> Config Class Initialized
INFO - 2025-05-25 14:03:10 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:03:10 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:03:10 --> Utf8 Class Initialized
INFO - 2025-05-25 14:03:10 --> URI Class Initialized
INFO - 2025-05-25 14:03:10 --> Router Class Initialized
INFO - 2025-05-25 14:03:10 --> Output Class Initialized
INFO - 2025-05-25 14:03:10 --> Security Class Initialized
DEBUG - 2025-05-25 14:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:03:10 --> Input Class Initialized
INFO - 2025-05-25 14:03:10 --> Language Class Initialized
INFO - 2025-05-25 14:03:10 --> Loader Class Initialized
INFO - 2025-05-25 14:03:10 --> Helper loaded: url_helper
INFO - 2025-05-25 14:03:10 --> Helper loaded: form_helper
INFO - 2025-05-25 14:03:10 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:03:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:03:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:03:10 --> Controller Class Initialized
INFO - 2025-05-25 14:03:10 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:03:10 --> Model "User_model" initialized
INFO - 2025-05-25 14:03:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:03:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:03:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/start.php
INFO - 2025-05-25 14:03:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:03:10 --> Final output sent to browser
DEBUG - 2025-05-25 14:03:10 --> Total execution time: 0.0762
INFO - 2025-05-25 14:03:34 --> Config Class Initialized
INFO - 2025-05-25 14:03:34 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:03:34 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:03:34 --> Utf8 Class Initialized
INFO - 2025-05-25 14:03:34 --> URI Class Initialized
INFO - 2025-05-25 14:03:34 --> Router Class Initialized
INFO - 2025-05-25 14:03:34 --> Output Class Initialized
INFO - 2025-05-25 14:03:34 --> Security Class Initialized
DEBUG - 2025-05-25 14:03:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:03:34 --> Input Class Initialized
INFO - 2025-05-25 14:03:34 --> Language Class Initialized
INFO - 2025-05-25 14:03:34 --> Loader Class Initialized
INFO - 2025-05-25 14:03:34 --> Helper loaded: url_helper
INFO - 2025-05-25 14:03:34 --> Helper loaded: form_helper
INFO - 2025-05-25 14:03:34 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:03:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:03:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:03:34 --> Controller Class Initialized
INFO - 2025-05-25 14:03:34 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:03:34 --> Model "User_model" initialized
INFO - 2025-05-25 14:03:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:03:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:03:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-05-25 14:03:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:03:34 --> Final output sent to browser
DEBUG - 2025-05-25 14:03:34 --> Total execution time: 0.0742
INFO - 2025-05-25 14:04:19 --> Config Class Initialized
INFO - 2025-05-25 14:04:19 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:04:19 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:04:19 --> Utf8 Class Initialized
INFO - 2025-05-25 14:04:19 --> URI Class Initialized
INFO - 2025-05-25 14:04:19 --> Router Class Initialized
INFO - 2025-05-25 14:04:19 --> Output Class Initialized
INFO - 2025-05-25 14:04:19 --> Security Class Initialized
DEBUG - 2025-05-25 14:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:04:19 --> Input Class Initialized
INFO - 2025-05-25 14:04:19 --> Language Class Initialized
INFO - 2025-05-25 14:04:19 --> Loader Class Initialized
INFO - 2025-05-25 14:04:19 --> Helper loaded: url_helper
INFO - 2025-05-25 14:04:19 --> Helper loaded: form_helper
INFO - 2025-05-25 14:04:19 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:04:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:04:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:04:19 --> Controller Class Initialized
INFO - 2025-05-25 14:04:19 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:04:19 --> Model "User_model" initialized
INFO - 2025-05-25 14:04:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:04:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:04:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-05-25 14:04:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:04:19 --> Final output sent to browser
DEBUG - 2025-05-25 14:04:19 --> Total execution time: 0.0592
INFO - 2025-05-25 14:04:20 --> Config Class Initialized
INFO - 2025-05-25 14:04:20 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:04:20 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:04:20 --> Utf8 Class Initialized
INFO - 2025-05-25 14:04:20 --> URI Class Initialized
INFO - 2025-05-25 14:04:20 --> Router Class Initialized
INFO - 2025-05-25 14:04:20 --> Output Class Initialized
INFO - 2025-05-25 14:04:20 --> Security Class Initialized
DEBUG - 2025-05-25 14:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:04:20 --> Input Class Initialized
INFO - 2025-05-25 14:04:20 --> Language Class Initialized
INFO - 2025-05-25 14:04:20 --> Loader Class Initialized
INFO - 2025-05-25 14:04:20 --> Helper loaded: url_helper
INFO - 2025-05-25 14:04:20 --> Helper loaded: form_helper
INFO - 2025-05-25 14:04:20 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:04:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:04:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:04:20 --> Controller Class Initialized
INFO - 2025-05-25 14:04:20 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:04:20 --> Model "User_model" initialized
INFO - 2025-05-25 14:04:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:04:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:04:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/menu.php
INFO - 2025-05-25 14:04:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:04:20 --> Final output sent to browser
DEBUG - 2025-05-25 14:04:20 --> Total execution time: 0.0608
INFO - 2025-05-25 14:04:21 --> Config Class Initialized
INFO - 2025-05-25 14:04:21 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:04:21 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:04:21 --> Utf8 Class Initialized
INFO - 2025-05-25 14:04:21 --> URI Class Initialized
INFO - 2025-05-25 14:04:21 --> Router Class Initialized
INFO - 2025-05-25 14:04:21 --> Output Class Initialized
INFO - 2025-05-25 14:04:21 --> Security Class Initialized
DEBUG - 2025-05-25 14:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:04:21 --> Input Class Initialized
INFO - 2025-05-25 14:04:21 --> Language Class Initialized
INFO - 2025-05-25 14:04:21 --> Loader Class Initialized
INFO - 2025-05-25 14:04:21 --> Helper loaded: url_helper
INFO - 2025-05-25 14:04:21 --> Helper loaded: form_helper
INFO - 2025-05-25 14:04:21 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:04:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:04:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:04:22 --> Controller Class Initialized
INFO - 2025-05-25 14:04:22 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:04:22 --> Model "User_model" initialized
INFO - 2025-05-25 14:04:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:04:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:04:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/start.php
INFO - 2025-05-25 14:04:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:04:22 --> Final output sent to browser
DEBUG - 2025-05-25 14:04:22 --> Total execution time: 0.0605
INFO - 2025-05-25 14:05:42 --> Config Class Initialized
INFO - 2025-05-25 14:05:42 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:05:42 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:05:42 --> Utf8 Class Initialized
INFO - 2025-05-25 14:05:42 --> URI Class Initialized
INFO - 2025-05-25 14:05:42 --> Router Class Initialized
INFO - 2025-05-25 14:05:42 --> Output Class Initialized
INFO - 2025-05-25 14:05:42 --> Security Class Initialized
DEBUG - 2025-05-25 14:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:05:42 --> Input Class Initialized
INFO - 2025-05-25 14:05:42 --> Language Class Initialized
INFO - 2025-05-25 14:05:42 --> Loader Class Initialized
INFO - 2025-05-25 14:05:42 --> Helper loaded: url_helper
INFO - 2025-05-25 14:05:42 --> Helper loaded: form_helper
INFO - 2025-05-25 14:05:42 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:05:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:05:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:05:42 --> Controller Class Initialized
INFO - 2025-05-25 14:05:42 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:05:42 --> Model "User_model" initialized
INFO - 2025-05-25 14:05:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:05:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:05:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/start.php
INFO - 2025-05-25 14:05:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:05:42 --> Final output sent to browser
DEBUG - 2025-05-25 14:05:42 --> Total execution time: 0.0776
INFO - 2025-05-25 14:06:03 --> Config Class Initialized
INFO - 2025-05-25 14:06:03 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:06:03 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:06:03 --> Utf8 Class Initialized
INFO - 2025-05-25 14:06:03 --> URI Class Initialized
INFO - 2025-05-25 14:06:03 --> Router Class Initialized
INFO - 2025-05-25 14:06:03 --> Output Class Initialized
INFO - 2025-05-25 14:06:03 --> Security Class Initialized
DEBUG - 2025-05-25 14:06:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:06:03 --> Input Class Initialized
INFO - 2025-05-25 14:06:03 --> Language Class Initialized
INFO - 2025-05-25 14:06:03 --> Loader Class Initialized
INFO - 2025-05-25 14:06:03 --> Helper loaded: url_helper
INFO - 2025-05-25 14:06:03 --> Helper loaded: form_helper
INFO - 2025-05-25 14:06:03 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:06:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:06:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:06:03 --> Controller Class Initialized
INFO - 2025-05-25 14:06:03 --> Model "Progress_model" initialized
INFO - 2025-05-25 14:06:03 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:06:03 --> Model "User_model" initialized
INFO - 2025-05-25 14:06:03 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:06:03 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:06:03 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-25 14:06:03 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:06:03 --> Final output sent to browser
DEBUG - 2025-05-25 14:06:03 --> Total execution time: 0.0794
INFO - 2025-05-25 14:06:03 --> Config Class Initialized
INFO - 2025-05-25 14:06:03 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:06:03 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:06:03 --> Utf8 Class Initialized
INFO - 2025-05-25 14:06:03 --> URI Class Initialized
INFO - 2025-05-25 14:06:03 --> Router Class Initialized
INFO - 2025-05-25 14:06:03 --> Output Class Initialized
INFO - 2025-05-25 14:06:03 --> Security Class Initialized
DEBUG - 2025-05-25 14:06:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:06:03 --> Input Class Initialized
INFO - 2025-05-25 14:06:03 --> Language Class Initialized
INFO - 2025-05-25 14:06:03 --> Loader Class Initialized
INFO - 2025-05-25 14:06:03 --> Helper loaded: url_helper
INFO - 2025-05-25 14:06:03 --> Helper loaded: form_helper
INFO - 2025-05-25 14:06:03 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:06:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:06:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:06:03 --> Controller Class Initialized
INFO - 2025-05-25 14:06:03 --> Model "Progress_model" initialized
INFO - 2025-05-25 14:06:03 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:06:03 --> Model "User_model" initialized
INFO - 2025-05-25 14:06:03 --> Final output sent to browser
DEBUG - 2025-05-25 14:06:03 --> Total execution time: 0.0649
INFO - 2025-05-25 14:06:36 --> Config Class Initialized
INFO - 2025-05-25 14:06:36 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:06:36 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:06:36 --> Utf8 Class Initialized
INFO - 2025-05-25 14:06:36 --> URI Class Initialized
INFO - 2025-05-25 14:06:36 --> Router Class Initialized
INFO - 2025-05-25 14:06:36 --> Output Class Initialized
INFO - 2025-05-25 14:06:36 --> Security Class Initialized
DEBUG - 2025-05-25 14:06:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:06:36 --> Input Class Initialized
INFO - 2025-05-25 14:06:36 --> Language Class Initialized
INFO - 2025-05-25 14:06:36 --> Loader Class Initialized
INFO - 2025-05-25 14:06:36 --> Helper loaded: url_helper
INFO - 2025-05-25 14:06:36 --> Helper loaded: form_helper
INFO - 2025-05-25 14:06:36 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:06:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:06:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:06:36 --> Controller Class Initialized
INFO - 2025-05-25 14:06:36 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:06:36 --> Model "User_model" initialized
INFO - 2025-05-25 14:06:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:06:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:06:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-05-25 14:06:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:06:36 --> Final output sent to browser
DEBUG - 2025-05-25 14:06:36 --> Total execution time: 0.0659
INFO - 2025-05-25 14:06:39 --> Config Class Initialized
INFO - 2025-05-25 14:06:39 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:06:39 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:06:39 --> Utf8 Class Initialized
INFO - 2025-05-25 14:06:39 --> URI Class Initialized
INFO - 2025-05-25 14:06:39 --> Router Class Initialized
INFO - 2025-05-25 14:06:39 --> Output Class Initialized
INFO - 2025-05-25 14:06:39 --> Security Class Initialized
DEBUG - 2025-05-25 14:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:06:39 --> Input Class Initialized
INFO - 2025-05-25 14:06:39 --> Language Class Initialized
INFO - 2025-05-25 14:06:39 --> Loader Class Initialized
INFO - 2025-05-25 14:06:39 --> Helper loaded: url_helper
INFO - 2025-05-25 14:06:39 --> Helper loaded: form_helper
INFO - 2025-05-25 14:06:39 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:06:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:06:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:06:39 --> Controller Class Initialized
INFO - 2025-05-25 14:06:39 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:06:39 --> Model "User_model" initialized
INFO - 2025-05-25 14:06:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:06:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:06:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-05-25 14:06:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:06:39 --> Final output sent to browser
DEBUG - 2025-05-25 14:06:39 --> Total execution time: 0.0797
INFO - 2025-05-25 14:06:41 --> Config Class Initialized
INFO - 2025-05-25 14:06:41 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:06:41 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:06:41 --> Utf8 Class Initialized
INFO - 2025-05-25 14:06:41 --> URI Class Initialized
INFO - 2025-05-25 14:06:41 --> Router Class Initialized
INFO - 2025-05-25 14:06:41 --> Output Class Initialized
INFO - 2025-05-25 14:06:41 --> Security Class Initialized
DEBUG - 2025-05-25 14:06:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:06:41 --> Input Class Initialized
INFO - 2025-05-25 14:06:41 --> Language Class Initialized
INFO - 2025-05-25 14:06:41 --> Loader Class Initialized
INFO - 2025-05-25 14:06:41 --> Helper loaded: url_helper
INFO - 2025-05-25 14:06:41 --> Helper loaded: form_helper
INFO - 2025-05-25 14:06:41 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:06:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:06:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:06:41 --> Controller Class Initialized
INFO - 2025-05-25 14:06:41 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:06:41 --> Model "User_model" initialized
INFO - 2025-05-25 14:06:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:06:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:06:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/menu.php
INFO - 2025-05-25 14:06:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:06:41 --> Final output sent to browser
DEBUG - 2025-05-25 14:06:41 --> Total execution time: 0.0603
INFO - 2025-05-25 14:06:42 --> Config Class Initialized
INFO - 2025-05-25 14:06:42 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:06:42 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:06:42 --> Utf8 Class Initialized
INFO - 2025-05-25 14:06:42 --> URI Class Initialized
INFO - 2025-05-25 14:06:42 --> Router Class Initialized
INFO - 2025-05-25 14:06:42 --> Output Class Initialized
INFO - 2025-05-25 14:06:42 --> Security Class Initialized
DEBUG - 2025-05-25 14:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:06:42 --> Input Class Initialized
INFO - 2025-05-25 14:06:42 --> Language Class Initialized
INFO - 2025-05-25 14:06:42 --> Loader Class Initialized
INFO - 2025-05-25 14:06:42 --> Helper loaded: url_helper
INFO - 2025-05-25 14:06:42 --> Helper loaded: form_helper
INFO - 2025-05-25 14:06:42 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:06:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:06:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:06:42 --> Controller Class Initialized
INFO - 2025-05-25 14:06:42 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:06:42 --> Model "User_model" initialized
INFO - 2025-05-25 14:06:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:06:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:06:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/start.php
INFO - 2025-05-25 14:06:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:06:42 --> Final output sent to browser
DEBUG - 2025-05-25 14:06:42 --> Total execution time: 0.0739
INFO - 2025-05-25 14:08:33 --> Config Class Initialized
INFO - 2025-05-25 14:08:33 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:08:33 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:08:33 --> Utf8 Class Initialized
INFO - 2025-05-25 14:08:33 --> URI Class Initialized
INFO - 2025-05-25 14:08:33 --> Router Class Initialized
INFO - 2025-05-25 14:08:33 --> Output Class Initialized
INFO - 2025-05-25 14:08:33 --> Security Class Initialized
DEBUG - 2025-05-25 14:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:08:33 --> Input Class Initialized
INFO - 2025-05-25 14:08:33 --> Language Class Initialized
INFO - 2025-05-25 14:08:33 --> Loader Class Initialized
INFO - 2025-05-25 14:08:33 --> Helper loaded: url_helper
INFO - 2025-05-25 14:08:33 --> Helper loaded: form_helper
INFO - 2025-05-25 14:08:33 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:08:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:08:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:08:33 --> Controller Class Initialized
INFO - 2025-05-25 14:08:33 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:08:33 --> Model "User_model" initialized
INFO - 2025-05-25 14:08:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:08:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:08:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/start.php
INFO - 2025-05-25 14:08:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:08:33 --> Final output sent to browser
DEBUG - 2025-05-25 14:08:33 --> Total execution time: 0.0736
INFO - 2025-05-25 14:08:40 --> Config Class Initialized
INFO - 2025-05-25 14:08:40 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:08:40 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:08:40 --> Utf8 Class Initialized
INFO - 2025-05-25 14:08:40 --> URI Class Initialized
INFO - 2025-05-25 14:08:40 --> Router Class Initialized
INFO - 2025-05-25 14:08:40 --> Output Class Initialized
INFO - 2025-05-25 14:08:40 --> Security Class Initialized
DEBUG - 2025-05-25 14:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:08:40 --> Input Class Initialized
INFO - 2025-05-25 14:08:40 --> Language Class Initialized
INFO - 2025-05-25 14:08:40 --> Loader Class Initialized
INFO - 2025-05-25 14:08:40 --> Helper loaded: url_helper
INFO - 2025-05-25 14:08:40 --> Helper loaded: form_helper
INFO - 2025-05-25 14:08:40 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:08:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:08:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:08:40 --> Controller Class Initialized
INFO - 2025-05-25 14:08:40 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:08:40 --> Model "User_model" initialized
INFO - 2025-05-25 14:08:40 --> Final output sent to browser
DEBUG - 2025-05-25 14:08:40 --> Total execution time: 0.0685
INFO - 2025-05-25 14:08:45 --> Config Class Initialized
INFO - 2025-05-25 14:08:45 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:08:45 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:08:45 --> Utf8 Class Initialized
INFO - 2025-05-25 14:08:45 --> URI Class Initialized
INFO - 2025-05-25 14:08:45 --> Router Class Initialized
INFO - 2025-05-25 14:08:45 --> Output Class Initialized
INFO - 2025-05-25 14:08:45 --> Security Class Initialized
DEBUG - 2025-05-25 14:08:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:08:45 --> Input Class Initialized
INFO - 2025-05-25 14:08:45 --> Language Class Initialized
INFO - 2025-05-25 14:08:45 --> Loader Class Initialized
INFO - 2025-05-25 14:08:45 --> Helper loaded: url_helper
INFO - 2025-05-25 14:08:45 --> Helper loaded: form_helper
INFO - 2025-05-25 14:08:45 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:08:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:08:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:08:45 --> Controller Class Initialized
INFO - 2025-05-25 14:08:45 --> Model "Progress_model" initialized
INFO - 2025-05-25 14:08:45 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:08:45 --> Model "User_model" initialized
INFO - 2025-05-25 14:08:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:08:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:08:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-25 14:08:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:08:45 --> Final output sent to browser
DEBUG - 2025-05-25 14:08:45 --> Total execution time: 0.0655
INFO - 2025-05-25 14:08:45 --> Config Class Initialized
INFO - 2025-05-25 14:08:45 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:08:45 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:08:45 --> Utf8 Class Initialized
INFO - 2025-05-25 14:08:45 --> URI Class Initialized
INFO - 2025-05-25 14:08:45 --> Router Class Initialized
INFO - 2025-05-25 14:08:45 --> Output Class Initialized
INFO - 2025-05-25 14:08:45 --> Security Class Initialized
DEBUG - 2025-05-25 14:08:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:08:45 --> Input Class Initialized
INFO - 2025-05-25 14:08:45 --> Language Class Initialized
INFO - 2025-05-25 14:08:45 --> Loader Class Initialized
INFO - 2025-05-25 14:08:45 --> Helper loaded: url_helper
INFO - 2025-05-25 14:08:45 --> Helper loaded: form_helper
INFO - 2025-05-25 14:08:45 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:08:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:08:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:08:45 --> Controller Class Initialized
INFO - 2025-05-25 14:08:45 --> Model "Progress_model" initialized
INFO - 2025-05-25 14:08:45 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:08:45 --> Model "User_model" initialized
INFO - 2025-05-25 14:08:45 --> Final output sent to browser
DEBUG - 2025-05-25 14:08:45 --> Total execution time: 0.0731
INFO - 2025-05-25 14:11:04 --> Config Class Initialized
INFO - 2025-05-25 14:11:04 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:11:04 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:11:04 --> Utf8 Class Initialized
INFO - 2025-05-25 14:11:04 --> URI Class Initialized
INFO - 2025-05-25 14:11:04 --> Router Class Initialized
INFO - 2025-05-25 14:11:04 --> Output Class Initialized
INFO - 2025-05-25 14:11:04 --> Security Class Initialized
DEBUG - 2025-05-25 14:11:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:11:04 --> Input Class Initialized
INFO - 2025-05-25 14:11:04 --> Language Class Initialized
INFO - 2025-05-25 14:11:04 --> Loader Class Initialized
INFO - 2025-05-25 14:11:04 --> Helper loaded: url_helper
INFO - 2025-05-25 14:11:04 --> Helper loaded: form_helper
INFO - 2025-05-25 14:11:04 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:11:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:11:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:11:04 --> Controller Class Initialized
INFO - 2025-05-25 14:11:04 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:11:04 --> Model "User_model" initialized
INFO - 2025-05-25 14:11:04 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:11:04 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:11:04 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-05-25 14:11:04 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:11:04 --> Final output sent to browser
DEBUG - 2025-05-25 14:11:04 --> Total execution time: 0.0896
INFO - 2025-05-25 14:11:05 --> Config Class Initialized
INFO - 2025-05-25 14:11:05 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:11:05 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:11:05 --> Utf8 Class Initialized
INFO - 2025-05-25 14:11:05 --> URI Class Initialized
INFO - 2025-05-25 14:11:05 --> Router Class Initialized
INFO - 2025-05-25 14:11:05 --> Output Class Initialized
INFO - 2025-05-25 14:11:05 --> Security Class Initialized
DEBUG - 2025-05-25 14:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:11:05 --> Input Class Initialized
INFO - 2025-05-25 14:11:05 --> Language Class Initialized
INFO - 2025-05-25 14:11:05 --> Loader Class Initialized
INFO - 2025-05-25 14:11:05 --> Helper loaded: url_helper
INFO - 2025-05-25 14:11:05 --> Helper loaded: form_helper
INFO - 2025-05-25 14:11:05 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:11:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:11:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:11:05 --> Controller Class Initialized
INFO - 2025-05-25 14:11:05 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:11:05 --> Model "User_model" initialized
INFO - 2025-05-25 14:11:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:11:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:11:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-05-25 14:11:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:11:05 --> Final output sent to browser
DEBUG - 2025-05-25 14:11:05 --> Total execution time: 0.0589
INFO - 2025-05-25 14:11:07 --> Config Class Initialized
INFO - 2025-05-25 14:11:07 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:11:07 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:11:07 --> Utf8 Class Initialized
INFO - 2025-05-25 14:11:07 --> URI Class Initialized
INFO - 2025-05-25 14:11:07 --> Router Class Initialized
INFO - 2025-05-25 14:11:07 --> Output Class Initialized
INFO - 2025-05-25 14:11:07 --> Security Class Initialized
DEBUG - 2025-05-25 14:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:11:07 --> Input Class Initialized
INFO - 2025-05-25 14:11:07 --> Language Class Initialized
INFO - 2025-05-25 14:11:07 --> Loader Class Initialized
INFO - 2025-05-25 14:11:07 --> Helper loaded: url_helper
INFO - 2025-05-25 14:11:07 --> Helper loaded: form_helper
INFO - 2025-05-25 14:11:07 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:11:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:11:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:11:07 --> Controller Class Initialized
INFO - 2025-05-25 14:11:07 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:11:07 --> Model "User_model" initialized
INFO - 2025-05-25 14:11:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:11:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:11:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/menu.php
INFO - 2025-05-25 14:11:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:11:07 --> Final output sent to browser
DEBUG - 2025-05-25 14:11:07 --> Total execution time: 0.0773
INFO - 2025-05-25 14:11:10 --> Config Class Initialized
INFO - 2025-05-25 14:11:10 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:11:10 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:11:10 --> Utf8 Class Initialized
INFO - 2025-05-25 14:11:10 --> URI Class Initialized
INFO - 2025-05-25 14:11:10 --> Router Class Initialized
INFO - 2025-05-25 14:11:10 --> Output Class Initialized
INFO - 2025-05-25 14:11:10 --> Security Class Initialized
DEBUG - 2025-05-25 14:11:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:11:10 --> Input Class Initialized
INFO - 2025-05-25 14:11:10 --> Language Class Initialized
INFO - 2025-05-25 14:11:10 --> Loader Class Initialized
INFO - 2025-05-25 14:11:10 --> Helper loaded: url_helper
INFO - 2025-05-25 14:11:10 --> Helper loaded: form_helper
INFO - 2025-05-25 14:11:10 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:11:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:11:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:11:10 --> Controller Class Initialized
INFO - 2025-05-25 14:11:10 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:11:10 --> Model "User_model" initialized
INFO - 2025-05-25 14:11:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:11:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:11:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/start.php
INFO - 2025-05-25 14:11:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:11:10 --> Final output sent to browser
DEBUG - 2025-05-25 14:11:10 --> Total execution time: 0.0932
INFO - 2025-05-25 14:11:18 --> Config Class Initialized
INFO - 2025-05-25 14:11:18 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:11:18 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:11:18 --> Utf8 Class Initialized
INFO - 2025-05-25 14:11:18 --> URI Class Initialized
INFO - 2025-05-25 14:11:18 --> Router Class Initialized
INFO - 2025-05-25 14:11:18 --> Output Class Initialized
INFO - 2025-05-25 14:11:18 --> Security Class Initialized
DEBUG - 2025-05-25 14:11:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:11:18 --> Input Class Initialized
INFO - 2025-05-25 14:11:18 --> Language Class Initialized
INFO - 2025-05-25 14:11:18 --> Loader Class Initialized
INFO - 2025-05-25 14:11:18 --> Helper loaded: url_helper
INFO - 2025-05-25 14:11:18 --> Helper loaded: form_helper
INFO - 2025-05-25 14:11:18 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:11:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:11:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:11:18 --> Controller Class Initialized
INFO - 2025-05-25 14:11:18 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:11:18 --> Model "User_model" initialized
INFO - 2025-05-25 14:11:18 --> Final output sent to browser
DEBUG - 2025-05-25 14:11:18 --> Total execution time: 0.0937
INFO - 2025-05-25 14:11:22 --> Config Class Initialized
INFO - 2025-05-25 14:11:22 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:11:22 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:11:22 --> Utf8 Class Initialized
INFO - 2025-05-25 14:11:22 --> URI Class Initialized
INFO - 2025-05-25 14:11:22 --> Router Class Initialized
INFO - 2025-05-25 14:11:22 --> Output Class Initialized
INFO - 2025-05-25 14:11:22 --> Security Class Initialized
DEBUG - 2025-05-25 14:11:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:11:22 --> Input Class Initialized
INFO - 2025-05-25 14:11:22 --> Language Class Initialized
INFO - 2025-05-25 14:11:22 --> Loader Class Initialized
INFO - 2025-05-25 14:11:22 --> Helper loaded: url_helper
INFO - 2025-05-25 14:11:22 --> Helper loaded: form_helper
INFO - 2025-05-25 14:11:22 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:11:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:11:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:11:22 --> Controller Class Initialized
INFO - 2025-05-25 14:11:22 --> Model "Progress_model" initialized
INFO - 2025-05-25 14:11:22 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:11:22 --> Model "User_model" initialized
INFO - 2025-05-25 14:11:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:11:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:11:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-25 14:11:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:11:22 --> Final output sent to browser
DEBUG - 2025-05-25 14:11:22 --> Total execution time: 0.0766
INFO - 2025-05-25 14:11:22 --> Config Class Initialized
INFO - 2025-05-25 14:11:22 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:11:22 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:11:22 --> Utf8 Class Initialized
INFO - 2025-05-25 14:11:22 --> URI Class Initialized
INFO - 2025-05-25 14:11:22 --> Router Class Initialized
INFO - 2025-05-25 14:11:22 --> Output Class Initialized
INFO - 2025-05-25 14:11:22 --> Security Class Initialized
DEBUG - 2025-05-25 14:11:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:11:22 --> Input Class Initialized
INFO - 2025-05-25 14:11:22 --> Language Class Initialized
INFO - 2025-05-25 14:11:22 --> Loader Class Initialized
INFO - 2025-05-25 14:11:22 --> Helper loaded: url_helper
INFO - 2025-05-25 14:11:22 --> Helper loaded: form_helper
INFO - 2025-05-25 14:11:22 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:11:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:11:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:11:22 --> Controller Class Initialized
INFO - 2025-05-25 14:11:22 --> Model "Progress_model" initialized
INFO - 2025-05-25 14:11:22 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:11:22 --> Model "User_model" initialized
INFO - 2025-05-25 14:11:22 --> Final output sent to browser
DEBUG - 2025-05-25 14:11:22 --> Total execution time: 0.0756
INFO - 2025-05-25 14:11:26 --> Config Class Initialized
INFO - 2025-05-25 14:11:26 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:11:26 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:11:26 --> Utf8 Class Initialized
INFO - 2025-05-25 14:11:26 --> URI Class Initialized
INFO - 2025-05-25 14:11:26 --> Router Class Initialized
INFO - 2025-05-25 14:11:26 --> Output Class Initialized
INFO - 2025-05-25 14:11:26 --> Security Class Initialized
DEBUG - 2025-05-25 14:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:11:26 --> Input Class Initialized
INFO - 2025-05-25 14:11:26 --> Language Class Initialized
INFO - 2025-05-25 14:11:26 --> Loader Class Initialized
INFO - 2025-05-25 14:11:26 --> Helper loaded: url_helper
INFO - 2025-05-25 14:11:26 --> Helper loaded: form_helper
INFO - 2025-05-25 14:11:26 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:11:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:11:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:11:26 --> Controller Class Initialized
INFO - 2025-05-25 14:11:26 --> Model "Progress_model" initialized
INFO - 2025-05-25 14:11:26 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:11:26 --> Model "User_model" initialized
INFO - 2025-05-25 14:11:26 --> Final output sent to browser
DEBUG - 2025-05-25 14:11:26 --> Total execution time: 0.0792
INFO - 2025-05-25 14:12:26 --> Config Class Initialized
INFO - 2025-05-25 14:12:26 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:12:26 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:12:26 --> Utf8 Class Initialized
INFO - 2025-05-25 14:12:26 --> URI Class Initialized
INFO - 2025-05-25 14:12:26 --> Router Class Initialized
INFO - 2025-05-25 14:12:26 --> Output Class Initialized
INFO - 2025-05-25 14:12:26 --> Security Class Initialized
DEBUG - 2025-05-25 14:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:12:26 --> Input Class Initialized
INFO - 2025-05-25 14:12:26 --> Language Class Initialized
INFO - 2025-05-25 14:12:26 --> Loader Class Initialized
INFO - 2025-05-25 14:12:26 --> Helper loaded: url_helper
INFO - 2025-05-25 14:12:26 --> Helper loaded: form_helper
INFO - 2025-05-25 14:12:26 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:12:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:12:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:12:26 --> Controller Class Initialized
INFO - 2025-05-25 14:12:26 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:12:26 --> Model "User_model" initialized
INFO - 2025-05-25 14:12:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:12:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:12:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-05-25 14:12:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:12:26 --> Final output sent to browser
DEBUG - 2025-05-25 14:12:26 --> Total execution time: 0.0830
INFO - 2025-05-25 14:12:27 --> Config Class Initialized
INFO - 2025-05-25 14:12:27 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:12:27 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:12:27 --> Utf8 Class Initialized
INFO - 2025-05-25 14:12:27 --> URI Class Initialized
INFO - 2025-05-25 14:12:27 --> Router Class Initialized
INFO - 2025-05-25 14:12:27 --> Output Class Initialized
INFO - 2025-05-25 14:12:27 --> Security Class Initialized
DEBUG - 2025-05-25 14:12:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:12:27 --> Input Class Initialized
INFO - 2025-05-25 14:12:27 --> Language Class Initialized
INFO - 2025-05-25 14:12:27 --> Loader Class Initialized
INFO - 2025-05-25 14:12:27 --> Helper loaded: url_helper
INFO - 2025-05-25 14:12:27 --> Helper loaded: form_helper
INFO - 2025-05-25 14:12:27 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:12:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:12:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:12:27 --> Controller Class Initialized
INFO - 2025-05-25 14:12:27 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:12:27 --> Model "User_model" initialized
INFO - 2025-05-25 14:12:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:12:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:12:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-05-25 14:12:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:12:27 --> Final output sent to browser
DEBUG - 2025-05-25 14:12:27 --> Total execution time: 0.0835
INFO - 2025-05-25 14:12:28 --> Config Class Initialized
INFO - 2025-05-25 14:12:28 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:12:28 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:12:28 --> Utf8 Class Initialized
INFO - 2025-05-25 14:12:28 --> URI Class Initialized
INFO - 2025-05-25 14:12:28 --> Router Class Initialized
INFO - 2025-05-25 14:12:28 --> Output Class Initialized
INFO - 2025-05-25 14:12:28 --> Security Class Initialized
DEBUG - 2025-05-25 14:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:12:28 --> Input Class Initialized
INFO - 2025-05-25 14:12:28 --> Language Class Initialized
INFO - 2025-05-25 14:12:28 --> Loader Class Initialized
INFO - 2025-05-25 14:12:28 --> Helper loaded: url_helper
INFO - 2025-05-25 14:12:28 --> Helper loaded: form_helper
INFO - 2025-05-25 14:12:28 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:12:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:12:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:12:28 --> Controller Class Initialized
INFO - 2025-05-25 14:12:28 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:12:28 --> Model "User_model" initialized
INFO - 2025-05-25 14:12:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:12:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:12:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/menu.php
INFO - 2025-05-25 14:12:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:12:28 --> Final output sent to browser
DEBUG - 2025-05-25 14:12:28 --> Total execution time: 0.0565
INFO - 2025-05-25 14:12:31 --> Config Class Initialized
INFO - 2025-05-25 14:12:31 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:12:31 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:12:31 --> Utf8 Class Initialized
INFO - 2025-05-25 14:12:31 --> URI Class Initialized
INFO - 2025-05-25 14:12:31 --> Router Class Initialized
INFO - 2025-05-25 14:12:31 --> Output Class Initialized
INFO - 2025-05-25 14:12:31 --> Security Class Initialized
DEBUG - 2025-05-25 14:12:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:12:31 --> Input Class Initialized
INFO - 2025-05-25 14:12:31 --> Language Class Initialized
INFO - 2025-05-25 14:12:31 --> Loader Class Initialized
INFO - 2025-05-25 14:12:31 --> Helper loaded: url_helper
INFO - 2025-05-25 14:12:31 --> Helper loaded: form_helper
INFO - 2025-05-25 14:12:31 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:12:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:12:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:12:31 --> Controller Class Initialized
INFO - 2025-05-25 14:12:31 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:12:31 --> Model "User_model" initialized
INFO - 2025-05-25 14:12:31 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:12:31 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:12:31 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/start.php
INFO - 2025-05-25 14:12:31 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:12:31 --> Final output sent to browser
DEBUG - 2025-05-25 14:12:31 --> Total execution time: 0.0642
INFO - 2025-05-25 14:13:39 --> Config Class Initialized
INFO - 2025-05-25 14:13:39 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:13:39 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:13:39 --> Utf8 Class Initialized
INFO - 2025-05-25 14:13:39 --> URI Class Initialized
INFO - 2025-05-25 14:13:39 --> Router Class Initialized
INFO - 2025-05-25 14:13:39 --> Output Class Initialized
INFO - 2025-05-25 14:13:39 --> Security Class Initialized
DEBUG - 2025-05-25 14:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:13:39 --> Input Class Initialized
INFO - 2025-05-25 14:13:39 --> Language Class Initialized
INFO - 2025-05-25 14:13:39 --> Loader Class Initialized
INFO - 2025-05-25 14:13:39 --> Helper loaded: url_helper
INFO - 2025-05-25 14:13:39 --> Helper loaded: form_helper
INFO - 2025-05-25 14:13:39 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:13:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:13:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:13:39 --> Controller Class Initialized
INFO - 2025-05-25 14:13:39 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:13:39 --> Model "User_model" initialized
INFO - 2025-05-25 14:13:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:13:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:13:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/start.php
INFO - 2025-05-25 14:13:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:13:39 --> Final output sent to browser
DEBUG - 2025-05-25 14:13:39 --> Total execution time: 0.0595
INFO - 2025-05-25 14:13:58 --> Config Class Initialized
INFO - 2025-05-25 14:13:58 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:13:58 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:13:58 --> Utf8 Class Initialized
INFO - 2025-05-25 14:13:58 --> URI Class Initialized
INFO - 2025-05-25 14:13:58 --> Router Class Initialized
INFO - 2025-05-25 14:13:58 --> Output Class Initialized
INFO - 2025-05-25 14:13:58 --> Security Class Initialized
DEBUG - 2025-05-25 14:13:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:13:58 --> Input Class Initialized
INFO - 2025-05-25 14:13:58 --> Language Class Initialized
INFO - 2025-05-25 14:13:58 --> Loader Class Initialized
INFO - 2025-05-25 14:13:58 --> Helper loaded: url_helper
INFO - 2025-05-25 14:13:58 --> Helper loaded: form_helper
INFO - 2025-05-25 14:13:58 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:13:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:13:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:13:58 --> Controller Class Initialized
INFO - 2025-05-25 14:13:58 --> Model "Progress_model" initialized
INFO - 2025-05-25 14:13:58 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:13:58 --> Model "User_model" initialized
INFO - 2025-05-25 14:13:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:13:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:13:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-25 14:13:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:13:58 --> Final output sent to browser
DEBUG - 2025-05-25 14:13:58 --> Total execution time: 0.0624
INFO - 2025-05-25 14:13:58 --> Config Class Initialized
INFO - 2025-05-25 14:13:58 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:13:58 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:13:58 --> Utf8 Class Initialized
INFO - 2025-05-25 14:13:58 --> URI Class Initialized
INFO - 2025-05-25 14:13:58 --> Router Class Initialized
INFO - 2025-05-25 14:13:58 --> Output Class Initialized
INFO - 2025-05-25 14:13:58 --> Security Class Initialized
DEBUG - 2025-05-25 14:13:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:13:58 --> Input Class Initialized
INFO - 2025-05-25 14:13:58 --> Language Class Initialized
INFO - 2025-05-25 14:13:58 --> Loader Class Initialized
INFO - 2025-05-25 14:13:58 --> Helper loaded: url_helper
INFO - 2025-05-25 14:13:58 --> Helper loaded: form_helper
INFO - 2025-05-25 14:13:58 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:13:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:13:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:13:58 --> Controller Class Initialized
INFO - 2025-05-25 14:13:58 --> Model "Progress_model" initialized
INFO - 2025-05-25 14:13:58 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:13:58 --> Model "User_model" initialized
INFO - 2025-05-25 14:13:58 --> Final output sent to browser
DEBUG - 2025-05-25 14:13:58 --> Total execution time: 0.0811
INFO - 2025-05-25 14:13:59 --> Config Class Initialized
INFO - 2025-05-25 14:13:59 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:13:59 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:13:59 --> Utf8 Class Initialized
INFO - 2025-05-25 14:13:59 --> URI Class Initialized
INFO - 2025-05-25 14:13:59 --> Router Class Initialized
INFO - 2025-05-25 14:13:59 --> Output Class Initialized
INFO - 2025-05-25 14:13:59 --> Security Class Initialized
DEBUG - 2025-05-25 14:13:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:13:59 --> Input Class Initialized
INFO - 2025-05-25 14:13:59 --> Language Class Initialized
INFO - 2025-05-25 14:13:59 --> Loader Class Initialized
INFO - 2025-05-25 14:13:59 --> Helper loaded: url_helper
INFO - 2025-05-25 14:13:59 --> Helper loaded: form_helper
INFO - 2025-05-25 14:13:59 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:13:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:13:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:13:59 --> Controller Class Initialized
INFO - 2025-05-25 14:13:59 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:13:59 --> Model "User_model" initialized
INFO - 2025-05-25 14:13:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:13:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:13:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-05-25 14:13:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:13:59 --> Final output sent to browser
DEBUG - 2025-05-25 14:13:59 --> Total execution time: 0.0558
INFO - 2025-05-25 14:14:00 --> Config Class Initialized
INFO - 2025-05-25 14:14:00 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:14:00 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:14:00 --> Utf8 Class Initialized
INFO - 2025-05-25 14:14:00 --> URI Class Initialized
INFO - 2025-05-25 14:14:00 --> Router Class Initialized
INFO - 2025-05-25 14:14:00 --> Output Class Initialized
INFO - 2025-05-25 14:14:00 --> Security Class Initialized
DEBUG - 2025-05-25 14:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:14:00 --> Input Class Initialized
INFO - 2025-05-25 14:14:00 --> Language Class Initialized
INFO - 2025-05-25 14:14:00 --> Loader Class Initialized
INFO - 2025-05-25 14:14:00 --> Helper loaded: url_helper
INFO - 2025-05-25 14:14:00 --> Helper loaded: form_helper
INFO - 2025-05-25 14:14:00 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:14:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:14:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:14:00 --> Controller Class Initialized
INFO - 2025-05-25 14:14:00 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:14:00 --> Model "User_model" initialized
INFO - 2025-05-25 14:14:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:14:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:14:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-05-25 14:14:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:14:00 --> Final output sent to browser
DEBUG - 2025-05-25 14:14:00 --> Total execution time: 0.0617
INFO - 2025-05-25 14:14:01 --> Config Class Initialized
INFO - 2025-05-25 14:14:01 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:14:01 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:14:01 --> Utf8 Class Initialized
INFO - 2025-05-25 14:14:01 --> URI Class Initialized
INFO - 2025-05-25 14:14:01 --> Router Class Initialized
INFO - 2025-05-25 14:14:01 --> Output Class Initialized
INFO - 2025-05-25 14:14:01 --> Security Class Initialized
DEBUG - 2025-05-25 14:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:14:01 --> Input Class Initialized
INFO - 2025-05-25 14:14:01 --> Language Class Initialized
INFO - 2025-05-25 14:14:01 --> Loader Class Initialized
INFO - 2025-05-25 14:14:01 --> Helper loaded: url_helper
INFO - 2025-05-25 14:14:01 --> Helper loaded: form_helper
INFO - 2025-05-25 14:14:01 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:14:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:14:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:14:01 --> Controller Class Initialized
INFO - 2025-05-25 14:14:01 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:14:01 --> Model "User_model" initialized
INFO - 2025-05-25 14:14:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:14:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:14:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/menu.php
INFO - 2025-05-25 14:14:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:14:01 --> Final output sent to browser
DEBUG - 2025-05-25 14:14:01 --> Total execution time: 0.0526
INFO - 2025-05-25 14:14:02 --> Config Class Initialized
INFO - 2025-05-25 14:14:02 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:14:02 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:14:02 --> Utf8 Class Initialized
INFO - 2025-05-25 14:14:02 --> URI Class Initialized
INFO - 2025-05-25 14:14:02 --> Router Class Initialized
INFO - 2025-05-25 14:14:02 --> Output Class Initialized
INFO - 2025-05-25 14:14:02 --> Security Class Initialized
DEBUG - 2025-05-25 14:14:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:14:02 --> Input Class Initialized
INFO - 2025-05-25 14:14:02 --> Language Class Initialized
INFO - 2025-05-25 14:14:02 --> Loader Class Initialized
INFO - 2025-05-25 14:14:02 --> Helper loaded: url_helper
INFO - 2025-05-25 14:14:02 --> Helper loaded: form_helper
INFO - 2025-05-25 14:14:02 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:14:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:14:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:14:02 --> Controller Class Initialized
INFO - 2025-05-25 14:14:02 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:14:02 --> Model "User_model" initialized
INFO - 2025-05-25 14:14:02 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:14:02 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:14:02 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/start.php
INFO - 2025-05-25 14:14:02 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:14:02 --> Final output sent to browser
DEBUG - 2025-05-25 14:14:02 --> Total execution time: 0.0626
INFO - 2025-05-25 14:14:49 --> Config Class Initialized
INFO - 2025-05-25 14:14:49 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:14:49 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:14:49 --> Utf8 Class Initialized
INFO - 2025-05-25 14:14:49 --> URI Class Initialized
INFO - 2025-05-25 14:14:49 --> Router Class Initialized
INFO - 2025-05-25 14:14:49 --> Output Class Initialized
INFO - 2025-05-25 14:14:49 --> Security Class Initialized
DEBUG - 2025-05-25 14:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:14:49 --> Input Class Initialized
INFO - 2025-05-25 14:14:49 --> Language Class Initialized
INFO - 2025-05-25 14:14:49 --> Loader Class Initialized
INFO - 2025-05-25 14:14:49 --> Helper loaded: url_helper
INFO - 2025-05-25 14:14:49 --> Helper loaded: form_helper
INFO - 2025-05-25 14:14:49 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:14:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:14:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:14:49 --> Controller Class Initialized
INFO - 2025-05-25 14:14:49 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:14:49 --> Model "User_model" initialized
INFO - 2025-05-25 14:14:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:14:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:14:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/start.php
INFO - 2025-05-25 14:14:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:14:49 --> Final output sent to browser
DEBUG - 2025-05-25 14:14:49 --> Total execution time: 0.0642
INFO - 2025-05-25 14:15:49 --> Config Class Initialized
INFO - 2025-05-25 14:15:49 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:15:49 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:15:49 --> Utf8 Class Initialized
INFO - 2025-05-25 14:15:49 --> URI Class Initialized
INFO - 2025-05-25 14:15:49 --> Router Class Initialized
INFO - 2025-05-25 14:15:49 --> Output Class Initialized
INFO - 2025-05-25 14:15:49 --> Security Class Initialized
DEBUG - 2025-05-25 14:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:15:49 --> Input Class Initialized
INFO - 2025-05-25 14:15:49 --> Language Class Initialized
INFO - 2025-05-25 14:15:49 --> Loader Class Initialized
INFO - 2025-05-25 14:15:49 --> Helper loaded: url_helper
INFO - 2025-05-25 14:15:49 --> Helper loaded: form_helper
INFO - 2025-05-25 14:15:49 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:15:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:15:49 --> Controller Class Initialized
INFO - 2025-05-25 14:15:49 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:15:49 --> Model "User_model" initialized
INFO - 2025-05-25 14:15:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:15:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:15:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/start.php
INFO - 2025-05-25 14:15:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:15:49 --> Final output sent to browser
DEBUG - 2025-05-25 14:15:49 --> Total execution time: 0.0672
INFO - 2025-05-25 14:16:39 --> Config Class Initialized
INFO - 2025-05-25 14:16:39 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:16:39 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:16:39 --> Utf8 Class Initialized
INFO - 2025-05-25 14:16:39 --> URI Class Initialized
INFO - 2025-05-25 14:16:39 --> Router Class Initialized
INFO - 2025-05-25 14:16:39 --> Output Class Initialized
INFO - 2025-05-25 14:16:39 --> Security Class Initialized
DEBUG - 2025-05-25 14:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:16:39 --> Input Class Initialized
INFO - 2025-05-25 14:16:39 --> Language Class Initialized
INFO - 2025-05-25 14:16:39 --> Loader Class Initialized
INFO - 2025-05-25 14:16:39 --> Helper loaded: url_helper
INFO - 2025-05-25 14:16:39 --> Helper loaded: form_helper
INFO - 2025-05-25 14:16:39 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:16:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:16:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:16:39 --> Controller Class Initialized
INFO - 2025-05-25 14:16:39 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:16:39 --> Model "User_model" initialized
INFO - 2025-05-25 14:16:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:16:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:16:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/start.php
INFO - 2025-05-25 14:16:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:16:39 --> Final output sent to browser
DEBUG - 2025-05-25 14:16:39 --> Total execution time: 0.0667
INFO - 2025-05-25 14:16:45 --> Config Class Initialized
INFO - 2025-05-25 14:16:45 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:16:45 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:16:45 --> Utf8 Class Initialized
INFO - 2025-05-25 14:16:45 --> URI Class Initialized
INFO - 2025-05-25 14:16:45 --> Router Class Initialized
INFO - 2025-05-25 14:16:45 --> Output Class Initialized
INFO - 2025-05-25 14:16:45 --> Security Class Initialized
DEBUG - 2025-05-25 14:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:16:45 --> Input Class Initialized
INFO - 2025-05-25 14:16:45 --> Language Class Initialized
INFO - 2025-05-25 14:16:45 --> Loader Class Initialized
INFO - 2025-05-25 14:16:45 --> Helper loaded: url_helper
INFO - 2025-05-25 14:16:45 --> Helper loaded: form_helper
INFO - 2025-05-25 14:16:45 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:16:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:16:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:16:45 --> Controller Class Initialized
INFO - 2025-05-25 14:16:45 --> Model "Progress_model" initialized
INFO - 2025-05-25 14:16:45 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:16:45 --> Model "User_model" initialized
INFO - 2025-05-25 14:16:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:16:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:16:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-25 14:16:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:16:45 --> Final output sent to browser
DEBUG - 2025-05-25 14:16:45 --> Total execution time: 0.0802
INFO - 2025-05-25 14:16:46 --> Config Class Initialized
INFO - 2025-05-25 14:16:46 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:16:46 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:16:46 --> Utf8 Class Initialized
INFO - 2025-05-25 14:16:46 --> URI Class Initialized
INFO - 2025-05-25 14:16:46 --> Router Class Initialized
INFO - 2025-05-25 14:16:46 --> Output Class Initialized
INFO - 2025-05-25 14:16:46 --> Security Class Initialized
DEBUG - 2025-05-25 14:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:16:46 --> Input Class Initialized
INFO - 2025-05-25 14:16:46 --> Language Class Initialized
INFO - 2025-05-25 14:16:46 --> Loader Class Initialized
INFO - 2025-05-25 14:16:46 --> Helper loaded: url_helper
INFO - 2025-05-25 14:16:46 --> Helper loaded: form_helper
INFO - 2025-05-25 14:16:46 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:16:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:16:46 --> Controller Class Initialized
INFO - 2025-05-25 14:16:46 --> Model "Progress_model" initialized
INFO - 2025-05-25 14:16:46 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:16:46 --> Model "User_model" initialized
INFO - 2025-05-25 14:16:46 --> Final output sent to browser
DEBUG - 2025-05-25 14:16:46 --> Total execution time: 0.0724
INFO - 2025-05-25 14:16:46 --> Config Class Initialized
INFO - 2025-05-25 14:16:46 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:16:46 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:16:46 --> Utf8 Class Initialized
INFO - 2025-05-25 14:16:46 --> URI Class Initialized
INFO - 2025-05-25 14:16:46 --> Router Class Initialized
INFO - 2025-05-25 14:16:46 --> Output Class Initialized
INFO - 2025-05-25 14:16:46 --> Security Class Initialized
DEBUG - 2025-05-25 14:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:16:46 --> Input Class Initialized
INFO - 2025-05-25 14:16:46 --> Language Class Initialized
INFO - 2025-05-25 14:16:46 --> Loader Class Initialized
INFO - 2025-05-25 14:16:46 --> Helper loaded: url_helper
INFO - 2025-05-25 14:16:46 --> Helper loaded: form_helper
INFO - 2025-05-25 14:16:46 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:16:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:16:46 --> Controller Class Initialized
INFO - 2025-05-25 14:16:46 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:16:46 --> Model "User_model" initialized
INFO - 2025-05-25 14:16:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:16:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:16:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-05-25 14:16:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:16:46 --> Final output sent to browser
DEBUG - 2025-05-25 14:16:46 --> Total execution time: 0.0641
INFO - 2025-05-25 14:16:48 --> Config Class Initialized
INFO - 2025-05-25 14:16:48 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:16:48 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:16:48 --> Utf8 Class Initialized
INFO - 2025-05-25 14:16:48 --> URI Class Initialized
INFO - 2025-05-25 14:16:48 --> Router Class Initialized
INFO - 2025-05-25 14:16:48 --> Output Class Initialized
INFO - 2025-05-25 14:16:48 --> Security Class Initialized
DEBUG - 2025-05-25 14:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:16:48 --> Input Class Initialized
INFO - 2025-05-25 14:16:48 --> Language Class Initialized
INFO - 2025-05-25 14:16:48 --> Loader Class Initialized
INFO - 2025-05-25 14:16:48 --> Helper loaded: url_helper
INFO - 2025-05-25 14:16:48 --> Helper loaded: form_helper
INFO - 2025-05-25 14:16:48 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:16:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:16:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:16:48 --> Controller Class Initialized
INFO - 2025-05-25 14:16:48 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:16:48 --> Model "User_model" initialized
INFO - 2025-05-25 14:16:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:16:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:16:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-05-25 14:16:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:16:48 --> Final output sent to browser
DEBUG - 2025-05-25 14:16:48 --> Total execution time: 0.0746
INFO - 2025-05-25 14:16:49 --> Config Class Initialized
INFO - 2025-05-25 14:16:49 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:16:49 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:16:49 --> Utf8 Class Initialized
INFO - 2025-05-25 14:16:49 --> URI Class Initialized
INFO - 2025-05-25 14:16:49 --> Router Class Initialized
INFO - 2025-05-25 14:16:49 --> Output Class Initialized
INFO - 2025-05-25 14:16:49 --> Security Class Initialized
DEBUG - 2025-05-25 14:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:16:49 --> Input Class Initialized
INFO - 2025-05-25 14:16:49 --> Language Class Initialized
INFO - 2025-05-25 14:16:49 --> Loader Class Initialized
INFO - 2025-05-25 14:16:49 --> Helper loaded: url_helper
INFO - 2025-05-25 14:16:49 --> Helper loaded: form_helper
INFO - 2025-05-25 14:16:49 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:16:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:16:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:16:49 --> Controller Class Initialized
INFO - 2025-05-25 14:16:49 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:16:49 --> Model "User_model" initialized
INFO - 2025-05-25 14:16:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:16:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:16:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/menu.php
INFO - 2025-05-25 14:16:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:16:49 --> Final output sent to browser
DEBUG - 2025-05-25 14:16:49 --> Total execution time: 0.0742
INFO - 2025-05-25 14:16:51 --> Config Class Initialized
INFO - 2025-05-25 14:16:51 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:16:51 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:16:51 --> Utf8 Class Initialized
INFO - 2025-05-25 14:16:51 --> URI Class Initialized
INFO - 2025-05-25 14:16:51 --> Router Class Initialized
INFO - 2025-05-25 14:16:51 --> Output Class Initialized
INFO - 2025-05-25 14:16:51 --> Security Class Initialized
DEBUG - 2025-05-25 14:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:16:51 --> Input Class Initialized
INFO - 2025-05-25 14:16:51 --> Language Class Initialized
INFO - 2025-05-25 14:16:51 --> Loader Class Initialized
INFO - 2025-05-25 14:16:51 --> Helper loaded: url_helper
INFO - 2025-05-25 14:16:51 --> Helper loaded: form_helper
INFO - 2025-05-25 14:16:51 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:16:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:16:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:16:51 --> Controller Class Initialized
INFO - 2025-05-25 14:16:51 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:16:51 --> Model "User_model" initialized
INFO - 2025-05-25 14:16:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:16:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:16:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/start.php
INFO - 2025-05-25 14:16:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:16:51 --> Final output sent to browser
DEBUG - 2025-05-25 14:16:51 --> Total execution time: 0.0803
INFO - 2025-05-25 14:18:25 --> Config Class Initialized
INFO - 2025-05-25 14:18:25 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:18:25 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:18:25 --> Utf8 Class Initialized
INFO - 2025-05-25 14:18:25 --> URI Class Initialized
INFO - 2025-05-25 14:18:25 --> Router Class Initialized
INFO - 2025-05-25 14:18:25 --> Output Class Initialized
INFO - 2025-05-25 14:18:25 --> Security Class Initialized
DEBUG - 2025-05-25 14:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:18:25 --> Input Class Initialized
INFO - 2025-05-25 14:18:25 --> Language Class Initialized
INFO - 2025-05-25 14:18:25 --> Loader Class Initialized
INFO - 2025-05-25 14:18:25 --> Helper loaded: url_helper
INFO - 2025-05-25 14:18:25 --> Helper loaded: form_helper
INFO - 2025-05-25 14:18:25 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:18:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:18:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:18:25 --> Controller Class Initialized
INFO - 2025-05-25 14:18:25 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:18:25 --> Model "User_model" initialized
INFO - 2025-05-25 14:18:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:18:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:18:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/start.php
INFO - 2025-05-25 14:18:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:18:25 --> Final output sent to browser
DEBUG - 2025-05-25 14:18:25 --> Total execution time: 0.0854
INFO - 2025-05-25 14:18:42 --> Config Class Initialized
INFO - 2025-05-25 14:18:42 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:18:42 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:18:42 --> Utf8 Class Initialized
INFO - 2025-05-25 14:18:42 --> URI Class Initialized
INFO - 2025-05-25 14:18:42 --> Router Class Initialized
INFO - 2025-05-25 14:18:42 --> Output Class Initialized
INFO - 2025-05-25 14:18:42 --> Security Class Initialized
DEBUG - 2025-05-25 14:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:18:42 --> Input Class Initialized
INFO - 2025-05-25 14:18:42 --> Language Class Initialized
INFO - 2025-05-25 14:18:42 --> Loader Class Initialized
INFO - 2025-05-25 14:18:42 --> Helper loaded: url_helper
INFO - 2025-05-25 14:18:42 --> Helper loaded: form_helper
INFO - 2025-05-25 14:18:42 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:18:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:18:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:18:42 --> Controller Class Initialized
INFO - 2025-05-25 14:18:42 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:18:42 --> Model "User_model" initialized
INFO - 2025-05-25 14:18:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:18:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:18:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/start.php
INFO - 2025-05-25 14:18:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:18:42 --> Final output sent to browser
DEBUG - 2025-05-25 14:18:42 --> Total execution time: 0.1007
INFO - 2025-05-25 14:19:55 --> Config Class Initialized
INFO - 2025-05-25 14:19:55 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:19:55 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:19:55 --> Utf8 Class Initialized
INFO - 2025-05-25 14:19:55 --> URI Class Initialized
INFO - 2025-05-25 14:19:55 --> Router Class Initialized
INFO - 2025-05-25 14:19:55 --> Output Class Initialized
INFO - 2025-05-25 14:19:55 --> Security Class Initialized
DEBUG - 2025-05-25 14:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:19:55 --> Input Class Initialized
INFO - 2025-05-25 14:19:55 --> Language Class Initialized
INFO - 2025-05-25 14:19:55 --> Loader Class Initialized
INFO - 2025-05-25 14:19:55 --> Helper loaded: url_helper
INFO - 2025-05-25 14:19:55 --> Helper loaded: form_helper
INFO - 2025-05-25 14:19:55 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:19:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:19:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:19:55 --> Controller Class Initialized
INFO - 2025-05-25 14:19:55 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:19:55 --> Model "User_model" initialized
INFO - 2025-05-25 14:19:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:19:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:19:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/start.php
INFO - 2025-05-25 14:19:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:19:55 --> Final output sent to browser
DEBUG - 2025-05-25 14:19:55 --> Total execution time: 0.0695
INFO - 2025-05-25 14:20:20 --> Config Class Initialized
INFO - 2025-05-25 14:20:20 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:20:20 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:20:20 --> Utf8 Class Initialized
INFO - 2025-05-25 14:20:20 --> URI Class Initialized
INFO - 2025-05-25 14:20:20 --> Router Class Initialized
INFO - 2025-05-25 14:20:20 --> Output Class Initialized
INFO - 2025-05-25 14:20:20 --> Security Class Initialized
DEBUG - 2025-05-25 14:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:20:20 --> Input Class Initialized
INFO - 2025-05-25 14:20:20 --> Language Class Initialized
INFO - 2025-05-25 14:20:20 --> Loader Class Initialized
INFO - 2025-05-25 14:20:20 --> Helper loaded: url_helper
INFO - 2025-05-25 14:20:20 --> Helper loaded: form_helper
INFO - 2025-05-25 14:20:20 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:20:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:20:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:20:20 --> Controller Class Initialized
INFO - 2025-05-25 14:20:20 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:20:20 --> Model "User_model" initialized
INFO - 2025-05-25 14:20:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:20:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:20:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/start.php
INFO - 2025-05-25 14:20:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:20:20 --> Final output sent to browser
DEBUG - 2025-05-25 14:20:20 --> Total execution time: 0.0717
INFO - 2025-05-25 14:20:41 --> Config Class Initialized
INFO - 2025-05-25 14:20:41 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:20:41 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:20:41 --> Utf8 Class Initialized
INFO - 2025-05-25 14:20:41 --> URI Class Initialized
INFO - 2025-05-25 14:20:41 --> Router Class Initialized
INFO - 2025-05-25 14:20:41 --> Output Class Initialized
INFO - 2025-05-25 14:20:41 --> Security Class Initialized
DEBUG - 2025-05-25 14:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:20:41 --> Input Class Initialized
INFO - 2025-05-25 14:20:41 --> Language Class Initialized
INFO - 2025-05-25 14:20:41 --> Loader Class Initialized
INFO - 2025-05-25 14:20:41 --> Helper loaded: url_helper
INFO - 2025-05-25 14:20:41 --> Helper loaded: form_helper
INFO - 2025-05-25 14:20:41 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:20:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:20:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:20:41 --> Controller Class Initialized
INFO - 2025-05-25 14:20:41 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:20:41 --> Model "User_model" initialized
INFO - 2025-05-25 14:20:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:20:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:20:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/start.php
INFO - 2025-05-25 14:20:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:20:41 --> Final output sent to browser
DEBUG - 2025-05-25 14:20:41 --> Total execution time: 0.0829
INFO - 2025-05-25 14:20:57 --> Config Class Initialized
INFO - 2025-05-25 14:20:57 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:20:57 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:20:57 --> Utf8 Class Initialized
INFO - 2025-05-25 14:20:57 --> URI Class Initialized
INFO - 2025-05-25 14:20:57 --> Router Class Initialized
INFO - 2025-05-25 14:20:57 --> Output Class Initialized
INFO - 2025-05-25 14:20:57 --> Security Class Initialized
DEBUG - 2025-05-25 14:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:20:57 --> Input Class Initialized
INFO - 2025-05-25 14:20:57 --> Language Class Initialized
INFO - 2025-05-25 14:20:57 --> Loader Class Initialized
INFO - 2025-05-25 14:20:57 --> Helper loaded: url_helper
INFO - 2025-05-25 14:20:57 --> Helper loaded: form_helper
INFO - 2025-05-25 14:20:57 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:20:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:20:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:20:57 --> Controller Class Initialized
INFO - 2025-05-25 14:20:57 --> Model "Progress_model" initialized
INFO - 2025-05-25 14:20:57 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:20:57 --> Model "User_model" initialized
INFO - 2025-05-25 14:20:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:20:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:20:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-25 14:20:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:20:57 --> Final output sent to browser
DEBUG - 2025-05-25 14:20:57 --> Total execution time: 0.0802
INFO - 2025-05-25 14:20:57 --> Config Class Initialized
INFO - 2025-05-25 14:20:57 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:20:57 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:20:57 --> Utf8 Class Initialized
INFO - 2025-05-25 14:20:57 --> URI Class Initialized
INFO - 2025-05-25 14:20:57 --> Router Class Initialized
INFO - 2025-05-25 14:20:57 --> Output Class Initialized
INFO - 2025-05-25 14:20:57 --> Security Class Initialized
DEBUG - 2025-05-25 14:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:20:57 --> Input Class Initialized
INFO - 2025-05-25 14:20:57 --> Language Class Initialized
INFO - 2025-05-25 14:20:57 --> Loader Class Initialized
INFO - 2025-05-25 14:20:57 --> Helper loaded: url_helper
INFO - 2025-05-25 14:20:57 --> Helper loaded: form_helper
INFO - 2025-05-25 14:20:57 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:20:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:20:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:20:57 --> Controller Class Initialized
INFO - 2025-05-25 14:20:57 --> Model "Progress_model" initialized
INFO - 2025-05-25 14:20:57 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:20:57 --> Model "User_model" initialized
INFO - 2025-05-25 14:20:57 --> Final output sent to browser
DEBUG - 2025-05-25 14:20:57 --> Total execution time: 0.0863
INFO - 2025-05-25 14:21:02 --> Config Class Initialized
INFO - 2025-05-25 14:21:02 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:21:02 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:21:02 --> Utf8 Class Initialized
INFO - 2025-05-25 14:21:02 --> URI Class Initialized
INFO - 2025-05-25 14:21:02 --> Router Class Initialized
INFO - 2025-05-25 14:21:02 --> Output Class Initialized
INFO - 2025-05-25 14:21:02 --> Security Class Initialized
DEBUG - 2025-05-25 14:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:21:02 --> Input Class Initialized
INFO - 2025-05-25 14:21:02 --> Language Class Initialized
INFO - 2025-05-25 14:21:02 --> Loader Class Initialized
INFO - 2025-05-25 14:21:02 --> Helper loaded: url_helper
INFO - 2025-05-25 14:21:02 --> Helper loaded: form_helper
INFO - 2025-05-25 14:21:02 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:21:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:21:02 --> Controller Class Initialized
INFO - 2025-05-25 14:21:02 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:21:02 --> Model "User_model" initialized
INFO - 2025-05-25 14:21:02 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:21:02 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:21:02 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-05-25 14:21:02 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:21:02 --> Final output sent to browser
DEBUG - 2025-05-25 14:21:02 --> Total execution time: 0.0768
INFO - 2025-05-25 14:21:05 --> Config Class Initialized
INFO - 2025-05-25 14:21:05 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:21:05 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:21:05 --> Utf8 Class Initialized
INFO - 2025-05-25 14:21:05 --> URI Class Initialized
INFO - 2025-05-25 14:21:05 --> Router Class Initialized
INFO - 2025-05-25 14:21:05 --> Output Class Initialized
INFO - 2025-05-25 14:21:05 --> Security Class Initialized
DEBUG - 2025-05-25 14:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:21:05 --> Input Class Initialized
INFO - 2025-05-25 14:21:05 --> Language Class Initialized
INFO - 2025-05-25 14:21:05 --> Loader Class Initialized
INFO - 2025-05-25 14:21:05 --> Helper loaded: url_helper
INFO - 2025-05-25 14:21:05 --> Helper loaded: form_helper
INFO - 2025-05-25 14:21:05 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:21:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:21:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:21:05 --> Controller Class Initialized
INFO - 2025-05-25 14:21:05 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:21:05 --> Model "User_model" initialized
INFO - 2025-05-25 14:21:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:21:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:21:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-05-25 14:21:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:21:05 --> Final output sent to browser
DEBUG - 2025-05-25 14:21:05 --> Total execution time: 0.0811
INFO - 2025-05-25 14:21:24 --> Config Class Initialized
INFO - 2025-05-25 14:21:24 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:21:24 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:21:24 --> Utf8 Class Initialized
INFO - 2025-05-25 14:21:24 --> URI Class Initialized
INFO - 2025-05-25 14:21:24 --> Router Class Initialized
INFO - 2025-05-25 14:21:24 --> Output Class Initialized
INFO - 2025-05-25 14:21:24 --> Security Class Initialized
DEBUG - 2025-05-25 14:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:21:24 --> Input Class Initialized
INFO - 2025-05-25 14:21:24 --> Language Class Initialized
INFO - 2025-05-25 14:21:24 --> Loader Class Initialized
INFO - 2025-05-25 14:21:24 --> Helper loaded: url_helper
INFO - 2025-05-25 14:21:24 --> Helper loaded: form_helper
INFO - 2025-05-25 14:21:24 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:21:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:21:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:21:24 --> Controller Class Initialized
INFO - 2025-05-25 14:21:24 --> Model "Progress_model" initialized
INFO - 2025-05-25 14:21:24 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:21:24 --> Model "User_model" initialized
INFO - 2025-05-25 14:21:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:21:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:21:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-25 14:21:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:21:24 --> Final output sent to browser
DEBUG - 2025-05-25 14:21:24 --> Total execution time: 0.0775
INFO - 2025-05-25 14:21:24 --> Config Class Initialized
INFO - 2025-05-25 14:21:24 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:21:24 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:21:24 --> Utf8 Class Initialized
INFO - 2025-05-25 14:21:24 --> URI Class Initialized
INFO - 2025-05-25 14:21:24 --> Router Class Initialized
INFO - 2025-05-25 14:21:24 --> Output Class Initialized
INFO - 2025-05-25 14:21:24 --> Security Class Initialized
DEBUG - 2025-05-25 14:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:21:24 --> Input Class Initialized
INFO - 2025-05-25 14:21:24 --> Language Class Initialized
INFO - 2025-05-25 14:21:24 --> Loader Class Initialized
INFO - 2025-05-25 14:21:24 --> Helper loaded: url_helper
INFO - 2025-05-25 14:21:24 --> Helper loaded: form_helper
INFO - 2025-05-25 14:21:24 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:21:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:21:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:21:24 --> Controller Class Initialized
INFO - 2025-05-25 14:21:24 --> Model "Progress_model" initialized
INFO - 2025-05-25 14:21:24 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:21:24 --> Model "User_model" initialized
INFO - 2025-05-25 14:21:24 --> Final output sent to browser
DEBUG - 2025-05-25 14:21:24 --> Total execution time: 0.0753
INFO - 2025-05-25 14:21:27 --> Config Class Initialized
INFO - 2025-05-25 14:21:27 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:21:27 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:21:27 --> Utf8 Class Initialized
INFO - 2025-05-25 14:21:27 --> URI Class Initialized
INFO - 2025-05-25 14:21:27 --> Router Class Initialized
INFO - 2025-05-25 14:21:27 --> Output Class Initialized
INFO - 2025-05-25 14:21:27 --> Security Class Initialized
DEBUG - 2025-05-25 14:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:21:27 --> Input Class Initialized
INFO - 2025-05-25 14:21:27 --> Language Class Initialized
INFO - 2025-05-25 14:21:27 --> Loader Class Initialized
INFO - 2025-05-25 14:21:27 --> Helper loaded: url_helper
INFO - 2025-05-25 14:21:27 --> Helper loaded: form_helper
INFO - 2025-05-25 14:21:27 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:21:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:21:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:21:27 --> Controller Class Initialized
INFO - 2025-05-25 14:21:27 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:21:27 --> Model "User_model" initialized
INFO - 2025-05-25 14:21:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:21:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:21:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-05-25 14:21:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:21:27 --> Final output sent to browser
DEBUG - 2025-05-25 14:21:27 --> Total execution time: 0.0868
INFO - 2025-05-25 14:21:30 --> Config Class Initialized
INFO - 2025-05-25 14:21:30 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:21:30 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:21:30 --> Utf8 Class Initialized
INFO - 2025-05-25 14:21:30 --> URI Class Initialized
INFO - 2025-05-25 14:21:30 --> Router Class Initialized
INFO - 2025-05-25 14:21:30 --> Output Class Initialized
INFO - 2025-05-25 14:21:30 --> Security Class Initialized
DEBUG - 2025-05-25 14:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:21:30 --> Input Class Initialized
INFO - 2025-05-25 14:21:30 --> Language Class Initialized
INFO - 2025-05-25 14:21:30 --> Loader Class Initialized
INFO - 2025-05-25 14:21:30 --> Helper loaded: url_helper
INFO - 2025-05-25 14:21:30 --> Helper loaded: form_helper
INFO - 2025-05-25 14:21:30 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:21:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:21:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:21:31 --> Controller Class Initialized
INFO - 2025-05-25 14:21:31 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:21:31 --> Model "User_model" initialized
INFO - 2025-05-25 14:21:31 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:21:31 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:21:31 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-05-25 14:21:31 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:21:31 --> Final output sent to browser
DEBUG - 2025-05-25 14:21:31 --> Total execution time: 0.0798
INFO - 2025-05-25 14:21:35 --> Config Class Initialized
INFO - 2025-05-25 14:21:35 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:21:35 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:21:35 --> Utf8 Class Initialized
INFO - 2025-05-25 14:21:35 --> URI Class Initialized
INFO - 2025-05-25 14:21:35 --> Router Class Initialized
INFO - 2025-05-25 14:21:35 --> Output Class Initialized
INFO - 2025-05-25 14:21:35 --> Security Class Initialized
DEBUG - 2025-05-25 14:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:21:35 --> Input Class Initialized
INFO - 2025-05-25 14:21:35 --> Language Class Initialized
INFO - 2025-05-25 14:21:35 --> Loader Class Initialized
INFO - 2025-05-25 14:21:35 --> Helper loaded: url_helper
INFO - 2025-05-25 14:21:35 --> Helper loaded: form_helper
INFO - 2025-05-25 14:21:35 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:21:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:21:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:21:35 --> Controller Class Initialized
INFO - 2025-05-25 14:21:35 --> Model "User_model" initialized
INFO - 2025-05-25 14:21:35 --> Model "Progress_model" initialized
INFO - 2025-05-25 14:21:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:21:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:21:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-25 14:21:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:21:35 --> Final output sent to browser
DEBUG - 2025-05-25 14:21:35 --> Total execution time: 0.0704
INFO - 2025-05-25 14:31:11 --> Config Class Initialized
INFO - 2025-05-25 14:31:11 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:31:11 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:31:11 --> Utf8 Class Initialized
INFO - 2025-05-25 14:31:11 --> URI Class Initialized
INFO - 2025-05-25 14:31:11 --> Router Class Initialized
INFO - 2025-05-25 14:31:11 --> Output Class Initialized
INFO - 2025-05-25 14:31:11 --> Security Class Initialized
DEBUG - 2025-05-25 14:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:31:11 --> Input Class Initialized
INFO - 2025-05-25 14:31:11 --> Language Class Initialized
INFO - 2025-05-25 14:31:11 --> Loader Class Initialized
INFO - 2025-05-25 14:31:11 --> Helper loaded: url_helper
INFO - 2025-05-25 14:31:11 --> Helper loaded: form_helper
INFO - 2025-05-25 14:31:11 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:31:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:31:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:31:11 --> Controller Class Initialized
INFO - 2025-05-25 14:31:11 --> Model "User_model" initialized
INFO - 2025-05-25 14:31:11 --> Model "Progress_model" initialized
INFO - 2025-05-25 14:31:11 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:31:11 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:31:11 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-25 14:31:11 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:31:11 --> Final output sent to browser
DEBUG - 2025-05-25 14:31:11 --> Total execution time: 0.1066
INFO - 2025-05-25 14:31:49 --> Config Class Initialized
INFO - 2025-05-25 14:31:49 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:31:49 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:31:49 --> Utf8 Class Initialized
INFO - 2025-05-25 14:31:49 --> URI Class Initialized
INFO - 2025-05-25 14:31:49 --> Router Class Initialized
INFO - 2025-05-25 14:31:49 --> Output Class Initialized
INFO - 2025-05-25 14:31:49 --> Security Class Initialized
DEBUG - 2025-05-25 14:31:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:31:49 --> Input Class Initialized
INFO - 2025-05-25 14:31:49 --> Language Class Initialized
INFO - 2025-05-25 14:31:49 --> Loader Class Initialized
INFO - 2025-05-25 14:31:49 --> Helper loaded: url_helper
INFO - 2025-05-25 14:31:49 --> Helper loaded: form_helper
INFO - 2025-05-25 14:31:49 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:31:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:31:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:31:49 --> Controller Class Initialized
INFO - 2025-05-25 14:31:49 --> Model "User_model" initialized
INFO - 2025-05-25 14:31:49 --> Model "Progress_model" initialized
INFO - 2025-05-25 14:31:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:31:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:31:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-25 14:31:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:31:49 --> Final output sent to browser
DEBUG - 2025-05-25 14:31:49 --> Total execution time: 0.0839
INFO - 2025-05-25 14:32:26 --> Config Class Initialized
INFO - 2025-05-25 14:32:26 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:32:26 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:32:26 --> Utf8 Class Initialized
INFO - 2025-05-25 14:32:26 --> URI Class Initialized
INFO - 2025-05-25 14:32:26 --> Router Class Initialized
INFO - 2025-05-25 14:32:26 --> Output Class Initialized
INFO - 2025-05-25 14:32:26 --> Security Class Initialized
DEBUG - 2025-05-25 14:32:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:32:26 --> Input Class Initialized
INFO - 2025-05-25 14:32:26 --> Language Class Initialized
INFO - 2025-05-25 14:32:26 --> Loader Class Initialized
INFO - 2025-05-25 14:32:26 --> Helper loaded: url_helper
INFO - 2025-05-25 14:32:26 --> Helper loaded: form_helper
INFO - 2025-05-25 14:32:26 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:32:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:32:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:32:26 --> Controller Class Initialized
INFO - 2025-05-25 14:32:26 --> Model "User_model" initialized
INFO - 2025-05-25 14:32:26 --> Model "Progress_model" initialized
INFO - 2025-05-25 14:32:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:32:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:32:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-25 14:32:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:32:26 --> Final output sent to browser
DEBUG - 2025-05-25 14:32:26 --> Total execution time: 0.0882
INFO - 2025-05-25 14:35:18 --> Config Class Initialized
INFO - 2025-05-25 14:35:18 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:35:18 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:35:18 --> Utf8 Class Initialized
INFO - 2025-05-25 14:35:18 --> URI Class Initialized
INFO - 2025-05-25 14:35:18 --> Router Class Initialized
INFO - 2025-05-25 14:35:18 --> Output Class Initialized
INFO - 2025-05-25 14:35:18 --> Security Class Initialized
DEBUG - 2025-05-25 14:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:35:18 --> Input Class Initialized
INFO - 2025-05-25 14:35:18 --> Language Class Initialized
INFO - 2025-05-25 14:35:18 --> Loader Class Initialized
INFO - 2025-05-25 14:35:18 --> Helper loaded: url_helper
INFO - 2025-05-25 14:35:18 --> Helper loaded: form_helper
INFO - 2025-05-25 14:35:18 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:35:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:35:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:35:18 --> Controller Class Initialized
INFO - 2025-05-25 14:35:18 --> Model "User_model" initialized
INFO - 2025-05-25 14:35:18 --> Model "Progress_model" initialized
INFO - 2025-05-25 14:35:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:35:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:35:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-25 14:35:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:35:18 --> Final output sent to browser
DEBUG - 2025-05-25 14:35:18 --> Total execution time: 0.0885
INFO - 2025-05-25 14:36:01 --> Config Class Initialized
INFO - 2025-05-25 14:36:01 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:36:01 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:36:01 --> Utf8 Class Initialized
INFO - 2025-05-25 14:36:01 --> URI Class Initialized
INFO - 2025-05-25 14:36:01 --> Router Class Initialized
INFO - 2025-05-25 14:36:01 --> Output Class Initialized
INFO - 2025-05-25 14:36:01 --> Security Class Initialized
DEBUG - 2025-05-25 14:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:36:01 --> Input Class Initialized
INFO - 2025-05-25 14:36:01 --> Language Class Initialized
INFO - 2025-05-25 14:36:01 --> Loader Class Initialized
INFO - 2025-05-25 14:36:01 --> Helper loaded: url_helper
INFO - 2025-05-25 14:36:01 --> Helper loaded: form_helper
INFO - 2025-05-25 14:36:01 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:36:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:36:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:36:01 --> Controller Class Initialized
INFO - 2025-05-25 14:36:01 --> Model "User_model" initialized
INFO - 2025-05-25 14:36:01 --> Model "Progress_model" initialized
INFO - 2025-05-25 14:36:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:36:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:36:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-25 14:36:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:36:01 --> Final output sent to browser
DEBUG - 2025-05-25 14:36:01 --> Total execution time: 0.0812
INFO - 2025-05-25 14:36:06 --> Config Class Initialized
INFO - 2025-05-25 14:36:06 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:36:06 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:36:06 --> Utf8 Class Initialized
INFO - 2025-05-25 14:36:06 --> URI Class Initialized
INFO - 2025-05-25 14:36:06 --> Router Class Initialized
INFO - 2025-05-25 14:36:06 --> Output Class Initialized
INFO - 2025-05-25 14:36:06 --> Security Class Initialized
DEBUG - 2025-05-25 14:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:36:06 --> Input Class Initialized
INFO - 2025-05-25 14:36:06 --> Language Class Initialized
INFO - 2025-05-25 14:36:06 --> Loader Class Initialized
INFO - 2025-05-25 14:36:06 --> Helper loaded: url_helper
INFO - 2025-05-25 14:36:06 --> Helper loaded: form_helper
INFO - 2025-05-25 14:36:06 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:36:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:36:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:36:06 --> Controller Class Initialized
INFO - 2025-05-25 14:36:06 --> Model "User_model" initialized
INFO - 2025-05-25 14:36:06 --> Model "Progress_model" initialized
INFO - 2025-05-25 14:36:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:36:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:36:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-25 14:36:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:36:06 --> Final output sent to browser
DEBUG - 2025-05-25 14:36:06 --> Total execution time: 0.0613
INFO - 2025-05-25 14:38:32 --> Config Class Initialized
INFO - 2025-05-25 14:38:32 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:38:32 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:38:32 --> Utf8 Class Initialized
INFO - 2025-05-25 14:38:32 --> URI Class Initialized
INFO - 2025-05-25 14:38:32 --> Router Class Initialized
INFO - 2025-05-25 14:38:32 --> Output Class Initialized
INFO - 2025-05-25 14:38:32 --> Security Class Initialized
DEBUG - 2025-05-25 14:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:38:32 --> Input Class Initialized
INFO - 2025-05-25 14:38:32 --> Language Class Initialized
INFO - 2025-05-25 14:38:32 --> Loader Class Initialized
INFO - 2025-05-25 14:38:32 --> Helper loaded: url_helper
INFO - 2025-05-25 14:38:32 --> Helper loaded: form_helper
INFO - 2025-05-25 14:38:32 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:38:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:38:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:38:32 --> Controller Class Initialized
INFO - 2025-05-25 14:38:32 --> Model "User_model" initialized
INFO - 2025-05-25 14:38:32 --> Model "Progress_model" initialized
INFO - 2025-05-25 14:38:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:38:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:38:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-25 14:38:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:38:32 --> Final output sent to browser
DEBUG - 2025-05-25 14:38:32 --> Total execution time: 0.0772
INFO - 2025-05-25 14:42:32 --> Config Class Initialized
INFO - 2025-05-25 14:42:32 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:42:32 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:42:32 --> Utf8 Class Initialized
INFO - 2025-05-25 14:42:32 --> URI Class Initialized
INFO - 2025-05-25 14:42:32 --> Router Class Initialized
INFO - 2025-05-25 14:42:32 --> Output Class Initialized
INFO - 2025-05-25 14:42:32 --> Security Class Initialized
DEBUG - 2025-05-25 14:42:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:42:32 --> Input Class Initialized
INFO - 2025-05-25 14:42:32 --> Language Class Initialized
INFO - 2025-05-25 14:42:32 --> Loader Class Initialized
INFO - 2025-05-25 14:42:32 --> Helper loaded: url_helper
INFO - 2025-05-25 14:42:32 --> Helper loaded: form_helper
INFO - 2025-05-25 14:42:32 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:42:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:42:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:42:32 --> Controller Class Initialized
INFO - 2025-05-25 14:42:32 --> Model "Progress_model" initialized
INFO - 2025-05-25 14:42:32 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:42:32 --> Model "User_model" initialized
INFO - 2025-05-25 14:42:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:42:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:42:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-25 14:42:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:42:32 --> Final output sent to browser
DEBUG - 2025-05-25 14:42:32 --> Total execution time: 0.0849
INFO - 2025-05-25 14:42:33 --> Config Class Initialized
INFO - 2025-05-25 14:42:33 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:42:33 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:42:33 --> Utf8 Class Initialized
INFO - 2025-05-25 14:42:33 --> URI Class Initialized
INFO - 2025-05-25 14:42:33 --> Router Class Initialized
INFO - 2025-05-25 14:42:33 --> Output Class Initialized
INFO - 2025-05-25 14:42:33 --> Security Class Initialized
DEBUG - 2025-05-25 14:42:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:42:33 --> Input Class Initialized
INFO - 2025-05-25 14:42:33 --> Language Class Initialized
INFO - 2025-05-25 14:42:33 --> Loader Class Initialized
INFO - 2025-05-25 14:42:33 --> Helper loaded: url_helper
INFO - 2025-05-25 14:42:33 --> Helper loaded: form_helper
INFO - 2025-05-25 14:42:33 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:42:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:42:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:42:33 --> Controller Class Initialized
INFO - 2025-05-25 14:42:33 --> Model "Progress_model" initialized
INFO - 2025-05-25 14:42:33 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:42:33 --> Model "User_model" initialized
INFO - 2025-05-25 14:42:33 --> Final output sent to browser
DEBUG - 2025-05-25 14:42:33 --> Total execution time: 0.0991
INFO - 2025-05-25 14:42:36 --> Config Class Initialized
INFO - 2025-05-25 14:42:36 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:42:36 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:42:36 --> Utf8 Class Initialized
INFO - 2025-05-25 14:42:36 --> URI Class Initialized
INFO - 2025-05-25 14:42:36 --> Router Class Initialized
INFO - 2025-05-25 14:42:36 --> Output Class Initialized
INFO - 2025-05-25 14:42:36 --> Security Class Initialized
DEBUG - 2025-05-25 14:42:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:42:36 --> Input Class Initialized
INFO - 2025-05-25 14:42:36 --> Language Class Initialized
INFO - 2025-05-25 14:42:36 --> Loader Class Initialized
INFO - 2025-05-25 14:42:36 --> Helper loaded: url_helper
INFO - 2025-05-25 14:42:36 --> Helper loaded: form_helper
INFO - 2025-05-25 14:42:36 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:42:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:42:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:42:36 --> Controller Class Initialized
INFO - 2025-05-25 14:42:36 --> Model "User_model" initialized
INFO - 2025-05-25 14:42:36 --> Model "Progress_model" initialized
INFO - 2025-05-25 14:42:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:42:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:42:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-25 14:42:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:42:36 --> Final output sent to browser
DEBUG - 2025-05-25 14:42:36 --> Total execution time: 0.0752
INFO - 2025-05-25 14:44:50 --> Config Class Initialized
INFO - 2025-05-25 14:44:50 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:44:50 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:44:50 --> Utf8 Class Initialized
INFO - 2025-05-25 14:44:50 --> URI Class Initialized
INFO - 2025-05-25 14:44:50 --> Router Class Initialized
INFO - 2025-05-25 14:44:50 --> Output Class Initialized
INFO - 2025-05-25 14:44:51 --> Security Class Initialized
DEBUG - 2025-05-25 14:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:44:51 --> Input Class Initialized
INFO - 2025-05-25 14:44:51 --> Language Class Initialized
INFO - 2025-05-25 14:44:51 --> Loader Class Initialized
INFO - 2025-05-25 14:44:51 --> Helper loaded: url_helper
INFO - 2025-05-25 14:44:51 --> Helper loaded: form_helper
INFO - 2025-05-25 14:44:51 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:44:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:44:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:44:51 --> Controller Class Initialized
INFO - 2025-05-25 14:44:51 --> Model "User_model" initialized
INFO - 2025-05-25 14:44:51 --> Model "Progress_model" initialized
INFO - 2025-05-25 14:44:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:44:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:44:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-25 14:44:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:44:51 --> Final output sent to browser
DEBUG - 2025-05-25 14:44:51 --> Total execution time: 0.0910
INFO - 2025-05-25 14:45:22 --> Config Class Initialized
INFO - 2025-05-25 14:45:22 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:45:22 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:45:22 --> Utf8 Class Initialized
INFO - 2025-05-25 14:45:22 --> URI Class Initialized
INFO - 2025-05-25 14:45:22 --> Router Class Initialized
INFO - 2025-05-25 14:45:22 --> Output Class Initialized
INFO - 2025-05-25 14:45:22 --> Security Class Initialized
DEBUG - 2025-05-25 14:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:45:22 --> Input Class Initialized
INFO - 2025-05-25 14:45:22 --> Language Class Initialized
INFO - 2025-05-25 14:45:22 --> Loader Class Initialized
INFO - 2025-05-25 14:45:22 --> Helper loaded: url_helper
INFO - 2025-05-25 14:45:22 --> Helper loaded: form_helper
INFO - 2025-05-25 14:45:22 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:45:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:45:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:45:22 --> Controller Class Initialized
INFO - 2025-05-25 14:45:22 --> Model "User_model" initialized
INFO - 2025-05-25 14:45:22 --> Model "Progress_model" initialized
INFO - 2025-05-25 14:45:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:45:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:45:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-25 14:45:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:45:22 --> Final output sent to browser
DEBUG - 2025-05-25 14:45:22 --> Total execution time: 0.0946
INFO - 2025-05-25 14:47:25 --> Config Class Initialized
INFO - 2025-05-25 14:47:25 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:47:25 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:47:25 --> Utf8 Class Initialized
INFO - 2025-05-25 14:47:25 --> URI Class Initialized
INFO - 2025-05-25 14:47:25 --> Router Class Initialized
INFO - 2025-05-25 14:47:25 --> Output Class Initialized
INFO - 2025-05-25 14:47:25 --> Security Class Initialized
DEBUG - 2025-05-25 14:47:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:47:25 --> Input Class Initialized
INFO - 2025-05-25 14:47:25 --> Language Class Initialized
INFO - 2025-05-25 14:47:25 --> Loader Class Initialized
INFO - 2025-05-25 14:47:25 --> Helper loaded: url_helper
INFO - 2025-05-25 14:47:25 --> Helper loaded: form_helper
INFO - 2025-05-25 14:47:25 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:47:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:47:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:47:25 --> Controller Class Initialized
INFO - 2025-05-25 14:47:25 --> Model "User_model" initialized
INFO - 2025-05-25 14:47:25 --> Model "Progress_model" initialized
INFO - 2025-05-25 14:47:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:47:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:47:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-25 14:47:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:47:25 --> Final output sent to browser
DEBUG - 2025-05-25 14:47:25 --> Total execution time: 0.0879
INFO - 2025-05-25 14:47:32 --> Config Class Initialized
INFO - 2025-05-25 14:47:32 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:47:32 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:47:32 --> Utf8 Class Initialized
INFO - 2025-05-25 14:47:32 --> URI Class Initialized
INFO - 2025-05-25 14:47:32 --> Router Class Initialized
INFO - 2025-05-25 14:47:32 --> Output Class Initialized
INFO - 2025-05-25 14:47:32 --> Security Class Initialized
DEBUG - 2025-05-25 14:47:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:47:32 --> Input Class Initialized
INFO - 2025-05-25 14:47:32 --> Language Class Initialized
INFO - 2025-05-25 14:47:32 --> Loader Class Initialized
INFO - 2025-05-25 14:47:32 --> Helper loaded: url_helper
INFO - 2025-05-25 14:47:32 --> Helper loaded: form_helper
INFO - 2025-05-25 14:47:32 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:47:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:47:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:47:32 --> Controller Class Initialized
INFO - 2025-05-25 14:47:32 --> Model "User_model" initialized
INFO - 2025-05-25 14:47:32 --> Model "Progress_model" initialized
INFO - 2025-05-25 14:47:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:47:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:47:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-25 14:47:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:47:32 --> Final output sent to browser
DEBUG - 2025-05-25 14:47:32 --> Total execution time: 0.0817
INFO - 2025-05-25 14:47:35 --> Config Class Initialized
INFO - 2025-05-25 14:47:35 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:47:35 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:47:35 --> Utf8 Class Initialized
INFO - 2025-05-25 14:47:35 --> URI Class Initialized
INFO - 2025-05-25 14:47:35 --> Router Class Initialized
INFO - 2025-05-25 14:47:35 --> Output Class Initialized
INFO - 2025-05-25 14:47:35 --> Security Class Initialized
DEBUG - 2025-05-25 14:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:47:35 --> Input Class Initialized
INFO - 2025-05-25 14:47:35 --> Language Class Initialized
INFO - 2025-05-25 14:47:35 --> Loader Class Initialized
INFO - 2025-05-25 14:47:35 --> Helper loaded: url_helper
INFO - 2025-05-25 14:47:35 --> Helper loaded: form_helper
INFO - 2025-05-25 14:47:35 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:47:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:47:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:47:35 --> Controller Class Initialized
INFO - 2025-05-25 14:47:35 --> Model "Progress_model" initialized
INFO - 2025-05-25 14:47:35 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:47:35 --> Model "User_model" initialized
INFO - 2025-05-25 14:47:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:47:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:47:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-25 14:47:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:47:35 --> Final output sent to browser
DEBUG - 2025-05-25 14:47:35 --> Total execution time: 0.0855
INFO - 2025-05-25 14:47:35 --> Config Class Initialized
INFO - 2025-05-25 14:47:35 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:47:35 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:47:35 --> Utf8 Class Initialized
INFO - 2025-05-25 14:47:35 --> URI Class Initialized
INFO - 2025-05-25 14:47:35 --> Router Class Initialized
INFO - 2025-05-25 14:47:35 --> Output Class Initialized
INFO - 2025-05-25 14:47:35 --> Security Class Initialized
DEBUG - 2025-05-25 14:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:47:35 --> Input Class Initialized
INFO - 2025-05-25 14:47:35 --> Language Class Initialized
INFO - 2025-05-25 14:47:35 --> Loader Class Initialized
INFO - 2025-05-25 14:47:35 --> Helper loaded: url_helper
INFO - 2025-05-25 14:47:35 --> Helper loaded: form_helper
INFO - 2025-05-25 14:47:35 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:47:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:47:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:47:35 --> Controller Class Initialized
INFO - 2025-05-25 14:47:35 --> Model "Progress_model" initialized
INFO - 2025-05-25 14:47:35 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:47:35 --> Model "User_model" initialized
INFO - 2025-05-25 14:47:35 --> Final output sent to browser
DEBUG - 2025-05-25 14:47:35 --> Total execution time: 0.0900
INFO - 2025-05-25 14:47:38 --> Config Class Initialized
INFO - 2025-05-25 14:47:38 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:47:38 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:47:38 --> Utf8 Class Initialized
INFO - 2025-05-25 14:47:38 --> URI Class Initialized
INFO - 2025-05-25 14:47:38 --> Router Class Initialized
INFO - 2025-05-25 14:47:38 --> Output Class Initialized
INFO - 2025-05-25 14:47:38 --> Security Class Initialized
DEBUG - 2025-05-25 14:47:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:47:38 --> Input Class Initialized
INFO - 2025-05-25 14:47:38 --> Language Class Initialized
INFO - 2025-05-25 14:47:38 --> Loader Class Initialized
INFO - 2025-05-25 14:47:38 --> Helper loaded: url_helper
INFO - 2025-05-25 14:47:38 --> Helper loaded: form_helper
INFO - 2025-05-25 14:47:38 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:47:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:47:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:47:38 --> Controller Class Initialized
INFO - 2025-05-25 14:47:38 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:47:38 --> Model "User_model" initialized
INFO - 2025-05-25 14:47:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:47:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:47:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-05-25 14:47:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:47:38 --> Final output sent to browser
DEBUG - 2025-05-25 14:47:38 --> Total execution time: 0.0765
INFO - 2025-05-25 14:47:40 --> Config Class Initialized
INFO - 2025-05-25 14:47:40 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:47:40 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:47:40 --> Utf8 Class Initialized
INFO - 2025-05-25 14:47:40 --> URI Class Initialized
INFO - 2025-05-25 14:47:40 --> Router Class Initialized
INFO - 2025-05-25 14:47:40 --> Output Class Initialized
INFO - 2025-05-25 14:47:40 --> Security Class Initialized
DEBUG - 2025-05-25 14:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:47:40 --> Input Class Initialized
INFO - 2025-05-25 14:47:40 --> Language Class Initialized
INFO - 2025-05-25 14:47:40 --> Loader Class Initialized
INFO - 2025-05-25 14:47:40 --> Helper loaded: url_helper
INFO - 2025-05-25 14:47:40 --> Helper loaded: form_helper
INFO - 2025-05-25 14:47:40 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:47:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:47:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:47:40 --> Controller Class Initialized
INFO - 2025-05-25 14:47:40 --> Model "User_model" initialized
INFO - 2025-05-25 14:47:40 --> Model "Community_model" initialized
INFO - 2025-05-25 14:47:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:47:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:47:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/community.php
INFO - 2025-05-25 14:47:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:47:40 --> Final output sent to browser
DEBUG - 2025-05-25 14:47:40 --> Total execution time: 0.1117
INFO - 2025-05-25 14:47:44 --> Config Class Initialized
INFO - 2025-05-25 14:47:44 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:47:44 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:47:44 --> Utf8 Class Initialized
INFO - 2025-05-25 14:47:44 --> URI Class Initialized
INFO - 2025-05-25 14:47:44 --> Router Class Initialized
INFO - 2025-05-25 14:47:44 --> Output Class Initialized
INFO - 2025-05-25 14:47:44 --> Security Class Initialized
DEBUG - 2025-05-25 14:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:47:44 --> Input Class Initialized
INFO - 2025-05-25 14:47:44 --> Language Class Initialized
INFO - 2025-05-25 14:47:44 --> Loader Class Initialized
INFO - 2025-05-25 14:47:44 --> Helper loaded: url_helper
INFO - 2025-05-25 14:47:44 --> Helper loaded: form_helper
INFO - 2025-05-25 14:47:44 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:47:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:47:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:47:44 --> Controller Class Initialized
INFO - 2025-05-25 14:47:44 --> Model "User_model" initialized
INFO - 2025-05-25 14:47:44 --> Model "Progress_model" initialized
INFO - 2025-05-25 14:47:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:47:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:47:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-25 14:47:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:47:44 --> Final output sent to browser
DEBUG - 2025-05-25 14:47:44 --> Total execution time: 0.0805
INFO - 2025-05-25 14:47:47 --> Config Class Initialized
INFO - 2025-05-25 14:47:47 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:47:47 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:47:47 --> Utf8 Class Initialized
INFO - 2025-05-25 14:47:47 --> URI Class Initialized
INFO - 2025-05-25 14:47:47 --> Router Class Initialized
INFO - 2025-05-25 14:47:48 --> Output Class Initialized
INFO - 2025-05-25 14:47:48 --> Security Class Initialized
DEBUG - 2025-05-25 14:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:47:48 --> Input Class Initialized
INFO - 2025-05-25 14:47:48 --> Language Class Initialized
INFO - 2025-05-25 14:47:48 --> Loader Class Initialized
INFO - 2025-05-25 14:47:48 --> Helper loaded: url_helper
INFO - 2025-05-25 14:47:48 --> Helper loaded: form_helper
INFO - 2025-05-25 14:47:48 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:47:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:47:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:47:48 --> Controller Class Initialized
INFO - 2025-05-25 14:47:48 --> Model "User_model" initialized
INFO - 2025-05-25 14:47:48 --> Config Class Initialized
INFO - 2025-05-25 14:47:48 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:47:48 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:47:48 --> Utf8 Class Initialized
INFO - 2025-05-25 14:47:48 --> URI Class Initialized
INFO - 2025-05-25 14:47:48 --> Router Class Initialized
INFO - 2025-05-25 14:47:48 --> Output Class Initialized
INFO - 2025-05-25 14:47:48 --> Security Class Initialized
DEBUG - 2025-05-25 14:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:47:48 --> Input Class Initialized
INFO - 2025-05-25 14:47:48 --> Language Class Initialized
INFO - 2025-05-25 14:47:48 --> Loader Class Initialized
INFO - 2025-05-25 14:47:48 --> Helper loaded: url_helper
INFO - 2025-05-25 14:47:48 --> Helper loaded: form_helper
INFO - 2025-05-25 14:47:48 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:47:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:47:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:47:48 --> Controller Class Initialized
INFO - 2025-05-25 14:47:48 --> Model "User_model" initialized
INFO - 2025-05-25 14:47:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-25 14:47:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-25 14:47:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-25 14:47:48 --> Final output sent to browser
DEBUG - 2025-05-25 14:47:48 --> Total execution time: 0.0745
INFO - 2025-05-25 14:47:49 --> Config Class Initialized
INFO - 2025-05-25 14:47:49 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:47:49 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:47:49 --> Utf8 Class Initialized
INFO - 2025-05-25 14:47:49 --> URI Class Initialized
INFO - 2025-05-25 14:47:49 --> Router Class Initialized
INFO - 2025-05-25 14:47:49 --> Output Class Initialized
INFO - 2025-05-25 14:47:49 --> Security Class Initialized
DEBUG - 2025-05-25 14:47:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:47:49 --> Input Class Initialized
INFO - 2025-05-25 14:47:49 --> Language Class Initialized
INFO - 2025-05-25 14:47:49 --> Loader Class Initialized
INFO - 2025-05-25 14:47:49 --> Helper loaded: url_helper
INFO - 2025-05-25 14:47:49 --> Helper loaded: form_helper
INFO - 2025-05-25 14:47:49 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:47:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:47:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:47:49 --> Controller Class Initialized
INFO - 2025-05-25 14:47:49 --> Model "User_model" initialized
INFO - 2025-05-25 14:47:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-25 14:47:49 --> Final output sent to browser
DEBUG - 2025-05-25 14:47:49 --> Total execution time: 0.0688
INFO - 2025-05-25 14:47:54 --> Config Class Initialized
INFO - 2025-05-25 14:47:54 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:47:54 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:47:54 --> Utf8 Class Initialized
INFO - 2025-05-25 14:47:54 --> URI Class Initialized
INFO - 2025-05-25 14:47:54 --> Router Class Initialized
INFO - 2025-05-25 14:47:54 --> Output Class Initialized
INFO - 2025-05-25 14:47:54 --> Security Class Initialized
DEBUG - 2025-05-25 14:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:47:54 --> Input Class Initialized
INFO - 2025-05-25 14:47:54 --> Language Class Initialized
INFO - 2025-05-25 14:47:54 --> Loader Class Initialized
INFO - 2025-05-25 14:47:54 --> Helper loaded: url_helper
INFO - 2025-05-25 14:47:54 --> Helper loaded: form_helper
INFO - 2025-05-25 14:47:54 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:47:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:47:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:47:54 --> Controller Class Initialized
INFO - 2025-05-25 14:47:54 --> Model "User_model" initialized
INFO - 2025-05-25 14:47:55 --> Config Class Initialized
INFO - 2025-05-25 14:47:55 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:47:55 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:47:55 --> Utf8 Class Initialized
INFO - 2025-05-25 14:47:55 --> URI Class Initialized
INFO - 2025-05-25 14:47:55 --> Router Class Initialized
INFO - 2025-05-25 14:47:55 --> Output Class Initialized
INFO - 2025-05-25 14:47:55 --> Security Class Initialized
DEBUG - 2025-05-25 14:47:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:47:55 --> Input Class Initialized
INFO - 2025-05-25 14:47:55 --> Language Class Initialized
INFO - 2025-05-25 14:47:55 --> Loader Class Initialized
INFO - 2025-05-25 14:47:55 --> Helper loaded: url_helper
INFO - 2025-05-25 14:47:55 --> Helper loaded: form_helper
INFO - 2025-05-25 14:47:55 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:47:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:47:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:47:55 --> Controller Class Initialized
INFO - 2025-05-25 14:47:55 --> Model "User_model" initialized
INFO - 2025-05-25 14:47:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-25 14:47:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-25 14:47:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-25 14:47:55 --> Final output sent to browser
DEBUG - 2025-05-25 14:47:55 --> Total execution time: 0.0851
INFO - 2025-05-25 14:47:56 --> Config Class Initialized
INFO - 2025-05-25 14:47:56 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:47:56 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:47:56 --> Utf8 Class Initialized
INFO - 2025-05-25 14:47:56 --> URI Class Initialized
INFO - 2025-05-25 14:47:56 --> Router Class Initialized
INFO - 2025-05-25 14:47:56 --> Output Class Initialized
INFO - 2025-05-25 14:47:56 --> Security Class Initialized
DEBUG - 2025-05-25 14:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:47:56 --> Input Class Initialized
INFO - 2025-05-25 14:47:56 --> Language Class Initialized
INFO - 2025-05-25 14:47:56 --> Loader Class Initialized
INFO - 2025-05-25 14:47:56 --> Helper loaded: url_helper
INFO - 2025-05-25 14:47:56 --> Helper loaded: form_helper
INFO - 2025-05-25 14:47:56 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:47:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:47:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:47:56 --> Controller Class Initialized
INFO - 2025-05-25 14:47:56 --> Model "User_model" initialized
INFO - 2025-05-25 14:47:56 --> Model "Progress_model" initialized
INFO - 2025-05-25 14:47:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:47:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:47:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-25 14:47:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:47:56 --> Final output sent to browser
DEBUG - 2025-05-25 14:47:56 --> Total execution time: 0.0787
INFO - 2025-05-25 14:48:08 --> Config Class Initialized
INFO - 2025-05-25 14:48:08 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:48:08 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:48:08 --> Utf8 Class Initialized
INFO - 2025-05-25 14:48:08 --> URI Class Initialized
INFO - 2025-05-25 14:48:08 --> Router Class Initialized
INFO - 2025-05-25 14:48:08 --> Output Class Initialized
INFO - 2025-05-25 14:48:08 --> Security Class Initialized
DEBUG - 2025-05-25 14:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:48:08 --> Input Class Initialized
INFO - 2025-05-25 14:48:08 --> Language Class Initialized
INFO - 2025-05-25 14:48:08 --> Loader Class Initialized
INFO - 2025-05-25 14:48:08 --> Helper loaded: url_helper
INFO - 2025-05-25 14:48:08 --> Helper loaded: form_helper
INFO - 2025-05-25 14:48:08 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:48:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:48:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:48:08 --> Controller Class Initialized
INFO - 2025-05-25 14:48:08 --> Model "User_model" initialized
INFO - 2025-05-25 14:48:08 --> Model "Progress_model" initialized
INFO - 2025-05-25 14:48:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:48:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:48:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-25 14:48:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:48:08 --> Final output sent to browser
DEBUG - 2025-05-25 14:48:08 --> Total execution time: 0.0982
INFO - 2025-05-25 14:48:09 --> Config Class Initialized
INFO - 2025-05-25 14:48:09 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:48:09 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:48:09 --> Utf8 Class Initialized
INFO - 2025-05-25 14:48:09 --> URI Class Initialized
INFO - 2025-05-25 14:48:09 --> Router Class Initialized
INFO - 2025-05-25 14:48:09 --> Output Class Initialized
INFO - 2025-05-25 14:48:09 --> Security Class Initialized
DEBUG - 2025-05-25 14:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:48:09 --> Input Class Initialized
INFO - 2025-05-25 14:48:09 --> Language Class Initialized
INFO - 2025-05-25 14:48:09 --> Loader Class Initialized
INFO - 2025-05-25 14:48:09 --> Helper loaded: url_helper
INFO - 2025-05-25 14:48:09 --> Helper loaded: form_helper
INFO - 2025-05-25 14:48:09 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:48:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:48:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:48:09 --> Controller Class Initialized
INFO - 2025-05-25 14:48:09 --> Model "Progress_model" initialized
INFO - 2025-05-25 14:48:09 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:48:09 --> Model "User_model" initialized
INFO - 2025-05-25 14:48:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:48:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:48:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-25 14:48:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:48:09 --> Final output sent to browser
DEBUG - 2025-05-25 14:48:09 --> Total execution time: 0.0671
INFO - 2025-05-25 14:48:09 --> Config Class Initialized
INFO - 2025-05-25 14:48:09 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:48:09 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:48:09 --> Utf8 Class Initialized
INFO - 2025-05-25 14:48:09 --> URI Class Initialized
INFO - 2025-05-25 14:48:09 --> Router Class Initialized
INFO - 2025-05-25 14:48:09 --> Output Class Initialized
INFO - 2025-05-25 14:48:09 --> Security Class Initialized
DEBUG - 2025-05-25 14:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:48:09 --> Input Class Initialized
INFO - 2025-05-25 14:48:09 --> Language Class Initialized
INFO - 2025-05-25 14:48:09 --> Loader Class Initialized
INFO - 2025-05-25 14:48:09 --> Helper loaded: url_helper
INFO - 2025-05-25 14:48:09 --> Helper loaded: form_helper
INFO - 2025-05-25 14:48:09 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:48:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:48:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:48:09 --> Controller Class Initialized
INFO - 2025-05-25 14:48:09 --> Model "Progress_model" initialized
INFO - 2025-05-25 14:48:09 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:48:09 --> Model "User_model" initialized
INFO - 2025-05-25 14:48:09 --> Final output sent to browser
DEBUG - 2025-05-25 14:48:09 --> Total execution time: 0.0738
INFO - 2025-05-25 14:48:13 --> Config Class Initialized
INFO - 2025-05-25 14:48:13 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:48:13 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:48:13 --> Utf8 Class Initialized
INFO - 2025-05-25 14:48:13 --> URI Class Initialized
INFO - 2025-05-25 14:48:13 --> Router Class Initialized
INFO - 2025-05-25 14:48:13 --> Output Class Initialized
INFO - 2025-05-25 14:48:13 --> Security Class Initialized
DEBUG - 2025-05-25 14:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:48:13 --> Input Class Initialized
INFO - 2025-05-25 14:48:13 --> Language Class Initialized
INFO - 2025-05-25 14:48:13 --> Loader Class Initialized
INFO - 2025-05-25 14:48:13 --> Helper loaded: url_helper
INFO - 2025-05-25 14:48:13 --> Helper loaded: form_helper
INFO - 2025-05-25 14:48:13 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:48:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:48:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:48:13 --> Controller Class Initialized
INFO - 2025-05-25 14:48:13 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:48:13 --> Model "User_model" initialized
INFO - 2025-05-25 14:48:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:48:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:48:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-05-25 14:48:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:48:13 --> Final output sent to browser
DEBUG - 2025-05-25 14:48:13 --> Total execution time: 0.0642
INFO - 2025-05-25 14:48:17 --> Config Class Initialized
INFO - 2025-05-25 14:48:17 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:48:17 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:48:17 --> Utf8 Class Initialized
INFO - 2025-05-25 14:48:17 --> URI Class Initialized
INFO - 2025-05-25 14:48:17 --> Router Class Initialized
INFO - 2025-05-25 14:48:17 --> Output Class Initialized
INFO - 2025-05-25 14:48:17 --> Security Class Initialized
DEBUG - 2025-05-25 14:48:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:48:17 --> Input Class Initialized
INFO - 2025-05-25 14:48:17 --> Language Class Initialized
INFO - 2025-05-25 14:48:17 --> Loader Class Initialized
INFO - 2025-05-25 14:48:17 --> Helper loaded: url_helper
INFO - 2025-05-25 14:48:17 --> Helper loaded: form_helper
INFO - 2025-05-25 14:48:17 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:48:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:48:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:48:17 --> Controller Class Initialized
INFO - 2025-05-25 14:48:17 --> Model "User_model" initialized
INFO - 2025-05-25 14:48:17 --> Model "Community_model" initialized
INFO - 2025-05-25 14:48:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:48:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:48:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/community.php
INFO - 2025-05-25 14:48:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:48:17 --> Final output sent to browser
DEBUG - 2025-05-25 14:48:17 --> Total execution time: 0.0840
INFO - 2025-05-25 14:48:19 --> Config Class Initialized
INFO - 2025-05-25 14:48:19 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:48:19 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:48:19 --> Utf8 Class Initialized
INFO - 2025-05-25 14:48:19 --> URI Class Initialized
INFO - 2025-05-25 14:48:19 --> Router Class Initialized
INFO - 2025-05-25 14:48:19 --> Output Class Initialized
INFO - 2025-05-25 14:48:19 --> Security Class Initialized
DEBUG - 2025-05-25 14:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:48:19 --> Input Class Initialized
INFO - 2025-05-25 14:48:19 --> Language Class Initialized
INFO - 2025-05-25 14:48:19 --> Loader Class Initialized
INFO - 2025-05-25 14:48:19 --> Helper loaded: url_helper
INFO - 2025-05-25 14:48:19 --> Helper loaded: form_helper
INFO - 2025-05-25 14:48:19 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:48:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:48:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:48:19 --> Controller Class Initialized
INFO - 2025-05-25 14:48:19 --> Model "User_model" initialized
INFO - 2025-05-25 14:48:19 --> Model "Progress_model" initialized
INFO - 2025-05-25 14:48:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:48:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:48:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-25 14:48:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:48:19 --> Final output sent to browser
DEBUG - 2025-05-25 14:48:19 --> Total execution time: 0.0932
INFO - 2025-05-25 14:55:48 --> Config Class Initialized
INFO - 2025-05-25 14:55:48 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:55:48 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:55:48 --> Utf8 Class Initialized
INFO - 2025-05-25 14:55:48 --> URI Class Initialized
INFO - 2025-05-25 14:55:48 --> Router Class Initialized
INFO - 2025-05-25 14:55:48 --> Output Class Initialized
INFO - 2025-05-25 14:55:48 --> Security Class Initialized
DEBUG - 2025-05-25 14:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:55:48 --> Input Class Initialized
INFO - 2025-05-25 14:55:48 --> Language Class Initialized
INFO - 2025-05-25 14:55:48 --> Loader Class Initialized
INFO - 2025-05-25 14:55:48 --> Helper loaded: url_helper
INFO - 2025-05-25 14:55:48 --> Helper loaded: form_helper
INFO - 2025-05-25 14:55:48 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:55:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:55:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:55:48 --> Controller Class Initialized
INFO - 2025-05-25 14:55:48 --> Model "User_model" initialized
INFO - 2025-05-25 14:55:48 --> Config Class Initialized
INFO - 2025-05-25 14:55:48 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:55:48 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:55:48 --> Utf8 Class Initialized
INFO - 2025-05-25 14:55:48 --> URI Class Initialized
INFO - 2025-05-25 14:55:48 --> Router Class Initialized
INFO - 2025-05-25 14:55:48 --> Output Class Initialized
INFO - 2025-05-25 14:55:48 --> Security Class Initialized
DEBUG - 2025-05-25 14:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:55:48 --> Input Class Initialized
INFO - 2025-05-25 14:55:48 --> Language Class Initialized
INFO - 2025-05-25 14:55:48 --> Loader Class Initialized
INFO - 2025-05-25 14:55:48 --> Helper loaded: url_helper
INFO - 2025-05-25 14:55:48 --> Helper loaded: form_helper
INFO - 2025-05-25 14:55:48 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:55:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:55:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:55:48 --> Controller Class Initialized
INFO - 2025-05-25 14:55:48 --> Model "User_model" initialized
INFO - 2025-05-25 14:55:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-25 14:55:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-25 14:55:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-25 14:55:48 --> Final output sent to browser
DEBUG - 2025-05-25 14:55:48 --> Total execution time: 0.0887
INFO - 2025-05-25 14:55:51 --> Config Class Initialized
INFO - 2025-05-25 14:55:51 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:55:51 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:55:51 --> Utf8 Class Initialized
INFO - 2025-05-25 14:55:51 --> URI Class Initialized
INFO - 2025-05-25 14:55:51 --> Router Class Initialized
INFO - 2025-05-25 14:55:51 --> Output Class Initialized
INFO - 2025-05-25 14:55:51 --> Security Class Initialized
DEBUG - 2025-05-25 14:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:55:51 --> Input Class Initialized
INFO - 2025-05-25 14:55:51 --> Language Class Initialized
INFO - 2025-05-25 14:55:51 --> Loader Class Initialized
INFO - 2025-05-25 14:55:51 --> Helper loaded: url_helper
INFO - 2025-05-25 14:55:51 --> Helper loaded: form_helper
INFO - 2025-05-25 14:55:51 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:55:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:55:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:55:51 --> Controller Class Initialized
INFO - 2025-05-25 14:55:51 --> Model "User_model" initialized
INFO - 2025-05-25 14:55:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-25 14:55:51 --> Final output sent to browser
DEBUG - 2025-05-25 14:55:51 --> Total execution time: 0.0613
INFO - 2025-05-25 14:55:57 --> Config Class Initialized
INFO - 2025-05-25 14:55:57 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:55:57 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:55:57 --> Utf8 Class Initialized
INFO - 2025-05-25 14:55:57 --> URI Class Initialized
INFO - 2025-05-25 14:55:57 --> Router Class Initialized
INFO - 2025-05-25 14:55:57 --> Output Class Initialized
INFO - 2025-05-25 14:55:57 --> Security Class Initialized
DEBUG - 2025-05-25 14:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:55:57 --> Input Class Initialized
INFO - 2025-05-25 14:55:57 --> Language Class Initialized
INFO - 2025-05-25 14:55:57 --> Loader Class Initialized
INFO - 2025-05-25 14:55:57 --> Helper loaded: url_helper
INFO - 2025-05-25 14:55:57 --> Helper loaded: form_helper
INFO - 2025-05-25 14:55:57 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:55:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:55:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:55:57 --> Controller Class Initialized
INFO - 2025-05-25 14:55:57 --> Model "User_model" initialized
INFO - 2025-05-25 14:55:57 --> Config Class Initialized
INFO - 2025-05-25 14:55:57 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:55:57 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:55:57 --> Utf8 Class Initialized
INFO - 2025-05-25 14:55:57 --> URI Class Initialized
INFO - 2025-05-25 14:55:57 --> Router Class Initialized
INFO - 2025-05-25 14:55:57 --> Output Class Initialized
INFO - 2025-05-25 14:55:57 --> Security Class Initialized
DEBUG - 2025-05-25 14:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:55:57 --> Input Class Initialized
INFO - 2025-05-25 14:55:57 --> Language Class Initialized
INFO - 2025-05-25 14:55:57 --> Loader Class Initialized
INFO - 2025-05-25 14:55:57 --> Helper loaded: url_helper
INFO - 2025-05-25 14:55:57 --> Helper loaded: form_helper
INFO - 2025-05-25 14:55:57 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:55:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:55:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:55:57 --> Controller Class Initialized
INFO - 2025-05-25 14:55:57 --> Model "User_model" initialized
INFO - 2025-05-25 14:55:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-25 14:55:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-25 14:55:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-25 14:55:57 --> Final output sent to browser
DEBUG - 2025-05-25 14:55:57 --> Total execution time: 0.0730
INFO - 2025-05-25 14:56:00 --> Config Class Initialized
INFO - 2025-05-25 14:56:00 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:56:00 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:56:00 --> Utf8 Class Initialized
INFO - 2025-05-25 14:56:00 --> URI Class Initialized
INFO - 2025-05-25 14:56:00 --> Router Class Initialized
INFO - 2025-05-25 14:56:00 --> Output Class Initialized
INFO - 2025-05-25 14:56:00 --> Security Class Initialized
DEBUG - 2025-05-25 14:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:56:00 --> Input Class Initialized
INFO - 2025-05-25 14:56:00 --> Language Class Initialized
INFO - 2025-05-25 14:56:00 --> Loader Class Initialized
INFO - 2025-05-25 14:56:00 --> Helper loaded: url_helper
INFO - 2025-05-25 14:56:00 --> Helper loaded: form_helper
INFO - 2025-05-25 14:56:00 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:56:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:56:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:56:00 --> Controller Class Initialized
INFO - 2025-05-25 14:56:00 --> Model "User_model" initialized
INFO - 2025-05-25 14:56:00 --> Model "Progress_model" initialized
INFO - 2025-05-25 14:56:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:56:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:56:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-25 14:56:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:56:00 --> Final output sent to browser
DEBUG - 2025-05-25 14:56:00 --> Total execution time: 0.0787
INFO - 2025-05-25 14:56:05 --> Config Class Initialized
INFO - 2025-05-25 14:56:05 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:56:05 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:56:05 --> Utf8 Class Initialized
INFO - 2025-05-25 14:56:05 --> URI Class Initialized
INFO - 2025-05-25 14:56:05 --> Router Class Initialized
INFO - 2025-05-25 14:56:05 --> Output Class Initialized
INFO - 2025-05-25 14:56:05 --> Security Class Initialized
DEBUG - 2025-05-25 14:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:56:05 --> Input Class Initialized
INFO - 2025-05-25 14:56:05 --> Language Class Initialized
INFO - 2025-05-25 14:56:05 --> Loader Class Initialized
INFO - 2025-05-25 14:56:05 --> Helper loaded: url_helper
INFO - 2025-05-25 14:56:05 --> Helper loaded: form_helper
INFO - 2025-05-25 14:56:05 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:56:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:56:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:56:05 --> Controller Class Initialized
INFO - 2025-05-25 14:56:05 --> Model "User_model" initialized
INFO - 2025-05-25 14:56:05 --> Model "Progress_model" initialized
INFO - 2025-05-25 14:56:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:56:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:56:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-25 14:56:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:56:05 --> Final output sent to browser
DEBUG - 2025-05-25 14:56:05 --> Total execution time: 0.0905
INFO - 2025-05-25 14:56:33 --> Config Class Initialized
INFO - 2025-05-25 14:56:33 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:56:33 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:56:33 --> Utf8 Class Initialized
INFO - 2025-05-25 14:56:33 --> URI Class Initialized
INFO - 2025-05-25 14:56:33 --> Router Class Initialized
INFO - 2025-05-25 14:56:33 --> Output Class Initialized
INFO - 2025-05-25 14:56:33 --> Security Class Initialized
DEBUG - 2025-05-25 14:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:56:33 --> Input Class Initialized
INFO - 2025-05-25 14:56:33 --> Language Class Initialized
INFO - 2025-05-25 14:56:33 --> Loader Class Initialized
INFO - 2025-05-25 14:56:33 --> Helper loaded: url_helper
INFO - 2025-05-25 14:56:33 --> Helper loaded: form_helper
INFO - 2025-05-25 14:56:33 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:56:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:56:33 --> Controller Class Initialized
INFO - 2025-05-25 14:56:33 --> Model "Progress_model" initialized
INFO - 2025-05-25 14:56:33 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:56:33 --> Model "User_model" initialized
INFO - 2025-05-25 14:56:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:56:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:56:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-25 14:56:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:56:33 --> Final output sent to browser
DEBUG - 2025-05-25 14:56:33 --> Total execution time: 0.0643
INFO - 2025-05-25 14:56:33 --> Config Class Initialized
INFO - 2025-05-25 14:56:33 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:56:33 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:56:33 --> Utf8 Class Initialized
INFO - 2025-05-25 14:56:33 --> URI Class Initialized
INFO - 2025-05-25 14:56:33 --> Router Class Initialized
INFO - 2025-05-25 14:56:33 --> Output Class Initialized
INFO - 2025-05-25 14:56:33 --> Security Class Initialized
DEBUG - 2025-05-25 14:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:56:33 --> Input Class Initialized
INFO - 2025-05-25 14:56:33 --> Language Class Initialized
INFO - 2025-05-25 14:56:33 --> Loader Class Initialized
INFO - 2025-05-25 14:56:33 --> Helper loaded: url_helper
INFO - 2025-05-25 14:56:33 --> Helper loaded: form_helper
INFO - 2025-05-25 14:56:33 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:56:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:56:33 --> Controller Class Initialized
INFO - 2025-05-25 14:56:33 --> Model "Progress_model" initialized
INFO - 2025-05-25 14:56:33 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:56:33 --> Model "User_model" initialized
INFO - 2025-05-25 14:56:33 --> Final output sent to browser
DEBUG - 2025-05-25 14:56:33 --> Total execution time: 0.0841
INFO - 2025-05-25 14:56:47 --> Config Class Initialized
INFO - 2025-05-25 14:56:47 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:56:47 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:56:47 --> Utf8 Class Initialized
INFO - 2025-05-25 14:56:47 --> URI Class Initialized
INFO - 2025-05-25 14:56:47 --> Router Class Initialized
INFO - 2025-05-25 14:56:47 --> Output Class Initialized
INFO - 2025-05-25 14:56:47 --> Security Class Initialized
DEBUG - 2025-05-25 14:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:56:47 --> Input Class Initialized
INFO - 2025-05-25 14:56:47 --> Language Class Initialized
INFO - 2025-05-25 14:56:47 --> Loader Class Initialized
INFO - 2025-05-25 14:56:47 --> Helper loaded: url_helper
INFO - 2025-05-25 14:56:47 --> Helper loaded: form_helper
INFO - 2025-05-25 14:56:47 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:56:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:56:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:56:47 --> Controller Class Initialized
INFO - 2025-05-25 14:56:47 --> Model "Progress_model" initialized
INFO - 2025-05-25 14:56:47 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:56:47 --> Model "User_model" initialized
INFO - 2025-05-25 14:56:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 14:56:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 14:56:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-25 14:56:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 14:56:47 --> Final output sent to browser
DEBUG - 2025-05-25 14:56:47 --> Total execution time: 0.0842
INFO - 2025-05-25 14:56:47 --> Config Class Initialized
INFO - 2025-05-25 14:56:47 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:56:47 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:56:47 --> Utf8 Class Initialized
INFO - 2025-05-25 14:56:47 --> URI Class Initialized
INFO - 2025-05-25 14:56:47 --> Router Class Initialized
INFO - 2025-05-25 14:56:47 --> Output Class Initialized
INFO - 2025-05-25 14:56:47 --> Security Class Initialized
DEBUG - 2025-05-25 14:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:56:47 --> Input Class Initialized
INFO - 2025-05-25 14:56:47 --> Language Class Initialized
INFO - 2025-05-25 14:56:47 --> Loader Class Initialized
INFO - 2025-05-25 14:56:47 --> Helper loaded: url_helper
INFO - 2025-05-25 14:56:47 --> Helper loaded: form_helper
INFO - 2025-05-25 14:56:47 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:56:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:56:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:56:47 --> Controller Class Initialized
INFO - 2025-05-25 14:56:47 --> Model "Progress_model" initialized
INFO - 2025-05-25 14:56:47 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:56:47 --> Model "User_model" initialized
INFO - 2025-05-25 14:56:47 --> Final output sent to browser
DEBUG - 2025-05-25 14:56:47 --> Total execution time: 0.0714
INFO - 2025-05-25 14:56:54 --> Config Class Initialized
INFO - 2025-05-25 14:56:54 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:56:54 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:56:54 --> Utf8 Class Initialized
INFO - 2025-05-25 14:56:54 --> URI Class Initialized
INFO - 2025-05-25 14:56:54 --> Router Class Initialized
INFO - 2025-05-25 14:56:54 --> Output Class Initialized
INFO - 2025-05-25 14:56:54 --> Security Class Initialized
DEBUG - 2025-05-25 14:56:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:56:54 --> Input Class Initialized
INFO - 2025-05-25 14:56:54 --> Language Class Initialized
INFO - 2025-05-25 14:56:54 --> Loader Class Initialized
INFO - 2025-05-25 14:56:54 --> Helper loaded: url_helper
INFO - 2025-05-25 14:56:54 --> Helper loaded: form_helper
INFO - 2025-05-25 14:56:54 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:56:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:56:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:56:54 --> Controller Class Initialized
INFO - 2025-05-25 14:56:54 --> Model "Progress_model" initialized
INFO - 2025-05-25 14:56:54 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:56:54 --> Model "User_model" initialized
INFO - 2025-05-25 14:56:54 --> Final output sent to browser
DEBUG - 2025-05-25 14:56:54 --> Total execution time: 0.0691
INFO - 2025-05-25 14:56:57 --> Config Class Initialized
INFO - 2025-05-25 14:56:57 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:56:57 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:56:57 --> Utf8 Class Initialized
INFO - 2025-05-25 14:56:57 --> URI Class Initialized
INFO - 2025-05-25 14:56:57 --> Router Class Initialized
INFO - 2025-05-25 14:56:57 --> Output Class Initialized
INFO - 2025-05-25 14:56:57 --> Security Class Initialized
DEBUG - 2025-05-25 14:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:56:57 --> Input Class Initialized
INFO - 2025-05-25 14:56:57 --> Language Class Initialized
INFO - 2025-05-25 14:56:57 --> Loader Class Initialized
INFO - 2025-05-25 14:56:57 --> Helper loaded: url_helper
INFO - 2025-05-25 14:56:57 --> Helper loaded: form_helper
INFO - 2025-05-25 14:56:57 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:56:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:56:57 --> Controller Class Initialized
INFO - 2025-05-25 14:56:57 --> Model "Progress_model" initialized
INFO - 2025-05-25 14:56:57 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:56:57 --> Model "User_model" initialized
INFO - 2025-05-25 14:56:57 --> Final output sent to browser
DEBUG - 2025-05-25 14:56:57 --> Total execution time: 0.0848
INFO - 2025-05-25 14:56:58 --> Config Class Initialized
INFO - 2025-05-25 14:56:58 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:56:58 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:56:58 --> Utf8 Class Initialized
INFO - 2025-05-25 14:56:58 --> URI Class Initialized
INFO - 2025-05-25 14:56:58 --> Router Class Initialized
INFO - 2025-05-25 14:56:58 --> Output Class Initialized
INFO - 2025-05-25 14:56:58 --> Security Class Initialized
DEBUG - 2025-05-25 14:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:56:58 --> Input Class Initialized
INFO - 2025-05-25 14:56:58 --> Language Class Initialized
INFO - 2025-05-25 14:56:58 --> Loader Class Initialized
INFO - 2025-05-25 14:56:58 --> Helper loaded: url_helper
INFO - 2025-05-25 14:56:58 --> Helper loaded: form_helper
INFO - 2025-05-25 14:56:58 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:56:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:56:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:56:58 --> Controller Class Initialized
INFO - 2025-05-25 14:56:58 --> Model "Progress_model" initialized
INFO - 2025-05-25 14:56:58 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:56:58 --> Model "User_model" initialized
INFO - 2025-05-25 14:56:58 --> Final output sent to browser
DEBUG - 2025-05-25 14:56:58 --> Total execution time: 0.0744
INFO - 2025-05-25 14:56:59 --> Config Class Initialized
INFO - 2025-05-25 14:56:59 --> Hooks Class Initialized
DEBUG - 2025-05-25 14:56:59 --> UTF-8 Support Enabled
INFO - 2025-05-25 14:56:59 --> Utf8 Class Initialized
INFO - 2025-05-25 14:56:59 --> URI Class Initialized
INFO - 2025-05-25 14:56:59 --> Router Class Initialized
INFO - 2025-05-25 14:56:59 --> Output Class Initialized
INFO - 2025-05-25 14:56:59 --> Security Class Initialized
DEBUG - 2025-05-25 14:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 14:56:59 --> Input Class Initialized
INFO - 2025-05-25 14:56:59 --> Language Class Initialized
INFO - 2025-05-25 14:56:59 --> Loader Class Initialized
INFO - 2025-05-25 14:56:59 --> Helper loaded: url_helper
INFO - 2025-05-25 14:56:59 --> Helper loaded: form_helper
INFO - 2025-05-25 14:56:59 --> Database Driver Class Initialized
DEBUG - 2025-05-25 14:56:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 14:56:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 14:56:59 --> Controller Class Initialized
INFO - 2025-05-25 14:56:59 --> Model "Progress_model" initialized
INFO - 2025-05-25 14:56:59 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 14:56:59 --> Model "User_model" initialized
INFO - 2025-05-25 14:56:59 --> Final output sent to browser
DEBUG - 2025-05-25 14:56:59 --> Total execution time: 0.0804
INFO - 2025-05-25 15:01:39 --> Config Class Initialized
INFO - 2025-05-25 15:01:39 --> Hooks Class Initialized
DEBUG - 2025-05-25 15:01:39 --> UTF-8 Support Enabled
INFO - 2025-05-25 15:01:39 --> Utf8 Class Initialized
INFO - 2025-05-25 15:01:39 --> URI Class Initialized
INFO - 2025-05-25 15:01:39 --> Router Class Initialized
INFO - 2025-05-25 15:01:39 --> Output Class Initialized
INFO - 2025-05-25 15:01:39 --> Security Class Initialized
DEBUG - 2025-05-25 15:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 15:01:39 --> Input Class Initialized
INFO - 2025-05-25 15:01:39 --> Language Class Initialized
INFO - 2025-05-25 15:01:39 --> Loader Class Initialized
INFO - 2025-05-25 15:01:39 --> Helper loaded: url_helper
INFO - 2025-05-25 15:01:39 --> Helper loaded: form_helper
INFO - 2025-05-25 15:01:39 --> Database Driver Class Initialized
DEBUG - 2025-05-25 15:01:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 15:01:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 15:01:39 --> Controller Class Initialized
INFO - 2025-05-25 15:01:39 --> Model "Progress_model" initialized
INFO - 2025-05-25 15:01:39 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 15:01:39 --> Model "User_model" initialized
INFO - 2025-05-25 15:01:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 15:01:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 15:01:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-25 15:01:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 15:01:39 --> Final output sent to browser
DEBUG - 2025-05-25 15:01:39 --> Total execution time: 0.1056
INFO - 2025-05-25 15:01:40 --> Config Class Initialized
INFO - 2025-05-25 15:01:40 --> Hooks Class Initialized
DEBUG - 2025-05-25 15:01:40 --> UTF-8 Support Enabled
INFO - 2025-05-25 15:01:40 --> Utf8 Class Initialized
INFO - 2025-05-25 15:01:40 --> URI Class Initialized
INFO - 2025-05-25 15:01:40 --> Router Class Initialized
INFO - 2025-05-25 15:01:40 --> Output Class Initialized
INFO - 2025-05-25 15:01:40 --> Security Class Initialized
DEBUG - 2025-05-25 15:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 15:01:40 --> Input Class Initialized
INFO - 2025-05-25 15:01:40 --> Language Class Initialized
INFO - 2025-05-25 15:01:40 --> Loader Class Initialized
INFO - 2025-05-25 15:01:40 --> Helper loaded: url_helper
INFO - 2025-05-25 15:01:40 --> Helper loaded: form_helper
INFO - 2025-05-25 15:01:40 --> Database Driver Class Initialized
DEBUG - 2025-05-25 15:01:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 15:01:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 15:01:40 --> Controller Class Initialized
INFO - 2025-05-25 15:01:40 --> Model "Progress_model" initialized
INFO - 2025-05-25 15:01:40 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 15:01:40 --> Model "User_model" initialized
INFO - 2025-05-25 15:01:40 --> Final output sent to browser
DEBUG - 2025-05-25 15:01:40 --> Total execution time: 0.0916
INFO - 2025-05-25 15:01:45 --> Config Class Initialized
INFO - 2025-05-25 15:01:45 --> Hooks Class Initialized
DEBUG - 2025-05-25 15:01:45 --> UTF-8 Support Enabled
INFO - 2025-05-25 15:01:45 --> Utf8 Class Initialized
INFO - 2025-05-25 15:01:45 --> URI Class Initialized
INFO - 2025-05-25 15:01:45 --> Router Class Initialized
INFO - 2025-05-25 15:01:45 --> Output Class Initialized
INFO - 2025-05-25 15:01:45 --> Security Class Initialized
DEBUG - 2025-05-25 15:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 15:01:45 --> Input Class Initialized
INFO - 2025-05-25 15:01:45 --> Language Class Initialized
INFO - 2025-05-25 15:01:45 --> Loader Class Initialized
INFO - 2025-05-25 15:01:45 --> Helper loaded: url_helper
INFO - 2025-05-25 15:01:45 --> Helper loaded: form_helper
INFO - 2025-05-25 15:01:45 --> Database Driver Class Initialized
DEBUG - 2025-05-25 15:01:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 15:01:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 15:01:45 --> Controller Class Initialized
INFO - 2025-05-25 15:01:45 --> Model "User_model" initialized
INFO - 2025-05-25 15:01:45 --> Model "Community_model" initialized
INFO - 2025-05-25 15:01:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 15:01:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 15:01:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/community.php
INFO - 2025-05-25 15:01:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 15:01:45 --> Final output sent to browser
DEBUG - 2025-05-25 15:01:45 --> Total execution time: 0.0671
INFO - 2025-05-25 15:01:46 --> Config Class Initialized
INFO - 2025-05-25 15:01:46 --> Hooks Class Initialized
DEBUG - 2025-05-25 15:01:46 --> UTF-8 Support Enabled
INFO - 2025-05-25 15:01:46 --> Utf8 Class Initialized
INFO - 2025-05-25 15:01:46 --> URI Class Initialized
INFO - 2025-05-25 15:01:46 --> Router Class Initialized
INFO - 2025-05-25 15:01:46 --> Output Class Initialized
INFO - 2025-05-25 15:01:46 --> Security Class Initialized
DEBUG - 2025-05-25 15:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 15:01:46 --> Input Class Initialized
INFO - 2025-05-25 15:01:46 --> Language Class Initialized
INFO - 2025-05-25 15:01:46 --> Loader Class Initialized
INFO - 2025-05-25 15:01:46 --> Helper loaded: url_helper
INFO - 2025-05-25 15:01:46 --> Helper loaded: form_helper
INFO - 2025-05-25 15:01:46 --> Database Driver Class Initialized
DEBUG - 2025-05-25 15:01:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 15:01:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 15:01:46 --> Controller Class Initialized
INFO - 2025-05-25 15:01:46 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 15:01:46 --> Model "User_model" initialized
INFO - 2025-05-25 15:01:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 15:01:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 15:01:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-05-25 15:01:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 15:01:46 --> Final output sent to browser
DEBUG - 2025-05-25 15:01:46 --> Total execution time: 0.0658
INFO - 2025-05-25 15:01:48 --> Config Class Initialized
INFO - 2025-05-25 15:01:48 --> Hooks Class Initialized
DEBUG - 2025-05-25 15:01:48 --> UTF-8 Support Enabled
INFO - 2025-05-25 15:01:48 --> Utf8 Class Initialized
INFO - 2025-05-25 15:01:48 --> URI Class Initialized
INFO - 2025-05-25 15:01:48 --> Router Class Initialized
INFO - 2025-05-25 15:01:48 --> Output Class Initialized
INFO - 2025-05-25 15:01:48 --> Security Class Initialized
DEBUG - 2025-05-25 15:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 15:01:48 --> Input Class Initialized
INFO - 2025-05-25 15:01:48 --> Language Class Initialized
INFO - 2025-05-25 15:01:48 --> Loader Class Initialized
INFO - 2025-05-25 15:01:48 --> Helper loaded: url_helper
INFO - 2025-05-25 15:01:48 --> Helper loaded: form_helper
INFO - 2025-05-25 15:01:48 --> Database Driver Class Initialized
DEBUG - 2025-05-25 15:01:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 15:01:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 15:01:48 --> Controller Class Initialized
INFO - 2025-05-25 15:01:48 --> Model "Progress_model" initialized
INFO - 2025-05-25 15:01:48 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 15:01:48 --> Model "User_model" initialized
INFO - 2025-05-25 15:01:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 15:01:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 15:01:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-25 15:01:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 15:01:48 --> Final output sent to browser
DEBUG - 2025-05-25 15:01:48 --> Total execution time: 0.0589
INFO - 2025-05-25 15:01:48 --> Config Class Initialized
INFO - 2025-05-25 15:01:48 --> Hooks Class Initialized
DEBUG - 2025-05-25 15:01:48 --> UTF-8 Support Enabled
INFO - 2025-05-25 15:01:48 --> Utf8 Class Initialized
INFO - 2025-05-25 15:01:48 --> URI Class Initialized
INFO - 2025-05-25 15:01:48 --> Router Class Initialized
INFO - 2025-05-25 15:01:48 --> Output Class Initialized
INFO - 2025-05-25 15:01:48 --> Security Class Initialized
DEBUG - 2025-05-25 15:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 15:01:48 --> Input Class Initialized
INFO - 2025-05-25 15:01:48 --> Language Class Initialized
INFO - 2025-05-25 15:01:48 --> Loader Class Initialized
INFO - 2025-05-25 15:01:48 --> Helper loaded: url_helper
INFO - 2025-05-25 15:01:48 --> Helper loaded: form_helper
INFO - 2025-05-25 15:01:48 --> Database Driver Class Initialized
DEBUG - 2025-05-25 15:01:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 15:01:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 15:01:48 --> Controller Class Initialized
INFO - 2025-05-25 15:01:48 --> Model "Progress_model" initialized
INFO - 2025-05-25 15:01:48 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 15:01:48 --> Model "User_model" initialized
INFO - 2025-05-25 15:01:48 --> Final output sent to browser
DEBUG - 2025-05-25 15:01:48 --> Total execution time: 0.0817
INFO - 2025-05-25 15:01:49 --> Config Class Initialized
INFO - 2025-05-25 15:01:49 --> Hooks Class Initialized
DEBUG - 2025-05-25 15:01:49 --> UTF-8 Support Enabled
INFO - 2025-05-25 15:01:49 --> Utf8 Class Initialized
INFO - 2025-05-25 15:01:49 --> URI Class Initialized
INFO - 2025-05-25 15:01:49 --> Router Class Initialized
INFO - 2025-05-25 15:01:49 --> Output Class Initialized
INFO - 2025-05-25 15:01:49 --> Security Class Initialized
DEBUG - 2025-05-25 15:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 15:01:49 --> Input Class Initialized
INFO - 2025-05-25 15:01:49 --> Language Class Initialized
INFO - 2025-05-25 15:01:49 --> Loader Class Initialized
INFO - 2025-05-25 15:01:49 --> Helper loaded: url_helper
INFO - 2025-05-25 15:01:49 --> Helper loaded: form_helper
INFO - 2025-05-25 15:01:49 --> Database Driver Class Initialized
DEBUG - 2025-05-25 15:01:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 15:01:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 15:01:49 --> Controller Class Initialized
INFO - 2025-05-25 15:01:49 --> Model "User_model" initialized
INFO - 2025-05-25 15:01:49 --> Model "Progress_model" initialized
INFO - 2025-05-25 15:01:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 15:01:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 15:01:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-25 15:01:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 15:01:49 --> Final output sent to browser
DEBUG - 2025-05-25 15:01:49 --> Total execution time: 0.0825
INFO - 2025-05-25 15:01:51 --> Config Class Initialized
INFO - 2025-05-25 15:01:51 --> Hooks Class Initialized
DEBUG - 2025-05-25 15:01:51 --> UTF-8 Support Enabled
INFO - 2025-05-25 15:01:51 --> Utf8 Class Initialized
INFO - 2025-05-25 15:01:51 --> URI Class Initialized
INFO - 2025-05-25 15:01:51 --> Router Class Initialized
INFO - 2025-05-25 15:01:51 --> Output Class Initialized
INFO - 2025-05-25 15:01:51 --> Security Class Initialized
DEBUG - 2025-05-25 15:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 15:01:51 --> Input Class Initialized
INFO - 2025-05-25 15:01:51 --> Language Class Initialized
INFO - 2025-05-25 15:01:51 --> Loader Class Initialized
INFO - 2025-05-25 15:01:51 --> Helper loaded: url_helper
INFO - 2025-05-25 15:01:51 --> Helper loaded: form_helper
INFO - 2025-05-25 15:01:51 --> Database Driver Class Initialized
DEBUG - 2025-05-25 15:01:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 15:01:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 15:01:51 --> Controller Class Initialized
INFO - 2025-05-25 15:01:51 --> Model "Progress_model" initialized
INFO - 2025-05-25 15:01:51 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 15:01:51 --> Model "User_model" initialized
INFO - 2025-05-25 15:01:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 15:01:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 15:01:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-25 15:01:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 15:01:51 --> Final output sent to browser
DEBUG - 2025-05-25 15:01:51 --> Total execution time: 0.0762
INFO - 2025-05-25 15:01:51 --> Config Class Initialized
INFO - 2025-05-25 15:01:51 --> Hooks Class Initialized
DEBUG - 2025-05-25 15:01:51 --> UTF-8 Support Enabled
INFO - 2025-05-25 15:01:51 --> Utf8 Class Initialized
INFO - 2025-05-25 15:01:51 --> URI Class Initialized
INFO - 2025-05-25 15:01:51 --> Router Class Initialized
INFO - 2025-05-25 15:01:51 --> Output Class Initialized
INFO - 2025-05-25 15:01:51 --> Security Class Initialized
DEBUG - 2025-05-25 15:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 15:01:51 --> Input Class Initialized
INFO - 2025-05-25 15:01:51 --> Language Class Initialized
INFO - 2025-05-25 15:01:51 --> Loader Class Initialized
INFO - 2025-05-25 15:01:51 --> Helper loaded: url_helper
INFO - 2025-05-25 15:01:51 --> Helper loaded: form_helper
INFO - 2025-05-25 15:01:51 --> Database Driver Class Initialized
DEBUG - 2025-05-25 15:01:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 15:01:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 15:01:52 --> Controller Class Initialized
INFO - 2025-05-25 15:01:52 --> Model "Progress_model" initialized
INFO - 2025-05-25 15:01:52 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 15:01:52 --> Model "User_model" initialized
INFO - 2025-05-25 15:01:52 --> Final output sent to browser
DEBUG - 2025-05-25 15:01:52 --> Total execution time: 0.0666
INFO - 2025-05-25 15:01:53 --> Config Class Initialized
INFO - 2025-05-25 15:01:53 --> Hooks Class Initialized
DEBUG - 2025-05-25 15:01:53 --> UTF-8 Support Enabled
INFO - 2025-05-25 15:01:53 --> Utf8 Class Initialized
INFO - 2025-05-25 15:01:53 --> URI Class Initialized
INFO - 2025-05-25 15:01:53 --> Router Class Initialized
INFO - 2025-05-25 15:01:53 --> Output Class Initialized
INFO - 2025-05-25 15:01:53 --> Security Class Initialized
DEBUG - 2025-05-25 15:01:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 15:01:53 --> Input Class Initialized
INFO - 2025-05-25 15:01:53 --> Language Class Initialized
INFO - 2025-05-25 15:01:53 --> Loader Class Initialized
INFO - 2025-05-25 15:01:53 --> Helper loaded: url_helper
INFO - 2025-05-25 15:01:53 --> Helper loaded: form_helper
INFO - 2025-05-25 15:01:53 --> Database Driver Class Initialized
DEBUG - 2025-05-25 15:01:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 15:01:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 15:01:53 --> Controller Class Initialized
INFO - 2025-05-25 15:01:53 --> Model "Progress_model" initialized
INFO - 2025-05-25 15:01:53 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 15:01:53 --> Model "User_model" initialized
INFO - 2025-05-25 15:01:53 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 15:01:53 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 15:01:53 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-25 15:01:53 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 15:01:53 --> Final output sent to browser
DEBUG - 2025-05-25 15:01:53 --> Total execution time: 0.0828
INFO - 2025-05-25 15:01:53 --> Config Class Initialized
INFO - 2025-05-25 15:01:53 --> Hooks Class Initialized
DEBUG - 2025-05-25 15:01:53 --> UTF-8 Support Enabled
INFO - 2025-05-25 15:01:53 --> Utf8 Class Initialized
INFO - 2025-05-25 15:01:53 --> URI Class Initialized
INFO - 2025-05-25 15:01:53 --> Router Class Initialized
INFO - 2025-05-25 15:01:53 --> Output Class Initialized
INFO - 2025-05-25 15:01:53 --> Security Class Initialized
DEBUG - 2025-05-25 15:01:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 15:01:53 --> Input Class Initialized
INFO - 2025-05-25 15:01:53 --> Language Class Initialized
INFO - 2025-05-25 15:01:53 --> Loader Class Initialized
INFO - 2025-05-25 15:01:53 --> Helper loaded: url_helper
INFO - 2025-05-25 15:01:53 --> Helper loaded: form_helper
INFO - 2025-05-25 15:01:53 --> Database Driver Class Initialized
DEBUG - 2025-05-25 15:01:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 15:01:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 15:01:53 --> Controller Class Initialized
INFO - 2025-05-25 15:01:53 --> Model "Progress_model" initialized
INFO - 2025-05-25 15:01:53 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 15:01:53 --> Model "User_model" initialized
INFO - 2025-05-25 15:01:53 --> Final output sent to browser
DEBUG - 2025-05-25 15:01:53 --> Total execution time: 0.0814
INFO - 2025-05-25 15:01:54 --> Config Class Initialized
INFO - 2025-05-25 15:01:54 --> Hooks Class Initialized
DEBUG - 2025-05-25 15:01:54 --> UTF-8 Support Enabled
INFO - 2025-05-25 15:01:54 --> Utf8 Class Initialized
INFO - 2025-05-25 15:01:54 --> URI Class Initialized
INFO - 2025-05-25 15:01:54 --> Router Class Initialized
INFO - 2025-05-25 15:01:54 --> Output Class Initialized
INFO - 2025-05-25 15:01:54 --> Security Class Initialized
DEBUG - 2025-05-25 15:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 15:01:54 --> Input Class Initialized
INFO - 2025-05-25 15:01:54 --> Language Class Initialized
INFO - 2025-05-25 15:01:54 --> Loader Class Initialized
INFO - 2025-05-25 15:01:54 --> Helper loaded: url_helper
INFO - 2025-05-25 15:01:54 --> Helper loaded: form_helper
INFO - 2025-05-25 15:01:54 --> Database Driver Class Initialized
DEBUG - 2025-05-25 15:01:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 15:01:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 15:01:54 --> Controller Class Initialized
INFO - 2025-05-25 15:01:54 --> Model "User_model" initialized
INFO - 2025-05-25 15:01:54 --> Model "Progress_model" initialized
INFO - 2025-05-25 15:01:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 15:01:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 15:01:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-25 15:01:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 15:01:54 --> Final output sent to browser
DEBUG - 2025-05-25 15:01:54 --> Total execution time: 0.0931
INFO - 2025-05-25 15:01:56 --> Config Class Initialized
INFO - 2025-05-25 15:01:56 --> Hooks Class Initialized
DEBUG - 2025-05-25 15:01:56 --> UTF-8 Support Enabled
INFO - 2025-05-25 15:01:56 --> Utf8 Class Initialized
INFO - 2025-05-25 15:01:56 --> URI Class Initialized
INFO - 2025-05-25 15:01:56 --> Router Class Initialized
INFO - 2025-05-25 15:01:56 --> Output Class Initialized
INFO - 2025-05-25 15:01:56 --> Security Class Initialized
DEBUG - 2025-05-25 15:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 15:01:56 --> Input Class Initialized
INFO - 2025-05-25 15:01:56 --> Language Class Initialized
INFO - 2025-05-25 15:01:56 --> Loader Class Initialized
INFO - 2025-05-25 15:01:56 --> Helper loaded: url_helper
INFO - 2025-05-25 15:01:56 --> Helper loaded: form_helper
INFO - 2025-05-25 15:01:56 --> Database Driver Class Initialized
DEBUG - 2025-05-25 15:01:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 15:01:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 15:01:56 --> Controller Class Initialized
INFO - 2025-05-25 15:01:56 --> Model "User_model" initialized
INFO - 2025-05-25 15:01:56 --> Model "Progress_model" initialized
INFO - 2025-05-25 15:01:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 15:01:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 15:01:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-25 15:01:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 15:01:56 --> Final output sent to browser
DEBUG - 2025-05-25 15:01:56 --> Total execution time: 0.0864
INFO - 2025-05-25 15:04:22 --> Config Class Initialized
INFO - 2025-05-25 15:04:22 --> Hooks Class Initialized
DEBUG - 2025-05-25 15:04:22 --> UTF-8 Support Enabled
INFO - 2025-05-25 15:04:22 --> Utf8 Class Initialized
INFO - 2025-05-25 15:04:22 --> URI Class Initialized
INFO - 2025-05-25 15:04:22 --> Router Class Initialized
INFO - 2025-05-25 15:04:22 --> Output Class Initialized
INFO - 2025-05-25 15:04:22 --> Security Class Initialized
DEBUG - 2025-05-25 15:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 15:04:22 --> Input Class Initialized
INFO - 2025-05-25 15:04:22 --> Language Class Initialized
INFO - 2025-05-25 15:04:22 --> Loader Class Initialized
INFO - 2025-05-25 15:04:22 --> Helper loaded: url_helper
INFO - 2025-05-25 15:04:22 --> Helper loaded: form_helper
INFO - 2025-05-25 15:04:22 --> Database Driver Class Initialized
DEBUG - 2025-05-25 15:04:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 15:04:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 15:04:22 --> Controller Class Initialized
INFO - 2025-05-25 15:04:22 --> Model "User_model" initialized
INFO - 2025-05-25 15:04:22 --> Model "Progress_model" initialized
INFO - 2025-05-25 15:04:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 15:04:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 15:04:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-25 15:04:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 15:04:22 --> Final output sent to browser
DEBUG - 2025-05-25 15:04:22 --> Total execution time: 0.0832
INFO - 2025-05-25 15:04:26 --> Config Class Initialized
INFO - 2025-05-25 15:04:26 --> Hooks Class Initialized
DEBUG - 2025-05-25 15:04:26 --> UTF-8 Support Enabled
INFO - 2025-05-25 15:04:26 --> Utf8 Class Initialized
INFO - 2025-05-25 15:04:26 --> URI Class Initialized
INFO - 2025-05-25 15:04:26 --> Router Class Initialized
INFO - 2025-05-25 15:04:26 --> Output Class Initialized
INFO - 2025-05-25 15:04:26 --> Security Class Initialized
DEBUG - 2025-05-25 15:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 15:04:26 --> Input Class Initialized
INFO - 2025-05-25 15:04:26 --> Language Class Initialized
INFO - 2025-05-25 15:04:26 --> Loader Class Initialized
INFO - 2025-05-25 15:04:26 --> Helper loaded: url_helper
INFO - 2025-05-25 15:04:26 --> Helper loaded: form_helper
INFO - 2025-05-25 15:04:26 --> Database Driver Class Initialized
DEBUG - 2025-05-25 15:04:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 15:04:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 15:04:26 --> Controller Class Initialized
INFO - 2025-05-25 15:04:26 --> Model "User_model" initialized
INFO - 2025-05-25 15:04:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-25 15:04:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-25 15:04:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-25 15:04:26 --> Final output sent to browser
DEBUG - 2025-05-25 15:04:26 --> Total execution time: 0.0814
INFO - 2025-05-25 15:05:37 --> Config Class Initialized
INFO - 2025-05-25 15:05:37 --> Hooks Class Initialized
DEBUG - 2025-05-25 15:05:37 --> UTF-8 Support Enabled
INFO - 2025-05-25 15:05:37 --> Utf8 Class Initialized
INFO - 2025-05-25 15:05:37 --> URI Class Initialized
INFO - 2025-05-25 15:05:37 --> Router Class Initialized
INFO - 2025-05-25 15:05:37 --> Output Class Initialized
INFO - 2025-05-25 15:05:37 --> Security Class Initialized
DEBUG - 2025-05-25 15:05:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 15:05:37 --> Input Class Initialized
INFO - 2025-05-25 15:05:37 --> Language Class Initialized
INFO - 2025-05-25 15:05:37 --> Loader Class Initialized
INFO - 2025-05-25 15:05:37 --> Helper loaded: url_helper
INFO - 2025-05-25 15:05:37 --> Helper loaded: form_helper
INFO - 2025-05-25 15:05:37 --> Database Driver Class Initialized
DEBUG - 2025-05-25 15:05:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 15:05:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 15:05:37 --> Controller Class Initialized
INFO - 2025-05-25 15:05:37 --> Model "User_model" initialized
INFO - 2025-05-25 15:05:37 --> Model "Progress_model" initialized
INFO - 2025-05-25 15:05:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 15:05:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 15:05:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-25 15:05:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 15:05:37 --> Final output sent to browser
DEBUG - 2025-05-25 15:05:37 --> Total execution time: 0.0846
INFO - 2025-05-25 15:05:57 --> Config Class Initialized
INFO - 2025-05-25 15:05:57 --> Hooks Class Initialized
DEBUG - 2025-05-25 15:05:57 --> UTF-8 Support Enabled
INFO - 2025-05-25 15:05:57 --> Utf8 Class Initialized
INFO - 2025-05-25 15:05:57 --> URI Class Initialized
INFO - 2025-05-25 15:05:57 --> Router Class Initialized
INFO - 2025-05-25 15:05:57 --> Output Class Initialized
INFO - 2025-05-25 15:05:57 --> Security Class Initialized
DEBUG - 2025-05-25 15:05:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 15:05:57 --> Input Class Initialized
INFO - 2025-05-25 15:05:57 --> Language Class Initialized
INFO - 2025-05-25 15:05:57 --> Loader Class Initialized
INFO - 2025-05-25 15:05:57 --> Helper loaded: url_helper
INFO - 2025-05-25 15:05:57 --> Helper loaded: form_helper
INFO - 2025-05-25 15:05:57 --> Database Driver Class Initialized
DEBUG - 2025-05-25 15:05:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 15:05:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 15:05:57 --> Controller Class Initialized
INFO - 2025-05-25 15:05:57 --> Model "User_model" initialized
INFO - 2025-05-25 15:05:57 --> Config Class Initialized
INFO - 2025-05-25 15:05:57 --> Hooks Class Initialized
DEBUG - 2025-05-25 15:05:57 --> UTF-8 Support Enabled
INFO - 2025-05-25 15:05:57 --> Utf8 Class Initialized
INFO - 2025-05-25 15:05:57 --> URI Class Initialized
INFO - 2025-05-25 15:05:57 --> Router Class Initialized
INFO - 2025-05-25 15:05:57 --> Output Class Initialized
INFO - 2025-05-25 15:05:57 --> Security Class Initialized
DEBUG - 2025-05-25 15:05:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 15:05:57 --> Input Class Initialized
INFO - 2025-05-25 15:05:57 --> Language Class Initialized
INFO - 2025-05-25 15:05:57 --> Loader Class Initialized
INFO - 2025-05-25 15:05:57 --> Helper loaded: url_helper
INFO - 2025-05-25 15:05:57 --> Helper loaded: form_helper
INFO - 2025-05-25 15:05:57 --> Database Driver Class Initialized
DEBUG - 2025-05-25 15:05:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 15:05:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 15:05:57 --> Controller Class Initialized
INFO - 2025-05-25 15:05:57 --> Model "User_model" initialized
INFO - 2025-05-25 15:05:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-25 15:05:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-25 15:05:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-25 15:05:57 --> Final output sent to browser
DEBUG - 2025-05-25 15:05:57 --> Total execution time: 0.0551
INFO - 2025-05-25 15:06:40 --> Config Class Initialized
INFO - 2025-05-25 15:06:40 --> Hooks Class Initialized
DEBUG - 2025-05-25 15:06:40 --> UTF-8 Support Enabled
INFO - 2025-05-25 15:06:40 --> Utf8 Class Initialized
INFO - 2025-05-25 15:06:40 --> URI Class Initialized
INFO - 2025-05-25 15:06:40 --> Router Class Initialized
INFO - 2025-05-25 15:06:40 --> Output Class Initialized
INFO - 2025-05-25 15:06:40 --> Security Class Initialized
DEBUG - 2025-05-25 15:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 15:06:40 --> Input Class Initialized
INFO - 2025-05-25 15:06:40 --> Language Class Initialized
INFO - 2025-05-25 15:06:40 --> Loader Class Initialized
INFO - 2025-05-25 15:06:40 --> Helper loaded: url_helper
INFO - 2025-05-25 15:06:40 --> Helper loaded: form_helper
INFO - 2025-05-25 15:06:40 --> Database Driver Class Initialized
DEBUG - 2025-05-25 15:06:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 15:06:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 15:06:40 --> Controller Class Initialized
INFO - 2025-05-25 15:06:40 --> Model "User_model" initialized
INFO - 2025-05-25 15:06:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-25 15:06:40 --> Final output sent to browser
DEBUG - 2025-05-25 15:06:40 --> Total execution time: 0.0743
INFO - 2025-05-25 15:06:48 --> Config Class Initialized
INFO - 2025-05-25 15:06:48 --> Hooks Class Initialized
DEBUG - 2025-05-25 15:06:48 --> UTF-8 Support Enabled
INFO - 2025-05-25 15:06:48 --> Utf8 Class Initialized
INFO - 2025-05-25 15:06:48 --> URI Class Initialized
INFO - 2025-05-25 15:06:48 --> Router Class Initialized
INFO - 2025-05-25 15:06:48 --> Output Class Initialized
INFO - 2025-05-25 15:06:48 --> Security Class Initialized
DEBUG - 2025-05-25 15:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 15:06:48 --> Input Class Initialized
INFO - 2025-05-25 15:06:48 --> Language Class Initialized
INFO - 2025-05-25 15:06:48 --> Loader Class Initialized
INFO - 2025-05-25 15:06:48 --> Helper loaded: url_helper
INFO - 2025-05-25 15:06:48 --> Helper loaded: form_helper
INFO - 2025-05-25 15:06:48 --> Database Driver Class Initialized
DEBUG - 2025-05-25 15:06:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 15:06:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 15:06:49 --> Controller Class Initialized
INFO - 2025-05-25 15:06:49 --> Model "User_model" initialized
INFO - 2025-05-25 15:06:49 --> Config Class Initialized
INFO - 2025-05-25 15:06:49 --> Hooks Class Initialized
DEBUG - 2025-05-25 15:06:49 --> UTF-8 Support Enabled
INFO - 2025-05-25 15:06:49 --> Utf8 Class Initialized
INFO - 2025-05-25 15:06:49 --> URI Class Initialized
INFO - 2025-05-25 15:06:49 --> Router Class Initialized
INFO - 2025-05-25 15:06:49 --> Output Class Initialized
INFO - 2025-05-25 15:06:49 --> Security Class Initialized
DEBUG - 2025-05-25 15:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 15:06:49 --> Input Class Initialized
INFO - 2025-05-25 15:06:49 --> Language Class Initialized
INFO - 2025-05-25 15:06:49 --> Loader Class Initialized
INFO - 2025-05-25 15:06:49 --> Helper loaded: url_helper
INFO - 2025-05-25 15:06:49 --> Helper loaded: form_helper
INFO - 2025-05-25 15:06:49 --> Database Driver Class Initialized
DEBUG - 2025-05-25 15:06:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 15:06:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 15:06:49 --> Controller Class Initialized
INFO - 2025-05-25 15:06:49 --> Model "User_model" initialized
INFO - 2025-05-25 15:06:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-25 15:06:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-25 15:06:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-25 15:06:49 --> Final output sent to browser
DEBUG - 2025-05-25 15:06:49 --> Total execution time: 0.0616
INFO - 2025-05-25 15:06:51 --> Config Class Initialized
INFO - 2025-05-25 15:06:51 --> Hooks Class Initialized
DEBUG - 2025-05-25 15:06:51 --> UTF-8 Support Enabled
INFO - 2025-05-25 15:06:51 --> Utf8 Class Initialized
INFO - 2025-05-25 15:06:51 --> URI Class Initialized
INFO - 2025-05-25 15:06:51 --> Router Class Initialized
INFO - 2025-05-25 15:06:51 --> Output Class Initialized
INFO - 2025-05-25 15:06:51 --> Security Class Initialized
DEBUG - 2025-05-25 15:06:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 15:06:51 --> Input Class Initialized
INFO - 2025-05-25 15:06:51 --> Language Class Initialized
INFO - 2025-05-25 15:06:51 --> Loader Class Initialized
INFO - 2025-05-25 15:06:51 --> Helper loaded: url_helper
INFO - 2025-05-25 15:06:51 --> Helper loaded: form_helper
INFO - 2025-05-25 15:06:51 --> Database Driver Class Initialized
DEBUG - 2025-05-25 15:06:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 15:06:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 15:06:51 --> Controller Class Initialized
INFO - 2025-05-25 15:06:51 --> Model "User_model" initialized
INFO - 2025-05-25 15:06:51 --> Model "Progress_model" initialized
INFO - 2025-05-25 15:06:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 15:06:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 15:06:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-25 15:06:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 15:06:51 --> Final output sent to browser
DEBUG - 2025-05-25 15:06:51 --> Total execution time: 0.0778
INFO - 2025-05-25 15:17:50 --> Config Class Initialized
INFO - 2025-05-25 15:17:50 --> Hooks Class Initialized
DEBUG - 2025-05-25 15:17:50 --> UTF-8 Support Enabled
INFO - 2025-05-25 15:17:50 --> Utf8 Class Initialized
INFO - 2025-05-25 15:17:50 --> URI Class Initialized
INFO - 2025-05-25 15:17:50 --> Router Class Initialized
INFO - 2025-05-25 15:17:50 --> Output Class Initialized
INFO - 2025-05-25 15:17:50 --> Security Class Initialized
DEBUG - 2025-05-25 15:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 15:17:50 --> Input Class Initialized
INFO - 2025-05-25 15:17:50 --> Language Class Initialized
INFO - 2025-05-25 15:17:50 --> Loader Class Initialized
INFO - 2025-05-25 15:17:50 --> Helper loaded: url_helper
INFO - 2025-05-25 15:17:50 --> Helper loaded: form_helper
INFO - 2025-05-25 15:17:50 --> Database Driver Class Initialized
DEBUG - 2025-05-25 15:17:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 15:17:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 15:17:50 --> Controller Class Initialized
INFO - 2025-05-25 15:17:50 --> Model "Progress_model" initialized
INFO - 2025-05-25 15:17:50 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 15:17:50 --> Model "User_model" initialized
INFO - 2025-05-25 15:17:50 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 15:17:50 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 15:17:50 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-25 15:17:50 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 15:17:50 --> Final output sent to browser
DEBUG - 2025-05-25 15:17:50 --> Total execution time: 0.0890
INFO - 2025-05-25 15:17:57 --> Config Class Initialized
INFO - 2025-05-25 15:17:57 --> Hooks Class Initialized
DEBUG - 2025-05-25 15:17:57 --> UTF-8 Support Enabled
INFO - 2025-05-25 15:17:57 --> Utf8 Class Initialized
INFO - 2025-05-25 15:17:57 --> URI Class Initialized
INFO - 2025-05-25 15:17:57 --> Router Class Initialized
INFO - 2025-05-25 15:17:57 --> Output Class Initialized
INFO - 2025-05-25 15:17:57 --> Security Class Initialized
DEBUG - 2025-05-25 15:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 15:17:57 --> Input Class Initialized
INFO - 2025-05-25 15:17:57 --> Language Class Initialized
INFO - 2025-05-25 15:17:57 --> Loader Class Initialized
INFO - 2025-05-25 15:17:57 --> Helper loaded: url_helper
INFO - 2025-05-25 15:17:57 --> Helper loaded: form_helper
INFO - 2025-05-25 15:17:57 --> Database Driver Class Initialized
DEBUG - 2025-05-25 15:17:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 15:17:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 15:17:57 --> Controller Class Initialized
INFO - 2025-05-25 15:17:57 --> Model "Progress_model" initialized
INFO - 2025-05-25 15:17:57 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 15:17:57 --> Model "User_model" initialized
INFO - 2025-05-25 15:17:57 --> Final output sent to browser
DEBUG - 2025-05-25 15:17:57 --> Total execution time: 0.0767
INFO - 2025-05-25 15:18:02 --> Config Class Initialized
INFO - 2025-05-25 15:18:02 --> Hooks Class Initialized
DEBUG - 2025-05-25 15:18:02 --> UTF-8 Support Enabled
INFO - 2025-05-25 15:18:02 --> Utf8 Class Initialized
INFO - 2025-05-25 15:18:02 --> URI Class Initialized
INFO - 2025-05-25 15:18:02 --> Router Class Initialized
INFO - 2025-05-25 15:18:02 --> Output Class Initialized
INFO - 2025-05-25 15:18:02 --> Security Class Initialized
DEBUG - 2025-05-25 15:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 15:18:02 --> Input Class Initialized
INFO - 2025-05-25 15:18:02 --> Language Class Initialized
INFO - 2025-05-25 15:18:02 --> Loader Class Initialized
INFO - 2025-05-25 15:18:02 --> Helper loaded: url_helper
INFO - 2025-05-25 15:18:02 --> Helper loaded: form_helper
INFO - 2025-05-25 15:18:02 --> Database Driver Class Initialized
DEBUG - 2025-05-25 15:18:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 15:18:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 15:18:02 --> Controller Class Initialized
INFO - 2025-05-25 15:18:02 --> Model "Progress_model" initialized
INFO - 2025-05-25 15:18:02 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 15:18:02 --> Model "User_model" initialized
INFO - 2025-05-25 15:18:02 --> Final output sent to browser
DEBUG - 2025-05-25 15:18:02 --> Total execution time: 0.0828
INFO - 2025-05-25 15:18:05 --> Config Class Initialized
INFO - 2025-05-25 15:18:05 --> Hooks Class Initialized
DEBUG - 2025-05-25 15:18:05 --> UTF-8 Support Enabled
INFO - 2025-05-25 15:18:05 --> Utf8 Class Initialized
INFO - 2025-05-25 15:18:05 --> URI Class Initialized
INFO - 2025-05-25 15:18:05 --> Router Class Initialized
INFO - 2025-05-25 15:18:05 --> Output Class Initialized
INFO - 2025-05-25 15:18:05 --> Security Class Initialized
DEBUG - 2025-05-25 15:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 15:18:05 --> Input Class Initialized
INFO - 2025-05-25 15:18:05 --> Language Class Initialized
INFO - 2025-05-25 15:18:05 --> Loader Class Initialized
INFO - 2025-05-25 15:18:05 --> Helper loaded: url_helper
INFO - 2025-05-25 15:18:05 --> Helper loaded: form_helper
INFO - 2025-05-25 15:18:05 --> Database Driver Class Initialized
DEBUG - 2025-05-25 15:18:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 15:18:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 15:18:05 --> Controller Class Initialized
INFO - 2025-05-25 15:18:05 --> Model "Progress_model" initialized
INFO - 2025-05-25 15:18:05 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 15:18:05 --> Model "User_model" initialized
INFO - 2025-05-25 15:18:05 --> Final output sent to browser
DEBUG - 2025-05-25 15:18:05 --> Total execution time: 0.0777
INFO - 2025-05-25 15:18:08 --> Config Class Initialized
INFO - 2025-05-25 15:18:08 --> Hooks Class Initialized
DEBUG - 2025-05-25 15:18:08 --> UTF-8 Support Enabled
INFO - 2025-05-25 15:18:08 --> Utf8 Class Initialized
INFO - 2025-05-25 15:18:08 --> URI Class Initialized
INFO - 2025-05-25 15:18:08 --> Router Class Initialized
INFO - 2025-05-25 15:18:08 --> Output Class Initialized
INFO - 2025-05-25 15:18:08 --> Security Class Initialized
DEBUG - 2025-05-25 15:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 15:18:08 --> Input Class Initialized
INFO - 2025-05-25 15:18:08 --> Language Class Initialized
INFO - 2025-05-25 15:18:08 --> Loader Class Initialized
INFO - 2025-05-25 15:18:08 --> Helper loaded: url_helper
INFO - 2025-05-25 15:18:08 --> Helper loaded: form_helper
INFO - 2025-05-25 15:18:08 --> Database Driver Class Initialized
DEBUG - 2025-05-25 15:18:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 15:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 15:18:08 --> Controller Class Initialized
INFO - 2025-05-25 15:18:08 --> Model "Progress_model" initialized
INFO - 2025-05-25 15:18:08 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 15:18:08 --> Model "User_model" initialized
INFO - 2025-05-25 15:18:08 --> Final output sent to browser
DEBUG - 2025-05-25 15:18:08 --> Total execution time: 0.0887
INFO - 2025-05-25 15:18:10 --> Config Class Initialized
INFO - 2025-05-25 15:18:10 --> Hooks Class Initialized
DEBUG - 2025-05-25 15:18:10 --> UTF-8 Support Enabled
INFO - 2025-05-25 15:18:10 --> Utf8 Class Initialized
INFO - 2025-05-25 15:18:10 --> URI Class Initialized
INFO - 2025-05-25 15:18:10 --> Router Class Initialized
INFO - 2025-05-25 15:18:10 --> Output Class Initialized
INFO - 2025-05-25 15:18:10 --> Security Class Initialized
DEBUG - 2025-05-25 15:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 15:18:10 --> Input Class Initialized
INFO - 2025-05-25 15:18:10 --> Language Class Initialized
INFO - 2025-05-25 15:18:10 --> Loader Class Initialized
INFO - 2025-05-25 15:18:10 --> Helper loaded: url_helper
INFO - 2025-05-25 15:18:10 --> Helper loaded: form_helper
INFO - 2025-05-25 15:18:10 --> Database Driver Class Initialized
DEBUG - 2025-05-25 15:18:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 15:18:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 15:18:10 --> Controller Class Initialized
INFO - 2025-05-25 15:18:10 --> Model "Progress_model" initialized
INFO - 2025-05-25 15:18:10 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 15:18:10 --> Model "User_model" initialized
INFO - 2025-05-25 15:18:10 --> Final output sent to browser
DEBUG - 2025-05-25 15:18:10 --> Total execution time: 0.0771
INFO - 2025-05-25 15:18:12 --> Config Class Initialized
INFO - 2025-05-25 15:18:12 --> Hooks Class Initialized
DEBUG - 2025-05-25 15:18:12 --> UTF-8 Support Enabled
INFO - 2025-05-25 15:18:12 --> Utf8 Class Initialized
INFO - 2025-05-25 15:18:12 --> URI Class Initialized
INFO - 2025-05-25 15:18:12 --> Router Class Initialized
INFO - 2025-05-25 15:18:12 --> Output Class Initialized
INFO - 2025-05-25 15:18:12 --> Security Class Initialized
DEBUG - 2025-05-25 15:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 15:18:12 --> Input Class Initialized
INFO - 2025-05-25 15:18:12 --> Language Class Initialized
INFO - 2025-05-25 15:18:12 --> Loader Class Initialized
INFO - 2025-05-25 15:18:12 --> Helper loaded: url_helper
INFO - 2025-05-25 15:18:12 --> Helper loaded: form_helper
INFO - 2025-05-25 15:18:12 --> Database Driver Class Initialized
DEBUG - 2025-05-25 15:18:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 15:18:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 15:18:12 --> Controller Class Initialized
INFO - 2025-05-25 15:18:12 --> Model "Progress_model" initialized
INFO - 2025-05-25 15:18:12 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 15:18:12 --> Model "User_model" initialized
INFO - 2025-05-25 15:18:12 --> Final output sent to browser
DEBUG - 2025-05-25 15:18:12 --> Total execution time: 0.0722
INFO - 2025-05-25 15:18:14 --> Config Class Initialized
INFO - 2025-05-25 15:18:14 --> Hooks Class Initialized
DEBUG - 2025-05-25 15:18:14 --> UTF-8 Support Enabled
INFO - 2025-05-25 15:18:14 --> Utf8 Class Initialized
INFO - 2025-05-25 15:18:14 --> URI Class Initialized
INFO - 2025-05-25 15:18:14 --> Router Class Initialized
INFO - 2025-05-25 15:18:14 --> Output Class Initialized
INFO - 2025-05-25 15:18:14 --> Security Class Initialized
DEBUG - 2025-05-25 15:18:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 15:18:14 --> Input Class Initialized
INFO - 2025-05-25 15:18:14 --> Language Class Initialized
INFO - 2025-05-25 15:18:14 --> Loader Class Initialized
INFO - 2025-05-25 15:18:14 --> Helper loaded: url_helper
INFO - 2025-05-25 15:18:14 --> Helper loaded: form_helper
INFO - 2025-05-25 15:18:14 --> Database Driver Class Initialized
DEBUG - 2025-05-25 15:18:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 15:18:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 15:18:14 --> Controller Class Initialized
INFO - 2025-05-25 15:18:14 --> Model "Progress_model" initialized
INFO - 2025-05-25 15:18:14 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 15:18:14 --> Model "User_model" initialized
INFO - 2025-05-25 15:18:14 --> Final output sent to browser
DEBUG - 2025-05-25 15:18:14 --> Total execution time: 0.0821
INFO - 2025-05-25 15:18:17 --> Config Class Initialized
INFO - 2025-05-25 15:18:17 --> Hooks Class Initialized
DEBUG - 2025-05-25 15:18:17 --> UTF-8 Support Enabled
INFO - 2025-05-25 15:18:17 --> Utf8 Class Initialized
INFO - 2025-05-25 15:18:17 --> URI Class Initialized
INFO - 2025-05-25 15:18:17 --> Router Class Initialized
INFO - 2025-05-25 15:18:17 --> Output Class Initialized
INFO - 2025-05-25 15:18:17 --> Security Class Initialized
DEBUG - 2025-05-25 15:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 15:18:17 --> Input Class Initialized
INFO - 2025-05-25 15:18:17 --> Language Class Initialized
INFO - 2025-05-25 15:18:17 --> Loader Class Initialized
INFO - 2025-05-25 15:18:17 --> Helper loaded: url_helper
INFO - 2025-05-25 15:18:17 --> Helper loaded: form_helper
INFO - 2025-05-25 15:18:17 --> Database Driver Class Initialized
DEBUG - 2025-05-25 15:18:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 15:18:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 15:18:17 --> Controller Class Initialized
INFO - 2025-05-25 15:18:17 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 15:18:17 --> Model "User_model" initialized
INFO - 2025-05-25 15:18:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 15:18:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 15:18:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-05-25 15:18:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 15:18:17 --> Final output sent to browser
DEBUG - 2025-05-25 15:18:17 --> Total execution time: 0.0800
INFO - 2025-05-25 15:18:27 --> Config Class Initialized
INFO - 2025-05-25 15:18:27 --> Hooks Class Initialized
DEBUG - 2025-05-25 15:18:27 --> UTF-8 Support Enabled
INFO - 2025-05-25 15:18:27 --> Utf8 Class Initialized
INFO - 2025-05-25 15:18:27 --> URI Class Initialized
INFO - 2025-05-25 15:18:27 --> Router Class Initialized
INFO - 2025-05-25 15:18:27 --> Output Class Initialized
INFO - 2025-05-25 15:18:27 --> Security Class Initialized
DEBUG - 2025-05-25 15:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 15:18:27 --> Input Class Initialized
INFO - 2025-05-25 15:18:27 --> Language Class Initialized
INFO - 2025-05-25 15:18:27 --> Loader Class Initialized
INFO - 2025-05-25 15:18:27 --> Helper loaded: url_helper
INFO - 2025-05-25 15:18:27 --> Helper loaded: form_helper
INFO - 2025-05-25 15:18:27 --> Database Driver Class Initialized
DEBUG - 2025-05-25 15:18:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 15:18:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 15:18:27 --> Controller Class Initialized
INFO - 2025-05-25 15:18:27 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 15:18:27 --> Model "User_model" initialized
INFO - 2025-05-25 15:18:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 15:18:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 15:18:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-05-25 15:18:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 15:18:27 --> Final output sent to browser
DEBUG - 2025-05-25 15:18:27 --> Total execution time: 0.0701
INFO - 2025-05-25 15:18:29 --> Config Class Initialized
INFO - 2025-05-25 15:18:29 --> Hooks Class Initialized
DEBUG - 2025-05-25 15:18:29 --> UTF-8 Support Enabled
INFO - 2025-05-25 15:18:29 --> Utf8 Class Initialized
INFO - 2025-05-25 15:18:29 --> URI Class Initialized
INFO - 2025-05-25 15:18:29 --> Router Class Initialized
INFO - 2025-05-25 15:18:29 --> Output Class Initialized
INFO - 2025-05-25 15:18:29 --> Security Class Initialized
DEBUG - 2025-05-25 15:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 15:18:29 --> Input Class Initialized
INFO - 2025-05-25 15:18:29 --> Language Class Initialized
INFO - 2025-05-25 15:18:29 --> Loader Class Initialized
INFO - 2025-05-25 15:18:29 --> Helper loaded: url_helper
INFO - 2025-05-25 15:18:29 --> Helper loaded: form_helper
INFO - 2025-05-25 15:18:29 --> Database Driver Class Initialized
DEBUG - 2025-05-25 15:18:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 15:18:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 15:18:29 --> Controller Class Initialized
INFO - 2025-05-25 15:18:29 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 15:18:29 --> Model "User_model" initialized
INFO - 2025-05-25 15:18:29 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 15:18:29 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 15:18:29 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/menu.php
INFO - 2025-05-25 15:18:29 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 15:18:29 --> Final output sent to browser
DEBUG - 2025-05-25 15:18:29 --> Total execution time: 0.0822
INFO - 2025-05-25 15:18:39 --> Config Class Initialized
INFO - 2025-05-25 15:18:39 --> Hooks Class Initialized
DEBUG - 2025-05-25 15:18:39 --> UTF-8 Support Enabled
INFO - 2025-05-25 15:18:39 --> Utf8 Class Initialized
INFO - 2025-05-25 15:18:39 --> URI Class Initialized
INFO - 2025-05-25 15:18:39 --> Router Class Initialized
INFO - 2025-05-25 15:18:39 --> Output Class Initialized
INFO - 2025-05-25 15:18:39 --> Security Class Initialized
DEBUG - 2025-05-25 15:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 15:18:39 --> Input Class Initialized
INFO - 2025-05-25 15:18:39 --> Language Class Initialized
INFO - 2025-05-25 15:18:39 --> Loader Class Initialized
INFO - 2025-05-25 15:18:39 --> Helper loaded: url_helper
INFO - 2025-05-25 15:18:39 --> Helper loaded: form_helper
INFO - 2025-05-25 15:18:39 --> Database Driver Class Initialized
DEBUG - 2025-05-25 15:18:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 15:18:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 15:18:39 --> Controller Class Initialized
INFO - 2025-05-25 15:18:39 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 15:18:39 --> Model "User_model" initialized
INFO - 2025-05-25 15:18:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 15:18:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 15:18:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/start.php
INFO - 2025-05-25 15:18:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 15:18:39 --> Final output sent to browser
DEBUG - 2025-05-25 15:18:39 --> Total execution time: 0.0693
INFO - 2025-05-25 15:19:01 --> Config Class Initialized
INFO - 2025-05-25 15:19:01 --> Hooks Class Initialized
DEBUG - 2025-05-25 15:19:01 --> UTF-8 Support Enabled
INFO - 2025-05-25 15:19:01 --> Utf8 Class Initialized
INFO - 2025-05-25 15:19:01 --> URI Class Initialized
INFO - 2025-05-25 15:19:01 --> Router Class Initialized
INFO - 2025-05-25 15:19:02 --> Output Class Initialized
INFO - 2025-05-25 15:19:02 --> Security Class Initialized
DEBUG - 2025-05-25 15:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 15:19:02 --> Input Class Initialized
INFO - 2025-05-25 15:19:02 --> Language Class Initialized
INFO - 2025-05-25 15:19:02 --> Loader Class Initialized
INFO - 2025-05-25 15:19:02 --> Helper loaded: url_helper
INFO - 2025-05-25 15:19:02 --> Helper loaded: form_helper
INFO - 2025-05-25 15:19:02 --> Database Driver Class Initialized
DEBUG - 2025-05-25 15:19:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 15:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 15:19:02 --> Controller Class Initialized
INFO - 2025-05-25 15:19:02 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 15:19:02 --> Model "User_model" initialized
INFO - 2025-05-25 15:19:02 --> Final output sent to browser
DEBUG - 2025-05-25 15:19:02 --> Total execution time: 0.0975
INFO - 2025-05-25 15:19:06 --> Config Class Initialized
INFO - 2025-05-25 15:19:06 --> Hooks Class Initialized
DEBUG - 2025-05-25 15:19:06 --> UTF-8 Support Enabled
INFO - 2025-05-25 15:19:06 --> Utf8 Class Initialized
INFO - 2025-05-25 15:19:06 --> URI Class Initialized
INFO - 2025-05-25 15:19:06 --> Router Class Initialized
INFO - 2025-05-25 15:19:06 --> Output Class Initialized
INFO - 2025-05-25 15:19:06 --> Security Class Initialized
DEBUG - 2025-05-25 15:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 15:19:06 --> Input Class Initialized
INFO - 2025-05-25 15:19:06 --> Language Class Initialized
INFO - 2025-05-25 15:19:06 --> Loader Class Initialized
INFO - 2025-05-25 15:19:06 --> Helper loaded: url_helper
INFO - 2025-05-25 15:19:06 --> Helper loaded: form_helper
INFO - 2025-05-25 15:19:06 --> Database Driver Class Initialized
DEBUG - 2025-05-25 15:19:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 15:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 15:19:06 --> Controller Class Initialized
INFO - 2025-05-25 15:19:06 --> Model "Progress_model" initialized
INFO - 2025-05-25 15:19:06 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 15:19:06 --> Model "User_model" initialized
INFO - 2025-05-25 15:19:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 15:19:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 15:19:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-25 15:19:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 15:19:06 --> Final output sent to browser
DEBUG - 2025-05-25 15:19:06 --> Total execution time: 0.0905
INFO - 2025-05-25 15:19:06 --> Config Class Initialized
INFO - 2025-05-25 15:19:06 --> Hooks Class Initialized
DEBUG - 2025-05-25 15:19:06 --> UTF-8 Support Enabled
INFO - 2025-05-25 15:19:06 --> Utf8 Class Initialized
INFO - 2025-05-25 15:19:06 --> URI Class Initialized
INFO - 2025-05-25 15:19:06 --> Router Class Initialized
INFO - 2025-05-25 15:19:06 --> Output Class Initialized
INFO - 2025-05-25 15:19:06 --> Security Class Initialized
DEBUG - 2025-05-25 15:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 15:19:06 --> Input Class Initialized
INFO - 2025-05-25 15:19:06 --> Language Class Initialized
INFO - 2025-05-25 15:19:06 --> Loader Class Initialized
INFO - 2025-05-25 15:19:06 --> Helper loaded: url_helper
INFO - 2025-05-25 15:19:06 --> Helper loaded: form_helper
INFO - 2025-05-25 15:19:06 --> Database Driver Class Initialized
DEBUG - 2025-05-25 15:19:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 15:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 15:19:06 --> Controller Class Initialized
INFO - 2025-05-25 15:19:06 --> Model "Progress_model" initialized
INFO - 2025-05-25 15:19:06 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 15:19:06 --> Model "User_model" initialized
INFO - 2025-05-25 15:19:06 --> Final output sent to browser
DEBUG - 2025-05-25 15:19:06 --> Total execution time: 0.0618
INFO - 2025-05-25 15:19:09 --> Config Class Initialized
INFO - 2025-05-25 15:19:09 --> Hooks Class Initialized
DEBUG - 2025-05-25 15:19:09 --> UTF-8 Support Enabled
INFO - 2025-05-25 15:19:09 --> Utf8 Class Initialized
INFO - 2025-05-25 15:19:09 --> URI Class Initialized
INFO - 2025-05-25 15:19:09 --> Router Class Initialized
INFO - 2025-05-25 15:19:09 --> Output Class Initialized
INFO - 2025-05-25 15:19:09 --> Security Class Initialized
DEBUG - 2025-05-25 15:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 15:19:09 --> Input Class Initialized
INFO - 2025-05-25 15:19:09 --> Language Class Initialized
INFO - 2025-05-25 15:19:09 --> Loader Class Initialized
INFO - 2025-05-25 15:19:09 --> Helper loaded: url_helper
INFO - 2025-05-25 15:19:09 --> Helper loaded: form_helper
INFO - 2025-05-25 15:19:09 --> Database Driver Class Initialized
DEBUG - 2025-05-25 15:19:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 15:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 15:19:09 --> Controller Class Initialized
INFO - 2025-05-25 15:19:09 --> Model "Progress_model" initialized
INFO - 2025-05-25 15:19:09 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 15:19:09 --> Model "User_model" initialized
INFO - 2025-05-25 15:19:09 --> Final output sent to browser
DEBUG - 2025-05-25 15:19:09 --> Total execution time: 0.0633
INFO - 2025-05-25 15:19:13 --> Config Class Initialized
INFO - 2025-05-25 15:19:13 --> Hooks Class Initialized
DEBUG - 2025-05-25 15:19:13 --> UTF-8 Support Enabled
INFO - 2025-05-25 15:19:13 --> Utf8 Class Initialized
INFO - 2025-05-25 15:19:13 --> URI Class Initialized
INFO - 2025-05-25 15:19:13 --> Router Class Initialized
INFO - 2025-05-25 15:19:13 --> Output Class Initialized
INFO - 2025-05-25 15:19:13 --> Security Class Initialized
DEBUG - 2025-05-25 15:19:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 15:19:13 --> Input Class Initialized
INFO - 2025-05-25 15:19:13 --> Language Class Initialized
INFO - 2025-05-25 15:19:13 --> Loader Class Initialized
INFO - 2025-05-25 15:19:13 --> Helper loaded: url_helper
INFO - 2025-05-25 15:19:13 --> Helper loaded: form_helper
INFO - 2025-05-25 15:19:13 --> Database Driver Class Initialized
DEBUG - 2025-05-25 15:19:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 15:19:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 15:19:13 --> Controller Class Initialized
INFO - 2025-05-25 15:19:13 --> Model "Progress_model" initialized
INFO - 2025-05-25 15:19:13 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 15:19:13 --> Model "User_model" initialized
INFO - 2025-05-25 15:19:13 --> Final output sent to browser
DEBUG - 2025-05-25 15:19:13 --> Total execution time: 0.0620
INFO - 2025-05-25 15:19:16 --> Config Class Initialized
INFO - 2025-05-25 15:19:16 --> Hooks Class Initialized
DEBUG - 2025-05-25 15:19:16 --> UTF-8 Support Enabled
INFO - 2025-05-25 15:19:16 --> Utf8 Class Initialized
INFO - 2025-05-25 15:19:16 --> URI Class Initialized
INFO - 2025-05-25 15:19:16 --> Router Class Initialized
INFO - 2025-05-25 15:19:16 --> Output Class Initialized
INFO - 2025-05-25 15:19:16 --> Security Class Initialized
DEBUG - 2025-05-25 15:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 15:19:16 --> Input Class Initialized
INFO - 2025-05-25 15:19:16 --> Language Class Initialized
INFO - 2025-05-25 15:19:16 --> Loader Class Initialized
INFO - 2025-05-25 15:19:16 --> Helper loaded: url_helper
INFO - 2025-05-25 15:19:16 --> Helper loaded: form_helper
INFO - 2025-05-25 15:19:16 --> Database Driver Class Initialized
DEBUG - 2025-05-25 15:19:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 15:19:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 15:19:16 --> Controller Class Initialized
INFO - 2025-05-25 15:19:16 --> Model "User_model" initialized
INFO - 2025-05-25 15:19:16 --> Model "Progress_model" initialized
INFO - 2025-05-25 15:19:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 15:19:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 15:19:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-25 15:19:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 15:19:16 --> Final output sent to browser
DEBUG - 2025-05-25 15:19:16 --> Total execution time: 0.1057
INFO - 2025-05-25 15:22:07 --> Config Class Initialized
INFO - 2025-05-25 15:22:07 --> Hooks Class Initialized
DEBUG - 2025-05-25 15:22:07 --> UTF-8 Support Enabled
INFO - 2025-05-25 15:22:07 --> Utf8 Class Initialized
INFO - 2025-05-25 15:22:07 --> URI Class Initialized
INFO - 2025-05-25 15:22:07 --> Router Class Initialized
INFO - 2025-05-25 15:22:07 --> Output Class Initialized
INFO - 2025-05-25 15:22:07 --> Security Class Initialized
DEBUG - 2025-05-25 15:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 15:22:07 --> Input Class Initialized
INFO - 2025-05-25 15:22:07 --> Language Class Initialized
INFO - 2025-05-25 15:22:07 --> Loader Class Initialized
INFO - 2025-05-25 15:22:07 --> Helper loaded: url_helper
INFO - 2025-05-25 15:22:07 --> Helper loaded: form_helper
INFO - 2025-05-25 15:22:07 --> Database Driver Class Initialized
DEBUG - 2025-05-25 15:22:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 15:22:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 15:22:07 --> Controller Class Initialized
INFO - 2025-05-25 15:22:07 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 15:22:07 --> Model "User_model" initialized
INFO - 2025-05-25 15:22:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 15:22:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 15:22:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-05-25 15:22:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 15:22:07 --> Final output sent to browser
DEBUG - 2025-05-25 15:22:07 --> Total execution time: 0.0631
INFO - 2025-05-25 15:22:14 --> Config Class Initialized
INFO - 2025-05-25 15:22:14 --> Hooks Class Initialized
DEBUG - 2025-05-25 15:22:14 --> UTF-8 Support Enabled
INFO - 2025-05-25 15:22:14 --> Utf8 Class Initialized
INFO - 2025-05-25 15:22:14 --> URI Class Initialized
INFO - 2025-05-25 15:22:14 --> Router Class Initialized
INFO - 2025-05-25 15:22:14 --> Output Class Initialized
INFO - 2025-05-25 15:22:14 --> Security Class Initialized
DEBUG - 2025-05-25 15:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 15:22:14 --> Input Class Initialized
INFO - 2025-05-25 15:22:14 --> Language Class Initialized
INFO - 2025-05-25 15:22:14 --> Loader Class Initialized
INFO - 2025-05-25 15:22:14 --> Helper loaded: url_helper
INFO - 2025-05-25 15:22:14 --> Helper loaded: form_helper
INFO - 2025-05-25 15:22:14 --> Database Driver Class Initialized
DEBUG - 2025-05-25 15:22:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 15:22:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 15:22:14 --> Controller Class Initialized
INFO - 2025-05-25 15:22:14 --> Model "User_model" initialized
INFO - 2025-05-25 15:22:14 --> Model "Progress_model" initialized
INFO - 2025-05-25 15:22:14 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 15:22:14 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 15:22:14 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-25 15:22:14 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 15:22:14 --> Final output sent to browser
DEBUG - 2025-05-25 15:22:14 --> Total execution time: 0.0866
INFO - 2025-05-25 15:22:22 --> Config Class Initialized
INFO - 2025-05-25 15:22:22 --> Hooks Class Initialized
DEBUG - 2025-05-25 15:22:22 --> UTF-8 Support Enabled
INFO - 2025-05-25 15:22:22 --> Utf8 Class Initialized
INFO - 2025-05-25 15:22:22 --> URI Class Initialized
INFO - 2025-05-25 15:22:22 --> Router Class Initialized
INFO - 2025-05-25 15:22:22 --> Output Class Initialized
INFO - 2025-05-25 15:22:22 --> Security Class Initialized
DEBUG - 2025-05-25 15:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 15:22:22 --> Input Class Initialized
INFO - 2025-05-25 15:22:22 --> Language Class Initialized
INFO - 2025-05-25 15:22:22 --> Loader Class Initialized
INFO - 2025-05-25 15:22:22 --> Helper loaded: url_helper
INFO - 2025-05-25 15:22:22 --> Helper loaded: form_helper
INFO - 2025-05-25 15:22:22 --> Database Driver Class Initialized
DEBUG - 2025-05-25 15:22:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 15:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 15:22:22 --> Controller Class Initialized
INFO - 2025-05-25 15:22:22 --> Model "User_model" initialized
INFO - 2025-05-25 15:22:22 --> Config Class Initialized
INFO - 2025-05-25 15:22:22 --> Hooks Class Initialized
DEBUG - 2025-05-25 15:22:22 --> UTF-8 Support Enabled
INFO - 2025-05-25 15:22:22 --> Utf8 Class Initialized
INFO - 2025-05-25 15:22:22 --> URI Class Initialized
INFO - 2025-05-25 15:22:22 --> Router Class Initialized
INFO - 2025-05-25 15:22:22 --> Output Class Initialized
INFO - 2025-05-25 15:22:22 --> Security Class Initialized
DEBUG - 2025-05-25 15:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 15:22:22 --> Input Class Initialized
INFO - 2025-05-25 15:22:22 --> Language Class Initialized
INFO - 2025-05-25 15:22:22 --> Loader Class Initialized
INFO - 2025-05-25 15:22:22 --> Helper loaded: url_helper
INFO - 2025-05-25 15:22:22 --> Helper loaded: form_helper
INFO - 2025-05-25 15:22:22 --> Database Driver Class Initialized
DEBUG - 2025-05-25 15:22:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 15:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 15:22:22 --> Controller Class Initialized
INFO - 2025-05-25 15:22:22 --> Model "User_model" initialized
INFO - 2025-05-25 15:22:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-25 15:22:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-25 15:22:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-25 15:22:22 --> Final output sent to browser
DEBUG - 2025-05-25 15:22:22 --> Total execution time: 0.0702
INFO - 2025-05-25 15:22:24 --> Config Class Initialized
INFO - 2025-05-25 15:22:24 --> Hooks Class Initialized
DEBUG - 2025-05-25 15:22:24 --> UTF-8 Support Enabled
INFO - 2025-05-25 15:22:24 --> Utf8 Class Initialized
INFO - 2025-05-25 15:22:24 --> URI Class Initialized
INFO - 2025-05-25 15:22:24 --> Router Class Initialized
INFO - 2025-05-25 15:22:24 --> Output Class Initialized
INFO - 2025-05-25 15:22:24 --> Security Class Initialized
DEBUG - 2025-05-25 15:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 15:22:24 --> Input Class Initialized
INFO - 2025-05-25 15:22:24 --> Language Class Initialized
INFO - 2025-05-25 15:22:24 --> Loader Class Initialized
INFO - 2025-05-25 15:22:24 --> Helper loaded: url_helper
INFO - 2025-05-25 15:22:24 --> Helper loaded: form_helper
INFO - 2025-05-25 15:22:24 --> Database Driver Class Initialized
DEBUG - 2025-05-25 15:22:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 15:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 15:22:24 --> Controller Class Initialized
INFO - 2025-05-25 15:22:24 --> Model "User_model" initialized
INFO - 2025-05-25 15:22:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-25 15:22:24 --> Final output sent to browser
DEBUG - 2025-05-25 15:22:24 --> Total execution time: 0.0704
INFO - 2025-05-25 15:22:29 --> Config Class Initialized
INFO - 2025-05-25 15:22:29 --> Hooks Class Initialized
DEBUG - 2025-05-25 15:22:29 --> UTF-8 Support Enabled
INFO - 2025-05-25 15:22:29 --> Utf8 Class Initialized
INFO - 2025-05-25 15:22:29 --> URI Class Initialized
INFO - 2025-05-25 15:22:29 --> Router Class Initialized
INFO - 2025-05-25 15:22:29 --> Output Class Initialized
INFO - 2025-05-25 15:22:29 --> Security Class Initialized
DEBUG - 2025-05-25 15:22:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 15:22:29 --> Input Class Initialized
INFO - 2025-05-25 15:22:29 --> Language Class Initialized
INFO - 2025-05-25 15:22:29 --> Loader Class Initialized
INFO - 2025-05-25 15:22:29 --> Helper loaded: url_helper
INFO - 2025-05-25 15:22:29 --> Helper loaded: form_helper
INFO - 2025-05-25 15:22:29 --> Database Driver Class Initialized
DEBUG - 2025-05-25 15:22:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 15:22:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 15:22:29 --> Controller Class Initialized
INFO - 2025-05-25 15:22:29 --> Model "User_model" initialized
INFO - 2025-05-25 15:22:29 --> Config Class Initialized
INFO - 2025-05-25 15:22:29 --> Hooks Class Initialized
DEBUG - 2025-05-25 15:22:29 --> UTF-8 Support Enabled
INFO - 2025-05-25 15:22:29 --> Utf8 Class Initialized
INFO - 2025-05-25 15:22:29 --> URI Class Initialized
INFO - 2025-05-25 15:22:29 --> Router Class Initialized
INFO - 2025-05-25 15:22:29 --> Output Class Initialized
INFO - 2025-05-25 15:22:29 --> Security Class Initialized
DEBUG - 2025-05-25 15:22:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 15:22:29 --> Input Class Initialized
INFO - 2025-05-25 15:22:29 --> Language Class Initialized
INFO - 2025-05-25 15:22:29 --> Loader Class Initialized
INFO - 2025-05-25 15:22:29 --> Helper loaded: url_helper
INFO - 2025-05-25 15:22:29 --> Helper loaded: form_helper
INFO - 2025-05-25 15:22:29 --> Database Driver Class Initialized
DEBUG - 2025-05-25 15:22:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 15:22:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 15:22:30 --> Controller Class Initialized
INFO - 2025-05-25 15:22:30 --> Model "User_model" initialized
INFO - 2025-05-25 15:22:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-25 15:22:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-25 15:22:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-25 15:22:30 --> Final output sent to browser
DEBUG - 2025-05-25 15:22:30 --> Total execution time: 0.0823
INFO - 2025-05-25 15:22:30 --> Config Class Initialized
INFO - 2025-05-25 15:22:30 --> Hooks Class Initialized
DEBUG - 2025-05-25 15:22:30 --> UTF-8 Support Enabled
INFO - 2025-05-25 15:22:30 --> Utf8 Class Initialized
INFO - 2025-05-25 15:22:30 --> URI Class Initialized
INFO - 2025-05-25 15:22:30 --> Router Class Initialized
INFO - 2025-05-25 15:22:30 --> Output Class Initialized
INFO - 2025-05-25 15:22:30 --> Security Class Initialized
DEBUG - 2025-05-25 15:22:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 15:22:30 --> Input Class Initialized
INFO - 2025-05-25 15:22:30 --> Language Class Initialized
INFO - 2025-05-25 15:22:30 --> Loader Class Initialized
INFO - 2025-05-25 15:22:30 --> Helper loaded: url_helper
INFO - 2025-05-25 15:22:30 --> Helper loaded: form_helper
INFO - 2025-05-25 15:22:30 --> Database Driver Class Initialized
DEBUG - 2025-05-25 15:22:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 15:22:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 15:22:30 --> Controller Class Initialized
INFO - 2025-05-25 15:22:30 --> Model "User_model" initialized
INFO - 2025-05-25 15:22:30 --> Model "Progress_model" initialized
INFO - 2025-05-25 15:22:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 15:22:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 15:22:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-25 15:22:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 15:22:30 --> Final output sent to browser
DEBUG - 2025-05-25 15:22:30 --> Total execution time: 0.0846
INFO - 2025-05-25 15:22:42 --> Config Class Initialized
INFO - 2025-05-25 15:22:42 --> Hooks Class Initialized
DEBUG - 2025-05-25 15:22:42 --> UTF-8 Support Enabled
INFO - 2025-05-25 15:22:42 --> Utf8 Class Initialized
INFO - 2025-05-25 15:22:42 --> URI Class Initialized
INFO - 2025-05-25 15:22:42 --> Router Class Initialized
INFO - 2025-05-25 15:22:42 --> Output Class Initialized
INFO - 2025-05-25 15:22:42 --> Security Class Initialized
DEBUG - 2025-05-25 15:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 15:22:42 --> Input Class Initialized
INFO - 2025-05-25 15:22:42 --> Language Class Initialized
INFO - 2025-05-25 15:22:42 --> Loader Class Initialized
INFO - 2025-05-25 15:22:42 --> Helper loaded: url_helper
INFO - 2025-05-25 15:22:42 --> Helper loaded: form_helper
INFO - 2025-05-25 15:22:42 --> Database Driver Class Initialized
DEBUG - 2025-05-25 15:22:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 15:22:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 15:22:42 --> Controller Class Initialized
INFO - 2025-05-25 15:22:42 --> Model "User_model" initialized
INFO - 2025-05-25 15:22:42 --> Config Class Initialized
INFO - 2025-05-25 15:22:42 --> Hooks Class Initialized
DEBUG - 2025-05-25 15:22:42 --> UTF-8 Support Enabled
INFO - 2025-05-25 15:22:42 --> Utf8 Class Initialized
INFO - 2025-05-25 15:22:42 --> URI Class Initialized
INFO - 2025-05-25 15:22:42 --> Router Class Initialized
INFO - 2025-05-25 15:22:42 --> Output Class Initialized
INFO - 2025-05-25 15:22:42 --> Security Class Initialized
DEBUG - 2025-05-25 15:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 15:22:42 --> Input Class Initialized
INFO - 2025-05-25 15:22:42 --> Language Class Initialized
INFO - 2025-05-25 15:22:42 --> Loader Class Initialized
INFO - 2025-05-25 15:22:42 --> Helper loaded: url_helper
INFO - 2025-05-25 15:22:42 --> Helper loaded: form_helper
INFO - 2025-05-25 15:22:42 --> Database Driver Class Initialized
DEBUG - 2025-05-25 15:22:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 15:22:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 15:22:42 --> Controller Class Initialized
INFO - 2025-05-25 15:22:42 --> Model "User_model" initialized
INFO - 2025-05-25 15:22:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-25 15:22:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-25 15:22:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-25 15:22:42 --> Final output sent to browser
DEBUG - 2025-05-25 15:22:42 --> Total execution time: 0.0598
INFO - 2025-05-25 15:52:39 --> Config Class Initialized
INFO - 2025-05-25 15:52:39 --> Hooks Class Initialized
DEBUG - 2025-05-25 15:52:39 --> UTF-8 Support Enabled
INFO - 2025-05-25 15:52:39 --> Utf8 Class Initialized
INFO - 2025-05-25 15:52:39 --> URI Class Initialized
DEBUG - 2025-05-25 15:52:39 --> No URI present. Default controller set.
INFO - 2025-05-25 15:52:39 --> Router Class Initialized
INFO - 2025-05-25 15:52:39 --> Output Class Initialized
INFO - 2025-05-25 15:52:39 --> Security Class Initialized
DEBUG - 2025-05-25 15:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 15:52:39 --> Input Class Initialized
INFO - 2025-05-25 15:52:39 --> Language Class Initialized
INFO - 2025-05-25 15:52:39 --> Loader Class Initialized
INFO - 2025-05-25 15:52:39 --> Helper loaded: url_helper
INFO - 2025-05-25 15:52:39 --> Helper loaded: form_helper
INFO - 2025-05-25 15:52:39 --> Database Driver Class Initialized
DEBUG - 2025-05-25 15:52:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 15:52:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 15:52:39 --> Controller Class Initialized
INFO - 2025-05-25 15:52:39 --> Model "User_model" initialized
INFO - 2025-05-25 15:52:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-25 15:52:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-25 15:52:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-25 15:52:39 --> Final output sent to browser
DEBUG - 2025-05-25 15:52:39 --> Total execution time: 0.1119
INFO - 2025-05-25 15:52:43 --> Config Class Initialized
INFO - 2025-05-25 15:52:43 --> Hooks Class Initialized
DEBUG - 2025-05-25 15:52:43 --> UTF-8 Support Enabled
INFO - 2025-05-25 15:52:43 --> Utf8 Class Initialized
INFO - 2025-05-25 15:52:43 --> URI Class Initialized
INFO - 2025-05-25 15:52:43 --> Router Class Initialized
INFO - 2025-05-25 15:52:43 --> Output Class Initialized
INFO - 2025-05-25 15:52:43 --> Security Class Initialized
DEBUG - 2025-05-25 15:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 15:52:43 --> Input Class Initialized
INFO - 2025-05-25 15:52:43 --> Language Class Initialized
INFO - 2025-05-25 15:52:43 --> Loader Class Initialized
INFO - 2025-05-25 15:52:43 --> Helper loaded: url_helper
INFO - 2025-05-25 15:52:43 --> Helper loaded: form_helper
INFO - 2025-05-25 15:52:43 --> Database Driver Class Initialized
DEBUG - 2025-05-25 15:52:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 15:52:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 15:52:43 --> Controller Class Initialized
INFO - 2025-05-25 15:52:43 --> Model "User_model" initialized
INFO - 2025-05-25 15:52:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-25 15:52:43 --> Final output sent to browser
DEBUG - 2025-05-25 15:52:43 --> Total execution time: 0.0800
INFO - 2025-05-25 15:52:53 --> Config Class Initialized
INFO - 2025-05-25 15:52:53 --> Hooks Class Initialized
DEBUG - 2025-05-25 15:52:53 --> UTF-8 Support Enabled
INFO - 2025-05-25 15:52:53 --> Utf8 Class Initialized
INFO - 2025-05-25 15:52:53 --> URI Class Initialized
INFO - 2025-05-25 15:52:53 --> Router Class Initialized
INFO - 2025-05-25 15:52:53 --> Output Class Initialized
INFO - 2025-05-25 15:52:53 --> Security Class Initialized
DEBUG - 2025-05-25 15:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 15:52:53 --> Input Class Initialized
INFO - 2025-05-25 15:52:53 --> Language Class Initialized
INFO - 2025-05-25 15:52:53 --> Loader Class Initialized
INFO - 2025-05-25 15:52:53 --> Helper loaded: url_helper
INFO - 2025-05-25 15:52:53 --> Helper loaded: form_helper
INFO - 2025-05-25 15:52:53 --> Database Driver Class Initialized
DEBUG - 2025-05-25 15:52:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 15:52:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 15:52:54 --> Controller Class Initialized
INFO - 2025-05-25 15:52:54 --> Model "User_model" initialized
INFO - 2025-05-25 15:52:54 --> Config Class Initialized
INFO - 2025-05-25 15:52:54 --> Hooks Class Initialized
DEBUG - 2025-05-25 15:52:54 --> UTF-8 Support Enabled
INFO - 2025-05-25 15:52:54 --> Utf8 Class Initialized
INFO - 2025-05-25 15:52:54 --> URI Class Initialized
INFO - 2025-05-25 15:52:54 --> Router Class Initialized
INFO - 2025-05-25 15:52:54 --> Output Class Initialized
INFO - 2025-05-25 15:52:54 --> Security Class Initialized
DEBUG - 2025-05-25 15:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 15:52:54 --> Input Class Initialized
INFO - 2025-05-25 15:52:54 --> Language Class Initialized
INFO - 2025-05-25 15:52:54 --> Loader Class Initialized
INFO - 2025-05-25 15:52:54 --> Helper loaded: url_helper
INFO - 2025-05-25 15:52:54 --> Helper loaded: form_helper
INFO - 2025-05-25 15:52:54 --> Database Driver Class Initialized
DEBUG - 2025-05-25 15:52:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 15:52:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 15:52:54 --> Controller Class Initialized
INFO - 2025-05-25 15:52:54 --> Model "User_model" initialized
INFO - 2025-05-25 15:52:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-25 15:52:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-25 15:52:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-25 15:52:54 --> Final output sent to browser
DEBUG - 2025-05-25 15:52:54 --> Total execution time: 0.0901
INFO - 2025-05-25 15:52:56 --> Config Class Initialized
INFO - 2025-05-25 15:52:56 --> Hooks Class Initialized
DEBUG - 2025-05-25 15:52:56 --> UTF-8 Support Enabled
INFO - 2025-05-25 15:52:56 --> Utf8 Class Initialized
INFO - 2025-05-25 15:52:56 --> URI Class Initialized
INFO - 2025-05-25 15:52:56 --> Router Class Initialized
INFO - 2025-05-25 15:52:56 --> Output Class Initialized
INFO - 2025-05-25 15:52:56 --> Security Class Initialized
DEBUG - 2025-05-25 15:52:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 15:52:56 --> Input Class Initialized
INFO - 2025-05-25 15:52:56 --> Language Class Initialized
INFO - 2025-05-25 15:52:56 --> Loader Class Initialized
INFO - 2025-05-25 15:52:56 --> Helper loaded: url_helper
INFO - 2025-05-25 15:52:56 --> Helper loaded: form_helper
INFO - 2025-05-25 15:52:56 --> Database Driver Class Initialized
DEBUG - 2025-05-25 15:52:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 15:52:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 15:52:56 --> Controller Class Initialized
INFO - 2025-05-25 15:52:56 --> Model "User_model" initialized
INFO - 2025-05-25 15:52:56 --> Model "Progress_model" initialized
INFO - 2025-05-25 15:52:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 15:52:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 15:52:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-25 15:52:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 15:52:56 --> Final output sent to browser
DEBUG - 2025-05-25 15:52:56 --> Total execution time: 0.1189
INFO - 2025-05-25 15:53:04 --> Config Class Initialized
INFO - 2025-05-25 15:53:04 --> Hooks Class Initialized
DEBUG - 2025-05-25 15:53:04 --> UTF-8 Support Enabled
INFO - 2025-05-25 15:53:04 --> Utf8 Class Initialized
INFO - 2025-05-25 15:53:04 --> URI Class Initialized
INFO - 2025-05-25 15:53:04 --> Router Class Initialized
INFO - 2025-05-25 15:53:04 --> Output Class Initialized
INFO - 2025-05-25 15:53:04 --> Security Class Initialized
DEBUG - 2025-05-25 15:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 15:53:04 --> Input Class Initialized
INFO - 2025-05-25 15:53:04 --> Language Class Initialized
INFO - 2025-05-25 15:53:04 --> Loader Class Initialized
INFO - 2025-05-25 15:53:04 --> Helper loaded: url_helper
INFO - 2025-05-25 15:53:04 --> Helper loaded: form_helper
INFO - 2025-05-25 15:53:04 --> Database Driver Class Initialized
DEBUG - 2025-05-25 15:53:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 15:53:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 15:53:04 --> Controller Class Initialized
INFO - 2025-05-25 15:53:04 --> Model "User_model" initialized
INFO - 2025-05-25 15:53:04 --> Model "Progress_model" initialized
INFO - 2025-05-25 15:53:04 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 15:53:04 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 15:53:04 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-25 15:53:04 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 15:53:04 --> Final output sent to browser
DEBUG - 2025-05-25 15:53:04 --> Total execution time: 0.0750
INFO - 2025-05-25 15:53:06 --> Config Class Initialized
INFO - 2025-05-25 15:53:06 --> Hooks Class Initialized
DEBUG - 2025-05-25 15:53:06 --> UTF-8 Support Enabled
INFO - 2025-05-25 15:53:06 --> Utf8 Class Initialized
INFO - 2025-05-25 15:53:06 --> URI Class Initialized
INFO - 2025-05-25 15:53:06 --> Router Class Initialized
INFO - 2025-05-25 15:53:06 --> Output Class Initialized
INFO - 2025-05-25 15:53:06 --> Security Class Initialized
DEBUG - 2025-05-25 15:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 15:53:06 --> Input Class Initialized
INFO - 2025-05-25 15:53:06 --> Language Class Initialized
INFO - 2025-05-25 15:53:06 --> Loader Class Initialized
INFO - 2025-05-25 15:53:06 --> Helper loaded: url_helper
INFO - 2025-05-25 15:53:06 --> Helper loaded: form_helper
INFO - 2025-05-25 15:53:06 --> Database Driver Class Initialized
DEBUG - 2025-05-25 15:53:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 15:53:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 15:53:06 --> Controller Class Initialized
INFO - 2025-05-25 15:53:06 --> Model "User_model" initialized
INFO - 2025-05-25 15:53:06 --> Model "Progress_model" initialized
INFO - 2025-05-25 15:53:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 15:53:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 15:53:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-25 15:53:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 15:53:06 --> Final output sent to browser
DEBUG - 2025-05-25 15:53:06 --> Total execution time: 0.0759
INFO - 2025-05-25 15:53:07 --> Config Class Initialized
INFO - 2025-05-25 15:53:07 --> Hooks Class Initialized
DEBUG - 2025-05-25 15:53:07 --> UTF-8 Support Enabled
INFO - 2025-05-25 15:53:07 --> Utf8 Class Initialized
INFO - 2025-05-25 15:53:07 --> URI Class Initialized
INFO - 2025-05-25 15:53:07 --> Router Class Initialized
INFO - 2025-05-25 15:53:07 --> Output Class Initialized
INFO - 2025-05-25 15:53:07 --> Security Class Initialized
DEBUG - 2025-05-25 15:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 15:53:07 --> Input Class Initialized
INFO - 2025-05-25 15:53:07 --> Language Class Initialized
INFO - 2025-05-25 15:53:07 --> Loader Class Initialized
INFO - 2025-05-25 15:53:07 --> Helper loaded: url_helper
INFO - 2025-05-25 15:53:07 --> Helper loaded: form_helper
INFO - 2025-05-25 15:53:07 --> Database Driver Class Initialized
DEBUG - 2025-05-25 15:53:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 15:53:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 15:53:08 --> Controller Class Initialized
INFO - 2025-05-25 15:53:08 --> Model "User_model" initialized
INFO - 2025-05-25 15:53:08 --> Model "Progress_model" initialized
INFO - 2025-05-25 15:53:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 15:53:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 15:53:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-25 15:53:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 15:53:08 --> Final output sent to browser
DEBUG - 2025-05-25 15:53:08 --> Total execution time: 0.0658
INFO - 2025-05-25 15:53:10 --> Config Class Initialized
INFO - 2025-05-25 15:53:10 --> Hooks Class Initialized
DEBUG - 2025-05-25 15:53:10 --> UTF-8 Support Enabled
INFO - 2025-05-25 15:53:10 --> Utf8 Class Initialized
INFO - 2025-05-25 15:53:10 --> URI Class Initialized
INFO - 2025-05-25 15:53:10 --> Router Class Initialized
INFO - 2025-05-25 15:53:10 --> Output Class Initialized
INFO - 2025-05-25 15:53:10 --> Security Class Initialized
DEBUG - 2025-05-25 15:53:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 15:53:10 --> Input Class Initialized
INFO - 2025-05-25 15:53:10 --> Language Class Initialized
INFO - 2025-05-25 15:53:10 --> Loader Class Initialized
INFO - 2025-05-25 15:53:10 --> Helper loaded: url_helper
INFO - 2025-05-25 15:53:10 --> Helper loaded: form_helper
INFO - 2025-05-25 15:53:10 --> Database Driver Class Initialized
DEBUG - 2025-05-25 15:53:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 15:53:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 15:53:10 --> Controller Class Initialized
INFO - 2025-05-25 15:53:10 --> Model "User_model" initialized
INFO - 2025-05-25 15:53:10 --> Model "Progress_model" initialized
INFO - 2025-05-25 15:53:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 15:53:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 15:53:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-25 15:53:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 15:53:10 --> Final output sent to browser
DEBUG - 2025-05-25 15:53:10 --> Total execution time: 0.0781
INFO - 2025-05-25 15:53:12 --> Config Class Initialized
INFO - 2025-05-25 15:53:12 --> Hooks Class Initialized
DEBUG - 2025-05-25 15:53:12 --> UTF-8 Support Enabled
INFO - 2025-05-25 15:53:12 --> Utf8 Class Initialized
INFO - 2025-05-25 15:53:12 --> URI Class Initialized
INFO - 2025-05-25 15:53:12 --> Router Class Initialized
INFO - 2025-05-25 15:53:12 --> Output Class Initialized
INFO - 2025-05-25 15:53:12 --> Security Class Initialized
DEBUG - 2025-05-25 15:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 15:53:12 --> Input Class Initialized
INFO - 2025-05-25 15:53:12 --> Language Class Initialized
INFO - 2025-05-25 15:53:12 --> Loader Class Initialized
INFO - 2025-05-25 15:53:12 --> Helper loaded: url_helper
INFO - 2025-05-25 15:53:12 --> Helper loaded: form_helper
INFO - 2025-05-25 15:53:12 --> Database Driver Class Initialized
DEBUG - 2025-05-25 15:53:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 15:53:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 15:53:12 --> Controller Class Initialized
INFO - 2025-05-25 15:53:12 --> Model "Progress_model" initialized
INFO - 2025-05-25 15:53:12 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 15:53:12 --> Model "User_model" initialized
INFO - 2025-05-25 15:53:12 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-25 15:53:12 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-25 15:53:12 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-25 15:53:12 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-25 15:53:12 --> Final output sent to browser
DEBUG - 2025-05-25 15:53:12 --> Total execution time: 0.0633
INFO - 2025-05-25 15:53:12 --> Config Class Initialized
INFO - 2025-05-25 15:53:12 --> Hooks Class Initialized
DEBUG - 2025-05-25 15:53:12 --> UTF-8 Support Enabled
INFO - 2025-05-25 15:53:12 --> Utf8 Class Initialized
INFO - 2025-05-25 15:53:12 --> URI Class Initialized
INFO - 2025-05-25 15:53:12 --> Router Class Initialized
INFO - 2025-05-25 15:53:12 --> Output Class Initialized
INFO - 2025-05-25 15:53:12 --> Security Class Initialized
DEBUG - 2025-05-25 15:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 15:53:12 --> Input Class Initialized
INFO - 2025-05-25 15:53:12 --> Language Class Initialized
INFO - 2025-05-25 15:53:12 --> Loader Class Initialized
INFO - 2025-05-25 15:53:12 --> Helper loaded: url_helper
INFO - 2025-05-25 15:53:12 --> Helper loaded: form_helper
INFO - 2025-05-25 15:53:12 --> Database Driver Class Initialized
DEBUG - 2025-05-25 15:53:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 15:53:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 15:53:12 --> Controller Class Initialized
INFO - 2025-05-25 15:53:12 --> Model "Progress_model" initialized
INFO - 2025-05-25 15:53:12 --> Model "Olahraga_model" initialized
INFO - 2025-05-25 15:53:12 --> Model "User_model" initialized
INFO - 2025-05-25 15:53:12 --> Final output sent to browser
DEBUG - 2025-05-25 15:53:12 --> Total execution time: 0.0581
INFO - 2025-05-25 15:53:21 --> Config Class Initialized
INFO - 2025-05-25 15:53:21 --> Hooks Class Initialized
DEBUG - 2025-05-25 15:53:21 --> UTF-8 Support Enabled
INFO - 2025-05-25 15:53:21 --> Utf8 Class Initialized
INFO - 2025-05-25 15:53:21 --> URI Class Initialized
INFO - 2025-05-25 15:53:21 --> Router Class Initialized
INFO - 2025-05-25 15:53:21 --> Output Class Initialized
INFO - 2025-05-25 15:53:21 --> Security Class Initialized
DEBUG - 2025-05-25 15:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 15:53:21 --> Input Class Initialized
INFO - 2025-05-25 15:53:21 --> Language Class Initialized
INFO - 2025-05-25 15:53:21 --> Loader Class Initialized
INFO - 2025-05-25 15:53:21 --> Helper loaded: url_helper
INFO - 2025-05-25 15:53:21 --> Helper loaded: form_helper
INFO - 2025-05-25 15:53:21 --> Database Driver Class Initialized
DEBUG - 2025-05-25 15:53:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 15:53:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 15:53:21 --> Controller Class Initialized
INFO - 2025-05-25 15:53:21 --> Model "User_model" initialized
INFO - 2025-05-25 15:53:21 --> Config Class Initialized
INFO - 2025-05-25 15:53:21 --> Hooks Class Initialized
DEBUG - 2025-05-25 15:53:21 --> UTF-8 Support Enabled
INFO - 2025-05-25 15:53:21 --> Utf8 Class Initialized
INFO - 2025-05-25 15:53:21 --> URI Class Initialized
INFO - 2025-05-25 15:53:21 --> Router Class Initialized
INFO - 2025-05-25 15:53:21 --> Output Class Initialized
INFO - 2025-05-25 15:53:21 --> Security Class Initialized
DEBUG - 2025-05-25 15:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-25 15:53:21 --> Input Class Initialized
INFO - 2025-05-25 15:53:21 --> Language Class Initialized
INFO - 2025-05-25 15:53:21 --> Loader Class Initialized
INFO - 2025-05-25 15:53:21 --> Helper loaded: url_helper
INFO - 2025-05-25 15:53:21 --> Helper loaded: form_helper
INFO - 2025-05-25 15:53:21 --> Database Driver Class Initialized
DEBUG - 2025-05-25 15:53:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-25 15:53:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-25 15:53:21 --> Controller Class Initialized
INFO - 2025-05-25 15:53:21 --> Model "User_model" initialized
INFO - 2025-05-25 15:53:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-25 15:53:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-25 15:53:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-25 15:53:21 --> Final output sent to browser
DEBUG - 2025-05-25 15:53:21 --> Total execution time: 0.0799
