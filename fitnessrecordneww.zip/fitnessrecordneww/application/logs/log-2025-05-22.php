<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-05-22 12:36:40 --> Config Class Initialized
INFO - 2025-05-22 12:36:40 --> Hooks Class Initialized
DEBUG - 2025-05-22 12:36:41 --> UTF-8 Support Enabled
INFO - 2025-05-22 12:36:41 --> Utf8 Class Initialized
INFO - 2025-05-22 12:36:41 --> URI Class Initialized
DEBUG - 2025-05-22 12:36:41 --> No URI present. Default controller set.
INFO - 2025-05-22 12:36:41 --> Router Class Initialized
INFO - 2025-05-22 12:36:41 --> Output Class Initialized
INFO - 2025-05-22 12:36:41 --> Security Class Initialized
DEBUG - 2025-05-22 12:36:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 12:36:41 --> Input Class Initialized
INFO - 2025-05-22 12:36:41 --> Language Class Initialized
INFO - 2025-05-22 12:36:41 --> Loader Class Initialized
INFO - 2025-05-22 12:36:41 --> Helper loaded: url_helper
INFO - 2025-05-22 12:36:41 --> Helper loaded: form_helper
INFO - 2025-05-22 12:36:41 --> Database Driver Class Initialized
DEBUG - 2025-05-22 12:36:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 12:36:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 12:36:42 --> Controller Class Initialized
INFO - 2025-05-22 12:36:42 --> Model "User_model" initialized
INFO - 2025-05-22 12:36:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-22 12:36:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-22 12:36:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-22 12:36:42 --> Final output sent to browser
DEBUG - 2025-05-22 12:36:42 --> Total execution time: 1.7322
INFO - 2025-05-22 12:40:55 --> Config Class Initialized
INFO - 2025-05-22 12:40:55 --> Hooks Class Initialized
DEBUG - 2025-05-22 12:40:56 --> UTF-8 Support Enabled
INFO - 2025-05-22 12:40:56 --> Utf8 Class Initialized
INFO - 2025-05-22 12:40:56 --> URI Class Initialized
INFO - 2025-05-22 12:40:56 --> Router Class Initialized
INFO - 2025-05-22 12:40:56 --> Output Class Initialized
INFO - 2025-05-22 12:40:56 --> Security Class Initialized
DEBUG - 2025-05-22 12:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 12:40:56 --> Input Class Initialized
INFO - 2025-05-22 12:40:56 --> Language Class Initialized
INFO - 2025-05-22 12:40:56 --> Loader Class Initialized
INFO - 2025-05-22 12:40:56 --> Helper loaded: url_helper
INFO - 2025-05-22 12:40:56 --> Helper loaded: form_helper
INFO - 2025-05-22 12:40:57 --> Database Driver Class Initialized
DEBUG - 2025-05-22 12:40:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 12:40:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 12:40:57 --> Controller Class Initialized
INFO - 2025-05-22 12:40:57 --> Model "Progress_model" initialized
INFO - 2025-05-22 12:40:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\progress_view.php
INFO - 2025-05-22 12:40:57 --> Final output sent to browser
DEBUG - 2025-05-22 12:40:57 --> Total execution time: 1.8644
INFO - 2025-05-22 12:40:58 --> Config Class Initialized
INFO - 2025-05-22 12:40:58 --> Hooks Class Initialized
DEBUG - 2025-05-22 12:40:58 --> UTF-8 Support Enabled
INFO - 2025-05-22 12:40:58 --> Utf8 Class Initialized
INFO - 2025-05-22 12:40:58 --> URI Class Initialized
INFO - 2025-05-22 12:40:58 --> Router Class Initialized
INFO - 2025-05-22 12:40:58 --> Output Class Initialized
INFO - 2025-05-22 12:40:58 --> Security Class Initialized
DEBUG - 2025-05-22 12:40:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 12:40:58 --> Input Class Initialized
INFO - 2025-05-22 12:40:58 --> Language Class Initialized
INFO - 2025-05-22 12:40:58 --> Loader Class Initialized
INFO - 2025-05-22 12:40:58 --> Helper loaded: url_helper
INFO - 2025-05-22 12:40:58 --> Helper loaded: form_helper
INFO - 2025-05-22 12:40:58 --> Database Driver Class Initialized
DEBUG - 2025-05-22 12:40:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 12:40:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 12:40:58 --> Controller Class Initialized
INFO - 2025-05-22 12:40:58 --> Model "Progress_model" initialized
INFO - 2025-05-22 12:40:58 --> Final output sent to browser
DEBUG - 2025-05-22 12:40:58 --> Total execution time: 0.2139
INFO - 2025-05-22 12:43:03 --> Config Class Initialized
INFO - 2025-05-22 12:43:03 --> Hooks Class Initialized
DEBUG - 2025-05-22 12:43:03 --> UTF-8 Support Enabled
INFO - 2025-05-22 12:43:03 --> Utf8 Class Initialized
INFO - 2025-05-22 12:43:03 --> URI Class Initialized
INFO - 2025-05-22 12:43:03 --> Router Class Initialized
INFO - 2025-05-22 12:43:03 --> Output Class Initialized
INFO - 2025-05-22 12:43:03 --> Security Class Initialized
DEBUG - 2025-05-22 12:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 12:43:03 --> Input Class Initialized
INFO - 2025-05-22 12:43:03 --> Language Class Initialized
INFO - 2025-05-22 12:43:03 --> Loader Class Initialized
INFO - 2025-05-22 12:43:03 --> Helper loaded: url_helper
INFO - 2025-05-22 12:43:03 --> Helper loaded: form_helper
INFO - 2025-05-22 12:43:03 --> Database Driver Class Initialized
DEBUG - 2025-05-22 12:43:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 12:43:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 12:43:03 --> Controller Class Initialized
INFO - 2025-05-22 12:43:03 --> Model "Progress_model" initialized
INFO - 2025-05-22 12:43:03 --> Final output sent to browser
DEBUG - 2025-05-22 12:43:03 --> Total execution time: 0.0553
INFO - 2025-05-22 12:44:18 --> Config Class Initialized
INFO - 2025-05-22 12:44:18 --> Hooks Class Initialized
DEBUG - 2025-05-22 12:44:18 --> UTF-8 Support Enabled
INFO - 2025-05-22 12:44:18 --> Utf8 Class Initialized
INFO - 2025-05-22 12:44:18 --> URI Class Initialized
INFO - 2025-05-22 12:44:18 --> Router Class Initialized
INFO - 2025-05-22 12:44:18 --> Output Class Initialized
INFO - 2025-05-22 12:44:18 --> Security Class Initialized
DEBUG - 2025-05-22 12:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 12:44:18 --> Input Class Initialized
INFO - 2025-05-22 12:44:18 --> Language Class Initialized
INFO - 2025-05-22 12:44:18 --> Loader Class Initialized
INFO - 2025-05-22 12:44:18 --> Helper loaded: url_helper
INFO - 2025-05-22 12:44:18 --> Helper loaded: form_helper
INFO - 2025-05-22 12:44:18 --> Database Driver Class Initialized
DEBUG - 2025-05-22 12:44:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 12:44:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 12:44:18 --> Controller Class Initialized
INFO - 2025-05-22 12:44:18 --> Model "Progress_model" initialized
INFO - 2025-05-22 12:44:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\progress_view.php
INFO - 2025-05-22 12:44:18 --> Final output sent to browser
DEBUG - 2025-05-22 12:44:18 --> Total execution time: 0.0574
INFO - 2025-05-22 12:44:18 --> Config Class Initialized
INFO - 2025-05-22 12:44:18 --> Hooks Class Initialized
DEBUG - 2025-05-22 12:44:18 --> UTF-8 Support Enabled
INFO - 2025-05-22 12:44:18 --> Utf8 Class Initialized
INFO - 2025-05-22 12:44:18 --> URI Class Initialized
INFO - 2025-05-22 12:44:18 --> Router Class Initialized
INFO - 2025-05-22 12:44:18 --> Output Class Initialized
INFO - 2025-05-22 12:44:18 --> Security Class Initialized
DEBUG - 2025-05-22 12:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 12:44:18 --> Input Class Initialized
INFO - 2025-05-22 12:44:18 --> Language Class Initialized
INFO - 2025-05-22 12:44:18 --> Loader Class Initialized
INFO - 2025-05-22 12:44:18 --> Helper loaded: url_helper
INFO - 2025-05-22 12:44:18 --> Helper loaded: form_helper
INFO - 2025-05-22 12:44:18 --> Database Driver Class Initialized
DEBUG - 2025-05-22 12:44:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 12:44:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 12:44:18 --> Controller Class Initialized
INFO - 2025-05-22 12:44:18 --> Model "Progress_model" initialized
INFO - 2025-05-22 12:44:18 --> Final output sent to browser
DEBUG - 2025-05-22 12:44:18 --> Total execution time: 0.0919
INFO - 2025-05-22 12:44:21 --> Config Class Initialized
INFO - 2025-05-22 12:44:21 --> Hooks Class Initialized
DEBUG - 2025-05-22 12:44:21 --> UTF-8 Support Enabled
INFO - 2025-05-22 12:44:21 --> Utf8 Class Initialized
INFO - 2025-05-22 12:44:21 --> URI Class Initialized
INFO - 2025-05-22 12:44:21 --> Router Class Initialized
INFO - 2025-05-22 12:44:21 --> Output Class Initialized
INFO - 2025-05-22 12:44:21 --> Security Class Initialized
DEBUG - 2025-05-22 12:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 12:44:21 --> Input Class Initialized
INFO - 2025-05-22 12:44:21 --> Language Class Initialized
INFO - 2025-05-22 12:44:21 --> Loader Class Initialized
INFO - 2025-05-22 12:44:21 --> Helper loaded: url_helper
INFO - 2025-05-22 12:44:21 --> Helper loaded: form_helper
INFO - 2025-05-22 12:44:21 --> Database Driver Class Initialized
DEBUG - 2025-05-22 12:44:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 12:44:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 12:44:21 --> Controller Class Initialized
INFO - 2025-05-22 12:44:21 --> Model "Progress_model" initialized
INFO - 2025-05-22 12:44:21 --> Final output sent to browser
DEBUG - 2025-05-22 12:44:21 --> Total execution time: 0.0557
INFO - 2025-05-22 12:44:22 --> Config Class Initialized
INFO - 2025-05-22 12:44:22 --> Hooks Class Initialized
DEBUG - 2025-05-22 12:44:22 --> UTF-8 Support Enabled
INFO - 2025-05-22 12:44:22 --> Utf8 Class Initialized
INFO - 2025-05-22 12:44:22 --> URI Class Initialized
INFO - 2025-05-22 12:44:22 --> Router Class Initialized
INFO - 2025-05-22 12:44:22 --> Output Class Initialized
INFO - 2025-05-22 12:44:22 --> Security Class Initialized
DEBUG - 2025-05-22 12:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 12:44:22 --> Input Class Initialized
INFO - 2025-05-22 12:44:22 --> Language Class Initialized
INFO - 2025-05-22 12:44:22 --> Loader Class Initialized
INFO - 2025-05-22 12:44:22 --> Helper loaded: url_helper
INFO - 2025-05-22 12:44:22 --> Helper loaded: form_helper
INFO - 2025-05-22 12:44:22 --> Database Driver Class Initialized
DEBUG - 2025-05-22 12:44:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 12:44:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 12:44:22 --> Controller Class Initialized
INFO - 2025-05-22 12:44:22 --> Model "Progress_model" initialized
INFO - 2025-05-22 12:44:22 --> Final output sent to browser
DEBUG - 2025-05-22 12:44:22 --> Total execution time: 0.0787
INFO - 2025-05-22 12:44:26 --> Config Class Initialized
INFO - 2025-05-22 12:44:26 --> Hooks Class Initialized
DEBUG - 2025-05-22 12:44:26 --> UTF-8 Support Enabled
INFO - 2025-05-22 12:44:26 --> Utf8 Class Initialized
INFO - 2025-05-22 12:44:26 --> URI Class Initialized
INFO - 2025-05-22 12:44:26 --> Router Class Initialized
INFO - 2025-05-22 12:44:26 --> Output Class Initialized
INFO - 2025-05-22 12:44:26 --> Security Class Initialized
DEBUG - 2025-05-22 12:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 12:44:26 --> Input Class Initialized
INFO - 2025-05-22 12:44:26 --> Language Class Initialized
INFO - 2025-05-22 12:44:26 --> Loader Class Initialized
INFO - 2025-05-22 12:44:26 --> Helper loaded: url_helper
INFO - 2025-05-22 12:44:26 --> Helper loaded: form_helper
INFO - 2025-05-22 12:44:26 --> Database Driver Class Initialized
DEBUG - 2025-05-22 12:44:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 12:44:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 12:44:26 --> Controller Class Initialized
INFO - 2025-05-22 12:44:26 --> Model "Progress_model" initialized
INFO - 2025-05-22 12:44:26 --> Final output sent to browser
DEBUG - 2025-05-22 12:44:26 --> Total execution time: 0.0550
INFO - 2025-05-22 12:48:24 --> Config Class Initialized
INFO - 2025-05-22 12:48:24 --> Hooks Class Initialized
DEBUG - 2025-05-22 12:48:24 --> UTF-8 Support Enabled
INFO - 2025-05-22 12:48:24 --> Utf8 Class Initialized
INFO - 2025-05-22 12:48:24 --> URI Class Initialized
INFO - 2025-05-22 12:48:24 --> Router Class Initialized
INFO - 2025-05-22 12:48:24 --> Output Class Initialized
INFO - 2025-05-22 12:48:24 --> Security Class Initialized
DEBUG - 2025-05-22 12:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 12:48:24 --> Input Class Initialized
INFO - 2025-05-22 12:48:24 --> Language Class Initialized
INFO - 2025-05-22 12:48:24 --> Loader Class Initialized
INFO - 2025-05-22 12:48:24 --> Helper loaded: url_helper
INFO - 2025-05-22 12:48:24 --> Helper loaded: form_helper
INFO - 2025-05-22 12:48:24 --> Database Driver Class Initialized
DEBUG - 2025-05-22 12:48:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 12:48:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 12:48:24 --> Controller Class Initialized
INFO - 2025-05-22 12:48:24 --> Model "Progress_model" initialized
INFO - 2025-05-22 12:48:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\progress_view.php
INFO - 2025-05-22 12:48:24 --> Final output sent to browser
DEBUG - 2025-05-22 12:48:24 --> Total execution time: 0.0570
INFO - 2025-05-22 12:48:25 --> Config Class Initialized
INFO - 2025-05-22 12:48:25 --> Hooks Class Initialized
DEBUG - 2025-05-22 12:48:25 --> UTF-8 Support Enabled
INFO - 2025-05-22 12:48:25 --> Utf8 Class Initialized
INFO - 2025-05-22 12:48:25 --> URI Class Initialized
INFO - 2025-05-22 12:48:25 --> Router Class Initialized
INFO - 2025-05-22 12:48:25 --> Output Class Initialized
INFO - 2025-05-22 12:48:25 --> Security Class Initialized
DEBUG - 2025-05-22 12:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 12:48:25 --> Input Class Initialized
INFO - 2025-05-22 12:48:25 --> Language Class Initialized
INFO - 2025-05-22 12:48:25 --> Loader Class Initialized
INFO - 2025-05-22 12:48:25 --> Helper loaded: url_helper
INFO - 2025-05-22 12:48:25 --> Helper loaded: form_helper
INFO - 2025-05-22 12:48:25 --> Database Driver Class Initialized
DEBUG - 2025-05-22 12:48:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 12:48:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 12:48:25 --> Controller Class Initialized
INFO - 2025-05-22 12:48:25 --> Model "Progress_model" initialized
INFO - 2025-05-22 12:48:25 --> Final output sent to browser
DEBUG - 2025-05-22 12:48:25 --> Total execution time: 0.0662
INFO - 2025-05-22 12:48:28 --> Config Class Initialized
INFO - 2025-05-22 12:48:28 --> Hooks Class Initialized
DEBUG - 2025-05-22 12:48:28 --> UTF-8 Support Enabled
INFO - 2025-05-22 12:48:28 --> Utf8 Class Initialized
INFO - 2025-05-22 12:48:28 --> URI Class Initialized
INFO - 2025-05-22 12:48:28 --> Router Class Initialized
INFO - 2025-05-22 12:48:28 --> Output Class Initialized
INFO - 2025-05-22 12:48:28 --> Security Class Initialized
DEBUG - 2025-05-22 12:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 12:48:28 --> Input Class Initialized
INFO - 2025-05-22 12:48:28 --> Language Class Initialized
INFO - 2025-05-22 12:48:28 --> Loader Class Initialized
INFO - 2025-05-22 12:48:28 --> Helper loaded: url_helper
INFO - 2025-05-22 12:48:28 --> Helper loaded: form_helper
INFO - 2025-05-22 12:48:28 --> Database Driver Class Initialized
DEBUG - 2025-05-22 12:48:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 12:48:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 12:48:28 --> Controller Class Initialized
INFO - 2025-05-22 12:48:28 --> Model "Progress_model" initialized
INFO - 2025-05-22 12:48:28 --> Final output sent to browser
DEBUG - 2025-05-22 12:48:28 --> Total execution time: 0.0574
INFO - 2025-05-22 12:49:23 --> Config Class Initialized
INFO - 2025-05-22 12:49:23 --> Hooks Class Initialized
DEBUG - 2025-05-22 12:49:23 --> UTF-8 Support Enabled
INFO - 2025-05-22 12:49:23 --> Utf8 Class Initialized
INFO - 2025-05-22 12:49:23 --> URI Class Initialized
INFO - 2025-05-22 12:49:23 --> Router Class Initialized
INFO - 2025-05-22 12:49:23 --> Output Class Initialized
INFO - 2025-05-22 12:49:23 --> Security Class Initialized
DEBUG - 2025-05-22 12:49:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 12:49:23 --> Input Class Initialized
INFO - 2025-05-22 12:49:23 --> Language Class Initialized
INFO - 2025-05-22 12:49:23 --> Loader Class Initialized
INFO - 2025-05-22 12:49:23 --> Helper loaded: url_helper
INFO - 2025-05-22 12:49:23 --> Helper loaded: form_helper
INFO - 2025-05-22 12:49:23 --> Database Driver Class Initialized
DEBUG - 2025-05-22 12:49:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 12:49:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 12:49:23 --> Controller Class Initialized
INFO - 2025-05-22 12:49:23 --> Model "Progress_model" initialized
INFO - 2025-05-22 12:49:23 --> Final output sent to browser
DEBUG - 2025-05-22 12:49:23 --> Total execution time: 0.0770
INFO - 2025-05-22 12:49:33 --> Config Class Initialized
INFO - 2025-05-22 12:49:33 --> Hooks Class Initialized
DEBUG - 2025-05-22 12:49:33 --> UTF-8 Support Enabled
INFO - 2025-05-22 12:49:33 --> Utf8 Class Initialized
INFO - 2025-05-22 12:49:33 --> URI Class Initialized
INFO - 2025-05-22 12:49:33 --> Router Class Initialized
INFO - 2025-05-22 12:49:33 --> Output Class Initialized
INFO - 2025-05-22 12:49:33 --> Security Class Initialized
DEBUG - 2025-05-22 12:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 12:49:33 --> Input Class Initialized
INFO - 2025-05-22 12:49:33 --> Language Class Initialized
INFO - 2025-05-22 12:49:33 --> Loader Class Initialized
INFO - 2025-05-22 12:49:33 --> Helper loaded: url_helper
INFO - 2025-05-22 12:49:33 --> Helper loaded: form_helper
INFO - 2025-05-22 12:49:33 --> Database Driver Class Initialized
DEBUG - 2025-05-22 12:49:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 12:49:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 12:49:33 --> Controller Class Initialized
INFO - 2025-05-22 12:49:33 --> Model "Progress_model" initialized
INFO - 2025-05-22 12:49:33 --> Final output sent to browser
DEBUG - 2025-05-22 12:49:33 --> Total execution time: 0.0765
INFO - 2025-05-22 12:49:35 --> Config Class Initialized
INFO - 2025-05-22 12:49:35 --> Hooks Class Initialized
DEBUG - 2025-05-22 12:49:35 --> UTF-8 Support Enabled
INFO - 2025-05-22 12:49:35 --> Utf8 Class Initialized
INFO - 2025-05-22 12:49:35 --> URI Class Initialized
INFO - 2025-05-22 12:49:35 --> Router Class Initialized
INFO - 2025-05-22 12:49:35 --> Output Class Initialized
INFO - 2025-05-22 12:49:35 --> Security Class Initialized
DEBUG - 2025-05-22 12:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 12:49:35 --> Input Class Initialized
INFO - 2025-05-22 12:49:35 --> Language Class Initialized
INFO - 2025-05-22 12:49:35 --> Loader Class Initialized
INFO - 2025-05-22 12:49:35 --> Helper loaded: url_helper
INFO - 2025-05-22 12:49:35 --> Helper loaded: form_helper
INFO - 2025-05-22 12:49:35 --> Database Driver Class Initialized
DEBUG - 2025-05-22 12:49:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 12:49:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 12:49:35 --> Controller Class Initialized
INFO - 2025-05-22 12:49:35 --> Model "Progress_model" initialized
INFO - 2025-05-22 12:49:35 --> Final output sent to browser
DEBUG - 2025-05-22 12:49:35 --> Total execution time: 0.0961
INFO - 2025-05-22 12:49:38 --> Config Class Initialized
INFO - 2025-05-22 12:49:38 --> Hooks Class Initialized
DEBUG - 2025-05-22 12:49:38 --> UTF-8 Support Enabled
INFO - 2025-05-22 12:49:38 --> Utf8 Class Initialized
INFO - 2025-05-22 12:49:38 --> URI Class Initialized
INFO - 2025-05-22 12:49:38 --> Router Class Initialized
INFO - 2025-05-22 12:49:38 --> Output Class Initialized
INFO - 2025-05-22 12:49:38 --> Security Class Initialized
DEBUG - 2025-05-22 12:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 12:49:38 --> Input Class Initialized
INFO - 2025-05-22 12:49:38 --> Language Class Initialized
INFO - 2025-05-22 12:49:38 --> Loader Class Initialized
INFO - 2025-05-22 12:49:38 --> Helper loaded: url_helper
INFO - 2025-05-22 12:49:38 --> Helper loaded: form_helper
INFO - 2025-05-22 12:49:38 --> Database Driver Class Initialized
DEBUG - 2025-05-22 12:49:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 12:49:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 12:49:38 --> Controller Class Initialized
INFO - 2025-05-22 12:49:38 --> Model "Progress_model" initialized
INFO - 2025-05-22 12:49:38 --> Final output sent to browser
DEBUG - 2025-05-22 12:49:38 --> Total execution time: 0.0644
INFO - 2025-05-22 12:49:38 --> Config Class Initialized
INFO - 2025-05-22 12:49:38 --> Hooks Class Initialized
DEBUG - 2025-05-22 12:49:38 --> UTF-8 Support Enabled
INFO - 2025-05-22 12:49:38 --> Utf8 Class Initialized
INFO - 2025-05-22 12:49:38 --> URI Class Initialized
INFO - 2025-05-22 12:49:38 --> Router Class Initialized
INFO - 2025-05-22 12:49:38 --> Output Class Initialized
INFO - 2025-05-22 12:49:38 --> Security Class Initialized
DEBUG - 2025-05-22 12:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 12:49:38 --> Input Class Initialized
INFO - 2025-05-22 12:49:38 --> Language Class Initialized
INFO - 2025-05-22 12:49:38 --> Loader Class Initialized
INFO - 2025-05-22 12:49:38 --> Helper loaded: url_helper
INFO - 2025-05-22 12:49:38 --> Helper loaded: form_helper
INFO - 2025-05-22 12:49:38 --> Database Driver Class Initialized
DEBUG - 2025-05-22 12:49:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 12:49:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 12:49:38 --> Controller Class Initialized
INFO - 2025-05-22 12:49:38 --> Model "Progress_model" initialized
INFO - 2025-05-22 12:49:38 --> Final output sent to browser
DEBUG - 2025-05-22 12:49:38 --> Total execution time: 0.0881
INFO - 2025-05-22 13:06:57 --> Config Class Initialized
INFO - 2025-05-22 13:06:57 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:06:57 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:06:57 --> Utf8 Class Initialized
INFO - 2025-05-22 13:06:57 --> URI Class Initialized
INFO - 2025-05-22 13:06:57 --> Router Class Initialized
INFO - 2025-05-22 13:06:57 --> Output Class Initialized
INFO - 2025-05-22 13:06:57 --> Security Class Initialized
DEBUG - 2025-05-22 13:06:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:06:57 --> Input Class Initialized
INFO - 2025-05-22 13:06:57 --> Language Class Initialized
INFO - 2025-05-22 13:06:57 --> Loader Class Initialized
INFO - 2025-05-22 13:06:57 --> Helper loaded: url_helper
INFO - 2025-05-22 13:06:57 --> Helper loaded: form_helper
INFO - 2025-05-22 13:06:57 --> Database Driver Class Initialized
DEBUG - 2025-05-22 13:06:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 13:06:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 13:06:57 --> Controller Class Initialized
INFO - 2025-05-22 13:06:57 --> Model "Progress_model" initialized
INFO - 2025-05-22 13:06:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\progress_view.php
INFO - 2025-05-22 13:06:57 --> Final output sent to browser
DEBUG - 2025-05-22 13:06:57 --> Total execution time: 0.0608
INFO - 2025-05-22 13:06:58 --> Config Class Initialized
INFO - 2025-05-22 13:06:58 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:06:58 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:06:58 --> Utf8 Class Initialized
INFO - 2025-05-22 13:06:58 --> URI Class Initialized
INFO - 2025-05-22 13:06:58 --> Router Class Initialized
INFO - 2025-05-22 13:06:58 --> Output Class Initialized
INFO - 2025-05-22 13:06:58 --> Security Class Initialized
DEBUG - 2025-05-22 13:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:06:58 --> Input Class Initialized
INFO - 2025-05-22 13:06:58 --> Language Class Initialized
INFO - 2025-05-22 13:06:58 --> Loader Class Initialized
INFO - 2025-05-22 13:06:58 --> Helper loaded: url_helper
INFO - 2025-05-22 13:06:58 --> Helper loaded: form_helper
INFO - 2025-05-22 13:06:58 --> Database Driver Class Initialized
DEBUG - 2025-05-22 13:06:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 13:06:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 13:06:58 --> Controller Class Initialized
INFO - 2025-05-22 13:06:58 --> Model "Progress_model" initialized
INFO - 2025-05-22 13:06:58 --> Final output sent to browser
DEBUG - 2025-05-22 13:06:58 --> Total execution time: 0.0674
INFO - 2025-05-22 13:07:00 --> Config Class Initialized
INFO - 2025-05-22 13:07:00 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:07:00 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:07:00 --> Utf8 Class Initialized
INFO - 2025-05-22 13:07:00 --> URI Class Initialized
INFO - 2025-05-22 13:07:00 --> Router Class Initialized
INFO - 2025-05-22 13:07:00 --> Output Class Initialized
INFO - 2025-05-22 13:07:00 --> Security Class Initialized
DEBUG - 2025-05-22 13:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:07:00 --> Input Class Initialized
INFO - 2025-05-22 13:07:00 --> Language Class Initialized
INFO - 2025-05-22 13:07:00 --> Loader Class Initialized
INFO - 2025-05-22 13:07:00 --> Helper loaded: url_helper
INFO - 2025-05-22 13:07:00 --> Helper loaded: form_helper
INFO - 2025-05-22 13:07:00 --> Database Driver Class Initialized
DEBUG - 2025-05-22 13:07:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 13:07:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 13:07:00 --> Controller Class Initialized
INFO - 2025-05-22 13:07:00 --> Model "Progress_model" initialized
INFO - 2025-05-22 13:07:00 --> Final output sent to browser
DEBUG - 2025-05-22 13:07:00 --> Total execution time: 0.0732
INFO - 2025-05-22 13:07:12 --> Config Class Initialized
INFO - 2025-05-22 13:07:12 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:07:12 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:07:12 --> Utf8 Class Initialized
INFO - 2025-05-22 13:07:12 --> URI Class Initialized
INFO - 2025-05-22 13:07:12 --> Router Class Initialized
INFO - 2025-05-22 13:07:12 --> Output Class Initialized
INFO - 2025-05-22 13:07:12 --> Security Class Initialized
DEBUG - 2025-05-22 13:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:07:12 --> Input Class Initialized
INFO - 2025-05-22 13:07:12 --> Language Class Initialized
INFO - 2025-05-22 13:07:12 --> Loader Class Initialized
INFO - 2025-05-22 13:07:12 --> Helper loaded: url_helper
INFO - 2025-05-22 13:07:12 --> Helper loaded: form_helper
INFO - 2025-05-22 13:07:12 --> Database Driver Class Initialized
DEBUG - 2025-05-22 13:07:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 13:07:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 13:07:12 --> Controller Class Initialized
INFO - 2025-05-22 13:07:12 --> Model "Timer_model" initialized
INFO - 2025-05-22 13:07:12 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\timer_view.php
INFO - 2025-05-22 13:07:12 --> Final output sent to browser
DEBUG - 2025-05-22 13:07:12 --> Total execution time: 0.0806
INFO - 2025-05-22 13:07:23 --> Config Class Initialized
INFO - 2025-05-22 13:07:23 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:07:23 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:07:23 --> Utf8 Class Initialized
INFO - 2025-05-22 13:07:23 --> URI Class Initialized
INFO - 2025-05-22 13:07:23 --> Router Class Initialized
INFO - 2025-05-22 13:07:23 --> Output Class Initialized
INFO - 2025-05-22 13:07:23 --> Security Class Initialized
DEBUG - 2025-05-22 13:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:07:23 --> Input Class Initialized
INFO - 2025-05-22 13:07:23 --> Language Class Initialized
INFO - 2025-05-22 13:07:23 --> Loader Class Initialized
INFO - 2025-05-22 13:07:23 --> Helper loaded: url_helper
INFO - 2025-05-22 13:07:23 --> Helper loaded: form_helper
INFO - 2025-05-22 13:07:23 --> Database Driver Class Initialized
DEBUG - 2025-05-22 13:07:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 13:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 13:07:23 --> Controller Class Initialized
INFO - 2025-05-22 13:07:23 --> Model "Timer_model" initialized
INFO - 2025-05-22 13:07:23 --> Final output sent to browser
DEBUG - 2025-05-22 13:07:23 --> Total execution time: 0.0591
INFO - 2025-05-22 13:07:25 --> Config Class Initialized
INFO - 2025-05-22 13:07:25 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:07:25 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:07:25 --> Utf8 Class Initialized
INFO - 2025-05-22 13:07:25 --> URI Class Initialized
INFO - 2025-05-22 13:07:25 --> Router Class Initialized
INFO - 2025-05-22 13:07:25 --> Output Class Initialized
INFO - 2025-05-22 13:07:25 --> Security Class Initialized
DEBUG - 2025-05-22 13:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:07:25 --> Input Class Initialized
INFO - 2025-05-22 13:07:25 --> Language Class Initialized
INFO - 2025-05-22 13:07:25 --> Loader Class Initialized
INFO - 2025-05-22 13:07:25 --> Helper loaded: url_helper
INFO - 2025-05-22 13:07:25 --> Helper loaded: form_helper
INFO - 2025-05-22 13:07:25 --> Database Driver Class Initialized
DEBUG - 2025-05-22 13:07:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 13:07:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 13:07:25 --> Controller Class Initialized
INFO - 2025-05-22 13:07:25 --> Model "Timer_model" initialized
INFO - 2025-05-22 13:07:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\timer_view.php
INFO - 2025-05-22 13:07:25 --> Final output sent to browser
DEBUG - 2025-05-22 13:07:25 --> Total execution time: 0.0886
INFO - 2025-05-22 13:07:32 --> Config Class Initialized
INFO - 2025-05-22 13:07:32 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:07:32 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:07:32 --> Utf8 Class Initialized
INFO - 2025-05-22 13:07:32 --> URI Class Initialized
INFO - 2025-05-22 13:07:32 --> Router Class Initialized
INFO - 2025-05-22 13:07:32 --> Output Class Initialized
INFO - 2025-05-22 13:07:32 --> Security Class Initialized
DEBUG - 2025-05-22 13:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:07:32 --> Input Class Initialized
INFO - 2025-05-22 13:07:33 --> Language Class Initialized
INFO - 2025-05-22 13:07:33 --> Loader Class Initialized
INFO - 2025-05-22 13:07:33 --> Helper loaded: url_helper
INFO - 2025-05-22 13:07:33 --> Helper loaded: form_helper
INFO - 2025-05-22 13:07:33 --> Database Driver Class Initialized
DEBUG - 2025-05-22 13:07:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 13:07:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 13:07:33 --> Controller Class Initialized
INFO - 2025-05-22 13:07:33 --> Model "Progress_model" initialized
INFO - 2025-05-22 13:07:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\progress_view.php
INFO - 2025-05-22 13:07:33 --> Final output sent to browser
DEBUG - 2025-05-22 13:07:33 --> Total execution time: 0.0628
INFO - 2025-05-22 13:07:33 --> Config Class Initialized
INFO - 2025-05-22 13:07:33 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:07:33 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:07:33 --> Utf8 Class Initialized
INFO - 2025-05-22 13:07:33 --> URI Class Initialized
INFO - 2025-05-22 13:07:33 --> Router Class Initialized
INFO - 2025-05-22 13:07:33 --> Output Class Initialized
INFO - 2025-05-22 13:07:33 --> Security Class Initialized
DEBUG - 2025-05-22 13:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:07:33 --> Input Class Initialized
INFO - 2025-05-22 13:07:33 --> Language Class Initialized
INFO - 2025-05-22 13:07:33 --> Loader Class Initialized
INFO - 2025-05-22 13:07:33 --> Helper loaded: url_helper
INFO - 2025-05-22 13:07:33 --> Helper loaded: form_helper
INFO - 2025-05-22 13:07:33 --> Database Driver Class Initialized
DEBUG - 2025-05-22 13:07:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 13:07:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 13:07:33 --> Controller Class Initialized
INFO - 2025-05-22 13:07:33 --> Model "Progress_model" initialized
INFO - 2025-05-22 13:07:33 --> Final output sent to browser
DEBUG - 2025-05-22 13:07:33 --> Total execution time: 0.0641
INFO - 2025-05-22 13:07:36 --> Config Class Initialized
INFO - 2025-05-22 13:07:36 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:07:36 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:07:36 --> Utf8 Class Initialized
INFO - 2025-05-22 13:07:36 --> URI Class Initialized
INFO - 2025-05-22 13:07:36 --> Router Class Initialized
INFO - 2025-05-22 13:07:36 --> Output Class Initialized
INFO - 2025-05-22 13:07:36 --> Security Class Initialized
DEBUG - 2025-05-22 13:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:07:36 --> Input Class Initialized
INFO - 2025-05-22 13:07:36 --> Language Class Initialized
INFO - 2025-05-22 13:07:36 --> Loader Class Initialized
INFO - 2025-05-22 13:07:36 --> Helper loaded: url_helper
INFO - 2025-05-22 13:07:36 --> Helper loaded: form_helper
INFO - 2025-05-22 13:07:36 --> Database Driver Class Initialized
DEBUG - 2025-05-22 13:07:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 13:07:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 13:07:36 --> Controller Class Initialized
INFO - 2025-05-22 13:07:36 --> Model "Progress_model" initialized
INFO - 2025-05-22 13:07:36 --> Final output sent to browser
DEBUG - 2025-05-22 13:07:36 --> Total execution time: 0.0563
INFO - 2025-05-22 13:08:32 --> Config Class Initialized
INFO - 2025-05-22 13:08:32 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:08:32 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:08:32 --> Utf8 Class Initialized
INFO - 2025-05-22 13:08:32 --> URI Class Initialized
DEBUG - 2025-05-22 13:08:32 --> No URI present. Default controller set.
INFO - 2025-05-22 13:08:32 --> Router Class Initialized
INFO - 2025-05-22 13:08:32 --> Output Class Initialized
INFO - 2025-05-22 13:08:32 --> Security Class Initialized
DEBUG - 2025-05-22 13:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:08:32 --> Input Class Initialized
INFO - 2025-05-22 13:08:32 --> Language Class Initialized
INFO - 2025-05-22 13:08:32 --> Loader Class Initialized
INFO - 2025-05-22 13:08:32 --> Helper loaded: url_helper
INFO - 2025-05-22 13:08:32 --> Helper loaded: form_helper
INFO - 2025-05-22 13:08:32 --> Database Driver Class Initialized
DEBUG - 2025-05-22 13:08:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 13:08:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 13:08:32 --> Controller Class Initialized
INFO - 2025-05-22 13:08:32 --> Model "User_model" initialized
INFO - 2025-05-22 13:08:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-22 13:08:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-22 13:08:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-22 13:08:32 --> Final output sent to browser
DEBUG - 2025-05-22 13:08:32 --> Total execution time: 0.3332
INFO - 2025-05-22 13:08:35 --> Config Class Initialized
INFO - 2025-05-22 13:08:35 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:08:35 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:08:35 --> Utf8 Class Initialized
INFO - 2025-05-22 13:08:35 --> URI Class Initialized
INFO - 2025-05-22 13:08:35 --> Router Class Initialized
INFO - 2025-05-22 13:08:35 --> Output Class Initialized
INFO - 2025-05-22 13:08:35 --> Security Class Initialized
DEBUG - 2025-05-22 13:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:08:35 --> Input Class Initialized
INFO - 2025-05-22 13:08:35 --> Language Class Initialized
INFO - 2025-05-22 13:08:35 --> Loader Class Initialized
INFO - 2025-05-22 13:08:35 --> Helper loaded: url_helper
INFO - 2025-05-22 13:08:35 --> Helper loaded: form_helper
INFO - 2025-05-22 13:08:35 --> Database Driver Class Initialized
DEBUG - 2025-05-22 13:08:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 13:08:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 13:08:35 --> Controller Class Initialized
INFO - 2025-05-22 13:08:35 --> Model "User_model" initialized
INFO - 2025-05-22 13:08:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-22 13:08:35 --> Final output sent to browser
DEBUG - 2025-05-22 13:08:35 --> Total execution time: 0.1418
INFO - 2025-05-22 13:08:52 --> Config Class Initialized
INFO - 2025-05-22 13:08:52 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:08:52 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:08:52 --> Utf8 Class Initialized
INFO - 2025-05-22 13:08:52 --> URI Class Initialized
INFO - 2025-05-22 13:08:52 --> Router Class Initialized
INFO - 2025-05-22 13:08:52 --> Output Class Initialized
INFO - 2025-05-22 13:08:52 --> Security Class Initialized
DEBUG - 2025-05-22 13:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:08:52 --> Input Class Initialized
INFO - 2025-05-22 13:08:52 --> Language Class Initialized
INFO - 2025-05-22 13:08:52 --> Loader Class Initialized
INFO - 2025-05-22 13:08:52 --> Helper loaded: url_helper
INFO - 2025-05-22 13:08:52 --> Helper loaded: form_helper
INFO - 2025-05-22 13:08:52 --> Database Driver Class Initialized
DEBUG - 2025-05-22 13:08:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 13:08:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 13:08:52 --> Controller Class Initialized
INFO - 2025-05-22 13:08:52 --> Model "User_model" initialized
INFO - 2025-05-22 13:08:52 --> Config Class Initialized
INFO - 2025-05-22 13:08:52 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:08:52 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:08:52 --> Utf8 Class Initialized
INFO - 2025-05-22 13:08:52 --> URI Class Initialized
INFO - 2025-05-22 13:08:52 --> Router Class Initialized
INFO - 2025-05-22 13:08:52 --> Output Class Initialized
INFO - 2025-05-22 13:08:53 --> Security Class Initialized
DEBUG - 2025-05-22 13:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:08:53 --> Input Class Initialized
INFO - 2025-05-22 13:08:53 --> Language Class Initialized
INFO - 2025-05-22 13:08:53 --> Loader Class Initialized
INFO - 2025-05-22 13:08:53 --> Helper loaded: url_helper
INFO - 2025-05-22 13:08:53 --> Helper loaded: form_helper
INFO - 2025-05-22 13:08:53 --> Database Driver Class Initialized
DEBUG - 2025-05-22 13:08:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 13:08:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 13:08:53 --> Controller Class Initialized
INFO - 2025-05-22 13:08:53 --> Model "User_model" initialized
INFO - 2025-05-22 13:08:53 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-22 13:08:53 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-22 13:08:53 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-22 13:08:53 --> Final output sent to browser
DEBUG - 2025-05-22 13:08:53 --> Total execution time: 0.0866
INFO - 2025-05-22 13:08:55 --> Config Class Initialized
INFO - 2025-05-22 13:08:55 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:08:55 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:08:55 --> Utf8 Class Initialized
INFO - 2025-05-22 13:08:55 --> URI Class Initialized
INFO - 2025-05-22 13:08:55 --> Router Class Initialized
INFO - 2025-05-22 13:08:55 --> Output Class Initialized
INFO - 2025-05-22 13:08:55 --> Security Class Initialized
DEBUG - 2025-05-22 13:08:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:08:55 --> Input Class Initialized
INFO - 2025-05-22 13:08:55 --> Language Class Initialized
INFO - 2025-05-22 13:08:55 --> Loader Class Initialized
INFO - 2025-05-22 13:08:55 --> Helper loaded: url_helper
INFO - 2025-05-22 13:08:55 --> Helper loaded: form_helper
INFO - 2025-05-22 13:08:55 --> Database Driver Class Initialized
DEBUG - 2025-05-22 13:08:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 13:08:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 13:08:55 --> Controller Class Initialized
INFO - 2025-05-22 13:08:55 --> Model "User_model" initialized
INFO - 2025-05-22 13:08:55 --> Model "Workout_model" initialized
INFO - 2025-05-22 13:08:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-22 13:08:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-22 13:08:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-22 13:08:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-22 13:08:55 --> Final output sent to browser
DEBUG - 2025-05-22 13:08:55 --> Total execution time: 0.3086
INFO - 2025-05-22 13:08:59 --> Config Class Initialized
INFO - 2025-05-22 13:08:59 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:08:59 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:08:59 --> Utf8 Class Initialized
INFO - 2025-05-22 13:08:59 --> URI Class Initialized
INFO - 2025-05-22 13:08:59 --> Router Class Initialized
INFO - 2025-05-22 13:08:59 --> Output Class Initialized
INFO - 2025-05-22 13:08:59 --> Security Class Initialized
DEBUG - 2025-05-22 13:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:08:59 --> Input Class Initialized
INFO - 2025-05-22 13:08:59 --> Language Class Initialized
INFO - 2025-05-22 13:08:59 --> Loader Class Initialized
INFO - 2025-05-22 13:08:59 --> Helper loaded: url_helper
INFO - 2025-05-22 13:08:59 --> Helper loaded: form_helper
INFO - 2025-05-22 13:08:59 --> Database Driver Class Initialized
DEBUG - 2025-05-22 13:08:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 13:08:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 13:08:59 --> Controller Class Initialized
INFO - 2025-05-22 13:08:59 --> Model "Workout_model" initialized
INFO - 2025-05-22 13:08:59 --> Model "User_model" initialized
INFO - 2025-05-22 13:08:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-22 13:08:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-22 13:08:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga.php
INFO - 2025-05-22 13:08:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-22 13:08:59 --> Final output sent to browser
DEBUG - 2025-05-22 13:08:59 --> Total execution time: 0.1423
INFO - 2025-05-22 13:38:01 --> Config Class Initialized
INFO - 2025-05-22 13:38:01 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:38:01 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:38:01 --> Utf8 Class Initialized
INFO - 2025-05-22 13:38:01 --> URI Class Initialized
INFO - 2025-05-22 13:38:01 --> Router Class Initialized
INFO - 2025-05-22 13:38:01 --> Output Class Initialized
INFO - 2025-05-22 13:38:01 --> Security Class Initialized
DEBUG - 2025-05-22 13:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:38:01 --> Input Class Initialized
INFO - 2025-05-22 13:38:01 --> Language Class Initialized
INFO - 2025-05-22 13:38:01 --> Loader Class Initialized
INFO - 2025-05-22 13:38:01 --> Helper loaded: url_helper
INFO - 2025-05-22 13:38:01 --> Helper loaded: form_helper
INFO - 2025-05-22 13:38:01 --> Database Driver Class Initialized
DEBUG - 2025-05-22 13:38:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 13:38:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 13:38:01 --> Controller Class Initialized
INFO - 2025-05-22 13:38:01 --> Model "Progress_model" initialized
INFO - 2025-05-22 13:38:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\progress_view.php
INFO - 2025-05-22 13:38:01 --> Final output sent to browser
DEBUG - 2025-05-22 13:38:01 --> Total execution time: 0.0595
INFO - 2025-05-22 13:38:01 --> Config Class Initialized
INFO - 2025-05-22 13:38:01 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:38:01 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:38:01 --> Utf8 Class Initialized
INFO - 2025-05-22 13:38:01 --> URI Class Initialized
INFO - 2025-05-22 13:38:01 --> Router Class Initialized
INFO - 2025-05-22 13:38:01 --> Output Class Initialized
INFO - 2025-05-22 13:38:01 --> Security Class Initialized
DEBUG - 2025-05-22 13:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:38:01 --> Input Class Initialized
INFO - 2025-05-22 13:38:01 --> Language Class Initialized
INFO - 2025-05-22 13:38:01 --> Loader Class Initialized
INFO - 2025-05-22 13:38:01 --> Helper loaded: url_helper
INFO - 2025-05-22 13:38:01 --> Helper loaded: form_helper
INFO - 2025-05-22 13:38:01 --> Database Driver Class Initialized
DEBUG - 2025-05-22 13:38:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 13:38:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 13:38:01 --> Controller Class Initialized
INFO - 2025-05-22 13:38:01 --> Model "Progress_model" initialized
INFO - 2025-05-22 13:38:01 --> Final output sent to browser
DEBUG - 2025-05-22 13:38:01 --> Total execution time: 0.0653
INFO - 2025-05-22 13:38:06 --> Config Class Initialized
INFO - 2025-05-22 13:38:06 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:38:06 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:38:06 --> Utf8 Class Initialized
INFO - 2025-05-22 13:38:06 --> URI Class Initialized
INFO - 2025-05-22 13:38:06 --> Router Class Initialized
INFO - 2025-05-22 13:38:06 --> Output Class Initialized
INFO - 2025-05-22 13:38:06 --> Security Class Initialized
DEBUG - 2025-05-22 13:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:38:06 --> Input Class Initialized
INFO - 2025-05-22 13:38:06 --> Language Class Initialized
INFO - 2025-05-22 13:38:06 --> Loader Class Initialized
INFO - 2025-05-22 13:38:06 --> Helper loaded: url_helper
INFO - 2025-05-22 13:38:06 --> Helper loaded: form_helper
INFO - 2025-05-22 13:38:06 --> Database Driver Class Initialized
DEBUG - 2025-05-22 13:38:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 13:38:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 13:38:06 --> Controller Class Initialized
INFO - 2025-05-22 13:38:06 --> Model "Timer_model" initialized
INFO - 2025-05-22 13:38:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\timer_view.php
INFO - 2025-05-22 13:38:06 --> Final output sent to browser
DEBUG - 2025-05-22 13:38:06 --> Total execution time: 0.0681
INFO - 2025-05-22 13:39:08 --> Config Class Initialized
INFO - 2025-05-22 13:39:08 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:39:08 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:39:08 --> Utf8 Class Initialized
INFO - 2025-05-22 13:39:08 --> URI Class Initialized
INFO - 2025-05-22 13:39:08 --> Router Class Initialized
INFO - 2025-05-22 13:39:08 --> Output Class Initialized
INFO - 2025-05-22 13:39:08 --> Security Class Initialized
DEBUG - 2025-05-22 13:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:39:08 --> Input Class Initialized
INFO - 2025-05-22 13:39:08 --> Language Class Initialized
INFO - 2025-05-22 13:39:08 --> Loader Class Initialized
INFO - 2025-05-22 13:39:08 --> Helper loaded: url_helper
INFO - 2025-05-22 13:39:08 --> Helper loaded: form_helper
INFO - 2025-05-22 13:39:08 --> Database Driver Class Initialized
DEBUG - 2025-05-22 13:39:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 13:39:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 13:39:08 --> Controller Class Initialized
INFO - 2025-05-22 13:39:08 --> Model "Timer_model" initialized
INFO - 2025-05-22 13:39:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\timer_view.php
INFO - 2025-05-22 13:39:08 --> Final output sent to browser
DEBUG - 2025-05-22 13:39:08 --> Total execution time: 0.0814
INFO - 2025-05-22 13:39:19 --> Config Class Initialized
INFO - 2025-05-22 13:39:19 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:39:19 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:39:19 --> Utf8 Class Initialized
INFO - 2025-05-22 13:39:19 --> URI Class Initialized
INFO - 2025-05-22 13:39:19 --> Router Class Initialized
INFO - 2025-05-22 13:39:19 --> Output Class Initialized
INFO - 2025-05-22 13:39:19 --> Security Class Initialized
DEBUG - 2025-05-22 13:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:39:19 --> Input Class Initialized
INFO - 2025-05-22 13:39:20 --> Language Class Initialized
INFO - 2025-05-22 13:39:20 --> Loader Class Initialized
INFO - 2025-05-22 13:39:20 --> Helper loaded: url_helper
INFO - 2025-05-22 13:39:20 --> Helper loaded: form_helper
INFO - 2025-05-22 13:39:20 --> Database Driver Class Initialized
DEBUG - 2025-05-22 13:39:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 13:39:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 13:39:20 --> Controller Class Initialized
INFO - 2025-05-22 13:39:20 --> Model "Timer_model" initialized
INFO - 2025-05-22 13:39:20 --> Final output sent to browser
DEBUG - 2025-05-22 13:39:20 --> Total execution time: 0.0614
INFO - 2025-05-22 13:39:21 --> Config Class Initialized
INFO - 2025-05-22 13:39:21 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:39:21 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:39:21 --> Utf8 Class Initialized
INFO - 2025-05-22 13:39:21 --> URI Class Initialized
INFO - 2025-05-22 13:39:21 --> Router Class Initialized
INFO - 2025-05-22 13:39:21 --> Output Class Initialized
INFO - 2025-05-22 13:39:21 --> Security Class Initialized
DEBUG - 2025-05-22 13:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:39:21 --> Input Class Initialized
INFO - 2025-05-22 13:39:21 --> Language Class Initialized
INFO - 2025-05-22 13:39:21 --> Loader Class Initialized
INFO - 2025-05-22 13:39:21 --> Helper loaded: url_helper
INFO - 2025-05-22 13:39:21 --> Helper loaded: form_helper
INFO - 2025-05-22 13:39:21 --> Database Driver Class Initialized
DEBUG - 2025-05-22 13:39:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 13:39:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 13:39:21 --> Controller Class Initialized
INFO - 2025-05-22 13:39:21 --> Model "Timer_model" initialized
INFO - 2025-05-22 13:39:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\timer_view.php
INFO - 2025-05-22 13:39:21 --> Final output sent to browser
DEBUG - 2025-05-22 13:39:21 --> Total execution time: 0.0800
INFO - 2025-05-22 13:39:26 --> Config Class Initialized
INFO - 2025-05-22 13:39:27 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:39:27 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:39:27 --> Utf8 Class Initialized
INFO - 2025-05-22 13:39:27 --> URI Class Initialized
INFO - 2025-05-22 13:39:27 --> Router Class Initialized
INFO - 2025-05-22 13:39:27 --> Output Class Initialized
INFO - 2025-05-22 13:39:27 --> Security Class Initialized
DEBUG - 2025-05-22 13:39:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:39:27 --> Input Class Initialized
INFO - 2025-05-22 13:39:27 --> Language Class Initialized
INFO - 2025-05-22 13:39:27 --> Loader Class Initialized
INFO - 2025-05-22 13:39:27 --> Helper loaded: url_helper
INFO - 2025-05-22 13:39:27 --> Helper loaded: form_helper
INFO - 2025-05-22 13:39:27 --> Database Driver Class Initialized
DEBUG - 2025-05-22 13:39:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 13:39:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 13:39:27 --> Controller Class Initialized
INFO - 2025-05-22 13:39:27 --> Model "Progress_model" initialized
INFO - 2025-05-22 13:39:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\progress_view.php
INFO - 2025-05-22 13:39:27 --> Final output sent to browser
DEBUG - 2025-05-22 13:39:27 --> Total execution time: 0.0666
INFO - 2025-05-22 13:39:27 --> Config Class Initialized
INFO - 2025-05-22 13:39:27 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:39:27 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:39:27 --> Utf8 Class Initialized
INFO - 2025-05-22 13:39:27 --> URI Class Initialized
INFO - 2025-05-22 13:39:27 --> Router Class Initialized
INFO - 2025-05-22 13:39:27 --> Output Class Initialized
INFO - 2025-05-22 13:39:27 --> Security Class Initialized
DEBUG - 2025-05-22 13:39:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:39:27 --> Input Class Initialized
INFO - 2025-05-22 13:39:27 --> Language Class Initialized
INFO - 2025-05-22 13:39:27 --> Loader Class Initialized
INFO - 2025-05-22 13:39:27 --> Helper loaded: url_helper
INFO - 2025-05-22 13:39:27 --> Helper loaded: form_helper
INFO - 2025-05-22 13:39:27 --> Database Driver Class Initialized
DEBUG - 2025-05-22 13:39:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 13:39:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 13:39:27 --> Controller Class Initialized
INFO - 2025-05-22 13:39:27 --> Model "Progress_model" initialized
INFO - 2025-05-22 13:39:27 --> Final output sent to browser
DEBUG - 2025-05-22 13:39:27 --> Total execution time: 0.0683
INFO - 2025-05-22 13:39:31 --> Config Class Initialized
INFO - 2025-05-22 13:39:31 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:39:31 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:39:31 --> Utf8 Class Initialized
INFO - 2025-05-22 13:39:31 --> URI Class Initialized
INFO - 2025-05-22 13:39:31 --> Router Class Initialized
INFO - 2025-05-22 13:39:31 --> Output Class Initialized
INFO - 2025-05-22 13:39:31 --> Security Class Initialized
DEBUG - 2025-05-22 13:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:39:31 --> Input Class Initialized
INFO - 2025-05-22 13:39:31 --> Language Class Initialized
INFO - 2025-05-22 13:39:31 --> Loader Class Initialized
INFO - 2025-05-22 13:39:31 --> Helper loaded: url_helper
INFO - 2025-05-22 13:39:31 --> Helper loaded: form_helper
INFO - 2025-05-22 13:39:31 --> Database Driver Class Initialized
DEBUG - 2025-05-22 13:39:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 13:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 13:39:31 --> Controller Class Initialized
INFO - 2025-05-22 13:39:31 --> Model "Progress_model" initialized
INFO - 2025-05-22 13:39:31 --> Final output sent to browser
DEBUG - 2025-05-22 13:39:31 --> Total execution time: 0.0555
INFO - 2025-05-22 13:39:34 --> Config Class Initialized
INFO - 2025-05-22 13:39:34 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:39:34 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:39:34 --> Utf8 Class Initialized
INFO - 2025-05-22 13:39:34 --> URI Class Initialized
INFO - 2025-05-22 13:39:34 --> Router Class Initialized
INFO - 2025-05-22 13:39:34 --> Output Class Initialized
INFO - 2025-05-22 13:39:34 --> Security Class Initialized
DEBUG - 2025-05-22 13:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:39:34 --> Input Class Initialized
INFO - 2025-05-22 13:39:34 --> Language Class Initialized
INFO - 2025-05-22 13:39:34 --> Loader Class Initialized
INFO - 2025-05-22 13:39:34 --> Helper loaded: url_helper
INFO - 2025-05-22 13:39:34 --> Helper loaded: form_helper
INFO - 2025-05-22 13:39:34 --> Database Driver Class Initialized
DEBUG - 2025-05-22 13:39:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 13:39:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 13:39:34 --> Controller Class Initialized
INFO - 2025-05-22 13:39:34 --> Model "Progress_model" initialized
INFO - 2025-05-22 13:39:34 --> Final output sent to browser
DEBUG - 2025-05-22 13:39:34 --> Total execution time: 0.0584
INFO - 2025-05-22 13:39:36 --> Config Class Initialized
INFO - 2025-05-22 13:39:36 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:39:36 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:39:36 --> Utf8 Class Initialized
INFO - 2025-05-22 13:39:36 --> URI Class Initialized
INFO - 2025-05-22 13:39:36 --> Router Class Initialized
INFO - 2025-05-22 13:39:36 --> Output Class Initialized
INFO - 2025-05-22 13:39:36 --> Security Class Initialized
DEBUG - 2025-05-22 13:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:39:36 --> Input Class Initialized
INFO - 2025-05-22 13:39:36 --> Language Class Initialized
INFO - 2025-05-22 13:39:36 --> Loader Class Initialized
INFO - 2025-05-22 13:39:36 --> Helper loaded: url_helper
INFO - 2025-05-22 13:39:36 --> Helper loaded: form_helper
INFO - 2025-05-22 13:39:36 --> Database Driver Class Initialized
DEBUG - 2025-05-22 13:39:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 13:39:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 13:39:36 --> Controller Class Initialized
INFO - 2025-05-22 13:39:36 --> Model "Progress_model" initialized
INFO - 2025-05-22 13:39:36 --> Final output sent to browser
DEBUG - 2025-05-22 13:39:36 --> Total execution time: 0.0698
INFO - 2025-05-22 13:40:42 --> Config Class Initialized
INFO - 2025-05-22 13:40:42 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:40:42 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:40:42 --> Utf8 Class Initialized
INFO - 2025-05-22 13:40:42 --> URI Class Initialized
INFO - 2025-05-22 13:40:42 --> Router Class Initialized
INFO - 2025-05-22 13:40:42 --> Output Class Initialized
INFO - 2025-05-22 13:40:42 --> Security Class Initialized
DEBUG - 2025-05-22 13:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:40:42 --> Input Class Initialized
INFO - 2025-05-22 13:40:42 --> Language Class Initialized
INFO - 2025-05-22 13:40:42 --> Loader Class Initialized
INFO - 2025-05-22 13:40:42 --> Helper loaded: url_helper
INFO - 2025-05-22 13:40:42 --> Helper loaded: form_helper
INFO - 2025-05-22 13:40:42 --> Database Driver Class Initialized
DEBUG - 2025-05-22 13:40:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 13:40:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 13:40:42 --> Controller Class Initialized
INFO - 2025-05-22 13:40:42 --> Model "Progress_model" initialized
INFO - 2025-05-22 13:40:42 --> Final output sent to browser
DEBUG - 2025-05-22 13:40:42 --> Total execution time: 0.0793
INFO - 2025-05-22 13:41:24 --> Config Class Initialized
INFO - 2025-05-22 13:41:24 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:41:24 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:41:24 --> Utf8 Class Initialized
INFO - 2025-05-22 13:41:24 --> URI Class Initialized
INFO - 2025-05-22 13:41:24 --> Router Class Initialized
INFO - 2025-05-22 13:41:24 --> Output Class Initialized
INFO - 2025-05-22 13:41:24 --> Security Class Initialized
DEBUG - 2025-05-22 13:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:41:24 --> Input Class Initialized
INFO - 2025-05-22 13:41:24 --> Language Class Initialized
INFO - 2025-05-22 13:41:24 --> Loader Class Initialized
INFO - 2025-05-22 13:41:24 --> Helper loaded: url_helper
INFO - 2025-05-22 13:41:24 --> Helper loaded: form_helper
INFO - 2025-05-22 13:41:24 --> Database Driver Class Initialized
DEBUG - 2025-05-22 13:41:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 13:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 13:41:24 --> Controller Class Initialized
INFO - 2025-05-22 13:41:24 --> Model "Progress_model" initialized
INFO - 2025-05-22 13:41:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\progress_view.php
INFO - 2025-05-22 13:41:24 --> Final output sent to browser
DEBUG - 2025-05-22 13:41:24 --> Total execution time: 0.0582
INFO - 2025-05-22 13:41:24 --> Config Class Initialized
INFO - 2025-05-22 13:41:24 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:41:24 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:41:24 --> Utf8 Class Initialized
INFO - 2025-05-22 13:41:24 --> URI Class Initialized
INFO - 2025-05-22 13:41:24 --> Router Class Initialized
INFO - 2025-05-22 13:41:24 --> Output Class Initialized
INFO - 2025-05-22 13:41:24 --> Security Class Initialized
DEBUG - 2025-05-22 13:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:41:24 --> Input Class Initialized
INFO - 2025-05-22 13:41:24 --> Language Class Initialized
INFO - 2025-05-22 13:41:24 --> Loader Class Initialized
INFO - 2025-05-22 13:41:24 --> Helper loaded: url_helper
INFO - 2025-05-22 13:41:24 --> Helper loaded: form_helper
INFO - 2025-05-22 13:41:24 --> Database Driver Class Initialized
DEBUG - 2025-05-22 13:41:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 13:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 13:41:24 --> Controller Class Initialized
INFO - 2025-05-22 13:41:24 --> Model "Progress_model" initialized
ERROR - 2025-05-22 13:41:24 --> Query error: Table 'fitnessrec.progress' doesn't exist - Invalid query: SELECT *
FROM `progress`
WHERE `status` = 'selesai'
INFO - 2025-05-22 13:41:24 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-22 13:41:33 --> Config Class Initialized
INFO - 2025-05-22 13:41:33 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:41:33 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:41:33 --> Utf8 Class Initialized
INFO - 2025-05-22 13:41:33 --> URI Class Initialized
INFO - 2025-05-22 13:41:33 --> Router Class Initialized
INFO - 2025-05-22 13:41:33 --> Output Class Initialized
INFO - 2025-05-22 13:41:33 --> Security Class Initialized
DEBUG - 2025-05-22 13:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:41:33 --> Input Class Initialized
INFO - 2025-05-22 13:41:33 --> Language Class Initialized
INFO - 2025-05-22 13:41:33 --> Loader Class Initialized
INFO - 2025-05-22 13:41:33 --> Helper loaded: url_helper
INFO - 2025-05-22 13:41:33 --> Helper loaded: form_helper
INFO - 2025-05-22 13:41:33 --> Database Driver Class Initialized
DEBUG - 2025-05-22 13:41:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 13:41:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 13:41:33 --> Controller Class Initialized
INFO - 2025-05-22 13:41:33 --> Model "Timer_model" initialized
INFO - 2025-05-22 13:41:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\timer_view.php
INFO - 2025-05-22 13:41:33 --> Final output sent to browser
DEBUG - 2025-05-22 13:41:33 --> Total execution time: 0.0664
INFO - 2025-05-22 13:41:39 --> Config Class Initialized
INFO - 2025-05-22 13:41:39 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:41:39 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:41:39 --> Utf8 Class Initialized
INFO - 2025-05-22 13:41:39 --> URI Class Initialized
INFO - 2025-05-22 13:41:39 --> Router Class Initialized
INFO - 2025-05-22 13:41:39 --> Output Class Initialized
INFO - 2025-05-22 13:41:39 --> Security Class Initialized
DEBUG - 2025-05-22 13:41:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:41:39 --> Input Class Initialized
INFO - 2025-05-22 13:41:39 --> Language Class Initialized
INFO - 2025-05-22 13:41:39 --> Loader Class Initialized
INFO - 2025-05-22 13:41:39 --> Helper loaded: url_helper
INFO - 2025-05-22 13:41:39 --> Helper loaded: form_helper
INFO - 2025-05-22 13:41:39 --> Database Driver Class Initialized
DEBUG - 2025-05-22 13:41:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 13:41:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 13:41:39 --> Controller Class Initialized
INFO - 2025-05-22 13:41:39 --> Model "Timer_model" initialized
INFO - 2025-05-22 13:41:39 --> Final output sent to browser
DEBUG - 2025-05-22 13:41:39 --> Total execution time: 0.0726
INFO - 2025-05-22 13:41:41 --> Config Class Initialized
INFO - 2025-05-22 13:41:41 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:41:41 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:41:41 --> Utf8 Class Initialized
INFO - 2025-05-22 13:41:41 --> URI Class Initialized
INFO - 2025-05-22 13:41:41 --> Router Class Initialized
INFO - 2025-05-22 13:41:41 --> Output Class Initialized
INFO - 2025-05-22 13:41:41 --> Security Class Initialized
DEBUG - 2025-05-22 13:41:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:41:41 --> Input Class Initialized
INFO - 2025-05-22 13:41:41 --> Language Class Initialized
INFO - 2025-05-22 13:41:41 --> Loader Class Initialized
INFO - 2025-05-22 13:41:41 --> Helper loaded: url_helper
INFO - 2025-05-22 13:41:41 --> Helper loaded: form_helper
INFO - 2025-05-22 13:41:41 --> Database Driver Class Initialized
DEBUG - 2025-05-22 13:41:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 13:41:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 13:41:41 --> Controller Class Initialized
INFO - 2025-05-22 13:41:41 --> Model "Timer_model" initialized
INFO - 2025-05-22 13:41:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\timer_view.php
INFO - 2025-05-22 13:41:41 --> Final output sent to browser
DEBUG - 2025-05-22 13:41:41 --> Total execution time: 0.0867
INFO - 2025-05-22 13:41:45 --> Config Class Initialized
INFO - 2025-05-22 13:41:45 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:41:45 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:41:45 --> Utf8 Class Initialized
INFO - 2025-05-22 13:41:45 --> URI Class Initialized
INFO - 2025-05-22 13:41:45 --> Router Class Initialized
INFO - 2025-05-22 13:41:45 --> Output Class Initialized
INFO - 2025-05-22 13:41:45 --> Security Class Initialized
DEBUG - 2025-05-22 13:41:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:41:45 --> Input Class Initialized
INFO - 2025-05-22 13:41:45 --> Language Class Initialized
INFO - 2025-05-22 13:41:45 --> Loader Class Initialized
INFO - 2025-05-22 13:41:45 --> Helper loaded: url_helper
INFO - 2025-05-22 13:41:45 --> Helper loaded: form_helper
INFO - 2025-05-22 13:41:45 --> Database Driver Class Initialized
DEBUG - 2025-05-22 13:41:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 13:41:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 13:41:45 --> Controller Class Initialized
INFO - 2025-05-22 13:41:45 --> Model "Progress_model" initialized
INFO - 2025-05-22 13:41:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\progress_view.php
INFO - 2025-05-22 13:41:45 --> Final output sent to browser
DEBUG - 2025-05-22 13:41:45 --> Total execution time: 0.0601
INFO - 2025-05-22 13:41:45 --> Config Class Initialized
INFO - 2025-05-22 13:41:45 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:41:45 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:41:45 --> Utf8 Class Initialized
INFO - 2025-05-22 13:41:45 --> URI Class Initialized
INFO - 2025-05-22 13:41:45 --> Router Class Initialized
INFO - 2025-05-22 13:41:45 --> Output Class Initialized
INFO - 2025-05-22 13:41:45 --> Security Class Initialized
DEBUG - 2025-05-22 13:41:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:41:45 --> Input Class Initialized
INFO - 2025-05-22 13:41:45 --> Language Class Initialized
INFO - 2025-05-22 13:41:45 --> Loader Class Initialized
INFO - 2025-05-22 13:41:45 --> Helper loaded: url_helper
INFO - 2025-05-22 13:41:45 --> Helper loaded: form_helper
INFO - 2025-05-22 13:41:45 --> Database Driver Class Initialized
DEBUG - 2025-05-22 13:41:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 13:41:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 13:41:45 --> Controller Class Initialized
INFO - 2025-05-22 13:41:45 --> Model "Progress_model" initialized
ERROR - 2025-05-22 13:41:45 --> Query error: Table 'fitnessrec.progress' doesn't exist - Invalid query: SELECT *
FROM `progress`
WHERE `status` = 'selesai'
INFO - 2025-05-22 13:41:45 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-22 13:42:34 --> Config Class Initialized
INFO - 2025-05-22 13:42:34 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:42:34 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:42:34 --> Utf8 Class Initialized
INFO - 2025-05-22 13:42:34 --> URI Class Initialized
INFO - 2025-05-22 13:42:34 --> Router Class Initialized
INFO - 2025-05-22 13:42:34 --> Output Class Initialized
INFO - 2025-05-22 13:42:34 --> Security Class Initialized
DEBUG - 2025-05-22 13:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:42:34 --> Input Class Initialized
INFO - 2025-05-22 13:42:34 --> Language Class Initialized
INFO - 2025-05-22 13:42:34 --> Loader Class Initialized
INFO - 2025-05-22 13:42:34 --> Helper loaded: url_helper
INFO - 2025-05-22 13:42:34 --> Helper loaded: form_helper
INFO - 2025-05-22 13:42:34 --> Database Driver Class Initialized
DEBUG - 2025-05-22 13:42:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 13:42:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 13:42:34 --> Controller Class Initialized
INFO - 2025-05-22 13:42:34 --> Model "Progress_model" initialized
INFO - 2025-05-22 13:42:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\progress_view.php
INFO - 2025-05-22 13:42:34 --> Final output sent to browser
DEBUG - 2025-05-22 13:42:34 --> Total execution time: 0.0540
INFO - 2025-05-22 13:42:34 --> Config Class Initialized
INFO - 2025-05-22 13:42:34 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:42:34 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:42:34 --> Utf8 Class Initialized
INFO - 2025-05-22 13:42:34 --> URI Class Initialized
INFO - 2025-05-22 13:42:34 --> Router Class Initialized
INFO - 2025-05-22 13:42:34 --> Output Class Initialized
INFO - 2025-05-22 13:42:34 --> Security Class Initialized
DEBUG - 2025-05-22 13:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:42:34 --> Input Class Initialized
INFO - 2025-05-22 13:42:34 --> Language Class Initialized
INFO - 2025-05-22 13:42:34 --> Loader Class Initialized
INFO - 2025-05-22 13:42:34 --> Helper loaded: url_helper
INFO - 2025-05-22 13:42:34 --> Helper loaded: form_helper
INFO - 2025-05-22 13:42:34 --> Database Driver Class Initialized
DEBUG - 2025-05-22 13:42:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 13:42:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 13:42:34 --> Controller Class Initialized
INFO - 2025-05-22 13:42:34 --> Model "Progress_model" initialized
INFO - 2025-05-22 13:42:34 --> Final output sent to browser
DEBUG - 2025-05-22 13:42:34 --> Total execution time: 0.0788
INFO - 2025-05-22 13:45:58 --> Config Class Initialized
INFO - 2025-05-22 13:45:58 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:45:58 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:45:58 --> Utf8 Class Initialized
INFO - 2025-05-22 13:45:58 --> URI Class Initialized
INFO - 2025-05-22 13:45:58 --> Router Class Initialized
INFO - 2025-05-22 13:45:58 --> Output Class Initialized
INFO - 2025-05-22 13:45:58 --> Security Class Initialized
DEBUG - 2025-05-22 13:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:45:58 --> Input Class Initialized
INFO - 2025-05-22 13:45:58 --> Language Class Initialized
INFO - 2025-05-22 13:45:58 --> Loader Class Initialized
INFO - 2025-05-22 13:45:58 --> Helper loaded: url_helper
INFO - 2025-05-22 13:45:58 --> Helper loaded: form_helper
INFO - 2025-05-22 13:45:58 --> Database Driver Class Initialized
DEBUG - 2025-05-22 13:45:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 13:45:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 13:45:58 --> Controller Class Initialized
INFO - 2025-05-22 13:45:58 --> Model "Progress_model" initialized
INFO - 2025-05-22 13:45:58 --> Final output sent to browser
DEBUG - 2025-05-22 13:45:58 --> Total execution time: 0.0527
INFO - 2025-05-22 13:52:12 --> Config Class Initialized
INFO - 2025-05-22 13:52:12 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:52:12 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:52:12 --> Utf8 Class Initialized
INFO - 2025-05-22 13:52:12 --> URI Class Initialized
INFO - 2025-05-22 13:52:12 --> Router Class Initialized
INFO - 2025-05-22 13:52:12 --> Output Class Initialized
INFO - 2025-05-22 13:52:12 --> Security Class Initialized
DEBUG - 2025-05-22 13:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:52:12 --> Input Class Initialized
INFO - 2025-05-22 13:52:12 --> Language Class Initialized
INFO - 2025-05-22 13:52:12 --> Loader Class Initialized
INFO - 2025-05-22 13:52:12 --> Helper loaded: url_helper
INFO - 2025-05-22 13:52:12 --> Helper loaded: form_helper
INFO - 2025-05-22 13:52:12 --> Database Driver Class Initialized
DEBUG - 2025-05-22 13:52:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 13:52:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 13:52:12 --> Controller Class Initialized
INFO - 2025-05-22 13:52:12 --> Model "Progress_model" initialized
INFO - 2025-05-22 13:52:12 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\progress_view.php
INFO - 2025-05-22 13:52:12 --> Final output sent to browser
DEBUG - 2025-05-22 13:52:12 --> Total execution time: 0.0739
INFO - 2025-05-22 13:52:13 --> Config Class Initialized
INFO - 2025-05-22 13:52:13 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:52:13 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:52:13 --> Utf8 Class Initialized
INFO - 2025-05-22 13:52:13 --> URI Class Initialized
INFO - 2025-05-22 13:52:13 --> Router Class Initialized
INFO - 2025-05-22 13:52:13 --> Output Class Initialized
INFO - 2025-05-22 13:52:13 --> Security Class Initialized
DEBUG - 2025-05-22 13:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:52:13 --> Input Class Initialized
INFO - 2025-05-22 13:52:13 --> Language Class Initialized
INFO - 2025-05-22 13:52:13 --> Loader Class Initialized
INFO - 2025-05-22 13:52:13 --> Helper loaded: url_helper
INFO - 2025-05-22 13:52:13 --> Helper loaded: form_helper
INFO - 2025-05-22 13:52:13 --> Database Driver Class Initialized
DEBUG - 2025-05-22 13:52:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 13:52:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 13:52:13 --> Controller Class Initialized
INFO - 2025-05-22 13:52:13 --> Model "Progress_model" initialized
INFO - 2025-05-22 13:52:13 --> Final output sent to browser
DEBUG - 2025-05-22 13:52:13 --> Total execution time: 0.0869
INFO - 2025-05-22 13:52:34 --> Config Class Initialized
INFO - 2025-05-22 13:52:34 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:52:34 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:52:34 --> Utf8 Class Initialized
INFO - 2025-05-22 13:52:34 --> URI Class Initialized
INFO - 2025-05-22 13:52:34 --> Router Class Initialized
INFO - 2025-05-22 13:52:34 --> Output Class Initialized
INFO - 2025-05-22 13:52:34 --> Security Class Initialized
DEBUG - 2025-05-22 13:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:52:34 --> Input Class Initialized
INFO - 2025-05-22 13:52:34 --> Language Class Initialized
INFO - 2025-05-22 13:52:34 --> Loader Class Initialized
INFO - 2025-05-22 13:52:34 --> Helper loaded: url_helper
INFO - 2025-05-22 13:52:34 --> Helper loaded: form_helper
INFO - 2025-05-22 13:52:34 --> Database Driver Class Initialized
DEBUG - 2025-05-22 13:52:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 13:52:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 13:52:34 --> Controller Class Initialized
INFO - 2025-05-22 13:52:34 --> Model "Progress_model" initialized
INFO - 2025-05-22 13:52:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\progress_view.php
INFO - 2025-05-22 13:52:34 --> Final output sent to browser
DEBUG - 2025-05-22 13:52:34 --> Total execution time: 0.0595
INFO - 2025-05-22 13:52:34 --> Config Class Initialized
INFO - 2025-05-22 13:52:34 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:52:34 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:52:34 --> Utf8 Class Initialized
INFO - 2025-05-22 13:52:34 --> URI Class Initialized
INFO - 2025-05-22 13:52:34 --> Router Class Initialized
INFO - 2025-05-22 13:52:34 --> Output Class Initialized
INFO - 2025-05-22 13:52:34 --> Security Class Initialized
DEBUG - 2025-05-22 13:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:52:34 --> Input Class Initialized
INFO - 2025-05-22 13:52:34 --> Language Class Initialized
INFO - 2025-05-22 13:52:34 --> Loader Class Initialized
INFO - 2025-05-22 13:52:34 --> Helper loaded: url_helper
INFO - 2025-05-22 13:52:34 --> Helper loaded: form_helper
INFO - 2025-05-22 13:52:34 --> Database Driver Class Initialized
DEBUG - 2025-05-22 13:52:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 13:52:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 13:52:34 --> Controller Class Initialized
INFO - 2025-05-22 13:52:34 --> Model "Progress_model" initialized
INFO - 2025-05-22 13:52:34 --> Final output sent to browser
DEBUG - 2025-05-22 13:52:34 --> Total execution time: 0.0692
INFO - 2025-05-22 13:52:37 --> Config Class Initialized
INFO - 2025-05-22 13:52:37 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:52:37 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:52:37 --> Utf8 Class Initialized
INFO - 2025-05-22 13:52:37 --> URI Class Initialized
INFO - 2025-05-22 13:52:37 --> Router Class Initialized
INFO - 2025-05-22 13:52:37 --> Output Class Initialized
INFO - 2025-05-22 13:52:37 --> Security Class Initialized
DEBUG - 2025-05-22 13:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:52:37 --> Input Class Initialized
INFO - 2025-05-22 13:52:37 --> Language Class Initialized
ERROR - 2025-05-22 13:52:37 --> 404 Page Not Found: Progress/get_detail
INFO - 2025-05-22 13:52:38 --> Config Class Initialized
INFO - 2025-05-22 13:52:38 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:52:38 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:52:38 --> Utf8 Class Initialized
INFO - 2025-05-22 13:52:38 --> URI Class Initialized
INFO - 2025-05-22 13:52:38 --> Router Class Initialized
INFO - 2025-05-22 13:52:38 --> Output Class Initialized
INFO - 2025-05-22 13:52:38 --> Security Class Initialized
DEBUG - 2025-05-22 13:52:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:52:38 --> Input Class Initialized
INFO - 2025-05-22 13:52:38 --> Language Class Initialized
ERROR - 2025-05-22 13:52:38 --> 404 Page Not Found: Progress/get_detail
INFO - 2025-05-22 13:52:38 --> Config Class Initialized
INFO - 2025-05-22 13:52:38 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:52:38 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:52:38 --> Utf8 Class Initialized
INFO - 2025-05-22 13:52:38 --> URI Class Initialized
INFO - 2025-05-22 13:52:38 --> Router Class Initialized
INFO - 2025-05-22 13:52:38 --> Output Class Initialized
INFO - 2025-05-22 13:52:38 --> Security Class Initialized
DEBUG - 2025-05-22 13:52:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:52:38 --> Input Class Initialized
INFO - 2025-05-22 13:52:38 --> Language Class Initialized
ERROR - 2025-05-22 13:52:38 --> 404 Page Not Found: Progress/get_detail
INFO - 2025-05-22 13:52:41 --> Config Class Initialized
INFO - 2025-05-22 13:52:41 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:52:41 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:52:41 --> Utf8 Class Initialized
INFO - 2025-05-22 13:52:41 --> URI Class Initialized
INFO - 2025-05-22 13:52:41 --> Router Class Initialized
INFO - 2025-05-22 13:52:41 --> Output Class Initialized
INFO - 2025-05-22 13:52:41 --> Security Class Initialized
DEBUG - 2025-05-22 13:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:52:41 --> Input Class Initialized
INFO - 2025-05-22 13:52:41 --> Language Class Initialized
ERROR - 2025-05-22 13:52:41 --> 404 Page Not Found: Progress/get_detail
INFO - 2025-05-22 13:52:41 --> Config Class Initialized
INFO - 2025-05-22 13:52:41 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:52:41 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:52:41 --> Utf8 Class Initialized
INFO - 2025-05-22 13:52:41 --> URI Class Initialized
INFO - 2025-05-22 13:52:41 --> Router Class Initialized
INFO - 2025-05-22 13:52:41 --> Output Class Initialized
INFO - 2025-05-22 13:52:41 --> Security Class Initialized
DEBUG - 2025-05-22 13:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:52:41 --> Input Class Initialized
INFO - 2025-05-22 13:52:41 --> Language Class Initialized
ERROR - 2025-05-22 13:52:41 --> 404 Page Not Found: Progress/get_detail
INFO - 2025-05-22 13:52:41 --> Config Class Initialized
INFO - 2025-05-22 13:52:41 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:52:41 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:52:41 --> Utf8 Class Initialized
INFO - 2025-05-22 13:52:41 --> URI Class Initialized
INFO - 2025-05-22 13:52:41 --> Router Class Initialized
INFO - 2025-05-22 13:52:41 --> Output Class Initialized
INFO - 2025-05-22 13:52:41 --> Security Class Initialized
DEBUG - 2025-05-22 13:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:52:41 --> Input Class Initialized
INFO - 2025-05-22 13:52:41 --> Language Class Initialized
ERROR - 2025-05-22 13:52:41 --> 404 Page Not Found: Progress/get_detail
INFO - 2025-05-22 13:52:41 --> Config Class Initialized
INFO - 2025-05-22 13:52:41 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:52:41 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:52:41 --> Utf8 Class Initialized
INFO - 2025-05-22 13:52:41 --> URI Class Initialized
INFO - 2025-05-22 13:52:41 --> Router Class Initialized
INFO - 2025-05-22 13:52:41 --> Output Class Initialized
INFO - 2025-05-22 13:52:41 --> Security Class Initialized
DEBUG - 2025-05-22 13:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:52:41 --> Input Class Initialized
INFO - 2025-05-22 13:52:41 --> Language Class Initialized
ERROR - 2025-05-22 13:52:41 --> 404 Page Not Found: Progress/get_detail
INFO - 2025-05-22 13:54:32 --> Config Class Initialized
INFO - 2025-05-22 13:54:32 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:54:32 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:54:32 --> Utf8 Class Initialized
INFO - 2025-05-22 13:54:32 --> URI Class Initialized
INFO - 2025-05-22 13:54:32 --> Router Class Initialized
INFO - 2025-05-22 13:54:32 --> Output Class Initialized
INFO - 2025-05-22 13:54:32 --> Security Class Initialized
DEBUG - 2025-05-22 13:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:54:32 --> Input Class Initialized
INFO - 2025-05-22 13:54:32 --> Language Class Initialized
INFO - 2025-05-22 13:54:32 --> Loader Class Initialized
INFO - 2025-05-22 13:54:32 --> Helper loaded: url_helper
INFO - 2025-05-22 13:54:32 --> Helper loaded: form_helper
INFO - 2025-05-22 13:54:32 --> Database Driver Class Initialized
DEBUG - 2025-05-22 13:54:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 13:54:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 13:54:32 --> Controller Class Initialized
INFO - 2025-05-22 13:54:32 --> Model "Progress_model" initialized
INFO - 2025-05-22 13:54:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\progress_view.php
INFO - 2025-05-22 13:54:32 --> Final output sent to browser
DEBUG - 2025-05-22 13:54:32 --> Total execution time: 0.0629
INFO - 2025-05-22 13:54:33 --> Config Class Initialized
INFO - 2025-05-22 13:54:33 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:54:33 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:54:33 --> Utf8 Class Initialized
INFO - 2025-05-22 13:54:33 --> URI Class Initialized
INFO - 2025-05-22 13:54:33 --> Router Class Initialized
INFO - 2025-05-22 13:54:33 --> Output Class Initialized
INFO - 2025-05-22 13:54:33 --> Security Class Initialized
DEBUG - 2025-05-22 13:54:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:54:33 --> Input Class Initialized
INFO - 2025-05-22 13:54:33 --> Language Class Initialized
INFO - 2025-05-22 13:54:33 --> Loader Class Initialized
INFO - 2025-05-22 13:54:33 --> Helper loaded: url_helper
INFO - 2025-05-22 13:54:33 --> Helper loaded: form_helper
INFO - 2025-05-22 13:54:33 --> Database Driver Class Initialized
DEBUG - 2025-05-22 13:54:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 13:54:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 13:54:33 --> Controller Class Initialized
INFO - 2025-05-22 13:54:33 --> Model "Progress_model" initialized
INFO - 2025-05-22 13:54:33 --> Final output sent to browser
DEBUG - 2025-05-22 13:54:33 --> Total execution time: 0.0800
INFO - 2025-05-22 13:54:34 --> Config Class Initialized
INFO - 2025-05-22 13:54:34 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:54:34 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:54:34 --> Utf8 Class Initialized
INFO - 2025-05-22 13:54:34 --> URI Class Initialized
INFO - 2025-05-22 13:54:34 --> Router Class Initialized
INFO - 2025-05-22 13:54:34 --> Output Class Initialized
INFO - 2025-05-22 13:54:34 --> Security Class Initialized
DEBUG - 2025-05-22 13:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:54:34 --> Input Class Initialized
INFO - 2025-05-22 13:54:34 --> Language Class Initialized
INFO - 2025-05-22 13:54:34 --> Loader Class Initialized
INFO - 2025-05-22 13:54:34 --> Helper loaded: url_helper
INFO - 2025-05-22 13:54:34 --> Helper loaded: form_helper
INFO - 2025-05-22 13:54:34 --> Database Driver Class Initialized
DEBUG - 2025-05-22 13:54:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 13:54:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 13:54:34 --> Controller Class Initialized
INFO - 2025-05-22 13:54:34 --> Model "Progress_model" initialized
INFO - 2025-05-22 13:54:34 --> Final output sent to browser
DEBUG - 2025-05-22 13:54:34 --> Total execution time: 0.0617
INFO - 2025-05-22 13:54:39 --> Config Class Initialized
INFO - 2025-05-22 13:54:39 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:54:39 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:54:39 --> Utf8 Class Initialized
INFO - 2025-05-22 13:54:39 --> URI Class Initialized
INFO - 2025-05-22 13:54:39 --> Router Class Initialized
INFO - 2025-05-22 13:54:39 --> Output Class Initialized
INFO - 2025-05-22 13:54:39 --> Security Class Initialized
DEBUG - 2025-05-22 13:54:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:54:39 --> Input Class Initialized
INFO - 2025-05-22 13:54:39 --> Language Class Initialized
INFO - 2025-05-22 13:54:39 --> Loader Class Initialized
INFO - 2025-05-22 13:54:39 --> Helper loaded: url_helper
INFO - 2025-05-22 13:54:39 --> Helper loaded: form_helper
INFO - 2025-05-22 13:54:39 --> Database Driver Class Initialized
DEBUG - 2025-05-22 13:54:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 13:54:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 13:54:39 --> Controller Class Initialized
INFO - 2025-05-22 13:54:39 --> Model "Progress_model" initialized
INFO - 2025-05-22 13:54:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\progress_view.php
INFO - 2025-05-22 13:54:39 --> Final output sent to browser
DEBUG - 2025-05-22 13:54:39 --> Total execution time: 0.0764
INFO - 2025-05-22 13:54:39 --> Config Class Initialized
INFO - 2025-05-22 13:54:39 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:54:39 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:54:39 --> Utf8 Class Initialized
INFO - 2025-05-22 13:54:39 --> URI Class Initialized
INFO - 2025-05-22 13:54:39 --> Router Class Initialized
INFO - 2025-05-22 13:54:39 --> Output Class Initialized
INFO - 2025-05-22 13:54:39 --> Security Class Initialized
DEBUG - 2025-05-22 13:54:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:54:39 --> Input Class Initialized
INFO - 2025-05-22 13:54:39 --> Language Class Initialized
INFO - 2025-05-22 13:54:39 --> Loader Class Initialized
INFO - 2025-05-22 13:54:39 --> Helper loaded: url_helper
INFO - 2025-05-22 13:54:39 --> Helper loaded: form_helper
INFO - 2025-05-22 13:54:39 --> Database Driver Class Initialized
DEBUG - 2025-05-22 13:54:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 13:54:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 13:54:39 --> Controller Class Initialized
INFO - 2025-05-22 13:54:39 --> Model "Progress_model" initialized
INFO - 2025-05-22 13:54:39 --> Final output sent to browser
DEBUG - 2025-05-22 13:54:39 --> Total execution time: 0.0703
INFO - 2025-05-22 13:54:41 --> Config Class Initialized
INFO - 2025-05-22 13:54:41 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:54:41 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:54:41 --> Utf8 Class Initialized
INFO - 2025-05-22 13:54:41 --> URI Class Initialized
INFO - 2025-05-22 13:54:41 --> Router Class Initialized
INFO - 2025-05-22 13:54:41 --> Output Class Initialized
INFO - 2025-05-22 13:54:41 --> Security Class Initialized
DEBUG - 2025-05-22 13:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:54:41 --> Input Class Initialized
INFO - 2025-05-22 13:54:41 --> Language Class Initialized
INFO - 2025-05-22 13:54:41 --> Loader Class Initialized
INFO - 2025-05-22 13:54:41 --> Helper loaded: url_helper
INFO - 2025-05-22 13:54:41 --> Helper loaded: form_helper
INFO - 2025-05-22 13:54:41 --> Database Driver Class Initialized
DEBUG - 2025-05-22 13:54:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 13:54:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 13:54:41 --> Controller Class Initialized
INFO - 2025-05-22 13:54:41 --> Model "Progress_model" initialized
INFO - 2025-05-22 13:54:41 --> Final output sent to browser
DEBUG - 2025-05-22 13:54:41 --> Total execution time: 0.0568
INFO - 2025-05-22 13:54:45 --> Config Class Initialized
INFO - 2025-05-22 13:54:45 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:54:45 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:54:45 --> Utf8 Class Initialized
INFO - 2025-05-22 13:54:45 --> URI Class Initialized
INFO - 2025-05-22 13:54:45 --> Router Class Initialized
INFO - 2025-05-22 13:54:45 --> Output Class Initialized
INFO - 2025-05-22 13:54:45 --> Security Class Initialized
DEBUG - 2025-05-22 13:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:54:45 --> Input Class Initialized
INFO - 2025-05-22 13:54:45 --> Language Class Initialized
INFO - 2025-05-22 13:54:45 --> Loader Class Initialized
INFO - 2025-05-22 13:54:45 --> Helper loaded: url_helper
INFO - 2025-05-22 13:54:45 --> Helper loaded: form_helper
INFO - 2025-05-22 13:54:45 --> Database Driver Class Initialized
DEBUG - 2025-05-22 13:54:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 13:54:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 13:54:45 --> Controller Class Initialized
INFO - 2025-05-22 13:54:45 --> Model "Progress_model" initialized
INFO - 2025-05-22 13:54:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\progress_view.php
INFO - 2025-05-22 13:54:45 --> Final output sent to browser
DEBUG - 2025-05-22 13:54:45 --> Total execution time: 0.0756
INFO - 2025-05-22 13:54:45 --> Config Class Initialized
INFO - 2025-05-22 13:54:45 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:54:45 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:54:45 --> Utf8 Class Initialized
INFO - 2025-05-22 13:54:45 --> URI Class Initialized
INFO - 2025-05-22 13:54:45 --> Router Class Initialized
INFO - 2025-05-22 13:54:45 --> Output Class Initialized
INFO - 2025-05-22 13:54:45 --> Security Class Initialized
DEBUG - 2025-05-22 13:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:54:45 --> Input Class Initialized
INFO - 2025-05-22 13:54:45 --> Language Class Initialized
INFO - 2025-05-22 13:54:45 --> Loader Class Initialized
INFO - 2025-05-22 13:54:45 --> Helper loaded: url_helper
INFO - 2025-05-22 13:54:45 --> Helper loaded: form_helper
INFO - 2025-05-22 13:54:46 --> Database Driver Class Initialized
DEBUG - 2025-05-22 13:54:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 13:54:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 13:54:46 --> Controller Class Initialized
INFO - 2025-05-22 13:54:46 --> Model "Progress_model" initialized
INFO - 2025-05-22 13:54:46 --> Final output sent to browser
DEBUG - 2025-05-22 13:54:46 --> Total execution time: 0.0720
INFO - 2025-05-22 13:55:07 --> Config Class Initialized
INFO - 2025-05-22 13:55:07 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:55:07 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:55:07 --> Utf8 Class Initialized
INFO - 2025-05-22 13:55:07 --> URI Class Initialized
INFO - 2025-05-22 13:55:07 --> Router Class Initialized
INFO - 2025-05-22 13:55:07 --> Output Class Initialized
INFO - 2025-05-22 13:55:07 --> Security Class Initialized
DEBUG - 2025-05-22 13:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:55:07 --> Input Class Initialized
INFO - 2025-05-22 13:55:07 --> Language Class Initialized
INFO - 2025-05-22 13:55:07 --> Loader Class Initialized
INFO - 2025-05-22 13:55:07 --> Helper loaded: url_helper
INFO - 2025-05-22 13:55:07 --> Helper loaded: form_helper
INFO - 2025-05-22 13:55:07 --> Database Driver Class Initialized
DEBUG - 2025-05-22 13:55:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 13:55:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 13:55:07 --> Controller Class Initialized
INFO - 2025-05-22 13:55:07 --> Model "Progress_model" initialized
INFO - 2025-05-22 13:55:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\progress_view.php
INFO - 2025-05-22 13:55:07 --> Final output sent to browser
DEBUG - 2025-05-22 13:55:07 --> Total execution time: 0.0666
INFO - 2025-05-22 13:55:07 --> Config Class Initialized
INFO - 2025-05-22 13:55:07 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:55:07 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:55:07 --> Utf8 Class Initialized
INFO - 2025-05-22 13:55:07 --> URI Class Initialized
INFO - 2025-05-22 13:55:07 --> Router Class Initialized
INFO - 2025-05-22 13:55:07 --> Output Class Initialized
INFO - 2025-05-22 13:55:07 --> Security Class Initialized
DEBUG - 2025-05-22 13:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:55:07 --> Input Class Initialized
INFO - 2025-05-22 13:55:07 --> Language Class Initialized
INFO - 2025-05-22 13:55:07 --> Loader Class Initialized
INFO - 2025-05-22 13:55:07 --> Helper loaded: url_helper
INFO - 2025-05-22 13:55:07 --> Helper loaded: form_helper
INFO - 2025-05-22 13:55:07 --> Database Driver Class Initialized
DEBUG - 2025-05-22 13:55:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 13:55:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 13:55:07 --> Controller Class Initialized
INFO - 2025-05-22 13:55:07 --> Model "Progress_model" initialized
INFO - 2025-05-22 13:55:07 --> Final output sent to browser
DEBUG - 2025-05-22 13:55:07 --> Total execution time: 0.1006
INFO - 2025-05-22 13:55:09 --> Config Class Initialized
INFO - 2025-05-22 13:55:09 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:55:09 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:55:09 --> Utf8 Class Initialized
INFO - 2025-05-22 13:55:09 --> URI Class Initialized
INFO - 2025-05-22 13:55:09 --> Router Class Initialized
INFO - 2025-05-22 13:55:09 --> Output Class Initialized
INFO - 2025-05-22 13:55:09 --> Security Class Initialized
DEBUG - 2025-05-22 13:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:55:09 --> Input Class Initialized
INFO - 2025-05-22 13:55:09 --> Language Class Initialized
INFO - 2025-05-22 13:55:09 --> Loader Class Initialized
INFO - 2025-05-22 13:55:09 --> Helper loaded: url_helper
INFO - 2025-05-22 13:55:09 --> Helper loaded: form_helper
INFO - 2025-05-22 13:55:09 --> Database Driver Class Initialized
DEBUG - 2025-05-22 13:55:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 13:55:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 13:55:09 --> Controller Class Initialized
INFO - 2025-05-22 13:55:09 --> Model "Progress_model" initialized
INFO - 2025-05-22 13:55:09 --> Final output sent to browser
DEBUG - 2025-05-22 13:55:09 --> Total execution time: 0.0609
INFO - 2025-05-22 13:55:11 --> Config Class Initialized
INFO - 2025-05-22 13:55:11 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:55:11 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:55:11 --> Utf8 Class Initialized
INFO - 2025-05-22 13:55:11 --> URI Class Initialized
INFO - 2025-05-22 13:55:11 --> Router Class Initialized
INFO - 2025-05-22 13:55:11 --> Output Class Initialized
INFO - 2025-05-22 13:55:11 --> Security Class Initialized
DEBUG - 2025-05-22 13:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:55:11 --> Input Class Initialized
INFO - 2025-05-22 13:55:11 --> Language Class Initialized
INFO - 2025-05-22 13:55:11 --> Loader Class Initialized
INFO - 2025-05-22 13:55:11 --> Helper loaded: url_helper
INFO - 2025-05-22 13:55:11 --> Helper loaded: form_helper
INFO - 2025-05-22 13:55:11 --> Database Driver Class Initialized
DEBUG - 2025-05-22 13:55:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 13:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 13:55:11 --> Controller Class Initialized
INFO - 2025-05-22 13:55:11 --> Model "Progress_model" initialized
INFO - 2025-05-22 13:55:11 --> Final output sent to browser
DEBUG - 2025-05-22 13:55:11 --> Total execution time: 0.0789
INFO - 2025-05-22 13:55:46 --> Config Class Initialized
INFO - 2025-05-22 13:55:46 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:55:46 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:55:46 --> Utf8 Class Initialized
INFO - 2025-05-22 13:55:46 --> URI Class Initialized
INFO - 2025-05-22 13:55:46 --> Router Class Initialized
INFO - 2025-05-22 13:55:46 --> Output Class Initialized
INFO - 2025-05-22 13:55:46 --> Security Class Initialized
DEBUG - 2025-05-22 13:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:55:46 --> Input Class Initialized
INFO - 2025-05-22 13:55:46 --> Language Class Initialized
INFO - 2025-05-22 13:55:46 --> Loader Class Initialized
INFO - 2025-05-22 13:55:46 --> Helper loaded: url_helper
INFO - 2025-05-22 13:55:46 --> Helper loaded: form_helper
INFO - 2025-05-22 13:55:46 --> Database Driver Class Initialized
DEBUG - 2025-05-22 13:55:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 13:55:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 13:55:46 --> Controller Class Initialized
INFO - 2025-05-22 13:55:46 --> Model "Progress_model" initialized
INFO - 2025-05-22 13:55:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\progress_view.php
INFO - 2025-05-22 13:55:46 --> Final output sent to browser
DEBUG - 2025-05-22 13:55:46 --> Total execution time: 0.0609
INFO - 2025-05-22 13:55:46 --> Config Class Initialized
INFO - 2025-05-22 13:55:46 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:55:46 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:55:46 --> Utf8 Class Initialized
INFO - 2025-05-22 13:55:46 --> URI Class Initialized
INFO - 2025-05-22 13:55:46 --> Router Class Initialized
INFO - 2025-05-22 13:55:46 --> Output Class Initialized
INFO - 2025-05-22 13:55:46 --> Security Class Initialized
DEBUG - 2025-05-22 13:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:55:46 --> Input Class Initialized
INFO - 2025-05-22 13:55:46 --> Language Class Initialized
INFO - 2025-05-22 13:55:46 --> Loader Class Initialized
INFO - 2025-05-22 13:55:46 --> Helper loaded: url_helper
INFO - 2025-05-22 13:55:46 --> Helper loaded: form_helper
INFO - 2025-05-22 13:55:46 --> Database Driver Class Initialized
DEBUG - 2025-05-22 13:55:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 13:55:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 13:55:46 --> Controller Class Initialized
INFO - 2025-05-22 13:55:46 --> Model "Progress_model" initialized
INFO - 2025-05-22 13:55:46 --> Final output sent to browser
DEBUG - 2025-05-22 13:55:46 --> Total execution time: 0.0744
INFO - 2025-05-22 13:55:48 --> Config Class Initialized
INFO - 2025-05-22 13:55:48 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:55:48 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:55:48 --> Utf8 Class Initialized
INFO - 2025-05-22 13:55:48 --> URI Class Initialized
INFO - 2025-05-22 13:55:48 --> Router Class Initialized
INFO - 2025-05-22 13:55:48 --> Output Class Initialized
INFO - 2025-05-22 13:55:48 --> Security Class Initialized
DEBUG - 2025-05-22 13:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:55:48 --> Input Class Initialized
INFO - 2025-05-22 13:55:48 --> Language Class Initialized
INFO - 2025-05-22 13:55:48 --> Loader Class Initialized
INFO - 2025-05-22 13:55:48 --> Helper loaded: url_helper
INFO - 2025-05-22 13:55:48 --> Helper loaded: form_helper
INFO - 2025-05-22 13:55:48 --> Database Driver Class Initialized
DEBUG - 2025-05-22 13:55:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 13:55:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 13:55:48 --> Controller Class Initialized
INFO - 2025-05-22 13:55:48 --> Model "Progress_model" initialized
INFO - 2025-05-22 13:55:48 --> Final output sent to browser
DEBUG - 2025-05-22 13:55:48 --> Total execution time: 0.0635
INFO - 2025-05-22 13:57:27 --> Config Class Initialized
INFO - 2025-05-22 13:57:27 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:57:27 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:57:27 --> Utf8 Class Initialized
INFO - 2025-05-22 13:57:27 --> URI Class Initialized
INFO - 2025-05-22 13:57:27 --> Router Class Initialized
INFO - 2025-05-22 13:57:27 --> Output Class Initialized
INFO - 2025-05-22 13:57:27 --> Security Class Initialized
DEBUG - 2025-05-22 13:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:57:27 --> Input Class Initialized
INFO - 2025-05-22 13:57:27 --> Language Class Initialized
INFO - 2025-05-22 13:57:27 --> Loader Class Initialized
INFO - 2025-05-22 13:57:27 --> Helper loaded: url_helper
INFO - 2025-05-22 13:57:27 --> Helper loaded: form_helper
INFO - 2025-05-22 13:57:27 --> Database Driver Class Initialized
DEBUG - 2025-05-22 13:57:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 13:57:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 13:57:27 --> Controller Class Initialized
INFO - 2025-05-22 13:57:27 --> Model "Progress_model" initialized
INFO - 2025-05-22 13:57:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\progress_view.php
INFO - 2025-05-22 13:57:27 --> Final output sent to browser
DEBUG - 2025-05-22 13:57:27 --> Total execution time: 0.0883
INFO - 2025-05-22 13:57:27 --> Config Class Initialized
INFO - 2025-05-22 13:57:27 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:57:27 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:57:27 --> Utf8 Class Initialized
INFO - 2025-05-22 13:57:27 --> URI Class Initialized
INFO - 2025-05-22 13:57:27 --> Router Class Initialized
INFO - 2025-05-22 13:57:27 --> Output Class Initialized
INFO - 2025-05-22 13:57:27 --> Security Class Initialized
DEBUG - 2025-05-22 13:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:57:27 --> Input Class Initialized
INFO - 2025-05-22 13:57:27 --> Language Class Initialized
INFO - 2025-05-22 13:57:27 --> Loader Class Initialized
INFO - 2025-05-22 13:57:27 --> Helper loaded: url_helper
INFO - 2025-05-22 13:57:27 --> Helper loaded: form_helper
INFO - 2025-05-22 13:57:27 --> Database Driver Class Initialized
DEBUG - 2025-05-22 13:57:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 13:57:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 13:57:27 --> Controller Class Initialized
INFO - 2025-05-22 13:57:27 --> Model "Progress_model" initialized
INFO - 2025-05-22 13:57:27 --> Final output sent to browser
DEBUG - 2025-05-22 13:57:27 --> Total execution time: 0.0904
INFO - 2025-05-22 13:57:28 --> Config Class Initialized
INFO - 2025-05-22 13:57:28 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:57:28 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:57:28 --> Utf8 Class Initialized
INFO - 2025-05-22 13:57:28 --> URI Class Initialized
INFO - 2025-05-22 13:57:28 --> Router Class Initialized
INFO - 2025-05-22 13:57:28 --> Output Class Initialized
INFO - 2025-05-22 13:57:28 --> Security Class Initialized
DEBUG - 2025-05-22 13:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:57:28 --> Input Class Initialized
INFO - 2025-05-22 13:57:28 --> Language Class Initialized
ERROR - 2025-05-22 13:57:28 --> 404 Page Not Found: Progress/get_detail
INFO - 2025-05-22 13:57:31 --> Config Class Initialized
INFO - 2025-05-22 13:57:31 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:57:31 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:57:31 --> Utf8 Class Initialized
INFO - 2025-05-22 13:57:31 --> URI Class Initialized
INFO - 2025-05-22 13:57:31 --> Router Class Initialized
INFO - 2025-05-22 13:57:31 --> Output Class Initialized
INFO - 2025-05-22 13:57:31 --> Security Class Initialized
DEBUG - 2025-05-22 13:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:57:31 --> Input Class Initialized
INFO - 2025-05-22 13:57:31 --> Language Class Initialized
ERROR - 2025-05-22 13:57:31 --> 404 Page Not Found: Progress/get_detail
INFO - 2025-05-22 13:57:46 --> Config Class Initialized
INFO - 2025-05-22 13:57:46 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:57:46 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:57:46 --> Utf8 Class Initialized
INFO - 2025-05-22 13:57:46 --> URI Class Initialized
INFO - 2025-05-22 13:57:46 --> Router Class Initialized
INFO - 2025-05-22 13:57:46 --> Output Class Initialized
INFO - 2025-05-22 13:57:46 --> Security Class Initialized
DEBUG - 2025-05-22 13:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:57:46 --> Input Class Initialized
INFO - 2025-05-22 13:57:46 --> Language Class Initialized
INFO - 2025-05-22 13:57:46 --> Loader Class Initialized
INFO - 2025-05-22 13:57:46 --> Helper loaded: url_helper
INFO - 2025-05-22 13:57:46 --> Helper loaded: form_helper
INFO - 2025-05-22 13:57:46 --> Database Driver Class Initialized
DEBUG - 2025-05-22 13:57:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 13:57:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 13:57:46 --> Controller Class Initialized
INFO - 2025-05-22 13:57:46 --> Model "Progress_model" initialized
INFO - 2025-05-22 13:57:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\progress_view.php
INFO - 2025-05-22 13:57:46 --> Final output sent to browser
DEBUG - 2025-05-22 13:57:46 --> Total execution time: 0.0701
INFO - 2025-05-22 13:57:46 --> Config Class Initialized
INFO - 2025-05-22 13:57:46 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:57:46 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:57:46 --> Utf8 Class Initialized
INFO - 2025-05-22 13:57:46 --> URI Class Initialized
INFO - 2025-05-22 13:57:46 --> Router Class Initialized
INFO - 2025-05-22 13:57:46 --> Output Class Initialized
INFO - 2025-05-22 13:57:46 --> Security Class Initialized
DEBUG - 2025-05-22 13:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:57:46 --> Input Class Initialized
INFO - 2025-05-22 13:57:46 --> Language Class Initialized
INFO - 2025-05-22 13:57:46 --> Loader Class Initialized
INFO - 2025-05-22 13:57:46 --> Helper loaded: url_helper
INFO - 2025-05-22 13:57:46 --> Helper loaded: form_helper
INFO - 2025-05-22 13:57:46 --> Database Driver Class Initialized
DEBUG - 2025-05-22 13:57:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 13:57:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 13:57:46 --> Controller Class Initialized
INFO - 2025-05-22 13:57:47 --> Model "Progress_model" initialized
INFO - 2025-05-22 13:57:47 --> Final output sent to browser
DEBUG - 2025-05-22 13:57:47 --> Total execution time: 0.0712
INFO - 2025-05-22 13:57:48 --> Config Class Initialized
INFO - 2025-05-22 13:57:48 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:57:48 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:57:48 --> Utf8 Class Initialized
INFO - 2025-05-22 13:57:48 --> URI Class Initialized
INFO - 2025-05-22 13:57:48 --> Router Class Initialized
INFO - 2025-05-22 13:57:48 --> Output Class Initialized
INFO - 2025-05-22 13:57:48 --> Security Class Initialized
DEBUG - 2025-05-22 13:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:57:48 --> Input Class Initialized
INFO - 2025-05-22 13:57:48 --> Language Class Initialized
ERROR - 2025-05-22 13:57:48 --> 404 Page Not Found: Progress/get_events_detail
INFO - 2025-05-22 13:58:05 --> Config Class Initialized
INFO - 2025-05-22 13:58:05 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:58:05 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:58:05 --> Utf8 Class Initialized
INFO - 2025-05-22 13:58:05 --> URI Class Initialized
INFO - 2025-05-22 13:58:05 --> Router Class Initialized
INFO - 2025-05-22 13:58:05 --> Output Class Initialized
INFO - 2025-05-22 13:58:05 --> Security Class Initialized
DEBUG - 2025-05-22 13:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:58:05 --> Input Class Initialized
INFO - 2025-05-22 13:58:05 --> Language Class Initialized
INFO - 2025-05-22 13:58:05 --> Loader Class Initialized
INFO - 2025-05-22 13:58:05 --> Helper loaded: url_helper
INFO - 2025-05-22 13:58:05 --> Helper loaded: form_helper
INFO - 2025-05-22 13:58:05 --> Database Driver Class Initialized
DEBUG - 2025-05-22 13:58:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 13:58:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 13:58:05 --> Controller Class Initialized
INFO - 2025-05-22 13:58:05 --> Model "Progress_model" initialized
INFO - 2025-05-22 13:58:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\progress_view.php
INFO - 2025-05-22 13:58:05 --> Final output sent to browser
DEBUG - 2025-05-22 13:58:05 --> Total execution time: 0.0648
INFO - 2025-05-22 13:58:06 --> Config Class Initialized
INFO - 2025-05-22 13:58:06 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:58:06 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:58:06 --> Utf8 Class Initialized
INFO - 2025-05-22 13:58:06 --> URI Class Initialized
INFO - 2025-05-22 13:58:06 --> Router Class Initialized
INFO - 2025-05-22 13:58:06 --> Output Class Initialized
INFO - 2025-05-22 13:58:06 --> Security Class Initialized
DEBUG - 2025-05-22 13:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:58:06 --> Input Class Initialized
INFO - 2025-05-22 13:58:06 --> Language Class Initialized
INFO - 2025-05-22 13:58:06 --> Loader Class Initialized
INFO - 2025-05-22 13:58:06 --> Helper loaded: url_helper
INFO - 2025-05-22 13:58:06 --> Helper loaded: form_helper
INFO - 2025-05-22 13:58:06 --> Database Driver Class Initialized
DEBUG - 2025-05-22 13:58:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 13:58:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 13:58:06 --> Controller Class Initialized
INFO - 2025-05-22 13:58:06 --> Model "Progress_model" initialized
INFO - 2025-05-22 13:58:06 --> Final output sent to browser
DEBUG - 2025-05-22 13:58:06 --> Total execution time: 0.0788
INFO - 2025-05-22 13:58:07 --> Config Class Initialized
INFO - 2025-05-22 13:58:07 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:58:07 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:58:07 --> Utf8 Class Initialized
INFO - 2025-05-22 13:58:07 --> URI Class Initialized
INFO - 2025-05-22 13:58:07 --> Router Class Initialized
INFO - 2025-05-22 13:58:07 --> Output Class Initialized
INFO - 2025-05-22 13:58:07 --> Security Class Initialized
DEBUG - 2025-05-22 13:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:58:07 --> Input Class Initialized
INFO - 2025-05-22 13:58:07 --> Language Class Initialized
INFO - 2025-05-22 13:58:07 --> Loader Class Initialized
INFO - 2025-05-22 13:58:07 --> Helper loaded: url_helper
INFO - 2025-05-22 13:58:07 --> Helper loaded: form_helper
INFO - 2025-05-22 13:58:07 --> Database Driver Class Initialized
DEBUG - 2025-05-22 13:58:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 13:58:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 13:58:07 --> Controller Class Initialized
INFO - 2025-05-22 13:58:07 --> Model "Progress_model" initialized
INFO - 2025-05-22 13:58:07 --> Final output sent to browser
DEBUG - 2025-05-22 13:58:07 --> Total execution time: 0.0780
INFO - 2025-05-22 13:58:58 --> Config Class Initialized
INFO - 2025-05-22 13:58:58 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:58:58 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:58:58 --> Utf8 Class Initialized
INFO - 2025-05-22 13:58:58 --> URI Class Initialized
INFO - 2025-05-22 13:58:58 --> Router Class Initialized
INFO - 2025-05-22 13:58:58 --> Output Class Initialized
INFO - 2025-05-22 13:58:58 --> Security Class Initialized
DEBUG - 2025-05-22 13:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:58:58 --> Input Class Initialized
INFO - 2025-05-22 13:58:58 --> Language Class Initialized
INFO - 2025-05-22 13:58:58 --> Loader Class Initialized
INFO - 2025-05-22 13:58:58 --> Helper loaded: url_helper
INFO - 2025-05-22 13:58:58 --> Helper loaded: form_helper
INFO - 2025-05-22 13:58:58 --> Database Driver Class Initialized
DEBUG - 2025-05-22 13:58:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 13:58:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 13:58:58 --> Controller Class Initialized
INFO - 2025-05-22 13:58:58 --> Model "Progress_model" initialized
INFO - 2025-05-22 13:58:58 --> Final output sent to browser
DEBUG - 2025-05-22 13:58:58 --> Total execution time: 0.0733
INFO - 2025-05-22 13:59:21 --> Config Class Initialized
INFO - 2025-05-22 13:59:21 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:59:21 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:59:21 --> Utf8 Class Initialized
INFO - 2025-05-22 13:59:21 --> URI Class Initialized
INFO - 2025-05-22 13:59:21 --> Router Class Initialized
INFO - 2025-05-22 13:59:21 --> Output Class Initialized
INFO - 2025-05-22 13:59:21 --> Security Class Initialized
DEBUG - 2025-05-22 13:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:59:21 --> Input Class Initialized
INFO - 2025-05-22 13:59:21 --> Language Class Initialized
INFO - 2025-05-22 13:59:21 --> Loader Class Initialized
INFO - 2025-05-22 13:59:21 --> Helper loaded: url_helper
INFO - 2025-05-22 13:59:21 --> Helper loaded: form_helper
INFO - 2025-05-22 13:59:21 --> Database Driver Class Initialized
DEBUG - 2025-05-22 13:59:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 13:59:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 13:59:21 --> Controller Class Initialized
INFO - 2025-05-22 13:59:21 --> Model "Progress_model" initialized
INFO - 2025-05-22 13:59:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\progress_view.php
INFO - 2025-05-22 13:59:21 --> Final output sent to browser
DEBUG - 2025-05-22 13:59:21 --> Total execution time: 0.0599
INFO - 2025-05-22 13:59:21 --> Config Class Initialized
INFO - 2025-05-22 13:59:21 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:59:21 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:59:21 --> Utf8 Class Initialized
INFO - 2025-05-22 13:59:21 --> URI Class Initialized
INFO - 2025-05-22 13:59:21 --> Router Class Initialized
INFO - 2025-05-22 13:59:21 --> Output Class Initialized
INFO - 2025-05-22 13:59:21 --> Security Class Initialized
DEBUG - 2025-05-22 13:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:59:21 --> Input Class Initialized
INFO - 2025-05-22 13:59:21 --> Language Class Initialized
INFO - 2025-05-22 13:59:21 --> Loader Class Initialized
INFO - 2025-05-22 13:59:21 --> Helper loaded: url_helper
INFO - 2025-05-22 13:59:21 --> Helper loaded: form_helper
INFO - 2025-05-22 13:59:21 --> Database Driver Class Initialized
DEBUG - 2025-05-22 13:59:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 13:59:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 13:59:21 --> Controller Class Initialized
INFO - 2025-05-22 13:59:21 --> Model "Progress_model" initialized
INFO - 2025-05-22 13:59:21 --> Final output sent to browser
DEBUG - 2025-05-22 13:59:21 --> Total execution time: 0.0724
INFO - 2025-05-22 13:59:22 --> Config Class Initialized
INFO - 2025-05-22 13:59:22 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:59:22 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:59:22 --> Utf8 Class Initialized
INFO - 2025-05-22 13:59:22 --> URI Class Initialized
INFO - 2025-05-22 13:59:22 --> Router Class Initialized
INFO - 2025-05-22 13:59:22 --> Output Class Initialized
INFO - 2025-05-22 13:59:22 --> Security Class Initialized
DEBUG - 2025-05-22 13:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:59:22 --> Input Class Initialized
INFO - 2025-05-22 13:59:22 --> Language Class Initialized
INFO - 2025-05-22 13:59:22 --> Loader Class Initialized
INFO - 2025-05-22 13:59:22 --> Helper loaded: url_helper
INFO - 2025-05-22 13:59:22 --> Helper loaded: form_helper
INFO - 2025-05-22 13:59:22 --> Database Driver Class Initialized
DEBUG - 2025-05-22 13:59:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 13:59:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 13:59:22 --> Controller Class Initialized
INFO - 2025-05-22 13:59:22 --> Model "Progress_model" initialized
INFO - 2025-05-22 13:59:22 --> Final output sent to browser
DEBUG - 2025-05-22 13:59:22 --> Total execution time: 0.0841
INFO - 2025-05-22 13:59:33 --> Config Class Initialized
INFO - 2025-05-22 13:59:33 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:59:33 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:59:33 --> Utf8 Class Initialized
INFO - 2025-05-22 13:59:33 --> URI Class Initialized
INFO - 2025-05-22 13:59:33 --> Router Class Initialized
INFO - 2025-05-22 13:59:33 --> Output Class Initialized
INFO - 2025-05-22 13:59:33 --> Security Class Initialized
DEBUG - 2025-05-22 13:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:59:33 --> Input Class Initialized
INFO - 2025-05-22 13:59:33 --> Language Class Initialized
INFO - 2025-05-22 13:59:33 --> Loader Class Initialized
INFO - 2025-05-22 13:59:33 --> Helper loaded: url_helper
INFO - 2025-05-22 13:59:33 --> Helper loaded: form_helper
INFO - 2025-05-22 13:59:33 --> Database Driver Class Initialized
DEBUG - 2025-05-22 13:59:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 13:59:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 13:59:33 --> Controller Class Initialized
INFO - 2025-05-22 13:59:33 --> Model "Progress_model" initialized
INFO - 2025-05-22 13:59:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\progress_view.php
INFO - 2025-05-22 13:59:33 --> Final output sent to browser
DEBUG - 2025-05-22 13:59:33 --> Total execution time: 0.0612
INFO - 2025-05-22 13:59:33 --> Config Class Initialized
INFO - 2025-05-22 13:59:33 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:59:33 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:59:33 --> Utf8 Class Initialized
INFO - 2025-05-22 13:59:33 --> URI Class Initialized
INFO - 2025-05-22 13:59:33 --> Router Class Initialized
INFO - 2025-05-22 13:59:33 --> Output Class Initialized
INFO - 2025-05-22 13:59:33 --> Security Class Initialized
DEBUG - 2025-05-22 13:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:59:33 --> Input Class Initialized
INFO - 2025-05-22 13:59:33 --> Language Class Initialized
INFO - 2025-05-22 13:59:33 --> Loader Class Initialized
INFO - 2025-05-22 13:59:33 --> Helper loaded: url_helper
INFO - 2025-05-22 13:59:33 --> Helper loaded: form_helper
INFO - 2025-05-22 13:59:33 --> Database Driver Class Initialized
DEBUG - 2025-05-22 13:59:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 13:59:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 13:59:33 --> Controller Class Initialized
INFO - 2025-05-22 13:59:33 --> Model "Progress_model" initialized
INFO - 2025-05-22 13:59:33 --> Final output sent to browser
DEBUG - 2025-05-22 13:59:33 --> Total execution time: 0.0652
INFO - 2025-05-22 13:59:34 --> Config Class Initialized
INFO - 2025-05-22 13:59:34 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:59:34 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:59:34 --> Utf8 Class Initialized
INFO - 2025-05-22 13:59:34 --> URI Class Initialized
INFO - 2025-05-22 13:59:34 --> Router Class Initialized
INFO - 2025-05-22 13:59:34 --> Output Class Initialized
INFO - 2025-05-22 13:59:34 --> Security Class Initialized
DEBUG - 2025-05-22 13:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:59:34 --> Input Class Initialized
INFO - 2025-05-22 13:59:34 --> Language Class Initialized
INFO - 2025-05-22 13:59:34 --> Loader Class Initialized
INFO - 2025-05-22 13:59:34 --> Helper loaded: url_helper
INFO - 2025-05-22 13:59:34 --> Helper loaded: form_helper
INFO - 2025-05-22 13:59:34 --> Database Driver Class Initialized
DEBUG - 2025-05-22 13:59:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 13:59:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 13:59:34 --> Controller Class Initialized
INFO - 2025-05-22 13:59:34 --> Model "Progress_model" initialized
INFO - 2025-05-22 13:59:34 --> Final output sent to browser
DEBUG - 2025-05-22 13:59:34 --> Total execution time: 0.0737
INFO - 2025-05-22 13:59:37 --> Config Class Initialized
INFO - 2025-05-22 13:59:37 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:59:37 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:59:37 --> Utf8 Class Initialized
INFO - 2025-05-22 13:59:37 --> URI Class Initialized
INFO - 2025-05-22 13:59:37 --> Router Class Initialized
INFO - 2025-05-22 13:59:37 --> Output Class Initialized
INFO - 2025-05-22 13:59:37 --> Security Class Initialized
DEBUG - 2025-05-22 13:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:59:37 --> Input Class Initialized
INFO - 2025-05-22 13:59:37 --> Language Class Initialized
INFO - 2025-05-22 13:59:37 --> Loader Class Initialized
INFO - 2025-05-22 13:59:37 --> Helper loaded: url_helper
INFO - 2025-05-22 13:59:37 --> Helper loaded: form_helper
INFO - 2025-05-22 13:59:37 --> Database Driver Class Initialized
DEBUG - 2025-05-22 13:59:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 13:59:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 13:59:37 --> Controller Class Initialized
INFO - 2025-05-22 13:59:37 --> Model "Progress_model" initialized
INFO - 2025-05-22 13:59:37 --> Final output sent to browser
DEBUG - 2025-05-22 13:59:37 --> Total execution time: 0.0586
INFO - 2025-05-22 13:59:40 --> Config Class Initialized
INFO - 2025-05-22 13:59:40 --> Hooks Class Initialized
DEBUG - 2025-05-22 13:59:40 --> UTF-8 Support Enabled
INFO - 2025-05-22 13:59:40 --> Utf8 Class Initialized
INFO - 2025-05-22 13:59:40 --> URI Class Initialized
INFO - 2025-05-22 13:59:40 --> Router Class Initialized
INFO - 2025-05-22 13:59:40 --> Output Class Initialized
INFO - 2025-05-22 13:59:40 --> Security Class Initialized
DEBUG - 2025-05-22 13:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 13:59:40 --> Input Class Initialized
INFO - 2025-05-22 13:59:40 --> Language Class Initialized
INFO - 2025-05-22 13:59:40 --> Loader Class Initialized
INFO - 2025-05-22 13:59:40 --> Helper loaded: url_helper
INFO - 2025-05-22 13:59:40 --> Helper loaded: form_helper
INFO - 2025-05-22 13:59:40 --> Database Driver Class Initialized
DEBUG - 2025-05-22 13:59:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 13:59:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 13:59:40 --> Controller Class Initialized
INFO - 2025-05-22 13:59:40 --> Model "Progress_model" initialized
INFO - 2025-05-22 13:59:40 --> Final output sent to browser
DEBUG - 2025-05-22 13:59:40 --> Total execution time: 0.0656
INFO - 2025-05-22 14:01:57 --> Config Class Initialized
INFO - 2025-05-22 14:01:57 --> Hooks Class Initialized
DEBUG - 2025-05-22 14:01:57 --> UTF-8 Support Enabled
INFO - 2025-05-22 14:01:57 --> Utf8 Class Initialized
INFO - 2025-05-22 14:01:57 --> URI Class Initialized
INFO - 2025-05-22 14:01:57 --> Router Class Initialized
INFO - 2025-05-22 14:01:57 --> Output Class Initialized
INFO - 2025-05-22 14:01:57 --> Security Class Initialized
DEBUG - 2025-05-22 14:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 14:01:57 --> Input Class Initialized
INFO - 2025-05-22 14:01:57 --> Language Class Initialized
INFO - 2025-05-22 14:01:57 --> Loader Class Initialized
INFO - 2025-05-22 14:01:57 --> Helper loaded: url_helper
INFO - 2025-05-22 14:01:57 --> Helper loaded: form_helper
INFO - 2025-05-22 14:01:57 --> Database Driver Class Initialized
DEBUG - 2025-05-22 14:01:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 14:01:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 14:01:57 --> Controller Class Initialized
INFO - 2025-05-22 14:01:57 --> Model "Progress_model" initialized
INFO - 2025-05-22 14:01:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\progress_view.php
INFO - 2025-05-22 14:01:57 --> Final output sent to browser
DEBUG - 2025-05-22 14:01:57 --> Total execution time: 0.0599
INFO - 2025-05-22 14:01:58 --> Config Class Initialized
INFO - 2025-05-22 14:01:58 --> Hooks Class Initialized
DEBUG - 2025-05-22 14:01:58 --> UTF-8 Support Enabled
INFO - 2025-05-22 14:01:58 --> Utf8 Class Initialized
INFO - 2025-05-22 14:01:58 --> URI Class Initialized
INFO - 2025-05-22 14:01:58 --> Router Class Initialized
INFO - 2025-05-22 14:01:58 --> Output Class Initialized
INFO - 2025-05-22 14:01:58 --> Security Class Initialized
DEBUG - 2025-05-22 14:01:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 14:01:58 --> Input Class Initialized
INFO - 2025-05-22 14:01:58 --> Language Class Initialized
INFO - 2025-05-22 14:01:58 --> Loader Class Initialized
INFO - 2025-05-22 14:01:58 --> Helper loaded: url_helper
INFO - 2025-05-22 14:01:58 --> Helper loaded: form_helper
INFO - 2025-05-22 14:01:58 --> Database Driver Class Initialized
DEBUG - 2025-05-22 14:01:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 14:01:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 14:01:58 --> Controller Class Initialized
INFO - 2025-05-22 14:01:58 --> Model "Progress_model" initialized
INFO - 2025-05-22 14:01:58 --> Final output sent to browser
DEBUG - 2025-05-22 14:01:58 --> Total execution time: 0.0782
INFO - 2025-05-22 14:01:59 --> Config Class Initialized
INFO - 2025-05-22 14:01:59 --> Hooks Class Initialized
DEBUG - 2025-05-22 14:01:59 --> UTF-8 Support Enabled
INFO - 2025-05-22 14:01:59 --> Utf8 Class Initialized
INFO - 2025-05-22 14:01:59 --> URI Class Initialized
INFO - 2025-05-22 14:01:59 --> Router Class Initialized
INFO - 2025-05-22 14:01:59 --> Output Class Initialized
INFO - 2025-05-22 14:01:59 --> Security Class Initialized
DEBUG - 2025-05-22 14:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 14:01:59 --> Input Class Initialized
INFO - 2025-05-22 14:01:59 --> Language Class Initialized
INFO - 2025-05-22 14:01:59 --> Loader Class Initialized
INFO - 2025-05-22 14:01:59 --> Helper loaded: url_helper
INFO - 2025-05-22 14:01:59 --> Helper loaded: form_helper
INFO - 2025-05-22 14:01:59 --> Database Driver Class Initialized
DEBUG - 2025-05-22 14:01:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 14:01:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 14:01:59 --> Controller Class Initialized
INFO - 2025-05-22 14:01:59 --> Model "Progress_model" initialized
INFO - 2025-05-22 14:01:59 --> Final output sent to browser
DEBUG - 2025-05-22 14:01:59 --> Total execution time: 0.0788
INFO - 2025-05-22 14:02:04 --> Config Class Initialized
INFO - 2025-05-22 14:02:04 --> Hooks Class Initialized
DEBUG - 2025-05-22 14:02:04 --> UTF-8 Support Enabled
INFO - 2025-05-22 14:02:04 --> Utf8 Class Initialized
INFO - 2025-05-22 14:02:04 --> URI Class Initialized
INFO - 2025-05-22 14:02:04 --> Router Class Initialized
INFO - 2025-05-22 14:02:04 --> Output Class Initialized
INFO - 2025-05-22 14:02:04 --> Security Class Initialized
DEBUG - 2025-05-22 14:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 14:02:04 --> Input Class Initialized
INFO - 2025-05-22 14:02:04 --> Language Class Initialized
INFO - 2025-05-22 14:02:04 --> Loader Class Initialized
INFO - 2025-05-22 14:02:04 --> Helper loaded: url_helper
INFO - 2025-05-22 14:02:04 --> Helper loaded: form_helper
INFO - 2025-05-22 14:02:04 --> Database Driver Class Initialized
DEBUG - 2025-05-22 14:02:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 14:02:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 14:02:04 --> Controller Class Initialized
INFO - 2025-05-22 14:02:04 --> Model "Timer_model" initialized
INFO - 2025-05-22 14:02:04 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\timer_view.php
INFO - 2025-05-22 14:02:04 --> Final output sent to browser
DEBUG - 2025-05-22 14:02:04 --> Total execution time: 0.0805
INFO - 2025-05-22 14:06:13 --> Config Class Initialized
INFO - 2025-05-22 14:06:13 --> Hooks Class Initialized
DEBUG - 2025-05-22 14:06:13 --> UTF-8 Support Enabled
INFO - 2025-05-22 14:06:13 --> Utf8 Class Initialized
INFO - 2025-05-22 14:06:13 --> URI Class Initialized
INFO - 2025-05-22 14:06:13 --> Router Class Initialized
INFO - 2025-05-22 14:06:13 --> Output Class Initialized
INFO - 2025-05-22 14:06:13 --> Security Class Initialized
DEBUG - 2025-05-22 14:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 14:06:13 --> Input Class Initialized
INFO - 2025-05-22 14:06:13 --> Language Class Initialized
INFO - 2025-05-22 14:06:13 --> Loader Class Initialized
INFO - 2025-05-22 14:06:13 --> Helper loaded: url_helper
INFO - 2025-05-22 14:06:13 --> Helper loaded: form_helper
INFO - 2025-05-22 14:06:13 --> Database Driver Class Initialized
DEBUG - 2025-05-22 14:06:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 14:06:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 14:06:13 --> Controller Class Initialized
INFO - 2025-05-22 14:06:13 --> Model "Timer_model" initialized
INFO - 2025-05-22 14:06:13 --> Final output sent to browser
DEBUG - 2025-05-22 14:06:13 --> Total execution time: 0.0713
INFO - 2025-05-22 14:06:15 --> Config Class Initialized
INFO - 2025-05-22 14:06:15 --> Hooks Class Initialized
DEBUG - 2025-05-22 14:06:15 --> UTF-8 Support Enabled
INFO - 2025-05-22 14:06:15 --> Utf8 Class Initialized
INFO - 2025-05-22 14:06:15 --> URI Class Initialized
INFO - 2025-05-22 14:06:15 --> Router Class Initialized
INFO - 2025-05-22 14:06:15 --> Output Class Initialized
INFO - 2025-05-22 14:06:15 --> Security Class Initialized
DEBUG - 2025-05-22 14:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 14:06:15 --> Input Class Initialized
INFO - 2025-05-22 14:06:15 --> Language Class Initialized
INFO - 2025-05-22 14:06:15 --> Loader Class Initialized
INFO - 2025-05-22 14:06:15 --> Helper loaded: url_helper
INFO - 2025-05-22 14:06:15 --> Helper loaded: form_helper
INFO - 2025-05-22 14:06:15 --> Database Driver Class Initialized
DEBUG - 2025-05-22 14:06:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 14:06:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 14:06:15 --> Controller Class Initialized
INFO - 2025-05-22 14:06:15 --> Model "Timer_model" initialized
INFO - 2025-05-22 14:06:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\timer_view.php
INFO - 2025-05-22 14:06:15 --> Final output sent to browser
DEBUG - 2025-05-22 14:06:15 --> Total execution time: 0.0792
INFO - 2025-05-22 14:06:21 --> Config Class Initialized
INFO - 2025-05-22 14:06:21 --> Hooks Class Initialized
DEBUG - 2025-05-22 14:06:21 --> UTF-8 Support Enabled
INFO - 2025-05-22 14:06:21 --> Utf8 Class Initialized
INFO - 2025-05-22 14:06:21 --> URI Class Initialized
INFO - 2025-05-22 14:06:21 --> Router Class Initialized
INFO - 2025-05-22 14:06:21 --> Output Class Initialized
INFO - 2025-05-22 14:06:21 --> Security Class Initialized
DEBUG - 2025-05-22 14:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 14:06:21 --> Input Class Initialized
INFO - 2025-05-22 14:06:21 --> Language Class Initialized
INFO - 2025-05-22 14:06:21 --> Loader Class Initialized
INFO - 2025-05-22 14:06:21 --> Helper loaded: url_helper
INFO - 2025-05-22 14:06:21 --> Helper loaded: form_helper
INFO - 2025-05-22 14:06:21 --> Database Driver Class Initialized
DEBUG - 2025-05-22 14:06:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 14:06:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 14:06:21 --> Controller Class Initialized
INFO - 2025-05-22 14:06:21 --> Model "Progress_model" initialized
INFO - 2025-05-22 14:06:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\progress_view.php
INFO - 2025-05-22 14:06:21 --> Final output sent to browser
DEBUG - 2025-05-22 14:06:21 --> Total execution time: 0.0785
INFO - 2025-05-22 14:06:21 --> Config Class Initialized
INFO - 2025-05-22 14:06:21 --> Hooks Class Initialized
DEBUG - 2025-05-22 14:06:21 --> UTF-8 Support Enabled
INFO - 2025-05-22 14:06:21 --> Utf8 Class Initialized
INFO - 2025-05-22 14:06:21 --> URI Class Initialized
INFO - 2025-05-22 14:06:21 --> Router Class Initialized
INFO - 2025-05-22 14:06:21 --> Output Class Initialized
INFO - 2025-05-22 14:06:21 --> Security Class Initialized
DEBUG - 2025-05-22 14:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 14:06:21 --> Input Class Initialized
INFO - 2025-05-22 14:06:21 --> Language Class Initialized
INFO - 2025-05-22 14:06:21 --> Loader Class Initialized
INFO - 2025-05-22 14:06:21 --> Helper loaded: url_helper
INFO - 2025-05-22 14:06:21 --> Helper loaded: form_helper
INFO - 2025-05-22 14:06:21 --> Database Driver Class Initialized
DEBUG - 2025-05-22 14:06:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 14:06:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 14:06:21 --> Controller Class Initialized
INFO - 2025-05-22 14:06:21 --> Model "Progress_model" initialized
INFO - 2025-05-22 14:06:21 --> Final output sent to browser
DEBUG - 2025-05-22 14:06:21 --> Total execution time: 0.0872
INFO - 2025-05-22 14:06:25 --> Config Class Initialized
INFO - 2025-05-22 14:06:25 --> Hooks Class Initialized
DEBUG - 2025-05-22 14:06:25 --> UTF-8 Support Enabled
INFO - 2025-05-22 14:06:25 --> Utf8 Class Initialized
INFO - 2025-05-22 14:06:25 --> URI Class Initialized
INFO - 2025-05-22 14:06:25 --> Router Class Initialized
INFO - 2025-05-22 14:06:25 --> Output Class Initialized
INFO - 2025-05-22 14:06:25 --> Security Class Initialized
DEBUG - 2025-05-22 14:06:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 14:06:25 --> Input Class Initialized
INFO - 2025-05-22 14:06:25 --> Language Class Initialized
INFO - 2025-05-22 14:06:25 --> Loader Class Initialized
INFO - 2025-05-22 14:06:25 --> Helper loaded: url_helper
INFO - 2025-05-22 14:06:25 --> Helper loaded: form_helper
INFO - 2025-05-22 14:06:25 --> Database Driver Class Initialized
DEBUG - 2025-05-22 14:06:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 14:06:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 14:06:25 --> Controller Class Initialized
INFO - 2025-05-22 14:06:25 --> Model "Progress_model" initialized
INFO - 2025-05-22 14:06:25 --> Final output sent to browser
DEBUG - 2025-05-22 14:06:25 --> Total execution time: 0.0804
INFO - 2025-05-22 14:25:16 --> Config Class Initialized
INFO - 2025-05-22 14:25:16 --> Hooks Class Initialized
DEBUG - 2025-05-22 14:25:16 --> UTF-8 Support Enabled
INFO - 2025-05-22 14:25:16 --> Utf8 Class Initialized
INFO - 2025-05-22 14:25:16 --> URI Class Initialized
INFO - 2025-05-22 14:25:16 --> Router Class Initialized
INFO - 2025-05-22 14:25:16 --> Output Class Initialized
INFO - 2025-05-22 14:25:16 --> Security Class Initialized
DEBUG - 2025-05-22 14:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 14:25:16 --> Input Class Initialized
INFO - 2025-05-22 14:25:16 --> Language Class Initialized
INFO - 2025-05-22 14:25:16 --> Loader Class Initialized
INFO - 2025-05-22 14:25:16 --> Helper loaded: url_helper
INFO - 2025-05-22 14:25:16 --> Helper loaded: form_helper
INFO - 2025-05-22 14:25:16 --> Database Driver Class Initialized
DEBUG - 2025-05-22 14:25:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 14:25:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 14:25:16 --> Controller Class Initialized
INFO - 2025-05-22 14:25:16 --> Model "Progress_model" initialized
INFO - 2025-05-22 14:25:16 --> Final output sent to browser
DEBUG - 2025-05-22 14:25:16 --> Total execution time: 0.0922
INFO - 2025-05-22 14:25:17 --> Config Class Initialized
INFO - 2025-05-22 14:25:17 --> Hooks Class Initialized
DEBUG - 2025-05-22 14:25:17 --> UTF-8 Support Enabled
INFO - 2025-05-22 14:25:17 --> Utf8 Class Initialized
INFO - 2025-05-22 14:25:17 --> URI Class Initialized
INFO - 2025-05-22 14:25:17 --> Router Class Initialized
INFO - 2025-05-22 14:25:17 --> Output Class Initialized
INFO - 2025-05-22 14:25:17 --> Security Class Initialized
DEBUG - 2025-05-22 14:25:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 14:25:17 --> Input Class Initialized
INFO - 2025-05-22 14:25:17 --> Language Class Initialized
INFO - 2025-05-22 14:25:17 --> Loader Class Initialized
INFO - 2025-05-22 14:25:17 --> Helper loaded: url_helper
INFO - 2025-05-22 14:25:17 --> Helper loaded: form_helper
INFO - 2025-05-22 14:25:17 --> Database Driver Class Initialized
DEBUG - 2025-05-22 14:25:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 14:25:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 14:25:17 --> Controller Class Initialized
INFO - 2025-05-22 14:25:17 --> Model "Progress_model" initialized
INFO - 2025-05-22 14:25:17 --> Final output sent to browser
DEBUG - 2025-05-22 14:25:17 --> Total execution time: 0.0765
INFO - 2025-05-22 14:25:52 --> Config Class Initialized
INFO - 2025-05-22 14:25:52 --> Hooks Class Initialized
DEBUG - 2025-05-22 14:25:52 --> UTF-8 Support Enabled
INFO - 2025-05-22 14:25:52 --> Utf8 Class Initialized
INFO - 2025-05-22 14:25:52 --> URI Class Initialized
INFO - 2025-05-22 14:25:52 --> Router Class Initialized
INFO - 2025-05-22 14:25:52 --> Output Class Initialized
INFO - 2025-05-22 14:25:52 --> Security Class Initialized
DEBUG - 2025-05-22 14:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 14:25:52 --> Input Class Initialized
INFO - 2025-05-22 14:25:52 --> Language Class Initialized
INFO - 2025-05-22 14:25:52 --> Loader Class Initialized
INFO - 2025-05-22 14:25:52 --> Helper loaded: url_helper
INFO - 2025-05-22 14:25:52 --> Helper loaded: form_helper
INFO - 2025-05-22 14:25:52 --> Database Driver Class Initialized
DEBUG - 2025-05-22 14:25:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 14:25:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 14:25:52 --> Controller Class Initialized
INFO - 2025-05-22 14:25:52 --> Model "Workout_model" initialized
INFO - 2025-05-22 14:25:52 --> Model "User_model" initialized
INFO - 2025-05-22 14:25:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-22 14:25:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-22 14:25:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-22 14:25:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-22 14:25:52 --> Final output sent to browser
DEBUG - 2025-05-22 14:25:52 --> Total execution time: 0.0964
INFO - 2025-05-22 14:26:00 --> Config Class Initialized
INFO - 2025-05-22 14:26:00 --> Hooks Class Initialized
DEBUG - 2025-05-22 14:26:00 --> UTF-8 Support Enabled
INFO - 2025-05-22 14:26:00 --> Utf8 Class Initialized
INFO - 2025-05-22 14:26:00 --> URI Class Initialized
INFO - 2025-05-22 14:26:00 --> Router Class Initialized
INFO - 2025-05-22 14:26:00 --> Output Class Initialized
INFO - 2025-05-22 14:26:00 --> Security Class Initialized
DEBUG - 2025-05-22 14:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 14:26:00 --> Input Class Initialized
INFO - 2025-05-22 14:26:00 --> Language Class Initialized
INFO - 2025-05-22 14:26:00 --> Loader Class Initialized
INFO - 2025-05-22 14:26:00 --> Helper loaded: url_helper
INFO - 2025-05-22 14:26:00 --> Helper loaded: form_helper
INFO - 2025-05-22 14:26:00 --> Database Driver Class Initialized
DEBUG - 2025-05-22 14:26:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 14:26:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 14:26:00 --> Controller Class Initialized
INFO - 2025-05-22 14:26:00 --> Model "Workout_model" initialized
INFO - 2025-05-22 14:26:00 --> Model "User_model" initialized
INFO - 2025-05-22 14:26:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-22 14:26:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-22 14:26:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/add_jadwal.php
INFO - 2025-05-22 14:26:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-22 14:26:00 --> Final output sent to browser
DEBUG - 2025-05-22 14:26:00 --> Total execution time: 0.1014
INFO - 2025-05-22 14:30:11 --> Config Class Initialized
INFO - 2025-05-22 14:30:11 --> Hooks Class Initialized
DEBUG - 2025-05-22 14:30:11 --> UTF-8 Support Enabled
INFO - 2025-05-22 14:30:11 --> Utf8 Class Initialized
INFO - 2025-05-22 14:30:11 --> URI Class Initialized
INFO - 2025-05-22 14:30:11 --> Router Class Initialized
INFO - 2025-05-22 14:30:11 --> Output Class Initialized
INFO - 2025-05-22 14:30:11 --> Security Class Initialized
DEBUG - 2025-05-22 14:30:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 14:30:11 --> Input Class Initialized
INFO - 2025-05-22 14:30:11 --> Language Class Initialized
INFO - 2025-05-22 14:30:11 --> Loader Class Initialized
INFO - 2025-05-22 14:30:11 --> Helper loaded: url_helper
INFO - 2025-05-22 14:30:11 --> Helper loaded: form_helper
INFO - 2025-05-22 14:30:11 --> Database Driver Class Initialized
DEBUG - 2025-05-22 14:30:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 14:30:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 14:30:11 --> Controller Class Initialized
INFO - 2025-05-22 14:30:11 --> Model "Workout_model" initialized
INFO - 2025-05-22 14:30:11 --> Model "User_model" initialized
INFO - 2025-05-22 14:30:11 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-22 14:30:11 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-22 14:30:11 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/add_jadwal.php
INFO - 2025-05-22 14:30:11 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-22 14:30:11 --> Final output sent to browser
DEBUG - 2025-05-22 14:30:11 --> Total execution time: 0.0792
INFO - 2025-05-22 14:30:22 --> Config Class Initialized
INFO - 2025-05-22 14:30:22 --> Hooks Class Initialized
DEBUG - 2025-05-22 14:30:22 --> UTF-8 Support Enabled
INFO - 2025-05-22 14:30:22 --> Utf8 Class Initialized
INFO - 2025-05-22 14:30:22 --> URI Class Initialized
INFO - 2025-05-22 14:30:22 --> Router Class Initialized
INFO - 2025-05-22 14:30:22 --> Output Class Initialized
INFO - 2025-05-22 14:30:22 --> Security Class Initialized
DEBUG - 2025-05-22 14:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 14:30:22 --> Input Class Initialized
INFO - 2025-05-22 14:30:22 --> Language Class Initialized
INFO - 2025-05-22 14:30:22 --> Loader Class Initialized
INFO - 2025-05-22 14:30:22 --> Helper loaded: url_helper
INFO - 2025-05-22 14:30:22 --> Helper loaded: form_helper
INFO - 2025-05-22 14:30:22 --> Database Driver Class Initialized
DEBUG - 2025-05-22 14:30:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 14:30:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 14:30:22 --> Controller Class Initialized
INFO - 2025-05-22 14:30:22 --> Model "Workout_model" initialized
INFO - 2025-05-22 14:30:22 --> Model "User_model" initialized
INFO - 2025-05-22 14:30:22 --> Config Class Initialized
INFO - 2025-05-22 14:30:22 --> Hooks Class Initialized
DEBUG - 2025-05-22 14:30:22 --> UTF-8 Support Enabled
INFO - 2025-05-22 14:30:22 --> Utf8 Class Initialized
INFO - 2025-05-22 14:30:22 --> URI Class Initialized
INFO - 2025-05-22 14:30:22 --> Router Class Initialized
INFO - 2025-05-22 14:30:22 --> Output Class Initialized
INFO - 2025-05-22 14:30:22 --> Security Class Initialized
DEBUG - 2025-05-22 14:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 14:30:22 --> Input Class Initialized
INFO - 2025-05-22 14:30:22 --> Language Class Initialized
INFO - 2025-05-22 14:30:22 --> Loader Class Initialized
INFO - 2025-05-22 14:30:22 --> Helper loaded: url_helper
INFO - 2025-05-22 14:30:22 --> Helper loaded: form_helper
INFO - 2025-05-22 14:30:22 --> Database Driver Class Initialized
DEBUG - 2025-05-22 14:30:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 14:30:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 14:30:22 --> Controller Class Initialized
INFO - 2025-05-22 14:30:22 --> Model "Workout_model" initialized
INFO - 2025-05-22 14:30:22 --> Model "User_model" initialized
INFO - 2025-05-22 14:30:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-22 14:30:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-22 14:30:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-22 14:30:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-22 14:30:22 --> Final output sent to browser
DEBUG - 2025-05-22 14:30:22 --> Total execution time: 0.0827
INFO - 2025-05-22 14:30:26 --> Config Class Initialized
INFO - 2025-05-22 14:30:26 --> Hooks Class Initialized
DEBUG - 2025-05-22 14:30:26 --> UTF-8 Support Enabled
INFO - 2025-05-22 14:30:26 --> Utf8 Class Initialized
INFO - 2025-05-22 14:30:26 --> URI Class Initialized
INFO - 2025-05-22 14:30:26 --> Router Class Initialized
INFO - 2025-05-22 14:30:26 --> Output Class Initialized
INFO - 2025-05-22 14:30:26 --> Security Class Initialized
DEBUG - 2025-05-22 14:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 14:30:26 --> Input Class Initialized
INFO - 2025-05-22 14:30:26 --> Language Class Initialized
INFO - 2025-05-22 14:30:26 --> Loader Class Initialized
INFO - 2025-05-22 14:30:26 --> Helper loaded: url_helper
INFO - 2025-05-22 14:30:26 --> Helper loaded: form_helper
INFO - 2025-05-22 14:30:26 --> Database Driver Class Initialized
DEBUG - 2025-05-22 14:30:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 14:30:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 14:30:26 --> Controller Class Initialized
INFO - 2025-05-22 14:30:26 --> Model "Workout_model" initialized
INFO - 2025-05-22 14:30:26 --> Model "User_model" initialized
INFO - 2025-05-22 14:30:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/start.php
INFO - 2025-05-22 14:30:26 --> Final output sent to browser
DEBUG - 2025-05-22 14:30:26 --> Total execution time: 0.1279
INFO - 2025-05-22 14:30:40 --> Config Class Initialized
INFO - 2025-05-22 14:30:40 --> Hooks Class Initialized
DEBUG - 2025-05-22 14:30:40 --> UTF-8 Support Enabled
INFO - 2025-05-22 14:30:40 --> Utf8 Class Initialized
INFO - 2025-05-22 14:30:40 --> URI Class Initialized
INFO - 2025-05-22 14:30:40 --> Router Class Initialized
INFO - 2025-05-22 14:30:40 --> Output Class Initialized
INFO - 2025-05-22 14:30:40 --> Security Class Initialized
DEBUG - 2025-05-22 14:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 14:30:40 --> Input Class Initialized
INFO - 2025-05-22 14:30:40 --> Language Class Initialized
INFO - 2025-05-22 14:30:40 --> Loader Class Initialized
INFO - 2025-05-22 14:30:40 --> Helper loaded: url_helper
INFO - 2025-05-22 14:30:40 --> Helper loaded: form_helper
INFO - 2025-05-22 14:30:40 --> Database Driver Class Initialized
DEBUG - 2025-05-22 14:30:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 14:30:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 14:30:40 --> Controller Class Initialized
INFO - 2025-05-22 14:30:40 --> Model "Workout_model" initialized
INFO - 2025-05-22 14:30:40 --> Model "User_model" initialized
INFO - 2025-05-22 14:30:40 --> Final output sent to browser
DEBUG - 2025-05-22 14:30:40 --> Total execution time: 0.0796
INFO - 2025-05-22 14:30:40 --> Config Class Initialized
INFO - 2025-05-22 14:30:40 --> Hooks Class Initialized
DEBUG - 2025-05-22 14:30:40 --> UTF-8 Support Enabled
INFO - 2025-05-22 14:30:40 --> Utf8 Class Initialized
INFO - 2025-05-22 14:30:40 --> URI Class Initialized
INFO - 2025-05-22 14:30:40 --> Router Class Initialized
INFO - 2025-05-22 14:30:40 --> Output Class Initialized
INFO - 2025-05-22 14:30:40 --> Security Class Initialized
DEBUG - 2025-05-22 14:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 14:30:40 --> Input Class Initialized
INFO - 2025-05-22 14:30:40 --> Language Class Initialized
INFO - 2025-05-22 14:30:40 --> Loader Class Initialized
INFO - 2025-05-22 14:30:40 --> Helper loaded: url_helper
INFO - 2025-05-22 14:30:40 --> Helper loaded: form_helper
INFO - 2025-05-22 14:30:40 --> Database Driver Class Initialized
DEBUG - 2025-05-22 14:30:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 14:30:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 14:30:40 --> Controller Class Initialized
INFO - 2025-05-22 14:30:40 --> Model "Workout_model" initialized
INFO - 2025-05-22 14:30:40 --> Model "User_model" initialized
INFO - 2025-05-22 14:30:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-22 14:30:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-22 14:30:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-22 14:30:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-22 14:30:40 --> Final output sent to browser
DEBUG - 2025-05-22 14:30:40 --> Total execution time: 0.0723
INFO - 2025-05-22 14:30:53 --> Config Class Initialized
INFO - 2025-05-22 14:30:53 --> Hooks Class Initialized
DEBUG - 2025-05-22 14:30:53 --> UTF-8 Support Enabled
INFO - 2025-05-22 14:30:53 --> Utf8 Class Initialized
INFO - 2025-05-22 14:30:53 --> URI Class Initialized
INFO - 2025-05-22 14:30:53 --> Router Class Initialized
INFO - 2025-05-22 14:30:53 --> Output Class Initialized
INFO - 2025-05-22 14:30:53 --> Security Class Initialized
DEBUG - 2025-05-22 14:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 14:30:53 --> Input Class Initialized
INFO - 2025-05-22 14:30:53 --> Language Class Initialized
INFO - 2025-05-22 14:30:53 --> Loader Class Initialized
INFO - 2025-05-22 14:30:53 --> Helper loaded: url_helper
INFO - 2025-05-22 14:30:53 --> Helper loaded: form_helper
INFO - 2025-05-22 14:30:53 --> Database Driver Class Initialized
DEBUG - 2025-05-22 14:30:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 14:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 14:30:54 --> Controller Class Initialized
INFO - 2025-05-22 14:30:54 --> Model "Workout_model" initialized
INFO - 2025-05-22 14:30:54 --> Model "User_model" initialized
INFO - 2025-05-22 14:30:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-22 14:30:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-22 14:30:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga.php
INFO - 2025-05-22 14:30:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-22 14:30:54 --> Final output sent to browser
DEBUG - 2025-05-22 14:30:54 --> Total execution time: 0.0822
INFO - 2025-05-22 14:30:59 --> Config Class Initialized
INFO - 2025-05-22 14:30:59 --> Hooks Class Initialized
DEBUG - 2025-05-22 14:30:59 --> UTF-8 Support Enabled
INFO - 2025-05-22 14:30:59 --> Utf8 Class Initialized
INFO - 2025-05-22 14:30:59 --> URI Class Initialized
INFO - 2025-05-22 14:30:59 --> Router Class Initialized
INFO - 2025-05-22 14:30:59 --> Output Class Initialized
INFO - 2025-05-22 14:30:59 --> Security Class Initialized
DEBUG - 2025-05-22 14:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 14:30:59 --> Input Class Initialized
INFO - 2025-05-22 14:30:59 --> Language Class Initialized
INFO - 2025-05-22 14:30:59 --> Loader Class Initialized
INFO - 2025-05-22 14:30:59 --> Helper loaded: url_helper
INFO - 2025-05-22 14:30:59 --> Helper loaded: form_helper
INFO - 2025-05-22 14:30:59 --> Database Driver Class Initialized
DEBUG - 2025-05-22 14:30:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 14:30:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 14:30:59 --> Controller Class Initialized
INFO - 2025-05-22 14:30:59 --> Model "Workout_model" initialized
INFO - 2025-05-22 14:30:59 --> Model "User_model" initialized
INFO - 2025-05-22 14:30:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-22 14:30:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-22 14:30:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-22 14:30:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-22 14:30:59 --> Final output sent to browser
DEBUG - 2025-05-22 14:30:59 --> Total execution time: 0.0776
INFO - 2025-05-22 14:58:18 --> Config Class Initialized
INFO - 2025-05-22 14:58:18 --> Hooks Class Initialized
DEBUG - 2025-05-22 14:58:18 --> UTF-8 Support Enabled
INFO - 2025-05-22 14:58:18 --> Utf8 Class Initialized
INFO - 2025-05-22 14:58:18 --> URI Class Initialized
INFO - 2025-05-22 14:58:18 --> Router Class Initialized
INFO - 2025-05-22 14:58:18 --> Output Class Initialized
INFO - 2025-05-22 14:58:18 --> Security Class Initialized
DEBUG - 2025-05-22 14:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 14:58:18 --> Input Class Initialized
INFO - 2025-05-22 14:58:18 --> Language Class Initialized
INFO - 2025-05-22 14:58:18 --> Loader Class Initialized
INFO - 2025-05-22 14:58:18 --> Helper loaded: url_helper
INFO - 2025-05-22 14:58:18 --> Helper loaded: form_helper
INFO - 2025-05-22 14:58:18 --> Database Driver Class Initialized
DEBUG - 2025-05-22 14:58:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 14:58:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 14:58:18 --> Controller Class Initialized
INFO - 2025-05-22 14:58:18 --> Model "Progress_model" initialized
ERROR - 2025-05-22 14:58:18 --> Severity: Warning --> Undefined variable $data C:\laragon\www\Project\fitnessrecord\application\views\progress_view.php 23
ERROR - 2025-05-22 14:58:18 --> Severity: Warning --> Attempt to read property "level" on null C:\laragon\www\Project\fitnessrecord\application\views\progress_view.php 23
ERROR - 2025-05-22 14:58:18 --> Severity: 8192 --> ucfirst(): Passing null to parameter #1 ($string) of type string is deprecated C:\laragon\www\Project\fitnessrecord\application\views\progress_view.php 23
INFO - 2025-05-22 14:58:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\progress_view.php
INFO - 2025-05-22 14:58:18 --> Final output sent to browser
DEBUG - 2025-05-22 14:58:18 --> Total execution time: 0.1435
INFO - 2025-05-22 14:58:18 --> Config Class Initialized
INFO - 2025-05-22 14:58:18 --> Hooks Class Initialized
DEBUG - 2025-05-22 14:58:18 --> UTF-8 Support Enabled
INFO - 2025-05-22 14:58:18 --> Utf8 Class Initialized
INFO - 2025-05-22 14:58:18 --> URI Class Initialized
INFO - 2025-05-22 14:58:18 --> Router Class Initialized
INFO - 2025-05-22 14:58:18 --> Output Class Initialized
INFO - 2025-05-22 14:58:18 --> Security Class Initialized
DEBUG - 2025-05-22 14:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 14:58:18 --> Input Class Initialized
INFO - 2025-05-22 14:58:18 --> Language Class Initialized
INFO - 2025-05-22 14:58:18 --> Loader Class Initialized
INFO - 2025-05-22 14:58:18 --> Helper loaded: url_helper
INFO - 2025-05-22 14:58:18 --> Helper loaded: form_helper
INFO - 2025-05-22 14:58:18 --> Database Driver Class Initialized
DEBUG - 2025-05-22 14:58:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 14:58:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 14:58:18 --> Controller Class Initialized
INFO - 2025-05-22 14:58:18 --> Model "Progress_model" initialized
INFO - 2025-05-22 14:58:18 --> Final output sent to browser
DEBUG - 2025-05-22 14:58:18 --> Total execution time: 0.1037
INFO - 2025-05-22 14:58:19 --> Config Class Initialized
INFO - 2025-05-22 14:58:19 --> Hooks Class Initialized
DEBUG - 2025-05-22 14:58:19 --> UTF-8 Support Enabled
INFO - 2025-05-22 14:58:19 --> Utf8 Class Initialized
INFO - 2025-05-22 14:58:19 --> URI Class Initialized
INFO - 2025-05-22 14:58:19 --> Router Class Initialized
INFO - 2025-05-22 14:58:19 --> Output Class Initialized
INFO - 2025-05-22 14:58:19 --> Security Class Initialized
DEBUG - 2025-05-22 14:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 14:58:19 --> Input Class Initialized
INFO - 2025-05-22 14:58:19 --> Language Class Initialized
INFO - 2025-05-22 14:58:19 --> Loader Class Initialized
INFO - 2025-05-22 14:58:19 --> Helper loaded: url_helper
INFO - 2025-05-22 14:58:19 --> Helper loaded: form_helper
INFO - 2025-05-22 14:58:19 --> Database Driver Class Initialized
DEBUG - 2025-05-22 14:58:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 14:58:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 14:58:19 --> Controller Class Initialized
INFO - 2025-05-22 14:58:19 --> Model "Progress_model" initialized
INFO - 2025-05-22 14:58:19 --> Final output sent to browser
DEBUG - 2025-05-22 14:58:19 --> Total execution time: 0.0694
INFO - 2025-05-22 14:58:23 --> Config Class Initialized
INFO - 2025-05-22 14:58:23 --> Hooks Class Initialized
DEBUG - 2025-05-22 14:58:23 --> UTF-8 Support Enabled
INFO - 2025-05-22 14:58:23 --> Utf8 Class Initialized
INFO - 2025-05-22 14:58:23 --> URI Class Initialized
INFO - 2025-05-22 14:58:23 --> Router Class Initialized
INFO - 2025-05-22 14:58:23 --> Output Class Initialized
INFO - 2025-05-22 14:58:23 --> Security Class Initialized
DEBUG - 2025-05-22 14:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 14:58:23 --> Input Class Initialized
INFO - 2025-05-22 14:58:23 --> Language Class Initialized
INFO - 2025-05-22 14:58:23 --> Loader Class Initialized
INFO - 2025-05-22 14:58:23 --> Helper loaded: url_helper
INFO - 2025-05-22 14:58:23 --> Helper loaded: form_helper
INFO - 2025-05-22 14:58:23 --> Database Driver Class Initialized
DEBUG - 2025-05-22 14:58:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 14:58:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 14:58:23 --> Controller Class Initialized
INFO - 2025-05-22 14:58:23 --> Model "Progress_model" initialized
ERROR - 2025-05-22 14:58:23 --> Severity: Warning --> Undefined variable $data C:\laragon\www\Project\fitnessrecord\application\views\progress_view.php 23
ERROR - 2025-05-22 14:58:23 --> Severity: Warning --> Attempt to read property "level" on null C:\laragon\www\Project\fitnessrecord\application\views\progress_view.php 23
ERROR - 2025-05-22 14:58:23 --> Severity: 8192 --> ucfirst(): Passing null to parameter #1 ($string) of type string is deprecated C:\laragon\www\Project\fitnessrecord\application\views\progress_view.php 23
INFO - 2025-05-22 14:58:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\progress_view.php
INFO - 2025-05-22 14:58:23 --> Final output sent to browser
DEBUG - 2025-05-22 14:58:23 --> Total execution time: 0.0655
INFO - 2025-05-22 14:58:23 --> Config Class Initialized
INFO - 2025-05-22 14:58:23 --> Hooks Class Initialized
DEBUG - 2025-05-22 14:58:23 --> UTF-8 Support Enabled
INFO - 2025-05-22 14:58:23 --> Utf8 Class Initialized
INFO - 2025-05-22 14:58:23 --> URI Class Initialized
INFO - 2025-05-22 14:58:23 --> Router Class Initialized
INFO - 2025-05-22 14:58:23 --> Output Class Initialized
INFO - 2025-05-22 14:58:23 --> Security Class Initialized
DEBUG - 2025-05-22 14:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 14:58:23 --> Input Class Initialized
INFO - 2025-05-22 14:58:23 --> Language Class Initialized
INFO - 2025-05-22 14:58:23 --> Loader Class Initialized
INFO - 2025-05-22 14:58:23 --> Helper loaded: url_helper
INFO - 2025-05-22 14:58:23 --> Helper loaded: form_helper
INFO - 2025-05-22 14:58:23 --> Database Driver Class Initialized
DEBUG - 2025-05-22 14:58:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 14:58:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 14:58:23 --> Controller Class Initialized
INFO - 2025-05-22 14:58:23 --> Model "Progress_model" initialized
INFO - 2025-05-22 14:58:23 --> Final output sent to browser
DEBUG - 2025-05-22 14:58:23 --> Total execution time: 0.0686
INFO - 2025-05-22 14:58:30 --> Config Class Initialized
INFO - 2025-05-22 14:58:30 --> Hooks Class Initialized
DEBUG - 2025-05-22 14:58:30 --> UTF-8 Support Enabled
INFO - 2025-05-22 14:58:30 --> Utf8 Class Initialized
INFO - 2025-05-22 14:58:30 --> URI Class Initialized
INFO - 2025-05-22 14:58:30 --> Router Class Initialized
INFO - 2025-05-22 14:58:30 --> Output Class Initialized
INFO - 2025-05-22 14:58:30 --> Security Class Initialized
DEBUG - 2025-05-22 14:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 14:58:30 --> Input Class Initialized
INFO - 2025-05-22 14:58:30 --> Language Class Initialized
INFO - 2025-05-22 14:58:30 --> Loader Class Initialized
INFO - 2025-05-22 14:58:30 --> Helper loaded: url_helper
INFO - 2025-05-22 14:58:30 --> Helper loaded: form_helper
INFO - 2025-05-22 14:58:30 --> Database Driver Class Initialized
DEBUG - 2025-05-22 14:58:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 14:58:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 14:58:30 --> Controller Class Initialized
INFO - 2025-05-22 14:58:30 --> Model "Timer_model" initialized
INFO - 2025-05-22 14:58:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\timer_view.php
INFO - 2025-05-22 14:58:30 --> Final output sent to browser
DEBUG - 2025-05-22 14:58:30 --> Total execution time: 0.0800
INFO - 2025-05-22 14:58:40 --> Config Class Initialized
INFO - 2025-05-22 14:58:40 --> Hooks Class Initialized
DEBUG - 2025-05-22 14:58:40 --> UTF-8 Support Enabled
INFO - 2025-05-22 14:58:40 --> Utf8 Class Initialized
INFO - 2025-05-22 14:58:40 --> URI Class Initialized
INFO - 2025-05-22 14:58:40 --> Router Class Initialized
INFO - 2025-05-22 14:58:40 --> Output Class Initialized
INFO - 2025-05-22 14:58:40 --> Security Class Initialized
DEBUG - 2025-05-22 14:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 14:58:40 --> Input Class Initialized
INFO - 2025-05-22 14:58:40 --> Language Class Initialized
INFO - 2025-05-22 14:58:40 --> Loader Class Initialized
INFO - 2025-05-22 14:58:40 --> Helper loaded: url_helper
INFO - 2025-05-22 14:58:40 --> Helper loaded: form_helper
INFO - 2025-05-22 14:58:40 --> Database Driver Class Initialized
DEBUG - 2025-05-22 14:58:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 14:58:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 14:58:40 --> Controller Class Initialized
INFO - 2025-05-22 14:58:40 --> Model "Timer_model" initialized
ERROR - 2025-05-22 14:58:40 --> Query error: Table 'fitnessrec.activity' doesn't exist - Invalid query: SELECT *
FROM `activity`
WHERE `id` = '1'
INFO - 2025-05-22 14:58:40 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-22 14:58:44 --> Config Class Initialized
INFO - 2025-05-22 14:58:44 --> Hooks Class Initialized
DEBUG - 2025-05-22 14:58:44 --> UTF-8 Support Enabled
INFO - 2025-05-22 14:58:44 --> Utf8 Class Initialized
INFO - 2025-05-22 14:58:44 --> URI Class Initialized
INFO - 2025-05-22 14:58:44 --> Router Class Initialized
INFO - 2025-05-22 14:58:44 --> Output Class Initialized
INFO - 2025-05-22 14:58:44 --> Security Class Initialized
DEBUG - 2025-05-22 14:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 14:58:44 --> Input Class Initialized
INFO - 2025-05-22 14:58:44 --> Language Class Initialized
INFO - 2025-05-22 14:58:44 --> Loader Class Initialized
INFO - 2025-05-22 14:58:44 --> Helper loaded: url_helper
INFO - 2025-05-22 14:58:44 --> Helper loaded: form_helper
INFO - 2025-05-22 14:58:44 --> Database Driver Class Initialized
DEBUG - 2025-05-22 14:58:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 14:58:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 14:58:44 --> Controller Class Initialized
INFO - 2025-05-22 14:58:44 --> Model "Timer_model" initialized
ERROR - 2025-05-22 14:58:44 --> Query error: Table 'fitnessrec.activity' doesn't exist - Invalid query: SELECT *
FROM `activity`
WHERE `id` = '1'
INFO - 2025-05-22 14:58:44 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-22 14:58:45 --> Config Class Initialized
INFO - 2025-05-22 14:58:45 --> Hooks Class Initialized
DEBUG - 2025-05-22 14:58:45 --> UTF-8 Support Enabled
INFO - 2025-05-22 14:58:45 --> Utf8 Class Initialized
INFO - 2025-05-22 14:58:45 --> URI Class Initialized
INFO - 2025-05-22 14:58:45 --> Router Class Initialized
INFO - 2025-05-22 14:58:45 --> Output Class Initialized
INFO - 2025-05-22 14:58:45 --> Security Class Initialized
DEBUG - 2025-05-22 14:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 14:58:45 --> Input Class Initialized
INFO - 2025-05-22 14:58:45 --> Language Class Initialized
INFO - 2025-05-22 14:58:45 --> Loader Class Initialized
INFO - 2025-05-22 14:58:45 --> Helper loaded: url_helper
INFO - 2025-05-22 14:58:45 --> Helper loaded: form_helper
INFO - 2025-05-22 14:58:45 --> Database Driver Class Initialized
DEBUG - 2025-05-22 14:58:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 14:58:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 14:58:45 --> Controller Class Initialized
INFO - 2025-05-22 14:58:45 --> Model "Timer_model" initialized
ERROR - 2025-05-22 14:58:45 --> Query error: Table 'fitnessrec.activity' doesn't exist - Invalid query: SELECT *
FROM `activity`
WHERE `id` = '1'
INFO - 2025-05-22 14:58:45 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-22 14:58:45 --> Config Class Initialized
INFO - 2025-05-22 14:58:45 --> Hooks Class Initialized
DEBUG - 2025-05-22 14:58:45 --> UTF-8 Support Enabled
INFO - 2025-05-22 14:58:45 --> Utf8 Class Initialized
INFO - 2025-05-22 14:58:45 --> URI Class Initialized
INFO - 2025-05-22 14:58:45 --> Router Class Initialized
INFO - 2025-05-22 14:58:45 --> Output Class Initialized
INFO - 2025-05-22 14:58:45 --> Security Class Initialized
DEBUG - 2025-05-22 14:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 14:58:45 --> Input Class Initialized
INFO - 2025-05-22 14:58:45 --> Language Class Initialized
INFO - 2025-05-22 14:58:45 --> Loader Class Initialized
INFO - 2025-05-22 14:58:45 --> Helper loaded: url_helper
INFO - 2025-05-22 14:58:45 --> Helper loaded: form_helper
INFO - 2025-05-22 14:58:45 --> Database Driver Class Initialized
DEBUG - 2025-05-22 14:58:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 14:58:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 14:58:45 --> Controller Class Initialized
INFO - 2025-05-22 14:58:45 --> Model "Timer_model" initialized
ERROR - 2025-05-22 14:58:45 --> Query error: Table 'fitnessrec.activity' doesn't exist - Invalid query: SELECT *
FROM `activity`
WHERE `id` = '1'
INFO - 2025-05-22 14:58:45 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-22 14:58:45 --> Config Class Initialized
INFO - 2025-05-22 14:58:45 --> Hooks Class Initialized
DEBUG - 2025-05-22 14:58:45 --> UTF-8 Support Enabled
INFO - 2025-05-22 14:58:45 --> Utf8 Class Initialized
INFO - 2025-05-22 14:58:45 --> URI Class Initialized
INFO - 2025-05-22 14:58:45 --> Router Class Initialized
INFO - 2025-05-22 14:58:45 --> Output Class Initialized
INFO - 2025-05-22 14:58:45 --> Security Class Initialized
DEBUG - 2025-05-22 14:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 14:58:45 --> Input Class Initialized
INFO - 2025-05-22 14:58:45 --> Language Class Initialized
INFO - 2025-05-22 14:58:45 --> Loader Class Initialized
INFO - 2025-05-22 14:58:45 --> Helper loaded: url_helper
INFO - 2025-05-22 14:58:45 --> Helper loaded: form_helper
INFO - 2025-05-22 14:58:45 --> Database Driver Class Initialized
DEBUG - 2025-05-22 14:58:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 14:58:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 14:58:45 --> Controller Class Initialized
INFO - 2025-05-22 14:58:45 --> Model "Timer_model" initialized
ERROR - 2025-05-22 14:58:45 --> Query error: Table 'fitnessrec.activity' doesn't exist - Invalid query: SELECT *
FROM `activity`
WHERE `id` = '1'
INFO - 2025-05-22 14:58:45 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-22 14:58:45 --> Config Class Initialized
INFO - 2025-05-22 14:58:45 --> Hooks Class Initialized
DEBUG - 2025-05-22 14:58:45 --> UTF-8 Support Enabled
INFO - 2025-05-22 14:58:45 --> Utf8 Class Initialized
INFO - 2025-05-22 14:58:45 --> URI Class Initialized
INFO - 2025-05-22 14:58:45 --> Router Class Initialized
INFO - 2025-05-22 14:58:45 --> Output Class Initialized
INFO - 2025-05-22 14:58:45 --> Security Class Initialized
DEBUG - 2025-05-22 14:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 14:58:45 --> Input Class Initialized
INFO - 2025-05-22 14:58:45 --> Language Class Initialized
INFO - 2025-05-22 14:58:45 --> Loader Class Initialized
INFO - 2025-05-22 14:58:45 --> Helper loaded: url_helper
INFO - 2025-05-22 14:58:45 --> Helper loaded: form_helper
INFO - 2025-05-22 14:58:45 --> Database Driver Class Initialized
DEBUG - 2025-05-22 14:58:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 14:58:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 14:58:45 --> Controller Class Initialized
INFO - 2025-05-22 14:58:45 --> Model "Timer_model" initialized
ERROR - 2025-05-22 14:58:45 --> Query error: Table 'fitnessrec.activity' doesn't exist - Invalid query: SELECT *
FROM `activity`
WHERE `id` = '1'
INFO - 2025-05-22 14:58:45 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-22 14:58:45 --> Config Class Initialized
INFO - 2025-05-22 14:58:45 --> Hooks Class Initialized
DEBUG - 2025-05-22 14:58:45 --> UTF-8 Support Enabled
INFO - 2025-05-22 14:58:45 --> Utf8 Class Initialized
INFO - 2025-05-22 14:58:45 --> URI Class Initialized
INFO - 2025-05-22 14:58:45 --> Router Class Initialized
INFO - 2025-05-22 14:58:45 --> Output Class Initialized
INFO - 2025-05-22 14:58:45 --> Security Class Initialized
DEBUG - 2025-05-22 14:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 14:58:45 --> Input Class Initialized
INFO - 2025-05-22 14:58:45 --> Language Class Initialized
INFO - 2025-05-22 14:58:45 --> Loader Class Initialized
INFO - 2025-05-22 14:58:45 --> Helper loaded: url_helper
INFO - 2025-05-22 14:58:45 --> Helper loaded: form_helper
INFO - 2025-05-22 14:58:45 --> Database Driver Class Initialized
DEBUG - 2025-05-22 14:58:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 14:58:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 14:58:45 --> Controller Class Initialized
INFO - 2025-05-22 14:58:45 --> Model "Timer_model" initialized
ERROR - 2025-05-22 14:58:45 --> Query error: Table 'fitnessrec.activity' doesn't exist - Invalid query: SELECT *
FROM `activity`
WHERE `id` = '1'
INFO - 2025-05-22 14:58:45 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-22 14:58:57 --> Config Class Initialized
INFO - 2025-05-22 14:58:57 --> Hooks Class Initialized
DEBUG - 2025-05-22 14:58:57 --> UTF-8 Support Enabled
INFO - 2025-05-22 14:58:57 --> Utf8 Class Initialized
INFO - 2025-05-22 14:58:57 --> URI Class Initialized
INFO - 2025-05-22 14:58:57 --> Router Class Initialized
INFO - 2025-05-22 14:58:57 --> Output Class Initialized
INFO - 2025-05-22 14:58:57 --> Security Class Initialized
DEBUG - 2025-05-22 14:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 14:58:57 --> Input Class Initialized
INFO - 2025-05-22 14:58:57 --> Language Class Initialized
INFO - 2025-05-22 14:58:57 --> Loader Class Initialized
INFO - 2025-05-22 14:58:57 --> Helper loaded: url_helper
INFO - 2025-05-22 14:58:57 --> Helper loaded: form_helper
INFO - 2025-05-22 14:58:57 --> Database Driver Class Initialized
DEBUG - 2025-05-22 14:58:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 14:58:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 14:58:57 --> Controller Class Initialized
INFO - 2025-05-22 14:58:57 --> Model "Timer_model" initialized
ERROR - 2025-05-22 14:58:57 --> Query error: Table 'fitnessrec.activity' doesn't exist - Invalid query: SELECT *
FROM `activity`
WHERE `id` = '7'
INFO - 2025-05-22 14:58:57 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-22 14:59:01 --> Config Class Initialized
INFO - 2025-05-22 14:59:01 --> Hooks Class Initialized
DEBUG - 2025-05-22 14:59:01 --> UTF-8 Support Enabled
INFO - 2025-05-22 14:59:01 --> Utf8 Class Initialized
INFO - 2025-05-22 14:59:01 --> URI Class Initialized
INFO - 2025-05-22 14:59:01 --> Router Class Initialized
INFO - 2025-05-22 14:59:01 --> Output Class Initialized
INFO - 2025-05-22 14:59:01 --> Security Class Initialized
DEBUG - 2025-05-22 14:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 14:59:01 --> Input Class Initialized
INFO - 2025-05-22 14:59:01 --> Language Class Initialized
INFO - 2025-05-22 14:59:01 --> Loader Class Initialized
INFO - 2025-05-22 14:59:01 --> Helper loaded: url_helper
INFO - 2025-05-22 14:59:01 --> Helper loaded: form_helper
INFO - 2025-05-22 14:59:01 --> Database Driver Class Initialized
DEBUG - 2025-05-22 14:59:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 14:59:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 14:59:01 --> Controller Class Initialized
INFO - 2025-05-22 14:59:01 --> Model "Progress_model" initialized
ERROR - 2025-05-22 14:59:01 --> Severity: Warning --> Undefined variable $data C:\laragon\www\Project\fitnessrecord\application\views\progress_view.php 23
ERROR - 2025-05-22 14:59:01 --> Severity: Warning --> Attempt to read property "level" on null C:\laragon\www\Project\fitnessrecord\application\views\progress_view.php 23
ERROR - 2025-05-22 14:59:01 --> Severity: 8192 --> ucfirst(): Passing null to parameter #1 ($string) of type string is deprecated C:\laragon\www\Project\fitnessrecord\application\views\progress_view.php 23
INFO - 2025-05-22 14:59:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\progress_view.php
INFO - 2025-05-22 14:59:01 --> Final output sent to browser
DEBUG - 2025-05-22 14:59:01 --> Total execution time: 0.0800
INFO - 2025-05-22 14:59:01 --> Config Class Initialized
INFO - 2025-05-22 14:59:01 --> Hooks Class Initialized
DEBUG - 2025-05-22 14:59:01 --> UTF-8 Support Enabled
INFO - 2025-05-22 14:59:01 --> Utf8 Class Initialized
INFO - 2025-05-22 14:59:01 --> URI Class Initialized
INFO - 2025-05-22 14:59:01 --> Router Class Initialized
INFO - 2025-05-22 14:59:01 --> Output Class Initialized
INFO - 2025-05-22 14:59:01 --> Security Class Initialized
DEBUG - 2025-05-22 14:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 14:59:01 --> Input Class Initialized
INFO - 2025-05-22 14:59:01 --> Language Class Initialized
INFO - 2025-05-22 14:59:01 --> Loader Class Initialized
INFO - 2025-05-22 14:59:01 --> Helper loaded: url_helper
INFO - 2025-05-22 14:59:02 --> Helper loaded: form_helper
INFO - 2025-05-22 14:59:02 --> Database Driver Class Initialized
DEBUG - 2025-05-22 14:59:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 14:59:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 14:59:02 --> Controller Class Initialized
INFO - 2025-05-22 14:59:02 --> Model "Progress_model" initialized
INFO - 2025-05-22 14:59:02 --> Final output sent to browser
DEBUG - 2025-05-22 14:59:02 --> Total execution time: 0.0722
INFO - 2025-05-22 15:00:02 --> Config Class Initialized
INFO - 2025-05-22 15:00:02 --> Hooks Class Initialized
DEBUG - 2025-05-22 15:00:02 --> UTF-8 Support Enabled
INFO - 2025-05-22 15:00:02 --> Utf8 Class Initialized
INFO - 2025-05-22 15:00:02 --> URI Class Initialized
INFO - 2025-05-22 15:00:02 --> Router Class Initialized
INFO - 2025-05-22 15:00:02 --> Output Class Initialized
INFO - 2025-05-22 15:00:02 --> Security Class Initialized
DEBUG - 2025-05-22 15:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 15:00:02 --> Input Class Initialized
INFO - 2025-05-22 15:00:02 --> Language Class Initialized
INFO - 2025-05-22 15:00:02 --> Loader Class Initialized
INFO - 2025-05-22 15:00:02 --> Helper loaded: url_helper
INFO - 2025-05-22 15:00:02 --> Helper loaded: form_helper
INFO - 2025-05-22 15:00:02 --> Database Driver Class Initialized
DEBUG - 2025-05-22 15:00:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 15:00:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 15:00:02 --> Controller Class Initialized
INFO - 2025-05-22 15:00:02 --> Model "Progress_model" initialized
INFO - 2025-05-22 15:00:02 --> Final output sent to browser
DEBUG - 2025-05-22 15:00:02 --> Total execution time: 0.0997
INFO - 2025-05-22 15:05:22 --> Config Class Initialized
INFO - 2025-05-22 15:05:22 --> Hooks Class Initialized
DEBUG - 2025-05-22 15:05:22 --> UTF-8 Support Enabled
INFO - 2025-05-22 15:05:22 --> Utf8 Class Initialized
INFO - 2025-05-22 15:05:22 --> URI Class Initialized
INFO - 2025-05-22 15:05:22 --> Router Class Initialized
INFO - 2025-05-22 15:05:22 --> Output Class Initialized
INFO - 2025-05-22 15:05:22 --> Security Class Initialized
DEBUG - 2025-05-22 15:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 15:05:22 --> Input Class Initialized
INFO - 2025-05-22 15:05:22 --> Language Class Initialized
INFO - 2025-05-22 15:05:22 --> Loader Class Initialized
INFO - 2025-05-22 15:05:22 --> Helper loaded: url_helper
INFO - 2025-05-22 15:05:22 --> Helper loaded: form_helper
INFO - 2025-05-22 15:05:22 --> Database Driver Class Initialized
DEBUG - 2025-05-22 15:05:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 15:05:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 15:05:22 --> Controller Class Initialized
INFO - 2025-05-22 15:05:22 --> Model "Progress_model" initialized
INFO - 2025-05-22 15:05:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\progress_view.php
INFO - 2025-05-22 15:05:22 --> Final output sent to browser
DEBUG - 2025-05-22 15:05:22 --> Total execution time: 0.0689
INFO - 2025-05-22 15:05:22 --> Config Class Initialized
INFO - 2025-05-22 15:05:22 --> Hooks Class Initialized
DEBUG - 2025-05-22 15:05:22 --> UTF-8 Support Enabled
INFO - 2025-05-22 15:05:22 --> Utf8 Class Initialized
INFO - 2025-05-22 15:05:22 --> URI Class Initialized
INFO - 2025-05-22 15:05:22 --> Router Class Initialized
INFO - 2025-05-22 15:05:22 --> Output Class Initialized
INFO - 2025-05-22 15:05:22 --> Security Class Initialized
DEBUG - 2025-05-22 15:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 15:05:22 --> Input Class Initialized
INFO - 2025-05-22 15:05:22 --> Language Class Initialized
INFO - 2025-05-22 15:05:22 --> Loader Class Initialized
INFO - 2025-05-22 15:05:22 --> Helper loaded: url_helper
INFO - 2025-05-22 15:05:22 --> Helper loaded: form_helper
INFO - 2025-05-22 15:05:22 --> Database Driver Class Initialized
DEBUG - 2025-05-22 15:05:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 15:05:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 15:05:23 --> Controller Class Initialized
INFO - 2025-05-22 15:05:23 --> Model "Progress_model" initialized
INFO - 2025-05-22 15:05:23 --> Final output sent to browser
DEBUG - 2025-05-22 15:05:23 --> Total execution time: 0.0843
INFO - 2025-05-22 15:05:24 --> Config Class Initialized
INFO - 2025-05-22 15:05:24 --> Hooks Class Initialized
DEBUG - 2025-05-22 15:05:24 --> UTF-8 Support Enabled
INFO - 2025-05-22 15:05:24 --> Utf8 Class Initialized
INFO - 2025-05-22 15:05:24 --> URI Class Initialized
INFO - 2025-05-22 15:05:24 --> Router Class Initialized
INFO - 2025-05-22 15:05:24 --> Output Class Initialized
INFO - 2025-05-22 15:05:24 --> Security Class Initialized
DEBUG - 2025-05-22 15:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 15:05:24 --> Input Class Initialized
INFO - 2025-05-22 15:05:24 --> Language Class Initialized
INFO - 2025-05-22 15:05:24 --> Loader Class Initialized
INFO - 2025-05-22 15:05:24 --> Helper loaded: url_helper
INFO - 2025-05-22 15:05:24 --> Helper loaded: form_helper
INFO - 2025-05-22 15:05:24 --> Database Driver Class Initialized
DEBUG - 2025-05-22 15:05:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 15:05:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 15:05:24 --> Controller Class Initialized
INFO - 2025-05-22 15:05:24 --> Model "Progress_model" initialized
INFO - 2025-05-22 15:05:24 --> Final output sent to browser
DEBUG - 2025-05-22 15:05:24 --> Total execution time: 0.0853
INFO - 2025-05-22 15:05:27 --> Config Class Initialized
INFO - 2025-05-22 15:05:27 --> Hooks Class Initialized
DEBUG - 2025-05-22 15:05:27 --> UTF-8 Support Enabled
INFO - 2025-05-22 15:05:27 --> Utf8 Class Initialized
INFO - 2025-05-22 15:05:27 --> URI Class Initialized
INFO - 2025-05-22 15:05:27 --> Router Class Initialized
INFO - 2025-05-22 15:05:27 --> Output Class Initialized
INFO - 2025-05-22 15:05:27 --> Security Class Initialized
DEBUG - 2025-05-22 15:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 15:05:27 --> Input Class Initialized
INFO - 2025-05-22 15:05:27 --> Language Class Initialized
INFO - 2025-05-22 15:05:27 --> Loader Class Initialized
INFO - 2025-05-22 15:05:27 --> Helper loaded: url_helper
INFO - 2025-05-22 15:05:27 --> Helper loaded: form_helper
INFO - 2025-05-22 15:05:27 --> Database Driver Class Initialized
DEBUG - 2025-05-22 15:05:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 15:05:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 15:05:27 --> Controller Class Initialized
INFO - 2025-05-22 15:05:27 --> Model "Progress_model" initialized
INFO - 2025-05-22 15:05:27 --> Final output sent to browser
DEBUG - 2025-05-22 15:05:27 --> Total execution time: 0.0782
INFO - 2025-05-22 15:05:31 --> Config Class Initialized
INFO - 2025-05-22 15:05:31 --> Hooks Class Initialized
DEBUG - 2025-05-22 15:05:31 --> UTF-8 Support Enabled
INFO - 2025-05-22 15:05:31 --> Utf8 Class Initialized
INFO - 2025-05-22 15:05:31 --> URI Class Initialized
INFO - 2025-05-22 15:05:31 --> Router Class Initialized
INFO - 2025-05-22 15:05:31 --> Output Class Initialized
INFO - 2025-05-22 15:05:31 --> Security Class Initialized
DEBUG - 2025-05-22 15:05:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 15:05:31 --> Input Class Initialized
INFO - 2025-05-22 15:05:31 --> Language Class Initialized
INFO - 2025-05-22 15:05:31 --> Loader Class Initialized
INFO - 2025-05-22 15:05:31 --> Helper loaded: url_helper
INFO - 2025-05-22 15:05:31 --> Helper loaded: form_helper
INFO - 2025-05-22 15:05:31 --> Database Driver Class Initialized
DEBUG - 2025-05-22 15:05:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 15:05:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 15:05:31 --> Controller Class Initialized
INFO - 2025-05-22 15:05:31 --> Model "Timer_model" initialized
INFO - 2025-05-22 15:05:31 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\timer_view.php
INFO - 2025-05-22 15:05:31 --> Final output sent to browser
DEBUG - 2025-05-22 15:05:31 --> Total execution time: 0.0873
INFO - 2025-05-22 15:05:39 --> Config Class Initialized
INFO - 2025-05-22 15:05:39 --> Hooks Class Initialized
DEBUG - 2025-05-22 15:05:39 --> UTF-8 Support Enabled
INFO - 2025-05-22 15:05:39 --> Utf8 Class Initialized
INFO - 2025-05-22 15:05:39 --> URI Class Initialized
INFO - 2025-05-22 15:05:39 --> Router Class Initialized
INFO - 2025-05-22 15:05:39 --> Output Class Initialized
INFO - 2025-05-22 15:05:39 --> Security Class Initialized
DEBUG - 2025-05-22 15:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 15:05:39 --> Input Class Initialized
INFO - 2025-05-22 15:05:39 --> Language Class Initialized
INFO - 2025-05-22 15:05:39 --> Loader Class Initialized
INFO - 2025-05-22 15:05:39 --> Helper loaded: url_helper
INFO - 2025-05-22 15:05:39 --> Helper loaded: form_helper
INFO - 2025-05-22 15:05:39 --> Database Driver Class Initialized
DEBUG - 2025-05-22 15:05:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 15:05:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 15:05:39 --> Controller Class Initialized
INFO - 2025-05-22 15:05:39 --> Model "Timer_model" initialized
ERROR - 2025-05-22 15:05:39 --> Query error: Table 'fitnessrec.activity' doesn't exist - Invalid query: SELECT *
FROM `activity`
WHERE `id` = '6'
INFO - 2025-05-22 15:05:39 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-22 15:05:39 --> Config Class Initialized
INFO - 2025-05-22 15:05:39 --> Hooks Class Initialized
DEBUG - 2025-05-22 15:05:39 --> UTF-8 Support Enabled
INFO - 2025-05-22 15:05:39 --> Utf8 Class Initialized
INFO - 2025-05-22 15:05:39 --> URI Class Initialized
INFO - 2025-05-22 15:05:39 --> Router Class Initialized
INFO - 2025-05-22 15:05:39 --> Output Class Initialized
INFO - 2025-05-22 15:05:39 --> Security Class Initialized
DEBUG - 2025-05-22 15:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 15:05:39 --> Input Class Initialized
INFO - 2025-05-22 15:05:39 --> Language Class Initialized
INFO - 2025-05-22 15:05:39 --> Loader Class Initialized
INFO - 2025-05-22 15:05:39 --> Helper loaded: url_helper
INFO - 2025-05-22 15:05:39 --> Helper loaded: form_helper
INFO - 2025-05-22 15:05:39 --> Database Driver Class Initialized
DEBUG - 2025-05-22 15:05:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 15:05:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 15:05:39 --> Controller Class Initialized
INFO - 2025-05-22 15:05:39 --> Model "Timer_model" initialized
ERROR - 2025-05-22 15:05:39 --> Query error: Table 'fitnessrec.activity' doesn't exist - Invalid query: SELECT *
FROM `activity`
WHERE `id` = '6'
INFO - 2025-05-22 15:05:39 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-22 15:05:39 --> Config Class Initialized
INFO - 2025-05-22 15:05:39 --> Hooks Class Initialized
DEBUG - 2025-05-22 15:05:39 --> UTF-8 Support Enabled
INFO - 2025-05-22 15:05:39 --> Utf8 Class Initialized
INFO - 2025-05-22 15:05:39 --> URI Class Initialized
INFO - 2025-05-22 15:05:39 --> Router Class Initialized
INFO - 2025-05-22 15:05:39 --> Output Class Initialized
INFO - 2025-05-22 15:05:39 --> Security Class Initialized
DEBUG - 2025-05-22 15:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 15:05:39 --> Input Class Initialized
INFO - 2025-05-22 15:05:39 --> Language Class Initialized
INFO - 2025-05-22 15:05:39 --> Loader Class Initialized
INFO - 2025-05-22 15:05:39 --> Helper loaded: url_helper
INFO - 2025-05-22 15:05:39 --> Helper loaded: form_helper
INFO - 2025-05-22 15:05:39 --> Database Driver Class Initialized
DEBUG - 2025-05-22 15:05:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 15:05:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 15:05:39 --> Controller Class Initialized
INFO - 2025-05-22 15:05:39 --> Model "Timer_model" initialized
ERROR - 2025-05-22 15:05:39 --> Query error: Table 'fitnessrec.activity' doesn't exist - Invalid query: SELECT *
FROM `activity`
WHERE `id` = '6'
INFO - 2025-05-22 15:05:39 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-22 15:05:41 --> Config Class Initialized
INFO - 2025-05-22 15:05:41 --> Hooks Class Initialized
DEBUG - 2025-05-22 15:05:41 --> UTF-8 Support Enabled
INFO - 2025-05-22 15:05:41 --> Utf8 Class Initialized
INFO - 2025-05-22 15:05:41 --> URI Class Initialized
INFO - 2025-05-22 15:05:41 --> Router Class Initialized
INFO - 2025-05-22 15:05:41 --> Output Class Initialized
INFO - 2025-05-22 15:05:41 --> Security Class Initialized
DEBUG - 2025-05-22 15:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 15:05:41 --> Input Class Initialized
INFO - 2025-05-22 15:05:41 --> Language Class Initialized
INFO - 2025-05-22 15:05:41 --> Loader Class Initialized
INFO - 2025-05-22 15:05:41 --> Helper loaded: url_helper
INFO - 2025-05-22 15:05:41 --> Helper loaded: form_helper
INFO - 2025-05-22 15:05:41 --> Database Driver Class Initialized
DEBUG - 2025-05-22 15:05:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 15:05:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 15:05:41 --> Controller Class Initialized
INFO - 2025-05-22 15:05:41 --> Model "Timer_model" initialized
ERROR - 2025-05-22 15:05:41 --> Query error: Table 'fitnessrec.activity' doesn't exist - Invalid query: SELECT *
FROM `activity`
WHERE `id` = '6'
INFO - 2025-05-22 15:05:41 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-22 15:05:44 --> Config Class Initialized
INFO - 2025-05-22 15:05:44 --> Hooks Class Initialized
DEBUG - 2025-05-22 15:05:44 --> UTF-8 Support Enabled
INFO - 2025-05-22 15:05:44 --> Utf8 Class Initialized
INFO - 2025-05-22 15:05:44 --> URI Class Initialized
INFO - 2025-05-22 15:05:44 --> Router Class Initialized
INFO - 2025-05-22 15:05:44 --> Output Class Initialized
INFO - 2025-05-22 15:05:44 --> Security Class Initialized
DEBUG - 2025-05-22 15:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 15:05:44 --> Input Class Initialized
INFO - 2025-05-22 15:05:44 --> Language Class Initialized
INFO - 2025-05-22 15:05:44 --> Loader Class Initialized
INFO - 2025-05-22 15:05:44 --> Helper loaded: url_helper
INFO - 2025-05-22 15:05:44 --> Helper loaded: form_helper
INFO - 2025-05-22 15:05:44 --> Database Driver Class Initialized
DEBUG - 2025-05-22 15:05:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 15:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 15:05:44 --> Controller Class Initialized
INFO - 2025-05-22 15:05:44 --> Model "Progress_model" initialized
INFO - 2025-05-22 15:05:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\progress_view.php
INFO - 2025-05-22 15:05:44 --> Final output sent to browser
DEBUG - 2025-05-22 15:05:44 --> Total execution time: 0.0723
INFO - 2025-05-22 15:05:44 --> Config Class Initialized
INFO - 2025-05-22 15:05:44 --> Hooks Class Initialized
DEBUG - 2025-05-22 15:05:44 --> UTF-8 Support Enabled
INFO - 2025-05-22 15:05:44 --> Utf8 Class Initialized
INFO - 2025-05-22 15:05:44 --> URI Class Initialized
INFO - 2025-05-22 15:05:44 --> Router Class Initialized
INFO - 2025-05-22 15:05:44 --> Output Class Initialized
INFO - 2025-05-22 15:05:44 --> Security Class Initialized
DEBUG - 2025-05-22 15:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 15:05:44 --> Input Class Initialized
INFO - 2025-05-22 15:05:44 --> Language Class Initialized
INFO - 2025-05-22 15:05:44 --> Loader Class Initialized
INFO - 2025-05-22 15:05:44 --> Helper loaded: url_helper
INFO - 2025-05-22 15:05:44 --> Helper loaded: form_helper
INFO - 2025-05-22 15:05:44 --> Database Driver Class Initialized
DEBUG - 2025-05-22 15:05:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 15:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 15:05:44 --> Controller Class Initialized
INFO - 2025-05-22 15:05:44 --> Model "Progress_model" initialized
INFO - 2025-05-22 15:05:44 --> Final output sent to browser
DEBUG - 2025-05-22 15:05:44 --> Total execution time: 0.0800
INFO - 2025-05-22 15:05:46 --> Config Class Initialized
INFO - 2025-05-22 15:05:46 --> Hooks Class Initialized
DEBUG - 2025-05-22 15:05:46 --> UTF-8 Support Enabled
INFO - 2025-05-22 15:05:46 --> Utf8 Class Initialized
INFO - 2025-05-22 15:05:46 --> URI Class Initialized
INFO - 2025-05-22 15:05:46 --> Router Class Initialized
INFO - 2025-05-22 15:05:46 --> Output Class Initialized
INFO - 2025-05-22 15:05:46 --> Security Class Initialized
DEBUG - 2025-05-22 15:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 15:05:46 --> Input Class Initialized
INFO - 2025-05-22 15:05:46 --> Language Class Initialized
INFO - 2025-05-22 15:05:46 --> Loader Class Initialized
INFO - 2025-05-22 15:05:46 --> Helper loaded: url_helper
INFO - 2025-05-22 15:05:46 --> Helper loaded: form_helper
INFO - 2025-05-22 15:05:46 --> Database Driver Class Initialized
DEBUG - 2025-05-22 15:05:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 15:05:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 15:05:46 --> Controller Class Initialized
INFO - 2025-05-22 15:05:46 --> Model "Progress_model" initialized
INFO - 2025-05-22 15:05:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\progress_view.php
INFO - 2025-05-22 15:05:46 --> Final output sent to browser
DEBUG - 2025-05-22 15:05:46 --> Total execution time: 0.0742
INFO - 2025-05-22 15:05:47 --> Config Class Initialized
INFO - 2025-05-22 15:05:47 --> Hooks Class Initialized
DEBUG - 2025-05-22 15:05:47 --> UTF-8 Support Enabled
INFO - 2025-05-22 15:05:47 --> Utf8 Class Initialized
INFO - 2025-05-22 15:05:47 --> URI Class Initialized
INFO - 2025-05-22 15:05:47 --> Router Class Initialized
INFO - 2025-05-22 15:05:47 --> Output Class Initialized
INFO - 2025-05-22 15:05:47 --> Security Class Initialized
DEBUG - 2025-05-22 15:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 15:05:47 --> Input Class Initialized
INFO - 2025-05-22 15:05:47 --> Language Class Initialized
INFO - 2025-05-22 15:05:47 --> Loader Class Initialized
INFO - 2025-05-22 15:05:47 --> Helper loaded: url_helper
INFO - 2025-05-22 15:05:47 --> Helper loaded: form_helper
INFO - 2025-05-22 15:05:47 --> Database Driver Class Initialized
DEBUG - 2025-05-22 15:05:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 15:05:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 15:05:47 --> Controller Class Initialized
INFO - 2025-05-22 15:05:47 --> Model "Progress_model" initialized
INFO - 2025-05-22 15:05:47 --> Final output sent to browser
DEBUG - 2025-05-22 15:05:47 --> Total execution time: 0.0636
INFO - 2025-05-22 15:05:52 --> Config Class Initialized
INFO - 2025-05-22 15:05:52 --> Hooks Class Initialized
DEBUG - 2025-05-22 15:05:52 --> UTF-8 Support Enabled
INFO - 2025-05-22 15:05:52 --> Utf8 Class Initialized
INFO - 2025-05-22 15:05:52 --> URI Class Initialized
INFO - 2025-05-22 15:05:52 --> Router Class Initialized
INFO - 2025-05-22 15:05:52 --> Output Class Initialized
INFO - 2025-05-22 15:05:52 --> Security Class Initialized
DEBUG - 2025-05-22 15:05:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 15:05:52 --> Input Class Initialized
INFO - 2025-05-22 15:05:52 --> Language Class Initialized
INFO - 2025-05-22 15:05:52 --> Loader Class Initialized
INFO - 2025-05-22 15:05:52 --> Helper loaded: url_helper
INFO - 2025-05-22 15:05:52 --> Helper loaded: form_helper
INFO - 2025-05-22 15:05:52 --> Database Driver Class Initialized
DEBUG - 2025-05-22 15:05:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 15:05:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 15:05:52 --> Controller Class Initialized
INFO - 2025-05-22 15:05:52 --> Model "Progress_model" initialized
INFO - 2025-05-22 15:05:52 --> Final output sent to browser
DEBUG - 2025-05-22 15:05:52 --> Total execution time: 0.0619
INFO - 2025-05-22 15:05:57 --> Config Class Initialized
INFO - 2025-05-22 15:05:57 --> Hooks Class Initialized
DEBUG - 2025-05-22 15:05:57 --> UTF-8 Support Enabled
INFO - 2025-05-22 15:05:57 --> Utf8 Class Initialized
INFO - 2025-05-22 15:05:57 --> URI Class Initialized
INFO - 2025-05-22 15:05:57 --> Router Class Initialized
INFO - 2025-05-22 15:05:57 --> Output Class Initialized
INFO - 2025-05-22 15:05:57 --> Security Class Initialized
DEBUG - 2025-05-22 15:05:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 15:05:57 --> Input Class Initialized
INFO - 2025-05-22 15:05:57 --> Language Class Initialized
INFO - 2025-05-22 15:05:57 --> Loader Class Initialized
INFO - 2025-05-22 15:05:57 --> Helper loaded: url_helper
INFO - 2025-05-22 15:05:57 --> Helper loaded: form_helper
INFO - 2025-05-22 15:05:57 --> Database Driver Class Initialized
DEBUG - 2025-05-22 15:05:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 15:05:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 15:05:57 --> Controller Class Initialized
INFO - 2025-05-22 15:05:57 --> Model "Progress_model" initialized
INFO - 2025-05-22 15:05:57 --> Final output sent to browser
DEBUG - 2025-05-22 15:05:57 --> Total execution time: 0.0690
INFO - 2025-05-22 15:05:58 --> Config Class Initialized
INFO - 2025-05-22 15:05:58 --> Hooks Class Initialized
DEBUG - 2025-05-22 15:05:58 --> UTF-8 Support Enabled
INFO - 2025-05-22 15:05:58 --> Utf8 Class Initialized
INFO - 2025-05-22 15:05:58 --> URI Class Initialized
INFO - 2025-05-22 15:05:58 --> Router Class Initialized
INFO - 2025-05-22 15:05:58 --> Output Class Initialized
INFO - 2025-05-22 15:05:58 --> Security Class Initialized
DEBUG - 2025-05-22 15:05:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 15:05:58 --> Input Class Initialized
INFO - 2025-05-22 15:05:58 --> Language Class Initialized
INFO - 2025-05-22 15:05:59 --> Loader Class Initialized
INFO - 2025-05-22 15:05:59 --> Helper loaded: url_helper
INFO - 2025-05-22 15:05:59 --> Helper loaded: form_helper
INFO - 2025-05-22 15:05:59 --> Database Driver Class Initialized
DEBUG - 2025-05-22 15:05:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 15:05:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 15:05:59 --> Controller Class Initialized
INFO - 2025-05-22 15:05:59 --> Model "Progress_model" initialized
INFO - 2025-05-22 15:05:59 --> Final output sent to browser
DEBUG - 2025-05-22 15:05:59 --> Total execution time: 0.0748
INFO - 2025-05-22 15:09:53 --> Config Class Initialized
INFO - 2025-05-22 15:09:53 --> Hooks Class Initialized
DEBUG - 2025-05-22 15:09:53 --> UTF-8 Support Enabled
INFO - 2025-05-22 15:09:53 --> Utf8 Class Initialized
INFO - 2025-05-22 15:09:53 --> URI Class Initialized
INFO - 2025-05-22 15:09:53 --> Router Class Initialized
INFO - 2025-05-22 15:09:53 --> Output Class Initialized
INFO - 2025-05-22 15:09:53 --> Security Class Initialized
DEBUG - 2025-05-22 15:09:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 15:09:53 --> Input Class Initialized
INFO - 2025-05-22 15:09:53 --> Language Class Initialized
INFO - 2025-05-22 15:09:53 --> Loader Class Initialized
INFO - 2025-05-22 15:09:53 --> Helper loaded: url_helper
INFO - 2025-05-22 15:09:53 --> Helper loaded: form_helper
INFO - 2025-05-22 15:09:53 --> Database Driver Class Initialized
DEBUG - 2025-05-22 15:09:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 15:09:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 15:09:53 --> Controller Class Initialized
INFO - 2025-05-22 15:09:53 --> Model "Progress_model" initialized
INFO - 2025-05-22 15:09:53 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\progress_view.php
INFO - 2025-05-22 15:09:53 --> Final output sent to browser
DEBUG - 2025-05-22 15:09:53 --> Total execution time: 0.0656
INFO - 2025-05-22 15:09:54 --> Config Class Initialized
INFO - 2025-05-22 15:09:54 --> Hooks Class Initialized
DEBUG - 2025-05-22 15:09:54 --> UTF-8 Support Enabled
INFO - 2025-05-22 15:09:54 --> Utf8 Class Initialized
INFO - 2025-05-22 15:09:54 --> URI Class Initialized
INFO - 2025-05-22 15:09:54 --> Router Class Initialized
INFO - 2025-05-22 15:09:54 --> Output Class Initialized
INFO - 2025-05-22 15:09:54 --> Security Class Initialized
DEBUG - 2025-05-22 15:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 15:09:54 --> Input Class Initialized
INFO - 2025-05-22 15:09:54 --> Language Class Initialized
INFO - 2025-05-22 15:09:54 --> Loader Class Initialized
INFO - 2025-05-22 15:09:54 --> Helper loaded: url_helper
INFO - 2025-05-22 15:09:54 --> Helper loaded: form_helper
INFO - 2025-05-22 15:09:54 --> Database Driver Class Initialized
DEBUG - 2025-05-22 15:09:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 15:09:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 15:09:54 --> Controller Class Initialized
INFO - 2025-05-22 15:09:54 --> Model "Progress_model" initialized
INFO - 2025-05-22 15:09:54 --> Final output sent to browser
DEBUG - 2025-05-22 15:09:54 --> Total execution time: 0.0713
INFO - 2025-05-22 15:09:56 --> Config Class Initialized
INFO - 2025-05-22 15:09:56 --> Hooks Class Initialized
DEBUG - 2025-05-22 15:09:56 --> UTF-8 Support Enabled
INFO - 2025-05-22 15:09:56 --> Utf8 Class Initialized
INFO - 2025-05-22 15:09:56 --> URI Class Initialized
INFO - 2025-05-22 15:09:56 --> Router Class Initialized
INFO - 2025-05-22 15:09:56 --> Output Class Initialized
INFO - 2025-05-22 15:09:56 --> Security Class Initialized
DEBUG - 2025-05-22 15:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 15:09:56 --> Input Class Initialized
INFO - 2025-05-22 15:09:56 --> Language Class Initialized
INFO - 2025-05-22 15:09:56 --> Loader Class Initialized
INFO - 2025-05-22 15:09:56 --> Helper loaded: url_helper
INFO - 2025-05-22 15:09:56 --> Helper loaded: form_helper
INFO - 2025-05-22 15:09:56 --> Database Driver Class Initialized
DEBUG - 2025-05-22 15:09:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 15:09:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 15:09:56 --> Controller Class Initialized
INFO - 2025-05-22 15:09:56 --> Model "Timer_model" initialized
INFO - 2025-05-22 15:09:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\timer_view.php
INFO - 2025-05-22 15:09:56 --> Final output sent to browser
DEBUG - 2025-05-22 15:09:56 --> Total execution time: 0.0692
INFO - 2025-05-22 15:10:02 --> Config Class Initialized
INFO - 2025-05-22 15:10:02 --> Hooks Class Initialized
DEBUG - 2025-05-22 15:10:02 --> UTF-8 Support Enabled
INFO - 2025-05-22 15:10:02 --> Utf8 Class Initialized
INFO - 2025-05-22 15:10:02 --> URI Class Initialized
INFO - 2025-05-22 15:10:02 --> Router Class Initialized
INFO - 2025-05-22 15:10:02 --> Output Class Initialized
INFO - 2025-05-22 15:10:02 --> Security Class Initialized
DEBUG - 2025-05-22 15:10:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 15:10:02 --> Input Class Initialized
INFO - 2025-05-22 15:10:02 --> Language Class Initialized
INFO - 2025-05-22 15:10:02 --> Loader Class Initialized
INFO - 2025-05-22 15:10:02 --> Helper loaded: url_helper
INFO - 2025-05-22 15:10:02 --> Helper loaded: form_helper
INFO - 2025-05-22 15:10:02 --> Database Driver Class Initialized
DEBUG - 2025-05-22 15:10:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 15:10:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 15:10:02 --> Controller Class Initialized
INFO - 2025-05-22 15:10:02 --> Model "Timer_model" initialized
ERROR - 2025-05-22 15:10:02 --> Severity: error --> Exception: Too few arguments to function Timer::mulai_timer(), 0 passed in C:\laragon\www\Project\fitnessrecord\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\Project\fitnessrecord\application\controllers\Timer.php 56
INFO - 2025-05-22 15:10:03 --> Config Class Initialized
INFO - 2025-05-22 15:10:03 --> Hooks Class Initialized
DEBUG - 2025-05-22 15:10:03 --> UTF-8 Support Enabled
INFO - 2025-05-22 15:10:03 --> Utf8 Class Initialized
INFO - 2025-05-22 15:10:03 --> URI Class Initialized
INFO - 2025-05-22 15:10:03 --> Router Class Initialized
INFO - 2025-05-22 15:10:03 --> Output Class Initialized
INFO - 2025-05-22 15:10:03 --> Security Class Initialized
DEBUG - 2025-05-22 15:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 15:10:03 --> Input Class Initialized
INFO - 2025-05-22 15:10:03 --> Language Class Initialized
INFO - 2025-05-22 15:10:03 --> Loader Class Initialized
INFO - 2025-05-22 15:10:03 --> Helper loaded: url_helper
INFO - 2025-05-22 15:10:03 --> Helper loaded: form_helper
INFO - 2025-05-22 15:10:03 --> Database Driver Class Initialized
DEBUG - 2025-05-22 15:10:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 15:10:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 15:10:03 --> Controller Class Initialized
INFO - 2025-05-22 15:10:03 --> Model "Timer_model" initialized
ERROR - 2025-05-22 15:10:03 --> Severity: error --> Exception: Too few arguments to function Timer::mulai_timer(), 0 passed in C:\laragon\www\Project\fitnessrecord\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\Project\fitnessrecord\application\controllers\Timer.php 56
INFO - 2025-05-22 15:10:05 --> Config Class Initialized
INFO - 2025-05-22 15:10:05 --> Hooks Class Initialized
DEBUG - 2025-05-22 15:10:05 --> UTF-8 Support Enabled
INFO - 2025-05-22 15:10:05 --> Utf8 Class Initialized
INFO - 2025-05-22 15:10:05 --> URI Class Initialized
INFO - 2025-05-22 15:10:05 --> Router Class Initialized
INFO - 2025-05-22 15:10:05 --> Output Class Initialized
INFO - 2025-05-22 15:10:05 --> Security Class Initialized
DEBUG - 2025-05-22 15:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 15:10:05 --> Input Class Initialized
INFO - 2025-05-22 15:10:05 --> Language Class Initialized
INFO - 2025-05-22 15:10:05 --> Loader Class Initialized
INFO - 2025-05-22 15:10:05 --> Helper loaded: url_helper
INFO - 2025-05-22 15:10:05 --> Helper loaded: form_helper
INFO - 2025-05-22 15:10:05 --> Database Driver Class Initialized
DEBUG - 2025-05-22 15:10:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 15:10:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 15:10:05 --> Controller Class Initialized
INFO - 2025-05-22 15:10:05 --> Model "Timer_model" initialized
ERROR - 2025-05-22 15:10:05 --> Severity: error --> Exception: Too few arguments to function Timer::mulai_timer(), 0 passed in C:\laragon\www\Project\fitnessrecord\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\Project\fitnessrecord\application\controllers\Timer.php 56
INFO - 2025-05-22 15:10:38 --> Config Class Initialized
INFO - 2025-05-22 15:10:38 --> Hooks Class Initialized
DEBUG - 2025-05-22 15:10:38 --> UTF-8 Support Enabled
INFO - 2025-05-22 15:10:38 --> Utf8 Class Initialized
INFO - 2025-05-22 15:10:38 --> URI Class Initialized
INFO - 2025-05-22 15:10:38 --> Router Class Initialized
INFO - 2025-05-22 15:10:38 --> Output Class Initialized
INFO - 2025-05-22 15:10:38 --> Security Class Initialized
DEBUG - 2025-05-22 15:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 15:10:38 --> Input Class Initialized
INFO - 2025-05-22 15:10:38 --> Language Class Initialized
INFO - 2025-05-22 15:10:38 --> Loader Class Initialized
INFO - 2025-05-22 15:10:38 --> Helper loaded: url_helper
INFO - 2025-05-22 15:10:38 --> Helper loaded: form_helper
INFO - 2025-05-22 15:10:38 --> Database Driver Class Initialized
DEBUG - 2025-05-22 15:10:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 15:10:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 15:10:38 --> Controller Class Initialized
INFO - 2025-05-22 15:10:38 --> Model "Timer_model" initialized
INFO - 2025-05-22 15:10:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\timer_view.php
INFO - 2025-05-22 15:10:38 --> Final output sent to browser
DEBUG - 2025-05-22 15:10:38 --> Total execution time: 0.0886
INFO - 2025-05-22 15:26:32 --> Config Class Initialized
INFO - 2025-05-22 15:26:32 --> Hooks Class Initialized
DEBUG - 2025-05-22 15:26:32 --> UTF-8 Support Enabled
INFO - 2025-05-22 15:26:32 --> Utf8 Class Initialized
INFO - 2025-05-22 15:26:32 --> URI Class Initialized
INFO - 2025-05-22 15:26:32 --> Router Class Initialized
INFO - 2025-05-22 15:26:32 --> Output Class Initialized
INFO - 2025-05-22 15:26:32 --> Security Class Initialized
DEBUG - 2025-05-22 15:26:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 15:26:32 --> Input Class Initialized
INFO - 2025-05-22 15:26:32 --> Language Class Initialized
INFO - 2025-05-22 15:26:32 --> Loader Class Initialized
INFO - 2025-05-22 15:26:32 --> Helper loaded: url_helper
INFO - 2025-05-22 15:26:32 --> Helper loaded: form_helper
INFO - 2025-05-22 15:26:32 --> Database Driver Class Initialized
DEBUG - 2025-05-22 15:26:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 15:26:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 15:26:32 --> Controller Class Initialized
INFO - 2025-05-22 15:26:32 --> Model "Timer_model" initialized
INFO - 2025-05-22 15:26:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\timer_view.php
INFO - 2025-05-22 15:26:32 --> Final output sent to browser
DEBUG - 2025-05-22 15:26:32 --> Total execution time: 0.0923
INFO - 2025-05-22 15:26:38 --> Config Class Initialized
INFO - 2025-05-22 15:26:38 --> Hooks Class Initialized
DEBUG - 2025-05-22 15:26:38 --> UTF-8 Support Enabled
INFO - 2025-05-22 15:26:38 --> Utf8 Class Initialized
INFO - 2025-05-22 15:26:38 --> URI Class Initialized
INFO - 2025-05-22 15:26:38 --> Router Class Initialized
INFO - 2025-05-22 15:26:38 --> Output Class Initialized
INFO - 2025-05-22 15:26:38 --> Security Class Initialized
DEBUG - 2025-05-22 15:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 15:26:38 --> Input Class Initialized
INFO - 2025-05-22 15:26:38 --> Language Class Initialized
INFO - 2025-05-22 15:26:38 --> Loader Class Initialized
INFO - 2025-05-22 15:26:38 --> Helper loaded: url_helper
INFO - 2025-05-22 15:26:38 --> Helper loaded: form_helper
INFO - 2025-05-22 15:26:38 --> Database Driver Class Initialized
DEBUG - 2025-05-22 15:26:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 15:26:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 15:26:38 --> Controller Class Initialized
INFO - 2025-05-22 15:26:38 --> Model "Timer_model" initialized
ERROR - 2025-05-22 15:26:38 --> Severity: error --> Exception: Too few arguments to function Timer::mulai_timer(), 0 passed in C:\laragon\www\Project\fitnessrecord\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\Project\fitnessrecord\application\controllers\Timer.php 56
INFO - 2025-05-22 15:27:48 --> Config Class Initialized
INFO - 2025-05-22 15:27:48 --> Hooks Class Initialized
DEBUG - 2025-05-22 15:27:48 --> UTF-8 Support Enabled
INFO - 2025-05-22 15:27:48 --> Utf8 Class Initialized
INFO - 2025-05-22 15:27:48 --> URI Class Initialized
INFO - 2025-05-22 15:27:48 --> Router Class Initialized
INFO - 2025-05-22 15:27:48 --> Output Class Initialized
INFO - 2025-05-22 15:27:48 --> Security Class Initialized
DEBUG - 2025-05-22 15:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 15:27:48 --> Input Class Initialized
INFO - 2025-05-22 15:27:48 --> Language Class Initialized
INFO - 2025-05-22 15:27:48 --> Loader Class Initialized
INFO - 2025-05-22 15:27:48 --> Helper loaded: url_helper
INFO - 2025-05-22 15:27:48 --> Helper loaded: form_helper
INFO - 2025-05-22 15:27:48 --> Database Driver Class Initialized
DEBUG - 2025-05-22 15:27:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 15:27:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 15:27:48 --> Controller Class Initialized
INFO - 2025-05-22 15:27:48 --> Model "Timer_model" initialized
INFO - 2025-05-22 15:27:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\timer_view.php
INFO - 2025-05-22 15:27:48 --> Final output sent to browser
DEBUG - 2025-05-22 15:27:48 --> Total execution time: 0.0895
INFO - 2025-05-22 15:30:15 --> Config Class Initialized
INFO - 2025-05-22 15:30:15 --> Hooks Class Initialized
DEBUG - 2025-05-22 15:30:15 --> UTF-8 Support Enabled
INFO - 2025-05-22 15:30:15 --> Utf8 Class Initialized
INFO - 2025-05-22 15:30:15 --> URI Class Initialized
INFO - 2025-05-22 15:30:15 --> Router Class Initialized
INFO - 2025-05-22 15:30:15 --> Output Class Initialized
INFO - 2025-05-22 15:30:15 --> Security Class Initialized
DEBUG - 2025-05-22 15:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 15:30:15 --> Input Class Initialized
INFO - 2025-05-22 15:30:15 --> Language Class Initialized
INFO - 2025-05-22 15:30:15 --> Loader Class Initialized
INFO - 2025-05-22 15:30:15 --> Helper loaded: url_helper
INFO - 2025-05-22 15:30:15 --> Helper loaded: form_helper
INFO - 2025-05-22 15:30:15 --> Database Driver Class Initialized
DEBUG - 2025-05-22 15:30:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 15:30:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 15:30:15 --> Controller Class Initialized
INFO - 2025-05-22 15:30:15 --> Model "Timer_model" initialized
INFO - 2025-05-22 15:30:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\timer_view.php
INFO - 2025-05-22 15:30:15 --> Final output sent to browser
DEBUG - 2025-05-22 15:30:15 --> Total execution time: 0.0756
INFO - 2025-05-22 15:30:21 --> Config Class Initialized
INFO - 2025-05-22 15:30:21 --> Hooks Class Initialized
DEBUG - 2025-05-22 15:30:21 --> UTF-8 Support Enabled
INFO - 2025-05-22 15:30:21 --> Utf8 Class Initialized
INFO - 2025-05-22 15:30:21 --> URI Class Initialized
INFO - 2025-05-22 15:30:21 --> Router Class Initialized
INFO - 2025-05-22 15:30:21 --> Output Class Initialized
INFO - 2025-05-22 15:30:21 --> Security Class Initialized
DEBUG - 2025-05-22 15:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 15:30:21 --> Input Class Initialized
INFO - 2025-05-22 15:30:21 --> Language Class Initialized
INFO - 2025-05-22 15:30:21 --> Loader Class Initialized
INFO - 2025-05-22 15:30:21 --> Helper loaded: url_helper
INFO - 2025-05-22 15:30:21 --> Helper loaded: form_helper
INFO - 2025-05-22 15:30:21 --> Database Driver Class Initialized
DEBUG - 2025-05-22 15:30:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 15:30:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 15:30:21 --> Controller Class Initialized
INFO - 2025-05-22 15:30:21 --> Model "Timer_model" initialized
ERROR - 2025-05-22 15:30:21 --> Query error: Table 'fitnessrec.activity' doesn't exist - Invalid query: SELECT *
FROM `activity`
WHERE `id` = '8'
INFO - 2025-05-22 15:30:21 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-22 15:35:05 --> Config Class Initialized
INFO - 2025-05-22 15:35:05 --> Hooks Class Initialized
DEBUG - 2025-05-22 15:35:05 --> UTF-8 Support Enabled
INFO - 2025-05-22 15:35:05 --> Utf8 Class Initialized
INFO - 2025-05-22 15:35:05 --> URI Class Initialized
INFO - 2025-05-22 15:35:05 --> Router Class Initialized
INFO - 2025-05-22 15:35:05 --> Output Class Initialized
INFO - 2025-05-22 15:35:05 --> Security Class Initialized
DEBUG - 2025-05-22 15:35:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 15:35:05 --> Input Class Initialized
INFO - 2025-05-22 15:35:05 --> Language Class Initialized
INFO - 2025-05-22 15:35:05 --> Loader Class Initialized
INFO - 2025-05-22 15:35:05 --> Helper loaded: url_helper
INFO - 2025-05-22 15:35:05 --> Helper loaded: form_helper
INFO - 2025-05-22 15:35:05 --> Database Driver Class Initialized
DEBUG - 2025-05-22 15:35:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 15:35:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 15:35:05 --> Controller Class Initialized
INFO - 2025-05-22 15:35:05 --> Model "Timer_model" initialized
INFO - 2025-05-22 15:35:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\timer_view.php
INFO - 2025-05-22 15:35:05 --> Final output sent to browser
DEBUG - 2025-05-22 15:35:05 --> Total execution time: 0.0880
INFO - 2025-05-22 15:35:17 --> Config Class Initialized
INFO - 2025-05-22 15:35:17 --> Hooks Class Initialized
DEBUG - 2025-05-22 15:35:17 --> UTF-8 Support Enabled
INFO - 2025-05-22 15:35:17 --> Utf8 Class Initialized
INFO - 2025-05-22 15:35:17 --> URI Class Initialized
INFO - 2025-05-22 15:35:17 --> Router Class Initialized
INFO - 2025-05-22 15:35:17 --> Output Class Initialized
INFO - 2025-05-22 15:35:17 --> Security Class Initialized
DEBUG - 2025-05-22 15:35:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 15:35:17 --> Input Class Initialized
INFO - 2025-05-22 15:35:17 --> Language Class Initialized
INFO - 2025-05-22 15:35:17 --> Loader Class Initialized
INFO - 2025-05-22 15:35:17 --> Helper loaded: url_helper
INFO - 2025-05-22 15:35:17 --> Helper loaded: form_helper
INFO - 2025-05-22 15:35:17 --> Database Driver Class Initialized
DEBUG - 2025-05-22 15:35:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 15:35:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 15:35:17 --> Controller Class Initialized
INFO - 2025-05-22 15:35:17 --> Model "Timer_model" initialized
ERROR - 2025-05-22 15:35:17 --> Query error: Table 'fitnessrec.activity' doesn't exist - Invalid query: SELECT *
FROM `activity`
WHERE `id` = '9'
INFO - 2025-05-22 15:35:17 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-22 15:35:18 --> Config Class Initialized
INFO - 2025-05-22 15:35:18 --> Hooks Class Initialized
DEBUG - 2025-05-22 15:35:18 --> UTF-8 Support Enabled
INFO - 2025-05-22 15:35:18 --> Utf8 Class Initialized
INFO - 2025-05-22 15:35:18 --> URI Class Initialized
INFO - 2025-05-22 15:35:18 --> Router Class Initialized
INFO - 2025-05-22 15:35:18 --> Output Class Initialized
INFO - 2025-05-22 15:35:18 --> Security Class Initialized
DEBUG - 2025-05-22 15:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 15:35:18 --> Input Class Initialized
INFO - 2025-05-22 15:35:18 --> Language Class Initialized
INFO - 2025-05-22 15:35:18 --> Loader Class Initialized
INFO - 2025-05-22 15:35:18 --> Helper loaded: url_helper
INFO - 2025-05-22 15:35:18 --> Helper loaded: form_helper
INFO - 2025-05-22 15:35:18 --> Database Driver Class Initialized
DEBUG - 2025-05-22 15:35:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 15:35:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 15:35:18 --> Controller Class Initialized
INFO - 2025-05-22 15:35:18 --> Model "Timer_model" initialized
ERROR - 2025-05-22 15:35:18 --> Query error: Table 'fitnessrec.activity' doesn't exist - Invalid query: SELECT *
FROM `activity`
WHERE `id` = '9'
INFO - 2025-05-22 15:35:18 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-22 15:42:45 --> Config Class Initialized
INFO - 2025-05-22 15:42:45 --> Hooks Class Initialized
DEBUG - 2025-05-22 15:42:45 --> UTF-8 Support Enabled
INFO - 2025-05-22 15:42:45 --> Utf8 Class Initialized
INFO - 2025-05-22 15:42:45 --> URI Class Initialized
INFO - 2025-05-22 15:42:45 --> Router Class Initialized
INFO - 2025-05-22 15:42:45 --> Output Class Initialized
INFO - 2025-05-22 15:42:45 --> Security Class Initialized
DEBUG - 2025-05-22 15:42:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 15:42:45 --> Input Class Initialized
INFO - 2025-05-22 15:42:45 --> Language Class Initialized
INFO - 2025-05-22 15:42:45 --> Loader Class Initialized
INFO - 2025-05-22 15:42:45 --> Helper loaded: url_helper
INFO - 2025-05-22 15:42:45 --> Helper loaded: form_helper
INFO - 2025-05-22 15:42:45 --> Database Driver Class Initialized
DEBUG - 2025-05-22 15:42:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 15:42:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 15:42:45 --> Controller Class Initialized
INFO - 2025-05-22 15:42:45 --> Model "Timer_model" initialized
ERROR - 2025-05-22 15:42:45 --> Query error: Table 'fitnessrec.activity' doesn't exist - Invalid query: SELECT *
FROM `activity`
WHERE `id` = '9'
INFO - 2025-05-22 15:42:45 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-22 15:42:46 --> Config Class Initialized
INFO - 2025-05-22 15:42:46 --> Hooks Class Initialized
DEBUG - 2025-05-22 15:42:46 --> UTF-8 Support Enabled
INFO - 2025-05-22 15:42:46 --> Utf8 Class Initialized
INFO - 2025-05-22 15:42:46 --> URI Class Initialized
INFO - 2025-05-22 15:42:46 --> Router Class Initialized
INFO - 2025-05-22 15:42:46 --> Output Class Initialized
INFO - 2025-05-22 15:42:46 --> Security Class Initialized
DEBUG - 2025-05-22 15:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 15:42:46 --> Input Class Initialized
INFO - 2025-05-22 15:42:46 --> Language Class Initialized
INFO - 2025-05-22 15:42:46 --> Loader Class Initialized
INFO - 2025-05-22 15:42:46 --> Helper loaded: url_helper
INFO - 2025-05-22 15:42:46 --> Helper loaded: form_helper
INFO - 2025-05-22 15:42:46 --> Database Driver Class Initialized
DEBUG - 2025-05-22 15:42:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 15:42:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 15:42:46 --> Controller Class Initialized
INFO - 2025-05-22 15:42:46 --> Model "Timer_model" initialized
ERROR - 2025-05-22 15:42:46 --> Query error: Table 'fitnessrec.activity' doesn't exist - Invalid query: SELECT *
FROM `activity`
WHERE `id` = '9'
INFO - 2025-05-22 15:42:46 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-22 15:42:46 --> Config Class Initialized
INFO - 2025-05-22 15:42:46 --> Hooks Class Initialized
DEBUG - 2025-05-22 15:42:46 --> UTF-8 Support Enabled
INFO - 2025-05-22 15:42:46 --> Utf8 Class Initialized
INFO - 2025-05-22 15:42:46 --> URI Class Initialized
INFO - 2025-05-22 15:42:46 --> Router Class Initialized
INFO - 2025-05-22 15:42:46 --> Output Class Initialized
INFO - 2025-05-22 15:42:46 --> Security Class Initialized
DEBUG - 2025-05-22 15:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 15:42:46 --> Input Class Initialized
INFO - 2025-05-22 15:42:46 --> Language Class Initialized
INFO - 2025-05-22 15:42:46 --> Loader Class Initialized
INFO - 2025-05-22 15:42:46 --> Helper loaded: url_helper
INFO - 2025-05-22 15:42:46 --> Helper loaded: form_helper
INFO - 2025-05-22 15:42:46 --> Database Driver Class Initialized
DEBUG - 2025-05-22 15:42:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 15:42:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 15:42:46 --> Controller Class Initialized
INFO - 2025-05-22 15:42:46 --> Model "Timer_model" initialized
ERROR - 2025-05-22 15:42:46 --> Query error: Table 'fitnessrec.activity' doesn't exist - Invalid query: SELECT *
FROM `activity`
WHERE `id` = '9'
INFO - 2025-05-22 15:42:46 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-22 15:42:46 --> Config Class Initialized
INFO - 2025-05-22 15:42:46 --> Hooks Class Initialized
DEBUG - 2025-05-22 15:42:46 --> UTF-8 Support Enabled
INFO - 2025-05-22 15:42:46 --> Utf8 Class Initialized
INFO - 2025-05-22 15:42:46 --> URI Class Initialized
INFO - 2025-05-22 15:42:46 --> Router Class Initialized
INFO - 2025-05-22 15:42:46 --> Output Class Initialized
INFO - 2025-05-22 15:42:46 --> Security Class Initialized
DEBUG - 2025-05-22 15:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 15:42:46 --> Input Class Initialized
INFO - 2025-05-22 15:42:46 --> Language Class Initialized
INFO - 2025-05-22 15:42:46 --> Loader Class Initialized
INFO - 2025-05-22 15:42:46 --> Helper loaded: url_helper
INFO - 2025-05-22 15:42:46 --> Helper loaded: form_helper
INFO - 2025-05-22 15:42:46 --> Database Driver Class Initialized
DEBUG - 2025-05-22 15:42:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 15:42:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 15:42:46 --> Controller Class Initialized
INFO - 2025-05-22 15:42:46 --> Model "Timer_model" initialized
ERROR - 2025-05-22 15:42:46 --> Query error: Table 'fitnessrec.activity' doesn't exist - Invalid query: SELECT *
FROM `activity`
WHERE `id` = '9'
INFO - 2025-05-22 15:42:46 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-22 15:42:47 --> Config Class Initialized
INFO - 2025-05-22 15:42:47 --> Hooks Class Initialized
DEBUG - 2025-05-22 15:42:47 --> UTF-8 Support Enabled
INFO - 2025-05-22 15:42:47 --> Utf8 Class Initialized
INFO - 2025-05-22 15:42:47 --> URI Class Initialized
INFO - 2025-05-22 15:42:47 --> Router Class Initialized
INFO - 2025-05-22 15:42:47 --> Output Class Initialized
INFO - 2025-05-22 15:42:47 --> Security Class Initialized
DEBUG - 2025-05-22 15:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 15:42:47 --> Input Class Initialized
INFO - 2025-05-22 15:42:47 --> Language Class Initialized
INFO - 2025-05-22 15:42:47 --> Loader Class Initialized
INFO - 2025-05-22 15:42:47 --> Helper loaded: url_helper
INFO - 2025-05-22 15:42:47 --> Helper loaded: form_helper
INFO - 2025-05-22 15:42:47 --> Database Driver Class Initialized
DEBUG - 2025-05-22 15:42:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 15:42:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 15:42:47 --> Controller Class Initialized
INFO - 2025-05-22 15:42:47 --> Model "Timer_model" initialized
ERROR - 2025-05-22 15:42:47 --> Query error: Table 'fitnessrec.activity' doesn't exist - Invalid query: SELECT *
FROM `activity`
WHERE `id` = '9'
INFO - 2025-05-22 15:42:47 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-22 15:42:47 --> Config Class Initialized
INFO - 2025-05-22 15:42:47 --> Hooks Class Initialized
DEBUG - 2025-05-22 15:42:47 --> UTF-8 Support Enabled
INFO - 2025-05-22 15:42:47 --> Utf8 Class Initialized
INFO - 2025-05-22 15:42:47 --> URI Class Initialized
INFO - 2025-05-22 15:42:47 --> Router Class Initialized
INFO - 2025-05-22 15:42:47 --> Output Class Initialized
INFO - 2025-05-22 15:42:47 --> Security Class Initialized
DEBUG - 2025-05-22 15:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 15:42:47 --> Input Class Initialized
INFO - 2025-05-22 15:42:47 --> Language Class Initialized
INFO - 2025-05-22 15:42:47 --> Loader Class Initialized
INFO - 2025-05-22 15:42:47 --> Helper loaded: url_helper
INFO - 2025-05-22 15:42:47 --> Helper loaded: form_helper
INFO - 2025-05-22 15:42:47 --> Database Driver Class Initialized
DEBUG - 2025-05-22 15:42:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 15:42:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 15:42:47 --> Controller Class Initialized
INFO - 2025-05-22 15:42:47 --> Model "Timer_model" initialized
ERROR - 2025-05-22 15:42:47 --> Query error: Table 'fitnessrec.activity' doesn't exist - Invalid query: SELECT *
FROM `activity`
WHERE `id` = '9'
INFO - 2025-05-22 15:42:47 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-22 15:47:00 --> Config Class Initialized
INFO - 2025-05-22 15:47:00 --> Hooks Class Initialized
DEBUG - 2025-05-22 15:47:00 --> UTF-8 Support Enabled
INFO - 2025-05-22 15:47:00 --> Utf8 Class Initialized
INFO - 2025-05-22 15:47:00 --> URI Class Initialized
INFO - 2025-05-22 15:47:00 --> Router Class Initialized
INFO - 2025-05-22 15:47:00 --> Output Class Initialized
INFO - 2025-05-22 15:47:00 --> Security Class Initialized
DEBUG - 2025-05-22 15:47:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 15:47:00 --> Input Class Initialized
INFO - 2025-05-22 15:47:00 --> Language Class Initialized
INFO - 2025-05-22 15:47:00 --> Loader Class Initialized
INFO - 2025-05-22 15:47:00 --> Helper loaded: url_helper
INFO - 2025-05-22 15:47:00 --> Helper loaded: form_helper
INFO - 2025-05-22 15:47:00 --> Database Driver Class Initialized
DEBUG - 2025-05-22 15:47:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 15:47:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 15:47:00 --> Controller Class Initialized
INFO - 2025-05-22 15:47:00 --> Model "Timer_model" initialized
INFO - 2025-05-22 15:47:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\timer_view.php
INFO - 2025-05-22 15:47:00 --> Final output sent to browser
DEBUG - 2025-05-22 15:47:00 --> Total execution time: 0.0633
INFO - 2025-05-22 15:47:35 --> Config Class Initialized
INFO - 2025-05-22 15:47:35 --> Hooks Class Initialized
DEBUG - 2025-05-22 15:47:35 --> UTF-8 Support Enabled
INFO - 2025-05-22 15:47:35 --> Utf8 Class Initialized
INFO - 2025-05-22 15:47:35 --> URI Class Initialized
INFO - 2025-05-22 15:47:35 --> Router Class Initialized
INFO - 2025-05-22 15:47:35 --> Output Class Initialized
INFO - 2025-05-22 15:47:35 --> Security Class Initialized
DEBUG - 2025-05-22 15:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 15:47:35 --> Input Class Initialized
INFO - 2025-05-22 15:47:35 --> Language Class Initialized
INFO - 2025-05-22 15:47:35 --> Loader Class Initialized
INFO - 2025-05-22 15:47:35 --> Helper loaded: url_helper
INFO - 2025-05-22 15:47:35 --> Helper loaded: form_helper
INFO - 2025-05-22 15:47:35 --> Database Driver Class Initialized
DEBUG - 2025-05-22 15:47:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 15:47:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 15:47:35 --> Controller Class Initialized
INFO - 2025-05-22 15:47:35 --> Model "Timer_model" initialized
INFO - 2025-05-22 15:47:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\timer_view.php
INFO - 2025-05-22 15:47:35 --> Final output sent to browser
DEBUG - 2025-05-22 15:47:35 --> Total execution time: 0.0931
INFO - 2025-05-22 15:47:39 --> Config Class Initialized
INFO - 2025-05-22 15:47:39 --> Hooks Class Initialized
DEBUG - 2025-05-22 15:47:39 --> UTF-8 Support Enabled
INFO - 2025-05-22 15:47:39 --> Utf8 Class Initialized
INFO - 2025-05-22 15:47:39 --> URI Class Initialized
INFO - 2025-05-22 15:47:39 --> Router Class Initialized
INFO - 2025-05-22 15:47:39 --> Output Class Initialized
INFO - 2025-05-22 15:47:39 --> Security Class Initialized
DEBUG - 2025-05-22 15:47:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 15:47:39 --> Input Class Initialized
INFO - 2025-05-22 15:47:39 --> Language Class Initialized
INFO - 2025-05-22 15:47:39 --> Loader Class Initialized
INFO - 2025-05-22 15:47:39 --> Helper loaded: url_helper
INFO - 2025-05-22 15:47:39 --> Helper loaded: form_helper
INFO - 2025-05-22 15:47:39 --> Database Driver Class Initialized
DEBUG - 2025-05-22 15:47:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 15:47:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 15:47:39 --> Controller Class Initialized
INFO - 2025-05-22 15:47:39 --> Model "Timer_model" initialized
INFO - 2025-05-22 15:47:39 --> Final output sent to browser
DEBUG - 2025-05-22 15:47:39 --> Total execution time: 0.0669
INFO - 2025-05-22 15:47:40 --> Config Class Initialized
INFO - 2025-05-22 15:47:40 --> Hooks Class Initialized
DEBUG - 2025-05-22 15:47:40 --> UTF-8 Support Enabled
INFO - 2025-05-22 15:47:40 --> Utf8 Class Initialized
INFO - 2025-05-22 15:47:40 --> URI Class Initialized
INFO - 2025-05-22 15:47:40 --> Router Class Initialized
INFO - 2025-05-22 15:47:40 --> Output Class Initialized
INFO - 2025-05-22 15:47:40 --> Security Class Initialized
DEBUG - 2025-05-22 15:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 15:47:40 --> Input Class Initialized
INFO - 2025-05-22 15:47:40 --> Language Class Initialized
INFO - 2025-05-22 15:47:40 --> Loader Class Initialized
INFO - 2025-05-22 15:47:40 --> Helper loaded: url_helper
INFO - 2025-05-22 15:47:40 --> Helper loaded: form_helper
INFO - 2025-05-22 15:47:40 --> Database Driver Class Initialized
DEBUG - 2025-05-22 15:47:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 15:47:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 15:47:40 --> Controller Class Initialized
INFO - 2025-05-22 15:47:40 --> Model "Timer_model" initialized
INFO - 2025-05-22 15:47:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\timer_view.php
INFO - 2025-05-22 15:47:40 --> Final output sent to browser
DEBUG - 2025-05-22 15:47:40 --> Total execution time: 0.0711
INFO - 2025-05-22 15:47:46 --> Config Class Initialized
INFO - 2025-05-22 15:47:46 --> Hooks Class Initialized
DEBUG - 2025-05-22 15:47:46 --> UTF-8 Support Enabled
INFO - 2025-05-22 15:47:46 --> Utf8 Class Initialized
INFO - 2025-05-22 15:47:46 --> URI Class Initialized
INFO - 2025-05-22 15:47:46 --> Router Class Initialized
INFO - 2025-05-22 15:47:46 --> Output Class Initialized
INFO - 2025-05-22 15:47:46 --> Security Class Initialized
DEBUG - 2025-05-22 15:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 15:47:46 --> Input Class Initialized
INFO - 2025-05-22 15:47:46 --> Language Class Initialized
INFO - 2025-05-22 15:47:46 --> Loader Class Initialized
INFO - 2025-05-22 15:47:46 --> Helper loaded: url_helper
INFO - 2025-05-22 15:47:46 --> Helper loaded: form_helper
INFO - 2025-05-22 15:47:46 --> Database Driver Class Initialized
DEBUG - 2025-05-22 15:47:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 15:47:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 15:47:46 --> Controller Class Initialized
INFO - 2025-05-22 15:47:46 --> Model "Progress_model" initialized
INFO - 2025-05-22 15:47:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\progress_view.php
INFO - 2025-05-22 15:47:46 --> Final output sent to browser
DEBUG - 2025-05-22 15:47:46 --> Total execution time: 0.1024
INFO - 2025-05-22 15:47:46 --> Config Class Initialized
INFO - 2025-05-22 15:47:46 --> Hooks Class Initialized
DEBUG - 2025-05-22 15:47:46 --> UTF-8 Support Enabled
INFO - 2025-05-22 15:47:46 --> Utf8 Class Initialized
INFO - 2025-05-22 15:47:46 --> URI Class Initialized
INFO - 2025-05-22 15:47:46 --> Router Class Initialized
INFO - 2025-05-22 15:47:46 --> Output Class Initialized
INFO - 2025-05-22 15:47:46 --> Security Class Initialized
DEBUG - 2025-05-22 15:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 15:47:46 --> Input Class Initialized
INFO - 2025-05-22 15:47:46 --> Language Class Initialized
INFO - 2025-05-22 15:47:46 --> Loader Class Initialized
INFO - 2025-05-22 15:47:46 --> Helper loaded: url_helper
INFO - 2025-05-22 15:47:46 --> Helper loaded: form_helper
INFO - 2025-05-22 15:47:46 --> Database Driver Class Initialized
DEBUG - 2025-05-22 15:47:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 15:47:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 15:47:46 --> Controller Class Initialized
INFO - 2025-05-22 15:47:46 --> Model "Progress_model" initialized
INFO - 2025-05-22 15:47:46 --> Final output sent to browser
DEBUG - 2025-05-22 15:47:46 --> Total execution time: 0.1515
INFO - 2025-05-22 15:47:49 --> Config Class Initialized
INFO - 2025-05-22 15:47:49 --> Hooks Class Initialized
DEBUG - 2025-05-22 15:47:49 --> UTF-8 Support Enabled
INFO - 2025-05-22 15:47:49 --> Utf8 Class Initialized
INFO - 2025-05-22 15:47:49 --> URI Class Initialized
INFO - 2025-05-22 15:47:49 --> Router Class Initialized
INFO - 2025-05-22 15:47:49 --> Output Class Initialized
INFO - 2025-05-22 15:47:49 --> Security Class Initialized
DEBUG - 2025-05-22 15:47:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 15:47:49 --> Input Class Initialized
INFO - 2025-05-22 15:47:49 --> Language Class Initialized
INFO - 2025-05-22 15:47:49 --> Loader Class Initialized
INFO - 2025-05-22 15:47:49 --> Helper loaded: url_helper
INFO - 2025-05-22 15:47:49 --> Helper loaded: form_helper
INFO - 2025-05-22 15:47:49 --> Database Driver Class Initialized
DEBUG - 2025-05-22 15:47:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 15:47:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 15:47:49 --> Controller Class Initialized
INFO - 2025-05-22 15:47:49 --> Model "Progress_model" initialized
INFO - 2025-05-22 15:47:49 --> Final output sent to browser
DEBUG - 2025-05-22 15:47:49 --> Total execution time: 0.0588
INFO - 2025-05-22 15:47:52 --> Config Class Initialized
INFO - 2025-05-22 15:47:52 --> Hooks Class Initialized
DEBUG - 2025-05-22 15:47:52 --> UTF-8 Support Enabled
INFO - 2025-05-22 15:47:52 --> Utf8 Class Initialized
INFO - 2025-05-22 15:47:52 --> URI Class Initialized
INFO - 2025-05-22 15:47:52 --> Router Class Initialized
INFO - 2025-05-22 15:47:52 --> Output Class Initialized
INFO - 2025-05-22 15:47:52 --> Security Class Initialized
DEBUG - 2025-05-22 15:47:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 15:47:52 --> Input Class Initialized
INFO - 2025-05-22 15:47:52 --> Language Class Initialized
INFO - 2025-05-22 15:47:52 --> Loader Class Initialized
INFO - 2025-05-22 15:47:52 --> Helper loaded: url_helper
INFO - 2025-05-22 15:47:52 --> Helper loaded: form_helper
INFO - 2025-05-22 15:47:52 --> Database Driver Class Initialized
DEBUG - 2025-05-22 15:47:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 15:47:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 15:47:52 --> Controller Class Initialized
INFO - 2025-05-22 15:47:52 --> Model "Progress_model" initialized
INFO - 2025-05-22 15:47:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\progress_view.php
INFO - 2025-05-22 15:47:52 --> Final output sent to browser
DEBUG - 2025-05-22 15:47:52 --> Total execution time: 0.0862
INFO - 2025-05-22 15:47:52 --> Config Class Initialized
INFO - 2025-05-22 15:47:52 --> Hooks Class Initialized
DEBUG - 2025-05-22 15:47:52 --> UTF-8 Support Enabled
INFO - 2025-05-22 15:47:52 --> Utf8 Class Initialized
INFO - 2025-05-22 15:47:52 --> URI Class Initialized
INFO - 2025-05-22 15:47:52 --> Router Class Initialized
INFO - 2025-05-22 15:47:52 --> Output Class Initialized
INFO - 2025-05-22 15:47:52 --> Security Class Initialized
DEBUG - 2025-05-22 15:47:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 15:47:52 --> Input Class Initialized
INFO - 2025-05-22 15:47:52 --> Language Class Initialized
INFO - 2025-05-22 15:47:52 --> Loader Class Initialized
INFO - 2025-05-22 15:47:52 --> Helper loaded: url_helper
INFO - 2025-05-22 15:47:52 --> Helper loaded: form_helper
INFO - 2025-05-22 15:47:52 --> Database Driver Class Initialized
DEBUG - 2025-05-22 15:47:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 15:47:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 15:47:52 --> Controller Class Initialized
INFO - 2025-05-22 15:47:52 --> Model "Progress_model" initialized
INFO - 2025-05-22 15:47:52 --> Final output sent to browser
DEBUG - 2025-05-22 15:47:52 --> Total execution time: 0.0814
INFO - 2025-05-22 15:49:35 --> Config Class Initialized
INFO - 2025-05-22 15:49:35 --> Hooks Class Initialized
DEBUG - 2025-05-22 15:49:35 --> UTF-8 Support Enabled
INFO - 2025-05-22 15:49:35 --> Utf8 Class Initialized
INFO - 2025-05-22 15:49:35 --> URI Class Initialized
INFO - 2025-05-22 15:49:35 --> Router Class Initialized
INFO - 2025-05-22 15:49:35 --> Output Class Initialized
INFO - 2025-05-22 15:49:35 --> Security Class Initialized
DEBUG - 2025-05-22 15:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 15:49:35 --> Input Class Initialized
INFO - 2025-05-22 15:49:35 --> Language Class Initialized
INFO - 2025-05-22 15:49:35 --> Loader Class Initialized
INFO - 2025-05-22 15:49:35 --> Helper loaded: url_helper
INFO - 2025-05-22 15:49:35 --> Helper loaded: form_helper
INFO - 2025-05-22 15:49:35 --> Database Driver Class Initialized
DEBUG - 2025-05-22 15:49:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 15:49:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 15:49:35 --> Controller Class Initialized
INFO - 2025-05-22 15:49:35 --> Model "Progress_model" initialized
INFO - 2025-05-22 15:49:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\progress_view.php
INFO - 2025-05-22 15:49:35 --> Final output sent to browser
DEBUG - 2025-05-22 15:49:35 --> Total execution time: 0.0628
INFO - 2025-05-22 15:49:35 --> Config Class Initialized
INFO - 2025-05-22 15:49:35 --> Hooks Class Initialized
DEBUG - 2025-05-22 15:49:35 --> UTF-8 Support Enabled
INFO - 2025-05-22 15:49:35 --> Utf8 Class Initialized
INFO - 2025-05-22 15:49:35 --> URI Class Initialized
INFO - 2025-05-22 15:49:35 --> Router Class Initialized
INFO - 2025-05-22 15:49:35 --> Output Class Initialized
INFO - 2025-05-22 15:49:35 --> Security Class Initialized
DEBUG - 2025-05-22 15:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 15:49:35 --> Input Class Initialized
INFO - 2025-05-22 15:49:35 --> Language Class Initialized
INFO - 2025-05-22 15:49:35 --> Loader Class Initialized
INFO - 2025-05-22 15:49:35 --> Helper loaded: url_helper
INFO - 2025-05-22 15:49:35 --> Helper loaded: form_helper
INFO - 2025-05-22 15:49:35 --> Database Driver Class Initialized
DEBUG - 2025-05-22 15:49:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 15:49:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 15:49:35 --> Controller Class Initialized
INFO - 2025-05-22 15:49:35 --> Model "Progress_model" initialized
ERROR - 2025-05-22 15:49:35 --> Severity: Warning --> Undefined property: stdClass::$level C:\laragon\www\Project\fitnessrecord\application\models\Progress_model.php 16
ERROR - 2025-05-22 15:49:35 --> Severity: 8192 --> ucfirst(): Passing null to parameter #1 ($string) of type string is deprecated C:\laragon\www\Project\fitnessrecord\application\models\Progress_model.php 16
ERROR - 2025-05-22 15:49:35 --> Severity: Warning --> Undefined property: stdClass::$level C:\laragon\www\Project\fitnessrecord\application\models\Progress_model.php 16
ERROR - 2025-05-22 15:49:35 --> Severity: 8192 --> ucfirst(): Passing null to parameter #1 ($string) of type string is deprecated C:\laragon\www\Project\fitnessrecord\application\models\Progress_model.php 16
ERROR - 2025-05-22 15:49:35 --> Severity: Warning --> Undefined property: stdClass::$level C:\laragon\www\Project\fitnessrecord\application\models\Progress_model.php 16
ERROR - 2025-05-22 15:49:35 --> Severity: 8192 --> ucfirst(): Passing null to parameter #1 ($string) of type string is deprecated C:\laragon\www\Project\fitnessrecord\application\models\Progress_model.php 16
ERROR - 2025-05-22 15:49:35 --> Severity: Warning --> Undefined property: stdClass::$level C:\laragon\www\Project\fitnessrecord\application\models\Progress_model.php 16
ERROR - 2025-05-22 15:49:35 --> Severity: 8192 --> ucfirst(): Passing null to parameter #1 ($string) of type string is deprecated C:\laragon\www\Project\fitnessrecord\application\models\Progress_model.php 16
INFO - 2025-05-22 15:49:35 --> Final output sent to browser
DEBUG - 2025-05-22 15:49:35 --> Total execution time: 0.1123
INFO - 2025-05-22 15:51:06 --> Config Class Initialized
INFO - 2025-05-22 15:51:06 --> Hooks Class Initialized
DEBUG - 2025-05-22 15:51:06 --> UTF-8 Support Enabled
INFO - 2025-05-22 15:51:06 --> Utf8 Class Initialized
INFO - 2025-05-22 15:51:06 --> URI Class Initialized
INFO - 2025-05-22 15:51:06 --> Router Class Initialized
INFO - 2025-05-22 15:51:06 --> Output Class Initialized
INFO - 2025-05-22 15:51:06 --> Security Class Initialized
DEBUG - 2025-05-22 15:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 15:51:06 --> Input Class Initialized
INFO - 2025-05-22 15:51:06 --> Language Class Initialized
INFO - 2025-05-22 15:51:06 --> Loader Class Initialized
INFO - 2025-05-22 15:51:06 --> Helper loaded: url_helper
INFO - 2025-05-22 15:51:06 --> Helper loaded: form_helper
INFO - 2025-05-22 15:51:06 --> Database Driver Class Initialized
DEBUG - 2025-05-22 15:51:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 15:51:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 15:51:06 --> Controller Class Initialized
INFO - 2025-05-22 15:51:06 --> Model "Progress_model" initialized
INFO - 2025-05-22 15:51:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\progress_view.php
INFO - 2025-05-22 15:51:06 --> Final output sent to browser
DEBUG - 2025-05-22 15:51:06 --> Total execution time: 0.0645
INFO - 2025-05-22 15:51:06 --> Config Class Initialized
INFO - 2025-05-22 15:51:06 --> Hooks Class Initialized
DEBUG - 2025-05-22 15:51:06 --> UTF-8 Support Enabled
INFO - 2025-05-22 15:51:06 --> Utf8 Class Initialized
INFO - 2025-05-22 15:51:06 --> URI Class Initialized
INFO - 2025-05-22 15:51:06 --> Router Class Initialized
INFO - 2025-05-22 15:51:06 --> Output Class Initialized
INFO - 2025-05-22 15:51:06 --> Security Class Initialized
DEBUG - 2025-05-22 15:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 15:51:06 --> Input Class Initialized
INFO - 2025-05-22 15:51:06 --> Language Class Initialized
INFO - 2025-05-22 15:51:06 --> Loader Class Initialized
INFO - 2025-05-22 15:51:06 --> Helper loaded: url_helper
INFO - 2025-05-22 15:51:06 --> Helper loaded: form_helper
INFO - 2025-05-22 15:51:06 --> Database Driver Class Initialized
DEBUG - 2025-05-22 15:51:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 15:51:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 15:51:06 --> Controller Class Initialized
INFO - 2025-05-22 15:51:06 --> Model "Progress_model" initialized
INFO - 2025-05-22 15:51:06 --> Final output sent to browser
DEBUG - 2025-05-22 15:51:06 --> Total execution time: 0.0869
INFO - 2025-05-22 15:51:10 --> Config Class Initialized
INFO - 2025-05-22 15:51:10 --> Hooks Class Initialized
DEBUG - 2025-05-22 15:51:10 --> UTF-8 Support Enabled
INFO - 2025-05-22 15:51:10 --> Utf8 Class Initialized
INFO - 2025-05-22 15:51:10 --> URI Class Initialized
INFO - 2025-05-22 15:51:10 --> Router Class Initialized
INFO - 2025-05-22 15:51:10 --> Output Class Initialized
INFO - 2025-05-22 15:51:10 --> Security Class Initialized
DEBUG - 2025-05-22 15:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 15:51:10 --> Input Class Initialized
INFO - 2025-05-22 15:51:10 --> Language Class Initialized
INFO - 2025-05-22 15:51:10 --> Loader Class Initialized
INFO - 2025-05-22 15:51:10 --> Helper loaded: url_helper
INFO - 2025-05-22 15:51:10 --> Helper loaded: form_helper
INFO - 2025-05-22 15:51:10 --> Database Driver Class Initialized
DEBUG - 2025-05-22 15:51:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 15:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 15:51:10 --> Controller Class Initialized
INFO - 2025-05-22 15:51:10 --> Model "Timer_model" initialized
INFO - 2025-05-22 15:51:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\timer_view.php
INFO - 2025-05-22 15:51:10 --> Final output sent to browser
DEBUG - 2025-05-22 15:51:10 --> Total execution time: 0.0730
INFO - 2025-05-22 15:51:17 --> Config Class Initialized
INFO - 2025-05-22 15:51:17 --> Hooks Class Initialized
DEBUG - 2025-05-22 15:51:17 --> UTF-8 Support Enabled
INFO - 2025-05-22 15:51:17 --> Utf8 Class Initialized
INFO - 2025-05-22 15:51:17 --> URI Class Initialized
INFO - 2025-05-22 15:51:17 --> Router Class Initialized
INFO - 2025-05-22 15:51:17 --> Output Class Initialized
INFO - 2025-05-22 15:51:17 --> Security Class Initialized
DEBUG - 2025-05-22 15:51:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 15:51:17 --> Input Class Initialized
INFO - 2025-05-22 15:51:17 --> Language Class Initialized
INFO - 2025-05-22 15:51:17 --> Loader Class Initialized
INFO - 2025-05-22 15:51:17 --> Helper loaded: url_helper
INFO - 2025-05-22 15:51:17 --> Helper loaded: form_helper
INFO - 2025-05-22 15:51:17 --> Database Driver Class Initialized
DEBUG - 2025-05-22 15:51:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 15:51:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 15:51:17 --> Controller Class Initialized
INFO - 2025-05-22 15:51:17 --> Model "Timer_model" initialized
INFO - 2025-05-22 15:51:17 --> Final output sent to browser
DEBUG - 2025-05-22 15:51:17 --> Total execution time: 0.0756
INFO - 2025-05-22 15:51:18 --> Config Class Initialized
INFO - 2025-05-22 15:51:18 --> Hooks Class Initialized
DEBUG - 2025-05-22 15:51:18 --> UTF-8 Support Enabled
INFO - 2025-05-22 15:51:18 --> Utf8 Class Initialized
INFO - 2025-05-22 15:51:18 --> URI Class Initialized
INFO - 2025-05-22 15:51:18 --> Router Class Initialized
INFO - 2025-05-22 15:51:18 --> Output Class Initialized
INFO - 2025-05-22 15:51:18 --> Security Class Initialized
DEBUG - 2025-05-22 15:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 15:51:18 --> Input Class Initialized
INFO - 2025-05-22 15:51:18 --> Language Class Initialized
INFO - 2025-05-22 15:51:18 --> Loader Class Initialized
INFO - 2025-05-22 15:51:18 --> Helper loaded: url_helper
INFO - 2025-05-22 15:51:18 --> Helper loaded: form_helper
INFO - 2025-05-22 15:51:18 --> Database Driver Class Initialized
DEBUG - 2025-05-22 15:51:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 15:51:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 15:51:18 --> Controller Class Initialized
INFO - 2025-05-22 15:51:18 --> Model "Timer_model" initialized
INFO - 2025-05-22 15:51:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\timer_view.php
INFO - 2025-05-22 15:51:18 --> Final output sent to browser
DEBUG - 2025-05-22 15:51:18 --> Total execution time: 0.0899
INFO - 2025-05-22 15:51:23 --> Config Class Initialized
INFO - 2025-05-22 15:51:23 --> Hooks Class Initialized
DEBUG - 2025-05-22 15:51:23 --> UTF-8 Support Enabled
INFO - 2025-05-22 15:51:23 --> Utf8 Class Initialized
INFO - 2025-05-22 15:51:23 --> URI Class Initialized
INFO - 2025-05-22 15:51:23 --> Router Class Initialized
INFO - 2025-05-22 15:51:23 --> Output Class Initialized
INFO - 2025-05-22 15:51:23 --> Security Class Initialized
DEBUG - 2025-05-22 15:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 15:51:23 --> Input Class Initialized
INFO - 2025-05-22 15:51:23 --> Language Class Initialized
INFO - 2025-05-22 15:51:23 --> Loader Class Initialized
INFO - 2025-05-22 15:51:23 --> Helper loaded: url_helper
INFO - 2025-05-22 15:51:23 --> Helper loaded: form_helper
INFO - 2025-05-22 15:51:23 --> Database Driver Class Initialized
DEBUG - 2025-05-22 15:51:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 15:51:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 15:51:23 --> Controller Class Initialized
INFO - 2025-05-22 15:51:23 --> Model "Progress_model" initialized
INFO - 2025-05-22 15:51:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\progress_view.php
INFO - 2025-05-22 15:51:23 --> Final output sent to browser
DEBUG - 2025-05-22 15:51:23 --> Total execution time: 0.0936
INFO - 2025-05-22 15:51:24 --> Config Class Initialized
INFO - 2025-05-22 15:51:24 --> Hooks Class Initialized
DEBUG - 2025-05-22 15:51:24 --> UTF-8 Support Enabled
INFO - 2025-05-22 15:51:24 --> Utf8 Class Initialized
INFO - 2025-05-22 15:51:24 --> URI Class Initialized
INFO - 2025-05-22 15:51:24 --> Router Class Initialized
INFO - 2025-05-22 15:51:24 --> Output Class Initialized
INFO - 2025-05-22 15:51:24 --> Security Class Initialized
DEBUG - 2025-05-22 15:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 15:51:24 --> Input Class Initialized
INFO - 2025-05-22 15:51:24 --> Language Class Initialized
INFO - 2025-05-22 15:51:24 --> Loader Class Initialized
INFO - 2025-05-22 15:51:24 --> Helper loaded: url_helper
INFO - 2025-05-22 15:51:24 --> Helper loaded: form_helper
INFO - 2025-05-22 15:51:24 --> Database Driver Class Initialized
DEBUG - 2025-05-22 15:51:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 15:51:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 15:51:24 --> Controller Class Initialized
INFO - 2025-05-22 15:51:24 --> Model "Progress_model" initialized
INFO - 2025-05-22 15:51:24 --> Final output sent to browser
DEBUG - 2025-05-22 15:51:24 --> Total execution time: 0.0950
INFO - 2025-05-22 15:51:26 --> Config Class Initialized
INFO - 2025-05-22 15:51:26 --> Hooks Class Initialized
DEBUG - 2025-05-22 15:51:26 --> UTF-8 Support Enabled
INFO - 2025-05-22 15:51:26 --> Utf8 Class Initialized
INFO - 2025-05-22 15:51:26 --> URI Class Initialized
INFO - 2025-05-22 15:51:26 --> Router Class Initialized
INFO - 2025-05-22 15:51:26 --> Output Class Initialized
INFO - 2025-05-22 15:51:26 --> Security Class Initialized
DEBUG - 2025-05-22 15:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 15:51:26 --> Input Class Initialized
INFO - 2025-05-22 15:51:26 --> Language Class Initialized
INFO - 2025-05-22 15:51:26 --> Loader Class Initialized
INFO - 2025-05-22 15:51:26 --> Helper loaded: url_helper
INFO - 2025-05-22 15:51:26 --> Helper loaded: form_helper
INFO - 2025-05-22 15:51:26 --> Database Driver Class Initialized
DEBUG - 2025-05-22 15:51:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 15:51:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 15:51:26 --> Controller Class Initialized
INFO - 2025-05-22 15:51:26 --> Model "Progress_model" initialized
INFO - 2025-05-22 15:51:26 --> Final output sent to browser
DEBUG - 2025-05-22 15:51:26 --> Total execution time: 0.0781
INFO - 2025-05-22 16:00:34 --> Config Class Initialized
INFO - 2025-05-22 16:00:34 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:00:34 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:00:34 --> Utf8 Class Initialized
INFO - 2025-05-22 16:00:34 --> URI Class Initialized
INFO - 2025-05-22 16:00:34 --> Router Class Initialized
INFO - 2025-05-22 16:00:34 --> Output Class Initialized
INFO - 2025-05-22 16:00:34 --> Security Class Initialized
DEBUG - 2025-05-22 16:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:00:34 --> Input Class Initialized
INFO - 2025-05-22 16:00:34 --> Language Class Initialized
INFO - 2025-05-22 16:00:34 --> Loader Class Initialized
INFO - 2025-05-22 16:00:34 --> Helper loaded: url_helper
INFO - 2025-05-22 16:00:34 --> Helper loaded: form_helper
INFO - 2025-05-22 16:00:34 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:00:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:00:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:00:34 --> Controller Class Initialized
INFO - 2025-05-22 16:00:34 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:00:34 --> Model "User_model" initialized
INFO - 2025-05-22 16:00:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-22 16:00:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-22 16:00:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-22 16:00:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-22 16:00:34 --> Final output sent to browser
DEBUG - 2025-05-22 16:00:34 --> Total execution time: 0.0874
INFO - 2025-05-22 16:00:34 --> Config Class Initialized
INFO - 2025-05-22 16:00:34 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:00:34 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:00:34 --> Utf8 Class Initialized
INFO - 2025-05-22 16:00:34 --> URI Class Initialized
INFO - 2025-05-22 16:00:34 --> Router Class Initialized
INFO - 2025-05-22 16:00:34 --> Output Class Initialized
INFO - 2025-05-22 16:00:34 --> Security Class Initialized
DEBUG - 2025-05-22 16:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:00:34 --> Input Class Initialized
INFO - 2025-05-22 16:00:34 --> Language Class Initialized
INFO - 2025-05-22 16:00:34 --> Loader Class Initialized
INFO - 2025-05-22 16:00:34 --> Helper loaded: url_helper
INFO - 2025-05-22 16:00:34 --> Helper loaded: form_helper
INFO - 2025-05-22 16:00:34 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:00:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:00:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:00:34 --> Controller Class Initialized
INFO - 2025-05-22 16:00:34 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:00:34 --> Model "User_model" initialized
INFO - 2025-05-22 16:00:34 --> Final output sent to browser
DEBUG - 2025-05-22 16:00:34 --> Total execution time: 0.0863
INFO - 2025-05-22 16:00:36 --> Config Class Initialized
INFO - 2025-05-22 16:00:36 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:00:36 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:00:36 --> Utf8 Class Initialized
INFO - 2025-05-22 16:00:36 --> URI Class Initialized
INFO - 2025-05-22 16:00:36 --> Router Class Initialized
INFO - 2025-05-22 16:00:36 --> Output Class Initialized
INFO - 2025-05-22 16:00:36 --> Security Class Initialized
DEBUG - 2025-05-22 16:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:00:36 --> Input Class Initialized
INFO - 2025-05-22 16:00:36 --> Language Class Initialized
INFO - 2025-05-22 16:00:36 --> Loader Class Initialized
INFO - 2025-05-22 16:00:36 --> Helper loaded: url_helper
INFO - 2025-05-22 16:00:36 --> Helper loaded: form_helper
INFO - 2025-05-22 16:00:36 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:00:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:00:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:00:36 --> Controller Class Initialized
INFO - 2025-05-22 16:00:36 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:00:36 --> Model "User_model" initialized
INFO - 2025-05-22 16:00:36 --> Final output sent to browser
DEBUG - 2025-05-22 16:00:36 --> Total execution time: 0.0806
INFO - 2025-05-22 16:00:37 --> Config Class Initialized
INFO - 2025-05-22 16:00:37 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:00:37 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:00:37 --> Utf8 Class Initialized
INFO - 2025-05-22 16:00:37 --> URI Class Initialized
INFO - 2025-05-22 16:00:37 --> Router Class Initialized
INFO - 2025-05-22 16:00:37 --> Output Class Initialized
INFO - 2025-05-22 16:00:37 --> Security Class Initialized
DEBUG - 2025-05-22 16:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:00:37 --> Input Class Initialized
INFO - 2025-05-22 16:00:37 --> Language Class Initialized
INFO - 2025-05-22 16:00:37 --> Loader Class Initialized
INFO - 2025-05-22 16:00:37 --> Helper loaded: url_helper
INFO - 2025-05-22 16:00:37 --> Helper loaded: form_helper
INFO - 2025-05-22 16:00:37 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:00:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:00:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:00:37 --> Controller Class Initialized
INFO - 2025-05-22 16:00:37 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:00:37 --> Model "User_model" initialized
INFO - 2025-05-22 16:00:37 --> Final output sent to browser
DEBUG - 2025-05-22 16:00:37 --> Total execution time: 0.0870
INFO - 2025-05-22 16:00:37 --> Config Class Initialized
INFO - 2025-05-22 16:00:37 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:00:37 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:00:37 --> Utf8 Class Initialized
INFO - 2025-05-22 16:00:37 --> URI Class Initialized
INFO - 2025-05-22 16:00:37 --> Router Class Initialized
INFO - 2025-05-22 16:00:37 --> Output Class Initialized
INFO - 2025-05-22 16:00:37 --> Security Class Initialized
DEBUG - 2025-05-22 16:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:00:37 --> Input Class Initialized
INFO - 2025-05-22 16:00:37 --> Language Class Initialized
INFO - 2025-05-22 16:00:37 --> Loader Class Initialized
INFO - 2025-05-22 16:00:37 --> Helper loaded: url_helper
INFO - 2025-05-22 16:00:37 --> Helper loaded: form_helper
INFO - 2025-05-22 16:00:37 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:00:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:00:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:00:37 --> Controller Class Initialized
INFO - 2025-05-22 16:00:37 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:00:37 --> Model "User_model" initialized
INFO - 2025-05-22 16:00:37 --> Final output sent to browser
DEBUG - 2025-05-22 16:00:37 --> Total execution time: 0.0655
INFO - 2025-05-22 16:00:37 --> Config Class Initialized
INFO - 2025-05-22 16:00:37 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:00:37 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:00:37 --> Utf8 Class Initialized
INFO - 2025-05-22 16:00:37 --> URI Class Initialized
INFO - 2025-05-22 16:00:37 --> Router Class Initialized
INFO - 2025-05-22 16:00:37 --> Output Class Initialized
INFO - 2025-05-22 16:00:37 --> Security Class Initialized
DEBUG - 2025-05-22 16:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:00:37 --> Input Class Initialized
INFO - 2025-05-22 16:00:37 --> Language Class Initialized
INFO - 2025-05-22 16:00:37 --> Loader Class Initialized
INFO - 2025-05-22 16:00:37 --> Helper loaded: url_helper
INFO - 2025-05-22 16:00:37 --> Helper loaded: form_helper
INFO - 2025-05-22 16:00:37 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:00:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:00:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:00:38 --> Controller Class Initialized
INFO - 2025-05-22 16:00:38 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:00:38 --> Model "User_model" initialized
INFO - 2025-05-22 16:00:38 --> Final output sent to browser
DEBUG - 2025-05-22 16:00:38 --> Total execution time: 0.1089
INFO - 2025-05-22 16:00:38 --> Config Class Initialized
INFO - 2025-05-22 16:00:38 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:00:38 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:00:38 --> Utf8 Class Initialized
INFO - 2025-05-22 16:00:38 --> URI Class Initialized
INFO - 2025-05-22 16:00:38 --> Router Class Initialized
INFO - 2025-05-22 16:00:38 --> Output Class Initialized
INFO - 2025-05-22 16:00:38 --> Security Class Initialized
DEBUG - 2025-05-22 16:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:00:38 --> Input Class Initialized
INFO - 2025-05-22 16:00:38 --> Language Class Initialized
INFO - 2025-05-22 16:00:38 --> Loader Class Initialized
INFO - 2025-05-22 16:00:38 --> Helper loaded: url_helper
INFO - 2025-05-22 16:00:38 --> Helper loaded: form_helper
INFO - 2025-05-22 16:00:38 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:00:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:00:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:00:38 --> Controller Class Initialized
INFO - 2025-05-22 16:00:38 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:00:38 --> Model "User_model" initialized
INFO - 2025-05-22 16:00:38 --> Final output sent to browser
DEBUG - 2025-05-22 16:00:38 --> Total execution time: 0.0946
INFO - 2025-05-22 16:00:39 --> Config Class Initialized
INFO - 2025-05-22 16:00:39 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:00:39 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:00:39 --> Utf8 Class Initialized
INFO - 2025-05-22 16:00:39 --> URI Class Initialized
INFO - 2025-05-22 16:00:39 --> Router Class Initialized
INFO - 2025-05-22 16:00:39 --> Output Class Initialized
INFO - 2025-05-22 16:00:39 --> Security Class Initialized
DEBUG - 2025-05-22 16:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:00:39 --> Input Class Initialized
INFO - 2025-05-22 16:00:39 --> Language Class Initialized
INFO - 2025-05-22 16:00:39 --> Loader Class Initialized
INFO - 2025-05-22 16:00:39 --> Helper loaded: url_helper
INFO - 2025-05-22 16:00:39 --> Helper loaded: form_helper
INFO - 2025-05-22 16:00:39 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:00:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:00:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:00:39 --> Controller Class Initialized
INFO - 2025-05-22 16:00:39 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:00:39 --> Model "User_model" initialized
INFO - 2025-05-22 16:00:39 --> Final output sent to browser
DEBUG - 2025-05-22 16:00:39 --> Total execution time: 0.0623
INFO - 2025-05-22 16:00:39 --> Config Class Initialized
INFO - 2025-05-22 16:00:39 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:00:39 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:00:39 --> Utf8 Class Initialized
INFO - 2025-05-22 16:00:39 --> URI Class Initialized
INFO - 2025-05-22 16:00:39 --> Router Class Initialized
INFO - 2025-05-22 16:00:39 --> Output Class Initialized
INFO - 2025-05-22 16:00:39 --> Security Class Initialized
DEBUG - 2025-05-22 16:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:00:39 --> Input Class Initialized
INFO - 2025-05-22 16:00:39 --> Language Class Initialized
INFO - 2025-05-22 16:00:39 --> Loader Class Initialized
INFO - 2025-05-22 16:00:39 --> Helper loaded: url_helper
INFO - 2025-05-22 16:00:39 --> Helper loaded: form_helper
INFO - 2025-05-22 16:00:39 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:00:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:00:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:00:39 --> Controller Class Initialized
INFO - 2025-05-22 16:00:39 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:00:39 --> Model "User_model" initialized
INFO - 2025-05-22 16:00:39 --> Final output sent to browser
DEBUG - 2025-05-22 16:00:39 --> Total execution time: 0.0621
INFO - 2025-05-22 16:00:39 --> Config Class Initialized
INFO - 2025-05-22 16:00:39 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:00:39 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:00:39 --> Utf8 Class Initialized
INFO - 2025-05-22 16:00:39 --> URI Class Initialized
INFO - 2025-05-22 16:00:39 --> Router Class Initialized
INFO - 2025-05-22 16:00:39 --> Output Class Initialized
INFO - 2025-05-22 16:00:39 --> Security Class Initialized
DEBUG - 2025-05-22 16:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:00:39 --> Input Class Initialized
INFO - 2025-05-22 16:00:39 --> Language Class Initialized
INFO - 2025-05-22 16:00:39 --> Loader Class Initialized
INFO - 2025-05-22 16:00:39 --> Helper loaded: url_helper
INFO - 2025-05-22 16:00:39 --> Helper loaded: form_helper
INFO - 2025-05-22 16:00:39 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:00:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:00:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:00:39 --> Controller Class Initialized
INFO - 2025-05-22 16:00:39 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:00:39 --> Model "User_model" initialized
INFO - 2025-05-22 16:00:39 --> Final output sent to browser
DEBUG - 2025-05-22 16:00:39 --> Total execution time: 0.0858
INFO - 2025-05-22 16:00:40 --> Config Class Initialized
INFO - 2025-05-22 16:00:40 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:00:40 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:00:40 --> Utf8 Class Initialized
INFO - 2025-05-22 16:00:40 --> URI Class Initialized
INFO - 2025-05-22 16:00:40 --> Router Class Initialized
INFO - 2025-05-22 16:00:40 --> Output Class Initialized
INFO - 2025-05-22 16:00:40 --> Security Class Initialized
DEBUG - 2025-05-22 16:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:00:40 --> Input Class Initialized
INFO - 2025-05-22 16:00:40 --> Language Class Initialized
INFO - 2025-05-22 16:00:40 --> Loader Class Initialized
INFO - 2025-05-22 16:00:40 --> Helper loaded: url_helper
INFO - 2025-05-22 16:00:40 --> Helper loaded: form_helper
INFO - 2025-05-22 16:00:40 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:00:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:00:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:00:40 --> Controller Class Initialized
INFO - 2025-05-22 16:00:40 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:00:40 --> Model "User_model" initialized
INFO - 2025-05-22 16:00:40 --> Final output sent to browser
DEBUG - 2025-05-22 16:00:40 --> Total execution time: 0.0820
INFO - 2025-05-22 16:00:40 --> Config Class Initialized
INFO - 2025-05-22 16:00:40 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:00:40 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:00:40 --> Utf8 Class Initialized
INFO - 2025-05-22 16:00:40 --> URI Class Initialized
INFO - 2025-05-22 16:00:40 --> Router Class Initialized
INFO - 2025-05-22 16:00:40 --> Output Class Initialized
INFO - 2025-05-22 16:00:40 --> Security Class Initialized
DEBUG - 2025-05-22 16:00:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:00:40 --> Input Class Initialized
INFO - 2025-05-22 16:00:40 --> Language Class Initialized
INFO - 2025-05-22 16:00:40 --> Loader Class Initialized
INFO - 2025-05-22 16:00:40 --> Helper loaded: url_helper
INFO - 2025-05-22 16:00:40 --> Helper loaded: form_helper
INFO - 2025-05-22 16:00:40 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:00:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:00:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:00:40 --> Controller Class Initialized
INFO - 2025-05-22 16:00:40 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:00:40 --> Model "User_model" initialized
INFO - 2025-05-22 16:00:40 --> Final output sent to browser
DEBUG - 2025-05-22 16:00:40 --> Total execution time: 0.0790
INFO - 2025-05-22 16:00:41 --> Config Class Initialized
INFO - 2025-05-22 16:00:41 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:00:41 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:00:41 --> Utf8 Class Initialized
INFO - 2025-05-22 16:00:41 --> URI Class Initialized
INFO - 2025-05-22 16:00:41 --> Router Class Initialized
INFO - 2025-05-22 16:00:41 --> Output Class Initialized
INFO - 2025-05-22 16:00:41 --> Security Class Initialized
DEBUG - 2025-05-22 16:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:00:41 --> Input Class Initialized
INFO - 2025-05-22 16:00:41 --> Language Class Initialized
INFO - 2025-05-22 16:00:41 --> Loader Class Initialized
INFO - 2025-05-22 16:00:41 --> Helper loaded: url_helper
INFO - 2025-05-22 16:00:41 --> Helper loaded: form_helper
INFO - 2025-05-22 16:00:41 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:00:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:00:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:00:41 --> Controller Class Initialized
INFO - 2025-05-22 16:00:41 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:00:41 --> Model "User_model" initialized
INFO - 2025-05-22 16:00:41 --> Final output sent to browser
DEBUG - 2025-05-22 16:00:41 --> Total execution time: 0.0738
INFO - 2025-05-22 16:00:42 --> Config Class Initialized
INFO - 2025-05-22 16:00:42 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:00:42 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:00:42 --> Utf8 Class Initialized
INFO - 2025-05-22 16:00:42 --> URI Class Initialized
INFO - 2025-05-22 16:00:42 --> Router Class Initialized
INFO - 2025-05-22 16:00:42 --> Output Class Initialized
INFO - 2025-05-22 16:00:42 --> Security Class Initialized
DEBUG - 2025-05-22 16:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:00:42 --> Input Class Initialized
INFO - 2025-05-22 16:00:42 --> Language Class Initialized
INFO - 2025-05-22 16:00:42 --> Loader Class Initialized
INFO - 2025-05-22 16:00:42 --> Helper loaded: url_helper
INFO - 2025-05-22 16:00:42 --> Helper loaded: form_helper
INFO - 2025-05-22 16:00:42 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:00:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:00:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:00:42 --> Controller Class Initialized
INFO - 2025-05-22 16:00:42 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:00:42 --> Model "User_model" initialized
INFO - 2025-05-22 16:00:42 --> Final output sent to browser
DEBUG - 2025-05-22 16:00:42 --> Total execution time: 0.0788
INFO - 2025-05-22 16:02:20 --> Config Class Initialized
INFO - 2025-05-22 16:02:20 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:02:20 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:02:20 --> Utf8 Class Initialized
INFO - 2025-05-22 16:02:20 --> URI Class Initialized
INFO - 2025-05-22 16:02:20 --> Router Class Initialized
INFO - 2025-05-22 16:02:20 --> Output Class Initialized
INFO - 2025-05-22 16:02:20 --> Security Class Initialized
DEBUG - 2025-05-22 16:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:02:20 --> Input Class Initialized
INFO - 2025-05-22 16:02:20 --> Language Class Initialized
INFO - 2025-05-22 16:02:20 --> Loader Class Initialized
INFO - 2025-05-22 16:02:20 --> Helper loaded: url_helper
INFO - 2025-05-22 16:02:20 --> Helper loaded: form_helper
INFO - 2025-05-22 16:02:20 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:02:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:02:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:02:20 --> Controller Class Initialized
INFO - 2025-05-22 16:02:20 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:02:20 --> Model "User_model" initialized
INFO - 2025-05-22 16:02:20 --> Final output sent to browser
DEBUG - 2025-05-22 16:02:20 --> Total execution time: 0.0682
INFO - 2025-05-22 16:02:22 --> Config Class Initialized
INFO - 2025-05-22 16:02:22 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:02:22 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:02:22 --> Utf8 Class Initialized
INFO - 2025-05-22 16:02:22 --> URI Class Initialized
INFO - 2025-05-22 16:02:22 --> Router Class Initialized
INFO - 2025-05-22 16:02:22 --> Output Class Initialized
INFO - 2025-05-22 16:02:22 --> Security Class Initialized
DEBUG - 2025-05-22 16:02:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:02:22 --> Input Class Initialized
INFO - 2025-05-22 16:02:22 --> Language Class Initialized
INFO - 2025-05-22 16:02:22 --> Loader Class Initialized
INFO - 2025-05-22 16:02:22 --> Helper loaded: url_helper
INFO - 2025-05-22 16:02:22 --> Helper loaded: form_helper
INFO - 2025-05-22 16:02:22 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:02:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:02:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:02:22 --> Controller Class Initialized
INFO - 2025-05-22 16:02:22 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:02:22 --> Model "User_model" initialized
INFO - 2025-05-22 16:02:22 --> Final output sent to browser
DEBUG - 2025-05-22 16:02:22 --> Total execution time: 0.0750
INFO - 2025-05-22 16:02:24 --> Config Class Initialized
INFO - 2025-05-22 16:02:24 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:02:24 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:02:24 --> Utf8 Class Initialized
INFO - 2025-05-22 16:02:24 --> URI Class Initialized
INFO - 2025-05-22 16:02:24 --> Router Class Initialized
INFO - 2025-05-22 16:02:24 --> Output Class Initialized
INFO - 2025-05-22 16:02:24 --> Security Class Initialized
DEBUG - 2025-05-22 16:02:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:02:24 --> Input Class Initialized
INFO - 2025-05-22 16:02:24 --> Language Class Initialized
INFO - 2025-05-22 16:02:24 --> Loader Class Initialized
INFO - 2025-05-22 16:02:24 --> Helper loaded: url_helper
INFO - 2025-05-22 16:02:24 --> Helper loaded: form_helper
INFO - 2025-05-22 16:02:24 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:02:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:02:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:02:24 --> Controller Class Initialized
INFO - 2025-05-22 16:02:24 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:02:24 --> Model "User_model" initialized
INFO - 2025-05-22 16:02:24 --> Final output sent to browser
DEBUG - 2025-05-22 16:02:24 --> Total execution time: 0.0717
INFO - 2025-05-22 16:02:26 --> Config Class Initialized
INFO - 2025-05-22 16:02:26 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:02:26 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:02:26 --> Utf8 Class Initialized
INFO - 2025-05-22 16:02:26 --> URI Class Initialized
INFO - 2025-05-22 16:02:26 --> Router Class Initialized
INFO - 2025-05-22 16:02:26 --> Output Class Initialized
INFO - 2025-05-22 16:02:26 --> Security Class Initialized
DEBUG - 2025-05-22 16:02:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:02:26 --> Input Class Initialized
INFO - 2025-05-22 16:02:26 --> Language Class Initialized
INFO - 2025-05-22 16:02:26 --> Loader Class Initialized
INFO - 2025-05-22 16:02:26 --> Helper loaded: url_helper
INFO - 2025-05-22 16:02:26 --> Helper loaded: form_helper
INFO - 2025-05-22 16:02:26 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:02:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:02:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:02:26 --> Controller Class Initialized
INFO - 2025-05-22 16:02:26 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:02:26 --> Model "User_model" initialized
INFO - 2025-05-22 16:02:26 --> Final output sent to browser
DEBUG - 2025-05-22 16:02:26 --> Total execution time: 0.0815
INFO - 2025-05-22 16:02:28 --> Config Class Initialized
INFO - 2025-05-22 16:02:28 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:02:28 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:02:28 --> Utf8 Class Initialized
INFO - 2025-05-22 16:02:28 --> URI Class Initialized
INFO - 2025-05-22 16:02:28 --> Router Class Initialized
INFO - 2025-05-22 16:02:28 --> Output Class Initialized
INFO - 2025-05-22 16:02:28 --> Security Class Initialized
DEBUG - 2025-05-22 16:02:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:02:28 --> Input Class Initialized
INFO - 2025-05-22 16:02:28 --> Language Class Initialized
INFO - 2025-05-22 16:02:28 --> Loader Class Initialized
INFO - 2025-05-22 16:02:28 --> Helper loaded: url_helper
INFO - 2025-05-22 16:02:28 --> Helper loaded: form_helper
INFO - 2025-05-22 16:02:28 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:02:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:02:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:02:28 --> Controller Class Initialized
INFO - 2025-05-22 16:02:28 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:02:28 --> Model "User_model" initialized
INFO - 2025-05-22 16:02:28 --> Final output sent to browser
DEBUG - 2025-05-22 16:02:28 --> Total execution time: 0.0892
INFO - 2025-05-22 16:02:29 --> Config Class Initialized
INFO - 2025-05-22 16:02:29 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:02:29 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:02:29 --> Utf8 Class Initialized
INFO - 2025-05-22 16:02:29 --> URI Class Initialized
INFO - 2025-05-22 16:02:29 --> Router Class Initialized
INFO - 2025-05-22 16:02:29 --> Output Class Initialized
INFO - 2025-05-22 16:02:29 --> Security Class Initialized
DEBUG - 2025-05-22 16:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:02:29 --> Input Class Initialized
INFO - 2025-05-22 16:02:29 --> Language Class Initialized
INFO - 2025-05-22 16:02:29 --> Loader Class Initialized
INFO - 2025-05-22 16:02:29 --> Helper loaded: url_helper
INFO - 2025-05-22 16:02:29 --> Helper loaded: form_helper
INFO - 2025-05-22 16:02:29 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:02:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:02:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:02:29 --> Controller Class Initialized
INFO - 2025-05-22 16:02:29 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:02:29 --> Model "User_model" initialized
INFO - 2025-05-22 16:02:29 --> Final output sent to browser
DEBUG - 2025-05-22 16:02:29 --> Total execution time: 0.0745
INFO - 2025-05-22 16:02:32 --> Config Class Initialized
INFO - 2025-05-22 16:02:32 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:02:32 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:02:32 --> Utf8 Class Initialized
INFO - 2025-05-22 16:02:32 --> URI Class Initialized
INFO - 2025-05-22 16:02:32 --> Router Class Initialized
INFO - 2025-05-22 16:02:32 --> Output Class Initialized
INFO - 2025-05-22 16:02:32 --> Security Class Initialized
DEBUG - 2025-05-22 16:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:02:32 --> Input Class Initialized
INFO - 2025-05-22 16:02:32 --> Language Class Initialized
INFO - 2025-05-22 16:02:32 --> Loader Class Initialized
INFO - 2025-05-22 16:02:32 --> Helper loaded: url_helper
INFO - 2025-05-22 16:02:32 --> Helper loaded: form_helper
INFO - 2025-05-22 16:02:32 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:02:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:02:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:02:32 --> Controller Class Initialized
INFO - 2025-05-22 16:02:32 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:02:32 --> Model "User_model" initialized
INFO - 2025-05-22 16:02:32 --> Final output sent to browser
DEBUG - 2025-05-22 16:02:32 --> Total execution time: 0.0597
INFO - 2025-05-22 16:04:54 --> Config Class Initialized
INFO - 2025-05-22 16:04:54 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:04:54 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:04:54 --> Utf8 Class Initialized
INFO - 2025-05-22 16:04:54 --> URI Class Initialized
INFO - 2025-05-22 16:04:54 --> Router Class Initialized
INFO - 2025-05-22 16:04:54 --> Output Class Initialized
INFO - 2025-05-22 16:04:54 --> Security Class Initialized
DEBUG - 2025-05-22 16:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:04:54 --> Input Class Initialized
INFO - 2025-05-22 16:04:54 --> Language Class Initialized
INFO - 2025-05-22 16:04:54 --> Loader Class Initialized
INFO - 2025-05-22 16:04:54 --> Helper loaded: url_helper
INFO - 2025-05-22 16:04:54 --> Helper loaded: form_helper
INFO - 2025-05-22 16:04:54 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:04:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:04:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:04:54 --> Controller Class Initialized
INFO - 2025-05-22 16:04:54 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:04:54 --> Model "User_model" initialized
INFO - 2025-05-22 16:04:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-22 16:04:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-22 16:04:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-22 16:04:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-22 16:04:54 --> Final output sent to browser
DEBUG - 2025-05-22 16:04:54 --> Total execution time: 0.0623
INFO - 2025-05-22 16:04:54 --> Config Class Initialized
INFO - 2025-05-22 16:04:54 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:04:54 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:04:54 --> Utf8 Class Initialized
INFO - 2025-05-22 16:04:54 --> URI Class Initialized
INFO - 2025-05-22 16:04:54 --> Router Class Initialized
INFO - 2025-05-22 16:04:54 --> Output Class Initialized
INFO - 2025-05-22 16:04:54 --> Security Class Initialized
DEBUG - 2025-05-22 16:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:04:54 --> Input Class Initialized
INFO - 2025-05-22 16:04:54 --> Language Class Initialized
INFO - 2025-05-22 16:04:54 --> Loader Class Initialized
INFO - 2025-05-22 16:04:54 --> Helper loaded: url_helper
INFO - 2025-05-22 16:04:54 --> Helper loaded: form_helper
INFO - 2025-05-22 16:04:54 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:04:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:04:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:04:54 --> Controller Class Initialized
INFO - 2025-05-22 16:04:54 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:04:54 --> Model "User_model" initialized
INFO - 2025-05-22 16:04:54 --> Final output sent to browser
DEBUG - 2025-05-22 16:04:54 --> Total execution time: 0.0918
INFO - 2025-05-22 16:06:25 --> Config Class Initialized
INFO - 2025-05-22 16:06:25 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:06:25 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:06:25 --> Utf8 Class Initialized
INFO - 2025-05-22 16:06:25 --> URI Class Initialized
INFO - 2025-05-22 16:06:25 --> Router Class Initialized
INFO - 2025-05-22 16:06:25 --> Output Class Initialized
INFO - 2025-05-22 16:06:25 --> Security Class Initialized
DEBUG - 2025-05-22 16:06:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:06:25 --> Input Class Initialized
INFO - 2025-05-22 16:06:25 --> Language Class Initialized
INFO - 2025-05-22 16:06:25 --> Loader Class Initialized
INFO - 2025-05-22 16:06:25 --> Helper loaded: url_helper
INFO - 2025-05-22 16:06:25 --> Helper loaded: form_helper
INFO - 2025-05-22 16:06:25 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:06:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:06:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:06:25 --> Controller Class Initialized
INFO - 2025-05-22 16:06:25 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:06:25 --> Model "User_model" initialized
INFO - 2025-05-22 16:06:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-22 16:06:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-22 16:06:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-22 16:06:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-22 16:06:25 --> Final output sent to browser
DEBUG - 2025-05-22 16:06:25 --> Total execution time: 0.0854
INFO - 2025-05-22 16:06:25 --> Config Class Initialized
INFO - 2025-05-22 16:06:25 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:06:25 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:06:25 --> Utf8 Class Initialized
INFO - 2025-05-22 16:06:25 --> URI Class Initialized
INFO - 2025-05-22 16:06:25 --> Router Class Initialized
INFO - 2025-05-22 16:06:25 --> Output Class Initialized
INFO - 2025-05-22 16:06:25 --> Security Class Initialized
DEBUG - 2025-05-22 16:06:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:06:25 --> Input Class Initialized
INFO - 2025-05-22 16:06:25 --> Language Class Initialized
INFO - 2025-05-22 16:06:25 --> Loader Class Initialized
INFO - 2025-05-22 16:06:25 --> Helper loaded: url_helper
INFO - 2025-05-22 16:06:25 --> Helper loaded: form_helper
INFO - 2025-05-22 16:06:25 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:06:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:06:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:06:25 --> Controller Class Initialized
INFO - 2025-05-22 16:06:25 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:06:25 --> Model "User_model" initialized
INFO - 2025-05-22 16:06:25 --> Final output sent to browser
DEBUG - 2025-05-22 16:06:25 --> Total execution time: 0.0812
INFO - 2025-05-22 16:14:12 --> Config Class Initialized
INFO - 2025-05-22 16:14:12 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:14:12 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:14:12 --> Utf8 Class Initialized
INFO - 2025-05-22 16:14:12 --> URI Class Initialized
INFO - 2025-05-22 16:14:12 --> Router Class Initialized
INFO - 2025-05-22 16:14:12 --> Output Class Initialized
INFO - 2025-05-22 16:14:12 --> Security Class Initialized
DEBUG - 2025-05-22 16:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:14:12 --> Input Class Initialized
INFO - 2025-05-22 16:14:12 --> Language Class Initialized
INFO - 2025-05-22 16:14:12 --> Loader Class Initialized
INFO - 2025-05-22 16:14:12 --> Helper loaded: url_helper
INFO - 2025-05-22 16:14:12 --> Helper loaded: form_helper
INFO - 2025-05-22 16:14:12 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:14:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:14:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:14:12 --> Controller Class Initialized
INFO - 2025-05-22 16:14:12 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:14:12 --> Model "User_model" initialized
INFO - 2025-05-22 16:14:12 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-22 16:14:12 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-22 16:14:12 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-22 16:14:12 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-22 16:14:12 --> Final output sent to browser
DEBUG - 2025-05-22 16:14:12 --> Total execution time: 0.1068
INFO - 2025-05-22 16:14:12 --> Config Class Initialized
INFO - 2025-05-22 16:14:12 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:14:12 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:14:12 --> Utf8 Class Initialized
INFO - 2025-05-22 16:14:12 --> URI Class Initialized
INFO - 2025-05-22 16:14:12 --> Router Class Initialized
INFO - 2025-05-22 16:14:12 --> Output Class Initialized
INFO - 2025-05-22 16:14:12 --> Security Class Initialized
DEBUG - 2025-05-22 16:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:14:12 --> Input Class Initialized
INFO - 2025-05-22 16:14:12 --> Language Class Initialized
INFO - 2025-05-22 16:14:12 --> Loader Class Initialized
INFO - 2025-05-22 16:14:12 --> Helper loaded: url_helper
INFO - 2025-05-22 16:14:12 --> Helper loaded: form_helper
INFO - 2025-05-22 16:14:12 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:14:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:14:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:14:12 --> Controller Class Initialized
INFO - 2025-05-22 16:14:12 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:14:12 --> Model "User_model" initialized
INFO - 2025-05-22 16:14:12 --> Final output sent to browser
DEBUG - 2025-05-22 16:14:12 --> Total execution time: 0.0733
INFO - 2025-05-22 16:14:49 --> Config Class Initialized
INFO - 2025-05-22 16:14:49 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:14:49 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:14:49 --> Utf8 Class Initialized
INFO - 2025-05-22 16:14:49 --> URI Class Initialized
INFO - 2025-05-22 16:14:49 --> Router Class Initialized
INFO - 2025-05-22 16:14:49 --> Output Class Initialized
INFO - 2025-05-22 16:14:49 --> Security Class Initialized
DEBUG - 2025-05-22 16:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:14:49 --> Input Class Initialized
INFO - 2025-05-22 16:14:49 --> Language Class Initialized
INFO - 2025-05-22 16:14:49 --> Loader Class Initialized
INFO - 2025-05-22 16:14:49 --> Helper loaded: url_helper
INFO - 2025-05-22 16:14:49 --> Helper loaded: form_helper
INFO - 2025-05-22 16:14:49 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:14:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:14:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:14:49 --> Controller Class Initialized
INFO - 2025-05-22 16:14:49 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:14:49 --> Model "User_model" initialized
INFO - 2025-05-22 16:14:49 --> Final output sent to browser
DEBUG - 2025-05-22 16:14:49 --> Total execution time: 0.1084
INFO - 2025-05-22 16:14:50 --> Config Class Initialized
INFO - 2025-05-22 16:14:50 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:14:50 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:14:50 --> Utf8 Class Initialized
INFO - 2025-05-22 16:14:50 --> URI Class Initialized
INFO - 2025-05-22 16:14:50 --> Router Class Initialized
INFO - 2025-05-22 16:14:50 --> Output Class Initialized
INFO - 2025-05-22 16:14:50 --> Security Class Initialized
DEBUG - 2025-05-22 16:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:14:50 --> Input Class Initialized
INFO - 2025-05-22 16:14:50 --> Language Class Initialized
INFO - 2025-05-22 16:14:50 --> Loader Class Initialized
INFO - 2025-05-22 16:14:50 --> Helper loaded: url_helper
INFO - 2025-05-22 16:14:50 --> Helper loaded: form_helper
INFO - 2025-05-22 16:14:50 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:14:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:14:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:14:50 --> Controller Class Initialized
INFO - 2025-05-22 16:14:50 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:14:50 --> Model "User_model" initialized
INFO - 2025-05-22 16:14:50 --> Final output sent to browser
DEBUG - 2025-05-22 16:14:50 --> Total execution time: 0.0698
INFO - 2025-05-22 16:19:58 --> Config Class Initialized
INFO - 2025-05-22 16:19:58 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:19:58 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:19:58 --> Utf8 Class Initialized
INFO - 2025-05-22 16:19:58 --> URI Class Initialized
INFO - 2025-05-22 16:19:58 --> Router Class Initialized
INFO - 2025-05-22 16:19:58 --> Output Class Initialized
INFO - 2025-05-22 16:19:58 --> Security Class Initialized
DEBUG - 2025-05-22 16:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:19:58 --> Input Class Initialized
INFO - 2025-05-22 16:19:58 --> Language Class Initialized
INFO - 2025-05-22 16:19:58 --> Loader Class Initialized
INFO - 2025-05-22 16:19:58 --> Helper loaded: url_helper
INFO - 2025-05-22 16:19:58 --> Helper loaded: form_helper
INFO - 2025-05-22 16:19:58 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:19:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:19:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:19:58 --> Controller Class Initialized
INFO - 2025-05-22 16:19:58 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:19:58 --> Model "User_model" initialized
INFO - 2025-05-22 16:19:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-22 16:19:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-22 16:19:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-22 16:19:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-22 16:19:58 --> Final output sent to browser
DEBUG - 2025-05-22 16:19:58 --> Total execution time: 0.0840
INFO - 2025-05-22 16:19:58 --> Config Class Initialized
INFO - 2025-05-22 16:19:58 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:19:58 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:19:58 --> Utf8 Class Initialized
INFO - 2025-05-22 16:19:58 --> URI Class Initialized
INFO - 2025-05-22 16:19:58 --> Router Class Initialized
INFO - 2025-05-22 16:19:58 --> Output Class Initialized
INFO - 2025-05-22 16:19:58 --> Security Class Initialized
DEBUG - 2025-05-22 16:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:19:58 --> Input Class Initialized
INFO - 2025-05-22 16:19:58 --> Language Class Initialized
INFO - 2025-05-22 16:19:58 --> Loader Class Initialized
INFO - 2025-05-22 16:19:58 --> Helper loaded: url_helper
INFO - 2025-05-22 16:19:58 --> Helper loaded: form_helper
INFO - 2025-05-22 16:19:58 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:19:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:19:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:19:58 --> Controller Class Initialized
INFO - 2025-05-22 16:19:58 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:19:58 --> Model "User_model" initialized
INFO - 2025-05-22 16:19:58 --> Final output sent to browser
DEBUG - 2025-05-22 16:19:58 --> Total execution time: 0.0646
INFO - 2025-05-22 16:22:34 --> Config Class Initialized
INFO - 2025-05-22 16:22:34 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:22:34 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:22:34 --> Utf8 Class Initialized
INFO - 2025-05-22 16:22:34 --> URI Class Initialized
INFO - 2025-05-22 16:22:34 --> Router Class Initialized
INFO - 2025-05-22 16:22:34 --> Output Class Initialized
INFO - 2025-05-22 16:22:34 --> Security Class Initialized
DEBUG - 2025-05-22 16:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:22:34 --> Input Class Initialized
INFO - 2025-05-22 16:22:34 --> Language Class Initialized
INFO - 2025-05-22 16:22:34 --> Loader Class Initialized
INFO - 2025-05-22 16:22:34 --> Helper loaded: url_helper
INFO - 2025-05-22 16:22:34 --> Helper loaded: form_helper
INFO - 2025-05-22 16:22:34 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:22:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:22:34 --> Controller Class Initialized
INFO - 2025-05-22 16:22:34 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:22:34 --> Model "User_model" initialized
INFO - 2025-05-22 16:22:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-22 16:22:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-22 16:22:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-22 16:22:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-22 16:22:34 --> Final output sent to browser
DEBUG - 2025-05-22 16:22:34 --> Total execution time: 0.0775
INFO - 2025-05-22 16:22:35 --> Config Class Initialized
INFO - 2025-05-22 16:22:35 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:22:35 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:22:35 --> Utf8 Class Initialized
INFO - 2025-05-22 16:22:35 --> URI Class Initialized
INFO - 2025-05-22 16:22:35 --> Router Class Initialized
INFO - 2025-05-22 16:22:35 --> Output Class Initialized
INFO - 2025-05-22 16:22:35 --> Security Class Initialized
DEBUG - 2025-05-22 16:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:22:35 --> Input Class Initialized
INFO - 2025-05-22 16:22:35 --> Language Class Initialized
INFO - 2025-05-22 16:22:35 --> Loader Class Initialized
INFO - 2025-05-22 16:22:35 --> Helper loaded: url_helper
INFO - 2025-05-22 16:22:35 --> Helper loaded: form_helper
INFO - 2025-05-22 16:22:35 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:22:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:22:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:22:35 --> Controller Class Initialized
INFO - 2025-05-22 16:22:35 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:22:35 --> Model "User_model" initialized
INFO - 2025-05-22 16:22:35 --> Final output sent to browser
DEBUG - 2025-05-22 16:22:35 --> Total execution time: 0.0696
INFO - 2025-05-22 16:23:19 --> Config Class Initialized
INFO - 2025-05-22 16:23:19 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:23:19 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:23:19 --> Utf8 Class Initialized
INFO - 2025-05-22 16:23:19 --> URI Class Initialized
INFO - 2025-05-22 16:23:19 --> Router Class Initialized
INFO - 2025-05-22 16:23:19 --> Output Class Initialized
INFO - 2025-05-22 16:23:19 --> Security Class Initialized
DEBUG - 2025-05-22 16:23:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:23:19 --> Input Class Initialized
INFO - 2025-05-22 16:23:19 --> Language Class Initialized
INFO - 2025-05-22 16:23:19 --> Loader Class Initialized
INFO - 2025-05-22 16:23:19 --> Helper loaded: url_helper
INFO - 2025-05-22 16:23:19 --> Helper loaded: form_helper
INFO - 2025-05-22 16:23:19 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:23:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:23:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:23:19 --> Controller Class Initialized
INFO - 2025-05-22 16:23:19 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:23:19 --> Model "User_model" initialized
INFO - 2025-05-22 16:23:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-22 16:23:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-22 16:23:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-22 16:23:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-22 16:23:19 --> Final output sent to browser
DEBUG - 2025-05-22 16:23:19 --> Total execution time: 0.0744
INFO - 2025-05-22 16:23:19 --> Config Class Initialized
INFO - 2025-05-22 16:23:19 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:23:19 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:23:19 --> Utf8 Class Initialized
INFO - 2025-05-22 16:23:19 --> URI Class Initialized
INFO - 2025-05-22 16:23:19 --> Router Class Initialized
INFO - 2025-05-22 16:23:19 --> Output Class Initialized
INFO - 2025-05-22 16:23:19 --> Security Class Initialized
DEBUG - 2025-05-22 16:23:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:23:19 --> Input Class Initialized
INFO - 2025-05-22 16:23:19 --> Language Class Initialized
INFO - 2025-05-22 16:23:19 --> Loader Class Initialized
INFO - 2025-05-22 16:23:19 --> Helper loaded: url_helper
INFO - 2025-05-22 16:23:19 --> Helper loaded: form_helper
INFO - 2025-05-22 16:23:19 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:23:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:23:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:23:19 --> Controller Class Initialized
INFO - 2025-05-22 16:23:19 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:23:19 --> Model "User_model" initialized
INFO - 2025-05-22 16:23:19 --> Final output sent to browser
DEBUG - 2025-05-22 16:23:19 --> Total execution time: 0.0865
INFO - 2025-05-22 16:23:36 --> Config Class Initialized
INFO - 2025-05-22 16:23:36 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:23:36 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:23:36 --> Utf8 Class Initialized
INFO - 2025-05-22 16:23:36 --> URI Class Initialized
INFO - 2025-05-22 16:23:36 --> Router Class Initialized
INFO - 2025-05-22 16:23:36 --> Output Class Initialized
INFO - 2025-05-22 16:23:36 --> Security Class Initialized
DEBUG - 2025-05-22 16:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:23:36 --> Input Class Initialized
INFO - 2025-05-22 16:23:36 --> Language Class Initialized
INFO - 2025-05-22 16:23:36 --> Loader Class Initialized
INFO - 2025-05-22 16:23:36 --> Helper loaded: url_helper
INFO - 2025-05-22 16:23:36 --> Helper loaded: form_helper
INFO - 2025-05-22 16:23:36 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:23:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:23:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:23:36 --> Controller Class Initialized
INFO - 2025-05-22 16:23:36 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:23:36 --> Model "User_model" initialized
INFO - 2025-05-22 16:23:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-22 16:23:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-22 16:23:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-22 16:23:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-22 16:23:36 --> Final output sent to browser
DEBUG - 2025-05-22 16:23:36 --> Total execution time: 0.0801
INFO - 2025-05-22 16:23:36 --> Config Class Initialized
INFO - 2025-05-22 16:23:36 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:23:36 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:23:36 --> Utf8 Class Initialized
INFO - 2025-05-22 16:23:36 --> URI Class Initialized
INFO - 2025-05-22 16:23:36 --> Router Class Initialized
INFO - 2025-05-22 16:23:36 --> Output Class Initialized
INFO - 2025-05-22 16:23:36 --> Security Class Initialized
DEBUG - 2025-05-22 16:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:23:36 --> Input Class Initialized
INFO - 2025-05-22 16:23:36 --> Language Class Initialized
INFO - 2025-05-22 16:23:36 --> Loader Class Initialized
INFO - 2025-05-22 16:23:36 --> Helper loaded: url_helper
INFO - 2025-05-22 16:23:36 --> Helper loaded: form_helper
INFO - 2025-05-22 16:23:36 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:23:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:23:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:23:36 --> Controller Class Initialized
INFO - 2025-05-22 16:23:36 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:23:36 --> Model "User_model" initialized
INFO - 2025-05-22 16:23:36 --> Final output sent to browser
DEBUG - 2025-05-22 16:23:36 --> Total execution time: 0.0828
INFO - 2025-05-22 16:25:59 --> Config Class Initialized
INFO - 2025-05-22 16:25:59 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:25:59 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:25:59 --> Utf8 Class Initialized
INFO - 2025-05-22 16:25:59 --> URI Class Initialized
INFO - 2025-05-22 16:25:59 --> Router Class Initialized
INFO - 2025-05-22 16:25:59 --> Output Class Initialized
INFO - 2025-05-22 16:25:59 --> Security Class Initialized
DEBUG - 2025-05-22 16:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:26:00 --> Input Class Initialized
INFO - 2025-05-22 16:26:00 --> Language Class Initialized
INFO - 2025-05-22 16:26:00 --> Loader Class Initialized
INFO - 2025-05-22 16:26:00 --> Helper loaded: url_helper
INFO - 2025-05-22 16:26:00 --> Helper loaded: form_helper
INFO - 2025-05-22 16:26:00 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:26:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:26:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:26:00 --> Controller Class Initialized
INFO - 2025-05-22 16:26:00 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:26:00 --> Model "User_model" initialized
INFO - 2025-05-22 16:26:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-22 16:26:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-22 16:26:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-22 16:26:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-22 16:26:00 --> Final output sent to browser
DEBUG - 2025-05-22 16:26:00 --> Total execution time: 0.1084
INFO - 2025-05-22 16:26:00 --> Config Class Initialized
INFO - 2025-05-22 16:26:00 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:26:00 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:26:00 --> Utf8 Class Initialized
INFO - 2025-05-22 16:26:00 --> URI Class Initialized
INFO - 2025-05-22 16:26:00 --> Router Class Initialized
INFO - 2025-05-22 16:26:00 --> Output Class Initialized
INFO - 2025-05-22 16:26:00 --> Security Class Initialized
DEBUG - 2025-05-22 16:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:26:00 --> Input Class Initialized
INFO - 2025-05-22 16:26:00 --> Language Class Initialized
INFO - 2025-05-22 16:26:00 --> Loader Class Initialized
INFO - 2025-05-22 16:26:00 --> Helper loaded: url_helper
INFO - 2025-05-22 16:26:00 --> Helper loaded: form_helper
INFO - 2025-05-22 16:26:00 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:26:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:26:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:26:00 --> Controller Class Initialized
INFO - 2025-05-22 16:26:00 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:26:00 --> Model "User_model" initialized
INFO - 2025-05-22 16:26:00 --> Final output sent to browser
DEBUG - 2025-05-22 16:26:00 --> Total execution time: 0.0844
INFO - 2025-05-22 16:26:18 --> Config Class Initialized
INFO - 2025-05-22 16:26:18 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:26:18 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:26:18 --> Utf8 Class Initialized
INFO - 2025-05-22 16:26:18 --> URI Class Initialized
INFO - 2025-05-22 16:26:18 --> Router Class Initialized
INFO - 2025-05-22 16:26:18 --> Output Class Initialized
INFO - 2025-05-22 16:26:18 --> Security Class Initialized
DEBUG - 2025-05-22 16:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:26:18 --> Input Class Initialized
INFO - 2025-05-22 16:26:18 --> Language Class Initialized
INFO - 2025-05-22 16:26:18 --> Loader Class Initialized
INFO - 2025-05-22 16:26:18 --> Helper loaded: url_helper
INFO - 2025-05-22 16:26:18 --> Helper loaded: form_helper
INFO - 2025-05-22 16:26:18 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:26:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:26:18 --> Controller Class Initialized
INFO - 2025-05-22 16:26:18 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:26:18 --> Model "User_model" initialized
INFO - 2025-05-22 16:26:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-22 16:26:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-22 16:26:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-22 16:26:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-22 16:26:18 --> Final output sent to browser
DEBUG - 2025-05-22 16:26:18 --> Total execution time: 0.0846
INFO - 2025-05-22 16:26:18 --> Config Class Initialized
INFO - 2025-05-22 16:26:18 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:26:18 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:26:18 --> Utf8 Class Initialized
INFO - 2025-05-22 16:26:18 --> URI Class Initialized
INFO - 2025-05-22 16:26:18 --> Router Class Initialized
INFO - 2025-05-22 16:26:18 --> Output Class Initialized
INFO - 2025-05-22 16:26:18 --> Security Class Initialized
DEBUG - 2025-05-22 16:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:26:18 --> Input Class Initialized
INFO - 2025-05-22 16:26:18 --> Language Class Initialized
INFO - 2025-05-22 16:26:18 --> Loader Class Initialized
INFO - 2025-05-22 16:26:18 --> Helper loaded: url_helper
INFO - 2025-05-22 16:26:18 --> Helper loaded: form_helper
INFO - 2025-05-22 16:26:18 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:26:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:26:18 --> Controller Class Initialized
INFO - 2025-05-22 16:26:18 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:26:18 --> Model "User_model" initialized
INFO - 2025-05-22 16:26:18 --> Final output sent to browser
DEBUG - 2025-05-22 16:26:18 --> Total execution time: 0.0830
INFO - 2025-05-22 16:26:44 --> Config Class Initialized
INFO - 2025-05-22 16:26:44 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:26:44 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:26:44 --> Utf8 Class Initialized
INFO - 2025-05-22 16:26:44 --> URI Class Initialized
INFO - 2025-05-22 16:26:44 --> Router Class Initialized
INFO - 2025-05-22 16:26:44 --> Output Class Initialized
INFO - 2025-05-22 16:26:44 --> Security Class Initialized
DEBUG - 2025-05-22 16:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:26:44 --> Input Class Initialized
INFO - 2025-05-22 16:26:44 --> Language Class Initialized
INFO - 2025-05-22 16:26:44 --> Loader Class Initialized
INFO - 2025-05-22 16:26:44 --> Helper loaded: url_helper
INFO - 2025-05-22 16:26:44 --> Helper loaded: form_helper
INFO - 2025-05-22 16:26:44 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:26:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:26:44 --> Controller Class Initialized
INFO - 2025-05-22 16:26:44 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:26:44 --> Model "User_model" initialized
INFO - 2025-05-22 16:26:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-22 16:26:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-22 16:26:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-22 16:26:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-22 16:26:44 --> Final output sent to browser
DEBUG - 2025-05-22 16:26:44 --> Total execution time: 0.0767
INFO - 2025-05-22 16:26:44 --> Config Class Initialized
INFO - 2025-05-22 16:26:44 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:26:44 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:26:44 --> Utf8 Class Initialized
INFO - 2025-05-22 16:26:44 --> URI Class Initialized
INFO - 2025-05-22 16:26:44 --> Router Class Initialized
INFO - 2025-05-22 16:26:44 --> Output Class Initialized
INFO - 2025-05-22 16:26:44 --> Security Class Initialized
DEBUG - 2025-05-22 16:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:26:44 --> Input Class Initialized
INFO - 2025-05-22 16:26:44 --> Language Class Initialized
INFO - 2025-05-22 16:26:44 --> Loader Class Initialized
INFO - 2025-05-22 16:26:44 --> Helper loaded: url_helper
INFO - 2025-05-22 16:26:44 --> Helper loaded: form_helper
INFO - 2025-05-22 16:26:44 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:26:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:26:44 --> Controller Class Initialized
INFO - 2025-05-22 16:26:44 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:26:44 --> Model "User_model" initialized
INFO - 2025-05-22 16:26:44 --> Final output sent to browser
DEBUG - 2025-05-22 16:26:44 --> Total execution time: 0.0817
INFO - 2025-05-22 16:26:57 --> Config Class Initialized
INFO - 2025-05-22 16:26:57 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:26:57 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:26:57 --> Utf8 Class Initialized
INFO - 2025-05-22 16:26:57 --> URI Class Initialized
INFO - 2025-05-22 16:26:57 --> Router Class Initialized
INFO - 2025-05-22 16:26:57 --> Output Class Initialized
INFO - 2025-05-22 16:26:57 --> Security Class Initialized
DEBUG - 2025-05-22 16:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:26:57 --> Input Class Initialized
INFO - 2025-05-22 16:26:57 --> Language Class Initialized
INFO - 2025-05-22 16:26:57 --> Loader Class Initialized
INFO - 2025-05-22 16:26:57 --> Helper loaded: url_helper
INFO - 2025-05-22 16:26:57 --> Helper loaded: form_helper
INFO - 2025-05-22 16:26:57 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:26:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:26:57 --> Controller Class Initialized
INFO - 2025-05-22 16:26:57 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:26:57 --> Model "User_model" initialized
INFO - 2025-05-22 16:26:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-22 16:26:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-22 16:26:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-22 16:26:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-22 16:26:57 --> Final output sent to browser
DEBUG - 2025-05-22 16:26:57 --> Total execution time: 0.0695
INFO - 2025-05-22 16:26:57 --> Config Class Initialized
INFO - 2025-05-22 16:26:57 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:26:57 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:26:57 --> Utf8 Class Initialized
INFO - 2025-05-22 16:26:57 --> URI Class Initialized
INFO - 2025-05-22 16:26:57 --> Router Class Initialized
INFO - 2025-05-22 16:26:57 --> Output Class Initialized
INFO - 2025-05-22 16:26:57 --> Security Class Initialized
DEBUG - 2025-05-22 16:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:26:57 --> Input Class Initialized
INFO - 2025-05-22 16:26:57 --> Language Class Initialized
INFO - 2025-05-22 16:26:57 --> Loader Class Initialized
INFO - 2025-05-22 16:26:57 --> Helper loaded: url_helper
INFO - 2025-05-22 16:26:57 --> Helper loaded: form_helper
INFO - 2025-05-22 16:26:57 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:26:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:26:57 --> Controller Class Initialized
INFO - 2025-05-22 16:26:57 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:26:57 --> Model "User_model" initialized
INFO - 2025-05-22 16:26:57 --> Final output sent to browser
DEBUG - 2025-05-22 16:26:57 --> Total execution time: 0.0831
INFO - 2025-05-22 16:27:05 --> Config Class Initialized
INFO - 2025-05-22 16:27:05 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:27:05 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:27:05 --> Utf8 Class Initialized
INFO - 2025-05-22 16:27:05 --> URI Class Initialized
INFO - 2025-05-22 16:27:05 --> Router Class Initialized
INFO - 2025-05-22 16:27:05 --> Output Class Initialized
INFO - 2025-05-22 16:27:05 --> Security Class Initialized
DEBUG - 2025-05-22 16:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:27:05 --> Input Class Initialized
INFO - 2025-05-22 16:27:05 --> Language Class Initialized
INFO - 2025-05-22 16:27:05 --> Loader Class Initialized
INFO - 2025-05-22 16:27:05 --> Helper loaded: url_helper
INFO - 2025-05-22 16:27:05 --> Helper loaded: form_helper
INFO - 2025-05-22 16:27:05 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:27:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:27:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:27:05 --> Controller Class Initialized
INFO - 2025-05-22 16:27:05 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:27:05 --> Model "User_model" initialized
INFO - 2025-05-22 16:27:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-22 16:27:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-22 16:27:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-22 16:27:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-22 16:27:05 --> Final output sent to browser
DEBUG - 2025-05-22 16:27:05 --> Total execution time: 0.0747
INFO - 2025-05-22 16:27:05 --> Config Class Initialized
INFO - 2025-05-22 16:27:05 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:27:05 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:27:05 --> Utf8 Class Initialized
INFO - 2025-05-22 16:27:05 --> URI Class Initialized
INFO - 2025-05-22 16:27:05 --> Router Class Initialized
INFO - 2025-05-22 16:27:05 --> Output Class Initialized
INFO - 2025-05-22 16:27:05 --> Security Class Initialized
DEBUG - 2025-05-22 16:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:27:05 --> Input Class Initialized
INFO - 2025-05-22 16:27:05 --> Language Class Initialized
INFO - 2025-05-22 16:27:05 --> Loader Class Initialized
INFO - 2025-05-22 16:27:05 --> Helper loaded: url_helper
INFO - 2025-05-22 16:27:05 --> Helper loaded: form_helper
INFO - 2025-05-22 16:27:05 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:27:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:27:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:27:05 --> Controller Class Initialized
INFO - 2025-05-22 16:27:05 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:27:05 --> Model "User_model" initialized
INFO - 2025-05-22 16:27:05 --> Final output sent to browser
DEBUG - 2025-05-22 16:27:05 --> Total execution time: 0.0631
INFO - 2025-05-22 16:27:13 --> Config Class Initialized
INFO - 2025-05-22 16:27:13 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:27:13 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:27:13 --> Utf8 Class Initialized
INFO - 2025-05-22 16:27:13 --> URI Class Initialized
INFO - 2025-05-22 16:27:13 --> Router Class Initialized
INFO - 2025-05-22 16:27:13 --> Output Class Initialized
INFO - 2025-05-22 16:27:13 --> Security Class Initialized
DEBUG - 2025-05-22 16:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:27:13 --> Input Class Initialized
INFO - 2025-05-22 16:27:13 --> Language Class Initialized
INFO - 2025-05-22 16:27:13 --> Loader Class Initialized
INFO - 2025-05-22 16:27:13 --> Helper loaded: url_helper
INFO - 2025-05-22 16:27:13 --> Helper loaded: form_helper
INFO - 2025-05-22 16:27:13 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:27:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:27:13 --> Controller Class Initialized
INFO - 2025-05-22 16:27:13 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:27:13 --> Model "User_model" initialized
INFO - 2025-05-22 16:27:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-22 16:27:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-22 16:27:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-22 16:27:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-22 16:27:13 --> Final output sent to browser
DEBUG - 2025-05-22 16:27:13 --> Total execution time: 0.0730
INFO - 2025-05-22 16:27:13 --> Config Class Initialized
INFO - 2025-05-22 16:27:13 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:27:13 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:27:13 --> Utf8 Class Initialized
INFO - 2025-05-22 16:27:13 --> URI Class Initialized
INFO - 2025-05-22 16:27:13 --> Router Class Initialized
INFO - 2025-05-22 16:27:13 --> Output Class Initialized
INFO - 2025-05-22 16:27:13 --> Security Class Initialized
DEBUG - 2025-05-22 16:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:27:13 --> Input Class Initialized
INFO - 2025-05-22 16:27:13 --> Language Class Initialized
INFO - 2025-05-22 16:27:13 --> Loader Class Initialized
INFO - 2025-05-22 16:27:13 --> Helper loaded: url_helper
INFO - 2025-05-22 16:27:13 --> Helper loaded: form_helper
INFO - 2025-05-22 16:27:13 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:27:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:27:13 --> Controller Class Initialized
INFO - 2025-05-22 16:27:13 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:27:13 --> Model "User_model" initialized
INFO - 2025-05-22 16:27:13 --> Final output sent to browser
DEBUG - 2025-05-22 16:27:13 --> Total execution time: 0.0669
INFO - 2025-05-22 16:27:31 --> Config Class Initialized
INFO - 2025-05-22 16:27:31 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:27:31 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:27:31 --> Utf8 Class Initialized
INFO - 2025-05-22 16:27:31 --> URI Class Initialized
INFO - 2025-05-22 16:27:31 --> Router Class Initialized
INFO - 2025-05-22 16:27:31 --> Output Class Initialized
INFO - 2025-05-22 16:27:31 --> Security Class Initialized
DEBUG - 2025-05-22 16:27:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:27:31 --> Input Class Initialized
INFO - 2025-05-22 16:27:31 --> Language Class Initialized
INFO - 2025-05-22 16:27:31 --> Loader Class Initialized
INFO - 2025-05-22 16:27:31 --> Helper loaded: url_helper
INFO - 2025-05-22 16:27:31 --> Helper loaded: form_helper
INFO - 2025-05-22 16:27:31 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:27:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:27:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:27:31 --> Controller Class Initialized
INFO - 2025-05-22 16:27:31 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:27:31 --> Model "User_model" initialized
INFO - 2025-05-22 16:27:31 --> Final output sent to browser
DEBUG - 2025-05-22 16:27:31 --> Total execution time: 0.0634
INFO - 2025-05-22 16:28:12 --> Config Class Initialized
INFO - 2025-05-22 16:28:12 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:28:12 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:28:12 --> Utf8 Class Initialized
INFO - 2025-05-22 16:28:12 --> URI Class Initialized
INFO - 2025-05-22 16:28:12 --> Router Class Initialized
INFO - 2025-05-22 16:28:12 --> Output Class Initialized
INFO - 2025-05-22 16:28:12 --> Security Class Initialized
DEBUG - 2025-05-22 16:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:28:12 --> Input Class Initialized
INFO - 2025-05-22 16:28:12 --> Language Class Initialized
INFO - 2025-05-22 16:28:12 --> Loader Class Initialized
INFO - 2025-05-22 16:28:12 --> Helper loaded: url_helper
INFO - 2025-05-22 16:28:12 --> Helper loaded: form_helper
INFO - 2025-05-22 16:28:12 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:28:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:28:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:28:12 --> Controller Class Initialized
INFO - 2025-05-22 16:28:12 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:28:12 --> Model "User_model" initialized
INFO - 2025-05-22 16:28:12 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-22 16:28:12 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-22 16:28:12 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-22 16:28:12 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-22 16:28:12 --> Final output sent to browser
DEBUG - 2025-05-22 16:28:12 --> Total execution time: 0.0785
INFO - 2025-05-22 16:28:12 --> Config Class Initialized
INFO - 2025-05-22 16:28:12 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:28:12 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:28:12 --> Utf8 Class Initialized
INFO - 2025-05-22 16:28:12 --> URI Class Initialized
INFO - 2025-05-22 16:28:12 --> Router Class Initialized
INFO - 2025-05-22 16:28:12 --> Output Class Initialized
INFO - 2025-05-22 16:28:12 --> Security Class Initialized
DEBUG - 2025-05-22 16:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:28:12 --> Input Class Initialized
INFO - 2025-05-22 16:28:12 --> Language Class Initialized
INFO - 2025-05-22 16:28:12 --> Loader Class Initialized
INFO - 2025-05-22 16:28:12 --> Helper loaded: url_helper
INFO - 2025-05-22 16:28:12 --> Helper loaded: form_helper
INFO - 2025-05-22 16:28:12 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:28:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:28:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:28:12 --> Controller Class Initialized
INFO - 2025-05-22 16:28:12 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:28:12 --> Model "User_model" initialized
INFO - 2025-05-22 16:28:12 --> Final output sent to browser
DEBUG - 2025-05-22 16:28:12 --> Total execution time: 0.0722
INFO - 2025-05-22 16:28:14 --> Config Class Initialized
INFO - 2025-05-22 16:28:14 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:28:14 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:28:14 --> Utf8 Class Initialized
INFO - 2025-05-22 16:28:14 --> URI Class Initialized
INFO - 2025-05-22 16:28:14 --> Router Class Initialized
INFO - 2025-05-22 16:28:14 --> Output Class Initialized
INFO - 2025-05-22 16:28:14 --> Security Class Initialized
DEBUG - 2025-05-22 16:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:28:14 --> Input Class Initialized
INFO - 2025-05-22 16:28:14 --> Language Class Initialized
INFO - 2025-05-22 16:28:14 --> Loader Class Initialized
INFO - 2025-05-22 16:28:14 --> Helper loaded: url_helper
INFO - 2025-05-22 16:28:14 --> Helper loaded: form_helper
INFO - 2025-05-22 16:28:14 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:28:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:28:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:28:14 --> Controller Class Initialized
INFO - 2025-05-22 16:28:14 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:28:14 --> Model "User_model" initialized
INFO - 2025-05-22 16:28:14 --> Final output sent to browser
DEBUG - 2025-05-22 16:28:14 --> Total execution time: 0.0700
INFO - 2025-05-22 16:28:41 --> Config Class Initialized
INFO - 2025-05-22 16:28:41 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:28:41 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:28:41 --> Utf8 Class Initialized
INFO - 2025-05-22 16:28:41 --> URI Class Initialized
INFO - 2025-05-22 16:28:41 --> Router Class Initialized
INFO - 2025-05-22 16:28:41 --> Output Class Initialized
INFO - 2025-05-22 16:28:41 --> Security Class Initialized
DEBUG - 2025-05-22 16:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:28:41 --> Input Class Initialized
INFO - 2025-05-22 16:28:41 --> Language Class Initialized
INFO - 2025-05-22 16:28:41 --> Loader Class Initialized
INFO - 2025-05-22 16:28:41 --> Helper loaded: url_helper
INFO - 2025-05-22 16:28:41 --> Helper loaded: form_helper
INFO - 2025-05-22 16:28:41 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:28:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:28:41 --> Controller Class Initialized
INFO - 2025-05-22 16:28:41 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:28:41 --> Model "User_model" initialized
INFO - 2025-05-22 16:28:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-22 16:28:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-22 16:28:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-22 16:28:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-22 16:28:41 --> Final output sent to browser
DEBUG - 2025-05-22 16:28:41 --> Total execution time: 0.0822
INFO - 2025-05-22 16:28:41 --> Config Class Initialized
INFO - 2025-05-22 16:28:41 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:28:41 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:28:41 --> Utf8 Class Initialized
INFO - 2025-05-22 16:28:41 --> URI Class Initialized
INFO - 2025-05-22 16:28:41 --> Router Class Initialized
INFO - 2025-05-22 16:28:41 --> Output Class Initialized
INFO - 2025-05-22 16:28:41 --> Security Class Initialized
DEBUG - 2025-05-22 16:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:28:41 --> Input Class Initialized
INFO - 2025-05-22 16:28:41 --> Language Class Initialized
INFO - 2025-05-22 16:28:41 --> Loader Class Initialized
INFO - 2025-05-22 16:28:41 --> Helper loaded: url_helper
INFO - 2025-05-22 16:28:41 --> Helper loaded: form_helper
INFO - 2025-05-22 16:28:41 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:28:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:28:41 --> Controller Class Initialized
INFO - 2025-05-22 16:28:41 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:28:41 --> Model "User_model" initialized
INFO - 2025-05-22 16:28:41 --> Final output sent to browser
DEBUG - 2025-05-22 16:28:41 --> Total execution time: 0.0682
INFO - 2025-05-22 16:28:43 --> Config Class Initialized
INFO - 2025-05-22 16:28:43 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:28:43 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:28:43 --> Utf8 Class Initialized
INFO - 2025-05-22 16:28:43 --> URI Class Initialized
INFO - 2025-05-22 16:28:43 --> Router Class Initialized
INFO - 2025-05-22 16:28:43 --> Output Class Initialized
INFO - 2025-05-22 16:28:43 --> Security Class Initialized
DEBUG - 2025-05-22 16:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:28:43 --> Input Class Initialized
INFO - 2025-05-22 16:28:43 --> Language Class Initialized
INFO - 2025-05-22 16:28:43 --> Loader Class Initialized
INFO - 2025-05-22 16:28:43 --> Helper loaded: url_helper
INFO - 2025-05-22 16:28:43 --> Helper loaded: form_helper
INFO - 2025-05-22 16:28:43 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:28:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:28:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:28:43 --> Controller Class Initialized
INFO - 2025-05-22 16:28:43 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:28:43 --> Model "User_model" initialized
INFO - 2025-05-22 16:28:43 --> Final output sent to browser
DEBUG - 2025-05-22 16:28:43 --> Total execution time: 0.0629
INFO - 2025-05-22 16:30:46 --> Config Class Initialized
INFO - 2025-05-22 16:30:46 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:30:46 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:30:46 --> Utf8 Class Initialized
INFO - 2025-05-22 16:30:46 --> URI Class Initialized
INFO - 2025-05-22 16:30:46 --> Router Class Initialized
INFO - 2025-05-22 16:30:46 --> Output Class Initialized
INFO - 2025-05-22 16:30:46 --> Security Class Initialized
DEBUG - 2025-05-22 16:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:30:46 --> Input Class Initialized
INFO - 2025-05-22 16:30:46 --> Language Class Initialized
INFO - 2025-05-22 16:30:46 --> Loader Class Initialized
INFO - 2025-05-22 16:30:46 --> Helper loaded: url_helper
INFO - 2025-05-22 16:30:46 --> Helper loaded: form_helper
INFO - 2025-05-22 16:30:46 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:30:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:30:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:30:46 --> Controller Class Initialized
INFO - 2025-05-22 16:30:46 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:30:46 --> Model "User_model" initialized
INFO - 2025-05-22 16:30:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-22 16:30:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-22 16:30:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-22 16:30:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-22 16:30:46 --> Final output sent to browser
DEBUG - 2025-05-22 16:30:46 --> Total execution time: 0.0879
INFO - 2025-05-22 16:30:46 --> Config Class Initialized
INFO - 2025-05-22 16:30:46 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:30:46 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:30:46 --> Utf8 Class Initialized
INFO - 2025-05-22 16:30:46 --> URI Class Initialized
INFO - 2025-05-22 16:30:46 --> Router Class Initialized
INFO - 2025-05-22 16:30:46 --> Output Class Initialized
INFO - 2025-05-22 16:30:46 --> Security Class Initialized
DEBUG - 2025-05-22 16:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:30:46 --> Input Class Initialized
INFO - 2025-05-22 16:30:46 --> Language Class Initialized
INFO - 2025-05-22 16:30:46 --> Loader Class Initialized
INFO - 2025-05-22 16:30:46 --> Helper loaded: url_helper
INFO - 2025-05-22 16:30:46 --> Helper loaded: form_helper
INFO - 2025-05-22 16:30:46 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:30:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:30:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:30:46 --> Controller Class Initialized
INFO - 2025-05-22 16:30:46 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:30:46 --> Model "User_model" initialized
INFO - 2025-05-22 16:30:46 --> Final output sent to browser
DEBUG - 2025-05-22 16:30:46 --> Total execution time: 0.0876
INFO - 2025-05-22 16:30:48 --> Config Class Initialized
INFO - 2025-05-22 16:30:48 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:30:48 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:30:48 --> Utf8 Class Initialized
INFO - 2025-05-22 16:30:48 --> URI Class Initialized
INFO - 2025-05-22 16:30:48 --> Router Class Initialized
INFO - 2025-05-22 16:30:48 --> Output Class Initialized
INFO - 2025-05-22 16:30:48 --> Security Class Initialized
DEBUG - 2025-05-22 16:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:30:48 --> Input Class Initialized
INFO - 2025-05-22 16:30:48 --> Language Class Initialized
INFO - 2025-05-22 16:30:48 --> Loader Class Initialized
INFO - 2025-05-22 16:30:48 --> Helper loaded: url_helper
INFO - 2025-05-22 16:30:48 --> Helper loaded: form_helper
INFO - 2025-05-22 16:30:48 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:30:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:30:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:30:48 --> Controller Class Initialized
INFO - 2025-05-22 16:30:48 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:30:48 --> Model "User_model" initialized
INFO - 2025-05-22 16:30:48 --> Final output sent to browser
DEBUG - 2025-05-22 16:30:48 --> Total execution time: 0.0673
INFO - 2025-05-22 16:31:24 --> Config Class Initialized
INFO - 2025-05-22 16:31:24 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:31:24 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:31:24 --> Utf8 Class Initialized
INFO - 2025-05-22 16:31:24 --> URI Class Initialized
INFO - 2025-05-22 16:31:24 --> Router Class Initialized
INFO - 2025-05-22 16:31:24 --> Output Class Initialized
INFO - 2025-05-22 16:31:24 --> Security Class Initialized
DEBUG - 2025-05-22 16:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:31:24 --> Input Class Initialized
INFO - 2025-05-22 16:31:24 --> Language Class Initialized
INFO - 2025-05-22 16:31:24 --> Loader Class Initialized
INFO - 2025-05-22 16:31:24 --> Helper loaded: url_helper
INFO - 2025-05-22 16:31:24 --> Helper loaded: form_helper
INFO - 2025-05-22 16:31:24 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:31:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:31:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:31:24 --> Controller Class Initialized
INFO - 2025-05-22 16:31:24 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:31:24 --> Model "User_model" initialized
INFO - 2025-05-22 16:31:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-22 16:31:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-22 16:31:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-22 16:31:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-22 16:31:24 --> Final output sent to browser
DEBUG - 2025-05-22 16:31:24 --> Total execution time: 0.0927
INFO - 2025-05-22 16:31:24 --> Config Class Initialized
INFO - 2025-05-22 16:31:24 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:31:24 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:31:24 --> Utf8 Class Initialized
INFO - 2025-05-22 16:31:24 --> URI Class Initialized
INFO - 2025-05-22 16:31:24 --> Router Class Initialized
INFO - 2025-05-22 16:31:24 --> Output Class Initialized
INFO - 2025-05-22 16:31:24 --> Security Class Initialized
DEBUG - 2025-05-22 16:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:31:24 --> Input Class Initialized
INFO - 2025-05-22 16:31:24 --> Language Class Initialized
INFO - 2025-05-22 16:31:24 --> Loader Class Initialized
INFO - 2025-05-22 16:31:24 --> Helper loaded: url_helper
INFO - 2025-05-22 16:31:24 --> Helper loaded: form_helper
INFO - 2025-05-22 16:31:24 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:31:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:31:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:31:24 --> Controller Class Initialized
INFO - 2025-05-22 16:31:24 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:31:24 --> Model "User_model" initialized
INFO - 2025-05-22 16:31:24 --> Final output sent to browser
DEBUG - 2025-05-22 16:31:24 --> Total execution time: 0.0670
INFO - 2025-05-22 16:31:57 --> Config Class Initialized
INFO - 2025-05-22 16:31:57 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:31:57 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:31:57 --> Utf8 Class Initialized
INFO - 2025-05-22 16:31:57 --> URI Class Initialized
INFO - 2025-05-22 16:31:57 --> Router Class Initialized
INFO - 2025-05-22 16:31:57 --> Output Class Initialized
INFO - 2025-05-22 16:31:57 --> Security Class Initialized
DEBUG - 2025-05-22 16:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:31:57 --> Input Class Initialized
INFO - 2025-05-22 16:31:57 --> Language Class Initialized
INFO - 2025-05-22 16:31:57 --> Loader Class Initialized
INFO - 2025-05-22 16:31:57 --> Helper loaded: url_helper
INFO - 2025-05-22 16:31:57 --> Helper loaded: form_helper
INFO - 2025-05-22 16:31:57 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:31:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:31:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:31:57 --> Controller Class Initialized
INFO - 2025-05-22 16:31:57 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:31:57 --> Model "User_model" initialized
INFO - 2025-05-22 16:31:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-22 16:31:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-22 16:31:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-22 16:31:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-22 16:31:57 --> Final output sent to browser
DEBUG - 2025-05-22 16:31:57 --> Total execution time: 0.0785
INFO - 2025-05-22 16:31:57 --> Config Class Initialized
INFO - 2025-05-22 16:31:57 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:31:57 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:31:57 --> Utf8 Class Initialized
INFO - 2025-05-22 16:31:57 --> URI Class Initialized
INFO - 2025-05-22 16:31:57 --> Router Class Initialized
INFO - 2025-05-22 16:31:57 --> Output Class Initialized
INFO - 2025-05-22 16:31:57 --> Security Class Initialized
DEBUG - 2025-05-22 16:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:31:57 --> Input Class Initialized
INFO - 2025-05-22 16:31:57 --> Language Class Initialized
INFO - 2025-05-22 16:31:57 --> Loader Class Initialized
INFO - 2025-05-22 16:31:57 --> Helper loaded: url_helper
INFO - 2025-05-22 16:31:57 --> Helper loaded: form_helper
INFO - 2025-05-22 16:31:57 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:31:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:31:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:31:57 --> Controller Class Initialized
INFO - 2025-05-22 16:31:57 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:31:57 --> Model "User_model" initialized
INFO - 2025-05-22 16:31:57 --> Final output sent to browser
DEBUG - 2025-05-22 16:31:57 --> Total execution time: 0.0825
INFO - 2025-05-22 16:32:23 --> Config Class Initialized
INFO - 2025-05-22 16:32:23 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:32:23 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:32:23 --> Utf8 Class Initialized
INFO - 2025-05-22 16:32:23 --> URI Class Initialized
INFO - 2025-05-22 16:32:23 --> Router Class Initialized
INFO - 2025-05-22 16:32:23 --> Output Class Initialized
INFO - 2025-05-22 16:32:23 --> Security Class Initialized
DEBUG - 2025-05-22 16:32:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:32:23 --> Input Class Initialized
INFO - 2025-05-22 16:32:23 --> Language Class Initialized
INFO - 2025-05-22 16:32:23 --> Loader Class Initialized
INFO - 2025-05-22 16:32:23 --> Helper loaded: url_helper
INFO - 2025-05-22 16:32:23 --> Helper loaded: form_helper
INFO - 2025-05-22 16:32:23 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:32:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:32:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:32:23 --> Controller Class Initialized
INFO - 2025-05-22 16:32:23 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:32:23 --> Model "User_model" initialized
INFO - 2025-05-22 16:32:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-22 16:32:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-22 16:32:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-22 16:32:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-22 16:32:23 --> Final output sent to browser
DEBUG - 2025-05-22 16:32:23 --> Total execution time: 0.0910
INFO - 2025-05-22 16:32:23 --> Config Class Initialized
INFO - 2025-05-22 16:32:23 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:32:23 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:32:23 --> Utf8 Class Initialized
INFO - 2025-05-22 16:32:23 --> URI Class Initialized
INFO - 2025-05-22 16:32:23 --> Router Class Initialized
INFO - 2025-05-22 16:32:23 --> Output Class Initialized
INFO - 2025-05-22 16:32:23 --> Security Class Initialized
DEBUG - 2025-05-22 16:32:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:32:23 --> Input Class Initialized
INFO - 2025-05-22 16:32:23 --> Language Class Initialized
INFO - 2025-05-22 16:32:23 --> Loader Class Initialized
INFO - 2025-05-22 16:32:23 --> Helper loaded: url_helper
INFO - 2025-05-22 16:32:23 --> Helper loaded: form_helper
INFO - 2025-05-22 16:32:23 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:32:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:32:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:32:23 --> Controller Class Initialized
INFO - 2025-05-22 16:32:23 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:32:23 --> Model "User_model" initialized
INFO - 2025-05-22 16:32:23 --> Final output sent to browser
DEBUG - 2025-05-22 16:32:23 --> Total execution time: 0.0699
INFO - 2025-05-22 16:32:35 --> Config Class Initialized
INFO - 2025-05-22 16:32:35 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:32:35 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:32:35 --> Utf8 Class Initialized
INFO - 2025-05-22 16:32:35 --> URI Class Initialized
INFO - 2025-05-22 16:32:35 --> Router Class Initialized
INFO - 2025-05-22 16:32:35 --> Output Class Initialized
INFO - 2025-05-22 16:32:35 --> Security Class Initialized
DEBUG - 2025-05-22 16:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:32:35 --> Input Class Initialized
INFO - 2025-05-22 16:32:35 --> Language Class Initialized
INFO - 2025-05-22 16:32:35 --> Loader Class Initialized
INFO - 2025-05-22 16:32:35 --> Helper loaded: url_helper
INFO - 2025-05-22 16:32:35 --> Helper loaded: form_helper
INFO - 2025-05-22 16:32:35 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:32:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:32:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:32:35 --> Controller Class Initialized
INFO - 2025-05-22 16:32:35 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:32:35 --> Model "User_model" initialized
INFO - 2025-05-22 16:32:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-22 16:32:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-22 16:32:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-22 16:32:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-22 16:32:35 --> Final output sent to browser
DEBUG - 2025-05-22 16:32:35 --> Total execution time: 0.0818
INFO - 2025-05-22 16:32:35 --> Config Class Initialized
INFO - 2025-05-22 16:32:35 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:32:35 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:32:35 --> Utf8 Class Initialized
INFO - 2025-05-22 16:32:35 --> URI Class Initialized
INFO - 2025-05-22 16:32:35 --> Router Class Initialized
INFO - 2025-05-22 16:32:35 --> Output Class Initialized
INFO - 2025-05-22 16:32:35 --> Security Class Initialized
DEBUG - 2025-05-22 16:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:32:35 --> Input Class Initialized
INFO - 2025-05-22 16:32:35 --> Language Class Initialized
INFO - 2025-05-22 16:32:35 --> Loader Class Initialized
INFO - 2025-05-22 16:32:35 --> Helper loaded: url_helper
INFO - 2025-05-22 16:32:35 --> Helper loaded: form_helper
INFO - 2025-05-22 16:32:35 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:32:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:32:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:32:35 --> Controller Class Initialized
INFO - 2025-05-22 16:32:35 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:32:35 --> Model "User_model" initialized
INFO - 2025-05-22 16:32:35 --> Final output sent to browser
DEBUG - 2025-05-22 16:32:35 --> Total execution time: 0.0709
INFO - 2025-05-22 16:34:45 --> Config Class Initialized
INFO - 2025-05-22 16:34:45 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:34:45 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:34:45 --> Utf8 Class Initialized
INFO - 2025-05-22 16:34:45 --> URI Class Initialized
INFO - 2025-05-22 16:34:45 --> Router Class Initialized
INFO - 2025-05-22 16:34:45 --> Output Class Initialized
INFO - 2025-05-22 16:34:45 --> Security Class Initialized
DEBUG - 2025-05-22 16:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:34:45 --> Input Class Initialized
INFO - 2025-05-22 16:34:45 --> Language Class Initialized
INFO - 2025-05-22 16:34:45 --> Loader Class Initialized
INFO - 2025-05-22 16:34:45 --> Helper loaded: url_helper
INFO - 2025-05-22 16:34:45 --> Helper loaded: form_helper
INFO - 2025-05-22 16:34:45 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:34:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:34:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:34:45 --> Controller Class Initialized
INFO - 2025-05-22 16:34:45 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:34:45 --> Model "User_model" initialized
INFO - 2025-05-22 16:34:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-22 16:34:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-22 16:34:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-22 16:34:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-22 16:34:45 --> Final output sent to browser
DEBUG - 2025-05-22 16:34:45 --> Total execution time: 0.0987
INFO - 2025-05-22 16:34:45 --> Config Class Initialized
INFO - 2025-05-22 16:34:45 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:34:45 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:34:45 --> Utf8 Class Initialized
INFO - 2025-05-22 16:34:45 --> URI Class Initialized
INFO - 2025-05-22 16:34:45 --> Router Class Initialized
INFO - 2025-05-22 16:34:45 --> Output Class Initialized
INFO - 2025-05-22 16:34:45 --> Security Class Initialized
DEBUG - 2025-05-22 16:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:34:45 --> Input Class Initialized
INFO - 2025-05-22 16:34:45 --> Language Class Initialized
INFO - 2025-05-22 16:34:45 --> Loader Class Initialized
INFO - 2025-05-22 16:34:45 --> Helper loaded: url_helper
INFO - 2025-05-22 16:34:45 --> Helper loaded: form_helper
INFO - 2025-05-22 16:34:45 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:34:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:34:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:34:45 --> Controller Class Initialized
INFO - 2025-05-22 16:34:45 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:34:45 --> Model "User_model" initialized
INFO - 2025-05-22 16:34:45 --> Final output sent to browser
DEBUG - 2025-05-22 16:34:45 --> Total execution time: 0.0917
INFO - 2025-05-22 16:34:53 --> Config Class Initialized
INFO - 2025-05-22 16:34:53 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:34:53 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:34:53 --> Utf8 Class Initialized
INFO - 2025-05-22 16:34:53 --> URI Class Initialized
INFO - 2025-05-22 16:34:53 --> Router Class Initialized
INFO - 2025-05-22 16:34:53 --> Output Class Initialized
INFO - 2025-05-22 16:34:53 --> Security Class Initialized
DEBUG - 2025-05-22 16:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:34:53 --> Input Class Initialized
INFO - 2025-05-22 16:34:53 --> Language Class Initialized
INFO - 2025-05-22 16:34:53 --> Loader Class Initialized
INFO - 2025-05-22 16:34:53 --> Helper loaded: url_helper
INFO - 2025-05-22 16:34:53 --> Helper loaded: form_helper
INFO - 2025-05-22 16:34:53 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:34:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:34:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:34:54 --> Controller Class Initialized
INFO - 2025-05-22 16:34:54 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:34:54 --> Model "User_model" initialized
INFO - 2025-05-22 16:34:54 --> Final output sent to browser
DEBUG - 2025-05-22 16:34:54 --> Total execution time: 0.0678
INFO - 2025-05-22 16:34:56 --> Config Class Initialized
INFO - 2025-05-22 16:34:56 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:34:56 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:34:56 --> Utf8 Class Initialized
INFO - 2025-05-22 16:34:56 --> URI Class Initialized
INFO - 2025-05-22 16:34:56 --> Router Class Initialized
INFO - 2025-05-22 16:34:56 --> Output Class Initialized
INFO - 2025-05-22 16:34:56 --> Security Class Initialized
DEBUG - 2025-05-22 16:34:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:34:56 --> Input Class Initialized
INFO - 2025-05-22 16:34:56 --> Language Class Initialized
INFO - 2025-05-22 16:34:56 --> Loader Class Initialized
INFO - 2025-05-22 16:34:56 --> Helper loaded: url_helper
INFO - 2025-05-22 16:34:56 --> Helper loaded: form_helper
INFO - 2025-05-22 16:34:56 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:34:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:34:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:34:56 --> Controller Class Initialized
INFO - 2025-05-22 16:34:56 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:34:56 --> Model "User_model" initialized
INFO - 2025-05-22 16:34:56 --> Final output sent to browser
DEBUG - 2025-05-22 16:34:56 --> Total execution time: 0.0692
INFO - 2025-05-22 16:35:43 --> Config Class Initialized
INFO - 2025-05-22 16:35:43 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:35:43 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:35:43 --> Utf8 Class Initialized
INFO - 2025-05-22 16:35:43 --> URI Class Initialized
INFO - 2025-05-22 16:35:43 --> Router Class Initialized
INFO - 2025-05-22 16:35:43 --> Output Class Initialized
INFO - 2025-05-22 16:35:43 --> Security Class Initialized
DEBUG - 2025-05-22 16:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:35:43 --> Input Class Initialized
INFO - 2025-05-22 16:35:43 --> Language Class Initialized
INFO - 2025-05-22 16:35:43 --> Loader Class Initialized
INFO - 2025-05-22 16:35:43 --> Helper loaded: url_helper
INFO - 2025-05-22 16:35:43 --> Helper loaded: form_helper
INFO - 2025-05-22 16:35:43 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:35:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:35:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:35:43 --> Controller Class Initialized
INFO - 2025-05-22 16:35:43 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:35:43 --> Model "User_model" initialized
INFO - 2025-05-22 16:35:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-22 16:35:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-22 16:35:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-22 16:35:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-22 16:35:43 --> Final output sent to browser
DEBUG - 2025-05-22 16:35:43 --> Total execution time: 0.0668
INFO - 2025-05-22 16:35:43 --> Config Class Initialized
INFO - 2025-05-22 16:35:43 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:35:43 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:35:43 --> Utf8 Class Initialized
INFO - 2025-05-22 16:35:43 --> URI Class Initialized
INFO - 2025-05-22 16:35:43 --> Router Class Initialized
INFO - 2025-05-22 16:35:43 --> Output Class Initialized
INFO - 2025-05-22 16:35:43 --> Security Class Initialized
DEBUG - 2025-05-22 16:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:35:43 --> Input Class Initialized
INFO - 2025-05-22 16:35:43 --> Language Class Initialized
INFO - 2025-05-22 16:35:43 --> Loader Class Initialized
INFO - 2025-05-22 16:35:43 --> Helper loaded: url_helper
INFO - 2025-05-22 16:35:43 --> Helper loaded: form_helper
INFO - 2025-05-22 16:35:43 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:35:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:35:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:35:43 --> Controller Class Initialized
INFO - 2025-05-22 16:35:43 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:35:43 --> Model "User_model" initialized
INFO - 2025-05-22 16:35:43 --> Final output sent to browser
DEBUG - 2025-05-22 16:35:43 --> Total execution time: 0.0815
INFO - 2025-05-22 16:35:58 --> Config Class Initialized
INFO - 2025-05-22 16:35:58 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:35:58 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:35:58 --> Utf8 Class Initialized
INFO - 2025-05-22 16:35:58 --> URI Class Initialized
INFO - 2025-05-22 16:35:58 --> Router Class Initialized
INFO - 2025-05-22 16:35:58 --> Output Class Initialized
INFO - 2025-05-22 16:35:58 --> Security Class Initialized
DEBUG - 2025-05-22 16:35:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:35:58 --> Input Class Initialized
INFO - 2025-05-22 16:35:58 --> Language Class Initialized
INFO - 2025-05-22 16:35:58 --> Loader Class Initialized
INFO - 2025-05-22 16:35:58 --> Helper loaded: url_helper
INFO - 2025-05-22 16:35:58 --> Helper loaded: form_helper
INFO - 2025-05-22 16:35:58 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:35:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:35:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:35:58 --> Controller Class Initialized
INFO - 2025-05-22 16:35:58 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:35:58 --> Model "User_model" initialized
INFO - 2025-05-22 16:35:58 --> Final output sent to browser
DEBUG - 2025-05-22 16:35:58 --> Total execution time: 0.0695
INFO - 2025-05-22 16:36:01 --> Config Class Initialized
INFO - 2025-05-22 16:36:01 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:36:01 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:36:01 --> Utf8 Class Initialized
INFO - 2025-05-22 16:36:01 --> URI Class Initialized
INFO - 2025-05-22 16:36:01 --> Router Class Initialized
INFO - 2025-05-22 16:36:01 --> Output Class Initialized
INFO - 2025-05-22 16:36:01 --> Security Class Initialized
DEBUG - 2025-05-22 16:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:36:01 --> Input Class Initialized
INFO - 2025-05-22 16:36:01 --> Language Class Initialized
INFO - 2025-05-22 16:36:01 --> Loader Class Initialized
INFO - 2025-05-22 16:36:01 --> Helper loaded: url_helper
INFO - 2025-05-22 16:36:01 --> Helper loaded: form_helper
INFO - 2025-05-22 16:36:01 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:36:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:36:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:36:01 --> Controller Class Initialized
INFO - 2025-05-22 16:36:01 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:36:01 --> Model "User_model" initialized
INFO - 2025-05-22 16:36:01 --> Final output sent to browser
DEBUG - 2025-05-22 16:36:01 --> Total execution time: 0.1001
INFO - 2025-05-22 16:36:11 --> Config Class Initialized
INFO - 2025-05-22 16:36:11 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:36:11 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:36:11 --> Utf8 Class Initialized
INFO - 2025-05-22 16:36:11 --> URI Class Initialized
INFO - 2025-05-22 16:36:11 --> Router Class Initialized
INFO - 2025-05-22 16:36:11 --> Output Class Initialized
INFO - 2025-05-22 16:36:11 --> Security Class Initialized
DEBUG - 2025-05-22 16:36:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:36:11 --> Input Class Initialized
INFO - 2025-05-22 16:36:11 --> Language Class Initialized
INFO - 2025-05-22 16:36:11 --> Loader Class Initialized
INFO - 2025-05-22 16:36:11 --> Helper loaded: url_helper
INFO - 2025-05-22 16:36:11 --> Helper loaded: form_helper
INFO - 2025-05-22 16:36:11 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:36:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:36:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:36:11 --> Controller Class Initialized
INFO - 2025-05-22 16:36:11 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:36:11 --> Model "User_model" initialized
INFO - 2025-05-22 16:36:11 --> Final output sent to browser
DEBUG - 2025-05-22 16:36:11 --> Total execution time: 0.0776
INFO - 2025-05-22 16:36:13 --> Config Class Initialized
INFO - 2025-05-22 16:36:13 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:36:13 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:36:13 --> Utf8 Class Initialized
INFO - 2025-05-22 16:36:13 --> URI Class Initialized
INFO - 2025-05-22 16:36:13 --> Router Class Initialized
INFO - 2025-05-22 16:36:13 --> Output Class Initialized
INFO - 2025-05-22 16:36:13 --> Security Class Initialized
DEBUG - 2025-05-22 16:36:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:36:13 --> Input Class Initialized
INFO - 2025-05-22 16:36:13 --> Language Class Initialized
INFO - 2025-05-22 16:36:13 --> Loader Class Initialized
INFO - 2025-05-22 16:36:13 --> Helper loaded: url_helper
INFO - 2025-05-22 16:36:13 --> Helper loaded: form_helper
INFO - 2025-05-22 16:36:13 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:36:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:36:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:36:13 --> Controller Class Initialized
INFO - 2025-05-22 16:36:13 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:36:13 --> Model "User_model" initialized
INFO - 2025-05-22 16:36:13 --> Final output sent to browser
DEBUG - 2025-05-22 16:36:13 --> Total execution time: 0.0795
INFO - 2025-05-22 16:37:26 --> Config Class Initialized
INFO - 2025-05-22 16:37:26 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:37:26 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:37:26 --> Utf8 Class Initialized
INFO - 2025-05-22 16:37:26 --> URI Class Initialized
INFO - 2025-05-22 16:37:26 --> Router Class Initialized
INFO - 2025-05-22 16:37:26 --> Output Class Initialized
INFO - 2025-05-22 16:37:26 --> Security Class Initialized
DEBUG - 2025-05-22 16:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:37:26 --> Input Class Initialized
INFO - 2025-05-22 16:37:26 --> Language Class Initialized
INFO - 2025-05-22 16:37:26 --> Loader Class Initialized
INFO - 2025-05-22 16:37:26 --> Helper loaded: url_helper
INFO - 2025-05-22 16:37:26 --> Helper loaded: form_helper
INFO - 2025-05-22 16:37:26 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:37:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:37:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:37:27 --> Controller Class Initialized
INFO - 2025-05-22 16:37:27 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:37:27 --> Model "User_model" initialized
INFO - 2025-05-22 16:37:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-22 16:37:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-22 16:37:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-22 16:37:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-22 16:37:27 --> Final output sent to browser
DEBUG - 2025-05-22 16:37:27 --> Total execution time: 0.0815
INFO - 2025-05-22 16:37:27 --> Config Class Initialized
INFO - 2025-05-22 16:37:27 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:37:27 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:37:27 --> Utf8 Class Initialized
INFO - 2025-05-22 16:37:27 --> URI Class Initialized
INFO - 2025-05-22 16:37:27 --> Router Class Initialized
INFO - 2025-05-22 16:37:27 --> Output Class Initialized
INFO - 2025-05-22 16:37:27 --> Security Class Initialized
DEBUG - 2025-05-22 16:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:37:27 --> Input Class Initialized
INFO - 2025-05-22 16:37:27 --> Language Class Initialized
INFO - 2025-05-22 16:37:27 --> Loader Class Initialized
INFO - 2025-05-22 16:37:27 --> Helper loaded: url_helper
INFO - 2025-05-22 16:37:27 --> Helper loaded: form_helper
INFO - 2025-05-22 16:37:27 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:37:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:37:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:37:27 --> Controller Class Initialized
INFO - 2025-05-22 16:37:27 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:37:27 --> Model "User_model" initialized
INFO - 2025-05-22 16:37:27 --> Final output sent to browser
DEBUG - 2025-05-22 16:37:27 --> Total execution time: 0.0860
INFO - 2025-05-22 16:37:27 --> Config Class Initialized
INFO - 2025-05-22 16:37:27 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:37:27 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:37:27 --> Utf8 Class Initialized
INFO - 2025-05-22 16:37:27 --> URI Class Initialized
INFO - 2025-05-22 16:37:27 --> Router Class Initialized
INFO - 2025-05-22 16:37:27 --> Output Class Initialized
INFO - 2025-05-22 16:37:27 --> Security Class Initialized
DEBUG - 2025-05-22 16:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:37:27 --> Input Class Initialized
INFO - 2025-05-22 16:37:28 --> Language Class Initialized
INFO - 2025-05-22 16:37:28 --> Loader Class Initialized
INFO - 2025-05-22 16:37:28 --> Helper loaded: url_helper
INFO - 2025-05-22 16:37:28 --> Helper loaded: form_helper
INFO - 2025-05-22 16:37:28 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:37:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:37:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:37:28 --> Controller Class Initialized
INFO - 2025-05-22 16:37:28 --> Model "Workout_model" initialized
INFO - 2025-05-22 16:37:28 --> Model "User_model" initialized
INFO - 2025-05-22 16:37:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-22 16:37:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-22 16:37:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-22 16:37:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-22 16:37:28 --> Final output sent to browser
DEBUG - 2025-05-22 16:37:28 --> Total execution time: 0.0963
INFO - 2025-05-22 16:37:32 --> Config Class Initialized
INFO - 2025-05-22 16:37:32 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:37:32 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:37:32 --> Utf8 Class Initialized
INFO - 2025-05-22 16:37:32 --> URI Class Initialized
INFO - 2025-05-22 16:37:32 --> Router Class Initialized
INFO - 2025-05-22 16:37:32 --> Output Class Initialized
INFO - 2025-05-22 16:37:32 --> Security Class Initialized
DEBUG - 2025-05-22 16:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:37:32 --> Input Class Initialized
INFO - 2025-05-22 16:37:32 --> Language Class Initialized
INFO - 2025-05-22 16:37:32 --> Loader Class Initialized
INFO - 2025-05-22 16:37:32 --> Helper loaded: url_helper
INFO - 2025-05-22 16:37:32 --> Helper loaded: form_helper
INFO - 2025-05-22 16:37:32 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:37:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:37:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:37:32 --> Controller Class Initialized
INFO - 2025-05-22 16:37:32 --> Model "User_model" initialized
INFO - 2025-05-22 16:37:32 --> Model "Workout_model" initialized
INFO - 2025-05-22 16:37:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-22 16:37:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-22 16:37:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-22 16:37:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-22 16:37:32 --> Final output sent to browser
DEBUG - 2025-05-22 16:37:32 --> Total execution time: 0.0943
INFO - 2025-05-22 16:37:34 --> Config Class Initialized
INFO - 2025-05-22 16:37:34 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:37:34 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:37:34 --> Utf8 Class Initialized
INFO - 2025-05-22 16:37:34 --> URI Class Initialized
INFO - 2025-05-22 16:37:34 --> Router Class Initialized
INFO - 2025-05-22 16:37:34 --> Output Class Initialized
INFO - 2025-05-22 16:37:34 --> Security Class Initialized
DEBUG - 2025-05-22 16:37:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:37:34 --> Input Class Initialized
INFO - 2025-05-22 16:37:34 --> Language Class Initialized
INFO - 2025-05-22 16:37:34 --> Loader Class Initialized
INFO - 2025-05-22 16:37:34 --> Helper loaded: url_helper
INFO - 2025-05-22 16:37:34 --> Helper loaded: form_helper
INFO - 2025-05-22 16:37:34 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:37:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:37:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:37:34 --> Controller Class Initialized
INFO - 2025-05-22 16:37:34 --> Model "Workout_model" initialized
INFO - 2025-05-22 16:37:34 --> Model "User_model" initialized
INFO - 2025-05-22 16:37:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-22 16:37:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-22 16:37:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga.php
INFO - 2025-05-22 16:37:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-22 16:37:34 --> Final output sent to browser
DEBUG - 2025-05-22 16:37:34 --> Total execution time: 0.0762
INFO - 2025-05-22 16:37:35 --> Config Class Initialized
INFO - 2025-05-22 16:37:35 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:37:35 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:37:35 --> Utf8 Class Initialized
INFO - 2025-05-22 16:37:35 --> URI Class Initialized
INFO - 2025-05-22 16:37:35 --> Router Class Initialized
INFO - 2025-05-22 16:37:35 --> Output Class Initialized
INFO - 2025-05-22 16:37:35 --> Security Class Initialized
DEBUG - 2025-05-22 16:37:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:37:35 --> Input Class Initialized
INFO - 2025-05-22 16:37:35 --> Language Class Initialized
INFO - 2025-05-22 16:37:35 --> Loader Class Initialized
INFO - 2025-05-22 16:37:35 --> Helper loaded: url_helper
INFO - 2025-05-22 16:37:35 --> Helper loaded: form_helper
INFO - 2025-05-22 16:37:35 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:37:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:37:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:37:35 --> Controller Class Initialized
INFO - 2025-05-22 16:37:35 --> Model "Workout_model" initialized
INFO - 2025-05-22 16:37:35 --> Model "User_model" initialized
INFO - 2025-05-22 16:37:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-22 16:37:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-22 16:37:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-22 16:37:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-22 16:37:35 --> Final output sent to browser
DEBUG - 2025-05-22 16:37:35 --> Total execution time: 0.0667
INFO - 2025-05-22 16:38:42 --> Config Class Initialized
INFO - 2025-05-22 16:38:42 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:38:42 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:38:42 --> Utf8 Class Initialized
INFO - 2025-05-22 16:38:42 --> URI Class Initialized
INFO - 2025-05-22 16:38:42 --> Router Class Initialized
INFO - 2025-05-22 16:38:42 --> Output Class Initialized
INFO - 2025-05-22 16:38:42 --> Security Class Initialized
DEBUG - 2025-05-22 16:38:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:38:42 --> Input Class Initialized
INFO - 2025-05-22 16:38:42 --> Language Class Initialized
INFO - 2025-05-22 16:38:42 --> Loader Class Initialized
INFO - 2025-05-22 16:38:42 --> Helper loaded: url_helper
INFO - 2025-05-22 16:38:42 --> Helper loaded: form_helper
INFO - 2025-05-22 16:38:42 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:38:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:38:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:38:42 --> Controller Class Initialized
INFO - 2025-05-22 16:38:42 --> Model "Workout_model" initialized
INFO - 2025-05-22 16:38:42 --> Model "User_model" initialized
INFO - 2025-05-22 16:38:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-22 16:38:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-22 16:38:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-22 16:38:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-22 16:38:42 --> Final output sent to browser
DEBUG - 2025-05-22 16:38:42 --> Total execution time: 0.0981
INFO - 2025-05-22 16:38:44 --> Config Class Initialized
INFO - 2025-05-22 16:38:44 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:38:44 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:38:44 --> Utf8 Class Initialized
INFO - 2025-05-22 16:38:44 --> URI Class Initialized
INFO - 2025-05-22 16:38:44 --> Router Class Initialized
INFO - 2025-05-22 16:38:44 --> Output Class Initialized
INFO - 2025-05-22 16:38:44 --> Security Class Initialized
DEBUG - 2025-05-22 16:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:38:44 --> Input Class Initialized
INFO - 2025-05-22 16:38:44 --> Language Class Initialized
INFO - 2025-05-22 16:38:44 --> Loader Class Initialized
INFO - 2025-05-22 16:38:44 --> Helper loaded: url_helper
INFO - 2025-05-22 16:38:44 --> Helper loaded: form_helper
INFO - 2025-05-22 16:38:44 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:38:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:38:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:38:44 --> Controller Class Initialized
INFO - 2025-05-22 16:38:44 --> Model "Workout_model" initialized
INFO - 2025-05-22 16:38:44 --> Model "User_model" initialized
INFO - 2025-05-22 16:38:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-22 16:38:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-22 16:38:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga.php
INFO - 2025-05-22 16:38:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-22 16:38:44 --> Final output sent to browser
DEBUG - 2025-05-22 16:38:44 --> Total execution time: 0.0779
INFO - 2025-05-22 16:38:45 --> Config Class Initialized
INFO - 2025-05-22 16:38:45 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:38:45 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:38:45 --> Utf8 Class Initialized
INFO - 2025-05-22 16:38:45 --> URI Class Initialized
INFO - 2025-05-22 16:38:45 --> Router Class Initialized
INFO - 2025-05-22 16:38:45 --> Output Class Initialized
INFO - 2025-05-22 16:38:45 --> Security Class Initialized
DEBUG - 2025-05-22 16:38:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:38:45 --> Input Class Initialized
INFO - 2025-05-22 16:38:45 --> Language Class Initialized
INFO - 2025-05-22 16:38:45 --> Loader Class Initialized
INFO - 2025-05-22 16:38:45 --> Helper loaded: url_helper
INFO - 2025-05-22 16:38:45 --> Helper loaded: form_helper
INFO - 2025-05-22 16:38:45 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:38:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:38:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:38:45 --> Controller Class Initialized
INFO - 2025-05-22 16:38:45 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:38:45 --> Model "User_model" initialized
INFO - 2025-05-22 16:38:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-22 16:38:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-22 16:38:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-22 16:38:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-22 16:38:45 --> Final output sent to browser
DEBUG - 2025-05-22 16:38:45 --> Total execution time: 0.0837
INFO - 2025-05-22 16:38:45 --> Config Class Initialized
INFO - 2025-05-22 16:38:45 --> Hooks Class Initialized
DEBUG - 2025-05-22 16:38:45 --> UTF-8 Support Enabled
INFO - 2025-05-22 16:38:45 --> Utf8 Class Initialized
INFO - 2025-05-22 16:38:45 --> URI Class Initialized
INFO - 2025-05-22 16:38:45 --> Router Class Initialized
INFO - 2025-05-22 16:38:45 --> Output Class Initialized
INFO - 2025-05-22 16:38:45 --> Security Class Initialized
DEBUG - 2025-05-22 16:38:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-22 16:38:45 --> Input Class Initialized
INFO - 2025-05-22 16:38:45 --> Language Class Initialized
INFO - 2025-05-22 16:38:45 --> Loader Class Initialized
INFO - 2025-05-22 16:38:45 --> Helper loaded: url_helper
INFO - 2025-05-22 16:38:45 --> Helper loaded: form_helper
INFO - 2025-05-22 16:38:45 --> Database Driver Class Initialized
DEBUG - 2025-05-22 16:38:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-22 16:38:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-22 16:38:45 --> Controller Class Initialized
INFO - 2025-05-22 16:38:45 --> Model "Progress_model" initialized
INFO - 2025-05-22 16:38:45 --> Model "User_model" initialized
INFO - 2025-05-22 16:38:45 --> Final output sent to browser
DEBUG - 2025-05-22 16:38:45 --> Total execution time: 0.0683
