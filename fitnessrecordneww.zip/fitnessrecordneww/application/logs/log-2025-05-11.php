<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-05-11 11:21:44 --> Config Class Initialized
INFO - 2025-05-11 11:21:44 --> Hooks Class Initialized
DEBUG - 2025-05-11 11:21:44 --> UTF-8 Support Enabled
INFO - 2025-05-11 11:21:44 --> Utf8 Class Initialized
INFO - 2025-05-11 11:21:44 --> URI Class Initialized
DEBUG - 2025-05-11 11:21:44 --> No URI present. Default controller set.
INFO - 2025-05-11 11:21:44 --> Router Class Initialized
INFO - 2025-05-11 11:21:44 --> Output Class Initialized
INFO - 2025-05-11 11:21:44 --> Security Class Initialized
DEBUG - 2025-05-11 11:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 11:21:44 --> Input Class Initialized
INFO - 2025-05-11 11:21:44 --> Language Class Initialized
INFO - 2025-05-11 11:21:44 --> Loader Class Initialized
INFO - 2025-05-11 11:21:44 --> Helper loaded: url_helper
INFO - 2025-05-11 11:21:44 --> Helper loaded: form_helper
INFO - 2025-05-11 11:21:44 --> Database Driver Class Initialized
DEBUG - 2025-05-11 11:21:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 11:21:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 11:21:44 --> Controller Class Initialized
INFO - 2025-05-11 11:21:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-11 11:21:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-11 11:21:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-11 11:21:44 --> Final output sent to browser
DEBUG - 2025-05-11 11:21:44 --> Total execution time: 0.0854
INFO - 2025-05-11 11:22:21 --> Config Class Initialized
INFO - 2025-05-11 11:22:21 --> Hooks Class Initialized
DEBUG - 2025-05-11 11:22:21 --> UTF-8 Support Enabled
INFO - 2025-05-11 11:22:21 --> Utf8 Class Initialized
INFO - 2025-05-11 11:22:21 --> URI Class Initialized
DEBUG - 2025-05-11 11:22:21 --> No URI present. Default controller set.
INFO - 2025-05-11 11:22:21 --> Router Class Initialized
INFO - 2025-05-11 11:22:21 --> Output Class Initialized
INFO - 2025-05-11 11:22:21 --> Security Class Initialized
DEBUG - 2025-05-11 11:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 11:22:21 --> Input Class Initialized
INFO - 2025-05-11 11:22:21 --> Language Class Initialized
INFO - 2025-05-11 11:22:21 --> Loader Class Initialized
INFO - 2025-05-11 11:22:21 --> Helper loaded: url_helper
INFO - 2025-05-11 11:22:21 --> Helper loaded: form_helper
INFO - 2025-05-11 11:22:21 --> Database Driver Class Initialized
DEBUG - 2025-05-11 11:22:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 11:22:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 11:22:21 --> Controller Class Initialized
INFO - 2025-05-11 11:22:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-11 11:22:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-11 11:22:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-11 11:22:21 --> Final output sent to browser
DEBUG - 2025-05-11 11:22:21 --> Total execution time: 0.0662
INFO - 2025-05-11 11:22:28 --> Config Class Initialized
INFO - 2025-05-11 11:22:28 --> Hooks Class Initialized
DEBUG - 2025-05-11 11:22:28 --> UTF-8 Support Enabled
INFO - 2025-05-11 11:22:28 --> Utf8 Class Initialized
INFO - 2025-05-11 11:22:28 --> URI Class Initialized
DEBUG - 2025-05-11 11:22:28 --> No URI present. Default controller set.
INFO - 2025-05-11 11:22:28 --> Router Class Initialized
INFO - 2025-05-11 11:22:28 --> Output Class Initialized
INFO - 2025-05-11 11:22:28 --> Security Class Initialized
DEBUG - 2025-05-11 11:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 11:22:28 --> Input Class Initialized
INFO - 2025-05-11 11:22:28 --> Language Class Initialized
INFO - 2025-05-11 11:22:28 --> Loader Class Initialized
INFO - 2025-05-11 11:22:28 --> Helper loaded: url_helper
INFO - 2025-05-11 11:22:28 --> Helper loaded: form_helper
INFO - 2025-05-11 11:22:28 --> Database Driver Class Initialized
DEBUG - 2025-05-11 11:22:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 11:22:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 11:22:28 --> Controller Class Initialized
INFO - 2025-05-11 11:22:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-11 11:22:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-11 11:22:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-11 11:22:28 --> Final output sent to browser
DEBUG - 2025-05-11 11:22:28 --> Total execution time: 0.0762
INFO - 2025-05-11 11:26:11 --> Config Class Initialized
INFO - 2025-05-11 11:26:11 --> Hooks Class Initialized
DEBUG - 2025-05-11 11:26:11 --> UTF-8 Support Enabled
INFO - 2025-05-11 11:26:11 --> Utf8 Class Initialized
INFO - 2025-05-11 11:26:11 --> URI Class Initialized
DEBUG - 2025-05-11 11:26:11 --> No URI present. Default controller set.
INFO - 2025-05-11 11:26:11 --> Router Class Initialized
INFO - 2025-05-11 11:26:11 --> Output Class Initialized
INFO - 2025-05-11 11:26:11 --> Security Class Initialized
DEBUG - 2025-05-11 11:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 11:26:11 --> Input Class Initialized
INFO - 2025-05-11 11:26:11 --> Language Class Initialized
INFO - 2025-05-11 11:26:11 --> Loader Class Initialized
INFO - 2025-05-11 11:26:11 --> Helper loaded: url_helper
INFO - 2025-05-11 11:26:11 --> Helper loaded: form_helper
INFO - 2025-05-11 11:26:11 --> Database Driver Class Initialized
DEBUG - 2025-05-11 11:26:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 11:26:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 11:26:11 --> Controller Class Initialized
INFO - 2025-05-11 11:26:11 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-11 11:26:11 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-11 11:26:11 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-11 11:26:11 --> Final output sent to browser
DEBUG - 2025-05-11 11:26:11 --> Total execution time: 0.0743
INFO - 2025-05-11 11:27:06 --> Config Class Initialized
INFO - 2025-05-11 11:27:06 --> Hooks Class Initialized
DEBUG - 2025-05-11 11:27:06 --> UTF-8 Support Enabled
INFO - 2025-05-11 11:27:06 --> Utf8 Class Initialized
INFO - 2025-05-11 11:27:06 --> URI Class Initialized
DEBUG - 2025-05-11 11:27:06 --> No URI present. Default controller set.
INFO - 2025-05-11 11:27:06 --> Router Class Initialized
INFO - 2025-05-11 11:27:06 --> Output Class Initialized
INFO - 2025-05-11 11:27:06 --> Security Class Initialized
DEBUG - 2025-05-11 11:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 11:27:06 --> Input Class Initialized
INFO - 2025-05-11 11:27:06 --> Language Class Initialized
INFO - 2025-05-11 11:27:06 --> Loader Class Initialized
INFO - 2025-05-11 11:27:06 --> Helper loaded: url_helper
INFO - 2025-05-11 11:27:06 --> Helper loaded: form_helper
INFO - 2025-05-11 11:27:06 --> Database Driver Class Initialized
DEBUG - 2025-05-11 11:27:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 11:27:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 11:27:06 --> Controller Class Initialized
INFO - 2025-05-11 11:27:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-11 11:27:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-11 11:27:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-11 11:27:06 --> Final output sent to browser
DEBUG - 2025-05-11 11:27:06 --> Total execution time: 0.0769
INFO - 2025-05-11 11:27:26 --> Config Class Initialized
INFO - 2025-05-11 11:27:26 --> Hooks Class Initialized
DEBUG - 2025-05-11 11:27:26 --> UTF-8 Support Enabled
INFO - 2025-05-11 11:27:26 --> Utf8 Class Initialized
INFO - 2025-05-11 11:27:26 --> URI Class Initialized
DEBUG - 2025-05-11 11:27:26 --> No URI present. Default controller set.
INFO - 2025-05-11 11:27:26 --> Router Class Initialized
INFO - 2025-05-11 11:27:26 --> Output Class Initialized
INFO - 2025-05-11 11:27:26 --> Security Class Initialized
DEBUG - 2025-05-11 11:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 11:27:26 --> Input Class Initialized
INFO - 2025-05-11 11:27:26 --> Language Class Initialized
INFO - 2025-05-11 11:27:26 --> Loader Class Initialized
INFO - 2025-05-11 11:27:26 --> Helper loaded: url_helper
INFO - 2025-05-11 11:27:26 --> Helper loaded: form_helper
INFO - 2025-05-11 11:27:26 --> Database Driver Class Initialized
DEBUG - 2025-05-11 11:27:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 11:27:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 11:27:26 --> Controller Class Initialized
INFO - 2025-05-11 11:27:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-11 11:27:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-11 11:27:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-11 11:27:26 --> Final output sent to browser
DEBUG - 2025-05-11 11:27:26 --> Total execution time: 0.0614
INFO - 2025-05-11 11:27:29 --> Config Class Initialized
INFO - 2025-05-11 11:27:29 --> Hooks Class Initialized
DEBUG - 2025-05-11 11:27:29 --> UTF-8 Support Enabled
INFO - 2025-05-11 11:27:29 --> Utf8 Class Initialized
INFO - 2025-05-11 11:27:29 --> URI Class Initialized
INFO - 2025-05-11 11:27:29 --> Router Class Initialized
INFO - 2025-05-11 11:27:29 --> Output Class Initialized
INFO - 2025-05-11 11:27:29 --> Security Class Initialized
DEBUG - 2025-05-11 11:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 11:27:29 --> Input Class Initialized
INFO - 2025-05-11 11:27:29 --> Language Class Initialized
INFO - 2025-05-11 11:27:29 --> Loader Class Initialized
INFO - 2025-05-11 11:27:29 --> Helper loaded: url_helper
INFO - 2025-05-11 11:27:29 --> Helper loaded: form_helper
INFO - 2025-05-11 11:27:29 --> Database Driver Class Initialized
DEBUG - 2025-05-11 11:27:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 11:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 11:27:29 --> Controller Class Initialized
INFO - 2025-05-11 11:27:29 --> Model "User_model" initialized
INFO - 2025-05-11 11:27:29 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-11 11:27:29 --> Final output sent to browser
DEBUG - 2025-05-11 11:27:29 --> Total execution time: 0.0786
INFO - 2025-05-11 11:31:34 --> Config Class Initialized
INFO - 2025-05-11 11:31:34 --> Hooks Class Initialized
DEBUG - 2025-05-11 11:31:34 --> UTF-8 Support Enabled
INFO - 2025-05-11 11:31:34 --> Utf8 Class Initialized
INFO - 2025-05-11 11:31:34 --> URI Class Initialized
INFO - 2025-05-11 11:31:34 --> Router Class Initialized
INFO - 2025-05-11 11:31:34 --> Output Class Initialized
INFO - 2025-05-11 11:31:34 --> Security Class Initialized
DEBUG - 2025-05-11 11:31:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 11:31:34 --> Input Class Initialized
INFO - 2025-05-11 11:31:34 --> Language Class Initialized
INFO - 2025-05-11 11:31:34 --> Loader Class Initialized
INFO - 2025-05-11 11:31:34 --> Helper loaded: url_helper
INFO - 2025-05-11 11:31:34 --> Helper loaded: form_helper
INFO - 2025-05-11 11:31:34 --> Database Driver Class Initialized
DEBUG - 2025-05-11 11:31:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 11:31:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 11:31:34 --> Controller Class Initialized
INFO - 2025-05-11 11:31:34 --> Model "User_model" initialized
INFO - 2025-05-11 11:31:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-11 11:31:34 --> Final output sent to browser
DEBUG - 2025-05-11 11:31:34 --> Total execution time: 0.0718
INFO - 2025-05-11 11:32:20 --> Config Class Initialized
INFO - 2025-05-11 11:32:20 --> Hooks Class Initialized
DEBUG - 2025-05-11 11:32:20 --> UTF-8 Support Enabled
INFO - 2025-05-11 11:32:20 --> Utf8 Class Initialized
INFO - 2025-05-11 11:32:20 --> URI Class Initialized
INFO - 2025-05-11 11:32:20 --> Router Class Initialized
INFO - 2025-05-11 11:32:20 --> Output Class Initialized
INFO - 2025-05-11 11:32:20 --> Security Class Initialized
DEBUG - 2025-05-11 11:32:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 11:32:20 --> Input Class Initialized
INFO - 2025-05-11 11:32:20 --> Language Class Initialized
INFO - 2025-05-11 11:32:20 --> Loader Class Initialized
INFO - 2025-05-11 11:32:20 --> Helper loaded: url_helper
INFO - 2025-05-11 11:32:20 --> Helper loaded: form_helper
INFO - 2025-05-11 11:32:20 --> Database Driver Class Initialized
DEBUG - 2025-05-11 11:32:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 11:32:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 11:32:20 --> Controller Class Initialized
INFO - 2025-05-11 11:32:20 --> Model "User_model" initialized
INFO - 2025-05-11 11:32:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-11 11:32:20 --> Final output sent to browser
DEBUG - 2025-05-11 11:32:20 --> Total execution time: 0.0807
INFO - 2025-05-11 11:56:43 --> Config Class Initialized
INFO - 2025-05-11 11:56:43 --> Hooks Class Initialized
DEBUG - 2025-05-11 11:56:44 --> UTF-8 Support Enabled
INFO - 2025-05-11 11:56:44 --> Utf8 Class Initialized
INFO - 2025-05-11 11:56:44 --> URI Class Initialized
INFO - 2025-05-11 11:56:44 --> Router Class Initialized
INFO - 2025-05-11 11:56:44 --> Output Class Initialized
INFO - 2025-05-11 11:56:44 --> Security Class Initialized
DEBUG - 2025-05-11 11:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 11:56:44 --> Input Class Initialized
INFO - 2025-05-11 11:56:44 --> Language Class Initialized
INFO - 2025-05-11 11:56:44 --> Loader Class Initialized
INFO - 2025-05-11 11:56:44 --> Helper loaded: url_helper
INFO - 2025-05-11 11:56:44 --> Helper loaded: form_helper
INFO - 2025-05-11 11:56:45 --> Database Driver Class Initialized
DEBUG - 2025-05-11 11:56:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 11:56:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 11:56:45 --> Controller Class Initialized
INFO - 2025-05-11 11:56:45 --> Model "User_model" initialized
INFO - 2025-05-11 11:56:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-11 11:56:45 --> Final output sent to browser
DEBUG - 2025-05-11 11:56:45 --> Total execution time: 1.5793
INFO - 2025-05-11 11:57:38 --> Config Class Initialized
INFO - 2025-05-11 11:57:38 --> Hooks Class Initialized
DEBUG - 2025-05-11 11:57:38 --> UTF-8 Support Enabled
INFO - 2025-05-11 11:57:38 --> Utf8 Class Initialized
INFO - 2025-05-11 11:57:38 --> URI Class Initialized
INFO - 2025-05-11 11:57:38 --> Router Class Initialized
INFO - 2025-05-11 11:57:38 --> Output Class Initialized
INFO - 2025-05-11 11:57:38 --> Security Class Initialized
DEBUG - 2025-05-11 11:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 11:57:38 --> Input Class Initialized
INFO - 2025-05-11 11:57:38 --> Language Class Initialized
INFO - 2025-05-11 11:57:38 --> Loader Class Initialized
INFO - 2025-05-11 11:57:38 --> Helper loaded: url_helper
INFO - 2025-05-11 11:57:38 --> Helper loaded: form_helper
INFO - 2025-05-11 11:57:38 --> Database Driver Class Initialized
DEBUG - 2025-05-11 11:57:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 11:57:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 11:57:38 --> Controller Class Initialized
INFO - 2025-05-11 11:57:38 --> Model "User_model" initialized
INFO - 2025-05-11 11:57:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-11 11:57:38 --> Final output sent to browser
DEBUG - 2025-05-11 11:57:38 --> Total execution time: 0.0642
INFO - 2025-05-11 11:58:43 --> Config Class Initialized
INFO - 2025-05-11 11:58:43 --> Hooks Class Initialized
DEBUG - 2025-05-11 11:58:43 --> UTF-8 Support Enabled
INFO - 2025-05-11 11:58:43 --> Utf8 Class Initialized
INFO - 2025-05-11 11:58:43 --> URI Class Initialized
INFO - 2025-05-11 11:58:43 --> Router Class Initialized
INFO - 2025-05-11 11:58:43 --> Output Class Initialized
INFO - 2025-05-11 11:58:43 --> Security Class Initialized
DEBUG - 2025-05-11 11:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 11:58:43 --> Input Class Initialized
INFO - 2025-05-11 11:58:43 --> Language Class Initialized
INFO - 2025-05-11 11:58:43 --> Loader Class Initialized
INFO - 2025-05-11 11:58:43 --> Helper loaded: url_helper
INFO - 2025-05-11 11:58:43 --> Helper loaded: form_helper
INFO - 2025-05-11 11:58:43 --> Database Driver Class Initialized
DEBUG - 2025-05-11 11:58:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 11:58:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 11:58:43 --> Controller Class Initialized
INFO - 2025-05-11 11:58:43 --> Model "User_model" initialized
INFO - 2025-05-11 11:58:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-11 11:58:43 --> Final output sent to browser
DEBUG - 2025-05-11 11:58:43 --> Total execution time: 0.0810
INFO - 2025-05-11 11:59:25 --> Config Class Initialized
INFO - 2025-05-11 11:59:25 --> Hooks Class Initialized
DEBUG - 2025-05-11 11:59:25 --> UTF-8 Support Enabled
INFO - 2025-05-11 11:59:25 --> Utf8 Class Initialized
INFO - 2025-05-11 11:59:25 --> URI Class Initialized
INFO - 2025-05-11 11:59:25 --> Router Class Initialized
INFO - 2025-05-11 11:59:25 --> Output Class Initialized
INFO - 2025-05-11 11:59:25 --> Security Class Initialized
DEBUG - 2025-05-11 11:59:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 11:59:25 --> Input Class Initialized
INFO - 2025-05-11 11:59:25 --> Language Class Initialized
INFO - 2025-05-11 11:59:25 --> Loader Class Initialized
INFO - 2025-05-11 11:59:25 --> Helper loaded: url_helper
INFO - 2025-05-11 11:59:25 --> Helper loaded: form_helper
INFO - 2025-05-11 11:59:25 --> Database Driver Class Initialized
DEBUG - 2025-05-11 11:59:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 11:59:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 11:59:25 --> Controller Class Initialized
INFO - 2025-05-11 11:59:25 --> Model "User_model" initialized
INFO - 2025-05-11 11:59:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-11 11:59:25 --> Final output sent to browser
DEBUG - 2025-05-11 11:59:25 --> Total execution time: 0.0724
INFO - 2025-05-11 11:59:37 --> Config Class Initialized
INFO - 2025-05-11 11:59:37 --> Hooks Class Initialized
DEBUG - 2025-05-11 11:59:37 --> UTF-8 Support Enabled
INFO - 2025-05-11 11:59:37 --> Utf8 Class Initialized
INFO - 2025-05-11 11:59:37 --> URI Class Initialized
INFO - 2025-05-11 11:59:37 --> Router Class Initialized
INFO - 2025-05-11 11:59:37 --> Output Class Initialized
INFO - 2025-05-11 11:59:37 --> Security Class Initialized
DEBUG - 2025-05-11 11:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 11:59:37 --> Input Class Initialized
INFO - 2025-05-11 11:59:37 --> Language Class Initialized
INFO - 2025-05-11 11:59:37 --> Loader Class Initialized
INFO - 2025-05-11 11:59:37 --> Helper loaded: url_helper
INFO - 2025-05-11 11:59:37 --> Helper loaded: form_helper
INFO - 2025-05-11 11:59:37 --> Database Driver Class Initialized
DEBUG - 2025-05-11 11:59:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 11:59:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 11:59:37 --> Controller Class Initialized
INFO - 2025-05-11 11:59:37 --> Model "User_model" initialized
INFO - 2025-05-11 11:59:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-11 11:59:37 --> Final output sent to browser
DEBUG - 2025-05-11 11:59:37 --> Total execution time: 0.0679
INFO - 2025-05-11 12:01:02 --> Config Class Initialized
INFO - 2025-05-11 12:01:02 --> Hooks Class Initialized
DEBUG - 2025-05-11 12:01:02 --> UTF-8 Support Enabled
INFO - 2025-05-11 12:01:02 --> Utf8 Class Initialized
INFO - 2025-05-11 12:01:02 --> URI Class Initialized
INFO - 2025-05-11 12:01:02 --> Router Class Initialized
INFO - 2025-05-11 12:01:02 --> Output Class Initialized
INFO - 2025-05-11 12:01:02 --> Security Class Initialized
DEBUG - 2025-05-11 12:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 12:01:02 --> Input Class Initialized
INFO - 2025-05-11 12:01:02 --> Language Class Initialized
INFO - 2025-05-11 12:01:02 --> Loader Class Initialized
INFO - 2025-05-11 12:01:02 --> Helper loaded: url_helper
INFO - 2025-05-11 12:01:02 --> Helper loaded: form_helper
INFO - 2025-05-11 12:01:02 --> Database Driver Class Initialized
DEBUG - 2025-05-11 12:01:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 12:01:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 12:01:02 --> Controller Class Initialized
INFO - 2025-05-11 12:01:02 --> Model "User_model" initialized
INFO - 2025-05-11 12:01:02 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-11 12:01:02 --> Final output sent to browser
DEBUG - 2025-05-11 12:01:02 --> Total execution time: 0.0795
INFO - 2025-05-11 12:02:17 --> Config Class Initialized
INFO - 2025-05-11 12:02:17 --> Hooks Class Initialized
DEBUG - 2025-05-11 12:02:17 --> UTF-8 Support Enabled
INFO - 2025-05-11 12:02:17 --> Utf8 Class Initialized
INFO - 2025-05-11 12:02:17 --> URI Class Initialized
INFO - 2025-05-11 12:02:17 --> Router Class Initialized
INFO - 2025-05-11 12:02:17 --> Output Class Initialized
INFO - 2025-05-11 12:02:17 --> Security Class Initialized
DEBUG - 2025-05-11 12:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 12:02:17 --> Input Class Initialized
INFO - 2025-05-11 12:02:17 --> Language Class Initialized
INFO - 2025-05-11 12:02:17 --> Loader Class Initialized
INFO - 2025-05-11 12:02:17 --> Helper loaded: url_helper
INFO - 2025-05-11 12:02:17 --> Helper loaded: form_helper
INFO - 2025-05-11 12:02:17 --> Database Driver Class Initialized
DEBUG - 2025-05-11 12:02:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 12:02:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 12:02:17 --> Controller Class Initialized
INFO - 2025-05-11 12:02:17 --> Model "User_model" initialized
INFO - 2025-05-11 12:02:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-11 12:02:17 --> Final output sent to browser
DEBUG - 2025-05-11 12:02:17 --> Total execution time: 0.0935
INFO - 2025-05-11 12:02:30 --> Config Class Initialized
INFO - 2025-05-11 12:02:30 --> Hooks Class Initialized
DEBUG - 2025-05-11 12:02:30 --> UTF-8 Support Enabled
INFO - 2025-05-11 12:02:30 --> Utf8 Class Initialized
INFO - 2025-05-11 12:02:30 --> URI Class Initialized
INFO - 2025-05-11 12:02:30 --> Router Class Initialized
INFO - 2025-05-11 12:02:30 --> Output Class Initialized
INFO - 2025-05-11 12:02:30 --> Security Class Initialized
DEBUG - 2025-05-11 12:02:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 12:02:30 --> Input Class Initialized
INFO - 2025-05-11 12:02:30 --> Language Class Initialized
INFO - 2025-05-11 12:02:30 --> Loader Class Initialized
INFO - 2025-05-11 12:02:30 --> Helper loaded: url_helper
INFO - 2025-05-11 12:02:30 --> Helper loaded: form_helper
INFO - 2025-05-11 12:02:30 --> Database Driver Class Initialized
DEBUG - 2025-05-11 12:02:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 12:02:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 12:02:30 --> Controller Class Initialized
INFO - 2025-05-11 12:02:30 --> Model "User_model" initialized
INFO - 2025-05-11 12:02:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-11 12:02:30 --> Final output sent to browser
DEBUG - 2025-05-11 12:02:30 --> Total execution time: 0.0881
INFO - 2025-05-11 12:03:04 --> Config Class Initialized
INFO - 2025-05-11 12:03:04 --> Hooks Class Initialized
DEBUG - 2025-05-11 12:03:04 --> UTF-8 Support Enabled
INFO - 2025-05-11 12:03:04 --> Utf8 Class Initialized
INFO - 2025-05-11 12:03:04 --> URI Class Initialized
INFO - 2025-05-11 12:03:04 --> Router Class Initialized
INFO - 2025-05-11 12:03:04 --> Output Class Initialized
INFO - 2025-05-11 12:03:04 --> Security Class Initialized
DEBUG - 2025-05-11 12:03:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 12:03:04 --> Input Class Initialized
INFO - 2025-05-11 12:03:04 --> Language Class Initialized
INFO - 2025-05-11 12:03:04 --> Loader Class Initialized
INFO - 2025-05-11 12:03:04 --> Helper loaded: url_helper
INFO - 2025-05-11 12:03:04 --> Helper loaded: form_helper
INFO - 2025-05-11 12:03:04 --> Database Driver Class Initialized
DEBUG - 2025-05-11 12:03:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 12:03:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 12:03:04 --> Controller Class Initialized
INFO - 2025-05-11 12:03:04 --> Model "User_model" initialized
INFO - 2025-05-11 12:03:04 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-11 12:03:04 --> Final output sent to browser
DEBUG - 2025-05-11 12:03:04 --> Total execution time: 0.0862
INFO - 2025-05-11 12:03:13 --> Config Class Initialized
INFO - 2025-05-11 12:03:13 --> Hooks Class Initialized
DEBUG - 2025-05-11 12:03:13 --> UTF-8 Support Enabled
INFO - 2025-05-11 12:03:13 --> Utf8 Class Initialized
INFO - 2025-05-11 12:03:13 --> URI Class Initialized
INFO - 2025-05-11 12:03:13 --> Router Class Initialized
INFO - 2025-05-11 12:03:13 --> Output Class Initialized
INFO - 2025-05-11 12:03:13 --> Security Class Initialized
DEBUG - 2025-05-11 12:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 12:03:13 --> Input Class Initialized
INFO - 2025-05-11 12:03:13 --> Language Class Initialized
INFO - 2025-05-11 12:03:13 --> Loader Class Initialized
INFO - 2025-05-11 12:03:13 --> Helper loaded: url_helper
INFO - 2025-05-11 12:03:13 --> Helper loaded: form_helper
INFO - 2025-05-11 12:03:13 --> Database Driver Class Initialized
DEBUG - 2025-05-11 12:03:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 12:03:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 12:03:13 --> Controller Class Initialized
INFO - 2025-05-11 12:03:13 --> Model "User_model" initialized
INFO - 2025-05-11 12:03:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-11 12:03:13 --> Final output sent to browser
DEBUG - 2025-05-11 12:03:13 --> Total execution time: 0.0782
INFO - 2025-05-11 12:03:42 --> Config Class Initialized
INFO - 2025-05-11 12:03:42 --> Hooks Class Initialized
DEBUG - 2025-05-11 12:03:42 --> UTF-8 Support Enabled
INFO - 2025-05-11 12:03:42 --> Utf8 Class Initialized
INFO - 2025-05-11 12:03:42 --> URI Class Initialized
INFO - 2025-05-11 12:03:42 --> Router Class Initialized
INFO - 2025-05-11 12:03:42 --> Output Class Initialized
INFO - 2025-05-11 12:03:42 --> Security Class Initialized
DEBUG - 2025-05-11 12:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 12:03:42 --> Input Class Initialized
INFO - 2025-05-11 12:03:42 --> Language Class Initialized
INFO - 2025-05-11 12:03:42 --> Loader Class Initialized
INFO - 2025-05-11 12:03:42 --> Helper loaded: url_helper
INFO - 2025-05-11 12:03:42 --> Helper loaded: form_helper
INFO - 2025-05-11 12:03:42 --> Database Driver Class Initialized
DEBUG - 2025-05-11 12:03:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 12:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 12:03:42 --> Controller Class Initialized
INFO - 2025-05-11 12:03:42 --> Model "User_model" initialized
INFO - 2025-05-11 12:03:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-11 12:03:42 --> Final output sent to browser
DEBUG - 2025-05-11 12:03:42 --> Total execution time: 0.1070
INFO - 2025-05-11 12:03:59 --> Config Class Initialized
INFO - 2025-05-11 12:03:59 --> Hooks Class Initialized
DEBUG - 2025-05-11 12:03:59 --> UTF-8 Support Enabled
INFO - 2025-05-11 12:03:59 --> Utf8 Class Initialized
INFO - 2025-05-11 12:03:59 --> URI Class Initialized
INFO - 2025-05-11 12:03:59 --> Router Class Initialized
INFO - 2025-05-11 12:03:59 --> Output Class Initialized
INFO - 2025-05-11 12:03:59 --> Security Class Initialized
DEBUG - 2025-05-11 12:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 12:03:59 --> Input Class Initialized
INFO - 2025-05-11 12:03:59 --> Language Class Initialized
INFO - 2025-05-11 12:03:59 --> Loader Class Initialized
INFO - 2025-05-11 12:03:59 --> Helper loaded: url_helper
INFO - 2025-05-11 12:03:59 --> Helper loaded: form_helper
INFO - 2025-05-11 12:03:59 --> Database Driver Class Initialized
DEBUG - 2025-05-11 12:03:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 12:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 12:03:59 --> Controller Class Initialized
INFO - 2025-05-11 12:03:59 --> Model "User_model" initialized
INFO - 2025-05-11 12:03:59 --> Config Class Initialized
INFO - 2025-05-11 12:03:59 --> Hooks Class Initialized
DEBUG - 2025-05-11 12:03:59 --> UTF-8 Support Enabled
INFO - 2025-05-11 12:03:59 --> Utf8 Class Initialized
INFO - 2025-05-11 12:03:59 --> URI Class Initialized
INFO - 2025-05-11 12:03:59 --> Router Class Initialized
INFO - 2025-05-11 12:03:59 --> Output Class Initialized
INFO - 2025-05-11 12:03:59 --> Security Class Initialized
DEBUG - 2025-05-11 12:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 12:03:59 --> Input Class Initialized
INFO - 2025-05-11 12:03:59 --> Language Class Initialized
INFO - 2025-05-11 12:03:59 --> Loader Class Initialized
INFO - 2025-05-11 12:03:59 --> Helper loaded: url_helper
INFO - 2025-05-11 12:03:59 --> Helper loaded: form_helper
INFO - 2025-05-11 12:03:59 --> Database Driver Class Initialized
DEBUG - 2025-05-11 12:03:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 12:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 12:03:59 --> Controller Class Initialized
INFO - 2025-05-11 12:03:59 --> Model "User_model" initialized
INFO - 2025-05-11 12:04:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard.php
INFO - 2025-05-11 12:04:00 --> Final output sent to browser
DEBUG - 2025-05-11 12:04:00 --> Total execution time: 0.1294
INFO - 2025-05-11 12:04:04 --> Config Class Initialized
INFO - 2025-05-11 12:04:04 --> Hooks Class Initialized
DEBUG - 2025-05-11 12:04:04 --> UTF-8 Support Enabled
INFO - 2025-05-11 12:04:04 --> Utf8 Class Initialized
INFO - 2025-05-11 12:04:04 --> URI Class Initialized
INFO - 2025-05-11 12:04:04 --> Router Class Initialized
INFO - 2025-05-11 12:04:04 --> Output Class Initialized
INFO - 2025-05-11 12:04:04 --> Security Class Initialized
DEBUG - 2025-05-11 12:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 12:04:04 --> Input Class Initialized
INFO - 2025-05-11 12:04:04 --> Language Class Initialized
INFO - 2025-05-11 12:04:04 --> Loader Class Initialized
INFO - 2025-05-11 12:04:04 --> Helper loaded: url_helper
INFO - 2025-05-11 12:04:04 --> Helper loaded: form_helper
INFO - 2025-05-11 12:04:04 --> Database Driver Class Initialized
DEBUG - 2025-05-11 12:04:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 12:04:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 12:04:04 --> Controller Class Initialized
INFO - 2025-05-11 12:04:04 --> Model "User_model" initialized
INFO - 2025-05-11 12:04:04 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-11 12:04:04 --> Final output sent to browser
DEBUG - 2025-05-11 12:04:04 --> Total execution time: 0.0749
INFO - 2025-05-11 12:20:05 --> Config Class Initialized
INFO - 2025-05-11 12:20:05 --> Hooks Class Initialized
DEBUG - 2025-05-11 12:20:05 --> UTF-8 Support Enabled
INFO - 2025-05-11 12:20:05 --> Utf8 Class Initialized
INFO - 2025-05-11 12:20:05 --> URI Class Initialized
INFO - 2025-05-11 12:20:05 --> Router Class Initialized
INFO - 2025-05-11 12:20:05 --> Output Class Initialized
INFO - 2025-05-11 12:20:05 --> Security Class Initialized
DEBUG - 2025-05-11 12:20:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 12:20:05 --> Input Class Initialized
INFO - 2025-05-11 12:20:05 --> Language Class Initialized
INFO - 2025-05-11 12:20:05 --> Loader Class Initialized
INFO - 2025-05-11 12:20:05 --> Helper loaded: url_helper
INFO - 2025-05-11 12:20:05 --> Helper loaded: form_helper
INFO - 2025-05-11 12:20:05 --> Database Driver Class Initialized
DEBUG - 2025-05-11 12:20:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 12:20:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 12:20:05 --> Controller Class Initialized
INFO - 2025-05-11 12:20:05 --> Model "User_model" initialized
INFO - 2025-05-11 12:20:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-11 12:20:05 --> Final output sent to browser
DEBUG - 2025-05-11 12:20:05 --> Total execution time: 0.0809
INFO - 2025-05-11 12:20:12 --> Config Class Initialized
INFO - 2025-05-11 12:20:12 --> Hooks Class Initialized
DEBUG - 2025-05-11 12:20:12 --> UTF-8 Support Enabled
INFO - 2025-05-11 12:20:12 --> Utf8 Class Initialized
INFO - 2025-05-11 12:20:12 --> URI Class Initialized
INFO - 2025-05-11 12:20:12 --> Router Class Initialized
INFO - 2025-05-11 12:20:12 --> Output Class Initialized
INFO - 2025-05-11 12:20:12 --> Security Class Initialized
DEBUG - 2025-05-11 12:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 12:20:12 --> Input Class Initialized
INFO - 2025-05-11 12:20:12 --> Language Class Initialized
INFO - 2025-05-11 12:20:12 --> Loader Class Initialized
INFO - 2025-05-11 12:20:12 --> Helper loaded: url_helper
INFO - 2025-05-11 12:20:12 --> Helper loaded: form_helper
INFO - 2025-05-11 12:20:12 --> Database Driver Class Initialized
DEBUG - 2025-05-11 12:20:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 12:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 12:20:12 --> Controller Class Initialized
INFO - 2025-05-11 12:20:12 --> Model "User_model" initialized
INFO - 2025-05-11 12:20:12 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-11 12:20:12 --> Final output sent to browser
DEBUG - 2025-05-11 12:20:12 --> Total execution time: 0.0749
INFO - 2025-05-11 12:20:14 --> Config Class Initialized
INFO - 2025-05-11 12:20:14 --> Hooks Class Initialized
DEBUG - 2025-05-11 12:20:14 --> UTF-8 Support Enabled
INFO - 2025-05-11 12:20:14 --> Utf8 Class Initialized
INFO - 2025-05-11 12:20:14 --> URI Class Initialized
INFO - 2025-05-11 12:20:14 --> Router Class Initialized
INFO - 2025-05-11 12:20:14 --> Output Class Initialized
INFO - 2025-05-11 12:20:14 --> Security Class Initialized
DEBUG - 2025-05-11 12:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 12:20:14 --> Input Class Initialized
INFO - 2025-05-11 12:20:14 --> Language Class Initialized
INFO - 2025-05-11 12:20:14 --> Loader Class Initialized
INFO - 2025-05-11 12:20:14 --> Helper loaded: url_helper
INFO - 2025-05-11 12:20:14 --> Helper loaded: form_helper
INFO - 2025-05-11 12:20:14 --> Database Driver Class Initialized
DEBUG - 2025-05-11 12:20:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 12:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 12:20:14 --> Controller Class Initialized
INFO - 2025-05-11 12:20:14 --> Model "User_model" initialized
INFO - 2025-05-11 12:20:14 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-11 12:20:14 --> Final output sent to browser
DEBUG - 2025-05-11 12:20:14 --> Total execution time: 0.0669
INFO - 2025-05-11 12:22:33 --> Config Class Initialized
INFO - 2025-05-11 12:22:33 --> Hooks Class Initialized
DEBUG - 2025-05-11 12:22:33 --> UTF-8 Support Enabled
INFO - 2025-05-11 12:22:33 --> Utf8 Class Initialized
INFO - 2025-05-11 12:22:33 --> URI Class Initialized
INFO - 2025-05-11 12:22:33 --> Router Class Initialized
INFO - 2025-05-11 12:22:33 --> Output Class Initialized
INFO - 2025-05-11 12:22:33 --> Security Class Initialized
DEBUG - 2025-05-11 12:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 12:22:33 --> Input Class Initialized
INFO - 2025-05-11 12:22:33 --> Language Class Initialized
INFO - 2025-05-11 12:22:33 --> Loader Class Initialized
INFO - 2025-05-11 12:22:33 --> Helper loaded: url_helper
INFO - 2025-05-11 12:22:33 --> Helper loaded: form_helper
INFO - 2025-05-11 12:22:33 --> Database Driver Class Initialized
DEBUG - 2025-05-11 12:22:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 12:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 12:22:33 --> Controller Class Initialized
INFO - 2025-05-11 12:22:33 --> Model "User_model" initialized
INFO - 2025-05-11 12:22:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-11 12:22:33 --> Final output sent to browser
DEBUG - 2025-05-11 12:22:33 --> Total execution time: 0.0716
INFO - 2025-05-11 12:22:37 --> Config Class Initialized
INFO - 2025-05-11 12:22:37 --> Hooks Class Initialized
DEBUG - 2025-05-11 12:22:37 --> UTF-8 Support Enabled
INFO - 2025-05-11 12:22:37 --> Utf8 Class Initialized
INFO - 2025-05-11 12:22:37 --> URI Class Initialized
INFO - 2025-05-11 12:22:37 --> Router Class Initialized
INFO - 2025-05-11 12:22:37 --> Output Class Initialized
INFO - 2025-05-11 12:22:37 --> Security Class Initialized
DEBUG - 2025-05-11 12:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 12:22:37 --> Input Class Initialized
INFO - 2025-05-11 12:22:37 --> Language Class Initialized
INFO - 2025-05-11 12:22:37 --> Loader Class Initialized
INFO - 2025-05-11 12:22:37 --> Helper loaded: url_helper
INFO - 2025-05-11 12:22:37 --> Helper loaded: form_helper
INFO - 2025-05-11 12:22:37 --> Database Driver Class Initialized
DEBUG - 2025-05-11 12:22:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 12:22:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 12:22:37 --> Controller Class Initialized
INFO - 2025-05-11 12:22:37 --> Model "User_model" initialized
INFO - 2025-05-11 12:22:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-11 12:22:37 --> Final output sent to browser
DEBUG - 2025-05-11 12:22:37 --> Total execution time: 0.0703
INFO - 2025-05-11 12:22:43 --> Config Class Initialized
INFO - 2025-05-11 12:22:43 --> Hooks Class Initialized
DEBUG - 2025-05-11 12:22:43 --> UTF-8 Support Enabled
INFO - 2025-05-11 12:22:43 --> Utf8 Class Initialized
INFO - 2025-05-11 12:22:43 --> URI Class Initialized
INFO - 2025-05-11 12:22:43 --> Router Class Initialized
INFO - 2025-05-11 12:22:43 --> Output Class Initialized
INFO - 2025-05-11 12:22:43 --> Security Class Initialized
DEBUG - 2025-05-11 12:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 12:22:43 --> Input Class Initialized
INFO - 2025-05-11 12:22:43 --> Language Class Initialized
INFO - 2025-05-11 12:22:43 --> Loader Class Initialized
INFO - 2025-05-11 12:22:43 --> Helper loaded: url_helper
INFO - 2025-05-11 12:22:43 --> Helper loaded: form_helper
INFO - 2025-05-11 12:22:43 --> Database Driver Class Initialized
DEBUG - 2025-05-11 12:22:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 12:22:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 12:22:43 --> Controller Class Initialized
INFO - 2025-05-11 12:22:43 --> Model "User_model" initialized
INFO - 2025-05-11 12:22:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-11 12:22:43 --> Final output sent to browser
DEBUG - 2025-05-11 12:22:43 --> Total execution time: 0.1025
INFO - 2025-05-11 12:22:44 --> Config Class Initialized
INFO - 2025-05-11 12:22:44 --> Hooks Class Initialized
DEBUG - 2025-05-11 12:22:44 --> UTF-8 Support Enabled
INFO - 2025-05-11 12:22:44 --> Utf8 Class Initialized
INFO - 2025-05-11 12:22:44 --> URI Class Initialized
INFO - 2025-05-11 12:22:44 --> Router Class Initialized
INFO - 2025-05-11 12:22:44 --> Output Class Initialized
INFO - 2025-05-11 12:22:44 --> Security Class Initialized
DEBUG - 2025-05-11 12:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 12:22:44 --> Input Class Initialized
INFO - 2025-05-11 12:22:44 --> Language Class Initialized
INFO - 2025-05-11 12:22:44 --> Loader Class Initialized
INFO - 2025-05-11 12:22:44 --> Helper loaded: url_helper
INFO - 2025-05-11 12:22:44 --> Helper loaded: form_helper
INFO - 2025-05-11 12:22:44 --> Database Driver Class Initialized
DEBUG - 2025-05-11 12:22:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 12:22:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 12:22:44 --> Controller Class Initialized
INFO - 2025-05-11 12:22:44 --> Model "User_model" initialized
INFO - 2025-05-11 12:22:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-11 12:22:44 --> Final output sent to browser
DEBUG - 2025-05-11 12:22:44 --> Total execution time: 0.0664
INFO - 2025-05-11 12:22:45 --> Config Class Initialized
INFO - 2025-05-11 12:22:45 --> Hooks Class Initialized
DEBUG - 2025-05-11 12:22:45 --> UTF-8 Support Enabled
INFO - 2025-05-11 12:22:45 --> Utf8 Class Initialized
INFO - 2025-05-11 12:22:45 --> URI Class Initialized
INFO - 2025-05-11 12:22:45 --> Router Class Initialized
INFO - 2025-05-11 12:22:45 --> Output Class Initialized
INFO - 2025-05-11 12:22:45 --> Security Class Initialized
DEBUG - 2025-05-11 12:22:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 12:22:45 --> Input Class Initialized
INFO - 2025-05-11 12:22:45 --> Language Class Initialized
INFO - 2025-05-11 12:22:45 --> Loader Class Initialized
INFO - 2025-05-11 12:22:45 --> Helper loaded: url_helper
INFO - 2025-05-11 12:22:45 --> Helper loaded: form_helper
INFO - 2025-05-11 12:22:45 --> Database Driver Class Initialized
DEBUG - 2025-05-11 12:22:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 12:22:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 12:22:45 --> Controller Class Initialized
INFO - 2025-05-11 12:22:45 --> Model "User_model" initialized
INFO - 2025-05-11 12:22:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-11 12:22:45 --> Final output sent to browser
DEBUG - 2025-05-11 12:22:45 --> Total execution time: 0.0675
INFO - 2025-05-11 12:22:46 --> Config Class Initialized
INFO - 2025-05-11 12:22:46 --> Hooks Class Initialized
DEBUG - 2025-05-11 12:22:46 --> UTF-8 Support Enabled
INFO - 2025-05-11 12:22:46 --> Utf8 Class Initialized
INFO - 2025-05-11 12:22:46 --> URI Class Initialized
INFO - 2025-05-11 12:22:46 --> Router Class Initialized
INFO - 2025-05-11 12:22:46 --> Output Class Initialized
INFO - 2025-05-11 12:22:46 --> Security Class Initialized
DEBUG - 2025-05-11 12:22:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 12:22:46 --> Input Class Initialized
INFO - 2025-05-11 12:22:46 --> Language Class Initialized
INFO - 2025-05-11 12:22:46 --> Loader Class Initialized
INFO - 2025-05-11 12:22:46 --> Helper loaded: url_helper
INFO - 2025-05-11 12:22:46 --> Helper loaded: form_helper
INFO - 2025-05-11 12:22:46 --> Database Driver Class Initialized
DEBUG - 2025-05-11 12:22:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 12:22:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 12:22:46 --> Controller Class Initialized
INFO - 2025-05-11 12:22:46 --> Model "User_model" initialized
INFO - 2025-05-11 12:22:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-11 12:22:46 --> Final output sent to browser
DEBUG - 2025-05-11 12:22:46 --> Total execution time: 0.0802
INFO - 2025-05-11 12:24:43 --> Config Class Initialized
INFO - 2025-05-11 12:24:43 --> Hooks Class Initialized
DEBUG - 2025-05-11 12:24:43 --> UTF-8 Support Enabled
INFO - 2025-05-11 12:24:43 --> Utf8 Class Initialized
INFO - 2025-05-11 12:24:43 --> URI Class Initialized
INFO - 2025-05-11 12:24:43 --> Router Class Initialized
INFO - 2025-05-11 12:24:43 --> Output Class Initialized
INFO - 2025-05-11 12:24:43 --> Security Class Initialized
DEBUG - 2025-05-11 12:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 12:24:43 --> Input Class Initialized
INFO - 2025-05-11 12:24:43 --> Language Class Initialized
INFO - 2025-05-11 12:24:43 --> Loader Class Initialized
INFO - 2025-05-11 12:24:43 --> Helper loaded: url_helper
INFO - 2025-05-11 12:24:43 --> Helper loaded: form_helper
INFO - 2025-05-11 12:24:43 --> Database Driver Class Initialized
DEBUG - 2025-05-11 12:24:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 12:24:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 12:24:43 --> Controller Class Initialized
INFO - 2025-05-11 12:24:43 --> Model "User_model" initialized
INFO - 2025-05-11 12:24:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-11 12:24:43 --> Final output sent to browser
DEBUG - 2025-05-11 12:24:43 --> Total execution time: 0.1095
INFO - 2025-05-11 12:28:40 --> Config Class Initialized
INFO - 2025-05-11 12:28:40 --> Hooks Class Initialized
DEBUG - 2025-05-11 12:28:41 --> UTF-8 Support Enabled
INFO - 2025-05-11 12:28:41 --> Utf8 Class Initialized
INFO - 2025-05-11 12:28:41 --> URI Class Initialized
INFO - 2025-05-11 12:28:41 --> Router Class Initialized
INFO - 2025-05-11 12:28:41 --> Output Class Initialized
INFO - 2025-05-11 12:28:41 --> Security Class Initialized
DEBUG - 2025-05-11 12:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 12:28:41 --> Input Class Initialized
INFO - 2025-05-11 12:28:41 --> Language Class Initialized
INFO - 2025-05-11 12:28:41 --> Loader Class Initialized
INFO - 2025-05-11 12:28:41 --> Helper loaded: url_helper
INFO - 2025-05-11 12:28:41 --> Helper loaded: form_helper
INFO - 2025-05-11 12:28:41 --> Database Driver Class Initialized
DEBUG - 2025-05-11 12:28:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 12:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 12:28:41 --> Controller Class Initialized
INFO - 2025-05-11 12:28:41 --> Model "User_model" initialized
INFO - 2025-05-11 12:28:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-11 12:28:41 --> Final output sent to browser
DEBUG - 2025-05-11 12:28:41 --> Total execution time: 0.0759
INFO - 2025-05-11 12:29:01 --> Config Class Initialized
INFO - 2025-05-11 12:29:01 --> Hooks Class Initialized
DEBUG - 2025-05-11 12:29:01 --> UTF-8 Support Enabled
INFO - 2025-05-11 12:29:01 --> Utf8 Class Initialized
INFO - 2025-05-11 12:29:01 --> URI Class Initialized
INFO - 2025-05-11 12:29:01 --> Router Class Initialized
INFO - 2025-05-11 12:29:01 --> Output Class Initialized
INFO - 2025-05-11 12:29:01 --> Security Class Initialized
DEBUG - 2025-05-11 12:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 12:29:01 --> Input Class Initialized
INFO - 2025-05-11 12:29:01 --> Language Class Initialized
ERROR - 2025-05-11 12:29:01 --> 404 Page Not Found: Auth/index
INFO - 2025-05-11 12:29:10 --> Config Class Initialized
INFO - 2025-05-11 12:29:10 --> Hooks Class Initialized
DEBUG - 2025-05-11 12:29:10 --> UTF-8 Support Enabled
INFO - 2025-05-11 12:29:10 --> Utf8 Class Initialized
INFO - 2025-05-11 12:29:10 --> URI Class Initialized
DEBUG - 2025-05-11 12:29:10 --> No URI present. Default controller set.
INFO - 2025-05-11 12:29:10 --> Router Class Initialized
INFO - 2025-05-11 12:29:10 --> Output Class Initialized
INFO - 2025-05-11 12:29:10 --> Security Class Initialized
DEBUG - 2025-05-11 12:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 12:29:10 --> Input Class Initialized
INFO - 2025-05-11 12:29:10 --> Language Class Initialized
INFO - 2025-05-11 12:29:10 --> Loader Class Initialized
INFO - 2025-05-11 12:29:10 --> Helper loaded: url_helper
INFO - 2025-05-11 12:29:10 --> Helper loaded: form_helper
INFO - 2025-05-11 12:29:10 --> Database Driver Class Initialized
DEBUG - 2025-05-11 12:29:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 12:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 12:29:10 --> Controller Class Initialized
INFO - 2025-05-11 12:29:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-11 12:29:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-11 12:29:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-11 12:29:10 --> Final output sent to browser
DEBUG - 2025-05-11 12:29:10 --> Total execution time: 0.4270
INFO - 2025-05-11 12:29:14 --> Config Class Initialized
INFO - 2025-05-11 12:29:14 --> Hooks Class Initialized
DEBUG - 2025-05-11 12:29:14 --> UTF-8 Support Enabled
INFO - 2025-05-11 12:29:14 --> Utf8 Class Initialized
INFO - 2025-05-11 12:29:14 --> URI Class Initialized
INFO - 2025-05-11 12:29:14 --> Router Class Initialized
INFO - 2025-05-11 12:29:14 --> Output Class Initialized
INFO - 2025-05-11 12:29:14 --> Security Class Initialized
DEBUG - 2025-05-11 12:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 12:29:14 --> Input Class Initialized
INFO - 2025-05-11 12:29:14 --> Language Class Initialized
INFO - 2025-05-11 12:29:14 --> Loader Class Initialized
INFO - 2025-05-11 12:29:14 --> Helper loaded: url_helper
INFO - 2025-05-11 12:29:14 --> Helper loaded: form_helper
INFO - 2025-05-11 12:29:14 --> Database Driver Class Initialized
DEBUG - 2025-05-11 12:29:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 12:29:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 12:29:14 --> Controller Class Initialized
INFO - 2025-05-11 12:29:14 --> Model "User_model" initialized
INFO - 2025-05-11 12:29:14 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-11 12:29:14 --> Final output sent to browser
DEBUG - 2025-05-11 12:29:14 --> Total execution time: 0.0953
INFO - 2025-05-11 12:30:44 --> Config Class Initialized
INFO - 2025-05-11 12:30:44 --> Hooks Class Initialized
DEBUG - 2025-05-11 12:30:44 --> UTF-8 Support Enabled
INFO - 2025-05-11 12:30:44 --> Utf8 Class Initialized
INFO - 2025-05-11 12:30:44 --> URI Class Initialized
INFO - 2025-05-11 12:30:44 --> Router Class Initialized
INFO - 2025-05-11 12:30:44 --> Output Class Initialized
INFO - 2025-05-11 12:30:44 --> Security Class Initialized
DEBUG - 2025-05-11 12:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 12:30:44 --> Input Class Initialized
INFO - 2025-05-11 12:30:44 --> Language Class Initialized
INFO - 2025-05-11 12:30:45 --> Loader Class Initialized
INFO - 2025-05-11 12:30:45 --> Helper loaded: url_helper
INFO - 2025-05-11 12:30:45 --> Helper loaded: form_helper
INFO - 2025-05-11 12:30:45 --> Database Driver Class Initialized
DEBUG - 2025-05-11 12:30:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 12:30:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 12:30:45 --> Controller Class Initialized
INFO - 2025-05-11 12:30:45 --> Model "User_model" initialized
INFO - 2025-05-11 12:30:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-11 12:30:45 --> Final output sent to browser
DEBUG - 2025-05-11 12:30:45 --> Total execution time: 0.0611
INFO - 2025-05-11 12:32:47 --> Config Class Initialized
INFO - 2025-05-11 12:32:47 --> Hooks Class Initialized
DEBUG - 2025-05-11 12:32:47 --> UTF-8 Support Enabled
INFO - 2025-05-11 12:32:47 --> Utf8 Class Initialized
INFO - 2025-05-11 12:32:47 --> URI Class Initialized
INFO - 2025-05-11 12:32:47 --> Router Class Initialized
INFO - 2025-05-11 12:32:47 --> Output Class Initialized
INFO - 2025-05-11 12:32:47 --> Security Class Initialized
DEBUG - 2025-05-11 12:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 12:32:47 --> Input Class Initialized
INFO - 2025-05-11 12:32:47 --> Language Class Initialized
INFO - 2025-05-11 12:32:47 --> Loader Class Initialized
INFO - 2025-05-11 12:32:47 --> Helper loaded: url_helper
INFO - 2025-05-11 12:32:47 --> Helper loaded: form_helper
INFO - 2025-05-11 12:32:47 --> Database Driver Class Initialized
DEBUG - 2025-05-11 12:32:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 12:32:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 12:32:47 --> Controller Class Initialized
INFO - 2025-05-11 12:32:47 --> Model "User_model" initialized
INFO - 2025-05-11 12:32:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-11 12:32:47 --> Final output sent to browser
DEBUG - 2025-05-11 12:32:47 --> Total execution time: 0.0859
INFO - 2025-05-11 12:35:00 --> Config Class Initialized
INFO - 2025-05-11 12:35:00 --> Hooks Class Initialized
DEBUG - 2025-05-11 12:35:00 --> UTF-8 Support Enabled
INFO - 2025-05-11 12:35:00 --> Utf8 Class Initialized
INFO - 2025-05-11 12:35:00 --> URI Class Initialized
INFO - 2025-05-11 12:35:00 --> Router Class Initialized
INFO - 2025-05-11 12:35:00 --> Output Class Initialized
INFO - 2025-05-11 12:35:00 --> Security Class Initialized
DEBUG - 2025-05-11 12:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 12:35:00 --> Input Class Initialized
INFO - 2025-05-11 12:35:00 --> Language Class Initialized
INFO - 2025-05-11 12:35:00 --> Loader Class Initialized
INFO - 2025-05-11 12:35:00 --> Helper loaded: url_helper
INFO - 2025-05-11 12:35:00 --> Helper loaded: form_helper
INFO - 2025-05-11 12:35:00 --> Database Driver Class Initialized
DEBUG - 2025-05-11 12:35:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 12:35:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 12:35:00 --> Controller Class Initialized
INFO - 2025-05-11 12:35:00 --> Model "User_model" initialized
INFO - 2025-05-11 12:35:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-11 12:35:00 --> Final output sent to browser
DEBUG - 2025-05-11 12:35:00 --> Total execution time: 0.0743
INFO - 2025-05-11 12:37:51 --> Config Class Initialized
INFO - 2025-05-11 12:37:51 --> Hooks Class Initialized
DEBUG - 2025-05-11 12:37:51 --> UTF-8 Support Enabled
INFO - 2025-05-11 12:37:51 --> Utf8 Class Initialized
INFO - 2025-05-11 12:37:51 --> URI Class Initialized
INFO - 2025-05-11 12:37:51 --> Router Class Initialized
INFO - 2025-05-11 12:37:51 --> Output Class Initialized
INFO - 2025-05-11 12:37:51 --> Security Class Initialized
DEBUG - 2025-05-11 12:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 12:37:51 --> Input Class Initialized
INFO - 2025-05-11 12:37:51 --> Language Class Initialized
INFO - 2025-05-11 12:37:51 --> Loader Class Initialized
INFO - 2025-05-11 12:37:51 --> Helper loaded: url_helper
INFO - 2025-05-11 12:37:51 --> Helper loaded: form_helper
INFO - 2025-05-11 12:37:51 --> Database Driver Class Initialized
DEBUG - 2025-05-11 12:37:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 12:37:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 12:37:51 --> Controller Class Initialized
INFO - 2025-05-11 12:37:51 --> Model "User_model" initialized
INFO - 2025-05-11 12:37:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-11 12:37:51 --> Final output sent to browser
DEBUG - 2025-05-11 12:37:51 --> Total execution time: 0.0846
INFO - 2025-05-11 12:37:59 --> Config Class Initialized
INFO - 2025-05-11 12:37:59 --> Hooks Class Initialized
DEBUG - 2025-05-11 12:37:59 --> UTF-8 Support Enabled
INFO - 2025-05-11 12:37:59 --> Utf8 Class Initialized
INFO - 2025-05-11 12:37:59 --> URI Class Initialized
INFO - 2025-05-11 12:37:59 --> Router Class Initialized
INFO - 2025-05-11 12:37:59 --> Output Class Initialized
INFO - 2025-05-11 12:37:59 --> Security Class Initialized
DEBUG - 2025-05-11 12:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 12:37:59 --> Input Class Initialized
INFO - 2025-05-11 12:37:59 --> Language Class Initialized
INFO - 2025-05-11 12:37:59 --> Loader Class Initialized
INFO - 2025-05-11 12:37:59 --> Helper loaded: url_helper
INFO - 2025-05-11 12:37:59 --> Helper loaded: form_helper
INFO - 2025-05-11 12:37:59 --> Database Driver Class Initialized
DEBUG - 2025-05-11 12:37:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 12:37:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 12:37:59 --> Controller Class Initialized
INFO - 2025-05-11 12:37:59 --> Model "User_model" initialized
INFO - 2025-05-11 12:37:59 --> Config Class Initialized
INFO - 2025-05-11 12:37:59 --> Hooks Class Initialized
DEBUG - 2025-05-11 12:37:59 --> UTF-8 Support Enabled
INFO - 2025-05-11 12:37:59 --> Utf8 Class Initialized
INFO - 2025-05-11 12:37:59 --> URI Class Initialized
INFO - 2025-05-11 12:37:59 --> Router Class Initialized
INFO - 2025-05-11 12:37:59 --> Output Class Initialized
INFO - 2025-05-11 12:37:59 --> Security Class Initialized
DEBUG - 2025-05-11 12:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 12:37:59 --> Input Class Initialized
INFO - 2025-05-11 12:37:59 --> Language Class Initialized
INFO - 2025-05-11 12:37:59 --> Loader Class Initialized
INFO - 2025-05-11 12:37:59 --> Helper loaded: url_helper
INFO - 2025-05-11 12:37:59 --> Helper loaded: form_helper
INFO - 2025-05-11 12:37:59 --> Database Driver Class Initialized
DEBUG - 2025-05-11 12:37:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 12:37:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 12:37:59 --> Controller Class Initialized
INFO - 2025-05-11 12:37:59 --> Model "User_model" initialized
INFO - 2025-05-11 12:37:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard.php
INFO - 2025-05-11 12:37:59 --> Final output sent to browser
DEBUG - 2025-05-11 12:37:59 --> Total execution time: 0.0837
INFO - 2025-05-11 12:39:17 --> Config Class Initialized
INFO - 2025-05-11 12:39:17 --> Hooks Class Initialized
DEBUG - 2025-05-11 12:39:17 --> UTF-8 Support Enabled
INFO - 2025-05-11 12:39:17 --> Utf8 Class Initialized
INFO - 2025-05-11 12:39:17 --> URI Class Initialized
INFO - 2025-05-11 12:39:17 --> Router Class Initialized
INFO - 2025-05-11 12:39:17 --> Output Class Initialized
INFO - 2025-05-11 12:39:17 --> Security Class Initialized
DEBUG - 2025-05-11 12:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 12:39:17 --> Input Class Initialized
INFO - 2025-05-11 12:39:17 --> Language Class Initialized
INFO - 2025-05-11 12:39:17 --> Loader Class Initialized
INFO - 2025-05-11 12:39:17 --> Helper loaded: url_helper
INFO - 2025-05-11 12:39:17 --> Helper loaded: form_helper
INFO - 2025-05-11 12:39:17 --> Database Driver Class Initialized
DEBUG - 2025-05-11 12:39:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 12:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 12:39:17 --> Controller Class Initialized
INFO - 2025-05-11 12:39:17 --> Model "User_model" initialized
INFO - 2025-05-11 12:39:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-11 12:39:17 --> Final output sent to browser
DEBUG - 2025-05-11 12:39:17 --> Total execution time: 0.0716
INFO - 2025-05-11 12:39:22 --> Config Class Initialized
INFO - 2025-05-11 12:39:22 --> Hooks Class Initialized
DEBUG - 2025-05-11 12:39:22 --> UTF-8 Support Enabled
INFO - 2025-05-11 12:39:22 --> Utf8 Class Initialized
INFO - 2025-05-11 12:39:22 --> URI Class Initialized
INFO - 2025-05-11 12:39:22 --> Router Class Initialized
INFO - 2025-05-11 12:39:22 --> Output Class Initialized
INFO - 2025-05-11 12:39:22 --> Security Class Initialized
DEBUG - 2025-05-11 12:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 12:39:22 --> Input Class Initialized
INFO - 2025-05-11 12:39:22 --> Language Class Initialized
INFO - 2025-05-11 12:39:22 --> Loader Class Initialized
INFO - 2025-05-11 12:39:22 --> Helper loaded: url_helper
INFO - 2025-05-11 12:39:22 --> Helper loaded: form_helper
INFO - 2025-05-11 12:39:22 --> Database Driver Class Initialized
DEBUG - 2025-05-11 12:39:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 12:39:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 12:39:22 --> Controller Class Initialized
INFO - 2025-05-11 12:39:22 --> Model "User_model" initialized
INFO - 2025-05-11 12:39:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-11 12:39:22 --> Final output sent to browser
DEBUG - 2025-05-11 12:39:22 --> Total execution time: 0.0678
INFO - 2025-05-11 12:39:37 --> Config Class Initialized
INFO - 2025-05-11 12:39:37 --> Hooks Class Initialized
DEBUG - 2025-05-11 12:39:37 --> UTF-8 Support Enabled
INFO - 2025-05-11 12:39:37 --> Utf8 Class Initialized
INFO - 2025-05-11 12:39:37 --> URI Class Initialized
INFO - 2025-05-11 12:39:37 --> Router Class Initialized
INFO - 2025-05-11 12:39:37 --> Output Class Initialized
INFO - 2025-05-11 12:39:37 --> Security Class Initialized
DEBUG - 2025-05-11 12:39:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 12:39:37 --> Input Class Initialized
INFO - 2025-05-11 12:39:37 --> Language Class Initialized
INFO - 2025-05-11 12:39:37 --> Loader Class Initialized
INFO - 2025-05-11 12:39:37 --> Helper loaded: url_helper
INFO - 2025-05-11 12:39:37 --> Helper loaded: form_helper
INFO - 2025-05-11 12:39:37 --> Database Driver Class Initialized
DEBUG - 2025-05-11 12:39:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 12:39:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 12:39:37 --> Controller Class Initialized
INFO - 2025-05-11 12:39:37 --> Model "User_model" initialized
INFO - 2025-05-11 12:39:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-11 12:39:37 --> Final output sent to browser
DEBUG - 2025-05-11 12:39:37 --> Total execution time: 0.0752
INFO - 2025-05-11 12:39:44 --> Config Class Initialized
INFO - 2025-05-11 12:39:44 --> Hooks Class Initialized
DEBUG - 2025-05-11 12:39:44 --> UTF-8 Support Enabled
INFO - 2025-05-11 12:39:44 --> Utf8 Class Initialized
INFO - 2025-05-11 12:39:44 --> URI Class Initialized
INFO - 2025-05-11 12:39:44 --> Router Class Initialized
INFO - 2025-05-11 12:39:44 --> Output Class Initialized
INFO - 2025-05-11 12:39:44 --> Security Class Initialized
DEBUG - 2025-05-11 12:39:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 12:39:44 --> Input Class Initialized
INFO - 2025-05-11 12:39:44 --> Language Class Initialized
INFO - 2025-05-11 12:39:44 --> Loader Class Initialized
INFO - 2025-05-11 12:39:44 --> Helper loaded: url_helper
INFO - 2025-05-11 12:39:44 --> Helper loaded: form_helper
INFO - 2025-05-11 12:39:44 --> Database Driver Class Initialized
DEBUG - 2025-05-11 12:39:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 12:39:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 12:39:44 --> Controller Class Initialized
INFO - 2025-05-11 12:39:44 --> Model "User_model" initialized
INFO - 2025-05-11 12:39:44 --> Config Class Initialized
INFO - 2025-05-11 12:39:44 --> Hooks Class Initialized
DEBUG - 2025-05-11 12:39:44 --> UTF-8 Support Enabled
INFO - 2025-05-11 12:39:44 --> Utf8 Class Initialized
INFO - 2025-05-11 12:39:44 --> URI Class Initialized
INFO - 2025-05-11 12:39:44 --> Router Class Initialized
INFO - 2025-05-11 12:39:44 --> Output Class Initialized
INFO - 2025-05-11 12:39:44 --> Security Class Initialized
DEBUG - 2025-05-11 12:39:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 12:39:44 --> Input Class Initialized
INFO - 2025-05-11 12:39:44 --> Language Class Initialized
INFO - 2025-05-11 12:39:44 --> Loader Class Initialized
INFO - 2025-05-11 12:39:44 --> Helper loaded: url_helper
INFO - 2025-05-11 12:39:44 --> Helper loaded: form_helper
INFO - 2025-05-11 12:39:44 --> Database Driver Class Initialized
DEBUG - 2025-05-11 12:39:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 12:39:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 12:39:44 --> Controller Class Initialized
INFO - 2025-05-11 12:39:44 --> Model "User_model" initialized
INFO - 2025-05-11 12:39:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard.php
INFO - 2025-05-11 12:39:44 --> Final output sent to browser
DEBUG - 2025-05-11 12:39:44 --> Total execution time: 0.0798
INFO - 2025-05-11 12:40:27 --> Config Class Initialized
INFO - 2025-05-11 12:40:27 --> Hooks Class Initialized
DEBUG - 2025-05-11 12:40:27 --> UTF-8 Support Enabled
INFO - 2025-05-11 12:40:27 --> Utf8 Class Initialized
INFO - 2025-05-11 12:40:27 --> URI Class Initialized
INFO - 2025-05-11 12:40:27 --> Router Class Initialized
INFO - 2025-05-11 12:40:27 --> Output Class Initialized
INFO - 2025-05-11 12:40:27 --> Security Class Initialized
DEBUG - 2025-05-11 12:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 12:40:27 --> Input Class Initialized
INFO - 2025-05-11 12:40:27 --> Language Class Initialized
INFO - 2025-05-11 12:40:27 --> Loader Class Initialized
INFO - 2025-05-11 12:40:27 --> Helper loaded: url_helper
INFO - 2025-05-11 12:40:27 --> Helper loaded: form_helper
INFO - 2025-05-11 12:40:27 --> Database Driver Class Initialized
DEBUG - 2025-05-11 12:40:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 12:40:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 12:40:27 --> Controller Class Initialized
INFO - 2025-05-11 12:40:27 --> Model "User_model" initialized
INFO - 2025-05-11 12:40:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-11 12:40:27 --> Final output sent to browser
DEBUG - 2025-05-11 12:40:27 --> Total execution time: 0.0826
INFO - 2025-05-11 12:40:29 --> Config Class Initialized
INFO - 2025-05-11 12:40:29 --> Hooks Class Initialized
DEBUG - 2025-05-11 12:40:29 --> UTF-8 Support Enabled
INFO - 2025-05-11 12:40:29 --> Utf8 Class Initialized
INFO - 2025-05-11 12:40:29 --> URI Class Initialized
INFO - 2025-05-11 12:40:29 --> Router Class Initialized
INFO - 2025-05-11 12:40:29 --> Output Class Initialized
INFO - 2025-05-11 12:40:29 --> Security Class Initialized
DEBUG - 2025-05-11 12:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 12:40:29 --> Input Class Initialized
INFO - 2025-05-11 12:40:29 --> Language Class Initialized
INFO - 2025-05-11 12:40:29 --> Loader Class Initialized
INFO - 2025-05-11 12:40:29 --> Helper loaded: url_helper
INFO - 2025-05-11 12:40:29 --> Helper loaded: form_helper
INFO - 2025-05-11 12:40:29 --> Database Driver Class Initialized
DEBUG - 2025-05-11 12:40:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 12:40:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 12:40:29 --> Controller Class Initialized
INFO - 2025-05-11 12:40:29 --> Model "User_model" initialized
INFO - 2025-05-11 12:40:29 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-11 12:40:29 --> Final output sent to browser
DEBUG - 2025-05-11 12:40:29 --> Total execution time: 0.0923
INFO - 2025-05-11 12:40:31 --> Config Class Initialized
INFO - 2025-05-11 12:40:31 --> Hooks Class Initialized
DEBUG - 2025-05-11 12:40:31 --> UTF-8 Support Enabled
INFO - 2025-05-11 12:40:31 --> Utf8 Class Initialized
INFO - 2025-05-11 12:40:31 --> URI Class Initialized
INFO - 2025-05-11 12:40:31 --> Router Class Initialized
INFO - 2025-05-11 12:40:31 --> Output Class Initialized
INFO - 2025-05-11 12:40:31 --> Security Class Initialized
DEBUG - 2025-05-11 12:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 12:40:31 --> Input Class Initialized
INFO - 2025-05-11 12:40:31 --> Language Class Initialized
INFO - 2025-05-11 12:40:31 --> Loader Class Initialized
INFO - 2025-05-11 12:40:31 --> Helper loaded: url_helper
INFO - 2025-05-11 12:40:31 --> Helper loaded: form_helper
INFO - 2025-05-11 12:40:31 --> Database Driver Class Initialized
DEBUG - 2025-05-11 12:40:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 12:40:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 12:40:31 --> Controller Class Initialized
INFO - 2025-05-11 12:40:31 --> Model "User_model" initialized
INFO - 2025-05-11 12:40:31 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-11 12:40:31 --> Final output sent to browser
DEBUG - 2025-05-11 12:40:31 --> Total execution time: 0.0658
INFO - 2025-05-11 12:40:32 --> Config Class Initialized
INFO - 2025-05-11 12:40:32 --> Hooks Class Initialized
DEBUG - 2025-05-11 12:40:32 --> UTF-8 Support Enabled
INFO - 2025-05-11 12:40:32 --> Utf8 Class Initialized
INFO - 2025-05-11 12:40:32 --> URI Class Initialized
INFO - 2025-05-11 12:40:32 --> Router Class Initialized
INFO - 2025-05-11 12:40:32 --> Output Class Initialized
INFO - 2025-05-11 12:40:32 --> Security Class Initialized
DEBUG - 2025-05-11 12:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 12:40:32 --> Input Class Initialized
INFO - 2025-05-11 12:40:32 --> Language Class Initialized
INFO - 2025-05-11 12:40:32 --> Loader Class Initialized
INFO - 2025-05-11 12:40:32 --> Helper loaded: url_helper
INFO - 2025-05-11 12:40:32 --> Helper loaded: form_helper
INFO - 2025-05-11 12:40:32 --> Database Driver Class Initialized
DEBUG - 2025-05-11 12:40:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 12:40:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 12:40:32 --> Controller Class Initialized
INFO - 2025-05-11 12:40:32 --> Model "User_model" initialized
INFO - 2025-05-11 12:40:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-11 12:40:32 --> Final output sent to browser
DEBUG - 2025-05-11 12:40:32 --> Total execution time: 0.0940
INFO - 2025-05-11 12:41:10 --> Config Class Initialized
INFO - 2025-05-11 12:41:10 --> Hooks Class Initialized
DEBUG - 2025-05-11 12:41:10 --> UTF-8 Support Enabled
INFO - 2025-05-11 12:41:10 --> Utf8 Class Initialized
INFO - 2025-05-11 12:41:10 --> URI Class Initialized
INFO - 2025-05-11 12:41:10 --> Router Class Initialized
INFO - 2025-05-11 12:41:10 --> Output Class Initialized
INFO - 2025-05-11 12:41:10 --> Security Class Initialized
DEBUG - 2025-05-11 12:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 12:41:10 --> Input Class Initialized
INFO - 2025-05-11 12:41:10 --> Language Class Initialized
INFO - 2025-05-11 12:41:10 --> Loader Class Initialized
INFO - 2025-05-11 12:41:10 --> Helper loaded: url_helper
INFO - 2025-05-11 12:41:10 --> Helper loaded: form_helper
INFO - 2025-05-11 12:41:10 --> Database Driver Class Initialized
DEBUG - 2025-05-11 12:41:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 12:41:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 12:41:10 --> Controller Class Initialized
INFO - 2025-05-11 12:41:10 --> Model "User_model" initialized
INFO - 2025-05-11 12:41:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-11 12:41:10 --> Final output sent to browser
DEBUG - 2025-05-11 12:41:10 --> Total execution time: 0.0813
INFO - 2025-05-11 12:55:56 --> Config Class Initialized
INFO - 2025-05-11 12:55:56 --> Hooks Class Initialized
DEBUG - 2025-05-11 12:55:56 --> UTF-8 Support Enabled
INFO - 2025-05-11 12:55:56 --> Utf8 Class Initialized
INFO - 2025-05-11 12:55:56 --> URI Class Initialized
INFO - 2025-05-11 12:55:56 --> Router Class Initialized
INFO - 2025-05-11 12:55:56 --> Output Class Initialized
INFO - 2025-05-11 12:55:56 --> Security Class Initialized
DEBUG - 2025-05-11 12:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 12:55:56 --> Input Class Initialized
INFO - 2025-05-11 12:55:56 --> Language Class Initialized
INFO - 2025-05-11 12:55:56 --> Loader Class Initialized
INFO - 2025-05-11 12:55:56 --> Helper loaded: url_helper
INFO - 2025-05-11 12:55:56 --> Helper loaded: form_helper
INFO - 2025-05-11 12:55:56 --> Database Driver Class Initialized
DEBUG - 2025-05-11 12:55:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 12:55:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 12:55:56 --> Controller Class Initialized
INFO - 2025-05-11 12:55:56 --> Model "User_model" initialized
INFO - 2025-05-11 12:55:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-11 12:55:56 --> Final output sent to browser
DEBUG - 2025-05-11 12:55:56 --> Total execution time: 0.0741
INFO - 2025-05-11 12:55:58 --> Config Class Initialized
INFO - 2025-05-11 12:55:58 --> Hooks Class Initialized
DEBUG - 2025-05-11 12:55:58 --> UTF-8 Support Enabled
INFO - 2025-05-11 12:55:58 --> Utf8 Class Initialized
INFO - 2025-05-11 12:55:58 --> URI Class Initialized
INFO - 2025-05-11 12:55:58 --> Router Class Initialized
INFO - 2025-05-11 12:55:58 --> Output Class Initialized
INFO - 2025-05-11 12:55:58 --> Security Class Initialized
DEBUG - 2025-05-11 12:55:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 12:55:58 --> Input Class Initialized
INFO - 2025-05-11 12:55:58 --> Language Class Initialized
INFO - 2025-05-11 12:55:58 --> Loader Class Initialized
INFO - 2025-05-11 12:55:58 --> Helper loaded: url_helper
INFO - 2025-05-11 12:55:58 --> Helper loaded: form_helper
INFO - 2025-05-11 12:55:58 --> Database Driver Class Initialized
DEBUG - 2025-05-11 12:55:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 12:55:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 12:55:58 --> Controller Class Initialized
INFO - 2025-05-11 12:55:58 --> Model "User_model" initialized
INFO - 2025-05-11 12:55:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/register.php
INFO - 2025-05-11 12:55:58 --> Final output sent to browser
DEBUG - 2025-05-11 12:55:58 --> Total execution time: 0.0710
INFO - 2025-05-11 12:56:06 --> Config Class Initialized
INFO - 2025-05-11 12:56:06 --> Hooks Class Initialized
DEBUG - 2025-05-11 12:56:06 --> UTF-8 Support Enabled
INFO - 2025-05-11 12:56:06 --> Utf8 Class Initialized
INFO - 2025-05-11 12:56:06 --> URI Class Initialized
INFO - 2025-05-11 12:56:06 --> Router Class Initialized
INFO - 2025-05-11 12:56:06 --> Output Class Initialized
INFO - 2025-05-11 12:56:06 --> Security Class Initialized
DEBUG - 2025-05-11 12:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 12:56:06 --> Input Class Initialized
INFO - 2025-05-11 12:56:06 --> Language Class Initialized
INFO - 2025-05-11 12:56:06 --> Loader Class Initialized
INFO - 2025-05-11 12:56:06 --> Helper loaded: url_helper
INFO - 2025-05-11 12:56:06 --> Helper loaded: form_helper
INFO - 2025-05-11 12:56:06 --> Database Driver Class Initialized
DEBUG - 2025-05-11 12:56:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 12:56:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 12:56:06 --> Controller Class Initialized
INFO - 2025-05-11 12:56:06 --> Model "User_model" initialized
INFO - 2025-05-11 12:56:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-11 12:56:06 --> Final output sent to browser
DEBUG - 2025-05-11 12:56:06 --> Total execution time: 0.0661
INFO - 2025-05-11 12:56:08 --> Config Class Initialized
INFO - 2025-05-11 12:56:08 --> Hooks Class Initialized
DEBUG - 2025-05-11 12:56:08 --> UTF-8 Support Enabled
INFO - 2025-05-11 12:56:08 --> Utf8 Class Initialized
INFO - 2025-05-11 12:56:08 --> URI Class Initialized
INFO - 2025-05-11 12:56:08 --> Router Class Initialized
INFO - 2025-05-11 12:56:08 --> Output Class Initialized
INFO - 2025-05-11 12:56:08 --> Security Class Initialized
DEBUG - 2025-05-11 12:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 12:56:08 --> Input Class Initialized
INFO - 2025-05-11 12:56:08 --> Language Class Initialized
INFO - 2025-05-11 12:56:08 --> Loader Class Initialized
INFO - 2025-05-11 12:56:08 --> Helper loaded: url_helper
INFO - 2025-05-11 12:56:08 --> Helper loaded: form_helper
INFO - 2025-05-11 12:56:08 --> Database Driver Class Initialized
DEBUG - 2025-05-11 12:56:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 12:56:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 12:56:08 --> Controller Class Initialized
INFO - 2025-05-11 12:56:08 --> Model "User_model" initialized
INFO - 2025-05-11 12:56:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/register.php
INFO - 2025-05-11 12:56:08 --> Final output sent to browser
DEBUG - 2025-05-11 12:56:08 --> Total execution time: 0.0685
INFO - 2025-05-11 12:56:52 --> Config Class Initialized
INFO - 2025-05-11 12:56:52 --> Hooks Class Initialized
DEBUG - 2025-05-11 12:56:52 --> UTF-8 Support Enabled
INFO - 2025-05-11 12:56:52 --> Utf8 Class Initialized
INFO - 2025-05-11 12:56:52 --> URI Class Initialized
INFO - 2025-05-11 12:56:52 --> Router Class Initialized
INFO - 2025-05-11 12:56:52 --> Output Class Initialized
INFO - 2025-05-11 12:56:52 --> Security Class Initialized
DEBUG - 2025-05-11 12:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 12:56:52 --> Input Class Initialized
INFO - 2025-05-11 12:56:52 --> Language Class Initialized
INFO - 2025-05-11 12:56:52 --> Loader Class Initialized
INFO - 2025-05-11 12:56:52 --> Helper loaded: url_helper
INFO - 2025-05-11 12:56:52 --> Helper loaded: form_helper
INFO - 2025-05-11 12:56:52 --> Database Driver Class Initialized
DEBUG - 2025-05-11 12:56:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 12:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 12:56:52 --> Controller Class Initialized
INFO - 2025-05-11 12:56:52 --> Model "User_model" initialized
INFO - 2025-05-11 12:56:52 --> Config Class Initialized
INFO - 2025-05-11 12:56:52 --> Hooks Class Initialized
DEBUG - 2025-05-11 12:56:52 --> UTF-8 Support Enabled
INFO - 2025-05-11 12:56:52 --> Utf8 Class Initialized
INFO - 2025-05-11 12:56:52 --> URI Class Initialized
INFO - 2025-05-11 12:56:52 --> Router Class Initialized
INFO - 2025-05-11 12:56:52 --> Output Class Initialized
INFO - 2025-05-11 12:56:52 --> Security Class Initialized
DEBUG - 2025-05-11 12:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 12:56:52 --> Input Class Initialized
INFO - 2025-05-11 12:56:52 --> Language Class Initialized
INFO - 2025-05-11 12:56:52 --> Loader Class Initialized
INFO - 2025-05-11 12:56:52 --> Helper loaded: url_helper
INFO - 2025-05-11 12:56:52 --> Helper loaded: form_helper
INFO - 2025-05-11 12:56:52 --> Database Driver Class Initialized
DEBUG - 2025-05-11 12:56:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 12:56:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 12:56:52 --> Controller Class Initialized
INFO - 2025-05-11 12:56:52 --> Model "User_model" initialized
INFO - 2025-05-11 12:56:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-11 12:56:52 --> Final output sent to browser
DEBUG - 2025-05-11 12:56:52 --> Total execution time: 0.0844
INFO - 2025-05-11 12:57:16 --> Config Class Initialized
INFO - 2025-05-11 12:57:16 --> Hooks Class Initialized
DEBUG - 2025-05-11 12:57:16 --> UTF-8 Support Enabled
INFO - 2025-05-11 12:57:16 --> Utf8 Class Initialized
INFO - 2025-05-11 12:57:16 --> URI Class Initialized
INFO - 2025-05-11 12:57:16 --> Router Class Initialized
INFO - 2025-05-11 12:57:16 --> Output Class Initialized
INFO - 2025-05-11 12:57:16 --> Security Class Initialized
DEBUG - 2025-05-11 12:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 12:57:16 --> Input Class Initialized
INFO - 2025-05-11 12:57:16 --> Language Class Initialized
INFO - 2025-05-11 12:57:16 --> Loader Class Initialized
INFO - 2025-05-11 12:57:16 --> Helper loaded: url_helper
INFO - 2025-05-11 12:57:16 --> Helper loaded: form_helper
INFO - 2025-05-11 12:57:16 --> Database Driver Class Initialized
DEBUG - 2025-05-11 12:57:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 12:57:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 12:57:16 --> Controller Class Initialized
INFO - 2025-05-11 12:57:16 --> Model "User_model" initialized
INFO - 2025-05-11 12:57:16 --> Config Class Initialized
INFO - 2025-05-11 12:57:16 --> Hooks Class Initialized
DEBUG - 2025-05-11 12:57:16 --> UTF-8 Support Enabled
INFO - 2025-05-11 12:57:16 --> Utf8 Class Initialized
INFO - 2025-05-11 12:57:16 --> URI Class Initialized
INFO - 2025-05-11 12:57:16 --> Router Class Initialized
INFO - 2025-05-11 12:57:16 --> Output Class Initialized
INFO - 2025-05-11 12:57:16 --> Security Class Initialized
DEBUG - 2025-05-11 12:57:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 12:57:16 --> Input Class Initialized
INFO - 2025-05-11 12:57:16 --> Language Class Initialized
INFO - 2025-05-11 12:57:16 --> Loader Class Initialized
INFO - 2025-05-11 12:57:16 --> Helper loaded: url_helper
INFO - 2025-05-11 12:57:16 --> Helper loaded: form_helper
INFO - 2025-05-11 12:57:16 --> Database Driver Class Initialized
DEBUG - 2025-05-11 12:57:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 12:57:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 12:57:16 --> Controller Class Initialized
INFO - 2025-05-11 12:57:16 --> Model "User_model" initialized
INFO - 2025-05-11 12:57:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard.php
INFO - 2025-05-11 12:57:16 --> Final output sent to browser
DEBUG - 2025-05-11 12:57:16 --> Total execution time: 0.0613
INFO - 2025-05-11 12:57:25 --> Config Class Initialized
INFO - 2025-05-11 12:57:25 --> Hooks Class Initialized
DEBUG - 2025-05-11 12:57:25 --> UTF-8 Support Enabled
INFO - 2025-05-11 12:57:25 --> Utf8 Class Initialized
INFO - 2025-05-11 12:57:25 --> URI Class Initialized
INFO - 2025-05-11 12:57:25 --> Router Class Initialized
INFO - 2025-05-11 12:57:25 --> Output Class Initialized
INFO - 2025-05-11 12:57:25 --> Security Class Initialized
DEBUG - 2025-05-11 12:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 12:57:25 --> Input Class Initialized
INFO - 2025-05-11 12:57:25 --> Language Class Initialized
INFO - 2025-05-11 12:57:25 --> Loader Class Initialized
INFO - 2025-05-11 12:57:25 --> Helper loaded: url_helper
INFO - 2025-05-11 12:57:25 --> Helper loaded: form_helper
INFO - 2025-05-11 12:57:25 --> Database Driver Class Initialized
DEBUG - 2025-05-11 12:57:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 12:57:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 12:57:25 --> Controller Class Initialized
INFO - 2025-05-11 12:57:25 --> Model "Workout_model" initialized
INFO - 2025-05-11 12:57:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-11 12:57:25 --> Final output sent to browser
DEBUG - 2025-05-11 12:57:25 --> Total execution time: 0.2054
INFO - 2025-05-11 12:57:42 --> Config Class Initialized
INFO - 2025-05-11 12:57:42 --> Hooks Class Initialized
DEBUG - 2025-05-11 12:57:42 --> UTF-8 Support Enabled
INFO - 2025-05-11 12:57:42 --> Utf8 Class Initialized
INFO - 2025-05-11 12:57:42 --> URI Class Initialized
INFO - 2025-05-11 12:57:42 --> Router Class Initialized
INFO - 2025-05-11 12:57:42 --> Output Class Initialized
INFO - 2025-05-11 12:57:42 --> Security Class Initialized
DEBUG - 2025-05-11 12:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 12:57:42 --> Input Class Initialized
INFO - 2025-05-11 12:57:42 --> Language Class Initialized
INFO - 2025-05-11 12:57:42 --> Loader Class Initialized
INFO - 2025-05-11 12:57:42 --> Helper loaded: url_helper
INFO - 2025-05-11 12:57:42 --> Helper loaded: form_helper
INFO - 2025-05-11 12:57:42 --> Database Driver Class Initialized
DEBUG - 2025-05-11 12:57:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 12:57:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 12:57:42 --> Controller Class Initialized
INFO - 2025-05-11 12:57:42 --> Model "User_model" initialized
INFO - 2025-05-11 12:57:43 --> Config Class Initialized
INFO - 2025-05-11 12:57:43 --> Hooks Class Initialized
DEBUG - 2025-05-11 12:57:43 --> UTF-8 Support Enabled
INFO - 2025-05-11 12:57:43 --> Utf8 Class Initialized
INFO - 2025-05-11 12:57:43 --> URI Class Initialized
INFO - 2025-05-11 12:57:43 --> Router Class Initialized
INFO - 2025-05-11 12:57:43 --> Output Class Initialized
INFO - 2025-05-11 12:57:43 --> Security Class Initialized
DEBUG - 2025-05-11 12:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 12:57:43 --> Input Class Initialized
INFO - 2025-05-11 12:57:43 --> Language Class Initialized
INFO - 2025-05-11 12:57:43 --> Loader Class Initialized
INFO - 2025-05-11 12:57:43 --> Helper loaded: url_helper
INFO - 2025-05-11 12:57:43 --> Helper loaded: form_helper
INFO - 2025-05-11 12:57:43 --> Database Driver Class Initialized
DEBUG - 2025-05-11 12:57:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 12:57:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 12:57:43 --> Controller Class Initialized
INFO - 2025-05-11 12:57:43 --> Model "User_model" initialized
INFO - 2025-05-11 12:57:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard.php
INFO - 2025-05-11 12:57:43 --> Final output sent to browser
DEBUG - 2025-05-11 12:57:43 --> Total execution time: 0.0859
INFO - 2025-05-11 12:57:45 --> Config Class Initialized
INFO - 2025-05-11 12:57:45 --> Hooks Class Initialized
DEBUG - 2025-05-11 12:57:45 --> UTF-8 Support Enabled
INFO - 2025-05-11 12:57:45 --> Utf8 Class Initialized
INFO - 2025-05-11 12:57:45 --> URI Class Initialized
INFO - 2025-05-11 12:57:45 --> Router Class Initialized
INFO - 2025-05-11 12:57:45 --> Output Class Initialized
INFO - 2025-05-11 12:57:45 --> Security Class Initialized
DEBUG - 2025-05-11 12:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 12:57:45 --> Input Class Initialized
INFO - 2025-05-11 12:57:45 --> Language Class Initialized
INFO - 2025-05-11 12:57:45 --> Loader Class Initialized
INFO - 2025-05-11 12:57:45 --> Helper loaded: url_helper
INFO - 2025-05-11 12:57:45 --> Helper loaded: form_helper
INFO - 2025-05-11 12:57:45 --> Database Driver Class Initialized
DEBUG - 2025-05-11 12:57:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 12:57:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 12:57:45 --> Controller Class Initialized
INFO - 2025-05-11 12:57:45 --> Model "Workout_model" initialized
INFO - 2025-05-11 12:57:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-11 12:57:45 --> Final output sent to browser
DEBUG - 2025-05-11 12:57:45 --> Total execution time: 0.0997
INFO - 2025-05-11 12:58:02 --> Config Class Initialized
INFO - 2025-05-11 12:58:02 --> Hooks Class Initialized
DEBUG - 2025-05-11 12:58:02 --> UTF-8 Support Enabled
INFO - 2025-05-11 12:58:02 --> Utf8 Class Initialized
INFO - 2025-05-11 12:58:02 --> URI Class Initialized
DEBUG - 2025-05-11 12:58:02 --> No URI present. Default controller set.
INFO - 2025-05-11 12:58:02 --> Router Class Initialized
INFO - 2025-05-11 12:58:02 --> Output Class Initialized
INFO - 2025-05-11 12:58:02 --> Security Class Initialized
DEBUG - 2025-05-11 12:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 12:58:02 --> Input Class Initialized
INFO - 2025-05-11 12:58:02 --> Language Class Initialized
INFO - 2025-05-11 12:58:02 --> Loader Class Initialized
INFO - 2025-05-11 12:58:02 --> Helper loaded: url_helper
INFO - 2025-05-11 12:58:02 --> Helper loaded: form_helper
INFO - 2025-05-11 12:58:02 --> Database Driver Class Initialized
DEBUG - 2025-05-11 12:58:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 12:58:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 12:58:02 --> Controller Class Initialized
INFO - 2025-05-11 12:58:02 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-11 12:58:02 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-11 12:58:02 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-11 12:58:02 --> Final output sent to browser
DEBUG - 2025-05-11 12:58:02 --> Total execution time: 0.0728
INFO - 2025-05-11 13:18:51 --> Config Class Initialized
INFO - 2025-05-11 13:18:51 --> Hooks Class Initialized
DEBUG - 2025-05-11 13:18:51 --> UTF-8 Support Enabled
INFO - 2025-05-11 13:18:51 --> Utf8 Class Initialized
INFO - 2025-05-11 13:18:51 --> URI Class Initialized
DEBUG - 2025-05-11 13:18:51 --> No URI present. Default controller set.
INFO - 2025-05-11 13:18:51 --> Router Class Initialized
INFO - 2025-05-11 13:18:51 --> Output Class Initialized
INFO - 2025-05-11 13:18:51 --> Security Class Initialized
DEBUG - 2025-05-11 13:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 13:18:51 --> Input Class Initialized
INFO - 2025-05-11 13:18:51 --> Language Class Initialized
INFO - 2025-05-11 13:18:51 --> Loader Class Initialized
INFO - 2025-05-11 13:18:51 --> Helper loaded: url_helper
INFO - 2025-05-11 13:18:51 --> Helper loaded: form_helper
INFO - 2025-05-11 13:18:51 --> Database Driver Class Initialized
DEBUG - 2025-05-11 13:18:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 13:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 13:18:51 --> Controller Class Initialized
INFO - 2025-05-11 13:18:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-11 13:18:51 --> Final output sent to browser
DEBUG - 2025-05-11 13:18:51 --> Total execution time: 0.0918
INFO - 2025-05-11 13:25:37 --> Config Class Initialized
INFO - 2025-05-11 13:25:37 --> Hooks Class Initialized
DEBUG - 2025-05-11 13:25:37 --> UTF-8 Support Enabled
INFO - 2025-05-11 13:25:37 --> Utf8 Class Initialized
INFO - 2025-05-11 13:25:37 --> URI Class Initialized
DEBUG - 2025-05-11 13:25:37 --> No URI present. Default controller set.
INFO - 2025-05-11 13:25:37 --> Router Class Initialized
INFO - 2025-05-11 13:25:37 --> Output Class Initialized
INFO - 2025-05-11 13:25:37 --> Security Class Initialized
DEBUG - 2025-05-11 13:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 13:25:37 --> Input Class Initialized
INFO - 2025-05-11 13:25:37 --> Language Class Initialized
INFO - 2025-05-11 13:25:37 --> Loader Class Initialized
INFO - 2025-05-11 13:25:37 --> Helper loaded: url_helper
INFO - 2025-05-11 13:25:37 --> Helper loaded: form_helper
INFO - 2025-05-11 13:25:37 --> Database Driver Class Initialized
DEBUG - 2025-05-11 13:25:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 13:25:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 13:25:37 --> Controller Class Initialized
INFO - 2025-05-11 13:25:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-11 13:25:37 --> Final output sent to browser
DEBUG - 2025-05-11 13:25:37 --> Total execution time: 0.0739
INFO - 2025-05-11 13:46:51 --> Config Class Initialized
INFO - 2025-05-11 13:46:51 --> Hooks Class Initialized
DEBUG - 2025-05-11 13:46:51 --> UTF-8 Support Enabled
INFO - 2025-05-11 13:46:51 --> Utf8 Class Initialized
INFO - 2025-05-11 13:46:51 --> URI Class Initialized
INFO - 2025-05-11 13:46:51 --> Router Class Initialized
INFO - 2025-05-11 13:46:51 --> Output Class Initialized
INFO - 2025-05-11 13:46:51 --> Security Class Initialized
DEBUG - 2025-05-11 13:46:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 13:46:51 --> Input Class Initialized
INFO - 2025-05-11 13:46:51 --> Language Class Initialized
INFO - 2025-05-11 13:46:51 --> Loader Class Initialized
INFO - 2025-05-11 13:46:51 --> Helper loaded: url_helper
INFO - 2025-05-11 13:46:52 --> Helper loaded: form_helper
INFO - 2025-05-11 13:46:52 --> Database Driver Class Initialized
DEBUG - 2025-05-11 13:46:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 13:46:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 13:46:52 --> Controller Class Initialized
INFO - 2025-05-11 13:46:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/artikel.php
INFO - 2025-05-11 13:46:52 --> Final output sent to browser
DEBUG - 2025-05-11 13:46:52 --> Total execution time: 1.6294
INFO - 2025-05-11 13:48:21 --> Config Class Initialized
INFO - 2025-05-11 13:48:21 --> Hooks Class Initialized
DEBUG - 2025-05-11 13:48:21 --> UTF-8 Support Enabled
INFO - 2025-05-11 13:48:21 --> Utf8 Class Initialized
INFO - 2025-05-11 13:48:21 --> URI Class Initialized
INFO - 2025-05-11 13:48:21 --> Router Class Initialized
INFO - 2025-05-11 13:48:21 --> Output Class Initialized
INFO - 2025-05-11 13:48:21 --> Security Class Initialized
DEBUG - 2025-05-11 13:48:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 13:48:21 --> Input Class Initialized
INFO - 2025-05-11 13:48:21 --> Language Class Initialized
INFO - 2025-05-11 13:48:21 --> Loader Class Initialized
INFO - 2025-05-11 13:48:21 --> Helper loaded: url_helper
INFO - 2025-05-11 13:48:21 --> Helper loaded: form_helper
INFO - 2025-05-11 13:48:21 --> Database Driver Class Initialized
DEBUG - 2025-05-11 13:48:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 13:48:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 13:48:21 --> Controller Class Initialized
INFO - 2025-05-11 13:48:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/artikel.php
INFO - 2025-05-11 13:48:21 --> Final output sent to browser
DEBUG - 2025-05-11 13:48:21 --> Total execution time: 0.0634
INFO - 2025-05-11 13:50:54 --> Config Class Initialized
INFO - 2025-05-11 13:50:54 --> Hooks Class Initialized
DEBUG - 2025-05-11 13:50:54 --> UTF-8 Support Enabled
INFO - 2025-05-11 13:50:54 --> Utf8 Class Initialized
INFO - 2025-05-11 13:50:54 --> URI Class Initialized
INFO - 2025-05-11 13:50:54 --> Router Class Initialized
INFO - 2025-05-11 13:50:54 --> Output Class Initialized
INFO - 2025-05-11 13:50:54 --> Security Class Initialized
DEBUG - 2025-05-11 13:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 13:50:54 --> Input Class Initialized
INFO - 2025-05-11 13:50:54 --> Language Class Initialized
INFO - 2025-05-11 13:50:54 --> Loader Class Initialized
INFO - 2025-05-11 13:50:54 --> Helper loaded: url_helper
INFO - 2025-05-11 13:50:54 --> Helper loaded: form_helper
INFO - 2025-05-11 13:50:54 --> Database Driver Class Initialized
DEBUG - 2025-05-11 13:50:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 13:50:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 13:50:54 --> Controller Class Initialized
INFO - 2025-05-11 13:50:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/artikel.php
INFO - 2025-05-11 13:50:54 --> Final output sent to browser
DEBUG - 2025-05-11 13:50:54 --> Total execution time: 0.0634
INFO - 2025-05-11 13:53:37 --> Config Class Initialized
INFO - 2025-05-11 13:53:37 --> Hooks Class Initialized
DEBUG - 2025-05-11 13:53:37 --> UTF-8 Support Enabled
INFO - 2025-05-11 13:53:37 --> Utf8 Class Initialized
INFO - 2025-05-11 13:53:37 --> URI Class Initialized
INFO - 2025-05-11 13:53:37 --> Router Class Initialized
INFO - 2025-05-11 13:53:37 --> Output Class Initialized
INFO - 2025-05-11 13:53:37 --> Security Class Initialized
DEBUG - 2025-05-11 13:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 13:53:37 --> Input Class Initialized
INFO - 2025-05-11 13:53:37 --> Language Class Initialized
INFO - 2025-05-11 13:53:37 --> Loader Class Initialized
INFO - 2025-05-11 13:53:37 --> Helper loaded: url_helper
INFO - 2025-05-11 13:53:37 --> Helper loaded: form_helper
INFO - 2025-05-11 13:53:37 --> Database Driver Class Initialized
DEBUG - 2025-05-11 13:53:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 13:53:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 13:53:37 --> Controller Class Initialized
INFO - 2025-05-11 13:53:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/artikel.php
INFO - 2025-05-11 13:53:37 --> Final output sent to browser
DEBUG - 2025-05-11 13:53:37 --> Total execution time: 0.0577
INFO - 2025-05-11 13:56:15 --> Config Class Initialized
INFO - 2025-05-11 13:56:15 --> Hooks Class Initialized
DEBUG - 2025-05-11 13:56:15 --> UTF-8 Support Enabled
INFO - 2025-05-11 13:56:15 --> Utf8 Class Initialized
INFO - 2025-05-11 13:56:15 --> URI Class Initialized
INFO - 2025-05-11 13:56:15 --> Router Class Initialized
INFO - 2025-05-11 13:56:15 --> Output Class Initialized
INFO - 2025-05-11 13:56:15 --> Security Class Initialized
DEBUG - 2025-05-11 13:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 13:56:15 --> Input Class Initialized
INFO - 2025-05-11 13:56:15 --> Language Class Initialized
INFO - 2025-05-11 13:56:15 --> Loader Class Initialized
INFO - 2025-05-11 13:56:15 --> Helper loaded: url_helper
INFO - 2025-05-11 13:56:15 --> Helper loaded: form_helper
INFO - 2025-05-11 13:56:15 --> Database Driver Class Initialized
DEBUG - 2025-05-11 13:56:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 13:56:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 13:56:15 --> Controller Class Initialized
INFO - 2025-05-11 13:56:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/artikel.php
INFO - 2025-05-11 13:56:15 --> Final output sent to browser
DEBUG - 2025-05-11 13:56:15 --> Total execution time: 0.0502
INFO - 2025-05-11 13:58:50 --> Config Class Initialized
INFO - 2025-05-11 13:58:50 --> Hooks Class Initialized
DEBUG - 2025-05-11 13:58:50 --> UTF-8 Support Enabled
INFO - 2025-05-11 13:58:50 --> Utf8 Class Initialized
INFO - 2025-05-11 13:58:50 --> URI Class Initialized
INFO - 2025-05-11 13:58:50 --> Router Class Initialized
INFO - 2025-05-11 13:58:50 --> Output Class Initialized
INFO - 2025-05-11 13:58:50 --> Security Class Initialized
DEBUG - 2025-05-11 13:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 13:58:50 --> Input Class Initialized
INFO - 2025-05-11 13:58:50 --> Language Class Initialized
INFO - 2025-05-11 13:58:50 --> Loader Class Initialized
INFO - 2025-05-11 13:58:50 --> Helper loaded: url_helper
INFO - 2025-05-11 13:58:50 --> Helper loaded: form_helper
INFO - 2025-05-11 13:58:50 --> Database Driver Class Initialized
DEBUG - 2025-05-11 13:58:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 13:58:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 13:58:50 --> Controller Class Initialized
INFO - 2025-05-11 13:58:50 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/artikel.php
INFO - 2025-05-11 13:58:50 --> Final output sent to browser
DEBUG - 2025-05-11 13:58:50 --> Total execution time: 0.0737
INFO - 2025-05-11 14:00:43 --> Config Class Initialized
INFO - 2025-05-11 14:00:43 --> Hooks Class Initialized
DEBUG - 2025-05-11 14:00:43 --> UTF-8 Support Enabled
INFO - 2025-05-11 14:00:43 --> Utf8 Class Initialized
INFO - 2025-05-11 14:00:43 --> URI Class Initialized
INFO - 2025-05-11 14:00:43 --> Router Class Initialized
INFO - 2025-05-11 14:00:43 --> Output Class Initialized
INFO - 2025-05-11 14:00:43 --> Security Class Initialized
DEBUG - 2025-05-11 14:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 14:00:43 --> Input Class Initialized
INFO - 2025-05-11 14:00:43 --> Language Class Initialized
INFO - 2025-05-11 14:00:43 --> Loader Class Initialized
INFO - 2025-05-11 14:00:43 --> Helper loaded: url_helper
INFO - 2025-05-11 14:00:43 --> Helper loaded: form_helper
INFO - 2025-05-11 14:00:43 --> Database Driver Class Initialized
DEBUG - 2025-05-11 14:00:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 14:00:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 14:00:43 --> Controller Class Initialized
INFO - 2025-05-11 14:00:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/artikel.php
INFO - 2025-05-11 14:00:43 --> Final output sent to browser
DEBUG - 2025-05-11 14:00:43 --> Total execution time: 0.0632
INFO - 2025-05-11 14:01:00 --> Config Class Initialized
INFO - 2025-05-11 14:01:00 --> Hooks Class Initialized
DEBUG - 2025-05-11 14:01:00 --> UTF-8 Support Enabled
INFO - 2025-05-11 14:01:00 --> Utf8 Class Initialized
INFO - 2025-05-11 14:01:00 --> URI Class Initialized
INFO - 2025-05-11 14:01:00 --> Router Class Initialized
INFO - 2025-05-11 14:01:00 --> Output Class Initialized
INFO - 2025-05-11 14:01:00 --> Security Class Initialized
DEBUG - 2025-05-11 14:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 14:01:00 --> Input Class Initialized
INFO - 2025-05-11 14:01:00 --> Language Class Initialized
INFO - 2025-05-11 14:01:00 --> Loader Class Initialized
INFO - 2025-05-11 14:01:00 --> Helper loaded: url_helper
INFO - 2025-05-11 14:01:00 --> Helper loaded: form_helper
INFO - 2025-05-11 14:01:00 --> Database Driver Class Initialized
DEBUG - 2025-05-11 14:01:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 14:01:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 14:01:00 --> Controller Class Initialized
INFO - 2025-05-11 14:01:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-11 14:01:01 --> Final output sent to browser
DEBUG - 2025-05-11 14:01:01 --> Total execution time: 0.0957
INFO - 2025-05-11 14:01:15 --> Config Class Initialized
INFO - 2025-05-11 14:01:15 --> Hooks Class Initialized
DEBUG - 2025-05-11 14:01:15 --> UTF-8 Support Enabled
INFO - 2025-05-11 14:01:15 --> Utf8 Class Initialized
INFO - 2025-05-11 14:01:15 --> URI Class Initialized
INFO - 2025-05-11 14:01:15 --> Router Class Initialized
INFO - 2025-05-11 14:01:15 --> Output Class Initialized
INFO - 2025-05-11 14:01:15 --> Security Class Initialized
DEBUG - 2025-05-11 14:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 14:01:15 --> Input Class Initialized
INFO - 2025-05-11 14:01:15 --> Language Class Initialized
INFO - 2025-05-11 14:01:15 --> Loader Class Initialized
INFO - 2025-05-11 14:01:15 --> Helper loaded: url_helper
INFO - 2025-05-11 14:01:15 --> Helper loaded: form_helper
INFO - 2025-05-11 14:01:15 --> Database Driver Class Initialized
DEBUG - 2025-05-11 14:01:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 14:01:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 14:01:15 --> Controller Class Initialized
INFO - 2025-05-11 14:01:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/artikel.php
INFO - 2025-05-11 14:01:15 --> Final output sent to browser
DEBUG - 2025-05-11 14:01:15 --> Total execution time: 0.0516
INFO - 2025-05-11 14:07:20 --> Config Class Initialized
INFO - 2025-05-11 14:07:20 --> Hooks Class Initialized
DEBUG - 2025-05-11 14:07:20 --> UTF-8 Support Enabled
INFO - 2025-05-11 14:07:20 --> Utf8 Class Initialized
INFO - 2025-05-11 14:07:20 --> URI Class Initialized
INFO - 2025-05-11 14:07:20 --> Router Class Initialized
INFO - 2025-05-11 14:07:20 --> Output Class Initialized
INFO - 2025-05-11 14:07:20 --> Security Class Initialized
DEBUG - 2025-05-11 14:07:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 14:07:20 --> Input Class Initialized
INFO - 2025-05-11 14:07:20 --> Language Class Initialized
INFO - 2025-05-11 14:07:20 --> Loader Class Initialized
INFO - 2025-05-11 14:07:20 --> Helper loaded: url_helper
INFO - 2025-05-11 14:07:20 --> Helper loaded: form_helper
INFO - 2025-05-11 14:07:20 --> Database Driver Class Initialized
DEBUG - 2025-05-11 14:07:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 14:07:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 14:07:20 --> Controller Class Initialized
INFO - 2025-05-11 14:07:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-11 14:07:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-11 14:07:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-11 14:07:20 --> Final output sent to browser
DEBUG - 2025-05-11 14:07:20 --> Total execution time: 0.0551
INFO - 2025-05-11 14:07:51 --> Config Class Initialized
INFO - 2025-05-11 14:07:51 --> Hooks Class Initialized
DEBUG - 2025-05-11 14:07:51 --> UTF-8 Support Enabled
INFO - 2025-05-11 14:07:51 --> Utf8 Class Initialized
INFO - 2025-05-11 14:07:51 --> URI Class Initialized
INFO - 2025-05-11 14:07:51 --> Router Class Initialized
INFO - 2025-05-11 14:07:51 --> Output Class Initialized
INFO - 2025-05-11 14:07:51 --> Security Class Initialized
DEBUG - 2025-05-11 14:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 14:07:51 --> Input Class Initialized
INFO - 2025-05-11 14:07:51 --> Language Class Initialized
INFO - 2025-05-11 14:07:51 --> Loader Class Initialized
INFO - 2025-05-11 14:07:51 --> Helper loaded: url_helper
INFO - 2025-05-11 14:07:51 --> Helper loaded: form_helper
INFO - 2025-05-11 14:07:51 --> Database Driver Class Initialized
DEBUG - 2025-05-11 14:07:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 14:07:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 14:07:51 --> Controller Class Initialized
INFO - 2025-05-11 14:07:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-11 14:07:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/artikel.php
INFO - 2025-05-11 14:07:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-11 14:07:51 --> Final output sent to browser
DEBUG - 2025-05-11 14:07:51 --> Total execution time: 0.0659
INFO - 2025-05-11 14:10:15 --> Config Class Initialized
INFO - 2025-05-11 14:10:15 --> Hooks Class Initialized
DEBUG - 2025-05-11 14:10:15 --> UTF-8 Support Enabled
INFO - 2025-05-11 14:10:15 --> Utf8 Class Initialized
INFO - 2025-05-11 14:10:15 --> URI Class Initialized
INFO - 2025-05-11 14:10:15 --> Router Class Initialized
INFO - 2025-05-11 14:10:15 --> Output Class Initialized
INFO - 2025-05-11 14:10:15 --> Security Class Initialized
DEBUG - 2025-05-11 14:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 14:10:15 --> Input Class Initialized
INFO - 2025-05-11 14:10:15 --> Language Class Initialized
INFO - 2025-05-11 14:10:15 --> Loader Class Initialized
INFO - 2025-05-11 14:10:15 --> Helper loaded: url_helper
INFO - 2025-05-11 14:10:15 --> Helper loaded: form_helper
INFO - 2025-05-11 14:10:15 --> Database Driver Class Initialized
DEBUG - 2025-05-11 14:10:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 14:10:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 14:10:15 --> Controller Class Initialized
INFO - 2025-05-11 14:10:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-11 14:10:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/artikel.php
INFO - 2025-05-11 14:10:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-11 14:10:15 --> Final output sent to browser
DEBUG - 2025-05-11 14:10:15 --> Total execution time: 0.0644
INFO - 2025-05-11 14:10:17 --> Config Class Initialized
INFO - 2025-05-11 14:10:17 --> Hooks Class Initialized
DEBUG - 2025-05-11 14:10:17 --> UTF-8 Support Enabled
INFO - 2025-05-11 14:10:17 --> Utf8 Class Initialized
INFO - 2025-05-11 14:10:17 --> URI Class Initialized
INFO - 2025-05-11 14:10:17 --> Router Class Initialized
INFO - 2025-05-11 14:10:17 --> Output Class Initialized
INFO - 2025-05-11 14:10:17 --> Security Class Initialized
DEBUG - 2025-05-11 14:10:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 14:10:17 --> Input Class Initialized
INFO - 2025-05-11 14:10:17 --> Language Class Initialized
INFO - 2025-05-11 14:10:17 --> Loader Class Initialized
INFO - 2025-05-11 14:10:17 --> Helper loaded: url_helper
INFO - 2025-05-11 14:10:17 --> Helper loaded: form_helper
INFO - 2025-05-11 14:10:17 --> Database Driver Class Initialized
DEBUG - 2025-05-11 14:10:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 14:10:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 14:10:17 --> Controller Class Initialized
INFO - 2025-05-11 14:10:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-11 14:10:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-11 14:10:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-11 14:10:17 --> Final output sent to browser
DEBUG - 2025-05-11 14:10:17 --> Total execution time: 0.0612
INFO - 2025-05-11 14:10:20 --> Config Class Initialized
INFO - 2025-05-11 14:10:20 --> Hooks Class Initialized
DEBUG - 2025-05-11 14:10:20 --> UTF-8 Support Enabled
INFO - 2025-05-11 14:10:20 --> Utf8 Class Initialized
INFO - 2025-05-11 14:10:20 --> URI Class Initialized
INFO - 2025-05-11 14:10:20 --> Router Class Initialized
INFO - 2025-05-11 14:10:20 --> Output Class Initialized
INFO - 2025-05-11 14:10:20 --> Security Class Initialized
DEBUG - 2025-05-11 14:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 14:10:20 --> Input Class Initialized
INFO - 2025-05-11 14:10:20 --> Language Class Initialized
INFO - 2025-05-11 14:10:20 --> Loader Class Initialized
INFO - 2025-05-11 14:10:20 --> Helper loaded: url_helper
INFO - 2025-05-11 14:10:20 --> Helper loaded: form_helper
INFO - 2025-05-11 14:10:20 --> Database Driver Class Initialized
DEBUG - 2025-05-11 14:10:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 14:10:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 14:10:20 --> Controller Class Initialized
INFO - 2025-05-11 14:10:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-11 14:10:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/artikel.php
INFO - 2025-05-11 14:10:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-11 14:10:20 --> Final output sent to browser
DEBUG - 2025-05-11 14:10:20 --> Total execution time: 0.0538
INFO - 2025-05-11 14:10:22 --> Config Class Initialized
INFO - 2025-05-11 14:10:22 --> Hooks Class Initialized
DEBUG - 2025-05-11 14:10:22 --> UTF-8 Support Enabled
INFO - 2025-05-11 14:10:22 --> Utf8 Class Initialized
INFO - 2025-05-11 14:10:22 --> URI Class Initialized
INFO - 2025-05-11 14:10:22 --> Router Class Initialized
INFO - 2025-05-11 14:10:22 --> Output Class Initialized
INFO - 2025-05-11 14:10:22 --> Security Class Initialized
DEBUG - 2025-05-11 14:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 14:10:22 --> Input Class Initialized
INFO - 2025-05-11 14:10:22 --> Language Class Initialized
INFO - 2025-05-11 14:10:22 --> Loader Class Initialized
INFO - 2025-05-11 14:10:22 --> Helper loaded: url_helper
INFO - 2025-05-11 14:10:22 --> Helper loaded: form_helper
INFO - 2025-05-11 14:10:22 --> Database Driver Class Initialized
DEBUG - 2025-05-11 14:10:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 14:10:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 14:10:22 --> Controller Class Initialized
INFO - 2025-05-11 14:10:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-11 14:10:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-11 14:10:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-11 14:10:22 --> Final output sent to browser
DEBUG - 2025-05-11 14:10:22 --> Total execution time: 0.0496
INFO - 2025-05-11 14:10:23 --> Config Class Initialized
INFO - 2025-05-11 14:10:23 --> Hooks Class Initialized
DEBUG - 2025-05-11 14:10:23 --> UTF-8 Support Enabled
INFO - 2025-05-11 14:10:23 --> Utf8 Class Initialized
INFO - 2025-05-11 14:10:23 --> URI Class Initialized
INFO - 2025-05-11 14:10:23 --> Router Class Initialized
INFO - 2025-05-11 14:10:23 --> Output Class Initialized
INFO - 2025-05-11 14:10:23 --> Security Class Initialized
DEBUG - 2025-05-11 14:10:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 14:10:23 --> Input Class Initialized
INFO - 2025-05-11 14:10:23 --> Language Class Initialized
INFO - 2025-05-11 14:10:23 --> Loader Class Initialized
INFO - 2025-05-11 14:10:23 --> Helper loaded: url_helper
INFO - 2025-05-11 14:10:23 --> Helper loaded: form_helper
INFO - 2025-05-11 14:10:23 --> Database Driver Class Initialized
DEBUG - 2025-05-11 14:10:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 14:10:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 14:10:23 --> Controller Class Initialized
INFO - 2025-05-11 14:10:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-11 14:10:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/artikel.php
INFO - 2025-05-11 14:10:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-11 14:10:23 --> Final output sent to browser
DEBUG - 2025-05-11 14:10:23 --> Total execution time: 0.0574
INFO - 2025-05-11 14:10:31 --> Config Class Initialized
INFO - 2025-05-11 14:10:31 --> Hooks Class Initialized
DEBUG - 2025-05-11 14:10:31 --> UTF-8 Support Enabled
INFO - 2025-05-11 14:10:31 --> Utf8 Class Initialized
INFO - 2025-05-11 14:10:31 --> URI Class Initialized
INFO - 2025-05-11 14:10:31 --> Router Class Initialized
INFO - 2025-05-11 14:10:31 --> Output Class Initialized
INFO - 2025-05-11 14:10:31 --> Security Class Initialized
DEBUG - 2025-05-11 14:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 14:10:31 --> Input Class Initialized
INFO - 2025-05-11 14:10:31 --> Language Class Initialized
INFO - 2025-05-11 14:10:31 --> Loader Class Initialized
INFO - 2025-05-11 14:10:31 --> Helper loaded: url_helper
INFO - 2025-05-11 14:10:31 --> Helper loaded: form_helper
INFO - 2025-05-11 14:10:31 --> Database Driver Class Initialized
DEBUG - 2025-05-11 14:10:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 14:10:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 14:10:31 --> Controller Class Initialized
INFO - 2025-05-11 14:10:31 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-11 14:10:31 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-11 14:10:31 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-11 14:10:31 --> Final output sent to browser
DEBUG - 2025-05-11 14:10:31 --> Total execution time: 0.0781
INFO - 2025-05-11 14:10:32 --> Config Class Initialized
INFO - 2025-05-11 14:10:32 --> Hooks Class Initialized
DEBUG - 2025-05-11 14:10:32 --> UTF-8 Support Enabled
INFO - 2025-05-11 14:10:32 --> Utf8 Class Initialized
INFO - 2025-05-11 14:10:32 --> URI Class Initialized
INFO - 2025-05-11 14:10:32 --> Router Class Initialized
INFO - 2025-05-11 14:10:32 --> Output Class Initialized
INFO - 2025-05-11 14:10:32 --> Security Class Initialized
DEBUG - 2025-05-11 14:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 14:10:32 --> Input Class Initialized
INFO - 2025-05-11 14:10:32 --> Language Class Initialized
INFO - 2025-05-11 14:10:32 --> Loader Class Initialized
INFO - 2025-05-11 14:10:32 --> Helper loaded: url_helper
INFO - 2025-05-11 14:10:32 --> Helper loaded: form_helper
INFO - 2025-05-11 14:10:32 --> Database Driver Class Initialized
DEBUG - 2025-05-11 14:10:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 14:10:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 14:10:32 --> Controller Class Initialized
INFO - 2025-05-11 14:10:33 --> Model "User_model" initialized
INFO - 2025-05-11 14:10:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-11 14:10:33 --> Final output sent to browser
DEBUG - 2025-05-11 14:10:33 --> Total execution time: 0.2429
INFO - 2025-05-11 14:11:04 --> Config Class Initialized
INFO - 2025-05-11 14:11:04 --> Hooks Class Initialized
DEBUG - 2025-05-11 14:11:04 --> UTF-8 Support Enabled
INFO - 2025-05-11 14:11:04 --> Utf8 Class Initialized
INFO - 2025-05-11 14:11:04 --> URI Class Initialized
INFO - 2025-05-11 14:11:04 --> Router Class Initialized
INFO - 2025-05-11 14:11:04 --> Output Class Initialized
INFO - 2025-05-11 14:11:04 --> Security Class Initialized
DEBUG - 2025-05-11 14:11:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 14:11:04 --> Input Class Initialized
INFO - 2025-05-11 14:11:04 --> Language Class Initialized
INFO - 2025-05-11 14:11:04 --> Loader Class Initialized
INFO - 2025-05-11 14:11:04 --> Helper loaded: url_helper
INFO - 2025-05-11 14:11:04 --> Helper loaded: form_helper
INFO - 2025-05-11 14:11:04 --> Database Driver Class Initialized
DEBUG - 2025-05-11 14:11:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 14:11:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 14:11:04 --> Controller Class Initialized
INFO - 2025-05-11 14:11:04 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-11 14:11:04 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/artikel.php
INFO - 2025-05-11 14:11:04 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-11 14:11:04 --> Final output sent to browser
DEBUG - 2025-05-11 14:11:04 --> Total execution time: 0.0771
INFO - 2025-05-11 14:11:10 --> Config Class Initialized
INFO - 2025-05-11 14:11:10 --> Hooks Class Initialized
DEBUG - 2025-05-11 14:11:10 --> UTF-8 Support Enabled
INFO - 2025-05-11 14:11:10 --> Utf8 Class Initialized
INFO - 2025-05-11 14:11:10 --> URI Class Initialized
INFO - 2025-05-11 14:11:10 --> Router Class Initialized
INFO - 2025-05-11 14:11:10 --> Output Class Initialized
INFO - 2025-05-11 14:11:10 --> Security Class Initialized
DEBUG - 2025-05-11 14:11:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 14:11:10 --> Input Class Initialized
INFO - 2025-05-11 14:11:10 --> Language Class Initialized
INFO - 2025-05-11 14:11:10 --> Loader Class Initialized
INFO - 2025-05-11 14:11:10 --> Helper loaded: url_helper
INFO - 2025-05-11 14:11:10 --> Helper loaded: form_helper
INFO - 2025-05-11 14:11:10 --> Database Driver Class Initialized
DEBUG - 2025-05-11 14:11:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 14:11:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 14:11:10 --> Controller Class Initialized
INFO - 2025-05-11 14:11:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-11 14:11:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-11 14:11:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-11 14:11:10 --> Final output sent to browser
DEBUG - 2025-05-11 14:11:10 --> Total execution time: 0.0592
INFO - 2025-05-11 14:16:55 --> Config Class Initialized
INFO - 2025-05-11 14:16:55 --> Hooks Class Initialized
DEBUG - 2025-05-11 14:16:55 --> UTF-8 Support Enabled
INFO - 2025-05-11 14:16:55 --> Utf8 Class Initialized
INFO - 2025-05-11 14:16:55 --> URI Class Initialized
INFO - 2025-05-11 14:16:55 --> Router Class Initialized
INFO - 2025-05-11 14:16:55 --> Output Class Initialized
INFO - 2025-05-11 14:16:55 --> Security Class Initialized
DEBUG - 2025-05-11 14:16:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 14:16:55 --> Input Class Initialized
INFO - 2025-05-11 14:16:55 --> Language Class Initialized
INFO - 2025-05-11 14:16:55 --> Loader Class Initialized
INFO - 2025-05-11 14:16:55 --> Helper loaded: url_helper
INFO - 2025-05-11 14:16:55 --> Helper loaded: form_helper
INFO - 2025-05-11 14:16:55 --> Database Driver Class Initialized
DEBUG - 2025-05-11 14:16:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 14:16:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 14:16:55 --> Controller Class Initialized
INFO - 2025-05-11 14:16:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-11 14:16:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-11 14:16:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-11 14:16:55 --> Final output sent to browser
DEBUG - 2025-05-11 14:16:55 --> Total execution time: 0.0549
INFO - 2025-05-11 14:16:58 --> Config Class Initialized
INFO - 2025-05-11 14:16:58 --> Hooks Class Initialized
DEBUG - 2025-05-11 14:16:58 --> UTF-8 Support Enabled
INFO - 2025-05-11 14:16:58 --> Utf8 Class Initialized
INFO - 2025-05-11 14:16:58 --> URI Class Initialized
INFO - 2025-05-11 14:16:58 --> Router Class Initialized
INFO - 2025-05-11 14:16:58 --> Output Class Initialized
INFO - 2025-05-11 14:16:58 --> Security Class Initialized
DEBUG - 2025-05-11 14:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 14:16:58 --> Input Class Initialized
INFO - 2025-05-11 14:16:58 --> Language Class Initialized
INFO - 2025-05-11 14:16:58 --> Loader Class Initialized
INFO - 2025-05-11 14:16:58 --> Helper loaded: url_helper
INFO - 2025-05-11 14:16:58 --> Helper loaded: form_helper
INFO - 2025-05-11 14:16:58 --> Database Driver Class Initialized
DEBUG - 2025-05-11 14:16:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 14:16:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 14:16:58 --> Controller Class Initialized
INFO - 2025-05-11 14:16:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-11 14:16:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/artikel.php
INFO - 2025-05-11 14:16:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-11 14:16:58 --> Final output sent to browser
DEBUG - 2025-05-11 14:16:58 --> Total execution time: 0.0602
INFO - 2025-05-11 14:17:00 --> Config Class Initialized
INFO - 2025-05-11 14:17:00 --> Hooks Class Initialized
DEBUG - 2025-05-11 14:17:00 --> UTF-8 Support Enabled
INFO - 2025-05-11 14:17:00 --> Utf8 Class Initialized
INFO - 2025-05-11 14:17:00 --> URI Class Initialized
INFO - 2025-05-11 14:17:00 --> Router Class Initialized
INFO - 2025-05-11 14:17:00 --> Output Class Initialized
INFO - 2025-05-11 14:17:00 --> Security Class Initialized
DEBUG - 2025-05-11 14:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 14:17:00 --> Input Class Initialized
INFO - 2025-05-11 14:17:00 --> Language Class Initialized
INFO - 2025-05-11 14:17:00 --> Loader Class Initialized
INFO - 2025-05-11 14:17:00 --> Helper loaded: url_helper
INFO - 2025-05-11 14:17:00 --> Helper loaded: form_helper
INFO - 2025-05-11 14:17:00 --> Database Driver Class Initialized
DEBUG - 2025-05-11 14:17:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 14:17:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 14:17:00 --> Controller Class Initialized
INFO - 2025-05-11 14:17:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-11 14:17:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-11 14:17:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-11 14:17:00 --> Final output sent to browser
DEBUG - 2025-05-11 14:17:00 --> Total execution time: 0.0487
INFO - 2025-05-11 14:17:01 --> Config Class Initialized
INFO - 2025-05-11 14:17:01 --> Hooks Class Initialized
DEBUG - 2025-05-11 14:17:01 --> UTF-8 Support Enabled
INFO - 2025-05-11 14:17:01 --> Utf8 Class Initialized
INFO - 2025-05-11 14:17:01 --> URI Class Initialized
INFO - 2025-05-11 14:17:01 --> Router Class Initialized
INFO - 2025-05-11 14:17:01 --> Output Class Initialized
INFO - 2025-05-11 14:17:01 --> Security Class Initialized
DEBUG - 2025-05-11 14:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 14:17:01 --> Input Class Initialized
INFO - 2025-05-11 14:17:01 --> Language Class Initialized
INFO - 2025-05-11 14:17:01 --> Loader Class Initialized
INFO - 2025-05-11 14:17:01 --> Helper loaded: url_helper
INFO - 2025-05-11 14:17:01 --> Helper loaded: form_helper
INFO - 2025-05-11 14:17:01 --> Database Driver Class Initialized
DEBUG - 2025-05-11 14:17:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 14:17:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 14:17:01 --> Controller Class Initialized
INFO - 2025-05-11 14:17:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-11 14:17:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/artikel.php
INFO - 2025-05-11 14:17:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-11 14:17:01 --> Final output sent to browser
DEBUG - 2025-05-11 14:17:01 --> Total execution time: 0.0591
INFO - 2025-05-11 14:17:05 --> Config Class Initialized
INFO - 2025-05-11 14:17:05 --> Hooks Class Initialized
DEBUG - 2025-05-11 14:17:05 --> UTF-8 Support Enabled
INFO - 2025-05-11 14:17:05 --> Utf8 Class Initialized
INFO - 2025-05-11 14:17:05 --> URI Class Initialized
INFO - 2025-05-11 14:17:05 --> Router Class Initialized
INFO - 2025-05-11 14:17:05 --> Output Class Initialized
INFO - 2025-05-11 14:17:05 --> Security Class Initialized
DEBUG - 2025-05-11 14:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 14:17:05 --> Input Class Initialized
INFO - 2025-05-11 14:17:05 --> Language Class Initialized
INFO - 2025-05-11 14:17:05 --> Loader Class Initialized
INFO - 2025-05-11 14:17:05 --> Helper loaded: url_helper
INFO - 2025-05-11 14:17:05 --> Helper loaded: form_helper
INFO - 2025-05-11 14:17:05 --> Database Driver Class Initialized
DEBUG - 2025-05-11 14:17:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 14:17:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 14:17:05 --> Controller Class Initialized
INFO - 2025-05-11 14:17:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-11 14:17:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-11 14:17:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-11 14:17:05 --> Final output sent to browser
DEBUG - 2025-05-11 14:17:05 --> Total execution time: 0.0654
INFO - 2025-05-11 14:17:08 --> Config Class Initialized
INFO - 2025-05-11 14:17:08 --> Hooks Class Initialized
DEBUG - 2025-05-11 14:17:08 --> UTF-8 Support Enabled
INFO - 2025-05-11 14:17:08 --> Utf8 Class Initialized
INFO - 2025-05-11 14:17:08 --> URI Class Initialized
INFO - 2025-05-11 14:17:08 --> Router Class Initialized
INFO - 2025-05-11 14:17:08 --> Output Class Initialized
INFO - 2025-05-11 14:17:08 --> Security Class Initialized
DEBUG - 2025-05-11 14:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 14:17:08 --> Input Class Initialized
INFO - 2025-05-11 14:17:08 --> Language Class Initialized
INFO - 2025-05-11 14:17:08 --> Loader Class Initialized
INFO - 2025-05-11 14:17:08 --> Helper loaded: url_helper
INFO - 2025-05-11 14:17:08 --> Helper loaded: form_helper
INFO - 2025-05-11 14:17:08 --> Database Driver Class Initialized
DEBUG - 2025-05-11 14:17:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 14:17:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 14:17:08 --> Controller Class Initialized
INFO - 2025-05-11 14:17:08 --> Model "User_model" initialized
INFO - 2025-05-11 14:17:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-11 14:17:08 --> Final output sent to browser
DEBUG - 2025-05-11 14:17:08 --> Total execution time: 0.0611
INFO - 2025-05-11 14:17:17 --> Config Class Initialized
INFO - 2025-05-11 14:17:17 --> Hooks Class Initialized
DEBUG - 2025-05-11 14:17:17 --> UTF-8 Support Enabled
INFO - 2025-05-11 14:17:17 --> Utf8 Class Initialized
INFO - 2025-05-11 14:17:17 --> URI Class Initialized
INFO - 2025-05-11 14:17:17 --> Router Class Initialized
INFO - 2025-05-11 14:17:17 --> Output Class Initialized
INFO - 2025-05-11 14:17:17 --> Security Class Initialized
DEBUG - 2025-05-11 14:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 14:17:17 --> Input Class Initialized
INFO - 2025-05-11 14:17:17 --> Language Class Initialized
INFO - 2025-05-11 14:17:17 --> Loader Class Initialized
INFO - 2025-05-11 14:17:17 --> Helper loaded: url_helper
INFO - 2025-05-11 14:17:17 --> Helper loaded: form_helper
INFO - 2025-05-11 14:17:17 --> Database Driver Class Initialized
DEBUG - 2025-05-11 14:17:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 14:17:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 14:17:17 --> Controller Class Initialized
INFO - 2025-05-11 14:17:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-11 14:17:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-11 14:17:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-11 14:17:17 --> Final output sent to browser
DEBUG - 2025-05-11 14:17:17 --> Total execution time: 0.0620
INFO - 2025-05-11 14:21:45 --> Config Class Initialized
INFO - 2025-05-11 14:21:45 --> Hooks Class Initialized
DEBUG - 2025-05-11 14:21:45 --> UTF-8 Support Enabled
INFO - 2025-05-11 14:21:45 --> Utf8 Class Initialized
INFO - 2025-05-11 14:21:45 --> URI Class Initialized
INFO - 2025-05-11 14:21:45 --> Router Class Initialized
INFO - 2025-05-11 14:21:45 --> Output Class Initialized
INFO - 2025-05-11 14:21:45 --> Security Class Initialized
DEBUG - 2025-05-11 14:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 14:21:45 --> Input Class Initialized
INFO - 2025-05-11 14:21:45 --> Language Class Initialized
INFO - 2025-05-11 14:21:46 --> Loader Class Initialized
INFO - 2025-05-11 14:21:46 --> Helper loaded: url_helper
INFO - 2025-05-11 14:21:46 --> Helper loaded: form_helper
INFO - 2025-05-11 14:21:46 --> Database Driver Class Initialized
DEBUG - 2025-05-11 14:21:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 14:21:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 14:21:46 --> Controller Class Initialized
INFO - 2025-05-11 14:21:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-11 14:21:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-11 14:21:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-11 14:21:46 --> Final output sent to browser
DEBUG - 2025-05-11 14:21:46 --> Total execution time: 0.0621
INFO - 2025-05-11 14:21:48 --> Config Class Initialized
INFO - 2025-05-11 14:21:48 --> Hooks Class Initialized
DEBUG - 2025-05-11 14:21:48 --> UTF-8 Support Enabled
INFO - 2025-05-11 14:21:48 --> Utf8 Class Initialized
INFO - 2025-05-11 14:21:48 --> URI Class Initialized
INFO - 2025-05-11 14:21:48 --> Router Class Initialized
INFO - 2025-05-11 14:21:48 --> Output Class Initialized
INFO - 2025-05-11 14:21:48 --> Security Class Initialized
DEBUG - 2025-05-11 14:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 14:21:48 --> Input Class Initialized
INFO - 2025-05-11 14:21:48 --> Language Class Initialized
INFO - 2025-05-11 14:21:48 --> Loader Class Initialized
INFO - 2025-05-11 14:21:48 --> Helper loaded: url_helper
INFO - 2025-05-11 14:21:48 --> Helper loaded: form_helper
INFO - 2025-05-11 14:21:48 --> Database Driver Class Initialized
DEBUG - 2025-05-11 14:21:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 14:21:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 14:21:48 --> Controller Class Initialized
INFO - 2025-05-11 14:21:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-11 14:21:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/artikel.php
INFO - 2025-05-11 14:21:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-11 14:21:48 --> Final output sent to browser
DEBUG - 2025-05-11 14:21:48 --> Total execution time: 0.0498
INFO - 2025-05-11 14:21:51 --> Config Class Initialized
INFO - 2025-05-11 14:21:51 --> Hooks Class Initialized
DEBUG - 2025-05-11 14:21:51 --> UTF-8 Support Enabled
INFO - 2025-05-11 14:21:51 --> Utf8 Class Initialized
INFO - 2025-05-11 14:21:51 --> URI Class Initialized
INFO - 2025-05-11 14:21:51 --> Router Class Initialized
INFO - 2025-05-11 14:21:51 --> Output Class Initialized
INFO - 2025-05-11 14:21:51 --> Security Class Initialized
DEBUG - 2025-05-11 14:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 14:21:51 --> Input Class Initialized
INFO - 2025-05-11 14:21:51 --> Language Class Initialized
INFO - 2025-05-11 14:21:51 --> Loader Class Initialized
INFO - 2025-05-11 14:21:51 --> Helper loaded: url_helper
INFO - 2025-05-11 14:21:51 --> Helper loaded: form_helper
INFO - 2025-05-11 14:21:51 --> Database Driver Class Initialized
DEBUG - 2025-05-11 14:21:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 14:21:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 14:21:51 --> Controller Class Initialized
INFO - 2025-05-11 14:21:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-11 14:21:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-11 14:21:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-11 14:21:51 --> Final output sent to browser
DEBUG - 2025-05-11 14:21:51 --> Total execution time: 0.0586
INFO - 2025-05-11 14:22:22 --> Config Class Initialized
INFO - 2025-05-11 14:22:22 --> Hooks Class Initialized
DEBUG - 2025-05-11 14:22:22 --> UTF-8 Support Enabled
INFO - 2025-05-11 14:22:22 --> Utf8 Class Initialized
INFO - 2025-05-11 14:22:22 --> URI Class Initialized
INFO - 2025-05-11 14:22:22 --> Router Class Initialized
INFO - 2025-05-11 14:22:22 --> Output Class Initialized
INFO - 2025-05-11 14:22:22 --> Security Class Initialized
DEBUG - 2025-05-11 14:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 14:22:22 --> Input Class Initialized
INFO - 2025-05-11 14:22:22 --> Language Class Initialized
INFO - 2025-05-11 14:22:22 --> Loader Class Initialized
INFO - 2025-05-11 14:22:22 --> Helper loaded: url_helper
INFO - 2025-05-11 14:22:22 --> Helper loaded: form_helper
INFO - 2025-05-11 14:22:22 --> Database Driver Class Initialized
DEBUG - 2025-05-11 14:22:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 14:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 14:22:22 --> Controller Class Initialized
INFO - 2025-05-11 14:22:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-11 14:22:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-11 14:22:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-11 14:22:22 --> Final output sent to browser
DEBUG - 2025-05-11 14:22:22 --> Total execution time: 0.0738
INFO - 2025-05-11 14:24:12 --> Config Class Initialized
INFO - 2025-05-11 14:24:12 --> Hooks Class Initialized
DEBUG - 2025-05-11 14:24:12 --> UTF-8 Support Enabled
INFO - 2025-05-11 14:24:12 --> Utf8 Class Initialized
INFO - 2025-05-11 14:24:12 --> URI Class Initialized
INFO - 2025-05-11 14:24:12 --> Router Class Initialized
INFO - 2025-05-11 14:24:12 --> Output Class Initialized
INFO - 2025-05-11 14:24:12 --> Security Class Initialized
DEBUG - 2025-05-11 14:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 14:24:12 --> Input Class Initialized
INFO - 2025-05-11 14:24:12 --> Language Class Initialized
INFO - 2025-05-11 14:24:12 --> Loader Class Initialized
INFO - 2025-05-11 14:24:12 --> Helper loaded: url_helper
INFO - 2025-05-11 14:24:12 --> Helper loaded: form_helper
INFO - 2025-05-11 14:24:12 --> Database Driver Class Initialized
DEBUG - 2025-05-11 14:24:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 14:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 14:24:12 --> Controller Class Initialized
INFO - 2025-05-11 14:24:12 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-11 14:24:12 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/artikel.php
INFO - 2025-05-11 14:24:12 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-11 14:24:12 --> Final output sent to browser
DEBUG - 2025-05-11 14:24:12 --> Total execution time: 0.0616
INFO - 2025-05-11 14:24:22 --> Config Class Initialized
INFO - 2025-05-11 14:24:22 --> Hooks Class Initialized
DEBUG - 2025-05-11 14:24:22 --> UTF-8 Support Enabled
INFO - 2025-05-11 14:24:22 --> Utf8 Class Initialized
INFO - 2025-05-11 14:24:22 --> URI Class Initialized
INFO - 2025-05-11 14:24:22 --> Router Class Initialized
INFO - 2025-05-11 14:24:22 --> Output Class Initialized
INFO - 2025-05-11 14:24:22 --> Security Class Initialized
DEBUG - 2025-05-11 14:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 14:24:22 --> Input Class Initialized
INFO - 2025-05-11 14:24:22 --> Language Class Initialized
INFO - 2025-05-11 14:24:22 --> Loader Class Initialized
INFO - 2025-05-11 14:24:22 --> Helper loaded: url_helper
INFO - 2025-05-11 14:24:22 --> Helper loaded: form_helper
INFO - 2025-05-11 14:24:22 --> Database Driver Class Initialized
DEBUG - 2025-05-11 14:24:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 14:24:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 14:24:22 --> Controller Class Initialized
INFO - 2025-05-11 14:24:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-11 14:24:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-11 14:24:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-11 14:24:22 --> Final output sent to browser
DEBUG - 2025-05-11 14:24:22 --> Total execution time: 0.0612
INFO - 2025-05-11 14:26:35 --> Config Class Initialized
INFO - 2025-05-11 14:26:35 --> Hooks Class Initialized
DEBUG - 2025-05-11 14:26:35 --> UTF-8 Support Enabled
INFO - 2025-05-11 14:26:35 --> Utf8 Class Initialized
INFO - 2025-05-11 14:26:35 --> URI Class Initialized
INFO - 2025-05-11 14:26:35 --> Router Class Initialized
INFO - 2025-05-11 14:26:35 --> Output Class Initialized
INFO - 2025-05-11 14:26:35 --> Security Class Initialized
DEBUG - 2025-05-11 14:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 14:26:35 --> Input Class Initialized
INFO - 2025-05-11 14:26:35 --> Language Class Initialized
INFO - 2025-05-11 14:26:35 --> Loader Class Initialized
INFO - 2025-05-11 14:26:35 --> Helper loaded: url_helper
INFO - 2025-05-11 14:26:35 --> Helper loaded: form_helper
INFO - 2025-05-11 14:26:35 --> Database Driver Class Initialized
DEBUG - 2025-05-11 14:26:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 14:26:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 14:26:35 --> Controller Class Initialized
INFO - 2025-05-11 14:26:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-11 14:26:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-11 14:26:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-11 14:26:35 --> Final output sent to browser
DEBUG - 2025-05-11 14:26:35 --> Total execution time: 0.0637
INFO - 2025-05-11 14:31:08 --> Config Class Initialized
INFO - 2025-05-11 14:31:08 --> Hooks Class Initialized
DEBUG - 2025-05-11 14:31:08 --> UTF-8 Support Enabled
INFO - 2025-05-11 14:31:08 --> Utf8 Class Initialized
INFO - 2025-05-11 14:31:08 --> URI Class Initialized
INFO - 2025-05-11 14:31:08 --> Router Class Initialized
INFO - 2025-05-11 14:31:08 --> Output Class Initialized
INFO - 2025-05-11 14:31:08 --> Security Class Initialized
DEBUG - 2025-05-11 14:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 14:31:08 --> Input Class Initialized
INFO - 2025-05-11 14:31:08 --> Language Class Initialized
INFO - 2025-05-11 14:31:08 --> Loader Class Initialized
INFO - 2025-05-11 14:31:08 --> Helper loaded: url_helper
INFO - 2025-05-11 14:31:08 --> Helper loaded: form_helper
INFO - 2025-05-11 14:31:08 --> Database Driver Class Initialized
DEBUG - 2025-05-11 14:31:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 14:31:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 14:31:08 --> Controller Class Initialized
INFO - 2025-05-11 14:31:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-11 14:31:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-11 14:31:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-11 14:31:08 --> Final output sent to browser
DEBUG - 2025-05-11 14:31:08 --> Total execution time: 0.0641
INFO - 2025-05-11 14:31:14 --> Config Class Initialized
INFO - 2025-05-11 14:31:14 --> Hooks Class Initialized
DEBUG - 2025-05-11 14:31:14 --> UTF-8 Support Enabled
INFO - 2025-05-11 14:31:14 --> Utf8 Class Initialized
INFO - 2025-05-11 14:31:14 --> URI Class Initialized
INFO - 2025-05-11 14:31:14 --> Router Class Initialized
INFO - 2025-05-11 14:31:14 --> Output Class Initialized
INFO - 2025-05-11 14:31:14 --> Security Class Initialized
DEBUG - 2025-05-11 14:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 14:31:14 --> Input Class Initialized
INFO - 2025-05-11 14:31:14 --> Language Class Initialized
INFO - 2025-05-11 14:31:14 --> Loader Class Initialized
INFO - 2025-05-11 14:31:14 --> Helper loaded: url_helper
INFO - 2025-05-11 14:31:14 --> Helper loaded: form_helper
INFO - 2025-05-11 14:31:14 --> Database Driver Class Initialized
DEBUG - 2025-05-11 14:31:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 14:31:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 14:31:14 --> Controller Class Initialized
INFO - 2025-05-11 14:31:14 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-11 14:31:14 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/artikel.php
INFO - 2025-05-11 14:31:14 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-11 14:31:14 --> Final output sent to browser
DEBUG - 2025-05-11 14:31:14 --> Total execution time: 0.0513
INFO - 2025-05-11 14:31:21 --> Config Class Initialized
INFO - 2025-05-11 14:31:21 --> Hooks Class Initialized
DEBUG - 2025-05-11 14:31:21 --> UTF-8 Support Enabled
INFO - 2025-05-11 14:31:21 --> Utf8 Class Initialized
INFO - 2025-05-11 14:31:21 --> URI Class Initialized
INFO - 2025-05-11 14:31:21 --> Router Class Initialized
INFO - 2025-05-11 14:31:21 --> Output Class Initialized
INFO - 2025-05-11 14:31:21 --> Security Class Initialized
DEBUG - 2025-05-11 14:31:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 14:31:21 --> Input Class Initialized
INFO - 2025-05-11 14:31:21 --> Language Class Initialized
INFO - 2025-05-11 14:31:21 --> Loader Class Initialized
INFO - 2025-05-11 14:31:21 --> Helper loaded: url_helper
INFO - 2025-05-11 14:31:21 --> Helper loaded: form_helper
INFO - 2025-05-11 14:31:21 --> Database Driver Class Initialized
DEBUG - 2025-05-11 14:31:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 14:31:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 14:31:21 --> Controller Class Initialized
INFO - 2025-05-11 14:31:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-11 14:31:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-11 14:31:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-11 14:31:21 --> Final output sent to browser
DEBUG - 2025-05-11 14:31:21 --> Total execution time: 0.0523
INFO - 2025-05-11 14:33:48 --> Config Class Initialized
INFO - 2025-05-11 14:33:48 --> Hooks Class Initialized
DEBUG - 2025-05-11 14:33:48 --> UTF-8 Support Enabled
INFO - 2025-05-11 14:33:48 --> Utf8 Class Initialized
INFO - 2025-05-11 14:33:48 --> URI Class Initialized
INFO - 2025-05-11 14:33:48 --> Router Class Initialized
INFO - 2025-05-11 14:33:48 --> Output Class Initialized
INFO - 2025-05-11 14:33:48 --> Security Class Initialized
DEBUG - 2025-05-11 14:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 14:33:48 --> Input Class Initialized
INFO - 2025-05-11 14:33:48 --> Language Class Initialized
INFO - 2025-05-11 14:33:48 --> Loader Class Initialized
INFO - 2025-05-11 14:33:48 --> Helper loaded: url_helper
INFO - 2025-05-11 14:33:48 --> Helper loaded: form_helper
INFO - 2025-05-11 14:33:48 --> Database Driver Class Initialized
DEBUG - 2025-05-11 14:33:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 14:33:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 14:33:48 --> Controller Class Initialized
INFO - 2025-05-11 14:33:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-11 14:33:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-11 14:33:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-11 14:33:48 --> Final output sent to browser
DEBUG - 2025-05-11 14:33:48 --> Total execution time: 0.0612
INFO - 2025-05-11 14:34:26 --> Config Class Initialized
INFO - 2025-05-11 14:34:26 --> Hooks Class Initialized
DEBUG - 2025-05-11 14:34:26 --> UTF-8 Support Enabled
INFO - 2025-05-11 14:34:26 --> Utf8 Class Initialized
INFO - 2025-05-11 14:34:26 --> URI Class Initialized
INFO - 2025-05-11 14:34:26 --> Router Class Initialized
INFO - 2025-05-11 14:34:26 --> Output Class Initialized
INFO - 2025-05-11 14:34:26 --> Security Class Initialized
DEBUG - 2025-05-11 14:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 14:34:26 --> Input Class Initialized
INFO - 2025-05-11 14:34:26 --> Language Class Initialized
INFO - 2025-05-11 14:34:26 --> Loader Class Initialized
INFO - 2025-05-11 14:34:26 --> Helper loaded: url_helper
INFO - 2025-05-11 14:34:26 --> Helper loaded: form_helper
INFO - 2025-05-11 14:34:26 --> Database Driver Class Initialized
DEBUG - 2025-05-11 14:34:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 14:34:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 14:34:26 --> Controller Class Initialized
INFO - 2025-05-11 14:34:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-11 14:34:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-11 14:34:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-11 14:34:26 --> Final output sent to browser
DEBUG - 2025-05-11 14:34:26 --> Total execution time: 0.0471
INFO - 2025-05-11 14:37:25 --> Config Class Initialized
INFO - 2025-05-11 14:37:25 --> Hooks Class Initialized
DEBUG - 2025-05-11 14:37:25 --> UTF-8 Support Enabled
INFO - 2025-05-11 14:37:25 --> Utf8 Class Initialized
INFO - 2025-05-11 14:37:25 --> URI Class Initialized
INFO - 2025-05-11 14:37:25 --> Router Class Initialized
INFO - 2025-05-11 14:37:25 --> Output Class Initialized
INFO - 2025-05-11 14:37:25 --> Security Class Initialized
DEBUG - 2025-05-11 14:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 14:37:25 --> Input Class Initialized
INFO - 2025-05-11 14:37:25 --> Language Class Initialized
INFO - 2025-05-11 14:37:25 --> Loader Class Initialized
INFO - 2025-05-11 14:37:25 --> Helper loaded: url_helper
INFO - 2025-05-11 14:37:25 --> Helper loaded: form_helper
INFO - 2025-05-11 14:37:25 --> Database Driver Class Initialized
DEBUG - 2025-05-11 14:37:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 14:37:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 14:37:25 --> Controller Class Initialized
INFO - 2025-05-11 14:37:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-11 14:37:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-11 14:37:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-11 14:37:25 --> Final output sent to browser
DEBUG - 2025-05-11 14:37:25 --> Total execution time: 0.0603
INFO - 2025-05-11 14:37:28 --> Config Class Initialized
INFO - 2025-05-11 14:37:28 --> Hooks Class Initialized
DEBUG - 2025-05-11 14:37:28 --> UTF-8 Support Enabled
INFO - 2025-05-11 14:37:28 --> Utf8 Class Initialized
INFO - 2025-05-11 14:37:28 --> URI Class Initialized
INFO - 2025-05-11 14:37:28 --> Router Class Initialized
INFO - 2025-05-11 14:37:28 --> Output Class Initialized
INFO - 2025-05-11 14:37:28 --> Security Class Initialized
DEBUG - 2025-05-11 14:37:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 14:37:28 --> Input Class Initialized
INFO - 2025-05-11 14:37:28 --> Language Class Initialized
INFO - 2025-05-11 14:37:28 --> Loader Class Initialized
INFO - 2025-05-11 14:37:28 --> Helper loaded: url_helper
INFO - 2025-05-11 14:37:28 --> Helper loaded: form_helper
INFO - 2025-05-11 14:37:28 --> Database Driver Class Initialized
DEBUG - 2025-05-11 14:37:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 14:37:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 14:37:28 --> Controller Class Initialized
INFO - 2025-05-11 14:37:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-11 14:37:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-11 14:37:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-11 14:37:28 --> Final output sent to browser
DEBUG - 2025-05-11 14:37:28 --> Total execution time: 0.0660
INFO - 2025-05-11 14:37:33 --> Config Class Initialized
INFO - 2025-05-11 14:37:33 --> Hooks Class Initialized
DEBUG - 2025-05-11 14:37:33 --> UTF-8 Support Enabled
INFO - 2025-05-11 14:37:33 --> Utf8 Class Initialized
INFO - 2025-05-11 14:37:33 --> URI Class Initialized
INFO - 2025-05-11 14:37:33 --> Router Class Initialized
INFO - 2025-05-11 14:37:33 --> Output Class Initialized
INFO - 2025-05-11 14:37:33 --> Security Class Initialized
DEBUG - 2025-05-11 14:37:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 14:37:33 --> Input Class Initialized
INFO - 2025-05-11 14:37:33 --> Language Class Initialized
INFO - 2025-05-11 14:37:33 --> Loader Class Initialized
INFO - 2025-05-11 14:37:33 --> Helper loaded: url_helper
INFO - 2025-05-11 14:37:33 --> Helper loaded: form_helper
INFO - 2025-05-11 14:37:33 --> Database Driver Class Initialized
DEBUG - 2025-05-11 14:37:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 14:37:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 14:37:33 --> Controller Class Initialized
INFO - 2025-05-11 14:37:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-11 14:37:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/artikel.php
INFO - 2025-05-11 14:37:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-11 14:37:33 --> Final output sent to browser
DEBUG - 2025-05-11 14:37:33 --> Total execution time: 0.0451
INFO - 2025-05-11 14:37:37 --> Config Class Initialized
INFO - 2025-05-11 14:37:37 --> Hooks Class Initialized
DEBUG - 2025-05-11 14:37:37 --> UTF-8 Support Enabled
INFO - 2025-05-11 14:37:37 --> Utf8 Class Initialized
INFO - 2025-05-11 14:37:37 --> URI Class Initialized
INFO - 2025-05-11 14:37:37 --> Router Class Initialized
INFO - 2025-05-11 14:37:37 --> Output Class Initialized
INFO - 2025-05-11 14:37:37 --> Security Class Initialized
DEBUG - 2025-05-11 14:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 14:37:37 --> Input Class Initialized
INFO - 2025-05-11 14:37:37 --> Language Class Initialized
INFO - 2025-05-11 14:37:37 --> Loader Class Initialized
INFO - 2025-05-11 14:37:37 --> Helper loaded: url_helper
INFO - 2025-05-11 14:37:37 --> Helper loaded: form_helper
INFO - 2025-05-11 14:37:37 --> Database Driver Class Initialized
DEBUG - 2025-05-11 14:37:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 14:37:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 14:37:37 --> Controller Class Initialized
INFO - 2025-05-11 14:37:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-11 14:37:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-11 14:37:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-11 14:37:37 --> Final output sent to browser
DEBUG - 2025-05-11 14:37:37 --> Total execution time: 0.0497
INFO - 2025-05-11 14:37:38 --> Config Class Initialized
INFO - 2025-05-11 14:37:38 --> Hooks Class Initialized
DEBUG - 2025-05-11 14:37:38 --> UTF-8 Support Enabled
INFO - 2025-05-11 14:37:38 --> Utf8 Class Initialized
INFO - 2025-05-11 14:37:38 --> URI Class Initialized
INFO - 2025-05-11 14:37:38 --> Router Class Initialized
INFO - 2025-05-11 14:37:38 --> Output Class Initialized
INFO - 2025-05-11 14:37:38 --> Security Class Initialized
DEBUG - 2025-05-11 14:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 14:37:38 --> Input Class Initialized
INFO - 2025-05-11 14:37:38 --> Language Class Initialized
INFO - 2025-05-11 14:37:38 --> Loader Class Initialized
INFO - 2025-05-11 14:37:38 --> Helper loaded: url_helper
INFO - 2025-05-11 14:37:38 --> Helper loaded: form_helper
INFO - 2025-05-11 14:37:38 --> Database Driver Class Initialized
DEBUG - 2025-05-11 14:37:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 14:37:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 14:37:38 --> Controller Class Initialized
INFO - 2025-05-11 14:37:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-11 14:37:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-11 14:37:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-11 14:37:38 --> Final output sent to browser
DEBUG - 2025-05-11 14:37:38 --> Total execution time: 0.0472
INFO - 2025-05-11 14:42:24 --> Config Class Initialized
INFO - 2025-05-11 14:42:24 --> Hooks Class Initialized
DEBUG - 2025-05-11 14:42:24 --> UTF-8 Support Enabled
INFO - 2025-05-11 14:42:24 --> Utf8 Class Initialized
INFO - 2025-05-11 14:42:24 --> URI Class Initialized
INFO - 2025-05-11 14:42:24 --> Router Class Initialized
INFO - 2025-05-11 14:42:24 --> Output Class Initialized
INFO - 2025-05-11 14:42:24 --> Security Class Initialized
DEBUG - 2025-05-11 14:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 14:42:24 --> Input Class Initialized
INFO - 2025-05-11 14:42:24 --> Language Class Initialized
INFO - 2025-05-11 14:42:24 --> Loader Class Initialized
INFO - 2025-05-11 14:42:24 --> Helper loaded: url_helper
INFO - 2025-05-11 14:42:24 --> Helper loaded: form_helper
INFO - 2025-05-11 14:42:24 --> Database Driver Class Initialized
DEBUG - 2025-05-11 14:42:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 14:42:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 14:42:24 --> Controller Class Initialized
INFO - 2025-05-11 14:42:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-11 14:42:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-11 14:42:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-11 14:42:24 --> Final output sent to browser
DEBUG - 2025-05-11 14:42:24 --> Total execution time: 0.0817
INFO - 2025-05-11 14:42:26 --> Config Class Initialized
INFO - 2025-05-11 14:42:26 --> Hooks Class Initialized
DEBUG - 2025-05-11 14:42:26 --> UTF-8 Support Enabled
INFO - 2025-05-11 14:42:26 --> Utf8 Class Initialized
INFO - 2025-05-11 14:42:26 --> URI Class Initialized
INFO - 2025-05-11 14:42:26 --> Router Class Initialized
INFO - 2025-05-11 14:42:26 --> Output Class Initialized
INFO - 2025-05-11 14:42:26 --> Security Class Initialized
DEBUG - 2025-05-11 14:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 14:42:26 --> Input Class Initialized
INFO - 2025-05-11 14:42:26 --> Language Class Initialized
INFO - 2025-05-11 14:42:26 --> Loader Class Initialized
INFO - 2025-05-11 14:42:26 --> Helper loaded: url_helper
INFO - 2025-05-11 14:42:26 --> Helper loaded: form_helper
INFO - 2025-05-11 14:42:26 --> Database Driver Class Initialized
DEBUG - 2025-05-11 14:42:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 14:42:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 14:42:26 --> Controller Class Initialized
INFO - 2025-05-11 14:42:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-11 14:42:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/artikel.php
INFO - 2025-05-11 14:42:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-11 14:42:26 --> Final output sent to browser
DEBUG - 2025-05-11 14:42:26 --> Total execution time: 0.0622
INFO - 2025-05-11 14:42:27 --> Config Class Initialized
INFO - 2025-05-11 14:42:27 --> Hooks Class Initialized
DEBUG - 2025-05-11 14:42:27 --> UTF-8 Support Enabled
INFO - 2025-05-11 14:42:27 --> Utf8 Class Initialized
INFO - 2025-05-11 14:42:27 --> URI Class Initialized
INFO - 2025-05-11 14:42:27 --> Router Class Initialized
INFO - 2025-05-11 14:42:27 --> Output Class Initialized
INFO - 2025-05-11 14:42:27 --> Security Class Initialized
DEBUG - 2025-05-11 14:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 14:42:27 --> Input Class Initialized
INFO - 2025-05-11 14:42:27 --> Language Class Initialized
INFO - 2025-05-11 14:42:27 --> Loader Class Initialized
INFO - 2025-05-11 14:42:27 --> Helper loaded: url_helper
INFO - 2025-05-11 14:42:27 --> Helper loaded: form_helper
INFO - 2025-05-11 14:42:27 --> Database Driver Class Initialized
DEBUG - 2025-05-11 14:42:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 14:42:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 14:42:27 --> Controller Class Initialized
INFO - 2025-05-11 14:42:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-11 14:42:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-11 14:42:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-11 14:42:27 --> Final output sent to browser
DEBUG - 2025-05-11 14:42:27 --> Total execution time: 0.0437
INFO - 2025-05-11 14:42:30 --> Config Class Initialized
INFO - 2025-05-11 14:42:30 --> Hooks Class Initialized
DEBUG - 2025-05-11 14:42:30 --> UTF-8 Support Enabled
INFO - 2025-05-11 14:42:30 --> Utf8 Class Initialized
INFO - 2025-05-11 14:42:30 --> URI Class Initialized
INFO - 2025-05-11 14:42:30 --> Router Class Initialized
INFO - 2025-05-11 14:42:30 --> Output Class Initialized
INFO - 2025-05-11 14:42:30 --> Security Class Initialized
DEBUG - 2025-05-11 14:42:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 14:42:30 --> Input Class Initialized
INFO - 2025-05-11 14:42:30 --> Language Class Initialized
INFO - 2025-05-11 14:42:30 --> Loader Class Initialized
INFO - 2025-05-11 14:42:30 --> Helper loaded: url_helper
INFO - 2025-05-11 14:42:30 --> Helper loaded: form_helper
INFO - 2025-05-11 14:42:30 --> Database Driver Class Initialized
DEBUG - 2025-05-11 14:42:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 14:42:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 14:42:30 --> Controller Class Initialized
INFO - 2025-05-11 14:42:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-11 14:42:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-11 14:42:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-11 14:42:30 --> Final output sent to browser
DEBUG - 2025-05-11 14:42:30 --> Total execution time: 0.0597
INFO - 2025-05-11 14:42:37 --> Config Class Initialized
INFO - 2025-05-11 14:42:37 --> Hooks Class Initialized
DEBUG - 2025-05-11 14:42:37 --> UTF-8 Support Enabled
INFO - 2025-05-11 14:42:37 --> Utf8 Class Initialized
INFO - 2025-05-11 14:42:37 --> URI Class Initialized
INFO - 2025-05-11 14:42:37 --> Router Class Initialized
INFO - 2025-05-11 14:42:37 --> Output Class Initialized
INFO - 2025-05-11 14:42:37 --> Security Class Initialized
DEBUG - 2025-05-11 14:42:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 14:42:37 --> Input Class Initialized
INFO - 2025-05-11 14:42:37 --> Language Class Initialized
INFO - 2025-05-11 14:42:37 --> Loader Class Initialized
INFO - 2025-05-11 14:42:37 --> Helper loaded: url_helper
INFO - 2025-05-11 14:42:37 --> Helper loaded: form_helper
INFO - 2025-05-11 14:42:37 --> Database Driver Class Initialized
DEBUG - 2025-05-11 14:42:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 14:42:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 14:42:37 --> Controller Class Initialized
INFO - 2025-05-11 14:42:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-11 14:42:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/artikel.php
INFO - 2025-05-11 14:42:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-11 14:42:37 --> Final output sent to browser
DEBUG - 2025-05-11 14:42:37 --> Total execution time: 0.0555
INFO - 2025-05-11 14:42:40 --> Config Class Initialized
INFO - 2025-05-11 14:42:40 --> Hooks Class Initialized
DEBUG - 2025-05-11 14:42:40 --> UTF-8 Support Enabled
INFO - 2025-05-11 14:42:40 --> Utf8 Class Initialized
INFO - 2025-05-11 14:42:40 --> URI Class Initialized
INFO - 2025-05-11 14:42:40 --> Router Class Initialized
INFO - 2025-05-11 14:42:40 --> Output Class Initialized
INFO - 2025-05-11 14:42:40 --> Security Class Initialized
DEBUG - 2025-05-11 14:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 14:42:40 --> Input Class Initialized
INFO - 2025-05-11 14:42:40 --> Language Class Initialized
INFO - 2025-05-11 14:42:40 --> Loader Class Initialized
INFO - 2025-05-11 14:42:40 --> Helper loaded: url_helper
INFO - 2025-05-11 14:42:40 --> Helper loaded: form_helper
INFO - 2025-05-11 14:42:40 --> Database Driver Class Initialized
DEBUG - 2025-05-11 14:42:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 14:42:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 14:42:40 --> Controller Class Initialized
INFO - 2025-05-11 14:42:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-11 14:42:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/artikel.php
INFO - 2025-05-11 14:42:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-11 14:42:40 --> Final output sent to browser
DEBUG - 2025-05-11 14:42:40 --> Total execution time: 0.0674
INFO - 2025-05-11 14:42:43 --> Config Class Initialized
INFO - 2025-05-11 14:42:43 --> Hooks Class Initialized
DEBUG - 2025-05-11 14:42:43 --> UTF-8 Support Enabled
INFO - 2025-05-11 14:42:43 --> Utf8 Class Initialized
INFO - 2025-05-11 14:42:43 --> URI Class Initialized
INFO - 2025-05-11 14:42:43 --> Router Class Initialized
INFO - 2025-05-11 14:42:43 --> Output Class Initialized
INFO - 2025-05-11 14:42:43 --> Security Class Initialized
DEBUG - 2025-05-11 14:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 14:42:43 --> Input Class Initialized
INFO - 2025-05-11 14:42:43 --> Language Class Initialized
INFO - 2025-05-11 14:42:43 --> Loader Class Initialized
INFO - 2025-05-11 14:42:43 --> Helper loaded: url_helper
INFO - 2025-05-11 14:42:43 --> Helper loaded: form_helper
INFO - 2025-05-11 14:42:43 --> Database Driver Class Initialized
DEBUG - 2025-05-11 14:42:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 14:42:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 14:42:43 --> Controller Class Initialized
INFO - 2025-05-11 14:42:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-11 14:42:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-11 14:42:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-11 14:42:43 --> Final output sent to browser
DEBUG - 2025-05-11 14:42:43 --> Total execution time: 0.0510
INFO - 2025-05-11 14:59:59 --> Config Class Initialized
INFO - 2025-05-11 14:59:59 --> Hooks Class Initialized
DEBUG - 2025-05-11 14:59:59 --> UTF-8 Support Enabled
INFO - 2025-05-11 14:59:59 --> Utf8 Class Initialized
INFO - 2025-05-11 14:59:59 --> URI Class Initialized
INFO - 2025-05-11 14:59:59 --> Router Class Initialized
INFO - 2025-05-11 14:59:59 --> Output Class Initialized
INFO - 2025-05-11 14:59:59 --> Security Class Initialized
DEBUG - 2025-05-11 14:59:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 14:59:59 --> Input Class Initialized
INFO - 2025-05-11 14:59:59 --> Language Class Initialized
INFO - 2025-05-11 14:59:59 --> Loader Class Initialized
INFO - 2025-05-11 14:59:59 --> Helper loaded: url_helper
INFO - 2025-05-11 14:59:59 --> Helper loaded: form_helper
INFO - 2025-05-11 14:59:59 --> Database Driver Class Initialized
DEBUG - 2025-05-11 14:59:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 14:59:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 14:59:59 --> Controller Class Initialized
INFO - 2025-05-11 14:59:59 --> Model "User_model" initialized
INFO - 2025-05-11 14:59:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-11 14:59:59 --> Final output sent to browser
DEBUG - 2025-05-11 14:59:59 --> Total execution time: 0.0793
INFO - 2025-05-11 15:00:01 --> Config Class Initialized
INFO - 2025-05-11 15:00:01 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:00:01 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:00:01 --> Utf8 Class Initialized
INFO - 2025-05-11 15:00:01 --> URI Class Initialized
INFO - 2025-05-11 15:00:01 --> Router Class Initialized
INFO - 2025-05-11 15:00:01 --> Output Class Initialized
INFO - 2025-05-11 15:00:01 --> Security Class Initialized
DEBUG - 2025-05-11 15:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:00:01 --> Input Class Initialized
INFO - 2025-05-11 15:00:01 --> Language Class Initialized
INFO - 2025-05-11 15:00:01 --> Loader Class Initialized
INFO - 2025-05-11 15:00:01 --> Helper loaded: url_helper
INFO - 2025-05-11 15:00:01 --> Helper loaded: form_helper
INFO - 2025-05-11 15:00:01 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:00:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:00:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:00:01 --> Controller Class Initialized
INFO - 2025-05-11 15:00:01 --> Model "User_model" initialized
INFO - 2025-05-11 15:00:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/register.php
INFO - 2025-05-11 15:00:01 --> Final output sent to browser
DEBUG - 2025-05-11 15:00:01 --> Total execution time: 0.0783
INFO - 2025-05-11 15:00:05 --> Config Class Initialized
INFO - 2025-05-11 15:00:05 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:00:05 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:00:05 --> Utf8 Class Initialized
INFO - 2025-05-11 15:00:05 --> URI Class Initialized
INFO - 2025-05-11 15:00:05 --> Router Class Initialized
INFO - 2025-05-11 15:00:05 --> Output Class Initialized
INFO - 2025-05-11 15:00:05 --> Security Class Initialized
DEBUG - 2025-05-11 15:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:00:05 --> Input Class Initialized
INFO - 2025-05-11 15:00:05 --> Language Class Initialized
INFO - 2025-05-11 15:00:05 --> Loader Class Initialized
INFO - 2025-05-11 15:00:05 --> Helper loaded: url_helper
INFO - 2025-05-11 15:00:05 --> Helper loaded: form_helper
INFO - 2025-05-11 15:00:05 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:00:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:00:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:00:05 --> Controller Class Initialized
INFO - 2025-05-11 15:00:05 --> Model "User_model" initialized
INFO - 2025-05-11 15:00:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-11 15:00:05 --> Final output sent to browser
DEBUG - 2025-05-11 15:00:05 --> Total execution time: 0.0546
INFO - 2025-05-11 15:00:08 --> Config Class Initialized
INFO - 2025-05-11 15:00:08 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:00:08 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:00:08 --> Utf8 Class Initialized
INFO - 2025-05-11 15:00:08 --> URI Class Initialized
INFO - 2025-05-11 15:00:08 --> Router Class Initialized
INFO - 2025-05-11 15:00:08 --> Output Class Initialized
INFO - 2025-05-11 15:00:08 --> Security Class Initialized
DEBUG - 2025-05-11 15:00:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:00:08 --> Input Class Initialized
INFO - 2025-05-11 15:00:08 --> Language Class Initialized
INFO - 2025-05-11 15:00:08 --> Loader Class Initialized
INFO - 2025-05-11 15:00:08 --> Helper loaded: url_helper
INFO - 2025-05-11 15:00:08 --> Helper loaded: form_helper
INFO - 2025-05-11 15:00:08 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:00:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:00:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:00:08 --> Controller Class Initialized
INFO - 2025-05-11 15:00:08 --> Model "User_model" initialized
INFO - 2025-05-11 15:00:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/register.php
INFO - 2025-05-11 15:00:08 --> Final output sent to browser
DEBUG - 2025-05-11 15:00:08 --> Total execution time: 0.0444
INFO - 2025-05-11 15:00:10 --> Config Class Initialized
INFO - 2025-05-11 15:00:10 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:00:10 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:00:10 --> Utf8 Class Initialized
INFO - 2025-05-11 15:00:10 --> URI Class Initialized
INFO - 2025-05-11 15:00:10 --> Router Class Initialized
INFO - 2025-05-11 15:00:10 --> Output Class Initialized
INFO - 2025-05-11 15:00:10 --> Security Class Initialized
DEBUG - 2025-05-11 15:00:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:00:10 --> Input Class Initialized
INFO - 2025-05-11 15:00:10 --> Language Class Initialized
INFO - 2025-05-11 15:00:10 --> Loader Class Initialized
INFO - 2025-05-11 15:00:10 --> Helper loaded: url_helper
INFO - 2025-05-11 15:00:10 --> Helper loaded: form_helper
INFO - 2025-05-11 15:00:10 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:00:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:00:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:00:10 --> Controller Class Initialized
INFO - 2025-05-11 15:00:10 --> Model "User_model" initialized
INFO - 2025-05-11 15:00:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-11 15:00:10 --> Final output sent to browser
DEBUG - 2025-05-11 15:00:10 --> Total execution time: 0.0584
INFO - 2025-05-11 15:00:18 --> Config Class Initialized
INFO - 2025-05-11 15:00:18 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:00:18 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:00:18 --> Utf8 Class Initialized
INFO - 2025-05-11 15:00:18 --> URI Class Initialized
INFO - 2025-05-11 15:00:18 --> Router Class Initialized
INFO - 2025-05-11 15:00:18 --> Output Class Initialized
INFO - 2025-05-11 15:00:18 --> Security Class Initialized
DEBUG - 2025-05-11 15:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:00:18 --> Input Class Initialized
INFO - 2025-05-11 15:00:18 --> Language Class Initialized
INFO - 2025-05-11 15:00:18 --> Loader Class Initialized
INFO - 2025-05-11 15:00:18 --> Helper loaded: url_helper
INFO - 2025-05-11 15:00:18 --> Helper loaded: form_helper
INFO - 2025-05-11 15:00:18 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:00:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:00:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:00:18 --> Controller Class Initialized
INFO - 2025-05-11 15:00:18 --> Model "User_model" initialized
INFO - 2025-05-11 15:00:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-11 15:00:18 --> Final output sent to browser
DEBUG - 2025-05-11 15:00:18 --> Total execution time: 0.0608
INFO - 2025-05-11 15:00:20 --> Config Class Initialized
INFO - 2025-05-11 15:00:20 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:00:20 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:00:20 --> Utf8 Class Initialized
INFO - 2025-05-11 15:00:20 --> URI Class Initialized
INFO - 2025-05-11 15:00:20 --> Router Class Initialized
INFO - 2025-05-11 15:00:20 --> Output Class Initialized
INFO - 2025-05-11 15:00:20 --> Security Class Initialized
DEBUG - 2025-05-11 15:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:00:20 --> Input Class Initialized
INFO - 2025-05-11 15:00:20 --> Language Class Initialized
INFO - 2025-05-11 15:00:20 --> Loader Class Initialized
INFO - 2025-05-11 15:00:20 --> Helper loaded: url_helper
INFO - 2025-05-11 15:00:20 --> Helper loaded: form_helper
INFO - 2025-05-11 15:00:20 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:00:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:00:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:00:20 --> Controller Class Initialized
INFO - 2025-05-11 15:00:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-11 15:00:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-11 15:00:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-11 15:00:20 --> Final output sent to browser
DEBUG - 2025-05-11 15:00:20 --> Total execution time: 0.0632
INFO - 2025-05-11 15:01:35 --> Config Class Initialized
INFO - 2025-05-11 15:01:35 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:01:35 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:01:35 --> Utf8 Class Initialized
INFO - 2025-05-11 15:01:35 --> URI Class Initialized
INFO - 2025-05-11 15:01:35 --> Router Class Initialized
INFO - 2025-05-11 15:01:35 --> Output Class Initialized
INFO - 2025-05-11 15:01:35 --> Security Class Initialized
DEBUG - 2025-05-11 15:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:01:35 --> Input Class Initialized
INFO - 2025-05-11 15:01:35 --> Language Class Initialized
INFO - 2025-05-11 15:01:35 --> Loader Class Initialized
INFO - 2025-05-11 15:01:35 --> Helper loaded: url_helper
INFO - 2025-05-11 15:01:35 --> Helper loaded: form_helper
INFO - 2025-05-11 15:01:35 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:01:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:01:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:01:35 --> Controller Class Initialized
INFO - 2025-05-11 15:01:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-11 15:01:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/artikel.php
INFO - 2025-05-11 15:01:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-11 15:01:35 --> Final output sent to browser
DEBUG - 2025-05-11 15:01:35 --> Total execution time: 0.0560
INFO - 2025-05-11 15:01:43 --> Config Class Initialized
INFO - 2025-05-11 15:01:43 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:01:43 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:01:43 --> Utf8 Class Initialized
INFO - 2025-05-11 15:01:43 --> URI Class Initialized
INFO - 2025-05-11 15:01:43 --> Router Class Initialized
INFO - 2025-05-11 15:01:43 --> Output Class Initialized
INFO - 2025-05-11 15:01:43 --> Security Class Initialized
DEBUG - 2025-05-11 15:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:01:43 --> Input Class Initialized
INFO - 2025-05-11 15:01:43 --> Language Class Initialized
INFO - 2025-05-11 15:01:43 --> Loader Class Initialized
INFO - 2025-05-11 15:01:43 --> Helper loaded: url_helper
INFO - 2025-05-11 15:01:43 --> Helper loaded: form_helper
INFO - 2025-05-11 15:01:43 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:01:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:01:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:01:43 --> Controller Class Initialized
INFO - 2025-05-11 15:01:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-11 15:01:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-11 15:01:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-11 15:01:43 --> Final output sent to browser
DEBUG - 2025-05-11 15:01:43 --> Total execution time: 0.0788
INFO - 2025-05-11 15:03:12 --> Config Class Initialized
INFO - 2025-05-11 15:03:12 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:03:12 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:03:12 --> Utf8 Class Initialized
INFO - 2025-05-11 15:03:12 --> URI Class Initialized
INFO - 2025-05-11 15:03:12 --> Router Class Initialized
INFO - 2025-05-11 15:03:12 --> Output Class Initialized
INFO - 2025-05-11 15:03:12 --> Security Class Initialized
DEBUG - 2025-05-11 15:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:03:12 --> Input Class Initialized
INFO - 2025-05-11 15:03:12 --> Language Class Initialized
INFO - 2025-05-11 15:03:12 --> Loader Class Initialized
INFO - 2025-05-11 15:03:12 --> Helper loaded: url_helper
INFO - 2025-05-11 15:03:12 --> Helper loaded: form_helper
INFO - 2025-05-11 15:03:12 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:03:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:03:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:03:12 --> Controller Class Initialized
INFO - 2025-05-11 15:03:12 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-11 15:03:12 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-11 15:03:12 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-11 15:03:12 --> Final output sent to browser
DEBUG - 2025-05-11 15:03:12 --> Total execution time: 0.0499
INFO - 2025-05-11 15:03:14 --> Config Class Initialized
INFO - 2025-05-11 15:03:14 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:03:14 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:03:14 --> Utf8 Class Initialized
INFO - 2025-05-11 15:03:14 --> URI Class Initialized
INFO - 2025-05-11 15:03:14 --> Router Class Initialized
INFO - 2025-05-11 15:03:14 --> Output Class Initialized
INFO - 2025-05-11 15:03:14 --> Security Class Initialized
DEBUG - 2025-05-11 15:03:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:03:14 --> Input Class Initialized
INFO - 2025-05-11 15:03:14 --> Language Class Initialized
INFO - 2025-05-11 15:03:14 --> Loader Class Initialized
INFO - 2025-05-11 15:03:14 --> Helper loaded: url_helper
INFO - 2025-05-11 15:03:14 --> Helper loaded: form_helper
INFO - 2025-05-11 15:03:14 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:03:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:03:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:03:14 --> Controller Class Initialized
INFO - 2025-05-11 15:03:14 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-11 15:03:14 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/artikel.php
INFO - 2025-05-11 15:03:14 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-11 15:03:14 --> Final output sent to browser
DEBUG - 2025-05-11 15:03:14 --> Total execution time: 0.0531
INFO - 2025-05-11 15:03:20 --> Config Class Initialized
INFO - 2025-05-11 15:03:20 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:03:20 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:03:20 --> Utf8 Class Initialized
INFO - 2025-05-11 15:03:20 --> URI Class Initialized
INFO - 2025-05-11 15:03:20 --> Router Class Initialized
INFO - 2025-05-11 15:03:20 --> Output Class Initialized
INFO - 2025-05-11 15:03:20 --> Security Class Initialized
DEBUG - 2025-05-11 15:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:03:20 --> Input Class Initialized
INFO - 2025-05-11 15:03:20 --> Language Class Initialized
INFO - 2025-05-11 15:03:20 --> Loader Class Initialized
INFO - 2025-05-11 15:03:20 --> Helper loaded: url_helper
INFO - 2025-05-11 15:03:20 --> Helper loaded: form_helper
INFO - 2025-05-11 15:03:20 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:03:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:03:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:03:20 --> Controller Class Initialized
INFO - 2025-05-11 15:03:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-11 15:03:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-11 15:03:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-11 15:03:20 --> Final output sent to browser
DEBUG - 2025-05-11 15:03:20 --> Total execution time: 0.0520
INFO - 2025-05-11 15:03:35 --> Config Class Initialized
INFO - 2025-05-11 15:03:35 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:03:35 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:03:35 --> Utf8 Class Initialized
INFO - 2025-05-11 15:03:35 --> URI Class Initialized
INFO - 2025-05-11 15:03:35 --> Router Class Initialized
INFO - 2025-05-11 15:03:35 --> Output Class Initialized
INFO - 2025-05-11 15:03:35 --> Security Class Initialized
DEBUG - 2025-05-11 15:03:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:03:35 --> Input Class Initialized
INFO - 2025-05-11 15:03:35 --> Language Class Initialized
INFO - 2025-05-11 15:03:35 --> Loader Class Initialized
INFO - 2025-05-11 15:03:35 --> Helper loaded: url_helper
INFO - 2025-05-11 15:03:35 --> Helper loaded: form_helper
INFO - 2025-05-11 15:03:35 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:03:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:03:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:03:35 --> Controller Class Initialized
INFO - 2025-05-11 15:03:35 --> Model "User_model" initialized
INFO - 2025-05-11 15:03:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-11 15:03:35 --> Final output sent to browser
DEBUG - 2025-05-11 15:03:35 --> Total execution time: 0.0531
INFO - 2025-05-11 15:03:42 --> Config Class Initialized
INFO - 2025-05-11 15:03:42 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:03:42 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:03:42 --> Utf8 Class Initialized
INFO - 2025-05-11 15:03:42 --> URI Class Initialized
INFO - 2025-05-11 15:03:42 --> Router Class Initialized
INFO - 2025-05-11 15:03:42 --> Output Class Initialized
INFO - 2025-05-11 15:03:42 --> Security Class Initialized
DEBUG - 2025-05-11 15:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:03:42 --> Input Class Initialized
INFO - 2025-05-11 15:03:42 --> Language Class Initialized
INFO - 2025-05-11 15:03:42 --> Loader Class Initialized
INFO - 2025-05-11 15:03:42 --> Helper loaded: url_helper
INFO - 2025-05-11 15:03:42 --> Helper loaded: form_helper
INFO - 2025-05-11 15:03:42 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:03:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:03:42 --> Controller Class Initialized
INFO - 2025-05-11 15:03:42 --> Model "User_model" initialized
INFO - 2025-05-11 15:03:43 --> Config Class Initialized
INFO - 2025-05-11 15:03:43 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:03:43 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:03:43 --> Utf8 Class Initialized
INFO - 2025-05-11 15:03:43 --> URI Class Initialized
INFO - 2025-05-11 15:03:43 --> Router Class Initialized
INFO - 2025-05-11 15:03:43 --> Output Class Initialized
INFO - 2025-05-11 15:03:43 --> Security Class Initialized
DEBUG - 2025-05-11 15:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:03:43 --> Input Class Initialized
INFO - 2025-05-11 15:03:43 --> Language Class Initialized
INFO - 2025-05-11 15:03:43 --> Loader Class Initialized
INFO - 2025-05-11 15:03:43 --> Helper loaded: url_helper
INFO - 2025-05-11 15:03:43 --> Helper loaded: form_helper
INFO - 2025-05-11 15:03:43 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:03:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:03:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:03:43 --> Controller Class Initialized
INFO - 2025-05-11 15:03:43 --> Model "User_model" initialized
INFO - 2025-05-11 15:03:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard.php
INFO - 2025-05-11 15:03:43 --> Final output sent to browser
DEBUG - 2025-05-11 15:03:43 --> Total execution time: 0.0969
INFO - 2025-05-11 15:04:10 --> Config Class Initialized
INFO - 2025-05-11 15:04:10 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:04:10 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:04:10 --> Utf8 Class Initialized
INFO - 2025-05-11 15:04:10 --> URI Class Initialized
INFO - 2025-05-11 15:04:10 --> Router Class Initialized
INFO - 2025-05-11 15:04:10 --> Output Class Initialized
INFO - 2025-05-11 15:04:10 --> Security Class Initialized
DEBUG - 2025-05-11 15:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:04:10 --> Input Class Initialized
INFO - 2025-05-11 15:04:10 --> Language Class Initialized
INFO - 2025-05-11 15:04:10 --> Loader Class Initialized
INFO - 2025-05-11 15:04:10 --> Helper loaded: url_helper
INFO - 2025-05-11 15:04:10 --> Helper loaded: form_helper
INFO - 2025-05-11 15:04:10 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:04:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:04:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:04:10 --> Controller Class Initialized
INFO - 2025-05-11 15:04:10 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:04:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-11 15:04:10 --> Final output sent to browser
DEBUG - 2025-05-11 15:04:10 --> Total execution time: 0.1685
INFO - 2025-05-11 15:04:14 --> Config Class Initialized
INFO - 2025-05-11 15:04:14 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:04:14 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:04:14 --> Utf8 Class Initialized
INFO - 2025-05-11 15:04:14 --> URI Class Initialized
INFO - 2025-05-11 15:04:14 --> Router Class Initialized
INFO - 2025-05-11 15:04:14 --> Output Class Initialized
INFO - 2025-05-11 15:04:14 --> Security Class Initialized
DEBUG - 2025-05-11 15:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:04:14 --> Input Class Initialized
INFO - 2025-05-11 15:04:14 --> Language Class Initialized
INFO - 2025-05-11 15:04:14 --> Loader Class Initialized
INFO - 2025-05-11 15:04:14 --> Helper loaded: url_helper
INFO - 2025-05-11 15:04:14 --> Helper loaded: form_helper
INFO - 2025-05-11 15:04:14 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:04:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:04:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:04:14 --> Controller Class Initialized
INFO - 2025-05-11 15:04:14 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:04:14 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/add.php
INFO - 2025-05-11 15:04:14 --> Final output sent to browser
DEBUG - 2025-05-11 15:04:14 --> Total execution time: 0.0664
INFO - 2025-05-11 15:04:25 --> Config Class Initialized
INFO - 2025-05-11 15:04:25 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:04:25 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:04:25 --> Utf8 Class Initialized
INFO - 2025-05-11 15:04:25 --> URI Class Initialized
INFO - 2025-05-11 15:04:25 --> Router Class Initialized
INFO - 2025-05-11 15:04:25 --> Output Class Initialized
INFO - 2025-05-11 15:04:25 --> Security Class Initialized
DEBUG - 2025-05-11 15:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:04:25 --> Input Class Initialized
INFO - 2025-05-11 15:04:25 --> Language Class Initialized
INFO - 2025-05-11 15:04:25 --> Loader Class Initialized
INFO - 2025-05-11 15:04:25 --> Helper loaded: url_helper
INFO - 2025-05-11 15:04:25 --> Helper loaded: form_helper
INFO - 2025-05-11 15:04:25 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:04:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:04:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:04:25 --> Controller Class Initialized
INFO - 2025-05-11 15:04:25 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:04:25 --> Config Class Initialized
INFO - 2025-05-11 15:04:25 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:04:25 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:04:25 --> Utf8 Class Initialized
INFO - 2025-05-11 15:04:25 --> URI Class Initialized
INFO - 2025-05-11 15:04:25 --> Router Class Initialized
INFO - 2025-05-11 15:04:25 --> Output Class Initialized
INFO - 2025-05-11 15:04:25 --> Security Class Initialized
DEBUG - 2025-05-11 15:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:04:25 --> Input Class Initialized
INFO - 2025-05-11 15:04:25 --> Language Class Initialized
INFO - 2025-05-11 15:04:25 --> Loader Class Initialized
INFO - 2025-05-11 15:04:25 --> Helper loaded: url_helper
INFO - 2025-05-11 15:04:25 --> Helper loaded: form_helper
INFO - 2025-05-11 15:04:25 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:04:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:04:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:04:25 --> Controller Class Initialized
INFO - 2025-05-11 15:04:25 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:04:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-11 15:04:25 --> Final output sent to browser
DEBUG - 2025-05-11 15:04:25 --> Total execution time: 0.0557
INFO - 2025-05-11 15:04:28 --> Config Class Initialized
INFO - 2025-05-11 15:04:28 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:04:28 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:04:28 --> Utf8 Class Initialized
INFO - 2025-05-11 15:04:28 --> URI Class Initialized
INFO - 2025-05-11 15:04:28 --> Router Class Initialized
INFO - 2025-05-11 15:04:28 --> Output Class Initialized
INFO - 2025-05-11 15:04:28 --> Security Class Initialized
DEBUG - 2025-05-11 15:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:04:28 --> Input Class Initialized
INFO - 2025-05-11 15:04:28 --> Language Class Initialized
INFO - 2025-05-11 15:04:28 --> Loader Class Initialized
INFO - 2025-05-11 15:04:28 --> Helper loaded: url_helper
INFO - 2025-05-11 15:04:28 --> Helper loaded: form_helper
INFO - 2025-05-11 15:04:28 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:04:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:04:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:04:28 --> Controller Class Initialized
INFO - 2025-05-11 15:04:28 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:04:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/start.php
INFO - 2025-05-11 15:04:28 --> Final output sent to browser
DEBUG - 2025-05-11 15:04:28 --> Total execution time: 0.1167
INFO - 2025-05-11 15:04:33 --> Config Class Initialized
INFO - 2025-05-11 15:04:33 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:04:33 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:04:33 --> Utf8 Class Initialized
INFO - 2025-05-11 15:04:33 --> URI Class Initialized
INFO - 2025-05-11 15:04:33 --> Router Class Initialized
INFO - 2025-05-11 15:04:33 --> Output Class Initialized
INFO - 2025-05-11 15:04:33 --> Security Class Initialized
DEBUG - 2025-05-11 15:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:04:33 --> Input Class Initialized
INFO - 2025-05-11 15:04:33 --> Language Class Initialized
INFO - 2025-05-11 15:04:33 --> Loader Class Initialized
INFO - 2025-05-11 15:04:33 --> Helper loaded: url_helper
INFO - 2025-05-11 15:04:33 --> Helper loaded: form_helper
INFO - 2025-05-11 15:04:33 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:04:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:04:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:04:33 --> Controller Class Initialized
INFO - 2025-05-11 15:04:33 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:04:33 --> Final output sent to browser
DEBUG - 2025-05-11 15:04:33 --> Total execution time: 0.0669
INFO - 2025-05-11 15:04:42 --> Config Class Initialized
INFO - 2025-05-11 15:04:42 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:04:42 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:04:42 --> Utf8 Class Initialized
INFO - 2025-05-11 15:04:42 --> URI Class Initialized
INFO - 2025-05-11 15:04:42 --> Router Class Initialized
INFO - 2025-05-11 15:04:42 --> Output Class Initialized
INFO - 2025-05-11 15:04:42 --> Security Class Initialized
DEBUG - 2025-05-11 15:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:04:42 --> Input Class Initialized
INFO - 2025-05-11 15:04:42 --> Language Class Initialized
INFO - 2025-05-11 15:04:42 --> Loader Class Initialized
INFO - 2025-05-11 15:04:42 --> Helper loaded: url_helper
INFO - 2025-05-11 15:04:42 --> Helper loaded: form_helper
INFO - 2025-05-11 15:04:42 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:04:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:04:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:04:42 --> Controller Class Initialized
INFO - 2025-05-11 15:04:42 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:04:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-11 15:04:42 --> Final output sent to browser
DEBUG - 2025-05-11 15:04:42 --> Total execution time: 0.0672
INFO - 2025-05-11 15:04:58 --> Config Class Initialized
INFO - 2025-05-11 15:04:58 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:04:58 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:04:58 --> Utf8 Class Initialized
INFO - 2025-05-11 15:04:58 --> URI Class Initialized
INFO - 2025-05-11 15:04:58 --> Router Class Initialized
INFO - 2025-05-11 15:04:58 --> Output Class Initialized
INFO - 2025-05-11 15:04:58 --> Security Class Initialized
DEBUG - 2025-05-11 15:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:04:58 --> Input Class Initialized
INFO - 2025-05-11 15:04:58 --> Language Class Initialized
INFO - 2025-05-11 15:04:58 --> Loader Class Initialized
INFO - 2025-05-11 15:04:58 --> Helper loaded: url_helper
INFO - 2025-05-11 15:04:58 --> Helper loaded: form_helper
INFO - 2025-05-11 15:04:58 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:04:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:04:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:04:58 --> Controller Class Initialized
INFO - 2025-05-11 15:04:58 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:04:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/add.php
INFO - 2025-05-11 15:04:58 --> Final output sent to browser
DEBUG - 2025-05-11 15:04:58 --> Total execution time: 0.0612
INFO - 2025-05-11 15:05:14 --> Config Class Initialized
INFO - 2025-05-11 15:05:14 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:05:14 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:05:14 --> Utf8 Class Initialized
INFO - 2025-05-11 15:05:14 --> URI Class Initialized
INFO - 2025-05-11 15:05:14 --> Router Class Initialized
INFO - 2025-05-11 15:05:14 --> Output Class Initialized
INFO - 2025-05-11 15:05:14 --> Security Class Initialized
DEBUG - 2025-05-11 15:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:05:14 --> Input Class Initialized
INFO - 2025-05-11 15:05:14 --> Language Class Initialized
INFO - 2025-05-11 15:05:14 --> Loader Class Initialized
INFO - 2025-05-11 15:05:14 --> Helper loaded: url_helper
INFO - 2025-05-11 15:05:14 --> Helper loaded: form_helper
INFO - 2025-05-11 15:05:14 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:05:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:05:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:05:14 --> Controller Class Initialized
INFO - 2025-05-11 15:05:14 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:05:14 --> Config Class Initialized
INFO - 2025-05-11 15:05:14 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:05:14 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:05:14 --> Utf8 Class Initialized
INFO - 2025-05-11 15:05:14 --> URI Class Initialized
INFO - 2025-05-11 15:05:14 --> Router Class Initialized
INFO - 2025-05-11 15:05:14 --> Output Class Initialized
INFO - 2025-05-11 15:05:14 --> Security Class Initialized
DEBUG - 2025-05-11 15:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:05:14 --> Input Class Initialized
INFO - 2025-05-11 15:05:14 --> Language Class Initialized
INFO - 2025-05-11 15:05:14 --> Loader Class Initialized
INFO - 2025-05-11 15:05:14 --> Helper loaded: url_helper
INFO - 2025-05-11 15:05:14 --> Helper loaded: form_helper
INFO - 2025-05-11 15:05:14 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:05:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:05:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:05:14 --> Controller Class Initialized
INFO - 2025-05-11 15:05:14 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:05:14 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-11 15:05:14 --> Final output sent to browser
DEBUG - 2025-05-11 15:05:14 --> Total execution time: 0.0466
INFO - 2025-05-11 15:05:18 --> Config Class Initialized
INFO - 2025-05-11 15:05:18 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:05:18 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:05:18 --> Utf8 Class Initialized
INFO - 2025-05-11 15:05:18 --> URI Class Initialized
INFO - 2025-05-11 15:05:18 --> Router Class Initialized
INFO - 2025-05-11 15:05:18 --> Output Class Initialized
INFO - 2025-05-11 15:05:18 --> Security Class Initialized
DEBUG - 2025-05-11 15:05:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:05:18 --> Input Class Initialized
INFO - 2025-05-11 15:05:18 --> Language Class Initialized
INFO - 2025-05-11 15:05:18 --> Loader Class Initialized
INFO - 2025-05-11 15:05:18 --> Helper loaded: url_helper
INFO - 2025-05-11 15:05:18 --> Helper loaded: form_helper
INFO - 2025-05-11 15:05:18 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:05:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:05:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:05:18 --> Controller Class Initialized
INFO - 2025-05-11 15:05:18 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:05:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-11 15:05:18 --> Final output sent to browser
DEBUG - 2025-05-11 15:05:18 --> Total execution time: 0.0590
INFO - 2025-05-11 15:05:20 --> Config Class Initialized
INFO - 2025-05-11 15:05:20 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:05:20 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:05:20 --> Utf8 Class Initialized
INFO - 2025-05-11 15:05:20 --> URI Class Initialized
INFO - 2025-05-11 15:05:20 --> Router Class Initialized
INFO - 2025-05-11 15:05:20 --> Output Class Initialized
INFO - 2025-05-11 15:05:20 --> Security Class Initialized
DEBUG - 2025-05-11 15:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:05:20 --> Input Class Initialized
INFO - 2025-05-11 15:05:20 --> Language Class Initialized
INFO - 2025-05-11 15:05:20 --> Loader Class Initialized
INFO - 2025-05-11 15:05:20 --> Helper loaded: url_helper
INFO - 2025-05-11 15:05:20 --> Helper loaded: form_helper
INFO - 2025-05-11 15:05:20 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:05:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:05:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:05:20 --> Controller Class Initialized
INFO - 2025-05-11 15:05:20 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:05:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-11 15:05:20 --> Final output sent to browser
DEBUG - 2025-05-11 15:05:20 --> Total execution time: 0.0717
INFO - 2025-05-11 15:05:20 --> Config Class Initialized
INFO - 2025-05-11 15:05:20 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:05:20 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:05:20 --> Utf8 Class Initialized
INFO - 2025-05-11 15:05:20 --> URI Class Initialized
INFO - 2025-05-11 15:05:20 --> Router Class Initialized
INFO - 2025-05-11 15:05:20 --> Output Class Initialized
INFO - 2025-05-11 15:05:20 --> Security Class Initialized
DEBUG - 2025-05-11 15:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:05:20 --> Input Class Initialized
INFO - 2025-05-11 15:05:20 --> Language Class Initialized
INFO - 2025-05-11 15:05:20 --> Loader Class Initialized
INFO - 2025-05-11 15:05:20 --> Helper loaded: url_helper
INFO - 2025-05-11 15:05:20 --> Helper loaded: form_helper
INFO - 2025-05-11 15:05:20 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:05:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:05:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:05:21 --> Controller Class Initialized
INFO - 2025-05-11 15:05:21 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:05:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-11 15:05:21 --> Final output sent to browser
DEBUG - 2025-05-11 15:05:21 --> Total execution time: 0.0703
INFO - 2025-05-11 15:05:23 --> Config Class Initialized
INFO - 2025-05-11 15:05:23 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:05:23 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:05:23 --> Utf8 Class Initialized
INFO - 2025-05-11 15:05:23 --> URI Class Initialized
INFO - 2025-05-11 15:05:23 --> Router Class Initialized
INFO - 2025-05-11 15:05:23 --> Output Class Initialized
INFO - 2025-05-11 15:05:23 --> Security Class Initialized
DEBUG - 2025-05-11 15:05:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:05:23 --> Input Class Initialized
INFO - 2025-05-11 15:05:23 --> Language Class Initialized
INFO - 2025-05-11 15:05:23 --> Loader Class Initialized
INFO - 2025-05-11 15:05:23 --> Helper loaded: url_helper
INFO - 2025-05-11 15:05:23 --> Helper loaded: form_helper
INFO - 2025-05-11 15:05:23 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:05:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:05:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:05:23 --> Controller Class Initialized
INFO - 2025-05-11 15:05:23 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:05:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/start.php
INFO - 2025-05-11 15:05:23 --> Final output sent to browser
DEBUG - 2025-05-11 15:05:23 --> Total execution time: 0.0478
INFO - 2025-05-11 15:05:30 --> Config Class Initialized
INFO - 2025-05-11 15:05:30 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:05:30 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:05:30 --> Utf8 Class Initialized
INFO - 2025-05-11 15:05:30 --> URI Class Initialized
INFO - 2025-05-11 15:05:30 --> Router Class Initialized
INFO - 2025-05-11 15:05:30 --> Output Class Initialized
INFO - 2025-05-11 15:05:30 --> Security Class Initialized
DEBUG - 2025-05-11 15:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:05:30 --> Input Class Initialized
INFO - 2025-05-11 15:05:30 --> Language Class Initialized
INFO - 2025-05-11 15:05:30 --> Loader Class Initialized
INFO - 2025-05-11 15:05:30 --> Helper loaded: url_helper
INFO - 2025-05-11 15:05:30 --> Helper loaded: form_helper
INFO - 2025-05-11 15:05:30 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:05:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:05:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:05:30 --> Controller Class Initialized
INFO - 2025-05-11 15:05:30 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:05:30 --> Final output sent to browser
DEBUG - 2025-05-11 15:05:30 --> Total execution time: 0.0750
INFO - 2025-05-11 15:06:27 --> Config Class Initialized
INFO - 2025-05-11 15:06:27 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:06:27 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:06:27 --> Utf8 Class Initialized
INFO - 2025-05-11 15:06:27 --> URI Class Initialized
INFO - 2025-05-11 15:06:27 --> Router Class Initialized
INFO - 2025-05-11 15:06:27 --> Output Class Initialized
INFO - 2025-05-11 15:06:27 --> Security Class Initialized
DEBUG - 2025-05-11 15:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:06:27 --> Input Class Initialized
INFO - 2025-05-11 15:06:27 --> Language Class Initialized
INFO - 2025-05-11 15:06:27 --> Loader Class Initialized
INFO - 2025-05-11 15:06:27 --> Helper loaded: url_helper
INFO - 2025-05-11 15:06:27 --> Helper loaded: form_helper
INFO - 2025-05-11 15:06:27 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:06:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:06:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:06:27 --> Controller Class Initialized
INFO - 2025-05-11 15:06:27 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:06:27 --> Final output sent to browser
DEBUG - 2025-05-11 15:06:27 --> Total execution time: 0.0490
INFO - 2025-05-11 15:06:28 --> Config Class Initialized
INFO - 2025-05-11 15:06:28 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:06:28 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:06:28 --> Utf8 Class Initialized
INFO - 2025-05-11 15:06:28 --> URI Class Initialized
INFO - 2025-05-11 15:06:28 --> Router Class Initialized
INFO - 2025-05-11 15:06:28 --> Output Class Initialized
INFO - 2025-05-11 15:06:28 --> Security Class Initialized
DEBUG - 2025-05-11 15:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:06:28 --> Input Class Initialized
INFO - 2025-05-11 15:06:28 --> Language Class Initialized
INFO - 2025-05-11 15:06:28 --> Loader Class Initialized
INFO - 2025-05-11 15:06:28 --> Helper loaded: url_helper
INFO - 2025-05-11 15:06:28 --> Helper loaded: form_helper
INFO - 2025-05-11 15:06:28 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:06:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:06:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:06:28 --> Controller Class Initialized
INFO - 2025-05-11 15:06:28 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:06:28 --> Final output sent to browser
DEBUG - 2025-05-11 15:06:28 --> Total execution time: 0.0606
INFO - 2025-05-11 15:06:29 --> Config Class Initialized
INFO - 2025-05-11 15:06:29 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:06:29 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:06:29 --> Utf8 Class Initialized
INFO - 2025-05-11 15:06:29 --> URI Class Initialized
INFO - 2025-05-11 15:06:29 --> Router Class Initialized
INFO - 2025-05-11 15:06:29 --> Output Class Initialized
INFO - 2025-05-11 15:06:29 --> Security Class Initialized
DEBUG - 2025-05-11 15:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:06:29 --> Input Class Initialized
INFO - 2025-05-11 15:06:29 --> Language Class Initialized
INFO - 2025-05-11 15:06:29 --> Loader Class Initialized
INFO - 2025-05-11 15:06:29 --> Helper loaded: url_helper
INFO - 2025-05-11 15:06:29 --> Helper loaded: form_helper
INFO - 2025-05-11 15:06:29 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:06:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:06:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:06:29 --> Controller Class Initialized
INFO - 2025-05-11 15:06:29 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:06:29 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-11 15:06:29 --> Final output sent to browser
DEBUG - 2025-05-11 15:06:29 --> Total execution time: 0.0576
INFO - 2025-05-11 15:07:39 --> Config Class Initialized
INFO - 2025-05-11 15:07:39 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:07:39 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:07:39 --> Utf8 Class Initialized
INFO - 2025-05-11 15:07:39 --> URI Class Initialized
INFO - 2025-05-11 15:07:39 --> Router Class Initialized
INFO - 2025-05-11 15:07:39 --> Output Class Initialized
INFO - 2025-05-11 15:07:39 --> Security Class Initialized
DEBUG - 2025-05-11 15:07:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:07:39 --> Input Class Initialized
INFO - 2025-05-11 15:07:39 --> Language Class Initialized
INFO - 2025-05-11 15:07:39 --> Loader Class Initialized
INFO - 2025-05-11 15:07:39 --> Helper loaded: url_helper
INFO - 2025-05-11 15:07:39 --> Helper loaded: form_helper
INFO - 2025-05-11 15:07:39 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:07:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:07:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:07:39 --> Controller Class Initialized
INFO - 2025-05-11 15:07:39 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:07:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-11 15:07:39 --> Final output sent to browser
DEBUG - 2025-05-11 15:07:39 --> Total execution time: 0.0564
INFO - 2025-05-11 15:07:41 --> Config Class Initialized
INFO - 2025-05-11 15:07:41 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:07:41 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:07:41 --> Utf8 Class Initialized
INFO - 2025-05-11 15:07:41 --> URI Class Initialized
INFO - 2025-05-11 15:07:41 --> Router Class Initialized
INFO - 2025-05-11 15:07:41 --> Output Class Initialized
INFO - 2025-05-11 15:07:41 --> Security Class Initialized
DEBUG - 2025-05-11 15:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:07:41 --> Input Class Initialized
INFO - 2025-05-11 15:07:41 --> Language Class Initialized
INFO - 2025-05-11 15:07:41 --> Loader Class Initialized
INFO - 2025-05-11 15:07:41 --> Helper loaded: url_helper
INFO - 2025-05-11 15:07:41 --> Helper loaded: form_helper
INFO - 2025-05-11 15:07:41 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:07:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:07:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:07:41 --> Controller Class Initialized
INFO - 2025-05-11 15:07:41 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:07:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/start.php
INFO - 2025-05-11 15:07:41 --> Final output sent to browser
DEBUG - 2025-05-11 15:07:41 --> Total execution time: 0.0691
INFO - 2025-05-11 15:07:43 --> Config Class Initialized
INFO - 2025-05-11 15:07:43 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:07:43 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:07:43 --> Utf8 Class Initialized
INFO - 2025-05-11 15:07:43 --> URI Class Initialized
INFO - 2025-05-11 15:07:43 --> Router Class Initialized
INFO - 2025-05-11 15:07:43 --> Output Class Initialized
INFO - 2025-05-11 15:07:43 --> Security Class Initialized
DEBUG - 2025-05-11 15:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:07:43 --> Input Class Initialized
INFO - 2025-05-11 15:07:43 --> Language Class Initialized
INFO - 2025-05-11 15:07:43 --> Loader Class Initialized
INFO - 2025-05-11 15:07:43 --> Helper loaded: url_helper
INFO - 2025-05-11 15:07:43 --> Helper loaded: form_helper
INFO - 2025-05-11 15:07:43 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:07:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:07:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:07:43 --> Controller Class Initialized
INFO - 2025-05-11 15:07:43 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:07:43 --> Final output sent to browser
DEBUG - 2025-05-11 15:07:43 --> Total execution time: 0.0669
INFO - 2025-05-11 15:07:46 --> Config Class Initialized
INFO - 2025-05-11 15:07:46 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:07:46 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:07:46 --> Utf8 Class Initialized
INFO - 2025-05-11 15:07:46 --> URI Class Initialized
INFO - 2025-05-11 15:07:46 --> Router Class Initialized
INFO - 2025-05-11 15:07:46 --> Output Class Initialized
INFO - 2025-05-11 15:07:46 --> Security Class Initialized
DEBUG - 2025-05-11 15:07:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:07:46 --> Input Class Initialized
INFO - 2025-05-11 15:07:46 --> Language Class Initialized
INFO - 2025-05-11 15:07:46 --> Loader Class Initialized
INFO - 2025-05-11 15:07:46 --> Helper loaded: url_helper
INFO - 2025-05-11 15:07:46 --> Helper loaded: form_helper
INFO - 2025-05-11 15:07:46 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:07:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:07:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:07:47 --> Controller Class Initialized
INFO - 2025-05-11 15:07:47 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:07:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-11 15:07:47 --> Final output sent to browser
DEBUG - 2025-05-11 15:07:47 --> Total execution time: 0.0682
INFO - 2025-05-11 15:22:43 --> Config Class Initialized
INFO - 2025-05-11 15:22:43 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:22:43 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:22:43 --> Utf8 Class Initialized
INFO - 2025-05-11 15:22:43 --> URI Class Initialized
INFO - 2025-05-11 15:22:43 --> Router Class Initialized
INFO - 2025-05-11 15:22:43 --> Output Class Initialized
INFO - 2025-05-11 15:22:43 --> Security Class Initialized
DEBUG - 2025-05-11 15:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:22:43 --> Input Class Initialized
INFO - 2025-05-11 15:22:43 --> Language Class Initialized
INFO - 2025-05-11 15:22:43 --> Loader Class Initialized
INFO - 2025-05-11 15:22:43 --> Helper loaded: url_helper
INFO - 2025-05-11 15:22:43 --> Helper loaded: form_helper
INFO - 2025-05-11 15:22:43 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:22:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:22:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:22:43 --> Controller Class Initialized
INFO - 2025-05-11 15:22:43 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:22:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-11 15:22:43 --> Final output sent to browser
DEBUG - 2025-05-11 15:22:43 --> Total execution time: 0.0523
INFO - 2025-05-11 15:27:32 --> Config Class Initialized
INFO - 2025-05-11 15:27:32 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:27:32 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:27:32 --> Utf8 Class Initialized
INFO - 2025-05-11 15:27:32 --> URI Class Initialized
INFO - 2025-05-11 15:27:32 --> Router Class Initialized
INFO - 2025-05-11 15:27:32 --> Output Class Initialized
INFO - 2025-05-11 15:27:32 --> Security Class Initialized
DEBUG - 2025-05-11 15:27:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:27:32 --> Input Class Initialized
INFO - 2025-05-11 15:27:32 --> Language Class Initialized
INFO - 2025-05-11 15:27:32 --> Loader Class Initialized
INFO - 2025-05-11 15:27:32 --> Helper loaded: url_helper
INFO - 2025-05-11 15:27:32 --> Helper loaded: form_helper
INFO - 2025-05-11 15:27:32 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:27:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:27:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:27:32 --> Controller Class Initialized
INFO - 2025-05-11 15:27:32 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:27:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-11 15:27:32 --> Final output sent to browser
DEBUG - 2025-05-11 15:27:32 --> Total execution time: 0.0737
INFO - 2025-05-11 15:27:35 --> Config Class Initialized
INFO - 2025-05-11 15:27:35 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:27:35 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:27:35 --> Utf8 Class Initialized
INFO - 2025-05-11 15:27:35 --> URI Class Initialized
INFO - 2025-05-11 15:27:35 --> Router Class Initialized
INFO - 2025-05-11 15:27:35 --> Output Class Initialized
INFO - 2025-05-11 15:27:35 --> Security Class Initialized
DEBUG - 2025-05-11 15:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:27:35 --> Input Class Initialized
INFO - 2025-05-11 15:27:35 --> Language Class Initialized
INFO - 2025-05-11 15:27:35 --> Loader Class Initialized
INFO - 2025-05-11 15:27:35 --> Helper loaded: url_helper
INFO - 2025-05-11 15:27:35 --> Helper loaded: form_helper
INFO - 2025-05-11 15:27:35 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:27:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:27:35 --> Controller Class Initialized
INFO - 2025-05-11 15:27:35 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:27:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/start.php
INFO - 2025-05-11 15:27:35 --> Final output sent to browser
DEBUG - 2025-05-11 15:27:35 --> Total execution time: 0.0523
INFO - 2025-05-11 15:27:44 --> Config Class Initialized
INFO - 2025-05-11 15:27:44 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:27:44 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:27:44 --> Utf8 Class Initialized
INFO - 2025-05-11 15:27:44 --> URI Class Initialized
INFO - 2025-05-11 15:27:44 --> Router Class Initialized
INFO - 2025-05-11 15:27:44 --> Output Class Initialized
INFO - 2025-05-11 15:27:44 --> Security Class Initialized
DEBUG - 2025-05-11 15:27:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:27:44 --> Input Class Initialized
INFO - 2025-05-11 15:27:44 --> Language Class Initialized
INFO - 2025-05-11 15:27:44 --> Loader Class Initialized
INFO - 2025-05-11 15:27:44 --> Helper loaded: url_helper
INFO - 2025-05-11 15:27:45 --> Helper loaded: form_helper
INFO - 2025-05-11 15:27:45 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:27:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:27:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:27:45 --> Controller Class Initialized
INFO - 2025-05-11 15:27:45 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:27:45 --> Final output sent to browser
DEBUG - 2025-05-11 15:27:45 --> Total execution time: 0.0574
INFO - 2025-05-11 15:27:45 --> Config Class Initialized
INFO - 2025-05-11 15:27:45 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:27:45 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:27:45 --> Utf8 Class Initialized
INFO - 2025-05-11 15:27:45 --> URI Class Initialized
INFO - 2025-05-11 15:27:45 --> Router Class Initialized
INFO - 2025-05-11 15:27:45 --> Output Class Initialized
INFO - 2025-05-11 15:27:45 --> Security Class Initialized
DEBUG - 2025-05-11 15:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:27:45 --> Input Class Initialized
INFO - 2025-05-11 15:27:45 --> Language Class Initialized
INFO - 2025-05-11 15:27:45 --> Loader Class Initialized
INFO - 2025-05-11 15:27:45 --> Helper loaded: url_helper
INFO - 2025-05-11 15:27:45 --> Helper loaded: form_helper
INFO - 2025-05-11 15:27:45 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:27:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:27:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:27:45 --> Controller Class Initialized
INFO - 2025-05-11 15:27:45 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:27:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-11 15:27:45 --> Final output sent to browser
DEBUG - 2025-05-11 15:27:45 --> Total execution time: 0.0720
INFO - 2025-05-11 15:27:52 --> Config Class Initialized
INFO - 2025-05-11 15:27:52 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:27:52 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:27:52 --> Utf8 Class Initialized
INFO - 2025-05-11 15:27:52 --> URI Class Initialized
INFO - 2025-05-11 15:27:52 --> Router Class Initialized
INFO - 2025-05-11 15:27:52 --> Output Class Initialized
INFO - 2025-05-11 15:27:52 --> Security Class Initialized
DEBUG - 2025-05-11 15:27:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:27:52 --> Input Class Initialized
INFO - 2025-05-11 15:27:52 --> Language Class Initialized
INFO - 2025-05-11 15:27:52 --> Loader Class Initialized
INFO - 2025-05-11 15:27:52 --> Helper loaded: url_helper
INFO - 2025-05-11 15:27:52 --> Helper loaded: form_helper
INFO - 2025-05-11 15:27:52 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:27:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:27:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:27:52 --> Controller Class Initialized
INFO - 2025-05-11 15:27:52 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:27:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/add.php
INFO - 2025-05-11 15:27:52 --> Final output sent to browser
DEBUG - 2025-05-11 15:27:52 --> Total execution time: 0.0520
INFO - 2025-05-11 15:28:23 --> Config Class Initialized
INFO - 2025-05-11 15:28:23 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:28:23 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:28:23 --> Utf8 Class Initialized
INFO - 2025-05-11 15:28:23 --> URI Class Initialized
INFO - 2025-05-11 15:28:23 --> Router Class Initialized
INFO - 2025-05-11 15:28:23 --> Output Class Initialized
INFO - 2025-05-11 15:28:23 --> Security Class Initialized
DEBUG - 2025-05-11 15:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:28:23 --> Input Class Initialized
INFO - 2025-05-11 15:28:23 --> Language Class Initialized
INFO - 2025-05-11 15:28:23 --> Loader Class Initialized
INFO - 2025-05-11 15:28:23 --> Helper loaded: url_helper
INFO - 2025-05-11 15:28:23 --> Helper loaded: form_helper
INFO - 2025-05-11 15:28:23 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:28:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:28:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:28:23 --> Controller Class Initialized
INFO - 2025-05-11 15:28:23 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:28:24 --> Config Class Initialized
INFO - 2025-05-11 15:28:24 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:28:24 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:28:24 --> Utf8 Class Initialized
INFO - 2025-05-11 15:28:24 --> URI Class Initialized
INFO - 2025-05-11 15:28:24 --> Router Class Initialized
INFO - 2025-05-11 15:28:24 --> Output Class Initialized
INFO - 2025-05-11 15:28:24 --> Security Class Initialized
DEBUG - 2025-05-11 15:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:28:24 --> Input Class Initialized
INFO - 2025-05-11 15:28:24 --> Language Class Initialized
INFO - 2025-05-11 15:28:24 --> Loader Class Initialized
INFO - 2025-05-11 15:28:24 --> Helper loaded: url_helper
INFO - 2025-05-11 15:28:24 --> Helper loaded: form_helper
INFO - 2025-05-11 15:28:24 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:28:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:28:24 --> Controller Class Initialized
INFO - 2025-05-11 15:28:24 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:28:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-11 15:28:24 --> Final output sent to browser
DEBUG - 2025-05-11 15:28:24 --> Total execution time: 0.0531
INFO - 2025-05-11 15:28:26 --> Config Class Initialized
INFO - 2025-05-11 15:28:26 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:28:26 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:28:26 --> Utf8 Class Initialized
INFO - 2025-05-11 15:28:26 --> URI Class Initialized
INFO - 2025-05-11 15:28:26 --> Router Class Initialized
INFO - 2025-05-11 15:28:26 --> Output Class Initialized
INFO - 2025-05-11 15:28:26 --> Security Class Initialized
DEBUG - 2025-05-11 15:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:28:26 --> Input Class Initialized
INFO - 2025-05-11 15:28:26 --> Language Class Initialized
INFO - 2025-05-11 15:28:26 --> Loader Class Initialized
INFO - 2025-05-11 15:28:26 --> Helper loaded: url_helper
INFO - 2025-05-11 15:28:26 --> Helper loaded: form_helper
INFO - 2025-05-11 15:28:26 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:28:26 --> Controller Class Initialized
INFO - 2025-05-11 15:28:26 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:28:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/start.php
INFO - 2025-05-11 15:28:26 --> Final output sent to browser
DEBUG - 2025-05-11 15:28:26 --> Total execution time: 0.0676
INFO - 2025-05-11 15:28:31 --> Config Class Initialized
INFO - 2025-05-11 15:28:31 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:28:31 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:28:31 --> Utf8 Class Initialized
INFO - 2025-05-11 15:28:31 --> URI Class Initialized
INFO - 2025-05-11 15:28:31 --> Router Class Initialized
INFO - 2025-05-11 15:28:31 --> Output Class Initialized
INFO - 2025-05-11 15:28:31 --> Security Class Initialized
DEBUG - 2025-05-11 15:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:28:31 --> Input Class Initialized
INFO - 2025-05-11 15:28:31 --> Language Class Initialized
INFO - 2025-05-11 15:28:31 --> Loader Class Initialized
INFO - 2025-05-11 15:28:31 --> Helper loaded: url_helper
INFO - 2025-05-11 15:28:31 --> Helper loaded: form_helper
INFO - 2025-05-11 15:28:31 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:28:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:28:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:28:31 --> Controller Class Initialized
INFO - 2025-05-11 15:28:31 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:28:31 --> Final output sent to browser
DEBUG - 2025-05-11 15:28:31 --> Total execution time: 0.0633
INFO - 2025-05-11 15:28:31 --> Config Class Initialized
INFO - 2025-05-11 15:28:31 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:28:31 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:28:31 --> Utf8 Class Initialized
INFO - 2025-05-11 15:28:31 --> URI Class Initialized
INFO - 2025-05-11 15:28:31 --> Router Class Initialized
INFO - 2025-05-11 15:28:31 --> Output Class Initialized
INFO - 2025-05-11 15:28:31 --> Security Class Initialized
DEBUG - 2025-05-11 15:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:28:31 --> Input Class Initialized
INFO - 2025-05-11 15:28:31 --> Language Class Initialized
INFO - 2025-05-11 15:28:31 --> Loader Class Initialized
INFO - 2025-05-11 15:28:31 --> Helper loaded: url_helper
INFO - 2025-05-11 15:28:31 --> Helper loaded: form_helper
INFO - 2025-05-11 15:28:31 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:28:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:28:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:28:31 --> Controller Class Initialized
INFO - 2025-05-11 15:28:31 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:28:31 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-11 15:28:31 --> Final output sent to browser
DEBUG - 2025-05-11 15:28:31 --> Total execution time: 0.0733
INFO - 2025-05-11 15:28:37 --> Config Class Initialized
INFO - 2025-05-11 15:28:37 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:28:37 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:28:37 --> Utf8 Class Initialized
INFO - 2025-05-11 15:28:37 --> URI Class Initialized
INFO - 2025-05-11 15:28:37 --> Router Class Initialized
INFO - 2025-05-11 15:28:37 --> Output Class Initialized
INFO - 2025-05-11 15:28:37 --> Security Class Initialized
DEBUG - 2025-05-11 15:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:28:37 --> Input Class Initialized
INFO - 2025-05-11 15:28:37 --> Language Class Initialized
INFO - 2025-05-11 15:28:37 --> Loader Class Initialized
INFO - 2025-05-11 15:28:37 --> Helper loaded: url_helper
INFO - 2025-05-11 15:28:37 --> Helper loaded: form_helper
INFO - 2025-05-11 15:28:37 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:28:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:28:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:28:37 --> Controller Class Initialized
INFO - 2025-05-11 15:28:37 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:28:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/add.php
INFO - 2025-05-11 15:28:37 --> Final output sent to browser
DEBUG - 2025-05-11 15:28:37 --> Total execution time: 0.0740
INFO - 2025-05-11 15:28:49 --> Config Class Initialized
INFO - 2025-05-11 15:28:49 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:28:49 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:28:49 --> Utf8 Class Initialized
INFO - 2025-05-11 15:28:49 --> URI Class Initialized
INFO - 2025-05-11 15:28:49 --> Router Class Initialized
INFO - 2025-05-11 15:28:49 --> Output Class Initialized
INFO - 2025-05-11 15:28:49 --> Security Class Initialized
DEBUG - 2025-05-11 15:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:28:49 --> Input Class Initialized
INFO - 2025-05-11 15:28:49 --> Language Class Initialized
INFO - 2025-05-11 15:28:49 --> Loader Class Initialized
INFO - 2025-05-11 15:28:49 --> Helper loaded: url_helper
INFO - 2025-05-11 15:28:49 --> Helper loaded: form_helper
INFO - 2025-05-11 15:28:49 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:28:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:28:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:28:49 --> Controller Class Initialized
INFO - 2025-05-11 15:28:49 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:28:49 --> Config Class Initialized
INFO - 2025-05-11 15:28:49 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:28:49 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:28:49 --> Utf8 Class Initialized
INFO - 2025-05-11 15:28:49 --> URI Class Initialized
INFO - 2025-05-11 15:28:49 --> Router Class Initialized
INFO - 2025-05-11 15:28:49 --> Output Class Initialized
INFO - 2025-05-11 15:28:49 --> Security Class Initialized
DEBUG - 2025-05-11 15:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:28:49 --> Input Class Initialized
INFO - 2025-05-11 15:28:49 --> Language Class Initialized
INFO - 2025-05-11 15:28:49 --> Loader Class Initialized
INFO - 2025-05-11 15:28:49 --> Helper loaded: url_helper
INFO - 2025-05-11 15:28:49 --> Helper loaded: form_helper
INFO - 2025-05-11 15:28:49 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:28:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:28:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:28:49 --> Controller Class Initialized
INFO - 2025-05-11 15:28:49 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:28:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-11 15:28:49 --> Final output sent to browser
DEBUG - 2025-05-11 15:28:49 --> Total execution time: 0.0440
INFO - 2025-05-11 15:28:50 --> Config Class Initialized
INFO - 2025-05-11 15:28:50 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:28:50 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:28:50 --> Utf8 Class Initialized
INFO - 2025-05-11 15:28:50 --> URI Class Initialized
INFO - 2025-05-11 15:28:50 --> Router Class Initialized
INFO - 2025-05-11 15:28:50 --> Output Class Initialized
INFO - 2025-05-11 15:28:50 --> Security Class Initialized
DEBUG - 2025-05-11 15:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:28:50 --> Input Class Initialized
INFO - 2025-05-11 15:28:50 --> Language Class Initialized
INFO - 2025-05-11 15:28:50 --> Loader Class Initialized
INFO - 2025-05-11 15:28:50 --> Helper loaded: url_helper
INFO - 2025-05-11 15:28:50 --> Helper loaded: form_helper
INFO - 2025-05-11 15:28:50 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:28:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:28:50 --> Controller Class Initialized
INFO - 2025-05-11 15:28:50 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:28:50 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/add.php
INFO - 2025-05-11 15:28:50 --> Final output sent to browser
DEBUG - 2025-05-11 15:28:50 --> Total execution time: 0.0626
INFO - 2025-05-11 15:29:02 --> Config Class Initialized
INFO - 2025-05-11 15:29:02 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:29:02 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:29:02 --> Utf8 Class Initialized
INFO - 2025-05-11 15:29:02 --> URI Class Initialized
INFO - 2025-05-11 15:29:02 --> Router Class Initialized
INFO - 2025-05-11 15:29:02 --> Output Class Initialized
INFO - 2025-05-11 15:29:02 --> Security Class Initialized
DEBUG - 2025-05-11 15:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:29:02 --> Input Class Initialized
INFO - 2025-05-11 15:29:02 --> Language Class Initialized
INFO - 2025-05-11 15:29:02 --> Loader Class Initialized
INFO - 2025-05-11 15:29:02 --> Helper loaded: url_helper
INFO - 2025-05-11 15:29:02 --> Helper loaded: form_helper
INFO - 2025-05-11 15:29:02 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:29:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:29:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:29:02 --> Controller Class Initialized
INFO - 2025-05-11 15:29:02 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:29:02 --> Config Class Initialized
INFO - 2025-05-11 15:29:02 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:29:02 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:29:02 --> Utf8 Class Initialized
INFO - 2025-05-11 15:29:02 --> URI Class Initialized
INFO - 2025-05-11 15:29:02 --> Router Class Initialized
INFO - 2025-05-11 15:29:02 --> Output Class Initialized
INFO - 2025-05-11 15:29:02 --> Security Class Initialized
DEBUG - 2025-05-11 15:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:29:02 --> Input Class Initialized
INFO - 2025-05-11 15:29:02 --> Language Class Initialized
INFO - 2025-05-11 15:29:02 --> Loader Class Initialized
INFO - 2025-05-11 15:29:02 --> Helper loaded: url_helper
INFO - 2025-05-11 15:29:02 --> Helper loaded: form_helper
INFO - 2025-05-11 15:29:02 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:29:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:29:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:29:02 --> Controller Class Initialized
INFO - 2025-05-11 15:29:02 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:29:02 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-11 15:29:02 --> Final output sent to browser
DEBUG - 2025-05-11 15:29:02 --> Total execution time: 0.0565
INFO - 2025-05-11 15:29:06 --> Config Class Initialized
INFO - 2025-05-11 15:29:06 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:29:06 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:29:06 --> Utf8 Class Initialized
INFO - 2025-05-11 15:29:06 --> URI Class Initialized
INFO - 2025-05-11 15:29:06 --> Router Class Initialized
INFO - 2025-05-11 15:29:06 --> Output Class Initialized
INFO - 2025-05-11 15:29:06 --> Security Class Initialized
DEBUG - 2025-05-11 15:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:29:06 --> Input Class Initialized
INFO - 2025-05-11 15:29:06 --> Language Class Initialized
INFO - 2025-05-11 15:29:06 --> Loader Class Initialized
INFO - 2025-05-11 15:29:06 --> Helper loaded: url_helper
INFO - 2025-05-11 15:29:06 --> Helper loaded: form_helper
INFO - 2025-05-11 15:29:06 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:29:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:29:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:29:06 --> Controller Class Initialized
INFO - 2025-05-11 15:29:06 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:29:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/add.php
INFO - 2025-05-11 15:29:06 --> Final output sent to browser
DEBUG - 2025-05-11 15:29:06 --> Total execution time: 0.0652
INFO - 2025-05-11 15:29:18 --> Config Class Initialized
INFO - 2025-05-11 15:29:18 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:29:18 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:29:18 --> Utf8 Class Initialized
INFO - 2025-05-11 15:29:18 --> URI Class Initialized
INFO - 2025-05-11 15:29:18 --> Router Class Initialized
INFO - 2025-05-11 15:29:18 --> Output Class Initialized
INFO - 2025-05-11 15:29:18 --> Security Class Initialized
DEBUG - 2025-05-11 15:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:29:18 --> Input Class Initialized
INFO - 2025-05-11 15:29:18 --> Language Class Initialized
INFO - 2025-05-11 15:29:18 --> Loader Class Initialized
INFO - 2025-05-11 15:29:18 --> Helper loaded: url_helper
INFO - 2025-05-11 15:29:18 --> Helper loaded: form_helper
INFO - 2025-05-11 15:29:18 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:29:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:29:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:29:18 --> Controller Class Initialized
INFO - 2025-05-11 15:29:18 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:29:18 --> Config Class Initialized
INFO - 2025-05-11 15:29:18 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:29:18 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:29:18 --> Utf8 Class Initialized
INFO - 2025-05-11 15:29:18 --> URI Class Initialized
INFO - 2025-05-11 15:29:18 --> Router Class Initialized
INFO - 2025-05-11 15:29:18 --> Output Class Initialized
INFO - 2025-05-11 15:29:18 --> Security Class Initialized
DEBUG - 2025-05-11 15:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:29:18 --> Input Class Initialized
INFO - 2025-05-11 15:29:18 --> Language Class Initialized
INFO - 2025-05-11 15:29:18 --> Loader Class Initialized
INFO - 2025-05-11 15:29:18 --> Helper loaded: url_helper
INFO - 2025-05-11 15:29:18 --> Helper loaded: form_helper
INFO - 2025-05-11 15:29:18 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:29:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:29:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:29:18 --> Controller Class Initialized
INFO - 2025-05-11 15:29:18 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:29:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-11 15:29:18 --> Final output sent to browser
DEBUG - 2025-05-11 15:29:18 --> Total execution time: 0.0730
INFO - 2025-05-11 15:29:20 --> Config Class Initialized
INFO - 2025-05-11 15:29:20 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:29:20 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:29:20 --> Utf8 Class Initialized
INFO - 2025-05-11 15:29:20 --> URI Class Initialized
INFO - 2025-05-11 15:29:20 --> Router Class Initialized
INFO - 2025-05-11 15:29:20 --> Output Class Initialized
INFO - 2025-05-11 15:29:20 --> Security Class Initialized
DEBUG - 2025-05-11 15:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:29:20 --> Input Class Initialized
INFO - 2025-05-11 15:29:20 --> Language Class Initialized
INFO - 2025-05-11 15:29:20 --> Loader Class Initialized
INFO - 2025-05-11 15:29:20 --> Helper loaded: url_helper
INFO - 2025-05-11 15:29:20 --> Helper loaded: form_helper
INFO - 2025-05-11 15:29:20 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:29:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:29:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:29:20 --> Controller Class Initialized
INFO - 2025-05-11 15:29:20 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:29:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/start.php
INFO - 2025-05-11 15:29:20 --> Final output sent to browser
DEBUG - 2025-05-11 15:29:20 --> Total execution time: 0.0516
INFO - 2025-05-11 15:29:26 --> Config Class Initialized
INFO - 2025-05-11 15:29:26 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:29:26 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:29:26 --> Utf8 Class Initialized
INFO - 2025-05-11 15:29:26 --> URI Class Initialized
INFO - 2025-05-11 15:29:26 --> Router Class Initialized
INFO - 2025-05-11 15:29:26 --> Output Class Initialized
INFO - 2025-05-11 15:29:26 --> Security Class Initialized
DEBUG - 2025-05-11 15:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:29:26 --> Input Class Initialized
INFO - 2025-05-11 15:29:26 --> Language Class Initialized
INFO - 2025-05-11 15:29:26 --> Loader Class Initialized
INFO - 2025-05-11 15:29:26 --> Helper loaded: url_helper
INFO - 2025-05-11 15:29:26 --> Helper loaded: form_helper
INFO - 2025-05-11 15:29:26 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:29:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:29:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:29:26 --> Controller Class Initialized
INFO - 2025-05-11 15:29:26 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:29:26 --> Final output sent to browser
DEBUG - 2025-05-11 15:29:26 --> Total execution time: 0.0627
INFO - 2025-05-11 15:29:26 --> Config Class Initialized
INFO - 2025-05-11 15:29:26 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:29:26 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:29:26 --> Utf8 Class Initialized
INFO - 2025-05-11 15:29:26 --> URI Class Initialized
INFO - 2025-05-11 15:29:26 --> Router Class Initialized
INFO - 2025-05-11 15:29:26 --> Output Class Initialized
INFO - 2025-05-11 15:29:26 --> Security Class Initialized
DEBUG - 2025-05-11 15:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:29:26 --> Input Class Initialized
INFO - 2025-05-11 15:29:26 --> Language Class Initialized
INFO - 2025-05-11 15:29:26 --> Loader Class Initialized
INFO - 2025-05-11 15:29:26 --> Helper loaded: url_helper
INFO - 2025-05-11 15:29:26 --> Helper loaded: form_helper
INFO - 2025-05-11 15:29:26 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:29:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:29:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:29:26 --> Controller Class Initialized
INFO - 2025-05-11 15:29:26 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:29:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-11 15:29:26 --> Final output sent to browser
DEBUG - 2025-05-11 15:29:26 --> Total execution time: 0.0725
INFO - 2025-05-11 15:32:52 --> Config Class Initialized
INFO - 2025-05-11 15:32:52 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:32:52 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:32:52 --> Utf8 Class Initialized
INFO - 2025-05-11 15:32:52 --> URI Class Initialized
INFO - 2025-05-11 15:32:52 --> Router Class Initialized
INFO - 2025-05-11 15:32:52 --> Output Class Initialized
INFO - 2025-05-11 15:32:52 --> Security Class Initialized
DEBUG - 2025-05-11 15:32:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:32:52 --> Input Class Initialized
INFO - 2025-05-11 15:32:52 --> Language Class Initialized
INFO - 2025-05-11 15:32:52 --> Loader Class Initialized
INFO - 2025-05-11 15:32:52 --> Helper loaded: url_helper
INFO - 2025-05-11 15:32:52 --> Helper loaded: form_helper
INFO - 2025-05-11 15:32:52 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:32:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:32:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:32:52 --> Controller Class Initialized
INFO - 2025-05-11 15:32:52 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:32:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-11 15:32:52 --> Final output sent to browser
DEBUG - 2025-05-11 15:32:52 --> Total execution time: 0.0694
INFO - 2025-05-11 15:32:54 --> Config Class Initialized
INFO - 2025-05-11 15:32:54 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:32:54 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:32:54 --> Utf8 Class Initialized
INFO - 2025-05-11 15:32:54 --> URI Class Initialized
INFO - 2025-05-11 15:32:54 --> Router Class Initialized
INFO - 2025-05-11 15:32:54 --> Output Class Initialized
INFO - 2025-05-11 15:32:54 --> Security Class Initialized
DEBUG - 2025-05-11 15:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:32:54 --> Input Class Initialized
INFO - 2025-05-11 15:32:54 --> Language Class Initialized
INFO - 2025-05-11 15:32:54 --> Loader Class Initialized
INFO - 2025-05-11 15:32:54 --> Helper loaded: url_helper
INFO - 2025-05-11 15:32:54 --> Helper loaded: form_helper
INFO - 2025-05-11 15:32:54 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:32:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:32:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:32:54 --> Controller Class Initialized
INFO - 2025-05-11 15:32:54 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:32:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/add.php
INFO - 2025-05-11 15:32:54 --> Final output sent to browser
DEBUG - 2025-05-11 15:32:54 --> Total execution time: 0.0620
INFO - 2025-05-11 15:40:34 --> Config Class Initialized
INFO - 2025-05-11 15:40:34 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:40:34 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:40:34 --> Utf8 Class Initialized
INFO - 2025-05-11 15:40:34 --> URI Class Initialized
INFO - 2025-05-11 15:40:34 --> Router Class Initialized
INFO - 2025-05-11 15:40:34 --> Output Class Initialized
INFO - 2025-05-11 15:40:34 --> Security Class Initialized
DEBUG - 2025-05-11 15:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:40:34 --> Input Class Initialized
INFO - 2025-05-11 15:40:34 --> Language Class Initialized
INFO - 2025-05-11 15:40:34 --> Loader Class Initialized
INFO - 2025-05-11 15:40:34 --> Helper loaded: url_helper
INFO - 2025-05-11 15:40:34 --> Helper loaded: form_helper
INFO - 2025-05-11 15:40:34 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:40:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:40:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:40:34 --> Controller Class Initialized
INFO - 2025-05-11 15:40:34 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:40:34 --> Config Class Initialized
INFO - 2025-05-11 15:40:34 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:40:34 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:40:34 --> Utf8 Class Initialized
INFO - 2025-05-11 15:40:34 --> URI Class Initialized
INFO - 2025-05-11 15:40:34 --> Router Class Initialized
INFO - 2025-05-11 15:40:34 --> Output Class Initialized
INFO - 2025-05-11 15:40:34 --> Security Class Initialized
DEBUG - 2025-05-11 15:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:40:34 --> Input Class Initialized
INFO - 2025-05-11 15:40:34 --> Language Class Initialized
INFO - 2025-05-11 15:40:34 --> Loader Class Initialized
INFO - 2025-05-11 15:40:34 --> Helper loaded: url_helper
INFO - 2025-05-11 15:40:34 --> Helper loaded: form_helper
INFO - 2025-05-11 15:40:34 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:40:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:40:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:40:34 --> Controller Class Initialized
INFO - 2025-05-11 15:40:34 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:40:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-11 15:40:34 --> Final output sent to browser
DEBUG - 2025-05-11 15:40:34 --> Total execution time: 0.0568
INFO - 2025-05-11 15:40:36 --> Config Class Initialized
INFO - 2025-05-11 15:40:36 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:40:36 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:40:36 --> Utf8 Class Initialized
INFO - 2025-05-11 15:40:36 --> URI Class Initialized
INFO - 2025-05-11 15:40:36 --> Router Class Initialized
INFO - 2025-05-11 15:40:36 --> Output Class Initialized
INFO - 2025-05-11 15:40:36 --> Security Class Initialized
DEBUG - 2025-05-11 15:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:40:36 --> Input Class Initialized
INFO - 2025-05-11 15:40:36 --> Language Class Initialized
INFO - 2025-05-11 15:40:36 --> Loader Class Initialized
INFO - 2025-05-11 15:40:36 --> Helper loaded: url_helper
INFO - 2025-05-11 15:40:36 --> Helper loaded: form_helper
INFO - 2025-05-11 15:40:36 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:40:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:40:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:40:36 --> Controller Class Initialized
INFO - 2025-05-11 15:40:36 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:40:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/add.php
INFO - 2025-05-11 15:40:36 --> Final output sent to browser
DEBUG - 2025-05-11 15:40:36 --> Total execution time: 0.0631
INFO - 2025-05-11 15:40:49 --> Config Class Initialized
INFO - 2025-05-11 15:40:49 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:40:49 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:40:49 --> Utf8 Class Initialized
INFO - 2025-05-11 15:40:49 --> URI Class Initialized
INFO - 2025-05-11 15:40:49 --> Router Class Initialized
INFO - 2025-05-11 15:40:49 --> Output Class Initialized
INFO - 2025-05-11 15:40:49 --> Security Class Initialized
DEBUG - 2025-05-11 15:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:40:49 --> Input Class Initialized
INFO - 2025-05-11 15:40:49 --> Language Class Initialized
INFO - 2025-05-11 15:40:49 --> Loader Class Initialized
INFO - 2025-05-11 15:40:49 --> Helper loaded: url_helper
INFO - 2025-05-11 15:40:49 --> Helper loaded: form_helper
INFO - 2025-05-11 15:40:49 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:40:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:40:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:40:49 --> Controller Class Initialized
INFO - 2025-05-11 15:40:49 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:40:49 --> Config Class Initialized
INFO - 2025-05-11 15:40:49 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:40:49 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:40:49 --> Utf8 Class Initialized
INFO - 2025-05-11 15:40:49 --> URI Class Initialized
INFO - 2025-05-11 15:40:49 --> Router Class Initialized
INFO - 2025-05-11 15:40:49 --> Output Class Initialized
INFO - 2025-05-11 15:40:49 --> Security Class Initialized
DEBUG - 2025-05-11 15:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:40:49 --> Input Class Initialized
INFO - 2025-05-11 15:40:49 --> Language Class Initialized
INFO - 2025-05-11 15:40:49 --> Loader Class Initialized
INFO - 2025-05-11 15:40:49 --> Helper loaded: url_helper
INFO - 2025-05-11 15:40:49 --> Helper loaded: form_helper
INFO - 2025-05-11 15:40:49 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:40:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:40:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:40:49 --> Controller Class Initialized
INFO - 2025-05-11 15:40:49 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:40:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-11 15:40:49 --> Final output sent to browser
DEBUG - 2025-05-11 15:40:49 --> Total execution time: 0.0454
INFO - 2025-05-11 15:40:50 --> Config Class Initialized
INFO - 2025-05-11 15:40:50 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:40:50 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:40:50 --> Utf8 Class Initialized
INFO - 2025-05-11 15:40:50 --> URI Class Initialized
INFO - 2025-05-11 15:40:50 --> Router Class Initialized
INFO - 2025-05-11 15:40:50 --> Output Class Initialized
INFO - 2025-05-11 15:40:50 --> Security Class Initialized
DEBUG - 2025-05-11 15:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:40:50 --> Input Class Initialized
INFO - 2025-05-11 15:40:50 --> Language Class Initialized
INFO - 2025-05-11 15:40:51 --> Loader Class Initialized
INFO - 2025-05-11 15:40:51 --> Helper loaded: url_helper
INFO - 2025-05-11 15:40:51 --> Helper loaded: form_helper
INFO - 2025-05-11 15:40:51 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:40:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:40:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:40:51 --> Controller Class Initialized
INFO - 2025-05-11 15:40:51 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:40:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/add.php
INFO - 2025-05-11 15:40:51 --> Final output sent to browser
DEBUG - 2025-05-11 15:40:51 --> Total execution time: 0.0670
INFO - 2025-05-11 15:41:06 --> Config Class Initialized
INFO - 2025-05-11 15:41:06 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:41:06 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:41:06 --> Utf8 Class Initialized
INFO - 2025-05-11 15:41:06 --> URI Class Initialized
INFO - 2025-05-11 15:41:06 --> Router Class Initialized
INFO - 2025-05-11 15:41:06 --> Output Class Initialized
INFO - 2025-05-11 15:41:06 --> Security Class Initialized
DEBUG - 2025-05-11 15:41:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:41:06 --> Input Class Initialized
INFO - 2025-05-11 15:41:06 --> Language Class Initialized
INFO - 2025-05-11 15:41:06 --> Loader Class Initialized
INFO - 2025-05-11 15:41:06 --> Helper loaded: url_helper
INFO - 2025-05-11 15:41:06 --> Helper loaded: form_helper
INFO - 2025-05-11 15:41:06 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:41:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:41:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:41:06 --> Controller Class Initialized
INFO - 2025-05-11 15:41:06 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:41:06 --> Config Class Initialized
INFO - 2025-05-11 15:41:06 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:41:06 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:41:06 --> Utf8 Class Initialized
INFO - 2025-05-11 15:41:06 --> URI Class Initialized
INFO - 2025-05-11 15:41:06 --> Router Class Initialized
INFO - 2025-05-11 15:41:06 --> Output Class Initialized
INFO - 2025-05-11 15:41:06 --> Security Class Initialized
DEBUG - 2025-05-11 15:41:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:41:06 --> Input Class Initialized
INFO - 2025-05-11 15:41:06 --> Language Class Initialized
INFO - 2025-05-11 15:41:06 --> Loader Class Initialized
INFO - 2025-05-11 15:41:06 --> Helper loaded: url_helper
INFO - 2025-05-11 15:41:06 --> Helper loaded: form_helper
INFO - 2025-05-11 15:41:06 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:41:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:41:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:41:06 --> Controller Class Initialized
INFO - 2025-05-11 15:41:06 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:41:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-11 15:41:06 --> Final output sent to browser
DEBUG - 2025-05-11 15:41:06 --> Total execution time: 0.0629
INFO - 2025-05-11 15:41:08 --> Config Class Initialized
INFO - 2025-05-11 15:41:08 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:41:08 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:41:08 --> Utf8 Class Initialized
INFO - 2025-05-11 15:41:08 --> URI Class Initialized
INFO - 2025-05-11 15:41:08 --> Router Class Initialized
INFO - 2025-05-11 15:41:08 --> Output Class Initialized
INFO - 2025-05-11 15:41:08 --> Security Class Initialized
DEBUG - 2025-05-11 15:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:41:08 --> Input Class Initialized
INFO - 2025-05-11 15:41:08 --> Language Class Initialized
INFO - 2025-05-11 15:41:08 --> Loader Class Initialized
INFO - 2025-05-11 15:41:08 --> Helper loaded: url_helper
INFO - 2025-05-11 15:41:08 --> Helper loaded: form_helper
INFO - 2025-05-11 15:41:08 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:41:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:41:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:41:08 --> Controller Class Initialized
INFO - 2025-05-11 15:41:08 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:41:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/add.php
INFO - 2025-05-11 15:41:08 --> Final output sent to browser
DEBUG - 2025-05-11 15:41:08 --> Total execution time: 0.0441
INFO - 2025-05-11 15:41:21 --> Config Class Initialized
INFO - 2025-05-11 15:41:21 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:41:21 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:41:21 --> Utf8 Class Initialized
INFO - 2025-05-11 15:41:21 --> URI Class Initialized
INFO - 2025-05-11 15:41:21 --> Router Class Initialized
INFO - 2025-05-11 15:41:21 --> Output Class Initialized
INFO - 2025-05-11 15:41:21 --> Security Class Initialized
DEBUG - 2025-05-11 15:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:41:21 --> Input Class Initialized
INFO - 2025-05-11 15:41:21 --> Language Class Initialized
INFO - 2025-05-11 15:41:21 --> Loader Class Initialized
INFO - 2025-05-11 15:41:22 --> Helper loaded: url_helper
INFO - 2025-05-11 15:41:22 --> Helper loaded: form_helper
INFO - 2025-05-11 15:41:22 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:41:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:41:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:41:22 --> Controller Class Initialized
INFO - 2025-05-11 15:41:22 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:41:22 --> Config Class Initialized
INFO - 2025-05-11 15:41:22 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:41:22 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:41:22 --> Utf8 Class Initialized
INFO - 2025-05-11 15:41:22 --> URI Class Initialized
INFO - 2025-05-11 15:41:22 --> Router Class Initialized
INFO - 2025-05-11 15:41:22 --> Output Class Initialized
INFO - 2025-05-11 15:41:22 --> Security Class Initialized
DEBUG - 2025-05-11 15:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:41:22 --> Input Class Initialized
INFO - 2025-05-11 15:41:22 --> Language Class Initialized
INFO - 2025-05-11 15:41:22 --> Loader Class Initialized
INFO - 2025-05-11 15:41:22 --> Helper loaded: url_helper
INFO - 2025-05-11 15:41:22 --> Helper loaded: form_helper
INFO - 2025-05-11 15:41:22 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:41:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:41:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:41:22 --> Controller Class Initialized
INFO - 2025-05-11 15:41:22 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:41:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-11 15:41:22 --> Final output sent to browser
DEBUG - 2025-05-11 15:41:22 --> Total execution time: 0.0707
INFO - 2025-05-11 15:41:24 --> Config Class Initialized
INFO - 2025-05-11 15:41:24 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:41:24 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:41:24 --> Utf8 Class Initialized
INFO - 2025-05-11 15:41:24 --> URI Class Initialized
INFO - 2025-05-11 15:41:24 --> Router Class Initialized
INFO - 2025-05-11 15:41:24 --> Output Class Initialized
INFO - 2025-05-11 15:41:24 --> Security Class Initialized
DEBUG - 2025-05-11 15:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:41:24 --> Input Class Initialized
INFO - 2025-05-11 15:41:24 --> Language Class Initialized
INFO - 2025-05-11 15:41:24 --> Loader Class Initialized
INFO - 2025-05-11 15:41:24 --> Helper loaded: url_helper
INFO - 2025-05-11 15:41:24 --> Helper loaded: form_helper
INFO - 2025-05-11 15:41:25 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:41:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:41:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:41:25 --> Controller Class Initialized
INFO - 2025-05-11 15:41:25 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:41:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/start.php
INFO - 2025-05-11 15:41:25 --> Final output sent to browser
DEBUG - 2025-05-11 15:41:25 --> Total execution time: 0.0494
INFO - 2025-05-11 15:41:27 --> Config Class Initialized
INFO - 2025-05-11 15:41:27 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:41:27 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:41:27 --> Utf8 Class Initialized
INFO - 2025-05-11 15:41:27 --> URI Class Initialized
INFO - 2025-05-11 15:41:27 --> Router Class Initialized
INFO - 2025-05-11 15:41:27 --> Output Class Initialized
INFO - 2025-05-11 15:41:27 --> Security Class Initialized
DEBUG - 2025-05-11 15:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:41:27 --> Input Class Initialized
INFO - 2025-05-11 15:41:27 --> Language Class Initialized
INFO - 2025-05-11 15:41:27 --> Loader Class Initialized
INFO - 2025-05-11 15:41:27 --> Helper loaded: url_helper
INFO - 2025-05-11 15:41:27 --> Helper loaded: form_helper
INFO - 2025-05-11 15:41:27 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:41:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:41:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:41:27 --> Controller Class Initialized
INFO - 2025-05-11 15:41:27 --> Model "Workout_model" initialized
ERROR - 2025-05-11 15:41:27 --> Query error: Unknown column 'schedule_id' in 'where clause' - Invalid query: DELETE FROM `workout_schedules`
WHERE `schedule_id` = '14'
INFO - 2025-05-11 15:41:27 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-11 15:41:37 --> Config Class Initialized
INFO - 2025-05-11 15:41:37 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:41:37 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:41:37 --> Utf8 Class Initialized
INFO - 2025-05-11 15:41:37 --> URI Class Initialized
INFO - 2025-05-11 15:41:38 --> Router Class Initialized
INFO - 2025-05-11 15:41:38 --> Output Class Initialized
INFO - 2025-05-11 15:41:38 --> Security Class Initialized
DEBUG - 2025-05-11 15:41:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:41:38 --> Input Class Initialized
INFO - 2025-05-11 15:41:38 --> Language Class Initialized
INFO - 2025-05-11 15:41:38 --> Loader Class Initialized
INFO - 2025-05-11 15:41:38 --> Helper loaded: url_helper
INFO - 2025-05-11 15:41:38 --> Helper loaded: form_helper
INFO - 2025-05-11 15:41:38 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:41:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:41:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:41:38 --> Controller Class Initialized
INFO - 2025-05-11 15:41:38 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:41:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-11 15:41:38 --> Final output sent to browser
DEBUG - 2025-05-11 15:41:38 --> Total execution time: 0.0678
INFO - 2025-05-11 15:45:26 --> Config Class Initialized
INFO - 2025-05-11 15:45:26 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:45:27 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:45:27 --> Utf8 Class Initialized
INFO - 2025-05-11 15:45:27 --> URI Class Initialized
INFO - 2025-05-11 15:45:27 --> Router Class Initialized
INFO - 2025-05-11 15:45:27 --> Output Class Initialized
INFO - 2025-05-11 15:45:27 --> Security Class Initialized
DEBUG - 2025-05-11 15:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:45:27 --> Input Class Initialized
INFO - 2025-05-11 15:45:27 --> Language Class Initialized
INFO - 2025-05-11 15:45:27 --> Loader Class Initialized
INFO - 2025-05-11 15:45:27 --> Helper loaded: url_helper
INFO - 2025-05-11 15:45:27 --> Helper loaded: form_helper
INFO - 2025-05-11 15:45:27 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:45:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:45:27 --> Controller Class Initialized
INFO - 2025-05-11 15:45:27 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:45:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-11 15:45:27 --> Final output sent to browser
DEBUG - 2025-05-11 15:45:27 --> Total execution time: 0.0571
INFO - 2025-05-11 15:45:28 --> Config Class Initialized
INFO - 2025-05-11 15:45:28 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:45:28 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:45:28 --> Utf8 Class Initialized
INFO - 2025-05-11 15:45:28 --> URI Class Initialized
INFO - 2025-05-11 15:45:28 --> Router Class Initialized
INFO - 2025-05-11 15:45:28 --> Output Class Initialized
INFO - 2025-05-11 15:45:28 --> Security Class Initialized
DEBUG - 2025-05-11 15:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:45:28 --> Input Class Initialized
INFO - 2025-05-11 15:45:28 --> Language Class Initialized
INFO - 2025-05-11 15:45:28 --> Loader Class Initialized
INFO - 2025-05-11 15:45:28 --> Helper loaded: url_helper
INFO - 2025-05-11 15:45:28 --> Helper loaded: form_helper
INFO - 2025-05-11 15:45:28 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:45:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:45:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:45:28 --> Controller Class Initialized
INFO - 2025-05-11 15:45:28 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:45:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/start.php
INFO - 2025-05-11 15:45:28 --> Final output sent to browser
DEBUG - 2025-05-11 15:45:28 --> Total execution time: 0.0496
INFO - 2025-05-11 15:45:31 --> Config Class Initialized
INFO - 2025-05-11 15:45:31 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:45:31 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:45:31 --> Utf8 Class Initialized
INFO - 2025-05-11 15:45:31 --> URI Class Initialized
INFO - 2025-05-11 15:45:31 --> Router Class Initialized
INFO - 2025-05-11 15:45:31 --> Output Class Initialized
INFO - 2025-05-11 15:45:31 --> Security Class Initialized
DEBUG - 2025-05-11 15:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:45:31 --> Input Class Initialized
INFO - 2025-05-11 15:45:31 --> Language Class Initialized
INFO - 2025-05-11 15:45:31 --> Loader Class Initialized
INFO - 2025-05-11 15:45:31 --> Helper loaded: url_helper
INFO - 2025-05-11 15:45:31 --> Helper loaded: form_helper
INFO - 2025-05-11 15:45:31 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:45:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:45:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:45:31 --> Controller Class Initialized
INFO - 2025-05-11 15:45:31 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:45:31 --> Final output sent to browser
DEBUG - 2025-05-11 15:45:31 --> Total execution time: 0.0454
INFO - 2025-05-11 15:45:31 --> Config Class Initialized
INFO - 2025-05-11 15:45:31 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:45:31 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:45:31 --> Utf8 Class Initialized
INFO - 2025-05-11 15:45:31 --> URI Class Initialized
INFO - 2025-05-11 15:45:31 --> Router Class Initialized
INFO - 2025-05-11 15:45:31 --> Output Class Initialized
INFO - 2025-05-11 15:45:31 --> Security Class Initialized
DEBUG - 2025-05-11 15:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:45:31 --> Input Class Initialized
INFO - 2025-05-11 15:45:31 --> Language Class Initialized
INFO - 2025-05-11 15:45:31 --> Loader Class Initialized
INFO - 2025-05-11 15:45:31 --> Helper loaded: url_helper
INFO - 2025-05-11 15:45:31 --> Helper loaded: form_helper
INFO - 2025-05-11 15:45:31 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:45:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:45:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:45:31 --> Controller Class Initialized
INFO - 2025-05-11 15:45:31 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:45:31 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-11 15:45:31 --> Final output sent to browser
DEBUG - 2025-05-11 15:45:31 --> Total execution time: 0.0464
INFO - 2025-05-11 15:49:10 --> Config Class Initialized
INFO - 2025-05-11 15:49:10 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:49:10 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:49:10 --> Utf8 Class Initialized
INFO - 2025-05-11 15:49:10 --> URI Class Initialized
INFO - 2025-05-11 15:49:10 --> Router Class Initialized
INFO - 2025-05-11 15:49:10 --> Output Class Initialized
INFO - 2025-05-11 15:49:10 --> Security Class Initialized
DEBUG - 2025-05-11 15:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:49:10 --> Input Class Initialized
INFO - 2025-05-11 15:49:10 --> Language Class Initialized
INFO - 2025-05-11 15:49:10 --> Loader Class Initialized
INFO - 2025-05-11 15:49:10 --> Helper loaded: url_helper
INFO - 2025-05-11 15:49:10 --> Helper loaded: form_helper
INFO - 2025-05-11 15:49:10 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:49:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:49:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:49:10 --> Controller Class Initialized
INFO - 2025-05-11 15:49:10 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:49:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-11 15:49:10 --> Final output sent to browser
DEBUG - 2025-05-11 15:49:10 --> Total execution time: 0.0639
INFO - 2025-05-11 15:49:11 --> Config Class Initialized
INFO - 2025-05-11 15:49:11 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:49:11 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:49:11 --> Utf8 Class Initialized
INFO - 2025-05-11 15:49:11 --> URI Class Initialized
INFO - 2025-05-11 15:49:11 --> Router Class Initialized
INFO - 2025-05-11 15:49:11 --> Output Class Initialized
INFO - 2025-05-11 15:49:11 --> Security Class Initialized
DEBUG - 2025-05-11 15:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:49:11 --> Input Class Initialized
INFO - 2025-05-11 15:49:11 --> Language Class Initialized
INFO - 2025-05-11 15:49:11 --> Loader Class Initialized
INFO - 2025-05-11 15:49:11 --> Helper loaded: url_helper
INFO - 2025-05-11 15:49:11 --> Helper loaded: form_helper
INFO - 2025-05-11 15:49:11 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:49:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:49:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:49:11 --> Controller Class Initialized
INFO - 2025-05-11 15:49:11 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:49:11 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-11 15:49:11 --> Final output sent to browser
DEBUG - 2025-05-11 15:49:11 --> Total execution time: 0.0684
INFO - 2025-05-11 15:49:12 --> Config Class Initialized
INFO - 2025-05-11 15:49:12 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:49:12 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:49:12 --> Utf8 Class Initialized
INFO - 2025-05-11 15:49:12 --> URI Class Initialized
INFO - 2025-05-11 15:49:12 --> Router Class Initialized
INFO - 2025-05-11 15:49:12 --> Output Class Initialized
INFO - 2025-05-11 15:49:12 --> Security Class Initialized
DEBUG - 2025-05-11 15:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:49:12 --> Input Class Initialized
INFO - 2025-05-11 15:49:12 --> Language Class Initialized
INFO - 2025-05-11 15:49:12 --> Loader Class Initialized
INFO - 2025-05-11 15:49:12 --> Helper loaded: url_helper
INFO - 2025-05-11 15:49:12 --> Helper loaded: form_helper
INFO - 2025-05-11 15:49:12 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:49:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:49:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:49:12 --> Controller Class Initialized
INFO - 2025-05-11 15:49:12 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:49:12 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/add.php
INFO - 2025-05-11 15:49:12 --> Final output sent to browser
DEBUG - 2025-05-11 15:49:12 --> Total execution time: 0.0436
INFO - 2025-05-11 15:49:19 --> Config Class Initialized
INFO - 2025-05-11 15:49:19 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:49:19 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:49:19 --> Utf8 Class Initialized
INFO - 2025-05-11 15:49:19 --> URI Class Initialized
INFO - 2025-05-11 15:49:19 --> Router Class Initialized
INFO - 2025-05-11 15:49:19 --> Output Class Initialized
INFO - 2025-05-11 15:49:19 --> Security Class Initialized
DEBUG - 2025-05-11 15:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:49:19 --> Input Class Initialized
INFO - 2025-05-11 15:49:19 --> Language Class Initialized
INFO - 2025-05-11 15:49:19 --> Loader Class Initialized
INFO - 2025-05-11 15:49:19 --> Helper loaded: url_helper
INFO - 2025-05-11 15:49:19 --> Helper loaded: form_helper
INFO - 2025-05-11 15:49:19 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:49:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:49:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:49:19 --> Controller Class Initialized
INFO - 2025-05-11 15:49:19 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:49:19 --> Config Class Initialized
INFO - 2025-05-11 15:49:19 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:49:19 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:49:19 --> Utf8 Class Initialized
INFO - 2025-05-11 15:49:19 --> URI Class Initialized
INFO - 2025-05-11 15:49:19 --> Router Class Initialized
INFO - 2025-05-11 15:49:19 --> Output Class Initialized
INFO - 2025-05-11 15:49:19 --> Security Class Initialized
DEBUG - 2025-05-11 15:49:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:49:19 --> Input Class Initialized
INFO - 2025-05-11 15:49:19 --> Language Class Initialized
INFO - 2025-05-11 15:49:19 --> Loader Class Initialized
INFO - 2025-05-11 15:49:19 --> Helper loaded: url_helper
INFO - 2025-05-11 15:49:19 --> Helper loaded: form_helper
INFO - 2025-05-11 15:49:19 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:49:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:49:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:49:19 --> Controller Class Initialized
INFO - 2025-05-11 15:49:19 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:49:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-11 15:49:19 --> Final output sent to browser
DEBUG - 2025-05-11 15:49:19 --> Total execution time: 0.0448
INFO - 2025-05-11 15:49:21 --> Config Class Initialized
INFO - 2025-05-11 15:49:21 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:49:21 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:49:21 --> Utf8 Class Initialized
INFO - 2025-05-11 15:49:21 --> URI Class Initialized
INFO - 2025-05-11 15:49:21 --> Router Class Initialized
INFO - 2025-05-11 15:49:21 --> Output Class Initialized
INFO - 2025-05-11 15:49:21 --> Security Class Initialized
DEBUG - 2025-05-11 15:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:49:21 --> Input Class Initialized
INFO - 2025-05-11 15:49:21 --> Language Class Initialized
INFO - 2025-05-11 15:49:21 --> Loader Class Initialized
INFO - 2025-05-11 15:49:21 --> Helper loaded: url_helper
INFO - 2025-05-11 15:49:21 --> Helper loaded: form_helper
INFO - 2025-05-11 15:49:21 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:49:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:49:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:49:21 --> Controller Class Initialized
INFO - 2025-05-11 15:49:21 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:49:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/add.php
INFO - 2025-05-11 15:49:21 --> Final output sent to browser
DEBUG - 2025-05-11 15:49:21 --> Total execution time: 0.0643
INFO - 2025-05-11 15:49:32 --> Config Class Initialized
INFO - 2025-05-11 15:49:32 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:49:32 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:49:32 --> Utf8 Class Initialized
INFO - 2025-05-11 15:49:32 --> URI Class Initialized
INFO - 2025-05-11 15:49:32 --> Router Class Initialized
INFO - 2025-05-11 15:49:32 --> Output Class Initialized
INFO - 2025-05-11 15:49:32 --> Security Class Initialized
DEBUG - 2025-05-11 15:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:49:32 --> Input Class Initialized
INFO - 2025-05-11 15:49:32 --> Language Class Initialized
INFO - 2025-05-11 15:49:32 --> Loader Class Initialized
INFO - 2025-05-11 15:49:32 --> Helper loaded: url_helper
INFO - 2025-05-11 15:49:32 --> Helper loaded: form_helper
INFO - 2025-05-11 15:49:32 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:49:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:49:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:49:32 --> Controller Class Initialized
INFO - 2025-05-11 15:49:32 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:49:32 --> Config Class Initialized
INFO - 2025-05-11 15:49:32 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:49:32 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:49:32 --> Utf8 Class Initialized
INFO - 2025-05-11 15:49:32 --> URI Class Initialized
INFO - 2025-05-11 15:49:32 --> Router Class Initialized
INFO - 2025-05-11 15:49:32 --> Output Class Initialized
INFO - 2025-05-11 15:49:32 --> Security Class Initialized
DEBUG - 2025-05-11 15:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:49:32 --> Input Class Initialized
INFO - 2025-05-11 15:49:32 --> Language Class Initialized
INFO - 2025-05-11 15:49:32 --> Loader Class Initialized
INFO - 2025-05-11 15:49:32 --> Helper loaded: url_helper
INFO - 2025-05-11 15:49:32 --> Helper loaded: form_helper
INFO - 2025-05-11 15:49:32 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:49:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:49:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:49:32 --> Controller Class Initialized
INFO - 2025-05-11 15:49:32 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:49:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-11 15:49:32 --> Final output sent to browser
DEBUG - 2025-05-11 15:49:32 --> Total execution time: 0.0547
INFO - 2025-05-11 15:49:34 --> Config Class Initialized
INFO - 2025-05-11 15:49:34 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:49:34 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:49:34 --> Utf8 Class Initialized
INFO - 2025-05-11 15:49:34 --> URI Class Initialized
INFO - 2025-05-11 15:49:34 --> Router Class Initialized
INFO - 2025-05-11 15:49:34 --> Output Class Initialized
INFO - 2025-05-11 15:49:34 --> Security Class Initialized
DEBUG - 2025-05-11 15:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:49:34 --> Input Class Initialized
INFO - 2025-05-11 15:49:34 --> Language Class Initialized
INFO - 2025-05-11 15:49:34 --> Loader Class Initialized
INFO - 2025-05-11 15:49:34 --> Helper loaded: url_helper
INFO - 2025-05-11 15:49:34 --> Helper loaded: form_helper
INFO - 2025-05-11 15:49:34 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:49:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:49:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:49:34 --> Controller Class Initialized
INFO - 2025-05-11 15:49:34 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:49:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/start.php
INFO - 2025-05-11 15:49:34 --> Final output sent to browser
DEBUG - 2025-05-11 15:49:34 --> Total execution time: 0.0714
INFO - 2025-05-11 15:49:37 --> Config Class Initialized
INFO - 2025-05-11 15:49:37 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:49:37 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:49:37 --> Utf8 Class Initialized
INFO - 2025-05-11 15:49:37 --> URI Class Initialized
INFO - 2025-05-11 15:49:37 --> Router Class Initialized
INFO - 2025-05-11 15:49:37 --> Output Class Initialized
INFO - 2025-05-11 15:49:37 --> Security Class Initialized
DEBUG - 2025-05-11 15:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:49:37 --> Input Class Initialized
INFO - 2025-05-11 15:49:37 --> Language Class Initialized
INFO - 2025-05-11 15:49:37 --> Loader Class Initialized
INFO - 2025-05-11 15:49:37 --> Helper loaded: url_helper
INFO - 2025-05-11 15:49:37 --> Helper loaded: form_helper
INFO - 2025-05-11 15:49:37 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:49:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:49:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:49:37 --> Controller Class Initialized
INFO - 2025-05-11 15:49:37 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:49:37 --> Final output sent to browser
DEBUG - 2025-05-11 15:49:37 --> Total execution time: 0.0491
INFO - 2025-05-11 15:49:37 --> Config Class Initialized
INFO - 2025-05-11 15:49:37 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:49:37 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:49:37 --> Utf8 Class Initialized
INFO - 2025-05-11 15:49:37 --> URI Class Initialized
INFO - 2025-05-11 15:49:37 --> Router Class Initialized
INFO - 2025-05-11 15:49:37 --> Output Class Initialized
INFO - 2025-05-11 15:49:37 --> Security Class Initialized
DEBUG - 2025-05-11 15:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:49:37 --> Input Class Initialized
INFO - 2025-05-11 15:49:37 --> Language Class Initialized
INFO - 2025-05-11 15:49:37 --> Loader Class Initialized
INFO - 2025-05-11 15:49:37 --> Helper loaded: url_helper
INFO - 2025-05-11 15:49:37 --> Helper loaded: form_helper
INFO - 2025-05-11 15:49:37 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:49:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:49:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:49:37 --> Controller Class Initialized
INFO - 2025-05-11 15:49:37 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:49:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-11 15:49:37 --> Final output sent to browser
DEBUG - 2025-05-11 15:49:37 --> Total execution time: 0.0552
INFO - 2025-05-11 15:49:48 --> Config Class Initialized
INFO - 2025-05-11 15:49:48 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:49:48 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:49:48 --> Utf8 Class Initialized
INFO - 2025-05-11 15:49:48 --> URI Class Initialized
INFO - 2025-05-11 15:49:48 --> Router Class Initialized
INFO - 2025-05-11 15:49:48 --> Output Class Initialized
INFO - 2025-05-11 15:49:48 --> Security Class Initialized
DEBUG - 2025-05-11 15:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:49:48 --> Input Class Initialized
INFO - 2025-05-11 15:49:48 --> Language Class Initialized
INFO - 2025-05-11 15:49:48 --> Loader Class Initialized
INFO - 2025-05-11 15:49:48 --> Helper loaded: url_helper
INFO - 2025-05-11 15:49:48 --> Helper loaded: form_helper
INFO - 2025-05-11 15:49:48 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:49:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:49:48 --> Controller Class Initialized
INFO - 2025-05-11 15:49:48 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:49:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/start.php
INFO - 2025-05-11 15:49:48 --> Final output sent to browser
DEBUG - 2025-05-11 15:49:48 --> Total execution time: 0.0514
INFO - 2025-05-11 15:49:52 --> Config Class Initialized
INFO - 2025-05-11 15:49:52 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:49:52 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:49:52 --> Utf8 Class Initialized
INFO - 2025-05-11 15:49:52 --> URI Class Initialized
INFO - 2025-05-11 15:49:52 --> Router Class Initialized
INFO - 2025-05-11 15:49:52 --> Output Class Initialized
INFO - 2025-05-11 15:49:52 --> Security Class Initialized
DEBUG - 2025-05-11 15:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:49:52 --> Input Class Initialized
INFO - 2025-05-11 15:49:52 --> Language Class Initialized
INFO - 2025-05-11 15:49:52 --> Loader Class Initialized
INFO - 2025-05-11 15:49:52 --> Helper loaded: url_helper
INFO - 2025-05-11 15:49:52 --> Helper loaded: form_helper
INFO - 2025-05-11 15:49:52 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:49:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:49:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:49:52 --> Controller Class Initialized
INFO - 2025-05-11 15:49:52 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:49:52 --> Final output sent to browser
DEBUG - 2025-05-11 15:49:52 --> Total execution time: 0.0625
INFO - 2025-05-11 15:49:52 --> Config Class Initialized
INFO - 2025-05-11 15:49:52 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:49:52 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:49:52 --> Utf8 Class Initialized
INFO - 2025-05-11 15:49:52 --> URI Class Initialized
INFO - 2025-05-11 15:49:52 --> Router Class Initialized
INFO - 2025-05-11 15:49:52 --> Output Class Initialized
INFO - 2025-05-11 15:49:52 --> Security Class Initialized
DEBUG - 2025-05-11 15:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:49:52 --> Input Class Initialized
INFO - 2025-05-11 15:49:52 --> Language Class Initialized
INFO - 2025-05-11 15:49:52 --> Loader Class Initialized
INFO - 2025-05-11 15:49:52 --> Helper loaded: url_helper
INFO - 2025-05-11 15:49:52 --> Helper loaded: form_helper
INFO - 2025-05-11 15:49:52 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:49:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:49:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:49:52 --> Controller Class Initialized
INFO - 2025-05-11 15:49:52 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:49:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-11 15:49:52 --> Final output sent to browser
DEBUG - 2025-05-11 15:49:52 --> Total execution time: 0.0485
INFO - 2025-05-11 15:51:33 --> Config Class Initialized
INFO - 2025-05-11 15:51:33 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:51:33 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:51:33 --> Utf8 Class Initialized
INFO - 2025-05-11 15:51:33 --> URI Class Initialized
INFO - 2025-05-11 15:51:33 --> Router Class Initialized
INFO - 2025-05-11 15:51:33 --> Output Class Initialized
INFO - 2025-05-11 15:51:33 --> Security Class Initialized
DEBUG - 2025-05-11 15:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:51:33 --> Input Class Initialized
INFO - 2025-05-11 15:51:33 --> Language Class Initialized
INFO - 2025-05-11 15:51:33 --> Loader Class Initialized
INFO - 2025-05-11 15:51:33 --> Helper loaded: url_helper
INFO - 2025-05-11 15:51:33 --> Helper loaded: form_helper
INFO - 2025-05-11 15:51:33 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:51:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:51:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:51:33 --> Controller Class Initialized
INFO - 2025-05-11 15:51:33 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:51:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-11 15:51:33 --> Final output sent to browser
DEBUG - 2025-05-11 15:51:33 --> Total execution time: 0.0496
INFO - 2025-05-11 15:51:42 --> Config Class Initialized
INFO - 2025-05-11 15:51:42 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:51:42 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:51:42 --> Utf8 Class Initialized
INFO - 2025-05-11 15:51:42 --> URI Class Initialized
INFO - 2025-05-11 15:51:42 --> Router Class Initialized
INFO - 2025-05-11 15:51:42 --> Output Class Initialized
INFO - 2025-05-11 15:51:42 --> Security Class Initialized
DEBUG - 2025-05-11 15:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:51:42 --> Input Class Initialized
INFO - 2025-05-11 15:51:42 --> Language Class Initialized
INFO - 2025-05-11 15:51:42 --> Loader Class Initialized
INFO - 2025-05-11 15:51:42 --> Helper loaded: url_helper
INFO - 2025-05-11 15:51:42 --> Helper loaded: form_helper
INFO - 2025-05-11 15:51:42 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:51:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:51:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:51:42 --> Controller Class Initialized
INFO - 2025-05-11 15:51:42 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:51:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/start.php
INFO - 2025-05-11 15:51:42 --> Final output sent to browser
DEBUG - 2025-05-11 15:51:42 --> Total execution time: 0.0518
INFO - 2025-05-11 15:51:48 --> Config Class Initialized
INFO - 2025-05-11 15:51:48 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:51:48 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:51:48 --> Utf8 Class Initialized
INFO - 2025-05-11 15:51:48 --> URI Class Initialized
INFO - 2025-05-11 15:51:48 --> Router Class Initialized
INFO - 2025-05-11 15:51:48 --> Output Class Initialized
INFO - 2025-05-11 15:51:48 --> Security Class Initialized
DEBUG - 2025-05-11 15:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:51:48 --> Input Class Initialized
INFO - 2025-05-11 15:51:48 --> Language Class Initialized
INFO - 2025-05-11 15:51:48 --> Loader Class Initialized
INFO - 2025-05-11 15:51:48 --> Helper loaded: url_helper
INFO - 2025-05-11 15:51:48 --> Helper loaded: form_helper
INFO - 2025-05-11 15:51:48 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:51:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:51:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:51:48 --> Controller Class Initialized
INFO - 2025-05-11 15:51:48 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:51:48 --> Final output sent to browser
DEBUG - 2025-05-11 15:51:48 --> Total execution time: 0.0758
INFO - 2025-05-11 15:51:48 --> Config Class Initialized
INFO - 2025-05-11 15:51:48 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:51:48 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:51:48 --> Utf8 Class Initialized
INFO - 2025-05-11 15:51:48 --> URI Class Initialized
INFO - 2025-05-11 15:51:48 --> Router Class Initialized
INFO - 2025-05-11 15:51:48 --> Output Class Initialized
INFO - 2025-05-11 15:51:48 --> Security Class Initialized
DEBUG - 2025-05-11 15:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:51:48 --> Input Class Initialized
INFO - 2025-05-11 15:51:48 --> Language Class Initialized
INFO - 2025-05-11 15:51:48 --> Loader Class Initialized
INFO - 2025-05-11 15:51:48 --> Helper loaded: url_helper
INFO - 2025-05-11 15:51:48 --> Helper loaded: form_helper
INFO - 2025-05-11 15:51:48 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:51:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:51:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:51:48 --> Controller Class Initialized
INFO - 2025-05-11 15:51:48 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:51:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-11 15:51:48 --> Final output sent to browser
DEBUG - 2025-05-11 15:51:48 --> Total execution time: 0.0510
INFO - 2025-05-11 15:51:55 --> Config Class Initialized
INFO - 2025-05-11 15:51:55 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:51:55 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:51:55 --> Utf8 Class Initialized
INFO - 2025-05-11 15:51:55 --> URI Class Initialized
INFO - 2025-05-11 15:51:55 --> Router Class Initialized
INFO - 2025-05-11 15:51:55 --> Output Class Initialized
INFO - 2025-05-11 15:51:55 --> Security Class Initialized
DEBUG - 2025-05-11 15:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:51:55 --> Input Class Initialized
INFO - 2025-05-11 15:51:55 --> Language Class Initialized
INFO - 2025-05-11 15:51:55 --> Loader Class Initialized
INFO - 2025-05-11 15:51:55 --> Helper loaded: url_helper
INFO - 2025-05-11 15:51:55 --> Helper loaded: form_helper
INFO - 2025-05-11 15:51:55 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:51:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:51:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:51:55 --> Controller Class Initialized
INFO - 2025-05-11 15:51:55 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:51:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/start.php
INFO - 2025-05-11 15:51:55 --> Final output sent to browser
DEBUG - 2025-05-11 15:51:55 --> Total execution time: 0.0582
INFO - 2025-05-11 15:52:58 --> Config Class Initialized
INFO - 2025-05-11 15:52:58 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:52:58 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:52:58 --> Utf8 Class Initialized
INFO - 2025-05-11 15:52:58 --> URI Class Initialized
INFO - 2025-05-11 15:52:58 --> Router Class Initialized
INFO - 2025-05-11 15:52:58 --> Output Class Initialized
INFO - 2025-05-11 15:52:58 --> Security Class Initialized
DEBUG - 2025-05-11 15:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:52:58 --> Input Class Initialized
INFO - 2025-05-11 15:52:58 --> Language Class Initialized
INFO - 2025-05-11 15:52:58 --> Loader Class Initialized
INFO - 2025-05-11 15:52:58 --> Helper loaded: url_helper
INFO - 2025-05-11 15:52:58 --> Helper loaded: form_helper
INFO - 2025-05-11 15:52:58 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:52:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:52:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:52:58 --> Controller Class Initialized
INFO - 2025-05-11 15:52:58 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:52:58 --> Final output sent to browser
DEBUG - 2025-05-11 15:52:58 --> Total execution time: 0.0729
INFO - 2025-05-11 15:52:58 --> Config Class Initialized
INFO - 2025-05-11 15:52:58 --> Hooks Class Initialized
DEBUG - 2025-05-11 15:52:58 --> UTF-8 Support Enabled
INFO - 2025-05-11 15:52:58 --> Utf8 Class Initialized
INFO - 2025-05-11 15:52:58 --> URI Class Initialized
INFO - 2025-05-11 15:52:58 --> Router Class Initialized
INFO - 2025-05-11 15:52:58 --> Output Class Initialized
INFO - 2025-05-11 15:52:58 --> Security Class Initialized
DEBUG - 2025-05-11 15:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 15:52:58 --> Input Class Initialized
INFO - 2025-05-11 15:52:58 --> Language Class Initialized
INFO - 2025-05-11 15:52:58 --> Loader Class Initialized
INFO - 2025-05-11 15:52:58 --> Helper loaded: url_helper
INFO - 2025-05-11 15:52:58 --> Helper loaded: form_helper
INFO - 2025-05-11 15:52:58 --> Database Driver Class Initialized
DEBUG - 2025-05-11 15:52:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 15:52:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 15:52:58 --> Controller Class Initialized
INFO - 2025-05-11 15:52:58 --> Model "Workout_model" initialized
INFO - 2025-05-11 15:52:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-11 15:52:58 --> Final output sent to browser
DEBUG - 2025-05-11 15:52:58 --> Total execution time: 0.0619
INFO - 2025-05-11 16:07:58 --> Config Class Initialized
INFO - 2025-05-11 16:07:58 --> Hooks Class Initialized
DEBUG - 2025-05-11 16:07:58 --> UTF-8 Support Enabled
INFO - 2025-05-11 16:07:58 --> Utf8 Class Initialized
INFO - 2025-05-11 16:07:58 --> URI Class Initialized
INFO - 2025-05-11 16:07:58 --> Router Class Initialized
INFO - 2025-05-11 16:07:58 --> Output Class Initialized
INFO - 2025-05-11 16:07:58 --> Security Class Initialized
DEBUG - 2025-05-11 16:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 16:07:59 --> Input Class Initialized
INFO - 2025-05-11 16:07:59 --> Language Class Initialized
INFO - 2025-05-11 16:07:59 --> Loader Class Initialized
INFO - 2025-05-11 16:07:59 --> Helper loaded: url_helper
INFO - 2025-05-11 16:07:59 --> Helper loaded: form_helper
INFO - 2025-05-11 16:07:59 --> Database Driver Class Initialized
DEBUG - 2025-05-11 16:07:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 16:07:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 16:07:59 --> Controller Class Initialized
INFO - 2025-05-11 16:07:59 --> Model "Workout_model" initialized
INFO - 2025-05-11 16:07:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-11 16:07:59 --> Final output sent to browser
DEBUG - 2025-05-11 16:07:59 --> Total execution time: 0.0569
INFO - 2025-05-11 16:08:00 --> Config Class Initialized
INFO - 2025-05-11 16:08:00 --> Hooks Class Initialized
DEBUG - 2025-05-11 16:08:00 --> UTF-8 Support Enabled
INFO - 2025-05-11 16:08:00 --> Utf8 Class Initialized
INFO - 2025-05-11 16:08:00 --> URI Class Initialized
INFO - 2025-05-11 16:08:00 --> Router Class Initialized
INFO - 2025-05-11 16:08:00 --> Output Class Initialized
INFO - 2025-05-11 16:08:00 --> Security Class Initialized
DEBUG - 2025-05-11 16:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 16:08:00 --> Input Class Initialized
INFO - 2025-05-11 16:08:00 --> Language Class Initialized
INFO - 2025-05-11 16:08:00 --> Loader Class Initialized
INFO - 2025-05-11 16:08:00 --> Helper loaded: url_helper
INFO - 2025-05-11 16:08:00 --> Helper loaded: form_helper
INFO - 2025-05-11 16:08:00 --> Database Driver Class Initialized
DEBUG - 2025-05-11 16:08:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 16:08:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 16:08:00 --> Controller Class Initialized
INFO - 2025-05-11 16:08:00 --> Model "Workout_model" initialized
INFO - 2025-05-11 16:08:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/start.php
INFO - 2025-05-11 16:08:00 --> Final output sent to browser
DEBUG - 2025-05-11 16:08:00 --> Total execution time: 0.0471
INFO - 2025-05-11 16:08:03 --> Config Class Initialized
INFO - 2025-05-11 16:08:03 --> Hooks Class Initialized
DEBUG - 2025-05-11 16:08:03 --> UTF-8 Support Enabled
INFO - 2025-05-11 16:08:03 --> Utf8 Class Initialized
INFO - 2025-05-11 16:08:03 --> URI Class Initialized
INFO - 2025-05-11 16:08:03 --> Router Class Initialized
INFO - 2025-05-11 16:08:03 --> Output Class Initialized
INFO - 2025-05-11 16:08:03 --> Security Class Initialized
DEBUG - 2025-05-11 16:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 16:08:03 --> Input Class Initialized
INFO - 2025-05-11 16:08:03 --> Language Class Initialized
INFO - 2025-05-11 16:08:03 --> Loader Class Initialized
INFO - 2025-05-11 16:08:03 --> Helper loaded: url_helper
INFO - 2025-05-11 16:08:03 --> Helper loaded: form_helper
INFO - 2025-05-11 16:08:03 --> Database Driver Class Initialized
DEBUG - 2025-05-11 16:08:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 16:08:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 16:08:03 --> Controller Class Initialized
INFO - 2025-05-11 16:08:03 --> Model "Workout_model" initialized
INFO - 2025-05-11 16:08:03 --> Final output sent to browser
DEBUG - 2025-05-11 16:08:03 --> Total execution time: 0.0609
INFO - 2025-05-11 16:08:03 --> Config Class Initialized
INFO - 2025-05-11 16:08:03 --> Hooks Class Initialized
DEBUG - 2025-05-11 16:08:03 --> UTF-8 Support Enabled
INFO - 2025-05-11 16:08:03 --> Utf8 Class Initialized
INFO - 2025-05-11 16:08:03 --> URI Class Initialized
INFO - 2025-05-11 16:08:03 --> Router Class Initialized
INFO - 2025-05-11 16:08:03 --> Output Class Initialized
INFO - 2025-05-11 16:08:03 --> Security Class Initialized
DEBUG - 2025-05-11 16:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 16:08:03 --> Input Class Initialized
INFO - 2025-05-11 16:08:03 --> Language Class Initialized
INFO - 2025-05-11 16:08:03 --> Loader Class Initialized
INFO - 2025-05-11 16:08:03 --> Helper loaded: url_helper
INFO - 2025-05-11 16:08:03 --> Helper loaded: form_helper
INFO - 2025-05-11 16:08:03 --> Database Driver Class Initialized
DEBUG - 2025-05-11 16:08:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 16:08:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 16:08:03 --> Controller Class Initialized
INFO - 2025-05-11 16:08:03 --> Model "Workout_model" initialized
INFO - 2025-05-11 16:08:03 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-11 16:08:03 --> Final output sent to browser
DEBUG - 2025-05-11 16:08:03 --> Total execution time: 0.0610
INFO - 2025-05-11 16:08:11 --> Config Class Initialized
INFO - 2025-05-11 16:08:11 --> Hooks Class Initialized
DEBUG - 2025-05-11 16:08:11 --> UTF-8 Support Enabled
INFO - 2025-05-11 16:08:11 --> Utf8 Class Initialized
INFO - 2025-05-11 16:08:11 --> URI Class Initialized
INFO - 2025-05-11 16:08:11 --> Router Class Initialized
INFO - 2025-05-11 16:08:11 --> Output Class Initialized
INFO - 2025-05-11 16:08:11 --> Security Class Initialized
DEBUG - 2025-05-11 16:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 16:08:11 --> Input Class Initialized
INFO - 2025-05-11 16:08:11 --> Language Class Initialized
INFO - 2025-05-11 16:08:11 --> Loader Class Initialized
INFO - 2025-05-11 16:08:11 --> Helper loaded: url_helper
INFO - 2025-05-11 16:08:11 --> Helper loaded: form_helper
INFO - 2025-05-11 16:08:11 --> Database Driver Class Initialized
DEBUG - 2025-05-11 16:08:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 16:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 16:08:11 --> Controller Class Initialized
INFO - 2025-05-11 16:08:11 --> Model "Workout_model" initialized
INFO - 2025-05-11 16:08:11 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/add.php
INFO - 2025-05-11 16:08:11 --> Final output sent to browser
DEBUG - 2025-05-11 16:08:11 --> Total execution time: 0.0494
INFO - 2025-05-11 16:08:20 --> Config Class Initialized
INFO - 2025-05-11 16:08:20 --> Hooks Class Initialized
DEBUG - 2025-05-11 16:08:20 --> UTF-8 Support Enabled
INFO - 2025-05-11 16:08:20 --> Utf8 Class Initialized
INFO - 2025-05-11 16:08:20 --> URI Class Initialized
INFO - 2025-05-11 16:08:20 --> Router Class Initialized
INFO - 2025-05-11 16:08:20 --> Output Class Initialized
INFO - 2025-05-11 16:08:20 --> Security Class Initialized
DEBUG - 2025-05-11 16:08:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 16:08:20 --> Input Class Initialized
INFO - 2025-05-11 16:08:20 --> Language Class Initialized
INFO - 2025-05-11 16:08:20 --> Loader Class Initialized
INFO - 2025-05-11 16:08:20 --> Helper loaded: url_helper
INFO - 2025-05-11 16:08:20 --> Helper loaded: form_helper
INFO - 2025-05-11 16:08:20 --> Database Driver Class Initialized
DEBUG - 2025-05-11 16:08:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 16:08:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 16:08:20 --> Controller Class Initialized
INFO - 2025-05-11 16:08:20 --> Model "Workout_model" initialized
INFO - 2025-05-11 16:08:20 --> Config Class Initialized
INFO - 2025-05-11 16:08:20 --> Hooks Class Initialized
DEBUG - 2025-05-11 16:08:20 --> UTF-8 Support Enabled
INFO - 2025-05-11 16:08:20 --> Utf8 Class Initialized
INFO - 2025-05-11 16:08:20 --> URI Class Initialized
INFO - 2025-05-11 16:08:20 --> Router Class Initialized
INFO - 2025-05-11 16:08:20 --> Output Class Initialized
INFO - 2025-05-11 16:08:20 --> Security Class Initialized
DEBUG - 2025-05-11 16:08:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 16:08:20 --> Input Class Initialized
INFO - 2025-05-11 16:08:20 --> Language Class Initialized
INFO - 2025-05-11 16:08:20 --> Loader Class Initialized
INFO - 2025-05-11 16:08:20 --> Helper loaded: url_helper
INFO - 2025-05-11 16:08:20 --> Helper loaded: form_helper
INFO - 2025-05-11 16:08:20 --> Database Driver Class Initialized
DEBUG - 2025-05-11 16:08:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 16:08:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 16:08:20 --> Controller Class Initialized
INFO - 2025-05-11 16:08:20 --> Model "Workout_model" initialized
INFO - 2025-05-11 16:08:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-11 16:08:20 --> Final output sent to browser
DEBUG - 2025-05-11 16:08:20 --> Total execution time: 0.0651
INFO - 2025-05-11 16:08:22 --> Config Class Initialized
INFO - 2025-05-11 16:08:22 --> Hooks Class Initialized
DEBUG - 2025-05-11 16:08:22 --> UTF-8 Support Enabled
INFO - 2025-05-11 16:08:22 --> Utf8 Class Initialized
INFO - 2025-05-11 16:08:22 --> URI Class Initialized
INFO - 2025-05-11 16:08:22 --> Router Class Initialized
INFO - 2025-05-11 16:08:22 --> Output Class Initialized
INFO - 2025-05-11 16:08:22 --> Security Class Initialized
DEBUG - 2025-05-11 16:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 16:08:22 --> Input Class Initialized
INFO - 2025-05-11 16:08:22 --> Language Class Initialized
INFO - 2025-05-11 16:08:22 --> Loader Class Initialized
INFO - 2025-05-11 16:08:22 --> Helper loaded: url_helper
INFO - 2025-05-11 16:08:22 --> Helper loaded: form_helper
INFO - 2025-05-11 16:08:22 --> Database Driver Class Initialized
DEBUG - 2025-05-11 16:08:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 16:08:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 16:08:22 --> Controller Class Initialized
INFO - 2025-05-11 16:08:22 --> Model "Workout_model" initialized
INFO - 2025-05-11 16:08:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/add.php
INFO - 2025-05-11 16:08:22 --> Final output sent to browser
DEBUG - 2025-05-11 16:08:22 --> Total execution time: 0.0456
INFO - 2025-05-11 16:08:40 --> Config Class Initialized
INFO - 2025-05-11 16:08:40 --> Hooks Class Initialized
DEBUG - 2025-05-11 16:08:40 --> UTF-8 Support Enabled
INFO - 2025-05-11 16:08:40 --> Utf8 Class Initialized
INFO - 2025-05-11 16:08:40 --> URI Class Initialized
INFO - 2025-05-11 16:08:40 --> Router Class Initialized
INFO - 2025-05-11 16:08:40 --> Output Class Initialized
INFO - 2025-05-11 16:08:40 --> Security Class Initialized
DEBUG - 2025-05-11 16:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 16:08:40 --> Input Class Initialized
INFO - 2025-05-11 16:08:40 --> Language Class Initialized
INFO - 2025-05-11 16:08:40 --> Loader Class Initialized
INFO - 2025-05-11 16:08:40 --> Helper loaded: url_helper
INFO - 2025-05-11 16:08:40 --> Helper loaded: form_helper
INFO - 2025-05-11 16:08:40 --> Database Driver Class Initialized
DEBUG - 2025-05-11 16:08:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 16:08:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 16:08:40 --> Controller Class Initialized
INFO - 2025-05-11 16:08:40 --> Model "Workout_model" initialized
INFO - 2025-05-11 16:08:40 --> Config Class Initialized
INFO - 2025-05-11 16:08:40 --> Hooks Class Initialized
DEBUG - 2025-05-11 16:08:40 --> UTF-8 Support Enabled
INFO - 2025-05-11 16:08:40 --> Utf8 Class Initialized
INFO - 2025-05-11 16:08:40 --> URI Class Initialized
INFO - 2025-05-11 16:08:40 --> Router Class Initialized
INFO - 2025-05-11 16:08:40 --> Output Class Initialized
INFO - 2025-05-11 16:08:40 --> Security Class Initialized
DEBUG - 2025-05-11 16:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 16:08:40 --> Input Class Initialized
INFO - 2025-05-11 16:08:40 --> Language Class Initialized
INFO - 2025-05-11 16:08:40 --> Loader Class Initialized
INFO - 2025-05-11 16:08:40 --> Helper loaded: url_helper
INFO - 2025-05-11 16:08:40 --> Helper loaded: form_helper
INFO - 2025-05-11 16:08:40 --> Database Driver Class Initialized
DEBUG - 2025-05-11 16:08:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 16:08:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 16:08:40 --> Controller Class Initialized
INFO - 2025-05-11 16:08:40 --> Model "Workout_model" initialized
INFO - 2025-05-11 16:08:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-11 16:08:40 --> Final output sent to browser
DEBUG - 2025-05-11 16:08:40 --> Total execution time: 0.0564
INFO - 2025-05-11 16:08:42 --> Config Class Initialized
INFO - 2025-05-11 16:08:42 --> Hooks Class Initialized
DEBUG - 2025-05-11 16:08:42 --> UTF-8 Support Enabled
INFO - 2025-05-11 16:08:42 --> Utf8 Class Initialized
INFO - 2025-05-11 16:08:42 --> URI Class Initialized
INFO - 2025-05-11 16:08:42 --> Router Class Initialized
INFO - 2025-05-11 16:08:42 --> Output Class Initialized
INFO - 2025-05-11 16:08:42 --> Security Class Initialized
DEBUG - 2025-05-11 16:08:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 16:08:42 --> Input Class Initialized
INFO - 2025-05-11 16:08:42 --> Language Class Initialized
INFO - 2025-05-11 16:08:42 --> Loader Class Initialized
INFO - 2025-05-11 16:08:42 --> Helper loaded: url_helper
INFO - 2025-05-11 16:08:42 --> Helper loaded: form_helper
INFO - 2025-05-11 16:08:42 --> Database Driver Class Initialized
DEBUG - 2025-05-11 16:08:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 16:08:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 16:08:42 --> Controller Class Initialized
INFO - 2025-05-11 16:08:42 --> Model "Workout_model" initialized
INFO - 2025-05-11 16:08:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/add.php
INFO - 2025-05-11 16:08:42 --> Final output sent to browser
DEBUG - 2025-05-11 16:08:42 --> Total execution time: 0.0439
INFO - 2025-05-11 16:08:55 --> Config Class Initialized
INFO - 2025-05-11 16:08:55 --> Hooks Class Initialized
DEBUG - 2025-05-11 16:08:55 --> UTF-8 Support Enabled
INFO - 2025-05-11 16:08:55 --> Utf8 Class Initialized
INFO - 2025-05-11 16:08:55 --> URI Class Initialized
INFO - 2025-05-11 16:08:55 --> Router Class Initialized
INFO - 2025-05-11 16:08:55 --> Output Class Initialized
INFO - 2025-05-11 16:08:55 --> Security Class Initialized
DEBUG - 2025-05-11 16:08:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 16:08:55 --> Input Class Initialized
INFO - 2025-05-11 16:08:55 --> Language Class Initialized
INFO - 2025-05-11 16:08:55 --> Loader Class Initialized
INFO - 2025-05-11 16:08:55 --> Helper loaded: url_helper
INFO - 2025-05-11 16:08:55 --> Helper loaded: form_helper
INFO - 2025-05-11 16:08:55 --> Database Driver Class Initialized
DEBUG - 2025-05-11 16:08:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 16:08:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 16:08:55 --> Controller Class Initialized
INFO - 2025-05-11 16:08:55 --> Model "Workout_model" initialized
INFO - 2025-05-11 16:08:55 --> Config Class Initialized
INFO - 2025-05-11 16:08:55 --> Hooks Class Initialized
DEBUG - 2025-05-11 16:08:55 --> UTF-8 Support Enabled
INFO - 2025-05-11 16:08:55 --> Utf8 Class Initialized
INFO - 2025-05-11 16:08:55 --> URI Class Initialized
INFO - 2025-05-11 16:08:55 --> Router Class Initialized
INFO - 2025-05-11 16:08:55 --> Output Class Initialized
INFO - 2025-05-11 16:08:55 --> Security Class Initialized
DEBUG - 2025-05-11 16:08:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 16:08:55 --> Input Class Initialized
INFO - 2025-05-11 16:08:55 --> Language Class Initialized
INFO - 2025-05-11 16:08:55 --> Loader Class Initialized
INFO - 2025-05-11 16:08:55 --> Helper loaded: url_helper
INFO - 2025-05-11 16:08:55 --> Helper loaded: form_helper
INFO - 2025-05-11 16:08:55 --> Database Driver Class Initialized
DEBUG - 2025-05-11 16:08:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 16:08:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 16:08:55 --> Controller Class Initialized
INFO - 2025-05-11 16:08:55 --> Model "Workout_model" initialized
INFO - 2025-05-11 16:08:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-11 16:08:55 --> Final output sent to browser
DEBUG - 2025-05-11 16:08:55 --> Total execution time: 0.0558
INFO - 2025-05-11 16:08:59 --> Config Class Initialized
INFO - 2025-05-11 16:08:59 --> Hooks Class Initialized
DEBUG - 2025-05-11 16:08:59 --> UTF-8 Support Enabled
INFO - 2025-05-11 16:08:59 --> Utf8 Class Initialized
INFO - 2025-05-11 16:08:59 --> URI Class Initialized
INFO - 2025-05-11 16:08:59 --> Router Class Initialized
INFO - 2025-05-11 16:08:59 --> Output Class Initialized
INFO - 2025-05-11 16:08:59 --> Security Class Initialized
DEBUG - 2025-05-11 16:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 16:08:59 --> Input Class Initialized
INFO - 2025-05-11 16:08:59 --> Language Class Initialized
INFO - 2025-05-11 16:08:59 --> Loader Class Initialized
INFO - 2025-05-11 16:08:59 --> Helper loaded: url_helper
INFO - 2025-05-11 16:08:59 --> Helper loaded: form_helper
INFO - 2025-05-11 16:08:59 --> Database Driver Class Initialized
DEBUG - 2025-05-11 16:08:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 16:08:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 16:08:59 --> Controller Class Initialized
INFO - 2025-05-11 16:08:59 --> Model "Workout_model" initialized
INFO - 2025-05-11 16:08:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/start.php
INFO - 2025-05-11 16:08:59 --> Final output sent to browser
DEBUG - 2025-05-11 16:08:59 --> Total execution time: 0.0501
INFO - 2025-05-11 16:09:01 --> Config Class Initialized
INFO - 2025-05-11 16:09:01 --> Hooks Class Initialized
DEBUG - 2025-05-11 16:09:01 --> UTF-8 Support Enabled
INFO - 2025-05-11 16:09:01 --> Utf8 Class Initialized
INFO - 2025-05-11 16:09:01 --> URI Class Initialized
INFO - 2025-05-11 16:09:01 --> Router Class Initialized
INFO - 2025-05-11 16:09:01 --> Output Class Initialized
INFO - 2025-05-11 16:09:01 --> Security Class Initialized
DEBUG - 2025-05-11 16:09:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 16:09:01 --> Input Class Initialized
INFO - 2025-05-11 16:09:01 --> Language Class Initialized
INFO - 2025-05-11 16:09:01 --> Loader Class Initialized
INFO - 2025-05-11 16:09:01 --> Helper loaded: url_helper
INFO - 2025-05-11 16:09:01 --> Helper loaded: form_helper
INFO - 2025-05-11 16:09:01 --> Database Driver Class Initialized
DEBUG - 2025-05-11 16:09:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 16:09:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 16:09:01 --> Controller Class Initialized
INFO - 2025-05-11 16:09:01 --> Model "Workout_model" initialized
INFO - 2025-05-11 16:09:01 --> Final output sent to browser
DEBUG - 2025-05-11 16:09:01 --> Total execution time: 0.0580
INFO - 2025-05-11 16:09:02 --> Config Class Initialized
INFO - 2025-05-11 16:09:02 --> Hooks Class Initialized
DEBUG - 2025-05-11 16:09:02 --> UTF-8 Support Enabled
INFO - 2025-05-11 16:09:02 --> Utf8 Class Initialized
INFO - 2025-05-11 16:09:02 --> URI Class Initialized
INFO - 2025-05-11 16:09:02 --> Router Class Initialized
INFO - 2025-05-11 16:09:02 --> Output Class Initialized
INFO - 2025-05-11 16:09:02 --> Security Class Initialized
DEBUG - 2025-05-11 16:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 16:09:02 --> Input Class Initialized
INFO - 2025-05-11 16:09:02 --> Language Class Initialized
INFO - 2025-05-11 16:09:02 --> Loader Class Initialized
INFO - 2025-05-11 16:09:02 --> Helper loaded: url_helper
INFO - 2025-05-11 16:09:02 --> Helper loaded: form_helper
INFO - 2025-05-11 16:09:02 --> Database Driver Class Initialized
DEBUG - 2025-05-11 16:09:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 16:09:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 16:09:02 --> Controller Class Initialized
INFO - 2025-05-11 16:09:02 --> Model "Workout_model" initialized
INFO - 2025-05-11 16:09:02 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-11 16:09:02 --> Final output sent to browser
DEBUG - 2025-05-11 16:09:02 --> Total execution time: 0.0613
INFO - 2025-05-11 16:09:05 --> Config Class Initialized
INFO - 2025-05-11 16:09:05 --> Hooks Class Initialized
DEBUG - 2025-05-11 16:09:05 --> UTF-8 Support Enabled
INFO - 2025-05-11 16:09:05 --> Utf8 Class Initialized
INFO - 2025-05-11 16:09:05 --> URI Class Initialized
INFO - 2025-05-11 16:09:05 --> Router Class Initialized
INFO - 2025-05-11 16:09:05 --> Output Class Initialized
INFO - 2025-05-11 16:09:05 --> Security Class Initialized
DEBUG - 2025-05-11 16:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 16:09:05 --> Input Class Initialized
INFO - 2025-05-11 16:09:05 --> Language Class Initialized
INFO - 2025-05-11 16:09:05 --> Loader Class Initialized
INFO - 2025-05-11 16:09:05 --> Helper loaded: url_helper
INFO - 2025-05-11 16:09:05 --> Helper loaded: form_helper
INFO - 2025-05-11 16:09:05 --> Database Driver Class Initialized
DEBUG - 2025-05-11 16:09:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 16:09:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 16:09:05 --> Controller Class Initialized
INFO - 2025-05-11 16:09:05 --> Model "Workout_model" initialized
INFO - 2025-05-11 16:09:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/start.php
INFO - 2025-05-11 16:09:05 --> Final output sent to browser
DEBUG - 2025-05-11 16:09:05 --> Total execution time: 0.0518
INFO - 2025-05-11 16:09:07 --> Config Class Initialized
INFO - 2025-05-11 16:09:07 --> Hooks Class Initialized
DEBUG - 2025-05-11 16:09:07 --> UTF-8 Support Enabled
INFO - 2025-05-11 16:09:07 --> Utf8 Class Initialized
INFO - 2025-05-11 16:09:07 --> URI Class Initialized
INFO - 2025-05-11 16:09:07 --> Router Class Initialized
INFO - 2025-05-11 16:09:07 --> Output Class Initialized
INFO - 2025-05-11 16:09:07 --> Security Class Initialized
DEBUG - 2025-05-11 16:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 16:09:07 --> Input Class Initialized
INFO - 2025-05-11 16:09:07 --> Language Class Initialized
INFO - 2025-05-11 16:09:07 --> Loader Class Initialized
INFO - 2025-05-11 16:09:07 --> Helper loaded: url_helper
INFO - 2025-05-11 16:09:07 --> Helper loaded: form_helper
INFO - 2025-05-11 16:09:07 --> Database Driver Class Initialized
DEBUG - 2025-05-11 16:09:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 16:09:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 16:09:07 --> Controller Class Initialized
INFO - 2025-05-11 16:09:07 --> Model "Workout_model" initialized
INFO - 2025-05-11 16:09:07 --> Final output sent to browser
DEBUG - 2025-05-11 16:09:07 --> Total execution time: 0.0568
INFO - 2025-05-11 16:09:07 --> Config Class Initialized
INFO - 2025-05-11 16:09:07 --> Hooks Class Initialized
DEBUG - 2025-05-11 16:09:07 --> UTF-8 Support Enabled
INFO - 2025-05-11 16:09:07 --> Utf8 Class Initialized
INFO - 2025-05-11 16:09:07 --> URI Class Initialized
INFO - 2025-05-11 16:09:07 --> Router Class Initialized
INFO - 2025-05-11 16:09:07 --> Output Class Initialized
INFO - 2025-05-11 16:09:07 --> Security Class Initialized
DEBUG - 2025-05-11 16:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 16:09:07 --> Input Class Initialized
INFO - 2025-05-11 16:09:07 --> Language Class Initialized
INFO - 2025-05-11 16:09:07 --> Loader Class Initialized
INFO - 2025-05-11 16:09:07 --> Helper loaded: url_helper
INFO - 2025-05-11 16:09:07 --> Helper loaded: form_helper
INFO - 2025-05-11 16:09:07 --> Database Driver Class Initialized
DEBUG - 2025-05-11 16:09:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 16:09:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 16:09:07 --> Controller Class Initialized
INFO - 2025-05-11 16:09:07 --> Model "Workout_model" initialized
INFO - 2025-05-11 16:09:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-11 16:09:07 --> Final output sent to browser
DEBUG - 2025-05-11 16:09:07 --> Total execution time: 0.0449
INFO - 2025-05-11 16:09:24 --> Config Class Initialized
INFO - 2025-05-11 16:09:24 --> Hooks Class Initialized
DEBUG - 2025-05-11 16:09:24 --> UTF-8 Support Enabled
INFO - 2025-05-11 16:09:24 --> Utf8 Class Initialized
INFO - 2025-05-11 16:09:24 --> URI Class Initialized
DEBUG - 2025-05-11 16:09:24 --> No URI present. Default controller set.
INFO - 2025-05-11 16:09:24 --> Router Class Initialized
INFO - 2025-05-11 16:09:24 --> Output Class Initialized
INFO - 2025-05-11 16:09:24 --> Security Class Initialized
DEBUG - 2025-05-11 16:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 16:09:24 --> Input Class Initialized
INFO - 2025-05-11 16:09:24 --> Language Class Initialized
INFO - 2025-05-11 16:09:24 --> Loader Class Initialized
INFO - 2025-05-11 16:09:24 --> Helper loaded: url_helper
INFO - 2025-05-11 16:09:24 --> Helper loaded: form_helper
INFO - 2025-05-11 16:09:24 --> Database Driver Class Initialized
DEBUG - 2025-05-11 16:09:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 16:09:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 16:09:24 --> Controller Class Initialized
INFO - 2025-05-11 16:09:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-11 16:09:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-11 16:09:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-11 16:09:24 --> Final output sent to browser
DEBUG - 2025-05-11 16:09:24 --> Total execution time: 0.0676
INFO - 2025-05-11 16:09:26 --> Config Class Initialized
INFO - 2025-05-11 16:09:26 --> Hooks Class Initialized
DEBUG - 2025-05-11 16:09:26 --> UTF-8 Support Enabled
INFO - 2025-05-11 16:09:26 --> Utf8 Class Initialized
INFO - 2025-05-11 16:09:26 --> URI Class Initialized
INFO - 2025-05-11 16:09:26 --> Router Class Initialized
INFO - 2025-05-11 16:09:26 --> Output Class Initialized
INFO - 2025-05-11 16:09:26 --> Security Class Initialized
DEBUG - 2025-05-11 16:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 16:09:26 --> Input Class Initialized
INFO - 2025-05-11 16:09:26 --> Language Class Initialized
INFO - 2025-05-11 16:09:26 --> Loader Class Initialized
INFO - 2025-05-11 16:09:26 --> Helper loaded: url_helper
INFO - 2025-05-11 16:09:26 --> Helper loaded: form_helper
INFO - 2025-05-11 16:09:26 --> Database Driver Class Initialized
DEBUG - 2025-05-11 16:09:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 16:09:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 16:09:26 --> Controller Class Initialized
INFO - 2025-05-11 16:09:26 --> Model "User_model" initialized
INFO - 2025-05-11 16:09:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-11 16:09:26 --> Final output sent to browser
DEBUG - 2025-05-11 16:09:26 --> Total execution time: 0.0669
INFO - 2025-05-11 16:09:49 --> Config Class Initialized
INFO - 2025-05-11 16:09:49 --> Hooks Class Initialized
DEBUG - 2025-05-11 16:09:49 --> UTF-8 Support Enabled
INFO - 2025-05-11 16:09:49 --> Utf8 Class Initialized
INFO - 2025-05-11 16:09:49 --> URI Class Initialized
INFO - 2025-05-11 16:09:49 --> Router Class Initialized
INFO - 2025-05-11 16:09:49 --> Output Class Initialized
INFO - 2025-05-11 16:09:49 --> Security Class Initialized
DEBUG - 2025-05-11 16:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 16:09:49 --> Input Class Initialized
INFO - 2025-05-11 16:09:49 --> Language Class Initialized
INFO - 2025-05-11 16:09:49 --> Loader Class Initialized
INFO - 2025-05-11 16:09:49 --> Helper loaded: url_helper
INFO - 2025-05-11 16:09:49 --> Helper loaded: form_helper
INFO - 2025-05-11 16:09:49 --> Database Driver Class Initialized
DEBUG - 2025-05-11 16:09:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 16:09:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 16:09:49 --> Controller Class Initialized
INFO - 2025-05-11 16:09:49 --> Model "User_model" initialized
INFO - 2025-05-11 16:09:49 --> Config Class Initialized
INFO - 2025-05-11 16:09:49 --> Hooks Class Initialized
DEBUG - 2025-05-11 16:09:49 --> UTF-8 Support Enabled
INFO - 2025-05-11 16:09:49 --> Utf8 Class Initialized
INFO - 2025-05-11 16:09:49 --> URI Class Initialized
INFO - 2025-05-11 16:09:49 --> Router Class Initialized
INFO - 2025-05-11 16:09:49 --> Output Class Initialized
INFO - 2025-05-11 16:09:49 --> Security Class Initialized
DEBUG - 2025-05-11 16:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 16:09:49 --> Input Class Initialized
INFO - 2025-05-11 16:09:49 --> Language Class Initialized
INFO - 2025-05-11 16:09:49 --> Loader Class Initialized
INFO - 2025-05-11 16:09:49 --> Helper loaded: url_helper
INFO - 2025-05-11 16:09:49 --> Helper loaded: form_helper
INFO - 2025-05-11 16:09:49 --> Database Driver Class Initialized
DEBUG - 2025-05-11 16:09:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 16:09:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 16:09:49 --> Controller Class Initialized
INFO - 2025-05-11 16:09:49 --> Model "User_model" initialized
INFO - 2025-05-11 16:09:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard.php
INFO - 2025-05-11 16:09:49 --> Final output sent to browser
DEBUG - 2025-05-11 16:09:49 --> Total execution time: 0.0560
INFO - 2025-05-11 16:09:51 --> Config Class Initialized
INFO - 2025-05-11 16:09:51 --> Hooks Class Initialized
DEBUG - 2025-05-11 16:09:51 --> UTF-8 Support Enabled
INFO - 2025-05-11 16:09:51 --> Utf8 Class Initialized
INFO - 2025-05-11 16:09:51 --> URI Class Initialized
INFO - 2025-05-11 16:09:51 --> Router Class Initialized
INFO - 2025-05-11 16:09:51 --> Output Class Initialized
INFO - 2025-05-11 16:09:51 --> Security Class Initialized
DEBUG - 2025-05-11 16:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 16:09:51 --> Input Class Initialized
INFO - 2025-05-11 16:09:51 --> Language Class Initialized
INFO - 2025-05-11 16:09:51 --> Loader Class Initialized
INFO - 2025-05-11 16:09:51 --> Helper loaded: url_helper
INFO - 2025-05-11 16:09:51 --> Helper loaded: form_helper
INFO - 2025-05-11 16:09:51 --> Database Driver Class Initialized
DEBUG - 2025-05-11 16:09:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 16:09:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 16:09:51 --> Controller Class Initialized
INFO - 2025-05-11 16:09:51 --> Model "Workout_model" initialized
INFO - 2025-05-11 16:09:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-11 16:09:51 --> Final output sent to browser
DEBUG - 2025-05-11 16:09:51 --> Total execution time: 0.0483
INFO - 2025-05-11 16:09:58 --> Config Class Initialized
INFO - 2025-05-11 16:09:58 --> Hooks Class Initialized
DEBUG - 2025-05-11 16:09:58 --> UTF-8 Support Enabled
INFO - 2025-05-11 16:09:58 --> Utf8 Class Initialized
INFO - 2025-05-11 16:09:58 --> URI Class Initialized
INFO - 2025-05-11 16:09:58 --> Router Class Initialized
INFO - 2025-05-11 16:09:58 --> Output Class Initialized
INFO - 2025-05-11 16:09:59 --> Security Class Initialized
DEBUG - 2025-05-11 16:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 16:09:59 --> Input Class Initialized
INFO - 2025-05-11 16:09:59 --> Language Class Initialized
INFO - 2025-05-11 16:09:59 --> Loader Class Initialized
INFO - 2025-05-11 16:09:59 --> Helper loaded: url_helper
INFO - 2025-05-11 16:09:59 --> Helper loaded: form_helper
INFO - 2025-05-11 16:09:59 --> Database Driver Class Initialized
DEBUG - 2025-05-11 16:09:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 16:09:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 16:09:59 --> Controller Class Initialized
INFO - 2025-05-11 16:09:59 --> Model "Workout_model" initialized
INFO - 2025-05-11 16:09:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/start.php
INFO - 2025-05-11 16:09:59 --> Final output sent to browser
DEBUG - 2025-05-11 16:09:59 --> Total execution time: 0.0516
INFO - 2025-05-11 16:10:01 --> Config Class Initialized
INFO - 2025-05-11 16:10:01 --> Hooks Class Initialized
DEBUG - 2025-05-11 16:10:01 --> UTF-8 Support Enabled
INFO - 2025-05-11 16:10:01 --> Utf8 Class Initialized
INFO - 2025-05-11 16:10:01 --> URI Class Initialized
INFO - 2025-05-11 16:10:01 --> Router Class Initialized
INFO - 2025-05-11 16:10:01 --> Output Class Initialized
INFO - 2025-05-11 16:10:01 --> Security Class Initialized
DEBUG - 2025-05-11 16:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 16:10:01 --> Input Class Initialized
INFO - 2025-05-11 16:10:01 --> Language Class Initialized
INFO - 2025-05-11 16:10:01 --> Loader Class Initialized
INFO - 2025-05-11 16:10:01 --> Helper loaded: url_helper
INFO - 2025-05-11 16:10:01 --> Helper loaded: form_helper
INFO - 2025-05-11 16:10:01 --> Database Driver Class Initialized
DEBUG - 2025-05-11 16:10:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 16:10:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 16:10:01 --> Controller Class Initialized
INFO - 2025-05-11 16:10:01 --> Model "Workout_model" initialized
INFO - 2025-05-11 16:10:01 --> Final output sent to browser
DEBUG - 2025-05-11 16:10:01 --> Total execution time: 0.0641
INFO - 2025-05-11 16:10:01 --> Config Class Initialized
INFO - 2025-05-11 16:10:01 --> Hooks Class Initialized
DEBUG - 2025-05-11 16:10:01 --> UTF-8 Support Enabled
INFO - 2025-05-11 16:10:01 --> Utf8 Class Initialized
INFO - 2025-05-11 16:10:01 --> URI Class Initialized
INFO - 2025-05-11 16:10:01 --> Router Class Initialized
INFO - 2025-05-11 16:10:01 --> Output Class Initialized
INFO - 2025-05-11 16:10:01 --> Security Class Initialized
DEBUG - 2025-05-11 16:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 16:10:01 --> Input Class Initialized
INFO - 2025-05-11 16:10:01 --> Language Class Initialized
INFO - 2025-05-11 16:10:01 --> Loader Class Initialized
INFO - 2025-05-11 16:10:01 --> Helper loaded: url_helper
INFO - 2025-05-11 16:10:01 --> Helper loaded: form_helper
INFO - 2025-05-11 16:10:01 --> Database Driver Class Initialized
DEBUG - 2025-05-11 16:10:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 16:10:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 16:10:01 --> Controller Class Initialized
INFO - 2025-05-11 16:10:01 --> Model "Workout_model" initialized
INFO - 2025-05-11 16:10:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-11 16:10:01 --> Final output sent to browser
DEBUG - 2025-05-11 16:10:01 --> Total execution time: 0.0589
INFO - 2025-05-11 16:19:22 --> Config Class Initialized
INFO - 2025-05-11 16:19:22 --> Hooks Class Initialized
DEBUG - 2025-05-11 16:19:22 --> UTF-8 Support Enabled
INFO - 2025-05-11 16:19:22 --> Utf8 Class Initialized
INFO - 2025-05-11 16:19:22 --> URI Class Initialized
INFO - 2025-05-11 16:19:22 --> Router Class Initialized
INFO - 2025-05-11 16:19:22 --> Output Class Initialized
INFO - 2025-05-11 16:19:22 --> Security Class Initialized
DEBUG - 2025-05-11 16:19:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 16:19:22 --> Input Class Initialized
INFO - 2025-05-11 16:19:22 --> Language Class Initialized
INFO - 2025-05-11 16:19:22 --> Loader Class Initialized
INFO - 2025-05-11 16:19:22 --> Helper loaded: url_helper
INFO - 2025-05-11 16:19:22 --> Helper loaded: form_helper
INFO - 2025-05-11 16:19:22 --> Database Driver Class Initialized
DEBUG - 2025-05-11 16:19:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 16:19:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 16:19:22 --> Controller Class Initialized
INFO - 2025-05-11 16:19:22 --> Model "Workout_model" initialized
INFO - 2025-05-11 16:19:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-11 16:19:22 --> Final output sent to browser
DEBUG - 2025-05-11 16:19:22 --> Total execution time: 0.0494
INFO - 2025-05-11 16:19:27 --> Config Class Initialized
INFO - 2025-05-11 16:19:27 --> Hooks Class Initialized
DEBUG - 2025-05-11 16:19:27 --> UTF-8 Support Enabled
INFO - 2025-05-11 16:19:27 --> Utf8 Class Initialized
INFO - 2025-05-11 16:19:27 --> URI Class Initialized
INFO - 2025-05-11 16:19:27 --> Router Class Initialized
INFO - 2025-05-11 16:19:27 --> Output Class Initialized
INFO - 2025-05-11 16:19:27 --> Security Class Initialized
DEBUG - 2025-05-11 16:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 16:19:27 --> Input Class Initialized
INFO - 2025-05-11 16:19:27 --> Language Class Initialized
INFO - 2025-05-11 16:19:27 --> Loader Class Initialized
INFO - 2025-05-11 16:19:27 --> Helper loaded: url_helper
INFO - 2025-05-11 16:19:27 --> Helper loaded: form_helper
INFO - 2025-05-11 16:19:27 --> Database Driver Class Initialized
DEBUG - 2025-05-11 16:19:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 16:19:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 16:19:27 --> Controller Class Initialized
INFO - 2025-05-11 16:19:27 --> Model "Workout_model" initialized
INFO - 2025-05-11 16:19:27 --> Config Class Initialized
INFO - 2025-05-11 16:19:27 --> Hooks Class Initialized
DEBUG - 2025-05-11 16:19:27 --> UTF-8 Support Enabled
INFO - 2025-05-11 16:19:27 --> Utf8 Class Initialized
INFO - 2025-05-11 16:19:27 --> URI Class Initialized
INFO - 2025-05-11 16:19:27 --> Router Class Initialized
INFO - 2025-05-11 16:19:27 --> Output Class Initialized
INFO - 2025-05-11 16:19:27 --> Security Class Initialized
DEBUG - 2025-05-11 16:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 16:19:27 --> Input Class Initialized
INFO - 2025-05-11 16:19:27 --> Language Class Initialized
INFO - 2025-05-11 16:19:27 --> Loader Class Initialized
INFO - 2025-05-11 16:19:27 --> Helper loaded: url_helper
INFO - 2025-05-11 16:19:27 --> Helper loaded: form_helper
INFO - 2025-05-11 16:19:27 --> Database Driver Class Initialized
DEBUG - 2025-05-11 16:19:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 16:19:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 16:19:27 --> Controller Class Initialized
INFO - 2025-05-11 16:19:27 --> Model "Workout_model" initialized
INFO - 2025-05-11 16:19:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-11 16:19:27 --> Final output sent to browser
DEBUG - 2025-05-11 16:19:27 --> Total execution time: 0.0433
INFO - 2025-05-11 16:19:34 --> Config Class Initialized
INFO - 2025-05-11 16:19:34 --> Hooks Class Initialized
DEBUG - 2025-05-11 16:19:34 --> UTF-8 Support Enabled
INFO - 2025-05-11 16:19:34 --> Utf8 Class Initialized
INFO - 2025-05-11 16:19:34 --> URI Class Initialized
INFO - 2025-05-11 16:19:34 --> Router Class Initialized
INFO - 2025-05-11 16:19:34 --> Output Class Initialized
INFO - 2025-05-11 16:19:34 --> Security Class Initialized
DEBUG - 2025-05-11 16:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 16:19:34 --> Input Class Initialized
INFO - 2025-05-11 16:19:34 --> Language Class Initialized
INFO - 2025-05-11 16:19:34 --> Loader Class Initialized
INFO - 2025-05-11 16:19:34 --> Helper loaded: url_helper
INFO - 2025-05-11 16:19:34 --> Helper loaded: form_helper
INFO - 2025-05-11 16:19:34 --> Database Driver Class Initialized
DEBUG - 2025-05-11 16:19:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 16:19:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 16:19:34 --> Controller Class Initialized
INFO - 2025-05-11 16:19:34 --> Model "Workout_model" initialized
INFO - 2025-05-11 16:19:34 --> Config Class Initialized
INFO - 2025-05-11 16:19:34 --> Hooks Class Initialized
DEBUG - 2025-05-11 16:19:34 --> UTF-8 Support Enabled
INFO - 2025-05-11 16:19:34 --> Utf8 Class Initialized
INFO - 2025-05-11 16:19:34 --> URI Class Initialized
INFO - 2025-05-11 16:19:34 --> Router Class Initialized
INFO - 2025-05-11 16:19:34 --> Output Class Initialized
INFO - 2025-05-11 16:19:34 --> Security Class Initialized
DEBUG - 2025-05-11 16:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 16:19:34 --> Input Class Initialized
INFO - 2025-05-11 16:19:34 --> Language Class Initialized
INFO - 2025-05-11 16:19:34 --> Loader Class Initialized
INFO - 2025-05-11 16:19:34 --> Helper loaded: url_helper
INFO - 2025-05-11 16:19:34 --> Helper loaded: form_helper
INFO - 2025-05-11 16:19:34 --> Database Driver Class Initialized
DEBUG - 2025-05-11 16:19:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 16:19:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 16:19:34 --> Controller Class Initialized
INFO - 2025-05-11 16:19:34 --> Model "Workout_model" initialized
INFO - 2025-05-11 16:19:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-11 16:19:34 --> Final output sent to browser
DEBUG - 2025-05-11 16:19:34 --> Total execution time: 0.0556
INFO - 2025-05-11 16:19:59 --> Config Class Initialized
INFO - 2025-05-11 16:19:59 --> Hooks Class Initialized
DEBUG - 2025-05-11 16:19:59 --> UTF-8 Support Enabled
INFO - 2025-05-11 16:19:59 --> Utf8 Class Initialized
INFO - 2025-05-11 16:19:59 --> URI Class Initialized
INFO - 2025-05-11 16:19:59 --> Router Class Initialized
INFO - 2025-05-11 16:19:59 --> Output Class Initialized
INFO - 2025-05-11 16:19:59 --> Security Class Initialized
DEBUG - 2025-05-11 16:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 16:19:59 --> Input Class Initialized
INFO - 2025-05-11 16:19:59 --> Language Class Initialized
INFO - 2025-05-11 16:19:59 --> Loader Class Initialized
INFO - 2025-05-11 16:19:59 --> Helper loaded: url_helper
INFO - 2025-05-11 16:19:59 --> Helper loaded: form_helper
INFO - 2025-05-11 16:19:59 --> Database Driver Class Initialized
DEBUG - 2025-05-11 16:19:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 16:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 16:19:59 --> Controller Class Initialized
INFO - 2025-05-11 16:19:59 --> Model "Workout_model" initialized
INFO - 2025-05-11 16:19:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-11 16:19:59 --> Final output sent to browser
DEBUG - 2025-05-11 16:19:59 --> Total execution time: 0.0531
INFO - 2025-05-11 16:20:11 --> Config Class Initialized
INFO - 2025-05-11 16:20:11 --> Hooks Class Initialized
DEBUG - 2025-05-11 16:20:11 --> UTF-8 Support Enabled
INFO - 2025-05-11 16:20:11 --> Utf8 Class Initialized
INFO - 2025-05-11 16:20:11 --> URI Class Initialized
INFO - 2025-05-11 16:20:11 --> Router Class Initialized
INFO - 2025-05-11 16:20:11 --> Output Class Initialized
INFO - 2025-05-11 16:20:11 --> Security Class Initialized
DEBUG - 2025-05-11 16:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 16:20:11 --> Input Class Initialized
INFO - 2025-05-11 16:20:11 --> Language Class Initialized
INFO - 2025-05-11 16:20:11 --> Loader Class Initialized
INFO - 2025-05-11 16:20:11 --> Helper loaded: url_helper
INFO - 2025-05-11 16:20:11 --> Helper loaded: form_helper
INFO - 2025-05-11 16:20:11 --> Database Driver Class Initialized
DEBUG - 2025-05-11 16:20:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 16:20:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 16:20:11 --> Controller Class Initialized
INFO - 2025-05-11 16:20:11 --> Model "Workout_model" initialized
INFO - 2025-05-11 16:20:11 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/start.php
INFO - 2025-05-11 16:20:11 --> Final output sent to browser
DEBUG - 2025-05-11 16:20:11 --> Total execution time: 0.0520
INFO - 2025-05-11 16:20:13 --> Config Class Initialized
INFO - 2025-05-11 16:20:13 --> Hooks Class Initialized
DEBUG - 2025-05-11 16:20:13 --> UTF-8 Support Enabled
INFO - 2025-05-11 16:20:13 --> Utf8 Class Initialized
INFO - 2025-05-11 16:20:13 --> URI Class Initialized
INFO - 2025-05-11 16:20:13 --> Router Class Initialized
INFO - 2025-05-11 16:20:13 --> Output Class Initialized
INFO - 2025-05-11 16:20:13 --> Security Class Initialized
DEBUG - 2025-05-11 16:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 16:20:13 --> Input Class Initialized
INFO - 2025-05-11 16:20:13 --> Language Class Initialized
INFO - 2025-05-11 16:20:13 --> Loader Class Initialized
INFO - 2025-05-11 16:20:13 --> Helper loaded: url_helper
INFO - 2025-05-11 16:20:13 --> Helper loaded: form_helper
INFO - 2025-05-11 16:20:13 --> Database Driver Class Initialized
DEBUG - 2025-05-11 16:20:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 16:20:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 16:20:13 --> Controller Class Initialized
INFO - 2025-05-11 16:20:13 --> Model "Workout_model" initialized
INFO - 2025-05-11 16:20:13 --> Final output sent to browser
DEBUG - 2025-05-11 16:20:13 --> Total execution time: 0.0479
INFO - 2025-05-11 16:20:13 --> Config Class Initialized
INFO - 2025-05-11 16:20:13 --> Hooks Class Initialized
DEBUG - 2025-05-11 16:20:13 --> UTF-8 Support Enabled
INFO - 2025-05-11 16:20:13 --> Utf8 Class Initialized
INFO - 2025-05-11 16:20:13 --> URI Class Initialized
INFO - 2025-05-11 16:20:13 --> Router Class Initialized
INFO - 2025-05-11 16:20:13 --> Output Class Initialized
INFO - 2025-05-11 16:20:13 --> Security Class Initialized
DEBUG - 2025-05-11 16:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 16:20:13 --> Input Class Initialized
INFO - 2025-05-11 16:20:13 --> Language Class Initialized
INFO - 2025-05-11 16:20:13 --> Loader Class Initialized
INFO - 2025-05-11 16:20:13 --> Helper loaded: url_helper
INFO - 2025-05-11 16:20:13 --> Helper loaded: form_helper
INFO - 2025-05-11 16:20:13 --> Database Driver Class Initialized
DEBUG - 2025-05-11 16:20:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 16:20:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 16:20:13 --> Controller Class Initialized
INFO - 2025-05-11 16:20:13 --> Model "Workout_model" initialized
INFO - 2025-05-11 16:20:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-11 16:20:13 --> Final output sent to browser
DEBUG - 2025-05-11 16:20:13 --> Total execution time: 0.0576
INFO - 2025-05-11 16:20:17 --> Config Class Initialized
INFO - 2025-05-11 16:20:17 --> Hooks Class Initialized
DEBUG - 2025-05-11 16:20:17 --> UTF-8 Support Enabled
INFO - 2025-05-11 16:20:17 --> Utf8 Class Initialized
INFO - 2025-05-11 16:20:17 --> URI Class Initialized
INFO - 2025-05-11 16:20:17 --> Router Class Initialized
INFO - 2025-05-11 16:20:17 --> Output Class Initialized
INFO - 2025-05-11 16:20:17 --> Security Class Initialized
DEBUG - 2025-05-11 16:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 16:20:17 --> Input Class Initialized
INFO - 2025-05-11 16:20:17 --> Language Class Initialized
INFO - 2025-05-11 16:20:17 --> Loader Class Initialized
INFO - 2025-05-11 16:20:17 --> Helper loaded: url_helper
INFO - 2025-05-11 16:20:17 --> Helper loaded: form_helper
INFO - 2025-05-11 16:20:17 --> Database Driver Class Initialized
DEBUG - 2025-05-11 16:20:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 16:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 16:20:17 --> Controller Class Initialized
INFO - 2025-05-11 16:20:17 --> Model "Workout_model" initialized
INFO - 2025-05-11 16:20:17 --> Config Class Initialized
INFO - 2025-05-11 16:20:17 --> Hooks Class Initialized
DEBUG - 2025-05-11 16:20:17 --> UTF-8 Support Enabled
INFO - 2025-05-11 16:20:17 --> Utf8 Class Initialized
INFO - 2025-05-11 16:20:17 --> URI Class Initialized
INFO - 2025-05-11 16:20:17 --> Router Class Initialized
INFO - 2025-05-11 16:20:17 --> Output Class Initialized
INFO - 2025-05-11 16:20:17 --> Security Class Initialized
DEBUG - 2025-05-11 16:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 16:20:17 --> Input Class Initialized
INFO - 2025-05-11 16:20:17 --> Language Class Initialized
INFO - 2025-05-11 16:20:17 --> Loader Class Initialized
INFO - 2025-05-11 16:20:17 --> Helper loaded: url_helper
INFO - 2025-05-11 16:20:17 --> Helper loaded: form_helper
INFO - 2025-05-11 16:20:17 --> Database Driver Class Initialized
DEBUG - 2025-05-11 16:20:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 16:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 16:20:17 --> Controller Class Initialized
INFO - 2025-05-11 16:20:17 --> Model "Workout_model" initialized
INFO - 2025-05-11 16:20:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-11 16:20:17 --> Final output sent to browser
DEBUG - 2025-05-11 16:20:17 --> Total execution time: 0.0429
INFO - 2025-05-11 16:20:22 --> Config Class Initialized
INFO - 2025-05-11 16:20:22 --> Hooks Class Initialized
DEBUG - 2025-05-11 16:20:22 --> UTF-8 Support Enabled
INFO - 2025-05-11 16:20:22 --> Utf8 Class Initialized
INFO - 2025-05-11 16:20:22 --> URI Class Initialized
INFO - 2025-05-11 16:20:22 --> Router Class Initialized
INFO - 2025-05-11 16:20:22 --> Output Class Initialized
INFO - 2025-05-11 16:20:22 --> Security Class Initialized
DEBUG - 2025-05-11 16:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 16:20:22 --> Input Class Initialized
INFO - 2025-05-11 16:20:22 --> Language Class Initialized
INFO - 2025-05-11 16:20:22 --> Loader Class Initialized
INFO - 2025-05-11 16:20:22 --> Helper loaded: url_helper
INFO - 2025-05-11 16:20:22 --> Helper loaded: form_helper
INFO - 2025-05-11 16:20:22 --> Database Driver Class Initialized
DEBUG - 2025-05-11 16:20:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 16:20:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 16:20:22 --> Controller Class Initialized
INFO - 2025-05-11 16:20:22 --> Model "Workout_model" initialized
INFO - 2025-05-11 16:20:22 --> Config Class Initialized
INFO - 2025-05-11 16:20:22 --> Hooks Class Initialized
DEBUG - 2025-05-11 16:20:22 --> UTF-8 Support Enabled
INFO - 2025-05-11 16:20:22 --> Utf8 Class Initialized
INFO - 2025-05-11 16:20:22 --> URI Class Initialized
INFO - 2025-05-11 16:20:22 --> Router Class Initialized
INFO - 2025-05-11 16:20:22 --> Output Class Initialized
INFO - 2025-05-11 16:20:22 --> Security Class Initialized
DEBUG - 2025-05-11 16:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 16:20:22 --> Input Class Initialized
INFO - 2025-05-11 16:20:22 --> Language Class Initialized
INFO - 2025-05-11 16:20:22 --> Loader Class Initialized
INFO - 2025-05-11 16:20:23 --> Helper loaded: url_helper
INFO - 2025-05-11 16:20:23 --> Helper loaded: form_helper
INFO - 2025-05-11 16:20:23 --> Database Driver Class Initialized
DEBUG - 2025-05-11 16:20:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 16:20:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 16:20:23 --> Controller Class Initialized
INFO - 2025-05-11 16:20:23 --> Model "Workout_model" initialized
INFO - 2025-05-11 16:20:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-11 16:20:23 --> Final output sent to browser
DEBUG - 2025-05-11 16:20:23 --> Total execution time: 0.0662
INFO - 2025-05-11 16:20:25 --> Config Class Initialized
INFO - 2025-05-11 16:20:25 --> Hooks Class Initialized
DEBUG - 2025-05-11 16:20:25 --> UTF-8 Support Enabled
INFO - 2025-05-11 16:20:25 --> Utf8 Class Initialized
INFO - 2025-05-11 16:20:25 --> URI Class Initialized
INFO - 2025-05-11 16:20:25 --> Router Class Initialized
INFO - 2025-05-11 16:20:25 --> Output Class Initialized
INFO - 2025-05-11 16:20:25 --> Security Class Initialized
DEBUG - 2025-05-11 16:20:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 16:20:25 --> Input Class Initialized
INFO - 2025-05-11 16:20:25 --> Language Class Initialized
INFO - 2025-05-11 16:20:25 --> Loader Class Initialized
INFO - 2025-05-11 16:20:25 --> Helper loaded: url_helper
INFO - 2025-05-11 16:20:25 --> Helper loaded: form_helper
INFO - 2025-05-11 16:20:25 --> Database Driver Class Initialized
DEBUG - 2025-05-11 16:20:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 16:20:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 16:20:25 --> Controller Class Initialized
INFO - 2025-05-11 16:20:25 --> Model "Workout_model" initialized
INFO - 2025-05-11 16:20:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-11 16:20:25 --> Final output sent to browser
DEBUG - 2025-05-11 16:20:25 --> Total execution time: 0.0681
INFO - 2025-05-11 16:20:27 --> Config Class Initialized
INFO - 2025-05-11 16:20:27 --> Hooks Class Initialized
DEBUG - 2025-05-11 16:20:27 --> UTF-8 Support Enabled
INFO - 2025-05-11 16:20:27 --> Utf8 Class Initialized
INFO - 2025-05-11 16:20:27 --> URI Class Initialized
INFO - 2025-05-11 16:20:27 --> Router Class Initialized
INFO - 2025-05-11 16:20:27 --> Output Class Initialized
INFO - 2025-05-11 16:20:27 --> Security Class Initialized
DEBUG - 2025-05-11 16:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 16:20:27 --> Input Class Initialized
INFO - 2025-05-11 16:20:27 --> Language Class Initialized
INFO - 2025-05-11 16:20:27 --> Loader Class Initialized
INFO - 2025-05-11 16:20:27 --> Helper loaded: url_helper
INFO - 2025-05-11 16:20:27 --> Helper loaded: form_helper
INFO - 2025-05-11 16:20:27 --> Database Driver Class Initialized
DEBUG - 2025-05-11 16:20:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 16:20:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 16:20:27 --> Controller Class Initialized
INFO - 2025-05-11 16:20:27 --> Model "Workout_model" initialized
INFO - 2025-05-11 16:20:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-11 16:20:27 --> Final output sent to browser
DEBUG - 2025-05-11 16:20:27 --> Total execution time: 0.0662
INFO - 2025-05-11 16:20:28 --> Config Class Initialized
INFO - 2025-05-11 16:20:28 --> Hooks Class Initialized
DEBUG - 2025-05-11 16:20:28 --> UTF-8 Support Enabled
INFO - 2025-05-11 16:20:28 --> Utf8 Class Initialized
INFO - 2025-05-11 16:20:28 --> URI Class Initialized
INFO - 2025-05-11 16:20:28 --> Router Class Initialized
INFO - 2025-05-11 16:20:28 --> Output Class Initialized
INFO - 2025-05-11 16:20:28 --> Security Class Initialized
DEBUG - 2025-05-11 16:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 16:20:28 --> Input Class Initialized
INFO - 2025-05-11 16:20:28 --> Language Class Initialized
INFO - 2025-05-11 16:20:28 --> Loader Class Initialized
INFO - 2025-05-11 16:20:28 --> Helper loaded: url_helper
INFO - 2025-05-11 16:20:28 --> Helper loaded: form_helper
INFO - 2025-05-11 16:20:28 --> Database Driver Class Initialized
DEBUG - 2025-05-11 16:20:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 16:20:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 16:20:28 --> Controller Class Initialized
INFO - 2025-05-11 16:20:28 --> Model "Workout_model" initialized
ERROR - 2025-05-11 16:20:28 --> 404 Page Not Found: 
INFO - 2025-05-11 16:20:35 --> Config Class Initialized
INFO - 2025-05-11 16:20:35 --> Hooks Class Initialized
DEBUG - 2025-05-11 16:20:35 --> UTF-8 Support Enabled
INFO - 2025-05-11 16:20:35 --> Utf8 Class Initialized
INFO - 2025-05-11 16:20:35 --> URI Class Initialized
DEBUG - 2025-05-11 16:20:35 --> No URI present. Default controller set.
INFO - 2025-05-11 16:20:35 --> Router Class Initialized
INFO - 2025-05-11 16:20:35 --> Output Class Initialized
INFO - 2025-05-11 16:20:35 --> Security Class Initialized
DEBUG - 2025-05-11 16:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 16:20:35 --> Input Class Initialized
INFO - 2025-05-11 16:20:35 --> Language Class Initialized
INFO - 2025-05-11 16:20:35 --> Loader Class Initialized
INFO - 2025-05-11 16:20:35 --> Helper loaded: url_helper
INFO - 2025-05-11 16:20:35 --> Helper loaded: form_helper
INFO - 2025-05-11 16:20:35 --> Database Driver Class Initialized
DEBUG - 2025-05-11 16:20:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 16:20:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 16:20:35 --> Controller Class Initialized
INFO - 2025-05-11 16:20:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-11 16:20:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-11 16:20:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-11 16:20:35 --> Final output sent to browser
DEBUG - 2025-05-11 16:20:35 --> Total execution time: 0.0562
INFO - 2025-05-11 16:20:37 --> Config Class Initialized
INFO - 2025-05-11 16:20:37 --> Hooks Class Initialized
DEBUG - 2025-05-11 16:20:37 --> UTF-8 Support Enabled
INFO - 2025-05-11 16:20:37 --> Utf8 Class Initialized
INFO - 2025-05-11 16:20:37 --> URI Class Initialized
INFO - 2025-05-11 16:20:37 --> Router Class Initialized
INFO - 2025-05-11 16:20:37 --> Output Class Initialized
INFO - 2025-05-11 16:20:37 --> Security Class Initialized
DEBUG - 2025-05-11 16:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 16:20:37 --> Input Class Initialized
INFO - 2025-05-11 16:20:37 --> Language Class Initialized
INFO - 2025-05-11 16:20:37 --> Loader Class Initialized
INFO - 2025-05-11 16:20:37 --> Helper loaded: url_helper
INFO - 2025-05-11 16:20:37 --> Helper loaded: form_helper
INFO - 2025-05-11 16:20:37 --> Database Driver Class Initialized
DEBUG - 2025-05-11 16:20:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 16:20:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 16:20:37 --> Controller Class Initialized
INFO - 2025-05-11 16:20:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-11 16:20:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/artikel.php
INFO - 2025-05-11 16:20:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-11 16:20:37 --> Final output sent to browser
DEBUG - 2025-05-11 16:20:37 --> Total execution time: 0.0669
INFO - 2025-05-11 16:20:38 --> Config Class Initialized
INFO - 2025-05-11 16:20:38 --> Hooks Class Initialized
DEBUG - 2025-05-11 16:20:38 --> UTF-8 Support Enabled
INFO - 2025-05-11 16:20:38 --> Utf8 Class Initialized
INFO - 2025-05-11 16:20:38 --> URI Class Initialized
INFO - 2025-05-11 16:20:38 --> Router Class Initialized
INFO - 2025-05-11 16:20:38 --> Output Class Initialized
INFO - 2025-05-11 16:20:38 --> Security Class Initialized
DEBUG - 2025-05-11 16:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 16:20:38 --> Input Class Initialized
INFO - 2025-05-11 16:20:38 --> Language Class Initialized
INFO - 2025-05-11 16:20:38 --> Loader Class Initialized
INFO - 2025-05-11 16:20:38 --> Helper loaded: url_helper
INFO - 2025-05-11 16:20:38 --> Helper loaded: form_helper
INFO - 2025-05-11 16:20:38 --> Database Driver Class Initialized
DEBUG - 2025-05-11 16:20:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 16:20:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 16:20:38 --> Controller Class Initialized
INFO - 2025-05-11 16:20:38 --> Model "User_model" initialized
INFO - 2025-05-11 16:20:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-11 16:20:38 --> Final output sent to browser
DEBUG - 2025-05-11 16:20:38 --> Total execution time: 0.0422
INFO - 2025-05-11 16:23:35 --> Config Class Initialized
INFO - 2025-05-11 16:23:35 --> Hooks Class Initialized
DEBUG - 2025-05-11 16:23:35 --> UTF-8 Support Enabled
INFO - 2025-05-11 16:23:35 --> Utf8 Class Initialized
INFO - 2025-05-11 16:23:35 --> URI Class Initialized
INFO - 2025-05-11 16:23:35 --> Router Class Initialized
INFO - 2025-05-11 16:23:35 --> Output Class Initialized
INFO - 2025-05-11 16:23:35 --> Security Class Initialized
DEBUG - 2025-05-11 16:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 16:23:35 --> Input Class Initialized
INFO - 2025-05-11 16:23:35 --> Language Class Initialized
INFO - 2025-05-11 16:23:35 --> Loader Class Initialized
INFO - 2025-05-11 16:23:35 --> Helper loaded: url_helper
INFO - 2025-05-11 16:23:35 --> Helper loaded: form_helper
INFO - 2025-05-11 16:23:35 --> Database Driver Class Initialized
DEBUG - 2025-05-11 16:23:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 16:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 16:23:35 --> Controller Class Initialized
INFO - 2025-05-11 16:23:35 --> Model "User_model" initialized
INFO - 2025-05-11 16:23:35 --> Config Class Initialized
INFO - 2025-05-11 16:23:35 --> Hooks Class Initialized
DEBUG - 2025-05-11 16:23:35 --> UTF-8 Support Enabled
INFO - 2025-05-11 16:23:35 --> Utf8 Class Initialized
INFO - 2025-05-11 16:23:35 --> URI Class Initialized
INFO - 2025-05-11 16:23:35 --> Router Class Initialized
INFO - 2025-05-11 16:23:35 --> Output Class Initialized
INFO - 2025-05-11 16:23:35 --> Security Class Initialized
DEBUG - 2025-05-11 16:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 16:23:35 --> Input Class Initialized
INFO - 2025-05-11 16:23:35 --> Language Class Initialized
INFO - 2025-05-11 16:23:35 --> Loader Class Initialized
INFO - 2025-05-11 16:23:35 --> Helper loaded: url_helper
INFO - 2025-05-11 16:23:35 --> Helper loaded: form_helper
INFO - 2025-05-11 16:23:35 --> Database Driver Class Initialized
DEBUG - 2025-05-11 16:23:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 16:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 16:23:35 --> Controller Class Initialized
INFO - 2025-05-11 16:23:35 --> Model "User_model" initialized
INFO - 2025-05-11 16:23:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard.php
INFO - 2025-05-11 16:23:35 --> Final output sent to browser
DEBUG - 2025-05-11 16:23:35 --> Total execution time: 0.0739
INFO - 2025-05-11 16:28:41 --> Config Class Initialized
INFO - 2025-05-11 16:28:41 --> Hooks Class Initialized
DEBUG - 2025-05-11 16:28:41 --> UTF-8 Support Enabled
INFO - 2025-05-11 16:28:41 --> Utf8 Class Initialized
INFO - 2025-05-11 16:28:41 --> URI Class Initialized
INFO - 2025-05-11 16:28:41 --> Router Class Initialized
INFO - 2025-05-11 16:28:41 --> Output Class Initialized
INFO - 2025-05-11 16:28:41 --> Security Class Initialized
DEBUG - 2025-05-11 16:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 16:28:41 --> Input Class Initialized
INFO - 2025-05-11 16:28:41 --> Language Class Initialized
INFO - 2025-05-11 16:28:41 --> Loader Class Initialized
INFO - 2025-05-11 16:28:41 --> Helper loaded: url_helper
INFO - 2025-05-11 16:28:41 --> Helper loaded: form_helper
INFO - 2025-05-11 16:28:41 --> Database Driver Class Initialized
DEBUG - 2025-05-11 16:28:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 16:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 16:28:41 --> Controller Class Initialized
INFO - 2025-05-11 16:28:41 --> Model "Workout_model" initialized
INFO - 2025-05-11 16:28:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-11 16:28:41 --> Final output sent to browser
DEBUG - 2025-05-11 16:28:41 --> Total execution time: 0.0575
INFO - 2025-05-11 16:28:56 --> Config Class Initialized
INFO - 2025-05-11 16:28:56 --> Hooks Class Initialized
DEBUG - 2025-05-11 16:28:56 --> UTF-8 Support Enabled
INFO - 2025-05-11 16:28:56 --> Utf8 Class Initialized
INFO - 2025-05-11 16:28:56 --> URI Class Initialized
INFO - 2025-05-11 16:28:56 --> Router Class Initialized
INFO - 2025-05-11 16:28:56 --> Output Class Initialized
INFO - 2025-05-11 16:28:56 --> Security Class Initialized
DEBUG - 2025-05-11 16:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 16:28:56 --> Input Class Initialized
INFO - 2025-05-11 16:28:56 --> Language Class Initialized
INFO - 2025-05-11 16:28:56 --> Loader Class Initialized
INFO - 2025-05-11 16:28:56 --> Helper loaded: url_helper
INFO - 2025-05-11 16:28:56 --> Helper loaded: form_helper
INFO - 2025-05-11 16:28:56 --> Database Driver Class Initialized
DEBUG - 2025-05-11 16:28:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 16:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 16:28:56 --> Controller Class Initialized
INFO - 2025-05-11 16:28:56 --> Model "User_model" initialized
INFO - 2025-05-11 16:28:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard.php
INFO - 2025-05-11 16:28:56 --> Final output sent to browser
DEBUG - 2025-05-11 16:28:56 --> Total execution time: 0.0624
INFO - 2025-05-11 16:29:01 --> Config Class Initialized
INFO - 2025-05-11 16:29:01 --> Hooks Class Initialized
DEBUG - 2025-05-11 16:29:01 --> UTF-8 Support Enabled
INFO - 2025-05-11 16:29:01 --> Utf8 Class Initialized
INFO - 2025-05-11 16:29:01 --> URI Class Initialized
INFO - 2025-05-11 16:29:01 --> Router Class Initialized
INFO - 2025-05-11 16:29:01 --> Output Class Initialized
INFO - 2025-05-11 16:29:01 --> Security Class Initialized
DEBUG - 2025-05-11 16:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 16:29:01 --> Input Class Initialized
INFO - 2025-05-11 16:29:01 --> Language Class Initialized
INFO - 2025-05-11 16:29:01 --> Loader Class Initialized
INFO - 2025-05-11 16:29:01 --> Helper loaded: url_helper
INFO - 2025-05-11 16:29:01 --> Helper loaded: form_helper
INFO - 2025-05-11 16:29:01 --> Database Driver Class Initialized
DEBUG - 2025-05-11 16:29:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 16:29:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 16:29:01 --> Controller Class Initialized
INFO - 2025-05-11 16:29:01 --> Model "Workout_model" initialized
INFO - 2025-05-11 16:29:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-11 16:29:01 --> Final output sent to browser
DEBUG - 2025-05-11 16:29:01 --> Total execution time: 0.0532
INFO - 2025-05-11 16:32:10 --> Config Class Initialized
INFO - 2025-05-11 16:32:10 --> Hooks Class Initialized
DEBUG - 2025-05-11 16:32:10 --> UTF-8 Support Enabled
INFO - 2025-05-11 16:32:10 --> Utf8 Class Initialized
INFO - 2025-05-11 16:32:10 --> URI Class Initialized
INFO - 2025-05-11 16:32:10 --> Router Class Initialized
INFO - 2025-05-11 16:32:10 --> Output Class Initialized
INFO - 2025-05-11 16:32:10 --> Security Class Initialized
DEBUG - 2025-05-11 16:32:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 16:32:10 --> Input Class Initialized
INFO - 2025-05-11 16:32:10 --> Language Class Initialized
INFO - 2025-05-11 16:32:10 --> Loader Class Initialized
INFO - 2025-05-11 16:32:10 --> Helper loaded: url_helper
INFO - 2025-05-11 16:32:10 --> Helper loaded: form_helper
INFO - 2025-05-11 16:32:10 --> Database Driver Class Initialized
DEBUG - 2025-05-11 16:32:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 16:32:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 16:32:10 --> Controller Class Initialized
INFO - 2025-05-11 16:32:10 --> Model "User_model" initialized
INFO - 2025-05-11 16:32:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard.php
INFO - 2025-05-11 16:32:10 --> Final output sent to browser
DEBUG - 2025-05-11 16:32:10 --> Total execution time: 0.0811
INFO - 2025-05-11 16:32:21 --> Config Class Initialized
INFO - 2025-05-11 16:32:21 --> Hooks Class Initialized
DEBUG - 2025-05-11 16:32:21 --> UTF-8 Support Enabled
INFO - 2025-05-11 16:32:21 --> Utf8 Class Initialized
INFO - 2025-05-11 16:32:21 --> URI Class Initialized
INFO - 2025-05-11 16:32:21 --> Router Class Initialized
INFO - 2025-05-11 16:32:21 --> Output Class Initialized
INFO - 2025-05-11 16:32:21 --> Security Class Initialized
DEBUG - 2025-05-11 16:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 16:32:21 --> Input Class Initialized
INFO - 2025-05-11 16:32:21 --> Language Class Initialized
INFO - 2025-05-11 16:32:21 --> Loader Class Initialized
INFO - 2025-05-11 16:32:21 --> Helper loaded: url_helper
INFO - 2025-05-11 16:32:21 --> Helper loaded: form_helper
INFO - 2025-05-11 16:32:21 --> Database Driver Class Initialized
DEBUG - 2025-05-11 16:32:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 16:32:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 16:32:21 --> Controller Class Initialized
INFO - 2025-05-11 16:32:21 --> Model "Sports_model" initialized
INFO - 2025-05-11 16:32:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\sports/index.php
INFO - 2025-05-11 16:32:21 --> Final output sent to browser
DEBUG - 2025-05-11 16:32:21 --> Total execution time: 0.1769
INFO - 2025-05-11 16:32:25 --> Config Class Initialized
INFO - 2025-05-11 16:32:25 --> Hooks Class Initialized
DEBUG - 2025-05-11 16:32:25 --> UTF-8 Support Enabled
INFO - 2025-05-11 16:32:25 --> Utf8 Class Initialized
INFO - 2025-05-11 16:32:25 --> URI Class Initialized
INFO - 2025-05-11 16:32:25 --> Router Class Initialized
INFO - 2025-05-11 16:32:25 --> Output Class Initialized
INFO - 2025-05-11 16:32:25 --> Security Class Initialized
DEBUG - 2025-05-11 16:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 16:32:25 --> Input Class Initialized
INFO - 2025-05-11 16:32:25 --> Language Class Initialized
INFO - 2025-05-11 16:32:25 --> Loader Class Initialized
INFO - 2025-05-11 16:32:25 --> Helper loaded: url_helper
INFO - 2025-05-11 16:32:25 --> Helper loaded: form_helper
INFO - 2025-05-11 16:32:25 --> Database Driver Class Initialized
DEBUG - 2025-05-11 16:32:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 16:32:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 16:32:25 --> Controller Class Initialized
INFO - 2025-05-11 16:32:25 --> Model "Sports_model" initialized
INFO - 2025-05-11 16:32:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\sports/level.php
INFO - 2025-05-11 16:32:25 --> Final output sent to browser
DEBUG - 2025-05-11 16:32:25 --> Total execution time: 0.0854
INFO - 2025-05-11 16:34:24 --> Config Class Initialized
INFO - 2025-05-11 16:34:24 --> Hooks Class Initialized
DEBUG - 2025-05-11 16:34:24 --> UTF-8 Support Enabled
INFO - 2025-05-11 16:34:24 --> Utf8 Class Initialized
INFO - 2025-05-11 16:34:24 --> URI Class Initialized
INFO - 2025-05-11 16:34:24 --> Router Class Initialized
INFO - 2025-05-11 16:34:24 --> Output Class Initialized
INFO - 2025-05-11 16:34:24 --> Security Class Initialized
DEBUG - 2025-05-11 16:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 16:34:24 --> Input Class Initialized
INFO - 2025-05-11 16:34:24 --> Language Class Initialized
INFO - 2025-05-11 16:34:24 --> Loader Class Initialized
INFO - 2025-05-11 16:34:24 --> Helper loaded: url_helper
INFO - 2025-05-11 16:34:24 --> Helper loaded: form_helper
INFO - 2025-05-11 16:34:24 --> Database Driver Class Initialized
DEBUG - 2025-05-11 16:34:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 16:34:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 16:34:24 --> Controller Class Initialized
INFO - 2025-05-11 16:34:24 --> Model "User_model" initialized
INFO - 2025-05-11 16:34:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard.php
INFO - 2025-05-11 16:34:24 --> Final output sent to browser
DEBUG - 2025-05-11 16:34:24 --> Total execution time: 0.0666
INFO - 2025-05-11 16:40:20 --> Config Class Initialized
INFO - 2025-05-11 16:40:20 --> Hooks Class Initialized
DEBUG - 2025-05-11 16:40:20 --> UTF-8 Support Enabled
INFO - 2025-05-11 16:40:20 --> Utf8 Class Initialized
INFO - 2025-05-11 16:40:20 --> URI Class Initialized
INFO - 2025-05-11 16:40:20 --> Router Class Initialized
INFO - 2025-05-11 16:40:20 --> Output Class Initialized
INFO - 2025-05-11 16:40:20 --> Security Class Initialized
DEBUG - 2025-05-11 16:40:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 16:40:20 --> Input Class Initialized
INFO - 2025-05-11 16:40:20 --> Language Class Initialized
INFO - 2025-05-11 16:40:20 --> Loader Class Initialized
INFO - 2025-05-11 16:40:20 --> Helper loaded: url_helper
INFO - 2025-05-11 16:40:20 --> Helper loaded: form_helper
INFO - 2025-05-11 16:40:20 --> Database Driver Class Initialized
DEBUG - 2025-05-11 16:40:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 16:40:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 16:40:20 --> Controller Class Initialized
INFO - 2025-05-11 16:40:20 --> Model "User_model" initialized
INFO - 2025-05-11 16:40:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard.php
INFO - 2025-05-11 16:40:20 --> Final output sent to browser
DEBUG - 2025-05-11 16:40:20 --> Total execution time: 0.0525
INFO - 2025-05-11 16:40:47 --> Config Class Initialized
INFO - 2025-05-11 16:40:47 --> Hooks Class Initialized
DEBUG - 2025-05-11 16:40:47 --> UTF-8 Support Enabled
INFO - 2025-05-11 16:40:47 --> Utf8 Class Initialized
INFO - 2025-05-11 16:40:47 --> URI Class Initialized
INFO - 2025-05-11 16:40:47 --> Router Class Initialized
INFO - 2025-05-11 16:40:47 --> Output Class Initialized
INFO - 2025-05-11 16:40:47 --> Security Class Initialized
DEBUG - 2025-05-11 16:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 16:40:47 --> Input Class Initialized
INFO - 2025-05-11 16:40:47 --> Language Class Initialized
INFO - 2025-05-11 16:40:47 --> Loader Class Initialized
INFO - 2025-05-11 16:40:47 --> Helper loaded: url_helper
INFO - 2025-05-11 16:40:47 --> Helper loaded: form_helper
INFO - 2025-05-11 16:40:47 --> Database Driver Class Initialized
DEBUG - 2025-05-11 16:40:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 16:40:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 16:40:47 --> Controller Class Initialized
INFO - 2025-05-11 16:40:47 --> Model "User_model" initialized
INFO - 2025-05-11 16:40:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard.php
INFO - 2025-05-11 16:40:47 --> Final output sent to browser
DEBUG - 2025-05-11 16:40:47 --> Total execution time: 0.0675
INFO - 2025-05-11 16:41:05 --> Config Class Initialized
INFO - 2025-05-11 16:41:05 --> Hooks Class Initialized
DEBUG - 2025-05-11 16:41:05 --> UTF-8 Support Enabled
INFO - 2025-05-11 16:41:05 --> Utf8 Class Initialized
INFO - 2025-05-11 16:41:05 --> URI Class Initialized
INFO - 2025-05-11 16:41:05 --> Router Class Initialized
INFO - 2025-05-11 16:41:05 --> Output Class Initialized
INFO - 2025-05-11 16:41:05 --> Security Class Initialized
DEBUG - 2025-05-11 16:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 16:41:05 --> Input Class Initialized
INFO - 2025-05-11 16:41:05 --> Language Class Initialized
INFO - 2025-05-11 16:41:05 --> Loader Class Initialized
INFO - 2025-05-11 16:41:05 --> Helper loaded: url_helper
INFO - 2025-05-11 16:41:05 --> Helper loaded: form_helper
INFO - 2025-05-11 16:41:05 --> Database Driver Class Initialized
DEBUG - 2025-05-11 16:41:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 16:41:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 16:41:05 --> Controller Class Initialized
INFO - 2025-05-11 16:41:05 --> Model "User_model" initialized
INFO - 2025-05-11 16:41:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard.php
INFO - 2025-05-11 16:41:05 --> Final output sent to browser
DEBUG - 2025-05-11 16:41:05 --> Total execution time: 0.0680
INFO - 2025-05-11 16:52:40 --> Config Class Initialized
INFO - 2025-05-11 16:52:40 --> Hooks Class Initialized
DEBUG - 2025-05-11 16:52:40 --> UTF-8 Support Enabled
INFO - 2025-05-11 16:52:40 --> Utf8 Class Initialized
INFO - 2025-05-11 16:52:40 --> URI Class Initialized
INFO - 2025-05-11 16:52:40 --> Router Class Initialized
INFO - 2025-05-11 16:52:40 --> Output Class Initialized
INFO - 2025-05-11 16:52:40 --> Security Class Initialized
DEBUG - 2025-05-11 16:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 16:52:40 --> Input Class Initialized
INFO - 2025-05-11 16:52:40 --> Language Class Initialized
INFO - 2025-05-11 16:52:40 --> Loader Class Initialized
INFO - 2025-05-11 16:52:40 --> Helper loaded: url_helper
INFO - 2025-05-11 16:52:40 --> Helper loaded: form_helper
INFO - 2025-05-11 16:52:40 --> Database Driver Class Initialized
DEBUG - 2025-05-11 16:52:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 16:52:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 16:52:40 --> Controller Class Initialized
INFO - 2025-05-11 16:52:40 --> Model "User_model" initialized
ERROR - 2025-05-11 16:52:40 --> Severity: Warning --> Undefined variable $history C:\laragon\www\Project\fitnessrecord\application\views\dashboard.php 214
ERROR - 2025-05-11 16:52:40 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given C:\laragon\www\Project\fitnessrecord\application\views\dashboard.php 214
INFO - 2025-05-11 16:54:34 --> Config Class Initialized
INFO - 2025-05-11 16:54:34 --> Hooks Class Initialized
DEBUG - 2025-05-11 16:54:34 --> UTF-8 Support Enabled
INFO - 2025-05-11 16:54:34 --> Utf8 Class Initialized
INFO - 2025-05-11 16:54:34 --> URI Class Initialized
INFO - 2025-05-11 16:54:34 --> Router Class Initialized
INFO - 2025-05-11 16:54:34 --> Output Class Initialized
INFO - 2025-05-11 16:54:34 --> Security Class Initialized
DEBUG - 2025-05-11 16:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 16:54:34 --> Input Class Initialized
INFO - 2025-05-11 16:54:34 --> Language Class Initialized
INFO - 2025-05-11 16:54:34 --> Loader Class Initialized
INFO - 2025-05-11 16:54:34 --> Helper loaded: url_helper
INFO - 2025-05-11 16:54:34 --> Helper loaded: form_helper
INFO - 2025-05-11 16:54:34 --> Database Driver Class Initialized
DEBUG - 2025-05-11 16:54:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 16:54:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 16:54:34 --> Controller Class Initialized
INFO - 2025-05-11 16:54:34 --> Model "User_model" initialized
INFO - 2025-05-11 16:54:34 --> Model "Workout_model" initialized
INFO - 2025-05-11 16:54:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard.php
INFO - 2025-05-11 16:54:34 --> Final output sent to browser
DEBUG - 2025-05-11 16:54:34 --> Total execution time: 0.0529
INFO - 2025-05-11 16:55:04 --> Config Class Initialized
INFO - 2025-05-11 16:55:04 --> Hooks Class Initialized
DEBUG - 2025-05-11 16:55:04 --> UTF-8 Support Enabled
INFO - 2025-05-11 16:55:04 --> Utf8 Class Initialized
INFO - 2025-05-11 16:55:04 --> URI Class Initialized
INFO - 2025-05-11 16:55:04 --> Router Class Initialized
INFO - 2025-05-11 16:55:04 --> Output Class Initialized
INFO - 2025-05-11 16:55:04 --> Security Class Initialized
DEBUG - 2025-05-11 16:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 16:55:04 --> Input Class Initialized
INFO - 2025-05-11 16:55:04 --> Language Class Initialized
ERROR - 2025-05-11 16:55:04 --> 404 Page Not Found: Dashboard/workout
INFO - 2025-05-11 16:55:22 --> Config Class Initialized
INFO - 2025-05-11 16:55:22 --> Hooks Class Initialized
DEBUG - 2025-05-11 16:55:22 --> UTF-8 Support Enabled
INFO - 2025-05-11 16:55:22 --> Utf8 Class Initialized
INFO - 2025-05-11 16:55:22 --> URI Class Initialized
INFO - 2025-05-11 16:55:22 --> Router Class Initialized
INFO - 2025-05-11 16:55:22 --> Output Class Initialized
INFO - 2025-05-11 16:55:22 --> Security Class Initialized
DEBUG - 2025-05-11 16:55:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 16:55:22 --> Input Class Initialized
INFO - 2025-05-11 16:55:22 --> Language Class Initialized
INFO - 2025-05-11 16:55:22 --> Loader Class Initialized
INFO - 2025-05-11 16:55:22 --> Helper loaded: url_helper
INFO - 2025-05-11 16:55:22 --> Helper loaded: form_helper
INFO - 2025-05-11 16:55:22 --> Database Driver Class Initialized
DEBUG - 2025-05-11 16:55:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 16:55:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 16:55:22 --> Controller Class Initialized
INFO - 2025-05-11 16:55:22 --> Model "Workout_model" initialized
INFO - 2025-05-11 16:55:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-11 16:55:22 --> Final output sent to browser
DEBUG - 2025-05-11 16:55:22 --> Total execution time: 0.0645
INFO - 2025-05-11 16:55:24 --> Config Class Initialized
INFO - 2025-05-11 16:55:24 --> Hooks Class Initialized
DEBUG - 2025-05-11 16:55:24 --> UTF-8 Support Enabled
INFO - 2025-05-11 16:55:24 --> Utf8 Class Initialized
INFO - 2025-05-11 16:55:24 --> URI Class Initialized
INFO - 2025-05-11 16:55:24 --> Router Class Initialized
INFO - 2025-05-11 16:55:24 --> Output Class Initialized
INFO - 2025-05-11 16:55:24 --> Security Class Initialized
DEBUG - 2025-05-11 16:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 16:55:24 --> Input Class Initialized
INFO - 2025-05-11 16:55:24 --> Language Class Initialized
INFO - 2025-05-11 16:55:24 --> Loader Class Initialized
INFO - 2025-05-11 16:55:24 --> Helper loaded: url_helper
INFO - 2025-05-11 16:55:24 --> Helper loaded: form_helper
INFO - 2025-05-11 16:55:24 --> Database Driver Class Initialized
DEBUG - 2025-05-11 16:55:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 16:55:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 16:55:24 --> Controller Class Initialized
INFO - 2025-05-11 16:55:24 --> Model "Workout_model" initialized
INFO - 2025-05-11 16:55:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/add.php
INFO - 2025-05-11 16:55:24 --> Final output sent to browser
DEBUG - 2025-05-11 16:55:24 --> Total execution time: 0.0639
INFO - 2025-05-11 16:55:32 --> Config Class Initialized
INFO - 2025-05-11 16:55:32 --> Hooks Class Initialized
DEBUG - 2025-05-11 16:55:32 --> UTF-8 Support Enabled
INFO - 2025-05-11 16:55:32 --> Utf8 Class Initialized
INFO - 2025-05-11 16:55:32 --> URI Class Initialized
INFO - 2025-05-11 16:55:32 --> Router Class Initialized
INFO - 2025-05-11 16:55:32 --> Output Class Initialized
INFO - 2025-05-11 16:55:32 --> Security Class Initialized
DEBUG - 2025-05-11 16:55:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 16:55:32 --> Input Class Initialized
INFO - 2025-05-11 16:55:32 --> Language Class Initialized
INFO - 2025-05-11 16:55:32 --> Loader Class Initialized
INFO - 2025-05-11 16:55:32 --> Helper loaded: url_helper
INFO - 2025-05-11 16:55:32 --> Helper loaded: form_helper
INFO - 2025-05-11 16:55:32 --> Database Driver Class Initialized
DEBUG - 2025-05-11 16:55:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 16:55:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 16:55:32 --> Controller Class Initialized
INFO - 2025-05-11 16:55:32 --> Model "Workout_model" initialized
INFO - 2025-05-11 16:55:32 --> Config Class Initialized
INFO - 2025-05-11 16:55:32 --> Hooks Class Initialized
DEBUG - 2025-05-11 16:55:32 --> UTF-8 Support Enabled
INFO - 2025-05-11 16:55:32 --> Utf8 Class Initialized
INFO - 2025-05-11 16:55:32 --> URI Class Initialized
INFO - 2025-05-11 16:55:32 --> Router Class Initialized
INFO - 2025-05-11 16:55:32 --> Output Class Initialized
INFO - 2025-05-11 16:55:32 --> Security Class Initialized
DEBUG - 2025-05-11 16:55:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 16:55:32 --> Input Class Initialized
INFO - 2025-05-11 16:55:32 --> Language Class Initialized
INFO - 2025-05-11 16:55:32 --> Loader Class Initialized
INFO - 2025-05-11 16:55:32 --> Helper loaded: url_helper
INFO - 2025-05-11 16:55:32 --> Helper loaded: form_helper
INFO - 2025-05-11 16:55:32 --> Database Driver Class Initialized
DEBUG - 2025-05-11 16:55:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 16:55:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 16:55:32 --> Controller Class Initialized
INFO - 2025-05-11 16:55:32 --> Model "Workout_model" initialized
INFO - 2025-05-11 16:55:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-11 16:55:32 --> Final output sent to browser
DEBUG - 2025-05-11 16:55:32 --> Total execution time: 0.0676
INFO - 2025-05-11 16:55:33 --> Config Class Initialized
INFO - 2025-05-11 16:55:33 --> Hooks Class Initialized
DEBUG - 2025-05-11 16:55:33 --> UTF-8 Support Enabled
INFO - 2025-05-11 16:55:33 --> Utf8 Class Initialized
INFO - 2025-05-11 16:55:33 --> URI Class Initialized
INFO - 2025-05-11 16:55:33 --> Router Class Initialized
INFO - 2025-05-11 16:55:33 --> Output Class Initialized
INFO - 2025-05-11 16:55:33 --> Security Class Initialized
DEBUG - 2025-05-11 16:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 16:55:33 --> Input Class Initialized
INFO - 2025-05-11 16:55:33 --> Language Class Initialized
INFO - 2025-05-11 16:55:33 --> Loader Class Initialized
INFO - 2025-05-11 16:55:33 --> Helper loaded: url_helper
INFO - 2025-05-11 16:55:33 --> Helper loaded: form_helper
INFO - 2025-05-11 16:55:34 --> Database Driver Class Initialized
DEBUG - 2025-05-11 16:55:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 16:55:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 16:55:34 --> Controller Class Initialized
INFO - 2025-05-11 16:55:34 --> Model "Workout_model" initialized
INFO - 2025-05-11 16:55:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/start.php
INFO - 2025-05-11 16:55:34 --> Final output sent to browser
DEBUG - 2025-05-11 16:55:34 --> Total execution time: 0.0472
INFO - 2025-05-11 16:55:37 --> Config Class Initialized
INFO - 2025-05-11 16:55:37 --> Hooks Class Initialized
DEBUG - 2025-05-11 16:55:37 --> UTF-8 Support Enabled
INFO - 2025-05-11 16:55:37 --> Utf8 Class Initialized
INFO - 2025-05-11 16:55:37 --> URI Class Initialized
INFO - 2025-05-11 16:55:37 --> Router Class Initialized
INFO - 2025-05-11 16:55:37 --> Output Class Initialized
INFO - 2025-05-11 16:55:37 --> Security Class Initialized
DEBUG - 2025-05-11 16:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 16:55:37 --> Input Class Initialized
INFO - 2025-05-11 16:55:37 --> Language Class Initialized
INFO - 2025-05-11 16:55:37 --> Loader Class Initialized
INFO - 2025-05-11 16:55:37 --> Helper loaded: url_helper
INFO - 2025-05-11 16:55:37 --> Helper loaded: form_helper
INFO - 2025-05-11 16:55:37 --> Database Driver Class Initialized
DEBUG - 2025-05-11 16:55:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 16:55:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 16:55:37 --> Controller Class Initialized
INFO - 2025-05-11 16:55:37 --> Model "Workout_model" initialized
INFO - 2025-05-11 16:55:37 --> Final output sent to browser
DEBUG - 2025-05-11 16:55:37 --> Total execution time: 0.0616
INFO - 2025-05-11 16:55:37 --> Config Class Initialized
INFO - 2025-05-11 16:55:37 --> Hooks Class Initialized
DEBUG - 2025-05-11 16:55:37 --> UTF-8 Support Enabled
INFO - 2025-05-11 16:55:37 --> Utf8 Class Initialized
INFO - 2025-05-11 16:55:37 --> URI Class Initialized
INFO - 2025-05-11 16:55:37 --> Router Class Initialized
INFO - 2025-05-11 16:55:37 --> Output Class Initialized
INFO - 2025-05-11 16:55:37 --> Security Class Initialized
DEBUG - 2025-05-11 16:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 16:55:37 --> Input Class Initialized
INFO - 2025-05-11 16:55:37 --> Language Class Initialized
INFO - 2025-05-11 16:55:37 --> Loader Class Initialized
INFO - 2025-05-11 16:55:37 --> Helper loaded: url_helper
INFO - 2025-05-11 16:55:37 --> Helper loaded: form_helper
INFO - 2025-05-11 16:55:37 --> Database Driver Class Initialized
DEBUG - 2025-05-11 16:55:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 16:55:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 16:55:37 --> Controller Class Initialized
INFO - 2025-05-11 16:55:37 --> Model "Workout_model" initialized
INFO - 2025-05-11 16:55:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-11 16:55:37 --> Final output sent to browser
DEBUG - 2025-05-11 16:55:37 --> Total execution time: 0.0466
INFO - 2025-05-11 16:55:42 --> Config Class Initialized
INFO - 2025-05-11 16:55:42 --> Hooks Class Initialized
DEBUG - 2025-05-11 16:55:42 --> UTF-8 Support Enabled
INFO - 2025-05-11 16:55:42 --> Utf8 Class Initialized
INFO - 2025-05-11 16:55:42 --> URI Class Initialized
INFO - 2025-05-11 16:55:42 --> Router Class Initialized
INFO - 2025-05-11 16:55:42 --> Output Class Initialized
INFO - 2025-05-11 16:55:42 --> Security Class Initialized
DEBUG - 2025-05-11 16:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-11 16:55:42 --> Input Class Initialized
INFO - 2025-05-11 16:55:42 --> Language Class Initialized
INFO - 2025-05-11 16:55:42 --> Loader Class Initialized
INFO - 2025-05-11 16:55:42 --> Helper loaded: url_helper
INFO - 2025-05-11 16:55:42 --> Helper loaded: form_helper
INFO - 2025-05-11 16:55:42 --> Database Driver Class Initialized
DEBUG - 2025-05-11 16:55:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-11 16:55:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-11 16:55:42 --> Controller Class Initialized
INFO - 2025-05-11 16:55:42 --> Model "User_model" initialized
INFO - 2025-05-11 16:55:42 --> Model "Workout_model" initialized
INFO - 2025-05-11 16:55:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard.php
INFO - 2025-05-11 16:55:42 --> Final output sent to browser
DEBUG - 2025-05-11 16:55:42 --> Total execution time: 0.0732
