<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-07-03 08:46:12 --> Config Class Initialized
INFO - 2025-07-03 08:46:12 --> Hooks Class Initialized
DEBUG - 2025-07-03 08:46:12 --> UTF-8 Support Enabled
INFO - 2025-07-03 08:46:12 --> Utf8 Class Initialized
INFO - 2025-07-03 08:46:13 --> URI Class Initialized
DEBUG - 2025-07-03 08:46:13 --> No URI present. Default controller set.
INFO - 2025-07-03 08:46:13 --> Router Class Initialized
INFO - 2025-07-03 08:46:13 --> Output Class Initialized
INFO - 2025-07-03 08:46:13 --> Security Class Initialized
DEBUG - 2025-07-03 08:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 08:46:13 --> Input Class Initialized
INFO - 2025-07-03 08:46:13 --> Language Class Initialized
INFO - 2025-07-03 08:46:13 --> Loader Class Initialized
INFO - 2025-07-03 08:46:13 --> Helper loaded: url_helper
INFO - 2025-07-03 08:46:13 --> Helper loaded: form_helper
INFO - 2025-07-03 08:46:13 --> Database Driver Class Initialized
DEBUG - 2025-07-03 08:46:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 08:46:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 08:46:13 --> Controller Class Initialized
INFO - 2025-07-03 08:46:13 --> Model "User_model" initialized
INFO - 2025-07-03 08:46:13 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-07-03 08:46:13 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\landing_page/home.php
INFO - 2025-07-03 08:46:14 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-07-03 08:46:14 --> Final output sent to browser
DEBUG - 2025-07-03 08:46:14 --> Total execution time: 1.3942
INFO - 2025-07-03 08:46:16 --> Config Class Initialized
INFO - 2025-07-03 08:46:16 --> Hooks Class Initialized
DEBUG - 2025-07-03 08:46:16 --> UTF-8 Support Enabled
INFO - 2025-07-03 08:46:16 --> Utf8 Class Initialized
INFO - 2025-07-03 08:46:16 --> URI Class Initialized
INFO - 2025-07-03 08:46:16 --> Router Class Initialized
INFO - 2025-07-03 08:46:16 --> Output Class Initialized
INFO - 2025-07-03 08:46:16 --> Security Class Initialized
DEBUG - 2025-07-03 08:46:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 08:46:16 --> Input Class Initialized
INFO - 2025-07-03 08:46:16 --> Language Class Initialized
INFO - 2025-07-03 08:46:16 --> Loader Class Initialized
INFO - 2025-07-03 08:46:16 --> Helper loaded: url_helper
INFO - 2025-07-03 08:46:16 --> Helper loaded: form_helper
INFO - 2025-07-03 08:46:16 --> Database Driver Class Initialized
DEBUG - 2025-07-03 08:46:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 08:46:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 08:46:16 --> Controller Class Initialized
INFO - 2025-07-03 08:46:16 --> Model "User_model" initialized
INFO - 2025-07-03 08:46:16 --> Form Validation Class Initialized
INFO - 2025-07-03 08:46:16 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\auth/login.php
INFO - 2025-07-03 08:46:16 --> Final output sent to browser
DEBUG - 2025-07-03 08:46:16 --> Total execution time: 0.2043
INFO - 2025-07-03 08:46:26 --> Config Class Initialized
INFO - 2025-07-03 08:46:26 --> Hooks Class Initialized
DEBUG - 2025-07-03 08:46:26 --> UTF-8 Support Enabled
INFO - 2025-07-03 08:46:26 --> Utf8 Class Initialized
INFO - 2025-07-03 08:46:26 --> URI Class Initialized
INFO - 2025-07-03 08:46:26 --> Router Class Initialized
INFO - 2025-07-03 08:46:26 --> Output Class Initialized
INFO - 2025-07-03 08:46:26 --> Security Class Initialized
DEBUG - 2025-07-03 08:46:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 08:46:26 --> Input Class Initialized
INFO - 2025-07-03 08:46:26 --> Language Class Initialized
INFO - 2025-07-03 08:46:26 --> Loader Class Initialized
INFO - 2025-07-03 08:46:26 --> Helper loaded: url_helper
INFO - 2025-07-03 08:46:26 --> Helper loaded: form_helper
INFO - 2025-07-03 08:46:26 --> Database Driver Class Initialized
DEBUG - 2025-07-03 08:46:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 08:46:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 08:46:26 --> Controller Class Initialized
INFO - 2025-07-03 08:46:26 --> Model "User_model" initialized
INFO - 2025-07-03 08:46:26 --> Form Validation Class Initialized
INFO - 2025-07-03 08:46:26 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-07-03 08:46:26 --> Config Class Initialized
INFO - 2025-07-03 08:46:26 --> Hooks Class Initialized
DEBUG - 2025-07-03 08:46:26 --> UTF-8 Support Enabled
INFO - 2025-07-03 08:46:26 --> Utf8 Class Initialized
INFO - 2025-07-03 08:46:26 --> URI Class Initialized
INFO - 2025-07-03 08:46:26 --> Router Class Initialized
INFO - 2025-07-03 08:46:26 --> Output Class Initialized
INFO - 2025-07-03 08:46:26 --> Security Class Initialized
DEBUG - 2025-07-03 08:46:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 08:46:26 --> Input Class Initialized
INFO - 2025-07-03 08:46:26 --> Language Class Initialized
INFO - 2025-07-03 08:46:26 --> Loader Class Initialized
INFO - 2025-07-03 08:46:26 --> Helper loaded: url_helper
INFO - 2025-07-03 08:46:26 --> Helper loaded: form_helper
INFO - 2025-07-03 08:46:26 --> Database Driver Class Initialized
DEBUG - 2025-07-03 08:46:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 08:46:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 08:46:26 --> Controller Class Initialized
INFO - 2025-07-03 08:46:26 --> Model "User_model" initialized
INFO - 2025-07-03 08:46:26 --> Form Validation Class Initialized
INFO - 2025-07-03 08:46:26 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\auth/login.php
INFO - 2025-07-03 08:46:26 --> Final output sent to browser
DEBUG - 2025-07-03 08:46:26 --> Total execution time: 0.0454
INFO - 2025-07-03 08:46:39 --> Config Class Initialized
INFO - 2025-07-03 08:46:39 --> Hooks Class Initialized
DEBUG - 2025-07-03 08:46:39 --> UTF-8 Support Enabled
INFO - 2025-07-03 08:46:39 --> Utf8 Class Initialized
INFO - 2025-07-03 08:46:39 --> URI Class Initialized
INFO - 2025-07-03 08:46:39 --> Router Class Initialized
INFO - 2025-07-03 08:46:39 --> Output Class Initialized
INFO - 2025-07-03 08:46:39 --> Security Class Initialized
DEBUG - 2025-07-03 08:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 08:46:39 --> Input Class Initialized
INFO - 2025-07-03 08:46:39 --> Language Class Initialized
INFO - 2025-07-03 08:46:39 --> Loader Class Initialized
INFO - 2025-07-03 08:46:40 --> Helper loaded: url_helper
INFO - 2025-07-03 08:46:40 --> Helper loaded: form_helper
INFO - 2025-07-03 08:46:40 --> Database Driver Class Initialized
DEBUG - 2025-07-03 08:46:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 08:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 08:46:40 --> Controller Class Initialized
INFO - 2025-07-03 08:46:40 --> Model "User_model" initialized
INFO - 2025-07-03 08:46:40 --> Form Validation Class Initialized
INFO - 2025-07-03 08:46:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-07-03 08:46:40 --> Config Class Initialized
INFO - 2025-07-03 08:46:40 --> Hooks Class Initialized
DEBUG - 2025-07-03 08:46:40 --> UTF-8 Support Enabled
INFO - 2025-07-03 08:46:40 --> Utf8 Class Initialized
INFO - 2025-07-03 08:46:40 --> URI Class Initialized
INFO - 2025-07-03 08:46:40 --> Router Class Initialized
INFO - 2025-07-03 08:46:40 --> Output Class Initialized
INFO - 2025-07-03 08:46:40 --> Security Class Initialized
DEBUG - 2025-07-03 08:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 08:46:40 --> Input Class Initialized
INFO - 2025-07-03 08:46:40 --> Language Class Initialized
INFO - 2025-07-03 08:46:40 --> Loader Class Initialized
INFO - 2025-07-03 08:46:40 --> Helper loaded: url_helper
INFO - 2025-07-03 08:46:40 --> Helper loaded: form_helper
INFO - 2025-07-03 08:46:40 --> Database Driver Class Initialized
DEBUG - 2025-07-03 08:46:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 08:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 08:46:40 --> Controller Class Initialized
INFO - 2025-07-03 08:46:40 --> Model "User_model" initialized
INFO - 2025-07-03 08:46:40 --> Form Validation Class Initialized
INFO - 2025-07-03 08:46:40 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\auth/login.php
INFO - 2025-07-03 08:46:40 --> Final output sent to browser
DEBUG - 2025-07-03 08:46:40 --> Total execution time: 0.0337
INFO - 2025-07-03 08:47:01 --> Config Class Initialized
INFO - 2025-07-03 08:47:01 --> Hooks Class Initialized
DEBUG - 2025-07-03 08:47:01 --> UTF-8 Support Enabled
INFO - 2025-07-03 08:47:01 --> Utf8 Class Initialized
INFO - 2025-07-03 08:47:01 --> URI Class Initialized
INFO - 2025-07-03 08:47:01 --> Router Class Initialized
INFO - 2025-07-03 08:47:01 --> Output Class Initialized
INFO - 2025-07-03 08:47:01 --> Security Class Initialized
DEBUG - 2025-07-03 08:47:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 08:47:01 --> Input Class Initialized
INFO - 2025-07-03 08:47:01 --> Language Class Initialized
INFO - 2025-07-03 08:47:01 --> Loader Class Initialized
INFO - 2025-07-03 08:47:01 --> Helper loaded: url_helper
INFO - 2025-07-03 08:47:01 --> Helper loaded: form_helper
INFO - 2025-07-03 08:47:01 --> Database Driver Class Initialized
DEBUG - 2025-07-03 08:47:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 08:47:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 08:47:01 --> Controller Class Initialized
INFO - 2025-07-03 08:47:01 --> Model "User_model" initialized
INFO - 2025-07-03 08:47:01 --> Form Validation Class Initialized
INFO - 2025-07-03 08:47:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-07-03 08:47:01 --> Config Class Initialized
INFO - 2025-07-03 08:47:01 --> Hooks Class Initialized
DEBUG - 2025-07-03 08:47:01 --> UTF-8 Support Enabled
INFO - 2025-07-03 08:47:01 --> Utf8 Class Initialized
INFO - 2025-07-03 08:47:01 --> URI Class Initialized
INFO - 2025-07-03 08:47:01 --> Router Class Initialized
INFO - 2025-07-03 08:47:01 --> Output Class Initialized
INFO - 2025-07-03 08:47:01 --> Security Class Initialized
DEBUG - 2025-07-03 08:47:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 08:47:01 --> Input Class Initialized
INFO - 2025-07-03 08:47:01 --> Language Class Initialized
INFO - 2025-07-03 08:47:01 --> Loader Class Initialized
INFO - 2025-07-03 08:47:01 --> Helper loaded: url_helper
INFO - 2025-07-03 08:47:01 --> Helper loaded: form_helper
INFO - 2025-07-03 08:47:01 --> Database Driver Class Initialized
DEBUG - 2025-07-03 08:47:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 08:47:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 08:47:01 --> Controller Class Initialized
INFO - 2025-07-03 08:47:01 --> Model "User_model" initialized
INFO - 2025-07-03 08:47:01 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-07-03 08:47:01 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\landing_page/home.php
INFO - 2025-07-03 08:47:01 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-07-03 08:47:01 --> Final output sent to browser
DEBUG - 2025-07-03 08:47:01 --> Total execution time: 0.0470
INFO - 2025-07-03 08:47:17 --> Config Class Initialized
INFO - 2025-07-03 08:47:17 --> Hooks Class Initialized
DEBUG - 2025-07-03 08:47:17 --> UTF-8 Support Enabled
INFO - 2025-07-03 08:47:17 --> Utf8 Class Initialized
INFO - 2025-07-03 08:47:17 --> URI Class Initialized
INFO - 2025-07-03 08:47:17 --> Router Class Initialized
INFO - 2025-07-03 08:47:17 --> Output Class Initialized
INFO - 2025-07-03 08:47:17 --> Security Class Initialized
DEBUG - 2025-07-03 08:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 08:47:17 --> Input Class Initialized
INFO - 2025-07-03 08:47:17 --> Language Class Initialized
INFO - 2025-07-03 08:47:17 --> Loader Class Initialized
INFO - 2025-07-03 08:47:17 --> Helper loaded: url_helper
INFO - 2025-07-03 08:47:17 --> Helper loaded: form_helper
INFO - 2025-07-03 08:47:17 --> Database Driver Class Initialized
DEBUG - 2025-07-03 08:47:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 08:47:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 08:47:17 --> Controller Class Initialized
INFO - 2025-07-03 08:47:17 --> Model "User_model" initialized
INFO - 2025-07-03 08:47:17 --> Model "Progress_model" initialized
INFO - 2025-07-03 08:47:17 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 08:47:17 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 08:47:17 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/dashboard.php
INFO - 2025-07-03 08:47:17 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 08:47:17 --> Final output sent to browser
DEBUG - 2025-07-03 08:47:17 --> Total execution time: 0.2847
INFO - 2025-07-03 08:47:20 --> Config Class Initialized
INFO - 2025-07-03 08:47:20 --> Hooks Class Initialized
DEBUG - 2025-07-03 08:47:20 --> UTF-8 Support Enabled
INFO - 2025-07-03 08:47:20 --> Utf8 Class Initialized
INFO - 2025-07-03 08:47:20 --> URI Class Initialized
INFO - 2025-07-03 08:47:20 --> Router Class Initialized
INFO - 2025-07-03 08:47:20 --> Output Class Initialized
INFO - 2025-07-03 08:47:20 --> Security Class Initialized
DEBUG - 2025-07-03 08:47:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 08:47:20 --> Input Class Initialized
INFO - 2025-07-03 08:47:20 --> Language Class Initialized
INFO - 2025-07-03 08:47:20 --> Loader Class Initialized
INFO - 2025-07-03 08:47:20 --> Helper loaded: url_helper
INFO - 2025-07-03 08:47:20 --> Helper loaded: form_helper
INFO - 2025-07-03 08:47:20 --> Database Driver Class Initialized
DEBUG - 2025-07-03 08:47:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 08:47:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 08:47:20 --> Controller Class Initialized
INFO - 2025-07-03 08:47:20 --> Model "User_model" initialized
INFO - 2025-07-03 08:47:20 --> Model "Community_model" initialized
INFO - 2025-07-03 08:47:20 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 08:47:20 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 08:47:20 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/community.php
INFO - 2025-07-03 08:47:20 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 08:47:20 --> Final output sent to browser
DEBUG - 2025-07-03 08:47:20 --> Total execution time: 0.1288
INFO - 2025-07-03 08:47:21 --> Config Class Initialized
INFO - 2025-07-03 08:47:21 --> Hooks Class Initialized
DEBUG - 2025-07-03 08:47:21 --> UTF-8 Support Enabled
INFO - 2025-07-03 08:47:21 --> Utf8 Class Initialized
INFO - 2025-07-03 08:47:21 --> URI Class Initialized
INFO - 2025-07-03 08:47:21 --> Router Class Initialized
INFO - 2025-07-03 08:47:21 --> Output Class Initialized
INFO - 2025-07-03 08:47:21 --> Security Class Initialized
DEBUG - 2025-07-03 08:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 08:47:21 --> Input Class Initialized
INFO - 2025-07-03 08:47:21 --> Language Class Initialized
INFO - 2025-07-03 08:47:21 --> Loader Class Initialized
INFO - 2025-07-03 08:47:21 --> Helper loaded: url_helper
INFO - 2025-07-03 08:47:21 --> Helper loaded: form_helper
INFO - 2025-07-03 08:47:21 --> Database Driver Class Initialized
DEBUG - 2025-07-03 08:47:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 08:47:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 08:47:21 --> Controller Class Initialized
INFO - 2025-07-03 08:47:21 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 08:47:21 --> Model "User_model" initialized
INFO - 2025-07-03 08:47:21 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 08:47:21 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 08:47:21 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-07-03 08:47:21 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 08:47:21 --> Final output sent to browser
DEBUG - 2025-07-03 08:47:21 --> Total execution time: 0.1216
INFO - 2025-07-03 08:47:24 --> Config Class Initialized
INFO - 2025-07-03 08:47:24 --> Hooks Class Initialized
DEBUG - 2025-07-03 08:47:24 --> UTF-8 Support Enabled
INFO - 2025-07-03 08:47:24 --> Utf8 Class Initialized
INFO - 2025-07-03 08:47:24 --> URI Class Initialized
INFO - 2025-07-03 08:47:24 --> Router Class Initialized
INFO - 2025-07-03 08:47:24 --> Output Class Initialized
INFO - 2025-07-03 08:47:24 --> Security Class Initialized
DEBUG - 2025-07-03 08:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 08:47:24 --> Input Class Initialized
INFO - 2025-07-03 08:47:24 --> Language Class Initialized
INFO - 2025-07-03 08:47:24 --> Loader Class Initialized
INFO - 2025-07-03 08:47:24 --> Helper loaded: url_helper
INFO - 2025-07-03 08:47:24 --> Helper loaded: form_helper
INFO - 2025-07-03 08:47:24 --> Database Driver Class Initialized
DEBUG - 2025-07-03 08:47:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 08:47:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 08:47:24 --> Controller Class Initialized
INFO - 2025-07-03 08:47:24 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 08:47:24 --> Model "User_model" initialized
INFO - 2025-07-03 08:47:24 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 08:47:24 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 08:47:24 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/level.php
INFO - 2025-07-03 08:47:24 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 08:47:24 --> Final output sent to browser
DEBUG - 2025-07-03 08:47:24 --> Total execution time: 0.0451
INFO - 2025-07-03 08:47:26 --> Config Class Initialized
INFO - 2025-07-03 08:47:26 --> Hooks Class Initialized
DEBUG - 2025-07-03 08:47:26 --> UTF-8 Support Enabled
INFO - 2025-07-03 08:47:26 --> Utf8 Class Initialized
INFO - 2025-07-03 08:47:26 --> URI Class Initialized
INFO - 2025-07-03 08:47:26 --> Router Class Initialized
INFO - 2025-07-03 08:47:26 --> Output Class Initialized
INFO - 2025-07-03 08:47:26 --> Security Class Initialized
DEBUG - 2025-07-03 08:47:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 08:47:26 --> Input Class Initialized
INFO - 2025-07-03 08:47:26 --> Language Class Initialized
INFO - 2025-07-03 08:47:26 --> Loader Class Initialized
INFO - 2025-07-03 08:47:26 --> Helper loaded: url_helper
INFO - 2025-07-03 08:47:26 --> Helper loaded: form_helper
INFO - 2025-07-03 08:47:26 --> Database Driver Class Initialized
DEBUG - 2025-07-03 08:47:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 08:47:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 08:47:26 --> Controller Class Initialized
INFO - 2025-07-03 08:47:26 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 08:47:26 --> Model "User_model" initialized
INFO - 2025-07-03 08:47:26 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 08:47:26 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 08:47:26 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-07-03 08:47:26 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 08:47:26 --> Final output sent to browser
DEBUG - 2025-07-03 08:47:26 --> Total execution time: 0.0595
INFO - 2025-07-03 08:47:31 --> Config Class Initialized
INFO - 2025-07-03 08:47:31 --> Hooks Class Initialized
DEBUG - 2025-07-03 08:47:31 --> UTF-8 Support Enabled
INFO - 2025-07-03 08:47:31 --> Utf8 Class Initialized
INFO - 2025-07-03 08:47:31 --> URI Class Initialized
INFO - 2025-07-03 08:47:31 --> Router Class Initialized
INFO - 2025-07-03 08:47:31 --> Output Class Initialized
INFO - 2025-07-03 08:47:31 --> Security Class Initialized
DEBUG - 2025-07-03 08:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 08:47:31 --> Input Class Initialized
INFO - 2025-07-03 08:47:31 --> Language Class Initialized
INFO - 2025-07-03 08:47:31 --> Loader Class Initialized
INFO - 2025-07-03 08:47:31 --> Helper loaded: url_helper
INFO - 2025-07-03 08:47:31 --> Helper loaded: form_helper
INFO - 2025-07-03 08:47:31 --> Database Driver Class Initialized
DEBUG - 2025-07-03 08:47:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 08:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 08:47:31 --> Controller Class Initialized
INFO - 2025-07-03 08:47:31 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 08:47:31 --> Model "User_model" initialized
INFO - 2025-07-03 08:47:31 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 08:47:31 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 08:47:31 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/start.php
INFO - 2025-07-03 08:47:31 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 08:47:31 --> Final output sent to browser
DEBUG - 2025-07-03 08:47:31 --> Total execution time: 0.0879
INFO - 2025-07-03 08:47:49 --> Config Class Initialized
INFO - 2025-07-03 08:47:49 --> Hooks Class Initialized
DEBUG - 2025-07-03 08:47:49 --> UTF-8 Support Enabled
INFO - 2025-07-03 08:47:49 --> Utf8 Class Initialized
INFO - 2025-07-03 08:47:49 --> URI Class Initialized
INFO - 2025-07-03 08:47:49 --> Router Class Initialized
INFO - 2025-07-03 08:47:49 --> Output Class Initialized
INFO - 2025-07-03 08:47:49 --> Security Class Initialized
DEBUG - 2025-07-03 08:47:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 08:47:49 --> Input Class Initialized
INFO - 2025-07-03 08:47:49 --> Language Class Initialized
INFO - 2025-07-03 08:47:49 --> Loader Class Initialized
INFO - 2025-07-03 08:47:49 --> Helper loaded: url_helper
INFO - 2025-07-03 08:47:49 --> Helper loaded: form_helper
INFO - 2025-07-03 08:47:49 --> Database Driver Class Initialized
DEBUG - 2025-07-03 08:47:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 08:47:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 08:47:49 --> Controller Class Initialized
INFO - 2025-07-03 08:47:49 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 08:47:49 --> Model "User_model" initialized
INFO - 2025-07-03 08:47:49 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 08:47:49 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 08:47:49 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/start.php
INFO - 2025-07-03 08:47:49 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 08:47:49 --> Final output sent to browser
DEBUG - 2025-07-03 08:47:49 --> Total execution time: 0.0693
INFO - 2025-07-03 08:48:04 --> Config Class Initialized
INFO - 2025-07-03 08:48:04 --> Hooks Class Initialized
DEBUG - 2025-07-03 08:48:04 --> UTF-8 Support Enabled
INFO - 2025-07-03 08:48:04 --> Utf8 Class Initialized
INFO - 2025-07-03 08:48:04 --> URI Class Initialized
INFO - 2025-07-03 08:48:04 --> Router Class Initialized
INFO - 2025-07-03 08:48:04 --> Output Class Initialized
INFO - 2025-07-03 08:48:04 --> Security Class Initialized
DEBUG - 2025-07-03 08:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 08:48:04 --> Input Class Initialized
INFO - 2025-07-03 08:48:04 --> Language Class Initialized
INFO - 2025-07-03 08:48:04 --> Loader Class Initialized
INFO - 2025-07-03 08:48:04 --> Helper loaded: url_helper
INFO - 2025-07-03 08:48:04 --> Helper loaded: form_helper
INFO - 2025-07-03 08:48:04 --> Database Driver Class Initialized
DEBUG - 2025-07-03 08:48:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 08:48:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 08:48:04 --> Controller Class Initialized
INFO - 2025-07-03 08:48:04 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 08:48:04 --> Model "User_model" initialized
INFO - 2025-07-03 08:48:04 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 08:48:04 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 08:48:04 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/start.php
INFO - 2025-07-03 08:48:04 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 08:48:04 --> Final output sent to browser
DEBUG - 2025-07-03 08:48:04 --> Total execution time: 0.0509
INFO - 2025-07-03 08:48:11 --> Config Class Initialized
INFO - 2025-07-03 08:48:11 --> Hooks Class Initialized
DEBUG - 2025-07-03 08:48:11 --> UTF-8 Support Enabled
INFO - 2025-07-03 08:48:11 --> Utf8 Class Initialized
INFO - 2025-07-03 08:48:11 --> URI Class Initialized
INFO - 2025-07-03 08:48:11 --> Router Class Initialized
INFO - 2025-07-03 08:48:11 --> Output Class Initialized
INFO - 2025-07-03 08:48:11 --> Security Class Initialized
DEBUG - 2025-07-03 08:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 08:48:11 --> Input Class Initialized
INFO - 2025-07-03 08:48:11 --> Language Class Initialized
INFO - 2025-07-03 08:48:11 --> Loader Class Initialized
INFO - 2025-07-03 08:48:11 --> Helper loaded: url_helper
INFO - 2025-07-03 08:48:11 --> Helper loaded: form_helper
INFO - 2025-07-03 08:48:11 --> Database Driver Class Initialized
DEBUG - 2025-07-03 08:48:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 08:48:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 08:48:11 --> Controller Class Initialized
INFO - 2025-07-03 08:48:11 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 08:48:11 --> Model "User_model" initialized
INFO - 2025-07-03 08:48:11 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 08:48:11 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 08:48:11 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/start.php
INFO - 2025-07-03 08:48:11 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 08:48:11 --> Final output sent to browser
DEBUG - 2025-07-03 08:48:11 --> Total execution time: 0.0452
INFO - 2025-07-03 08:48:18 --> Config Class Initialized
INFO - 2025-07-03 08:48:18 --> Hooks Class Initialized
DEBUG - 2025-07-03 08:48:18 --> UTF-8 Support Enabled
INFO - 2025-07-03 08:48:18 --> Utf8 Class Initialized
INFO - 2025-07-03 08:48:18 --> URI Class Initialized
INFO - 2025-07-03 08:48:18 --> Router Class Initialized
INFO - 2025-07-03 08:48:18 --> Output Class Initialized
INFO - 2025-07-03 08:48:18 --> Security Class Initialized
DEBUG - 2025-07-03 08:48:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 08:48:18 --> Input Class Initialized
INFO - 2025-07-03 08:48:18 --> Language Class Initialized
INFO - 2025-07-03 08:48:18 --> Loader Class Initialized
INFO - 2025-07-03 08:48:18 --> Helper loaded: url_helper
INFO - 2025-07-03 08:48:18 --> Helper loaded: form_helper
INFO - 2025-07-03 08:48:18 --> Database Driver Class Initialized
DEBUG - 2025-07-03 08:48:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 08:48:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 08:48:18 --> Controller Class Initialized
INFO - 2025-07-03 08:48:18 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 08:48:18 --> Model "User_model" initialized
INFO - 2025-07-03 08:48:18 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 08:48:18 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 08:48:18 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/start.php
INFO - 2025-07-03 08:48:18 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 08:48:18 --> Final output sent to browser
DEBUG - 2025-07-03 08:48:18 --> Total execution time: 0.0417
INFO - 2025-07-03 08:48:22 --> Config Class Initialized
INFO - 2025-07-03 08:48:22 --> Hooks Class Initialized
DEBUG - 2025-07-03 08:48:22 --> UTF-8 Support Enabled
INFO - 2025-07-03 08:48:22 --> Utf8 Class Initialized
INFO - 2025-07-03 08:48:22 --> URI Class Initialized
INFO - 2025-07-03 08:48:22 --> Router Class Initialized
INFO - 2025-07-03 08:48:22 --> Output Class Initialized
INFO - 2025-07-03 08:48:22 --> Security Class Initialized
DEBUG - 2025-07-03 08:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 08:48:22 --> Input Class Initialized
INFO - 2025-07-03 08:48:22 --> Language Class Initialized
INFO - 2025-07-03 08:48:22 --> Loader Class Initialized
INFO - 2025-07-03 08:48:22 --> Helper loaded: url_helper
INFO - 2025-07-03 08:48:22 --> Helper loaded: form_helper
INFO - 2025-07-03 08:48:22 --> Database Driver Class Initialized
DEBUG - 2025-07-03 08:48:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 08:48:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 08:48:22 --> Controller Class Initialized
INFO - 2025-07-03 08:48:22 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 08:48:22 --> Model "User_model" initialized
INFO - 2025-07-03 08:48:22 --> Final output sent to browser
DEBUG - 2025-07-03 08:48:22 --> Total execution time: 0.0528
INFO - 2025-07-03 08:48:30 --> Config Class Initialized
INFO - 2025-07-03 08:48:30 --> Hooks Class Initialized
DEBUG - 2025-07-03 08:48:30 --> UTF-8 Support Enabled
INFO - 2025-07-03 08:48:30 --> Utf8 Class Initialized
INFO - 2025-07-03 08:48:30 --> URI Class Initialized
INFO - 2025-07-03 08:48:30 --> Router Class Initialized
INFO - 2025-07-03 08:48:30 --> Output Class Initialized
INFO - 2025-07-03 08:48:30 --> Security Class Initialized
DEBUG - 2025-07-03 08:48:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 08:48:30 --> Input Class Initialized
INFO - 2025-07-03 08:48:30 --> Language Class Initialized
INFO - 2025-07-03 08:48:30 --> Loader Class Initialized
INFO - 2025-07-03 08:48:30 --> Helper loaded: url_helper
INFO - 2025-07-03 08:48:30 --> Helper loaded: form_helper
INFO - 2025-07-03 08:48:30 --> Database Driver Class Initialized
DEBUG - 2025-07-03 08:48:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 08:48:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 08:48:30 --> Controller Class Initialized
INFO - 2025-07-03 08:48:30 --> Model "User_model" initialized
INFO - 2025-07-03 08:48:30 --> Model "Progress_model" initialized
INFO - 2025-07-03 08:48:30 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 08:48:30 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 08:48:30 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/dashboard.php
INFO - 2025-07-03 08:48:30 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 08:48:30 --> Final output sent to browser
DEBUG - 2025-07-03 08:48:30 --> Total execution time: 0.0487
INFO - 2025-07-03 08:48:34 --> Config Class Initialized
INFO - 2025-07-03 08:48:34 --> Hooks Class Initialized
DEBUG - 2025-07-03 08:48:34 --> UTF-8 Support Enabled
INFO - 2025-07-03 08:48:34 --> Utf8 Class Initialized
INFO - 2025-07-03 08:48:34 --> URI Class Initialized
INFO - 2025-07-03 08:48:34 --> Router Class Initialized
INFO - 2025-07-03 08:48:34 --> Output Class Initialized
INFO - 2025-07-03 08:48:34 --> Security Class Initialized
DEBUG - 2025-07-03 08:48:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 08:48:34 --> Input Class Initialized
INFO - 2025-07-03 08:48:34 --> Language Class Initialized
INFO - 2025-07-03 08:48:34 --> Loader Class Initialized
INFO - 2025-07-03 08:48:34 --> Helper loaded: url_helper
INFO - 2025-07-03 08:48:34 --> Helper loaded: form_helper
INFO - 2025-07-03 08:48:34 --> Database Driver Class Initialized
DEBUG - 2025-07-03 08:48:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 08:48:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 08:48:34 --> Controller Class Initialized
INFO - 2025-07-03 08:48:34 --> Model "User_model" initialized
INFO - 2025-07-03 08:48:34 --> Model "Community_model" initialized
INFO - 2025-07-03 08:48:34 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 08:48:34 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 08:48:34 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/community.php
INFO - 2025-07-03 08:48:34 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 08:48:34 --> Final output sent to browser
DEBUG - 2025-07-03 08:48:34 --> Total execution time: 0.0499
INFO - 2025-07-03 08:48:36 --> Config Class Initialized
INFO - 2025-07-03 08:48:36 --> Hooks Class Initialized
DEBUG - 2025-07-03 08:48:36 --> UTF-8 Support Enabled
INFO - 2025-07-03 08:48:36 --> Utf8 Class Initialized
INFO - 2025-07-03 08:48:36 --> URI Class Initialized
INFO - 2025-07-03 08:48:36 --> Router Class Initialized
INFO - 2025-07-03 08:48:36 --> Output Class Initialized
INFO - 2025-07-03 08:48:36 --> Security Class Initialized
DEBUG - 2025-07-03 08:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 08:48:36 --> Input Class Initialized
INFO - 2025-07-03 08:48:36 --> Language Class Initialized
INFO - 2025-07-03 08:48:36 --> Loader Class Initialized
INFO - 2025-07-03 08:48:36 --> Helper loaded: url_helper
INFO - 2025-07-03 08:48:36 --> Helper loaded: form_helper
INFO - 2025-07-03 08:48:36 --> Database Driver Class Initialized
DEBUG - 2025-07-03 08:48:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 08:48:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 08:48:36 --> Controller Class Initialized
INFO - 2025-07-03 08:48:36 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 08:48:36 --> Model "User_model" initialized
INFO - 2025-07-03 08:48:36 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 08:48:36 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 08:48:36 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-07-03 08:48:36 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 08:48:36 --> Final output sent to browser
DEBUG - 2025-07-03 08:48:36 --> Total execution time: 0.0398
INFO - 2025-07-03 08:48:53 --> Config Class Initialized
INFO - 2025-07-03 08:48:53 --> Hooks Class Initialized
DEBUG - 2025-07-03 08:48:53 --> UTF-8 Support Enabled
INFO - 2025-07-03 08:48:53 --> Utf8 Class Initialized
INFO - 2025-07-03 08:48:53 --> URI Class Initialized
INFO - 2025-07-03 08:48:53 --> Router Class Initialized
INFO - 2025-07-03 08:48:53 --> Output Class Initialized
INFO - 2025-07-03 08:48:53 --> Security Class Initialized
DEBUG - 2025-07-03 08:48:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 08:48:53 --> Input Class Initialized
INFO - 2025-07-03 08:48:53 --> Language Class Initialized
INFO - 2025-07-03 08:48:53 --> Loader Class Initialized
INFO - 2025-07-03 08:48:53 --> Helper loaded: url_helper
INFO - 2025-07-03 08:48:53 --> Helper loaded: form_helper
INFO - 2025-07-03 08:48:53 --> Database Driver Class Initialized
DEBUG - 2025-07-03 08:48:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 08:48:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 08:48:53 --> Controller Class Initialized
INFO - 2025-07-03 08:48:53 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 08:48:53 --> Model "User_model" initialized
INFO - 2025-07-03 08:48:53 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 08:48:53 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 08:48:53 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/level.php
INFO - 2025-07-03 08:48:53 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 08:48:53 --> Final output sent to browser
DEBUG - 2025-07-03 08:48:53 --> Total execution time: 0.0418
INFO - 2025-07-03 08:49:05 --> Config Class Initialized
INFO - 2025-07-03 08:49:05 --> Hooks Class Initialized
DEBUG - 2025-07-03 08:49:05 --> UTF-8 Support Enabled
INFO - 2025-07-03 08:49:05 --> Utf8 Class Initialized
INFO - 2025-07-03 08:49:05 --> URI Class Initialized
INFO - 2025-07-03 08:49:05 --> Router Class Initialized
INFO - 2025-07-03 08:49:05 --> Output Class Initialized
INFO - 2025-07-03 08:49:05 --> Security Class Initialized
DEBUG - 2025-07-03 08:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 08:49:05 --> Input Class Initialized
INFO - 2025-07-03 08:49:05 --> Language Class Initialized
INFO - 2025-07-03 08:49:05 --> Loader Class Initialized
INFO - 2025-07-03 08:49:05 --> Helper loaded: url_helper
INFO - 2025-07-03 08:49:05 --> Helper loaded: form_helper
INFO - 2025-07-03 08:49:05 --> Database Driver Class Initialized
DEBUG - 2025-07-03 08:49:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 08:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 08:49:05 --> Controller Class Initialized
INFO - 2025-07-03 08:49:05 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 08:49:05 --> Model "User_model" initialized
INFO - 2025-07-03 08:49:05 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 08:49:05 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 08:49:05 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/level.php
INFO - 2025-07-03 08:49:05 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 08:49:05 --> Final output sent to browser
DEBUG - 2025-07-03 08:49:05 --> Total execution time: 0.0397
INFO - 2025-07-03 08:49:06 --> Config Class Initialized
INFO - 2025-07-03 08:49:06 --> Hooks Class Initialized
DEBUG - 2025-07-03 08:49:06 --> UTF-8 Support Enabled
INFO - 2025-07-03 08:49:06 --> Utf8 Class Initialized
INFO - 2025-07-03 08:49:06 --> URI Class Initialized
INFO - 2025-07-03 08:49:06 --> Router Class Initialized
INFO - 2025-07-03 08:49:06 --> Output Class Initialized
INFO - 2025-07-03 08:49:06 --> Security Class Initialized
DEBUG - 2025-07-03 08:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 08:49:06 --> Input Class Initialized
INFO - 2025-07-03 08:49:06 --> Language Class Initialized
INFO - 2025-07-03 08:49:06 --> Loader Class Initialized
INFO - 2025-07-03 08:49:06 --> Helper loaded: url_helper
INFO - 2025-07-03 08:49:06 --> Helper loaded: form_helper
INFO - 2025-07-03 08:49:06 --> Database Driver Class Initialized
DEBUG - 2025-07-03 08:49:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 08:49:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 08:49:06 --> Controller Class Initialized
INFO - 2025-07-03 08:49:06 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 08:49:06 --> Model "User_model" initialized
INFO - 2025-07-03 08:49:06 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 08:49:06 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 08:49:06 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-07-03 08:49:06 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 08:49:06 --> Final output sent to browser
DEBUG - 2025-07-03 08:49:06 --> Total execution time: 0.0529
INFO - 2025-07-03 08:49:10 --> Config Class Initialized
INFO - 2025-07-03 08:49:10 --> Hooks Class Initialized
DEBUG - 2025-07-03 08:49:10 --> UTF-8 Support Enabled
INFO - 2025-07-03 08:49:10 --> Utf8 Class Initialized
INFO - 2025-07-03 08:49:10 --> URI Class Initialized
INFO - 2025-07-03 08:49:10 --> Router Class Initialized
INFO - 2025-07-03 08:49:10 --> Output Class Initialized
INFO - 2025-07-03 08:49:10 --> Security Class Initialized
DEBUG - 2025-07-03 08:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 08:49:10 --> Input Class Initialized
INFO - 2025-07-03 08:49:10 --> Language Class Initialized
INFO - 2025-07-03 08:49:10 --> Loader Class Initialized
INFO - 2025-07-03 08:49:10 --> Helper loaded: url_helper
INFO - 2025-07-03 08:49:10 --> Helper loaded: form_helper
INFO - 2025-07-03 08:49:10 --> Database Driver Class Initialized
DEBUG - 2025-07-03 08:49:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 08:49:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 08:49:10 --> Controller Class Initialized
INFO - 2025-07-03 08:49:10 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 08:49:10 --> Model "User_model" initialized
INFO - 2025-07-03 08:49:10 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 08:49:10 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 08:49:10 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/start.php
INFO - 2025-07-03 08:49:10 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 08:49:10 --> Final output sent to browser
DEBUG - 2025-07-03 08:49:10 --> Total execution time: 0.0383
INFO - 2025-07-03 08:49:15 --> Config Class Initialized
INFO - 2025-07-03 08:49:15 --> Hooks Class Initialized
DEBUG - 2025-07-03 08:49:15 --> UTF-8 Support Enabled
INFO - 2025-07-03 08:49:15 --> Utf8 Class Initialized
INFO - 2025-07-03 08:49:15 --> URI Class Initialized
INFO - 2025-07-03 08:49:15 --> Router Class Initialized
INFO - 2025-07-03 08:49:15 --> Output Class Initialized
INFO - 2025-07-03 08:49:15 --> Security Class Initialized
DEBUG - 2025-07-03 08:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 08:49:15 --> Input Class Initialized
INFO - 2025-07-03 08:49:15 --> Language Class Initialized
INFO - 2025-07-03 08:49:15 --> Loader Class Initialized
INFO - 2025-07-03 08:49:15 --> Helper loaded: url_helper
INFO - 2025-07-03 08:49:15 --> Helper loaded: form_helper
INFO - 2025-07-03 08:49:15 --> Database Driver Class Initialized
DEBUG - 2025-07-03 08:49:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 08:49:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 08:49:15 --> Controller Class Initialized
INFO - 2025-07-03 08:49:15 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 08:49:15 --> Model "User_model" initialized
INFO - 2025-07-03 08:49:15 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 08:49:15 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 08:49:15 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/start.php
INFO - 2025-07-03 08:49:15 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 08:49:15 --> Final output sent to browser
DEBUG - 2025-07-03 08:49:15 --> Total execution time: 0.0411
INFO - 2025-07-03 08:49:22 --> Config Class Initialized
INFO - 2025-07-03 08:49:22 --> Hooks Class Initialized
DEBUG - 2025-07-03 08:49:22 --> UTF-8 Support Enabled
INFO - 2025-07-03 08:49:22 --> Utf8 Class Initialized
INFO - 2025-07-03 08:49:22 --> URI Class Initialized
INFO - 2025-07-03 08:49:22 --> Router Class Initialized
INFO - 2025-07-03 08:49:22 --> Output Class Initialized
INFO - 2025-07-03 08:49:22 --> Security Class Initialized
DEBUG - 2025-07-03 08:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 08:49:22 --> Input Class Initialized
INFO - 2025-07-03 08:49:22 --> Language Class Initialized
INFO - 2025-07-03 08:49:22 --> Loader Class Initialized
INFO - 2025-07-03 08:49:22 --> Helper loaded: url_helper
INFO - 2025-07-03 08:49:22 --> Helper loaded: form_helper
INFO - 2025-07-03 08:49:22 --> Database Driver Class Initialized
DEBUG - 2025-07-03 08:49:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 08:49:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 08:49:22 --> Controller Class Initialized
INFO - 2025-07-03 08:49:22 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 08:49:22 --> Model "User_model" initialized
INFO - 2025-07-03 08:49:22 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 08:49:22 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 08:49:22 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/start.php
INFO - 2025-07-03 08:49:22 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 08:49:22 --> Final output sent to browser
DEBUG - 2025-07-03 08:49:22 --> Total execution time: 0.0420
INFO - 2025-07-03 08:49:26 --> Config Class Initialized
INFO - 2025-07-03 08:49:26 --> Hooks Class Initialized
DEBUG - 2025-07-03 08:49:26 --> UTF-8 Support Enabled
INFO - 2025-07-03 08:49:26 --> Utf8 Class Initialized
INFO - 2025-07-03 08:49:26 --> URI Class Initialized
INFO - 2025-07-03 08:49:26 --> Router Class Initialized
INFO - 2025-07-03 08:49:26 --> Output Class Initialized
INFO - 2025-07-03 08:49:26 --> Security Class Initialized
DEBUG - 2025-07-03 08:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 08:49:26 --> Input Class Initialized
INFO - 2025-07-03 08:49:26 --> Language Class Initialized
INFO - 2025-07-03 08:49:26 --> Loader Class Initialized
INFO - 2025-07-03 08:49:26 --> Helper loaded: url_helper
INFO - 2025-07-03 08:49:26 --> Helper loaded: form_helper
INFO - 2025-07-03 08:49:26 --> Database Driver Class Initialized
DEBUG - 2025-07-03 08:49:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 08:49:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 08:49:26 --> Controller Class Initialized
INFO - 2025-07-03 08:49:26 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 08:49:26 --> Model "User_model" initialized
INFO - 2025-07-03 08:49:26 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 08:49:26 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 08:49:26 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/start.php
INFO - 2025-07-03 08:49:26 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 08:49:26 --> Final output sent to browser
DEBUG - 2025-07-03 08:49:26 --> Total execution time: 0.0437
INFO - 2025-07-03 08:49:29 --> Config Class Initialized
INFO - 2025-07-03 08:49:29 --> Hooks Class Initialized
DEBUG - 2025-07-03 08:49:29 --> UTF-8 Support Enabled
INFO - 2025-07-03 08:49:29 --> Utf8 Class Initialized
INFO - 2025-07-03 08:49:29 --> URI Class Initialized
INFO - 2025-07-03 08:49:29 --> Router Class Initialized
INFO - 2025-07-03 08:49:29 --> Output Class Initialized
INFO - 2025-07-03 08:49:29 --> Security Class Initialized
DEBUG - 2025-07-03 08:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 08:49:29 --> Input Class Initialized
INFO - 2025-07-03 08:49:29 --> Language Class Initialized
INFO - 2025-07-03 08:49:29 --> Loader Class Initialized
INFO - 2025-07-03 08:49:29 --> Helper loaded: url_helper
INFO - 2025-07-03 08:49:29 --> Helper loaded: form_helper
INFO - 2025-07-03 08:49:29 --> Database Driver Class Initialized
DEBUG - 2025-07-03 08:49:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 08:49:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 08:49:29 --> Controller Class Initialized
INFO - 2025-07-03 08:49:29 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 08:49:29 --> Model "User_model" initialized
INFO - 2025-07-03 08:49:29 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 08:49:29 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 08:49:29 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/start.php
INFO - 2025-07-03 08:49:29 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 08:49:29 --> Final output sent to browser
DEBUG - 2025-07-03 08:49:29 --> Total execution time: 0.0424
INFO - 2025-07-03 08:49:37 --> Config Class Initialized
INFO - 2025-07-03 08:49:37 --> Hooks Class Initialized
DEBUG - 2025-07-03 08:49:37 --> UTF-8 Support Enabled
INFO - 2025-07-03 08:49:37 --> Utf8 Class Initialized
INFO - 2025-07-03 08:49:37 --> URI Class Initialized
INFO - 2025-07-03 08:49:37 --> Router Class Initialized
INFO - 2025-07-03 08:49:37 --> Output Class Initialized
INFO - 2025-07-03 08:49:37 --> Security Class Initialized
DEBUG - 2025-07-03 08:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 08:49:37 --> Input Class Initialized
INFO - 2025-07-03 08:49:37 --> Language Class Initialized
INFO - 2025-07-03 08:49:37 --> Loader Class Initialized
INFO - 2025-07-03 08:49:37 --> Helper loaded: url_helper
INFO - 2025-07-03 08:49:37 --> Helper loaded: form_helper
INFO - 2025-07-03 08:49:37 --> Database Driver Class Initialized
DEBUG - 2025-07-03 08:49:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 08:49:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 08:49:37 --> Controller Class Initialized
INFO - 2025-07-03 08:49:37 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 08:49:37 --> Model "User_model" initialized
INFO - 2025-07-03 08:49:37 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 08:49:37 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 08:49:37 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/start.php
INFO - 2025-07-03 08:49:37 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 08:49:37 --> Final output sent to browser
DEBUG - 2025-07-03 08:49:37 --> Total execution time: 0.0562
INFO - 2025-07-03 08:49:46 --> Config Class Initialized
INFO - 2025-07-03 08:49:46 --> Hooks Class Initialized
DEBUG - 2025-07-03 08:49:46 --> UTF-8 Support Enabled
INFO - 2025-07-03 08:49:46 --> Utf8 Class Initialized
INFO - 2025-07-03 08:49:46 --> URI Class Initialized
INFO - 2025-07-03 08:49:46 --> Router Class Initialized
INFO - 2025-07-03 08:49:46 --> Output Class Initialized
INFO - 2025-07-03 08:49:46 --> Security Class Initialized
DEBUG - 2025-07-03 08:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 08:49:46 --> Input Class Initialized
INFO - 2025-07-03 08:49:46 --> Language Class Initialized
INFO - 2025-07-03 08:49:46 --> Loader Class Initialized
INFO - 2025-07-03 08:49:46 --> Helper loaded: url_helper
INFO - 2025-07-03 08:49:46 --> Helper loaded: form_helper
INFO - 2025-07-03 08:49:46 --> Database Driver Class Initialized
DEBUG - 2025-07-03 08:49:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 08:49:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 08:49:46 --> Controller Class Initialized
INFO - 2025-07-03 08:49:47 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 08:49:47 --> Model "User_model" initialized
INFO - 2025-07-03 08:49:47 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 08:49:47 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 08:49:47 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/start.php
INFO - 2025-07-03 08:49:47 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 08:49:47 --> Final output sent to browser
DEBUG - 2025-07-03 08:49:47 --> Total execution time: 0.0417
INFO - 2025-07-03 08:49:54 --> Config Class Initialized
INFO - 2025-07-03 08:49:54 --> Hooks Class Initialized
DEBUG - 2025-07-03 08:49:54 --> UTF-8 Support Enabled
INFO - 2025-07-03 08:49:54 --> Utf8 Class Initialized
INFO - 2025-07-03 08:49:54 --> URI Class Initialized
INFO - 2025-07-03 08:49:54 --> Router Class Initialized
INFO - 2025-07-03 08:49:54 --> Output Class Initialized
INFO - 2025-07-03 08:49:54 --> Security Class Initialized
DEBUG - 2025-07-03 08:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 08:49:54 --> Input Class Initialized
INFO - 2025-07-03 08:49:54 --> Language Class Initialized
INFO - 2025-07-03 08:49:54 --> Loader Class Initialized
INFO - 2025-07-03 08:49:54 --> Helper loaded: url_helper
INFO - 2025-07-03 08:49:54 --> Helper loaded: form_helper
INFO - 2025-07-03 08:49:54 --> Database Driver Class Initialized
DEBUG - 2025-07-03 08:49:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 08:49:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 08:49:54 --> Controller Class Initialized
INFO - 2025-07-03 08:49:54 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 08:49:54 --> Model "User_model" initialized
INFO - 2025-07-03 08:49:54 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 08:49:54 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 08:49:54 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/start.php
INFO - 2025-07-03 08:49:54 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 08:49:54 --> Final output sent to browser
DEBUG - 2025-07-03 08:49:54 --> Total execution time: 0.0471
INFO - 2025-07-03 08:49:57 --> Config Class Initialized
INFO - 2025-07-03 08:49:57 --> Hooks Class Initialized
DEBUG - 2025-07-03 08:49:57 --> UTF-8 Support Enabled
INFO - 2025-07-03 08:49:57 --> Utf8 Class Initialized
INFO - 2025-07-03 08:49:57 --> URI Class Initialized
INFO - 2025-07-03 08:49:57 --> Router Class Initialized
INFO - 2025-07-03 08:49:57 --> Output Class Initialized
INFO - 2025-07-03 08:49:57 --> Security Class Initialized
DEBUG - 2025-07-03 08:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 08:49:57 --> Input Class Initialized
INFO - 2025-07-03 08:49:57 --> Language Class Initialized
INFO - 2025-07-03 08:49:57 --> Loader Class Initialized
INFO - 2025-07-03 08:49:57 --> Helper loaded: url_helper
INFO - 2025-07-03 08:49:57 --> Helper loaded: form_helper
INFO - 2025-07-03 08:49:57 --> Database Driver Class Initialized
DEBUG - 2025-07-03 08:49:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 08:49:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 08:49:57 --> Controller Class Initialized
INFO - 2025-07-03 08:49:57 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 08:49:57 --> Model "User_model" initialized
INFO - 2025-07-03 08:49:57 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 08:49:57 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 08:49:57 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-07-03 08:49:57 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 08:49:57 --> Final output sent to browser
DEBUG - 2025-07-03 08:49:57 --> Total execution time: 0.0722
INFO - 2025-07-03 08:49:59 --> Config Class Initialized
INFO - 2025-07-03 08:49:59 --> Hooks Class Initialized
DEBUG - 2025-07-03 08:49:59 --> UTF-8 Support Enabled
INFO - 2025-07-03 08:49:59 --> Utf8 Class Initialized
INFO - 2025-07-03 08:49:59 --> URI Class Initialized
INFO - 2025-07-03 08:49:59 --> Router Class Initialized
INFO - 2025-07-03 08:49:59 --> Output Class Initialized
INFO - 2025-07-03 08:49:59 --> Security Class Initialized
DEBUG - 2025-07-03 08:49:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 08:49:59 --> Input Class Initialized
INFO - 2025-07-03 08:49:59 --> Language Class Initialized
INFO - 2025-07-03 08:49:59 --> Loader Class Initialized
INFO - 2025-07-03 08:49:59 --> Helper loaded: url_helper
INFO - 2025-07-03 08:49:59 --> Helper loaded: form_helper
INFO - 2025-07-03 08:49:59 --> Database Driver Class Initialized
DEBUG - 2025-07-03 08:49:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 08:49:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 08:49:59 --> Controller Class Initialized
INFO - 2025-07-03 08:49:59 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 08:49:59 --> Model "User_model" initialized
INFO - 2025-07-03 08:49:59 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 08:49:59 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 08:49:59 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/level.php
INFO - 2025-07-03 08:49:59 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 08:49:59 --> Final output sent to browser
DEBUG - 2025-07-03 08:49:59 --> Total execution time: 0.0427
INFO - 2025-07-03 08:50:03 --> Config Class Initialized
INFO - 2025-07-03 08:50:03 --> Hooks Class Initialized
DEBUG - 2025-07-03 08:50:03 --> UTF-8 Support Enabled
INFO - 2025-07-03 08:50:03 --> Utf8 Class Initialized
INFO - 2025-07-03 08:50:03 --> URI Class Initialized
INFO - 2025-07-03 08:50:03 --> Router Class Initialized
INFO - 2025-07-03 08:50:03 --> Output Class Initialized
INFO - 2025-07-03 08:50:03 --> Security Class Initialized
DEBUG - 2025-07-03 08:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 08:50:03 --> Input Class Initialized
INFO - 2025-07-03 08:50:03 --> Language Class Initialized
INFO - 2025-07-03 08:50:03 --> Loader Class Initialized
INFO - 2025-07-03 08:50:03 --> Helper loaded: url_helper
INFO - 2025-07-03 08:50:03 --> Helper loaded: form_helper
INFO - 2025-07-03 08:50:03 --> Database Driver Class Initialized
DEBUG - 2025-07-03 08:50:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 08:50:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 08:50:03 --> Controller Class Initialized
INFO - 2025-07-03 08:50:03 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 08:50:03 --> Model "User_model" initialized
INFO - 2025-07-03 08:50:03 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 08:50:03 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 08:50:03 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/level.php
INFO - 2025-07-03 08:50:03 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 08:50:03 --> Final output sent to browser
DEBUG - 2025-07-03 08:50:03 --> Total execution time: 0.0348
INFO - 2025-07-03 08:50:05 --> Config Class Initialized
INFO - 2025-07-03 08:50:05 --> Hooks Class Initialized
DEBUG - 2025-07-03 08:50:05 --> UTF-8 Support Enabled
INFO - 2025-07-03 08:50:05 --> Utf8 Class Initialized
INFO - 2025-07-03 08:50:05 --> URI Class Initialized
INFO - 2025-07-03 08:50:05 --> Router Class Initialized
INFO - 2025-07-03 08:50:05 --> Output Class Initialized
INFO - 2025-07-03 08:50:05 --> Security Class Initialized
DEBUG - 2025-07-03 08:50:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 08:50:05 --> Input Class Initialized
INFO - 2025-07-03 08:50:05 --> Language Class Initialized
INFO - 2025-07-03 08:50:05 --> Loader Class Initialized
INFO - 2025-07-03 08:50:05 --> Helper loaded: url_helper
INFO - 2025-07-03 08:50:05 --> Helper loaded: form_helper
INFO - 2025-07-03 08:50:05 --> Database Driver Class Initialized
DEBUG - 2025-07-03 08:50:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 08:50:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 08:50:05 --> Controller Class Initialized
INFO - 2025-07-03 08:50:05 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 08:50:05 --> Model "User_model" initialized
INFO - 2025-07-03 08:50:05 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 08:50:05 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 08:50:05 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-07-03 08:50:05 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 08:50:05 --> Final output sent to browser
DEBUG - 2025-07-03 08:50:05 --> Total execution time: 0.0382
INFO - 2025-07-03 08:50:07 --> Config Class Initialized
INFO - 2025-07-03 08:50:07 --> Hooks Class Initialized
DEBUG - 2025-07-03 08:50:07 --> UTF-8 Support Enabled
INFO - 2025-07-03 08:50:07 --> Utf8 Class Initialized
INFO - 2025-07-03 08:50:07 --> URI Class Initialized
INFO - 2025-07-03 08:50:07 --> Router Class Initialized
INFO - 2025-07-03 08:50:07 --> Output Class Initialized
INFO - 2025-07-03 08:50:07 --> Security Class Initialized
DEBUG - 2025-07-03 08:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 08:50:07 --> Input Class Initialized
INFO - 2025-07-03 08:50:07 --> Language Class Initialized
INFO - 2025-07-03 08:50:07 --> Loader Class Initialized
INFO - 2025-07-03 08:50:07 --> Helper loaded: url_helper
INFO - 2025-07-03 08:50:07 --> Helper loaded: form_helper
INFO - 2025-07-03 08:50:07 --> Database Driver Class Initialized
DEBUG - 2025-07-03 08:50:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 08:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 08:50:07 --> Controller Class Initialized
INFO - 2025-07-03 08:50:07 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 08:50:07 --> Model "User_model" initialized
INFO - 2025-07-03 08:50:07 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 08:50:07 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 08:50:07 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-07-03 08:50:07 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 08:50:07 --> Final output sent to browser
DEBUG - 2025-07-03 08:50:07 --> Total execution time: 0.0533
INFO - 2025-07-03 08:50:11 --> Config Class Initialized
INFO - 2025-07-03 08:50:11 --> Hooks Class Initialized
DEBUG - 2025-07-03 08:50:11 --> UTF-8 Support Enabled
INFO - 2025-07-03 08:50:11 --> Utf8 Class Initialized
INFO - 2025-07-03 08:50:11 --> URI Class Initialized
INFO - 2025-07-03 08:50:11 --> Router Class Initialized
INFO - 2025-07-03 08:50:11 --> Output Class Initialized
INFO - 2025-07-03 08:50:11 --> Security Class Initialized
DEBUG - 2025-07-03 08:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 08:50:11 --> Input Class Initialized
INFO - 2025-07-03 08:50:11 --> Language Class Initialized
INFO - 2025-07-03 08:50:11 --> Loader Class Initialized
INFO - 2025-07-03 08:50:11 --> Helper loaded: url_helper
INFO - 2025-07-03 08:50:11 --> Helper loaded: form_helper
INFO - 2025-07-03 08:50:11 --> Database Driver Class Initialized
DEBUG - 2025-07-03 08:50:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 08:50:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 08:50:11 --> Controller Class Initialized
INFO - 2025-07-03 08:50:11 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 08:50:11 --> Model "User_model" initialized
INFO - 2025-07-03 08:50:11 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 08:50:11 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 08:50:11 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/start.php
INFO - 2025-07-03 08:50:11 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 08:50:11 --> Final output sent to browser
DEBUG - 2025-07-03 08:50:11 --> Total execution time: 0.0388
INFO - 2025-07-03 08:50:15 --> Config Class Initialized
INFO - 2025-07-03 08:50:15 --> Hooks Class Initialized
DEBUG - 2025-07-03 08:50:15 --> UTF-8 Support Enabled
INFO - 2025-07-03 08:50:15 --> Utf8 Class Initialized
INFO - 2025-07-03 08:50:15 --> URI Class Initialized
INFO - 2025-07-03 08:50:15 --> Router Class Initialized
INFO - 2025-07-03 08:50:15 --> Output Class Initialized
INFO - 2025-07-03 08:50:15 --> Security Class Initialized
DEBUG - 2025-07-03 08:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 08:50:15 --> Input Class Initialized
INFO - 2025-07-03 08:50:15 --> Language Class Initialized
INFO - 2025-07-03 08:50:15 --> Loader Class Initialized
INFO - 2025-07-03 08:50:15 --> Helper loaded: url_helper
INFO - 2025-07-03 08:50:15 --> Helper loaded: form_helper
INFO - 2025-07-03 08:50:15 --> Database Driver Class Initialized
DEBUG - 2025-07-03 08:50:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 08:50:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 08:50:15 --> Controller Class Initialized
INFO - 2025-07-03 08:50:15 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 08:50:15 --> Model "User_model" initialized
INFO - 2025-07-03 08:50:15 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 08:50:15 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 08:50:15 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/start.php
INFO - 2025-07-03 08:50:15 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 08:50:15 --> Final output sent to browser
DEBUG - 2025-07-03 08:50:15 --> Total execution time: 0.0440
INFO - 2025-07-03 08:51:36 --> Config Class Initialized
INFO - 2025-07-03 08:51:36 --> Hooks Class Initialized
DEBUG - 2025-07-03 08:51:36 --> UTF-8 Support Enabled
INFO - 2025-07-03 08:51:36 --> Utf8 Class Initialized
INFO - 2025-07-03 08:51:36 --> URI Class Initialized
INFO - 2025-07-03 08:51:36 --> Router Class Initialized
INFO - 2025-07-03 08:51:36 --> Output Class Initialized
INFO - 2025-07-03 08:51:36 --> Security Class Initialized
DEBUG - 2025-07-03 08:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 08:51:36 --> Input Class Initialized
INFO - 2025-07-03 08:51:36 --> Language Class Initialized
INFO - 2025-07-03 08:51:36 --> Loader Class Initialized
INFO - 2025-07-03 08:51:36 --> Helper loaded: url_helper
INFO - 2025-07-03 08:51:36 --> Helper loaded: form_helper
INFO - 2025-07-03 08:51:36 --> Database Driver Class Initialized
DEBUG - 2025-07-03 08:51:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 08:51:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 08:51:36 --> Controller Class Initialized
INFO - 2025-07-03 08:51:36 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 08:51:36 --> Model "User_model" initialized
INFO - 2025-07-03 08:51:36 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 08:51:36 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 08:51:36 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/start.php
INFO - 2025-07-03 08:51:36 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 08:51:36 --> Final output sent to browser
DEBUG - 2025-07-03 08:51:36 --> Total execution time: 0.0533
INFO - 2025-07-03 08:55:13 --> Config Class Initialized
INFO - 2025-07-03 08:55:13 --> Hooks Class Initialized
DEBUG - 2025-07-03 08:55:13 --> UTF-8 Support Enabled
INFO - 2025-07-03 08:55:13 --> Utf8 Class Initialized
INFO - 2025-07-03 08:55:13 --> URI Class Initialized
INFO - 2025-07-03 08:55:13 --> Router Class Initialized
INFO - 2025-07-03 08:55:13 --> Output Class Initialized
INFO - 2025-07-03 08:55:13 --> Security Class Initialized
DEBUG - 2025-07-03 08:55:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 08:55:13 --> Input Class Initialized
INFO - 2025-07-03 08:55:13 --> Language Class Initialized
INFO - 2025-07-03 08:55:13 --> Loader Class Initialized
INFO - 2025-07-03 08:55:13 --> Helper loaded: url_helper
INFO - 2025-07-03 08:55:13 --> Helper loaded: form_helper
INFO - 2025-07-03 08:55:13 --> Database Driver Class Initialized
DEBUG - 2025-07-03 08:55:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 08:55:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 08:55:13 --> Controller Class Initialized
INFO - 2025-07-03 08:55:13 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 08:55:13 --> Model "User_model" initialized
INFO - 2025-07-03 08:55:13 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 08:55:13 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 08:55:13 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-07-03 08:55:13 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 08:55:13 --> Final output sent to browser
DEBUG - 2025-07-03 08:55:13 --> Total execution time: 0.0582
INFO - 2025-07-03 08:55:15 --> Config Class Initialized
INFO - 2025-07-03 08:55:15 --> Hooks Class Initialized
DEBUG - 2025-07-03 08:55:15 --> UTF-8 Support Enabled
INFO - 2025-07-03 08:55:15 --> Utf8 Class Initialized
INFO - 2025-07-03 08:55:15 --> URI Class Initialized
INFO - 2025-07-03 08:55:15 --> Router Class Initialized
INFO - 2025-07-03 08:55:15 --> Output Class Initialized
INFO - 2025-07-03 08:55:15 --> Security Class Initialized
DEBUG - 2025-07-03 08:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 08:55:15 --> Input Class Initialized
INFO - 2025-07-03 08:55:15 --> Language Class Initialized
INFO - 2025-07-03 08:55:15 --> Loader Class Initialized
INFO - 2025-07-03 08:55:15 --> Helper loaded: url_helper
INFO - 2025-07-03 08:55:15 --> Helper loaded: form_helper
INFO - 2025-07-03 08:55:15 --> Database Driver Class Initialized
DEBUG - 2025-07-03 08:55:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 08:55:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 08:55:15 --> Controller Class Initialized
INFO - 2025-07-03 08:55:15 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 08:55:15 --> Model "User_model" initialized
INFO - 2025-07-03 08:55:15 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 08:55:15 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 08:55:15 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/level.php
INFO - 2025-07-03 08:55:15 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 08:55:15 --> Final output sent to browser
DEBUG - 2025-07-03 08:55:15 --> Total execution time: 0.0616
INFO - 2025-07-03 08:55:17 --> Config Class Initialized
INFO - 2025-07-03 08:55:17 --> Hooks Class Initialized
DEBUG - 2025-07-03 08:55:17 --> UTF-8 Support Enabled
INFO - 2025-07-03 08:55:17 --> Utf8 Class Initialized
INFO - 2025-07-03 08:55:17 --> URI Class Initialized
INFO - 2025-07-03 08:55:17 --> Router Class Initialized
INFO - 2025-07-03 08:55:17 --> Output Class Initialized
INFO - 2025-07-03 08:55:17 --> Security Class Initialized
DEBUG - 2025-07-03 08:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 08:55:17 --> Input Class Initialized
INFO - 2025-07-03 08:55:17 --> Language Class Initialized
INFO - 2025-07-03 08:55:17 --> Loader Class Initialized
INFO - 2025-07-03 08:55:17 --> Helper loaded: url_helper
INFO - 2025-07-03 08:55:17 --> Helper loaded: form_helper
INFO - 2025-07-03 08:55:17 --> Database Driver Class Initialized
DEBUG - 2025-07-03 08:55:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 08:55:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 08:55:17 --> Controller Class Initialized
INFO - 2025-07-03 08:55:17 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 08:55:17 --> Model "User_model" initialized
INFO - 2025-07-03 08:55:17 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 08:55:17 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 08:55:17 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-07-03 08:55:17 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 08:55:17 --> Final output sent to browser
DEBUG - 2025-07-03 08:55:17 --> Total execution time: 0.0463
INFO - 2025-07-03 08:55:20 --> Config Class Initialized
INFO - 2025-07-03 08:55:20 --> Hooks Class Initialized
DEBUG - 2025-07-03 08:55:20 --> UTF-8 Support Enabled
INFO - 2025-07-03 08:55:20 --> Utf8 Class Initialized
INFO - 2025-07-03 08:55:20 --> URI Class Initialized
INFO - 2025-07-03 08:55:20 --> Router Class Initialized
INFO - 2025-07-03 08:55:20 --> Output Class Initialized
INFO - 2025-07-03 08:55:20 --> Security Class Initialized
DEBUG - 2025-07-03 08:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 08:55:20 --> Input Class Initialized
INFO - 2025-07-03 08:55:20 --> Language Class Initialized
INFO - 2025-07-03 08:55:20 --> Loader Class Initialized
INFO - 2025-07-03 08:55:20 --> Helper loaded: url_helper
INFO - 2025-07-03 08:55:20 --> Helper loaded: form_helper
INFO - 2025-07-03 08:55:20 --> Database Driver Class Initialized
DEBUG - 2025-07-03 08:55:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 08:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 08:55:20 --> Controller Class Initialized
INFO - 2025-07-03 08:55:20 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 08:55:20 --> Model "User_model" initialized
INFO - 2025-07-03 08:55:20 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 08:55:20 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 08:55:20 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/start.php
INFO - 2025-07-03 08:55:20 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 08:55:20 --> Final output sent to browser
DEBUG - 2025-07-03 08:55:20 --> Total execution time: 0.0388
INFO - 2025-07-03 08:57:05 --> Config Class Initialized
INFO - 2025-07-03 08:57:05 --> Hooks Class Initialized
DEBUG - 2025-07-03 08:57:05 --> UTF-8 Support Enabled
INFO - 2025-07-03 08:57:05 --> Utf8 Class Initialized
INFO - 2025-07-03 08:57:05 --> URI Class Initialized
INFO - 2025-07-03 08:57:05 --> Router Class Initialized
INFO - 2025-07-03 08:57:05 --> Output Class Initialized
INFO - 2025-07-03 08:57:05 --> Security Class Initialized
DEBUG - 2025-07-03 08:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 08:57:05 --> Input Class Initialized
INFO - 2025-07-03 08:57:05 --> Language Class Initialized
INFO - 2025-07-03 08:57:05 --> Loader Class Initialized
INFO - 2025-07-03 08:57:05 --> Helper loaded: url_helper
INFO - 2025-07-03 08:57:05 --> Helper loaded: form_helper
INFO - 2025-07-03 08:57:05 --> Database Driver Class Initialized
DEBUG - 2025-07-03 08:57:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 08:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 08:57:05 --> Controller Class Initialized
INFO - 2025-07-03 08:57:05 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 08:57:05 --> Model "User_model" initialized
INFO - 2025-07-03 08:57:05 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 08:57:05 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 08:57:05 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/start.php
INFO - 2025-07-03 08:57:05 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 08:57:05 --> Final output sent to browser
DEBUG - 2025-07-03 08:57:05 --> Total execution time: 0.0463
INFO - 2025-07-03 08:58:26 --> Config Class Initialized
INFO - 2025-07-03 08:58:26 --> Hooks Class Initialized
DEBUG - 2025-07-03 08:58:26 --> UTF-8 Support Enabled
INFO - 2025-07-03 08:58:26 --> Utf8 Class Initialized
INFO - 2025-07-03 08:58:26 --> URI Class Initialized
INFO - 2025-07-03 08:58:26 --> Router Class Initialized
INFO - 2025-07-03 08:58:26 --> Output Class Initialized
INFO - 2025-07-03 08:58:26 --> Security Class Initialized
DEBUG - 2025-07-03 08:58:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 08:58:26 --> Input Class Initialized
INFO - 2025-07-03 08:58:26 --> Language Class Initialized
INFO - 2025-07-03 08:58:26 --> Loader Class Initialized
INFO - 2025-07-03 08:58:26 --> Helper loaded: url_helper
INFO - 2025-07-03 08:58:26 --> Helper loaded: form_helper
INFO - 2025-07-03 08:58:26 --> Database Driver Class Initialized
DEBUG - 2025-07-03 08:58:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 08:58:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 08:58:26 --> Controller Class Initialized
INFO - 2025-07-03 08:58:26 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 08:58:26 --> Model "User_model" initialized
INFO - 2025-07-03 08:58:26 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 08:58:26 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 08:58:26 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/start.php
INFO - 2025-07-03 08:58:26 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 08:58:26 --> Final output sent to browser
DEBUG - 2025-07-03 08:58:26 --> Total execution time: 0.0443
INFO - 2025-07-03 08:58:29 --> Config Class Initialized
INFO - 2025-07-03 08:58:29 --> Hooks Class Initialized
DEBUG - 2025-07-03 08:58:29 --> UTF-8 Support Enabled
INFO - 2025-07-03 08:58:29 --> Utf8 Class Initialized
INFO - 2025-07-03 08:58:29 --> URI Class Initialized
INFO - 2025-07-03 08:58:29 --> Router Class Initialized
INFO - 2025-07-03 08:58:29 --> Output Class Initialized
INFO - 2025-07-03 08:58:29 --> Security Class Initialized
DEBUG - 2025-07-03 08:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 08:58:29 --> Input Class Initialized
INFO - 2025-07-03 08:58:29 --> Language Class Initialized
INFO - 2025-07-03 08:58:29 --> Loader Class Initialized
INFO - 2025-07-03 08:58:29 --> Helper loaded: url_helper
INFO - 2025-07-03 08:58:29 --> Helper loaded: form_helper
INFO - 2025-07-03 08:58:29 --> Database Driver Class Initialized
DEBUG - 2025-07-03 08:58:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 08:58:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 08:58:29 --> Controller Class Initialized
INFO - 2025-07-03 08:58:29 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 08:58:29 --> Model "User_model" initialized
INFO - 2025-07-03 08:58:29 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 08:58:29 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 08:58:29 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/start.php
INFO - 2025-07-03 08:58:29 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 08:58:29 --> Final output sent to browser
DEBUG - 2025-07-03 08:58:29 --> Total execution time: 0.0383
INFO - 2025-07-03 08:59:26 --> Config Class Initialized
INFO - 2025-07-03 08:59:26 --> Hooks Class Initialized
DEBUG - 2025-07-03 08:59:26 --> UTF-8 Support Enabled
INFO - 2025-07-03 08:59:26 --> Utf8 Class Initialized
INFO - 2025-07-03 08:59:26 --> URI Class Initialized
INFO - 2025-07-03 08:59:26 --> Router Class Initialized
INFO - 2025-07-03 08:59:26 --> Output Class Initialized
INFO - 2025-07-03 08:59:26 --> Security Class Initialized
DEBUG - 2025-07-03 08:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 08:59:26 --> Input Class Initialized
INFO - 2025-07-03 08:59:26 --> Language Class Initialized
INFO - 2025-07-03 08:59:26 --> Loader Class Initialized
INFO - 2025-07-03 08:59:26 --> Helper loaded: url_helper
INFO - 2025-07-03 08:59:26 --> Helper loaded: form_helper
INFO - 2025-07-03 08:59:26 --> Database Driver Class Initialized
DEBUG - 2025-07-03 08:59:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 08:59:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 08:59:26 --> Controller Class Initialized
INFO - 2025-07-03 08:59:26 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 08:59:26 --> Model "User_model" initialized
INFO - 2025-07-03 08:59:26 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 08:59:26 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 08:59:26 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-07-03 08:59:26 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 08:59:26 --> Final output sent to browser
DEBUG - 2025-07-03 08:59:26 --> Total execution time: 0.0424
INFO - 2025-07-03 08:59:27 --> Config Class Initialized
INFO - 2025-07-03 08:59:27 --> Hooks Class Initialized
DEBUG - 2025-07-03 08:59:27 --> UTF-8 Support Enabled
INFO - 2025-07-03 08:59:27 --> Utf8 Class Initialized
INFO - 2025-07-03 08:59:27 --> URI Class Initialized
INFO - 2025-07-03 08:59:27 --> Router Class Initialized
INFO - 2025-07-03 08:59:27 --> Output Class Initialized
INFO - 2025-07-03 08:59:27 --> Security Class Initialized
DEBUG - 2025-07-03 08:59:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 08:59:27 --> Input Class Initialized
INFO - 2025-07-03 08:59:27 --> Language Class Initialized
INFO - 2025-07-03 08:59:27 --> Loader Class Initialized
INFO - 2025-07-03 08:59:27 --> Helper loaded: url_helper
INFO - 2025-07-03 08:59:27 --> Helper loaded: form_helper
INFO - 2025-07-03 08:59:27 --> Database Driver Class Initialized
DEBUG - 2025-07-03 08:59:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 08:59:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 08:59:27 --> Controller Class Initialized
INFO - 2025-07-03 08:59:27 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 08:59:27 --> Model "User_model" initialized
INFO - 2025-07-03 08:59:27 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 08:59:27 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 08:59:27 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/level.php
INFO - 2025-07-03 08:59:27 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 08:59:27 --> Final output sent to browser
DEBUG - 2025-07-03 08:59:27 --> Total execution time: 0.0437
INFO - 2025-07-03 08:59:28 --> Config Class Initialized
INFO - 2025-07-03 08:59:28 --> Hooks Class Initialized
DEBUG - 2025-07-03 08:59:28 --> UTF-8 Support Enabled
INFO - 2025-07-03 08:59:28 --> Utf8 Class Initialized
INFO - 2025-07-03 08:59:28 --> URI Class Initialized
INFO - 2025-07-03 08:59:28 --> Router Class Initialized
INFO - 2025-07-03 08:59:28 --> Output Class Initialized
INFO - 2025-07-03 08:59:28 --> Security Class Initialized
DEBUG - 2025-07-03 08:59:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 08:59:28 --> Input Class Initialized
INFO - 2025-07-03 08:59:28 --> Language Class Initialized
INFO - 2025-07-03 08:59:28 --> Loader Class Initialized
INFO - 2025-07-03 08:59:28 --> Helper loaded: url_helper
INFO - 2025-07-03 08:59:28 --> Helper loaded: form_helper
INFO - 2025-07-03 08:59:28 --> Database Driver Class Initialized
DEBUG - 2025-07-03 08:59:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 08:59:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 08:59:28 --> Controller Class Initialized
INFO - 2025-07-03 08:59:28 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 08:59:28 --> Model "User_model" initialized
INFO - 2025-07-03 08:59:28 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 08:59:28 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 08:59:28 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-07-03 08:59:28 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 08:59:28 --> Final output sent to browser
DEBUG - 2025-07-03 08:59:28 --> Total execution time: 0.0497
INFO - 2025-07-03 08:59:33 --> Config Class Initialized
INFO - 2025-07-03 08:59:33 --> Hooks Class Initialized
DEBUG - 2025-07-03 08:59:33 --> UTF-8 Support Enabled
INFO - 2025-07-03 08:59:33 --> Utf8 Class Initialized
INFO - 2025-07-03 08:59:33 --> URI Class Initialized
INFO - 2025-07-03 08:59:33 --> Router Class Initialized
INFO - 2025-07-03 08:59:33 --> Output Class Initialized
INFO - 2025-07-03 08:59:33 --> Security Class Initialized
DEBUG - 2025-07-03 08:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 08:59:33 --> Input Class Initialized
INFO - 2025-07-03 08:59:33 --> Language Class Initialized
INFO - 2025-07-03 08:59:33 --> Loader Class Initialized
INFO - 2025-07-03 08:59:33 --> Helper loaded: url_helper
INFO - 2025-07-03 08:59:33 --> Helper loaded: form_helper
INFO - 2025-07-03 08:59:33 --> Database Driver Class Initialized
DEBUG - 2025-07-03 08:59:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 08:59:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 08:59:33 --> Controller Class Initialized
INFO - 2025-07-03 08:59:33 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 08:59:33 --> Model "User_model" initialized
INFO - 2025-07-03 08:59:33 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 08:59:33 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 08:59:33 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/start.php
INFO - 2025-07-03 08:59:33 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 08:59:33 --> Final output sent to browser
DEBUG - 2025-07-03 08:59:33 --> Total execution time: 0.0377
INFO - 2025-07-03 08:59:36 --> Config Class Initialized
INFO - 2025-07-03 08:59:36 --> Hooks Class Initialized
DEBUG - 2025-07-03 08:59:36 --> UTF-8 Support Enabled
INFO - 2025-07-03 08:59:36 --> Utf8 Class Initialized
INFO - 2025-07-03 08:59:36 --> URI Class Initialized
INFO - 2025-07-03 08:59:36 --> Router Class Initialized
INFO - 2025-07-03 08:59:36 --> Output Class Initialized
INFO - 2025-07-03 08:59:36 --> Security Class Initialized
DEBUG - 2025-07-03 08:59:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 08:59:36 --> Input Class Initialized
INFO - 2025-07-03 08:59:36 --> Language Class Initialized
INFO - 2025-07-03 08:59:36 --> Loader Class Initialized
INFO - 2025-07-03 08:59:36 --> Helper loaded: url_helper
INFO - 2025-07-03 08:59:36 --> Helper loaded: form_helper
INFO - 2025-07-03 08:59:36 --> Database Driver Class Initialized
DEBUG - 2025-07-03 08:59:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 08:59:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 08:59:36 --> Controller Class Initialized
INFO - 2025-07-03 08:59:36 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 08:59:36 --> Model "User_model" initialized
INFO - 2025-07-03 08:59:36 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 08:59:36 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 08:59:36 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/start.php
INFO - 2025-07-03 08:59:36 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 08:59:36 --> Final output sent to browser
DEBUG - 2025-07-03 08:59:36 --> Total execution time: 0.0423
INFO - 2025-07-03 08:59:41 --> Config Class Initialized
INFO - 2025-07-03 08:59:41 --> Hooks Class Initialized
DEBUG - 2025-07-03 08:59:41 --> UTF-8 Support Enabled
INFO - 2025-07-03 08:59:41 --> Utf8 Class Initialized
INFO - 2025-07-03 08:59:41 --> URI Class Initialized
INFO - 2025-07-03 08:59:41 --> Router Class Initialized
INFO - 2025-07-03 08:59:41 --> Output Class Initialized
INFO - 2025-07-03 08:59:41 --> Security Class Initialized
DEBUG - 2025-07-03 08:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 08:59:41 --> Input Class Initialized
INFO - 2025-07-03 08:59:41 --> Language Class Initialized
INFO - 2025-07-03 08:59:41 --> Loader Class Initialized
INFO - 2025-07-03 08:59:41 --> Helper loaded: url_helper
INFO - 2025-07-03 08:59:41 --> Helper loaded: form_helper
INFO - 2025-07-03 08:59:41 --> Database Driver Class Initialized
DEBUG - 2025-07-03 08:59:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 08:59:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 08:59:41 --> Controller Class Initialized
INFO - 2025-07-03 08:59:41 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 08:59:41 --> Model "User_model" initialized
INFO - 2025-07-03 08:59:41 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 08:59:41 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 08:59:41 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/start.php
INFO - 2025-07-03 08:59:41 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 08:59:41 --> Final output sent to browser
DEBUG - 2025-07-03 08:59:41 --> Total execution time: 0.0383
INFO - 2025-07-03 08:59:51 --> Config Class Initialized
INFO - 2025-07-03 08:59:51 --> Hooks Class Initialized
DEBUG - 2025-07-03 08:59:51 --> UTF-8 Support Enabled
INFO - 2025-07-03 08:59:51 --> Utf8 Class Initialized
INFO - 2025-07-03 08:59:51 --> URI Class Initialized
INFO - 2025-07-03 08:59:51 --> Router Class Initialized
INFO - 2025-07-03 08:59:51 --> Output Class Initialized
INFO - 2025-07-03 08:59:51 --> Security Class Initialized
DEBUG - 2025-07-03 08:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 08:59:51 --> Input Class Initialized
INFO - 2025-07-03 08:59:51 --> Language Class Initialized
INFO - 2025-07-03 08:59:51 --> Loader Class Initialized
INFO - 2025-07-03 08:59:51 --> Helper loaded: url_helper
INFO - 2025-07-03 08:59:51 --> Helper loaded: form_helper
INFO - 2025-07-03 08:59:51 --> Database Driver Class Initialized
DEBUG - 2025-07-03 08:59:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 08:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 08:59:51 --> Controller Class Initialized
INFO - 2025-07-03 08:59:51 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 08:59:51 --> Model "User_model" initialized
INFO - 2025-07-03 08:59:51 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 08:59:51 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 08:59:51 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/start.php
INFO - 2025-07-03 08:59:51 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 08:59:51 --> Final output sent to browser
DEBUG - 2025-07-03 08:59:51 --> Total execution time: 0.0394
INFO - 2025-07-03 09:00:26 --> Config Class Initialized
INFO - 2025-07-03 09:00:26 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:00:26 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:00:26 --> Utf8 Class Initialized
INFO - 2025-07-03 09:00:26 --> URI Class Initialized
INFO - 2025-07-03 09:00:26 --> Router Class Initialized
INFO - 2025-07-03 09:00:26 --> Output Class Initialized
INFO - 2025-07-03 09:00:26 --> Security Class Initialized
DEBUG - 2025-07-03 09:00:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:00:26 --> Input Class Initialized
INFO - 2025-07-03 09:00:26 --> Language Class Initialized
INFO - 2025-07-03 09:00:26 --> Loader Class Initialized
INFO - 2025-07-03 09:00:26 --> Helper loaded: url_helper
INFO - 2025-07-03 09:00:26 --> Helper loaded: form_helper
INFO - 2025-07-03 09:00:26 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:00:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:00:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:00:26 --> Controller Class Initialized
INFO - 2025-07-03 09:00:26 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:00:26 --> Model "User_model" initialized
INFO - 2025-07-03 09:00:26 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:00:26 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:00:26 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-07-03 09:00:26 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:00:26 --> Final output sent to browser
DEBUG - 2025-07-03 09:00:26 --> Total execution time: 0.0421
INFO - 2025-07-03 09:00:27 --> Config Class Initialized
INFO - 2025-07-03 09:00:27 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:00:27 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:00:27 --> Utf8 Class Initialized
INFO - 2025-07-03 09:00:27 --> URI Class Initialized
INFO - 2025-07-03 09:00:27 --> Router Class Initialized
INFO - 2025-07-03 09:00:27 --> Output Class Initialized
INFO - 2025-07-03 09:00:27 --> Security Class Initialized
DEBUG - 2025-07-03 09:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:00:27 --> Input Class Initialized
INFO - 2025-07-03 09:00:27 --> Language Class Initialized
INFO - 2025-07-03 09:00:27 --> Loader Class Initialized
INFO - 2025-07-03 09:00:27 --> Helper loaded: url_helper
INFO - 2025-07-03 09:00:27 --> Helper loaded: form_helper
INFO - 2025-07-03 09:00:27 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:00:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:00:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:00:27 --> Controller Class Initialized
INFO - 2025-07-03 09:00:27 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:00:27 --> Model "User_model" initialized
INFO - 2025-07-03 09:00:27 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:00:27 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:00:27 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/level.php
INFO - 2025-07-03 09:00:27 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:00:27 --> Final output sent to browser
DEBUG - 2025-07-03 09:00:27 --> Total execution time: 0.0439
INFO - 2025-07-03 09:00:29 --> Config Class Initialized
INFO - 2025-07-03 09:00:29 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:00:29 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:00:29 --> Utf8 Class Initialized
INFO - 2025-07-03 09:00:29 --> URI Class Initialized
INFO - 2025-07-03 09:00:29 --> Router Class Initialized
INFO - 2025-07-03 09:00:29 --> Output Class Initialized
INFO - 2025-07-03 09:00:29 --> Security Class Initialized
DEBUG - 2025-07-03 09:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:00:29 --> Input Class Initialized
INFO - 2025-07-03 09:00:29 --> Language Class Initialized
INFO - 2025-07-03 09:00:29 --> Loader Class Initialized
INFO - 2025-07-03 09:00:29 --> Helper loaded: url_helper
INFO - 2025-07-03 09:00:29 --> Helper loaded: form_helper
INFO - 2025-07-03 09:00:29 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:00:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:00:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:00:29 --> Controller Class Initialized
INFO - 2025-07-03 09:00:29 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:00:29 --> Model "User_model" initialized
INFO - 2025-07-03 09:00:29 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:00:29 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:00:29 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-07-03 09:00:29 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:00:29 --> Final output sent to browser
DEBUG - 2025-07-03 09:00:29 --> Total execution time: 0.0366
INFO - 2025-07-03 09:00:37 --> Config Class Initialized
INFO - 2025-07-03 09:00:37 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:00:37 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:00:37 --> Utf8 Class Initialized
INFO - 2025-07-03 09:00:37 --> URI Class Initialized
INFO - 2025-07-03 09:00:37 --> Router Class Initialized
INFO - 2025-07-03 09:00:37 --> Output Class Initialized
INFO - 2025-07-03 09:00:37 --> Security Class Initialized
DEBUG - 2025-07-03 09:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:00:37 --> Input Class Initialized
INFO - 2025-07-03 09:00:37 --> Language Class Initialized
INFO - 2025-07-03 09:00:37 --> Loader Class Initialized
INFO - 2025-07-03 09:00:37 --> Helper loaded: url_helper
INFO - 2025-07-03 09:00:37 --> Helper loaded: form_helper
INFO - 2025-07-03 09:00:37 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:00:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:00:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:00:37 --> Controller Class Initialized
INFO - 2025-07-03 09:00:37 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:00:37 --> Model "User_model" initialized
INFO - 2025-07-03 09:00:37 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:00:37 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
ERROR - 2025-07-03 09:00:37 --> Severity: 8192 --> Implicit conversion from float 88.8 to int loses precision C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard\olahraga\start.php 16
INFO - 2025-07-03 09:00:37 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/start.php
INFO - 2025-07-03 09:00:37 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:00:37 --> Final output sent to browser
DEBUG - 2025-07-03 09:00:37 --> Total execution time: 0.0378
INFO - 2025-07-03 09:02:29 --> Config Class Initialized
INFO - 2025-07-03 09:02:29 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:02:29 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:02:29 --> Utf8 Class Initialized
INFO - 2025-07-03 09:02:29 --> URI Class Initialized
INFO - 2025-07-03 09:02:29 --> Router Class Initialized
INFO - 2025-07-03 09:02:29 --> Output Class Initialized
INFO - 2025-07-03 09:02:29 --> Security Class Initialized
DEBUG - 2025-07-03 09:02:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:02:29 --> Input Class Initialized
INFO - 2025-07-03 09:02:29 --> Language Class Initialized
INFO - 2025-07-03 09:02:29 --> Loader Class Initialized
INFO - 2025-07-03 09:02:29 --> Helper loaded: url_helper
INFO - 2025-07-03 09:02:29 --> Helper loaded: form_helper
INFO - 2025-07-03 09:02:29 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:02:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:02:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:02:29 --> Controller Class Initialized
INFO - 2025-07-03 09:02:29 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:02:29 --> Model "User_model" initialized
INFO - 2025-07-03 09:02:29 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:02:29 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
ERROR - 2025-07-03 09:02:29 --> Severity: 8192 --> Implicit conversion from float 88.8 to int loses precision C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard\olahraga\start.php 16
INFO - 2025-07-03 09:02:29 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/start.php
INFO - 2025-07-03 09:02:29 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:02:29 --> Final output sent to browser
DEBUG - 2025-07-03 09:02:29 --> Total execution time: 0.0429
INFO - 2025-07-03 09:02:41 --> Config Class Initialized
INFO - 2025-07-03 09:02:41 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:02:41 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:02:41 --> Utf8 Class Initialized
INFO - 2025-07-03 09:02:41 --> URI Class Initialized
INFO - 2025-07-03 09:02:41 --> Router Class Initialized
INFO - 2025-07-03 09:02:41 --> Output Class Initialized
INFO - 2025-07-03 09:02:41 --> Security Class Initialized
DEBUG - 2025-07-03 09:02:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:02:41 --> Input Class Initialized
INFO - 2025-07-03 09:02:41 --> Language Class Initialized
INFO - 2025-07-03 09:02:41 --> Loader Class Initialized
INFO - 2025-07-03 09:02:41 --> Helper loaded: url_helper
INFO - 2025-07-03 09:02:41 --> Helper loaded: form_helper
INFO - 2025-07-03 09:02:41 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:02:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:02:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:02:41 --> Controller Class Initialized
INFO - 2025-07-03 09:02:41 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:02:41 --> Model "User_model" initialized
INFO - 2025-07-03 09:02:41 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:02:41 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
ERROR - 2025-07-03 09:02:41 --> Severity: 8192 --> Implicit conversion from float 88.8 to int loses precision C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard\olahraga\start.php 16
INFO - 2025-07-03 09:02:41 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/start.php
INFO - 2025-07-03 09:02:41 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:02:41 --> Final output sent to browser
DEBUG - 2025-07-03 09:02:41 --> Total execution time: 0.0458
INFO - 2025-07-03 09:02:54 --> Config Class Initialized
INFO - 2025-07-03 09:02:54 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:02:54 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:02:54 --> Utf8 Class Initialized
INFO - 2025-07-03 09:02:54 --> URI Class Initialized
INFO - 2025-07-03 09:02:54 --> Router Class Initialized
INFO - 2025-07-03 09:02:54 --> Output Class Initialized
INFO - 2025-07-03 09:02:54 --> Security Class Initialized
DEBUG - 2025-07-03 09:02:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:02:54 --> Input Class Initialized
INFO - 2025-07-03 09:02:54 --> Language Class Initialized
INFO - 2025-07-03 09:02:54 --> Loader Class Initialized
INFO - 2025-07-03 09:02:54 --> Helper loaded: url_helper
INFO - 2025-07-03 09:02:54 --> Helper loaded: form_helper
INFO - 2025-07-03 09:02:54 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:02:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:02:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:02:54 --> Controller Class Initialized
INFO - 2025-07-03 09:02:54 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:02:54 --> Model "User_model" initialized
INFO - 2025-07-03 09:02:54 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:02:54 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:02:54 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-07-03 09:02:54 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:02:54 --> Final output sent to browser
DEBUG - 2025-07-03 09:02:54 --> Total execution time: 0.0342
INFO - 2025-07-03 09:02:56 --> Config Class Initialized
INFO - 2025-07-03 09:02:56 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:02:56 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:02:56 --> Utf8 Class Initialized
INFO - 2025-07-03 09:02:56 --> URI Class Initialized
INFO - 2025-07-03 09:02:56 --> Router Class Initialized
INFO - 2025-07-03 09:02:56 --> Output Class Initialized
INFO - 2025-07-03 09:02:56 --> Security Class Initialized
DEBUG - 2025-07-03 09:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:02:56 --> Input Class Initialized
INFO - 2025-07-03 09:02:56 --> Language Class Initialized
INFO - 2025-07-03 09:02:56 --> Loader Class Initialized
INFO - 2025-07-03 09:02:56 --> Helper loaded: url_helper
INFO - 2025-07-03 09:02:56 --> Helper loaded: form_helper
INFO - 2025-07-03 09:02:56 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:02:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:02:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:02:56 --> Controller Class Initialized
INFO - 2025-07-03 09:02:56 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:02:56 --> Model "User_model" initialized
INFO - 2025-07-03 09:02:56 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:02:56 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:02:56 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/start.php
INFO - 2025-07-03 09:02:56 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:02:56 --> Final output sent to browser
DEBUG - 2025-07-03 09:02:56 --> Total execution time: 0.0397
INFO - 2025-07-03 09:04:07 --> Config Class Initialized
INFO - 2025-07-03 09:04:07 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:04:07 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:04:07 --> Utf8 Class Initialized
INFO - 2025-07-03 09:04:07 --> URI Class Initialized
INFO - 2025-07-03 09:04:07 --> Router Class Initialized
INFO - 2025-07-03 09:04:07 --> Output Class Initialized
INFO - 2025-07-03 09:04:07 --> Security Class Initialized
DEBUG - 2025-07-03 09:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:04:07 --> Input Class Initialized
INFO - 2025-07-03 09:04:07 --> Language Class Initialized
INFO - 2025-07-03 09:04:07 --> Loader Class Initialized
INFO - 2025-07-03 09:04:07 --> Helper loaded: url_helper
INFO - 2025-07-03 09:04:07 --> Helper loaded: form_helper
INFO - 2025-07-03 09:04:07 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:04:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:04:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:04:07 --> Controller Class Initialized
INFO - 2025-07-03 09:04:07 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:04:07 --> Model "User_model" initialized
INFO - 2025-07-03 09:04:07 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:04:07 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:04:07 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-07-03 09:04:07 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:04:07 --> Final output sent to browser
DEBUG - 2025-07-03 09:04:07 --> Total execution time: 0.0407
INFO - 2025-07-03 09:04:09 --> Config Class Initialized
INFO - 2025-07-03 09:04:09 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:04:09 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:04:09 --> Utf8 Class Initialized
INFO - 2025-07-03 09:04:09 --> URI Class Initialized
INFO - 2025-07-03 09:04:09 --> Router Class Initialized
INFO - 2025-07-03 09:04:09 --> Output Class Initialized
INFO - 2025-07-03 09:04:09 --> Security Class Initialized
DEBUG - 2025-07-03 09:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:04:09 --> Input Class Initialized
INFO - 2025-07-03 09:04:09 --> Language Class Initialized
INFO - 2025-07-03 09:04:09 --> Loader Class Initialized
INFO - 2025-07-03 09:04:09 --> Helper loaded: url_helper
INFO - 2025-07-03 09:04:09 --> Helper loaded: form_helper
INFO - 2025-07-03 09:04:09 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:04:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:04:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:04:09 --> Controller Class Initialized
INFO - 2025-07-03 09:04:09 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:04:09 --> Model "User_model" initialized
INFO - 2025-07-03 09:04:09 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:04:09 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:04:09 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/start.php
INFO - 2025-07-03 09:04:09 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:04:09 --> Final output sent to browser
DEBUG - 2025-07-03 09:04:09 --> Total execution time: 0.0452
INFO - 2025-07-03 09:07:32 --> Config Class Initialized
INFO - 2025-07-03 09:07:32 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:07:32 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:07:32 --> Utf8 Class Initialized
INFO - 2025-07-03 09:07:32 --> URI Class Initialized
INFO - 2025-07-03 09:07:32 --> Router Class Initialized
INFO - 2025-07-03 09:07:32 --> Output Class Initialized
INFO - 2025-07-03 09:07:32 --> Security Class Initialized
DEBUG - 2025-07-03 09:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:07:32 --> Input Class Initialized
INFO - 2025-07-03 09:07:32 --> Language Class Initialized
INFO - 2025-07-03 09:07:32 --> Loader Class Initialized
INFO - 2025-07-03 09:07:32 --> Helper loaded: url_helper
INFO - 2025-07-03 09:07:32 --> Helper loaded: form_helper
INFO - 2025-07-03 09:07:32 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:07:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:07:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:07:32 --> Controller Class Initialized
INFO - 2025-07-03 09:07:32 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:07:32 --> Model "User_model" initialized
INFO - 2025-07-03 09:07:32 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:07:32 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:07:32 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/start.php
INFO - 2025-07-03 09:07:32 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:07:32 --> Final output sent to browser
DEBUG - 2025-07-03 09:07:32 --> Total execution time: 0.0400
INFO - 2025-07-03 09:07:32 --> Config Class Initialized
INFO - 2025-07-03 09:07:32 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:07:32 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:07:32 --> Utf8 Class Initialized
INFO - 2025-07-03 09:07:32 --> URI Class Initialized
INFO - 2025-07-03 09:07:32 --> Router Class Initialized
INFO - 2025-07-03 09:07:32 --> Output Class Initialized
INFO - 2025-07-03 09:07:32 --> Security Class Initialized
DEBUG - 2025-07-03 09:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:07:32 --> Input Class Initialized
INFO - 2025-07-03 09:07:32 --> Language Class Initialized
INFO - 2025-07-03 09:07:32 --> Loader Class Initialized
INFO - 2025-07-03 09:07:32 --> Helper loaded: url_helper
INFO - 2025-07-03 09:07:32 --> Helper loaded: form_helper
INFO - 2025-07-03 09:07:32 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:07:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:07:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:07:32 --> Controller Class Initialized
INFO - 2025-07-03 09:07:32 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:07:32 --> Model "User_model" initialized
ERROR - 2025-07-03 09:07:32 --> Severity: Warning --> Attempt to read property "target_otot" on null C:\xamp\htdocs\fitnessrecordneww\application\controllers\Olahraga.php 74
ERROR - 2025-07-03 09:07:32 --> Severity: Warning --> Attempt to read property "level" on null C:\xamp\htdocs\fitnessrecordneww\application\controllers\Olahraga.php 74
ERROR - 2025-07-03 09:07:32 --> Severity: Warning --> Attempt to read property "target_otot" on null C:\xamp\htdocs\fitnessrecordneww\application\controllers\Olahraga.php 77
ERROR - 2025-07-03 09:07:32 --> Severity: Warning --> Attempt to read property "level" on null C:\xamp\htdocs\fitnessrecordneww\application\controllers\Olahraga.php 78
INFO - 2025-07-03 09:07:32 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:07:32 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
ERROR - 2025-07-03 09:07:32 --> Severity: 8192 --> ucfirst(): Passing null to parameter #1 ($string) of type string is deprecated C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard\olahraga\start.php 10
ERROR - 2025-07-03 09:07:32 --> Severity: 8192 --> ucfirst(): Passing null to parameter #1 ($string) of type string is deprecated C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard\olahraga\start.php 10
ERROR - 2025-07-03 09:07:32 --> Severity: Warning --> Attempt to read property "durasi" on null C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard\olahraga\start.php 14
ERROR - 2025-07-03 09:07:32 --> Severity: Warning --> Attempt to read property "nama_latihan" on null C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard\olahraga\start.php 26
ERROR - 2025-07-03 09:07:32 --> Severity: Warning --> Attempt to read property "video_url" on null C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard\olahraga\start.php 29
ERROR - 2025-07-03 09:07:32 --> Severity: Warning --> Attempt to read property "nama_latihan" on null C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard\olahraga\start.php 80
ERROR - 2025-07-03 09:07:32 --> Severity: Warning --> Attempt to read property "durasi" on null C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard\olahraga\start.php 81
ERROR - 2025-07-03 09:07:32 --> Severity: Warning --> Attempt to read property "kalori" on null C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard\olahraga\start.php 82
ERROR - 2025-07-03 09:07:32 --> Severity: Warning --> Attempt to read property "durasi" on null C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard\olahraga\start.php 82
INFO - 2025-07-03 09:07:32 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/start.php
INFO - 2025-07-03 09:07:32 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:07:32 --> Final output sent to browser
DEBUG - 2025-07-03 09:07:32 --> Total execution time: 0.0707
INFO - 2025-07-03 09:07:33 --> Config Class Initialized
INFO - 2025-07-03 09:07:33 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:07:33 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:07:33 --> Utf8 Class Initialized
INFO - 2025-07-03 09:11:44 --> Config Class Initialized
INFO - 2025-07-03 09:11:44 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:11:44 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:11:44 --> Utf8 Class Initialized
INFO - 2025-07-03 09:11:44 --> URI Class Initialized
INFO - 2025-07-03 09:11:44 --> Router Class Initialized
INFO - 2025-07-03 09:11:44 --> Output Class Initialized
INFO - 2025-07-03 09:11:44 --> Security Class Initialized
DEBUG - 2025-07-03 09:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:11:44 --> Input Class Initialized
INFO - 2025-07-03 09:11:44 --> Language Class Initialized
INFO - 2025-07-03 09:11:44 --> Loader Class Initialized
INFO - 2025-07-03 09:11:44 --> Helper loaded: url_helper
INFO - 2025-07-03 09:11:44 --> Helper loaded: form_helper
INFO - 2025-07-03 09:11:44 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:11:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:11:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:11:44 --> Controller Class Initialized
INFO - 2025-07-03 09:11:44 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:11:44 --> Model "User_model" initialized
INFO - 2025-07-03 09:11:44 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:11:44 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:11:44 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/start.php
INFO - 2025-07-03 09:11:44 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:11:44 --> Final output sent to browser
DEBUG - 2025-07-03 09:11:44 --> Total execution time: 0.0389
INFO - 2025-07-03 09:13:02 --> Config Class Initialized
INFO - 2025-07-03 09:13:02 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:13:02 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:13:02 --> Utf8 Class Initialized
INFO - 2025-07-03 09:13:02 --> URI Class Initialized
INFO - 2025-07-03 09:13:02 --> Router Class Initialized
INFO - 2025-07-03 09:13:02 --> Output Class Initialized
INFO - 2025-07-03 09:13:02 --> Security Class Initialized
DEBUG - 2025-07-03 09:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:13:02 --> Input Class Initialized
INFO - 2025-07-03 09:13:02 --> Language Class Initialized
INFO - 2025-07-03 09:13:02 --> Loader Class Initialized
INFO - 2025-07-03 09:13:02 --> Helper loaded: url_helper
INFO - 2025-07-03 09:13:02 --> Helper loaded: form_helper
INFO - 2025-07-03 09:13:02 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:13:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:13:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:13:02 --> Controller Class Initialized
INFO - 2025-07-03 09:13:02 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:13:02 --> Model "User_model" initialized
INFO - 2025-07-03 09:13:02 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:13:02 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:13:02 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/start.php
INFO - 2025-07-03 09:13:02 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:13:02 --> Final output sent to browser
DEBUG - 2025-07-03 09:13:02 --> Total execution time: 0.0377
INFO - 2025-07-03 09:14:22 --> Config Class Initialized
INFO - 2025-07-03 09:14:22 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:14:22 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:14:22 --> Utf8 Class Initialized
INFO - 2025-07-03 09:14:22 --> URI Class Initialized
INFO - 2025-07-03 09:14:22 --> Router Class Initialized
INFO - 2025-07-03 09:14:22 --> Output Class Initialized
INFO - 2025-07-03 09:14:22 --> Security Class Initialized
DEBUG - 2025-07-03 09:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:14:22 --> Input Class Initialized
INFO - 2025-07-03 09:14:22 --> Language Class Initialized
INFO - 2025-07-03 09:14:22 --> Loader Class Initialized
INFO - 2025-07-03 09:14:22 --> Helper loaded: url_helper
INFO - 2025-07-03 09:14:22 --> Helper loaded: form_helper
INFO - 2025-07-03 09:14:22 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:14:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:14:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:14:22 --> Controller Class Initialized
INFO - 2025-07-03 09:14:22 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:14:22 --> Model "User_model" initialized
INFO - 2025-07-03 09:14:22 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:14:22 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:14:22 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/start.php
INFO - 2025-07-03 09:14:22 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:14:22 --> Final output sent to browser
DEBUG - 2025-07-03 09:14:22 --> Total execution time: 0.0453
INFO - 2025-07-03 09:15:43 --> Config Class Initialized
INFO - 2025-07-03 09:15:43 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:15:43 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:15:43 --> Utf8 Class Initialized
INFO - 2025-07-03 09:15:43 --> URI Class Initialized
INFO - 2025-07-03 09:15:43 --> Router Class Initialized
INFO - 2025-07-03 09:15:43 --> Output Class Initialized
INFO - 2025-07-03 09:15:43 --> Security Class Initialized
DEBUG - 2025-07-03 09:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:15:43 --> Input Class Initialized
INFO - 2025-07-03 09:15:43 --> Language Class Initialized
INFO - 2025-07-03 09:15:43 --> Loader Class Initialized
INFO - 2025-07-03 09:15:43 --> Helper loaded: url_helper
INFO - 2025-07-03 09:15:43 --> Helper loaded: form_helper
INFO - 2025-07-03 09:15:43 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:15:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:15:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:15:43 --> Controller Class Initialized
INFO - 2025-07-03 09:15:43 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:15:43 --> Model "User_model" initialized
INFO - 2025-07-03 09:15:43 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:15:43 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:15:43 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/start.php
INFO - 2025-07-03 09:15:43 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:15:43 --> Final output sent to browser
DEBUG - 2025-07-03 09:15:43 --> Total execution time: 0.0355
INFO - 2025-07-03 09:16:01 --> Config Class Initialized
INFO - 2025-07-03 09:16:01 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:16:01 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:16:01 --> Utf8 Class Initialized
INFO - 2025-07-03 09:16:01 --> URI Class Initialized
INFO - 2025-07-03 09:16:01 --> Router Class Initialized
INFO - 2025-07-03 09:16:01 --> Output Class Initialized
INFO - 2025-07-03 09:16:01 --> Security Class Initialized
DEBUG - 2025-07-03 09:16:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:16:01 --> Input Class Initialized
INFO - 2025-07-03 09:16:01 --> Language Class Initialized
INFO - 2025-07-03 09:16:01 --> Loader Class Initialized
INFO - 2025-07-03 09:16:01 --> Helper loaded: url_helper
INFO - 2025-07-03 09:16:01 --> Helper loaded: form_helper
INFO - 2025-07-03 09:16:01 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:16:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:16:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:16:01 --> Controller Class Initialized
INFO - 2025-07-03 09:16:01 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:16:01 --> Model "User_model" initialized
INFO - 2025-07-03 09:16:01 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:16:01 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:16:01 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/start.php
INFO - 2025-07-03 09:16:01 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:16:01 --> Final output sent to browser
DEBUG - 2025-07-03 09:16:01 --> Total execution time: 0.0919
INFO - 2025-07-03 09:16:06 --> Config Class Initialized
INFO - 2025-07-03 09:16:06 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:16:06 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:16:06 --> Utf8 Class Initialized
INFO - 2025-07-03 09:16:06 --> URI Class Initialized
INFO - 2025-07-03 09:16:06 --> Router Class Initialized
INFO - 2025-07-03 09:16:06 --> Output Class Initialized
INFO - 2025-07-03 09:16:06 --> Security Class Initialized
DEBUG - 2025-07-03 09:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:16:06 --> Input Class Initialized
INFO - 2025-07-03 09:16:06 --> Language Class Initialized
INFO - 2025-07-03 09:16:06 --> Loader Class Initialized
INFO - 2025-07-03 09:16:06 --> Helper loaded: url_helper
INFO - 2025-07-03 09:16:06 --> Helper loaded: form_helper
INFO - 2025-07-03 09:16:06 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:16:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:16:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:16:06 --> Controller Class Initialized
INFO - 2025-07-03 09:16:06 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:16:06 --> Model "User_model" initialized
INFO - 2025-07-03 09:16:06 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:16:06 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:16:06 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/start.php
INFO - 2025-07-03 09:16:06 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:16:06 --> Final output sent to browser
DEBUG - 2025-07-03 09:16:06 --> Total execution time: 0.0372
INFO - 2025-07-03 09:16:59 --> Config Class Initialized
INFO - 2025-07-03 09:16:59 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:16:59 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:16:59 --> Utf8 Class Initialized
INFO - 2025-07-03 09:16:59 --> URI Class Initialized
INFO - 2025-07-03 09:16:59 --> Router Class Initialized
INFO - 2025-07-03 09:16:59 --> Output Class Initialized
INFO - 2025-07-03 09:16:59 --> Security Class Initialized
DEBUG - 2025-07-03 09:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:16:59 --> Input Class Initialized
INFO - 2025-07-03 09:16:59 --> Language Class Initialized
INFO - 2025-07-03 09:16:59 --> Loader Class Initialized
INFO - 2025-07-03 09:16:59 --> Helper loaded: url_helper
INFO - 2025-07-03 09:16:59 --> Helper loaded: form_helper
INFO - 2025-07-03 09:16:59 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:16:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:16:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:16:59 --> Controller Class Initialized
INFO - 2025-07-03 09:16:59 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:16:59 --> Model "User_model" initialized
INFO - 2025-07-03 09:16:59 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:16:59 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:16:59 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/start.php
INFO - 2025-07-03 09:17:00 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:17:00 --> Final output sent to browser
DEBUG - 2025-07-03 09:17:00 --> Total execution time: 0.0385
INFO - 2025-07-03 09:17:07 --> Config Class Initialized
INFO - 2025-07-03 09:17:07 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:17:07 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:17:07 --> Utf8 Class Initialized
INFO - 2025-07-03 09:17:07 --> URI Class Initialized
INFO - 2025-07-03 09:17:07 --> Router Class Initialized
INFO - 2025-07-03 09:17:07 --> Output Class Initialized
INFO - 2025-07-03 09:17:07 --> Security Class Initialized
DEBUG - 2025-07-03 09:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:17:07 --> Input Class Initialized
INFO - 2025-07-03 09:17:07 --> Language Class Initialized
INFO - 2025-07-03 09:17:07 --> Loader Class Initialized
INFO - 2025-07-03 09:17:07 --> Helper loaded: url_helper
INFO - 2025-07-03 09:17:07 --> Helper loaded: form_helper
INFO - 2025-07-03 09:17:07 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:17:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:17:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:17:07 --> Controller Class Initialized
INFO - 2025-07-03 09:17:07 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:17:07 --> Model "User_model" initialized
INFO - 2025-07-03 09:17:07 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:17:07 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:17:07 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/start.php
INFO - 2025-07-03 09:17:07 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:17:07 --> Final output sent to browser
DEBUG - 2025-07-03 09:17:07 --> Total execution time: 0.0423
INFO - 2025-07-03 09:17:44 --> Config Class Initialized
INFO - 2025-07-03 09:17:44 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:17:44 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:17:44 --> Utf8 Class Initialized
INFO - 2025-07-03 09:17:44 --> URI Class Initialized
INFO - 2025-07-03 09:17:44 --> Router Class Initialized
INFO - 2025-07-03 09:17:44 --> Output Class Initialized
INFO - 2025-07-03 09:17:44 --> Security Class Initialized
DEBUG - 2025-07-03 09:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:17:44 --> Input Class Initialized
INFO - 2025-07-03 09:17:44 --> Language Class Initialized
INFO - 2025-07-03 09:17:44 --> Loader Class Initialized
INFO - 2025-07-03 09:17:44 --> Helper loaded: url_helper
INFO - 2025-07-03 09:17:44 --> Helper loaded: form_helper
INFO - 2025-07-03 09:17:44 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:17:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:17:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:17:44 --> Controller Class Initialized
INFO - 2025-07-03 09:17:44 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:17:44 --> Model "User_model" initialized
INFO - 2025-07-03 09:17:44 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:17:44 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:17:44 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/start.php
INFO - 2025-07-03 09:17:44 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:17:44 --> Final output sent to browser
DEBUG - 2025-07-03 09:17:44 --> Total execution time: 0.0396
INFO - 2025-07-03 09:18:47 --> Config Class Initialized
INFO - 2025-07-03 09:18:47 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:18:47 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:18:47 --> Utf8 Class Initialized
INFO - 2025-07-03 09:18:47 --> URI Class Initialized
INFO - 2025-07-03 09:18:47 --> Router Class Initialized
INFO - 2025-07-03 09:18:47 --> Output Class Initialized
INFO - 2025-07-03 09:18:47 --> Security Class Initialized
DEBUG - 2025-07-03 09:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:18:47 --> Input Class Initialized
INFO - 2025-07-03 09:18:47 --> Language Class Initialized
INFO - 2025-07-03 09:18:47 --> Loader Class Initialized
INFO - 2025-07-03 09:18:47 --> Helper loaded: url_helper
INFO - 2025-07-03 09:18:47 --> Helper loaded: form_helper
INFO - 2025-07-03 09:18:47 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:18:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:18:47 --> Controller Class Initialized
INFO - 2025-07-03 09:18:47 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:18:47 --> Model "User_model" initialized
INFO - 2025-07-03 09:18:47 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:18:47 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:18:47 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-07-03 09:18:47 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:18:47 --> Final output sent to browser
DEBUG - 2025-07-03 09:18:47 --> Total execution time: 0.0461
INFO - 2025-07-03 09:18:50 --> Config Class Initialized
INFO - 2025-07-03 09:18:50 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:18:50 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:18:50 --> Utf8 Class Initialized
INFO - 2025-07-03 09:18:50 --> URI Class Initialized
INFO - 2025-07-03 09:18:50 --> Router Class Initialized
INFO - 2025-07-03 09:18:50 --> Output Class Initialized
INFO - 2025-07-03 09:18:50 --> Security Class Initialized
DEBUG - 2025-07-03 09:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:18:50 --> Input Class Initialized
INFO - 2025-07-03 09:18:50 --> Language Class Initialized
INFO - 2025-07-03 09:18:50 --> Loader Class Initialized
INFO - 2025-07-03 09:18:50 --> Helper loaded: url_helper
INFO - 2025-07-03 09:18:50 --> Helper loaded: form_helper
INFO - 2025-07-03 09:18:50 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:18:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:18:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:18:50 --> Controller Class Initialized
INFO - 2025-07-03 09:18:50 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:18:50 --> Model "User_model" initialized
INFO - 2025-07-03 09:18:50 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:18:50 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:18:50 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/level.php
INFO - 2025-07-03 09:18:50 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:18:50 --> Final output sent to browser
DEBUG - 2025-07-03 09:18:50 --> Total execution time: 0.0335
INFO - 2025-07-03 09:18:51 --> Config Class Initialized
INFO - 2025-07-03 09:18:51 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:18:51 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:18:51 --> Utf8 Class Initialized
INFO - 2025-07-03 09:18:51 --> URI Class Initialized
INFO - 2025-07-03 09:18:51 --> Router Class Initialized
INFO - 2025-07-03 09:18:51 --> Output Class Initialized
INFO - 2025-07-03 09:18:51 --> Security Class Initialized
DEBUG - 2025-07-03 09:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:18:51 --> Input Class Initialized
INFO - 2025-07-03 09:18:51 --> Language Class Initialized
INFO - 2025-07-03 09:18:51 --> Loader Class Initialized
INFO - 2025-07-03 09:18:51 --> Helper loaded: url_helper
INFO - 2025-07-03 09:18:51 --> Helper loaded: form_helper
INFO - 2025-07-03 09:18:51 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:18:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:18:51 --> Controller Class Initialized
INFO - 2025-07-03 09:18:51 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:18:51 --> Model "User_model" initialized
INFO - 2025-07-03 09:18:51 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:18:51 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:18:51 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-07-03 09:18:51 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:18:51 --> Final output sent to browser
DEBUG - 2025-07-03 09:18:51 --> Total execution time: 0.0359
INFO - 2025-07-03 09:19:06 --> Config Class Initialized
INFO - 2025-07-03 09:19:06 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:19:06 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:19:06 --> Utf8 Class Initialized
INFO - 2025-07-03 09:19:06 --> URI Class Initialized
INFO - 2025-07-03 09:19:06 --> Router Class Initialized
INFO - 2025-07-03 09:19:06 --> Output Class Initialized
INFO - 2025-07-03 09:19:06 --> Security Class Initialized
DEBUG - 2025-07-03 09:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:19:06 --> Input Class Initialized
INFO - 2025-07-03 09:19:06 --> Language Class Initialized
INFO - 2025-07-03 09:19:06 --> Loader Class Initialized
INFO - 2025-07-03 09:19:06 --> Helper loaded: url_helper
INFO - 2025-07-03 09:19:06 --> Helper loaded: form_helper
INFO - 2025-07-03 09:19:06 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:19:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:19:06 --> Controller Class Initialized
INFO - 2025-07-03 09:19:06 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:19:06 --> Model "User_model" initialized
INFO - 2025-07-03 09:19:06 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:19:06 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:19:06 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/start.php
INFO - 2025-07-03 09:19:06 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:19:06 --> Final output sent to browser
DEBUG - 2025-07-03 09:19:06 --> Total execution time: 0.0431
INFO - 2025-07-03 09:19:17 --> Config Class Initialized
INFO - 2025-07-03 09:19:17 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:19:17 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:19:17 --> Utf8 Class Initialized
INFO - 2025-07-03 09:19:17 --> URI Class Initialized
INFO - 2025-07-03 09:19:17 --> Router Class Initialized
INFO - 2025-07-03 09:19:17 --> Output Class Initialized
INFO - 2025-07-03 09:19:17 --> Security Class Initialized
DEBUG - 2025-07-03 09:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:19:17 --> Input Class Initialized
INFO - 2025-07-03 09:19:17 --> Language Class Initialized
INFO - 2025-07-03 09:19:17 --> Loader Class Initialized
INFO - 2025-07-03 09:19:17 --> Helper loaded: url_helper
INFO - 2025-07-03 09:19:17 --> Helper loaded: form_helper
INFO - 2025-07-03 09:19:17 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:19:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:19:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:19:17 --> Controller Class Initialized
INFO - 2025-07-03 09:19:17 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:19:17 --> Model "User_model" initialized
INFO - 2025-07-03 09:19:17 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:19:17 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:19:17 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/start.php
INFO - 2025-07-03 09:19:17 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:19:17 --> Final output sent to browser
DEBUG - 2025-07-03 09:19:17 --> Total execution time: 0.0516
INFO - 2025-07-03 09:19:35 --> Config Class Initialized
INFO - 2025-07-03 09:19:35 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:19:35 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:19:35 --> Utf8 Class Initialized
INFO - 2025-07-03 09:19:35 --> URI Class Initialized
INFO - 2025-07-03 09:19:35 --> Router Class Initialized
INFO - 2025-07-03 09:19:35 --> Output Class Initialized
INFO - 2025-07-03 09:19:35 --> Security Class Initialized
DEBUG - 2025-07-03 09:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:19:35 --> Input Class Initialized
INFO - 2025-07-03 09:19:35 --> Language Class Initialized
INFO - 2025-07-03 09:19:35 --> Loader Class Initialized
INFO - 2025-07-03 09:19:35 --> Helper loaded: url_helper
INFO - 2025-07-03 09:19:35 --> Helper loaded: form_helper
INFO - 2025-07-03 09:19:35 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:19:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:19:35 --> Controller Class Initialized
INFO - 2025-07-03 09:19:35 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:19:35 --> Model "User_model" initialized
INFO - 2025-07-03 09:19:35 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:19:35 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:19:35 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-07-03 09:19:35 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:19:35 --> Final output sent to browser
DEBUG - 2025-07-03 09:19:35 --> Total execution time: 0.0343
INFO - 2025-07-03 09:19:36 --> Config Class Initialized
INFO - 2025-07-03 09:19:36 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:19:36 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:19:36 --> Utf8 Class Initialized
INFO - 2025-07-03 09:19:36 --> URI Class Initialized
INFO - 2025-07-03 09:19:36 --> Router Class Initialized
INFO - 2025-07-03 09:19:36 --> Output Class Initialized
INFO - 2025-07-03 09:19:36 --> Security Class Initialized
DEBUG - 2025-07-03 09:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:19:36 --> Input Class Initialized
INFO - 2025-07-03 09:19:36 --> Language Class Initialized
INFO - 2025-07-03 09:19:36 --> Loader Class Initialized
INFO - 2025-07-03 09:19:36 --> Helper loaded: url_helper
INFO - 2025-07-03 09:19:36 --> Helper loaded: form_helper
INFO - 2025-07-03 09:19:36 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:19:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:19:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:19:36 --> Controller Class Initialized
INFO - 2025-07-03 09:19:36 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:19:36 --> Model "User_model" initialized
INFO - 2025-07-03 09:19:36 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:19:36 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:19:36 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/level.php
INFO - 2025-07-03 09:19:36 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:19:36 --> Final output sent to browser
DEBUG - 2025-07-03 09:19:36 --> Total execution time: 0.0352
INFO - 2025-07-03 09:19:37 --> Config Class Initialized
INFO - 2025-07-03 09:19:37 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:19:37 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:19:37 --> Utf8 Class Initialized
INFO - 2025-07-03 09:19:37 --> URI Class Initialized
INFO - 2025-07-03 09:19:37 --> Router Class Initialized
INFO - 2025-07-03 09:19:37 --> Output Class Initialized
INFO - 2025-07-03 09:19:37 --> Security Class Initialized
DEBUG - 2025-07-03 09:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:19:37 --> Input Class Initialized
INFO - 2025-07-03 09:19:37 --> Language Class Initialized
INFO - 2025-07-03 09:19:37 --> Loader Class Initialized
INFO - 2025-07-03 09:19:37 --> Helper loaded: url_helper
INFO - 2025-07-03 09:19:37 --> Helper loaded: form_helper
INFO - 2025-07-03 09:19:37 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:19:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:19:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:19:37 --> Controller Class Initialized
INFO - 2025-07-03 09:19:37 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:19:37 --> Model "User_model" initialized
INFO - 2025-07-03 09:19:37 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:19:37 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:19:37 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-07-03 09:19:37 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:19:37 --> Final output sent to browser
DEBUG - 2025-07-03 09:19:37 --> Total execution time: 0.0358
INFO - 2025-07-03 09:19:39 --> Config Class Initialized
INFO - 2025-07-03 09:19:39 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:19:39 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:19:39 --> Utf8 Class Initialized
INFO - 2025-07-03 09:19:39 --> URI Class Initialized
INFO - 2025-07-03 09:19:39 --> Router Class Initialized
INFO - 2025-07-03 09:19:39 --> Output Class Initialized
INFO - 2025-07-03 09:19:39 --> Security Class Initialized
DEBUG - 2025-07-03 09:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:19:39 --> Input Class Initialized
INFO - 2025-07-03 09:19:39 --> Language Class Initialized
INFO - 2025-07-03 09:19:39 --> Loader Class Initialized
INFO - 2025-07-03 09:19:39 --> Helper loaded: url_helper
INFO - 2025-07-03 09:19:39 --> Helper loaded: form_helper
INFO - 2025-07-03 09:19:39 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:19:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:19:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:19:39 --> Controller Class Initialized
INFO - 2025-07-03 09:19:39 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:19:39 --> Model "User_model" initialized
INFO - 2025-07-03 09:19:39 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:19:39 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:19:39 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/start.php
INFO - 2025-07-03 09:19:39 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:19:39 --> Final output sent to browser
DEBUG - 2025-07-03 09:19:39 --> Total execution time: 0.0382
INFO - 2025-07-03 09:19:59 --> Config Class Initialized
INFO - 2025-07-03 09:19:59 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:19:59 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:19:59 --> Utf8 Class Initialized
INFO - 2025-07-03 09:19:59 --> URI Class Initialized
INFO - 2025-07-03 09:19:59 --> Router Class Initialized
INFO - 2025-07-03 09:19:59 --> Output Class Initialized
INFO - 2025-07-03 09:19:59 --> Security Class Initialized
DEBUG - 2025-07-03 09:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:19:59 --> Input Class Initialized
INFO - 2025-07-03 09:19:59 --> Language Class Initialized
INFO - 2025-07-03 09:19:59 --> Loader Class Initialized
INFO - 2025-07-03 09:19:59 --> Helper loaded: url_helper
INFO - 2025-07-03 09:19:59 --> Helper loaded: form_helper
INFO - 2025-07-03 09:19:59 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:19:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:19:59 --> Controller Class Initialized
INFO - 2025-07-03 09:19:59 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:19:59 --> Model "User_model" initialized
INFO - 2025-07-03 09:19:59 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:19:59 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:19:59 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-07-03 09:19:59 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:19:59 --> Final output sent to browser
DEBUG - 2025-07-03 09:19:59 --> Total execution time: 0.0375
INFO - 2025-07-03 09:20:01 --> Config Class Initialized
INFO - 2025-07-03 09:20:01 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:20:01 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:20:01 --> Utf8 Class Initialized
INFO - 2025-07-03 09:20:01 --> URI Class Initialized
INFO - 2025-07-03 09:20:01 --> Router Class Initialized
INFO - 2025-07-03 09:20:01 --> Output Class Initialized
INFO - 2025-07-03 09:20:01 --> Security Class Initialized
DEBUG - 2025-07-03 09:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:20:01 --> Input Class Initialized
INFO - 2025-07-03 09:20:01 --> Language Class Initialized
INFO - 2025-07-03 09:20:01 --> Loader Class Initialized
INFO - 2025-07-03 09:20:01 --> Helper loaded: url_helper
INFO - 2025-07-03 09:20:01 --> Helper loaded: form_helper
INFO - 2025-07-03 09:20:01 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:20:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:20:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:20:01 --> Controller Class Initialized
INFO - 2025-07-03 09:20:01 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:20:01 --> Model "User_model" initialized
INFO - 2025-07-03 09:20:01 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:20:01 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:20:01 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/level.php
INFO - 2025-07-03 09:20:01 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:20:01 --> Final output sent to browser
DEBUG - 2025-07-03 09:20:01 --> Total execution time: 0.0403
INFO - 2025-07-03 09:20:02 --> Config Class Initialized
INFO - 2025-07-03 09:20:02 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:20:02 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:20:02 --> Utf8 Class Initialized
INFO - 2025-07-03 09:20:02 --> URI Class Initialized
INFO - 2025-07-03 09:20:02 --> Router Class Initialized
INFO - 2025-07-03 09:20:02 --> Output Class Initialized
INFO - 2025-07-03 09:20:02 --> Security Class Initialized
DEBUG - 2025-07-03 09:20:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:20:02 --> Input Class Initialized
INFO - 2025-07-03 09:20:02 --> Language Class Initialized
INFO - 2025-07-03 09:20:02 --> Loader Class Initialized
INFO - 2025-07-03 09:20:02 --> Helper loaded: url_helper
INFO - 2025-07-03 09:20:02 --> Helper loaded: form_helper
INFO - 2025-07-03 09:20:02 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:20:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:20:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:20:02 --> Controller Class Initialized
INFO - 2025-07-03 09:20:02 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:20:02 --> Model "User_model" initialized
INFO - 2025-07-03 09:20:02 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:20:02 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:20:02 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-07-03 09:20:02 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:20:02 --> Final output sent to browser
DEBUG - 2025-07-03 09:20:02 --> Total execution time: 0.0392
INFO - 2025-07-03 09:22:00 --> Config Class Initialized
INFO - 2025-07-03 09:22:00 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:22:00 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:22:00 --> Utf8 Class Initialized
INFO - 2025-07-03 09:22:00 --> URI Class Initialized
INFO - 2025-07-03 09:22:00 --> Router Class Initialized
INFO - 2025-07-03 09:22:00 --> Output Class Initialized
INFO - 2025-07-03 09:22:00 --> Security Class Initialized
DEBUG - 2025-07-03 09:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:22:00 --> Input Class Initialized
INFO - 2025-07-03 09:22:00 --> Language Class Initialized
INFO - 2025-07-03 09:22:00 --> Loader Class Initialized
INFO - 2025-07-03 09:22:00 --> Helper loaded: url_helper
INFO - 2025-07-03 09:22:00 --> Helper loaded: form_helper
INFO - 2025-07-03 09:22:00 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:22:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:22:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:22:00 --> Controller Class Initialized
INFO - 2025-07-03 09:22:00 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:22:00 --> Model "User_model" initialized
INFO - 2025-07-03 09:22:00 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:22:00 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:22:00 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-07-03 09:22:00 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:22:00 --> Final output sent to browser
DEBUG - 2025-07-03 09:22:00 --> Total execution time: 0.0396
INFO - 2025-07-03 09:22:50 --> Config Class Initialized
INFO - 2025-07-03 09:22:50 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:22:50 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:22:50 --> Utf8 Class Initialized
INFO - 2025-07-03 09:22:50 --> URI Class Initialized
INFO - 2025-07-03 09:22:50 --> Router Class Initialized
INFO - 2025-07-03 09:22:50 --> Output Class Initialized
INFO - 2025-07-03 09:22:50 --> Security Class Initialized
DEBUG - 2025-07-03 09:22:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:22:50 --> Input Class Initialized
INFO - 2025-07-03 09:22:50 --> Language Class Initialized
INFO - 2025-07-03 09:22:50 --> Loader Class Initialized
INFO - 2025-07-03 09:22:50 --> Helper loaded: url_helper
INFO - 2025-07-03 09:22:50 --> Helper loaded: form_helper
INFO - 2025-07-03 09:22:50 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:22:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:22:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:22:50 --> Controller Class Initialized
INFO - 2025-07-03 09:22:50 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:22:50 --> Model "User_model" initialized
INFO - 2025-07-03 09:22:50 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:22:50 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:22:50 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-07-03 09:22:50 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:22:50 --> Final output sent to browser
DEBUG - 2025-07-03 09:22:50 --> Total execution time: 0.0598
INFO - 2025-07-03 09:26:16 --> Config Class Initialized
INFO - 2025-07-03 09:26:16 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:26:16 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:26:16 --> Utf8 Class Initialized
INFO - 2025-07-03 09:26:16 --> URI Class Initialized
INFO - 2025-07-03 09:26:16 --> Router Class Initialized
INFO - 2025-07-03 09:26:16 --> Output Class Initialized
INFO - 2025-07-03 09:26:16 --> Security Class Initialized
DEBUG - 2025-07-03 09:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:26:16 --> Input Class Initialized
INFO - 2025-07-03 09:26:16 --> Language Class Initialized
INFO - 2025-07-03 09:26:16 --> Loader Class Initialized
INFO - 2025-07-03 09:26:16 --> Helper loaded: url_helper
INFO - 2025-07-03 09:26:16 --> Helper loaded: form_helper
INFO - 2025-07-03 09:26:16 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:26:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:26:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:26:16 --> Controller Class Initialized
INFO - 2025-07-03 09:26:16 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:26:16 --> Model "User_model" initialized
INFO - 2025-07-03 09:26:16 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:26:16 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:26:16 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-07-03 09:26:16 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:26:16 --> Final output sent to browser
DEBUG - 2025-07-03 09:26:16 --> Total execution time: 0.0372
INFO - 2025-07-03 09:26:17 --> Config Class Initialized
INFO - 2025-07-03 09:26:17 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:26:17 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:26:17 --> Utf8 Class Initialized
INFO - 2025-07-03 09:26:17 --> URI Class Initialized
INFO - 2025-07-03 09:26:17 --> Router Class Initialized
INFO - 2025-07-03 09:26:17 --> Output Class Initialized
INFO - 2025-07-03 09:26:17 --> Security Class Initialized
DEBUG - 2025-07-03 09:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:26:17 --> Input Class Initialized
INFO - 2025-07-03 09:26:17 --> Language Class Initialized
INFO - 2025-07-03 09:26:17 --> Loader Class Initialized
INFO - 2025-07-03 09:26:17 --> Helper loaded: url_helper
INFO - 2025-07-03 09:26:17 --> Helper loaded: form_helper
INFO - 2025-07-03 09:26:17 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:26:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:26:17 --> Controller Class Initialized
INFO - 2025-07-03 09:26:17 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:26:17 --> Model "User_model" initialized
INFO - 2025-07-03 09:26:17 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:26:17 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:26:17 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/start.php
INFO - 2025-07-03 09:26:17 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:26:17 --> Final output sent to browser
DEBUG - 2025-07-03 09:26:17 --> Total execution time: 0.0361
INFO - 2025-07-03 09:26:26 --> Config Class Initialized
INFO - 2025-07-03 09:26:26 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:26:26 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:26:26 --> Utf8 Class Initialized
INFO - 2025-07-03 09:26:26 --> URI Class Initialized
INFO - 2025-07-03 09:26:26 --> Router Class Initialized
INFO - 2025-07-03 09:26:26 --> Output Class Initialized
INFO - 2025-07-03 09:26:26 --> Security Class Initialized
DEBUG - 2025-07-03 09:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:26:26 --> Input Class Initialized
INFO - 2025-07-03 09:26:26 --> Language Class Initialized
INFO - 2025-07-03 09:26:26 --> Loader Class Initialized
INFO - 2025-07-03 09:26:26 --> Helper loaded: url_helper
INFO - 2025-07-03 09:26:26 --> Helper loaded: form_helper
INFO - 2025-07-03 09:26:26 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:26:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:26:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:26:26 --> Controller Class Initialized
INFO - 2025-07-03 09:26:26 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:26:26 --> Model "User_model" initialized
INFO - 2025-07-03 09:26:26 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:26:26 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:26:26 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-07-03 09:26:26 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:26:26 --> Final output sent to browser
DEBUG - 2025-07-03 09:26:26 --> Total execution time: 0.0613
INFO - 2025-07-03 09:28:22 --> Config Class Initialized
INFO - 2025-07-03 09:28:22 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:28:22 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:28:22 --> Utf8 Class Initialized
INFO - 2025-07-03 09:28:22 --> URI Class Initialized
INFO - 2025-07-03 09:28:22 --> Router Class Initialized
INFO - 2025-07-03 09:28:22 --> Output Class Initialized
INFO - 2025-07-03 09:28:22 --> Security Class Initialized
DEBUG - 2025-07-03 09:28:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:28:22 --> Input Class Initialized
INFO - 2025-07-03 09:28:22 --> Language Class Initialized
INFO - 2025-07-03 09:28:22 --> Loader Class Initialized
INFO - 2025-07-03 09:28:22 --> Helper loaded: url_helper
INFO - 2025-07-03 09:28:22 --> Helper loaded: form_helper
INFO - 2025-07-03 09:28:22 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:28:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:28:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:28:22 --> Controller Class Initialized
INFO - 2025-07-03 09:28:22 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:28:22 --> Model "User_model" initialized
INFO - 2025-07-03 09:28:22 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:28:22 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:28:22 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-07-03 09:28:22 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:28:22 --> Final output sent to browser
DEBUG - 2025-07-03 09:28:22 --> Total execution time: 0.0327
INFO - 2025-07-03 09:28:23 --> Config Class Initialized
INFO - 2025-07-03 09:28:23 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:28:23 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:28:23 --> Utf8 Class Initialized
INFO - 2025-07-03 09:28:23 --> URI Class Initialized
INFO - 2025-07-03 09:28:23 --> Router Class Initialized
INFO - 2025-07-03 09:28:23 --> Output Class Initialized
INFO - 2025-07-03 09:28:23 --> Security Class Initialized
DEBUG - 2025-07-03 09:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:28:23 --> Input Class Initialized
INFO - 2025-07-03 09:28:23 --> Language Class Initialized
INFO - 2025-07-03 09:28:23 --> Loader Class Initialized
INFO - 2025-07-03 09:28:23 --> Helper loaded: url_helper
INFO - 2025-07-03 09:28:23 --> Helper loaded: form_helper
INFO - 2025-07-03 09:28:23 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:28:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:28:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:28:23 --> Controller Class Initialized
INFO - 2025-07-03 09:28:23 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:28:23 --> Model "User_model" initialized
INFO - 2025-07-03 09:28:23 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:28:23 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:28:23 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/start.php
INFO - 2025-07-03 09:28:23 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:28:23 --> Final output sent to browser
DEBUG - 2025-07-03 09:28:23 --> Total execution time: 0.0354
INFO - 2025-07-03 09:29:36 --> Config Class Initialized
INFO - 2025-07-03 09:29:36 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:29:36 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:29:36 --> Utf8 Class Initialized
INFO - 2025-07-03 09:29:36 --> URI Class Initialized
INFO - 2025-07-03 09:29:36 --> Router Class Initialized
INFO - 2025-07-03 09:29:36 --> Output Class Initialized
INFO - 2025-07-03 09:29:36 --> Security Class Initialized
DEBUG - 2025-07-03 09:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:29:36 --> Input Class Initialized
INFO - 2025-07-03 09:29:36 --> Language Class Initialized
INFO - 2025-07-03 09:29:36 --> Loader Class Initialized
INFO - 2025-07-03 09:29:36 --> Helper loaded: url_helper
INFO - 2025-07-03 09:29:36 --> Helper loaded: form_helper
INFO - 2025-07-03 09:29:36 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:29:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:29:36 --> Controller Class Initialized
INFO - 2025-07-03 09:29:36 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:29:36 --> Model "User_model" initialized
INFO - 2025-07-03 09:29:36 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:29:36 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:29:36 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-07-03 09:29:36 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:29:36 --> Final output sent to browser
DEBUG - 2025-07-03 09:29:36 --> Total execution time: 0.0468
INFO - 2025-07-03 09:29:49 --> Config Class Initialized
INFO - 2025-07-03 09:29:49 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:29:49 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:29:49 --> Utf8 Class Initialized
INFO - 2025-07-03 09:29:49 --> URI Class Initialized
INFO - 2025-07-03 09:29:49 --> Router Class Initialized
INFO - 2025-07-03 09:29:49 --> Output Class Initialized
INFO - 2025-07-03 09:29:49 --> Security Class Initialized
DEBUG - 2025-07-03 09:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:29:49 --> Input Class Initialized
INFO - 2025-07-03 09:29:49 --> Language Class Initialized
INFO - 2025-07-03 09:29:49 --> Loader Class Initialized
INFO - 2025-07-03 09:29:49 --> Helper loaded: url_helper
INFO - 2025-07-03 09:29:49 --> Helper loaded: form_helper
INFO - 2025-07-03 09:29:49 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:29:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:29:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:29:49 --> Controller Class Initialized
INFO - 2025-07-03 09:29:49 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:29:49 --> Model "User_model" initialized
INFO - 2025-07-03 09:29:49 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:29:49 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:29:49 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/start.php
INFO - 2025-07-03 09:29:49 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:29:49 --> Final output sent to browser
DEBUG - 2025-07-03 09:29:49 --> Total execution time: 0.0524
INFO - 2025-07-03 09:30:25 --> Config Class Initialized
INFO - 2025-07-03 09:30:25 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:30:25 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:30:25 --> Utf8 Class Initialized
INFO - 2025-07-03 09:30:25 --> URI Class Initialized
INFO - 2025-07-03 09:30:25 --> Router Class Initialized
INFO - 2025-07-03 09:30:25 --> Output Class Initialized
INFO - 2025-07-03 09:30:25 --> Security Class Initialized
DEBUG - 2025-07-03 09:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:30:25 --> Input Class Initialized
INFO - 2025-07-03 09:30:25 --> Language Class Initialized
INFO - 2025-07-03 09:30:25 --> Loader Class Initialized
INFO - 2025-07-03 09:30:25 --> Helper loaded: url_helper
INFO - 2025-07-03 09:30:25 --> Helper loaded: form_helper
INFO - 2025-07-03 09:30:25 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:30:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:30:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:30:25 --> Controller Class Initialized
INFO - 2025-07-03 09:30:25 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:30:25 --> Model "User_model" initialized
INFO - 2025-07-03 09:30:25 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:30:25 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:30:25 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-07-03 09:30:25 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:30:25 --> Final output sent to browser
DEBUG - 2025-07-03 09:30:25 --> Total execution time: 0.0342
INFO - 2025-07-03 09:30:26 --> Config Class Initialized
INFO - 2025-07-03 09:30:26 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:30:26 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:30:26 --> Utf8 Class Initialized
INFO - 2025-07-03 09:30:26 --> URI Class Initialized
INFO - 2025-07-03 09:30:26 --> Router Class Initialized
INFO - 2025-07-03 09:30:26 --> Output Class Initialized
INFO - 2025-07-03 09:30:26 --> Security Class Initialized
DEBUG - 2025-07-03 09:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:30:26 --> Input Class Initialized
INFO - 2025-07-03 09:30:26 --> Language Class Initialized
INFO - 2025-07-03 09:30:26 --> Loader Class Initialized
INFO - 2025-07-03 09:30:26 --> Helper loaded: url_helper
INFO - 2025-07-03 09:30:26 --> Helper loaded: form_helper
INFO - 2025-07-03 09:30:26 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:30:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:30:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:30:26 --> Controller Class Initialized
INFO - 2025-07-03 09:30:26 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:30:26 --> Model "User_model" initialized
INFO - 2025-07-03 09:30:26 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:30:26 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:30:26 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/level.php
INFO - 2025-07-03 09:30:26 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:30:26 --> Final output sent to browser
DEBUG - 2025-07-03 09:30:26 --> Total execution time: 0.0363
INFO - 2025-07-03 09:30:29 --> Config Class Initialized
INFO - 2025-07-03 09:30:29 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:30:29 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:30:29 --> Utf8 Class Initialized
INFO - 2025-07-03 09:30:29 --> URI Class Initialized
INFO - 2025-07-03 09:30:29 --> Router Class Initialized
INFO - 2025-07-03 09:30:29 --> Output Class Initialized
INFO - 2025-07-03 09:30:29 --> Security Class Initialized
DEBUG - 2025-07-03 09:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:30:29 --> Input Class Initialized
INFO - 2025-07-03 09:30:29 --> Language Class Initialized
INFO - 2025-07-03 09:30:29 --> Loader Class Initialized
INFO - 2025-07-03 09:30:29 --> Helper loaded: url_helper
INFO - 2025-07-03 09:30:29 --> Helper loaded: form_helper
INFO - 2025-07-03 09:30:29 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:30:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:30:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:30:29 --> Controller Class Initialized
INFO - 2025-07-03 09:30:29 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:30:29 --> Model "User_model" initialized
INFO - 2025-07-03 09:30:29 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:30:29 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:30:29 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-07-03 09:30:29 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:30:29 --> Final output sent to browser
DEBUG - 2025-07-03 09:30:29 --> Total execution time: 0.0341
INFO - 2025-07-03 09:31:14 --> Config Class Initialized
INFO - 2025-07-03 09:31:14 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:31:14 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:31:14 --> Utf8 Class Initialized
INFO - 2025-07-03 09:31:14 --> URI Class Initialized
INFO - 2025-07-03 09:31:14 --> Router Class Initialized
INFO - 2025-07-03 09:31:14 --> Output Class Initialized
INFO - 2025-07-03 09:31:14 --> Security Class Initialized
DEBUG - 2025-07-03 09:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:31:14 --> Input Class Initialized
INFO - 2025-07-03 09:31:14 --> Language Class Initialized
INFO - 2025-07-03 09:31:14 --> Loader Class Initialized
INFO - 2025-07-03 09:31:14 --> Helper loaded: url_helper
INFO - 2025-07-03 09:31:14 --> Helper loaded: form_helper
INFO - 2025-07-03 09:31:14 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:31:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:31:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:31:14 --> Controller Class Initialized
INFO - 2025-07-03 09:31:14 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:31:14 --> Model "User_model" initialized
INFO - 2025-07-03 09:31:14 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:31:14 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:31:14 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/level.php
INFO - 2025-07-03 09:31:14 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:31:14 --> Final output sent to browser
DEBUG - 2025-07-03 09:31:14 --> Total execution time: 0.0391
INFO - 2025-07-03 09:31:15 --> Config Class Initialized
INFO - 2025-07-03 09:31:15 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:31:15 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:31:15 --> Utf8 Class Initialized
INFO - 2025-07-03 09:31:15 --> URI Class Initialized
INFO - 2025-07-03 09:31:15 --> Router Class Initialized
INFO - 2025-07-03 09:31:15 --> Output Class Initialized
INFO - 2025-07-03 09:31:15 --> Security Class Initialized
DEBUG - 2025-07-03 09:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:31:15 --> Input Class Initialized
INFO - 2025-07-03 09:31:15 --> Language Class Initialized
INFO - 2025-07-03 09:31:15 --> Loader Class Initialized
INFO - 2025-07-03 09:31:15 --> Helper loaded: url_helper
INFO - 2025-07-03 09:31:15 --> Helper loaded: form_helper
INFO - 2025-07-03 09:31:15 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:31:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:31:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:31:15 --> Controller Class Initialized
INFO - 2025-07-03 09:31:15 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:31:15 --> Model "User_model" initialized
INFO - 2025-07-03 09:31:15 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:31:15 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:31:15 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-07-03 09:31:15 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:31:15 --> Final output sent to browser
DEBUG - 2025-07-03 09:31:15 --> Total execution time: 0.0385
INFO - 2025-07-03 09:34:12 --> Config Class Initialized
INFO - 2025-07-03 09:34:12 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:34:12 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:34:12 --> Utf8 Class Initialized
INFO - 2025-07-03 09:34:12 --> URI Class Initialized
INFO - 2025-07-03 09:34:12 --> Router Class Initialized
INFO - 2025-07-03 09:34:12 --> Output Class Initialized
INFO - 2025-07-03 09:34:12 --> Security Class Initialized
DEBUG - 2025-07-03 09:34:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:34:12 --> Input Class Initialized
INFO - 2025-07-03 09:34:12 --> Language Class Initialized
INFO - 2025-07-03 09:34:12 --> Loader Class Initialized
INFO - 2025-07-03 09:34:12 --> Helper loaded: url_helper
INFO - 2025-07-03 09:34:12 --> Helper loaded: form_helper
INFO - 2025-07-03 09:34:12 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:34:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:34:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:34:12 --> Controller Class Initialized
INFO - 2025-07-03 09:34:12 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:34:12 --> Model "User_model" initialized
INFO - 2025-07-03 09:34:12 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:34:12 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:34:12 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/start.php
INFO - 2025-07-03 09:34:12 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:34:12 --> Final output sent to browser
DEBUG - 2025-07-03 09:34:12 --> Total execution time: 0.0388
INFO - 2025-07-03 09:36:31 --> Config Class Initialized
INFO - 2025-07-03 09:36:31 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:36:31 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:36:31 --> Utf8 Class Initialized
INFO - 2025-07-03 09:36:31 --> URI Class Initialized
INFO - 2025-07-03 09:36:31 --> Router Class Initialized
INFO - 2025-07-03 09:36:31 --> Output Class Initialized
INFO - 2025-07-03 09:36:31 --> Security Class Initialized
DEBUG - 2025-07-03 09:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:36:31 --> Input Class Initialized
INFO - 2025-07-03 09:36:31 --> Language Class Initialized
INFO - 2025-07-03 09:36:31 --> Loader Class Initialized
INFO - 2025-07-03 09:36:31 --> Helper loaded: url_helper
INFO - 2025-07-03 09:36:31 --> Helper loaded: form_helper
INFO - 2025-07-03 09:36:31 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:36:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:36:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:36:31 --> Controller Class Initialized
INFO - 2025-07-03 09:36:31 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:36:31 --> Model "User_model" initialized
INFO - 2025-07-03 09:36:31 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:36:31 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:36:31 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-07-03 09:36:31 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:36:31 --> Final output sent to browser
DEBUG - 2025-07-03 09:36:31 --> Total execution time: 0.0409
INFO - 2025-07-03 09:38:06 --> Config Class Initialized
INFO - 2025-07-03 09:38:06 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:38:06 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:38:06 --> Utf8 Class Initialized
INFO - 2025-07-03 09:38:06 --> URI Class Initialized
INFO - 2025-07-03 09:38:06 --> Router Class Initialized
INFO - 2025-07-03 09:38:06 --> Output Class Initialized
INFO - 2025-07-03 09:38:06 --> Security Class Initialized
DEBUG - 2025-07-03 09:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:38:06 --> Input Class Initialized
INFO - 2025-07-03 09:38:06 --> Language Class Initialized
INFO - 2025-07-03 09:38:06 --> Loader Class Initialized
INFO - 2025-07-03 09:38:06 --> Helper loaded: url_helper
INFO - 2025-07-03 09:38:06 --> Helper loaded: form_helper
INFO - 2025-07-03 09:38:06 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:38:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:38:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:38:06 --> Controller Class Initialized
INFO - 2025-07-03 09:38:06 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:38:06 --> Model "User_model" initialized
INFO - 2025-07-03 09:38:06 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:38:06 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:38:06 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-07-03 09:38:06 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:38:06 --> Final output sent to browser
DEBUG - 2025-07-03 09:38:06 --> Total execution time: 0.0571
INFO - 2025-07-03 09:38:15 --> Config Class Initialized
INFO - 2025-07-03 09:38:15 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:38:15 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:38:15 --> Utf8 Class Initialized
INFO - 2025-07-03 09:38:15 --> URI Class Initialized
INFO - 2025-07-03 09:38:15 --> Router Class Initialized
INFO - 2025-07-03 09:38:15 --> Output Class Initialized
INFO - 2025-07-03 09:38:15 --> Security Class Initialized
DEBUG - 2025-07-03 09:38:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:38:15 --> Input Class Initialized
INFO - 2025-07-03 09:38:15 --> Language Class Initialized
INFO - 2025-07-03 09:38:15 --> Loader Class Initialized
INFO - 2025-07-03 09:38:15 --> Helper loaded: url_helper
INFO - 2025-07-03 09:38:15 --> Helper loaded: form_helper
INFO - 2025-07-03 09:38:15 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:38:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:38:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:38:15 --> Controller Class Initialized
INFO - 2025-07-03 09:38:15 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:38:15 --> Model "User_model" initialized
INFO - 2025-07-03 09:38:15 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:38:15 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:38:15 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-07-03 09:38:15 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:38:15 --> Final output sent to browser
DEBUG - 2025-07-03 09:38:15 --> Total execution time: 0.0472
INFO - 2025-07-03 09:38:56 --> Config Class Initialized
INFO - 2025-07-03 09:38:56 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:38:56 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:38:56 --> Utf8 Class Initialized
INFO - 2025-07-03 09:38:56 --> URI Class Initialized
INFO - 2025-07-03 09:38:56 --> Router Class Initialized
INFO - 2025-07-03 09:38:56 --> Output Class Initialized
INFO - 2025-07-03 09:38:56 --> Security Class Initialized
DEBUG - 2025-07-03 09:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:38:56 --> Input Class Initialized
INFO - 2025-07-03 09:38:56 --> Language Class Initialized
INFO - 2025-07-03 09:38:56 --> Loader Class Initialized
INFO - 2025-07-03 09:38:56 --> Helper loaded: url_helper
INFO - 2025-07-03 09:38:56 --> Helper loaded: form_helper
INFO - 2025-07-03 09:38:56 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:38:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:38:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:38:56 --> Controller Class Initialized
INFO - 2025-07-03 09:38:56 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:38:56 --> Model "User_model" initialized
INFO - 2025-07-03 09:38:56 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:38:56 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:38:56 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-07-03 09:38:56 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:38:56 --> Final output sent to browser
DEBUG - 2025-07-03 09:38:56 --> Total execution time: 0.0391
INFO - 2025-07-03 09:38:57 --> Config Class Initialized
INFO - 2025-07-03 09:38:57 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:38:57 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:38:57 --> Utf8 Class Initialized
INFO - 2025-07-03 09:38:57 --> URI Class Initialized
INFO - 2025-07-03 09:38:57 --> Router Class Initialized
INFO - 2025-07-03 09:38:57 --> Output Class Initialized
INFO - 2025-07-03 09:38:57 --> Security Class Initialized
DEBUG - 2025-07-03 09:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:38:57 --> Input Class Initialized
INFO - 2025-07-03 09:38:57 --> Language Class Initialized
INFO - 2025-07-03 09:38:57 --> Loader Class Initialized
INFO - 2025-07-03 09:38:57 --> Helper loaded: url_helper
INFO - 2025-07-03 09:38:57 --> Helper loaded: form_helper
INFO - 2025-07-03 09:38:57 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:38:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:38:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:38:57 --> Controller Class Initialized
INFO - 2025-07-03 09:38:57 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:38:57 --> Model "User_model" initialized
INFO - 2025-07-03 09:38:57 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:38:57 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:38:57 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/level.php
INFO - 2025-07-03 09:38:57 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:38:57 --> Final output sent to browser
DEBUG - 2025-07-03 09:38:57 --> Total execution time: 0.0359
INFO - 2025-07-03 09:38:59 --> Config Class Initialized
INFO - 2025-07-03 09:38:59 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:38:59 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:38:59 --> Utf8 Class Initialized
INFO - 2025-07-03 09:38:59 --> URI Class Initialized
INFO - 2025-07-03 09:38:59 --> Router Class Initialized
INFO - 2025-07-03 09:38:59 --> Output Class Initialized
INFO - 2025-07-03 09:38:59 --> Security Class Initialized
DEBUG - 2025-07-03 09:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:38:59 --> Input Class Initialized
INFO - 2025-07-03 09:38:59 --> Language Class Initialized
INFO - 2025-07-03 09:38:59 --> Loader Class Initialized
INFO - 2025-07-03 09:38:59 --> Helper loaded: url_helper
INFO - 2025-07-03 09:38:59 --> Helper loaded: form_helper
INFO - 2025-07-03 09:38:59 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:38:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:38:59 --> Controller Class Initialized
INFO - 2025-07-03 09:38:59 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:38:59 --> Model "User_model" initialized
INFO - 2025-07-03 09:38:59 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:38:59 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:38:59 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-07-03 09:38:59 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:38:59 --> Final output sent to browser
DEBUG - 2025-07-03 09:38:59 --> Total execution time: 0.0479
INFO - 2025-07-03 09:39:03 --> Config Class Initialized
INFO - 2025-07-03 09:39:03 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:39:03 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:39:03 --> Utf8 Class Initialized
INFO - 2025-07-03 09:39:03 --> URI Class Initialized
INFO - 2025-07-03 09:39:03 --> Router Class Initialized
INFO - 2025-07-03 09:39:03 --> Output Class Initialized
INFO - 2025-07-03 09:39:03 --> Security Class Initialized
DEBUG - 2025-07-03 09:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:39:03 --> Input Class Initialized
INFO - 2025-07-03 09:39:03 --> Language Class Initialized
INFO - 2025-07-03 09:39:03 --> Loader Class Initialized
INFO - 2025-07-03 09:39:03 --> Helper loaded: url_helper
INFO - 2025-07-03 09:39:03 --> Helper loaded: form_helper
INFO - 2025-07-03 09:39:03 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:39:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:39:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:39:03 --> Controller Class Initialized
INFO - 2025-07-03 09:39:03 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:39:03 --> Model "User_model" initialized
INFO - 2025-07-03 09:39:03 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:39:03 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:39:03 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-07-03 09:39:03 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:39:03 --> Final output sent to browser
DEBUG - 2025-07-03 09:39:03 --> Total execution time: 0.0352
INFO - 2025-07-03 09:39:04 --> Config Class Initialized
INFO - 2025-07-03 09:39:04 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:39:04 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:39:04 --> Utf8 Class Initialized
INFO - 2025-07-03 09:39:04 --> URI Class Initialized
INFO - 2025-07-03 09:39:04 --> Router Class Initialized
INFO - 2025-07-03 09:39:04 --> Output Class Initialized
INFO - 2025-07-03 09:39:04 --> Security Class Initialized
DEBUG - 2025-07-03 09:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:39:04 --> Input Class Initialized
INFO - 2025-07-03 09:39:04 --> Language Class Initialized
INFO - 2025-07-03 09:39:04 --> Loader Class Initialized
INFO - 2025-07-03 09:39:04 --> Helper loaded: url_helper
INFO - 2025-07-03 09:39:04 --> Helper loaded: form_helper
INFO - 2025-07-03 09:39:04 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:39:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:39:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:39:04 --> Controller Class Initialized
INFO - 2025-07-03 09:39:04 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:39:04 --> Model "User_model" initialized
INFO - 2025-07-03 09:39:04 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:39:04 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:39:04 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/level.php
INFO - 2025-07-03 09:39:04 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:39:04 --> Final output sent to browser
DEBUG - 2025-07-03 09:39:04 --> Total execution time: 0.0378
INFO - 2025-07-03 09:39:05 --> Config Class Initialized
INFO - 2025-07-03 09:39:05 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:39:05 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:39:05 --> Utf8 Class Initialized
INFO - 2025-07-03 09:39:05 --> URI Class Initialized
INFO - 2025-07-03 09:39:05 --> Router Class Initialized
INFO - 2025-07-03 09:39:05 --> Output Class Initialized
INFO - 2025-07-03 09:39:05 --> Security Class Initialized
DEBUG - 2025-07-03 09:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:39:05 --> Input Class Initialized
INFO - 2025-07-03 09:39:05 --> Language Class Initialized
INFO - 2025-07-03 09:39:05 --> Loader Class Initialized
INFO - 2025-07-03 09:39:05 --> Helper loaded: url_helper
INFO - 2025-07-03 09:39:05 --> Helper loaded: form_helper
INFO - 2025-07-03 09:39:05 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:39:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:39:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:39:05 --> Controller Class Initialized
INFO - 2025-07-03 09:39:05 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:39:05 --> Model "User_model" initialized
INFO - 2025-07-03 09:39:05 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:39:05 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:39:05 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-07-03 09:39:05 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:39:05 --> Final output sent to browser
DEBUG - 2025-07-03 09:39:05 --> Total execution time: 0.0712
INFO - 2025-07-03 09:39:54 --> Config Class Initialized
INFO - 2025-07-03 09:39:54 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:39:54 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:39:54 --> Utf8 Class Initialized
INFO - 2025-07-03 09:39:54 --> URI Class Initialized
INFO - 2025-07-03 09:39:54 --> Router Class Initialized
INFO - 2025-07-03 09:39:54 --> Output Class Initialized
INFO - 2025-07-03 09:39:54 --> Security Class Initialized
DEBUG - 2025-07-03 09:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:39:54 --> Input Class Initialized
INFO - 2025-07-03 09:39:54 --> Language Class Initialized
INFO - 2025-07-03 09:39:54 --> Loader Class Initialized
INFO - 2025-07-03 09:39:54 --> Helper loaded: url_helper
INFO - 2025-07-03 09:39:55 --> Helper loaded: form_helper
INFO - 2025-07-03 09:39:55 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:39:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:39:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:39:55 --> Controller Class Initialized
INFO - 2025-07-03 09:39:55 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:39:55 --> Model "User_model" initialized
INFO - 2025-07-03 09:39:55 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:39:55 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:39:55 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/level.php
INFO - 2025-07-03 09:39:55 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:39:55 --> Final output sent to browser
DEBUG - 2025-07-03 09:39:55 --> Total execution time: 0.0416
INFO - 2025-07-03 09:39:56 --> Config Class Initialized
INFO - 2025-07-03 09:39:56 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:39:56 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:39:56 --> Utf8 Class Initialized
INFO - 2025-07-03 09:39:56 --> URI Class Initialized
INFO - 2025-07-03 09:39:56 --> Router Class Initialized
INFO - 2025-07-03 09:39:56 --> Output Class Initialized
INFO - 2025-07-03 09:39:56 --> Security Class Initialized
DEBUG - 2025-07-03 09:39:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:39:56 --> Input Class Initialized
INFO - 2025-07-03 09:39:56 --> Language Class Initialized
INFO - 2025-07-03 09:39:56 --> Loader Class Initialized
INFO - 2025-07-03 09:39:56 --> Helper loaded: url_helper
INFO - 2025-07-03 09:39:56 --> Helper loaded: form_helper
INFO - 2025-07-03 09:39:56 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:39:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:39:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:39:56 --> Controller Class Initialized
INFO - 2025-07-03 09:39:56 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:39:56 --> Model "User_model" initialized
INFO - 2025-07-03 09:39:56 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:39:56 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:39:56 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-07-03 09:39:56 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:39:56 --> Final output sent to browser
DEBUG - 2025-07-03 09:39:56 --> Total execution time: 0.0398
INFO - 2025-07-03 09:39:57 --> Config Class Initialized
INFO - 2025-07-03 09:39:57 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:39:57 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:39:57 --> Utf8 Class Initialized
INFO - 2025-07-03 09:39:57 --> URI Class Initialized
INFO - 2025-07-03 09:39:57 --> Router Class Initialized
INFO - 2025-07-03 09:39:57 --> Output Class Initialized
INFO - 2025-07-03 09:39:57 --> Security Class Initialized
DEBUG - 2025-07-03 09:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:39:57 --> Input Class Initialized
INFO - 2025-07-03 09:39:57 --> Language Class Initialized
INFO - 2025-07-03 09:39:57 --> Loader Class Initialized
INFO - 2025-07-03 09:39:57 --> Helper loaded: url_helper
INFO - 2025-07-03 09:39:57 --> Helper loaded: form_helper
INFO - 2025-07-03 09:39:57 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:39:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:39:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:39:57 --> Controller Class Initialized
INFO - 2025-07-03 09:39:57 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:39:57 --> Model "User_model" initialized
INFO - 2025-07-03 09:39:57 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:39:57 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:39:57 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/level.php
INFO - 2025-07-03 09:39:57 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:39:57 --> Final output sent to browser
DEBUG - 2025-07-03 09:39:57 --> Total execution time: 0.0389
INFO - 2025-07-03 09:39:59 --> Config Class Initialized
INFO - 2025-07-03 09:39:59 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:39:59 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:39:59 --> Utf8 Class Initialized
INFO - 2025-07-03 09:39:59 --> URI Class Initialized
INFO - 2025-07-03 09:39:59 --> Router Class Initialized
INFO - 2025-07-03 09:39:59 --> Output Class Initialized
INFO - 2025-07-03 09:39:59 --> Security Class Initialized
DEBUG - 2025-07-03 09:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:39:59 --> Input Class Initialized
INFO - 2025-07-03 09:39:59 --> Language Class Initialized
INFO - 2025-07-03 09:39:59 --> Loader Class Initialized
INFO - 2025-07-03 09:39:59 --> Helper loaded: url_helper
INFO - 2025-07-03 09:39:59 --> Helper loaded: form_helper
INFO - 2025-07-03 09:39:59 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:39:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:39:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:39:59 --> Controller Class Initialized
INFO - 2025-07-03 09:39:59 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:39:59 --> Model "User_model" initialized
INFO - 2025-07-03 09:39:59 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:39:59 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:39:59 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-07-03 09:39:59 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:39:59 --> Final output sent to browser
DEBUG - 2025-07-03 09:39:59 --> Total execution time: 0.0376
INFO - 2025-07-03 09:39:59 --> Config Class Initialized
INFO - 2025-07-03 09:39:59 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:39:59 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:39:59 --> Utf8 Class Initialized
INFO - 2025-07-03 09:39:59 --> URI Class Initialized
INFO - 2025-07-03 09:39:59 --> Router Class Initialized
INFO - 2025-07-03 09:39:59 --> Output Class Initialized
INFO - 2025-07-03 09:39:59 --> Security Class Initialized
DEBUG - 2025-07-03 09:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:40:00 --> Input Class Initialized
INFO - 2025-07-03 09:40:00 --> Language Class Initialized
INFO - 2025-07-03 09:40:00 --> Loader Class Initialized
INFO - 2025-07-03 09:40:00 --> Helper loaded: url_helper
INFO - 2025-07-03 09:40:00 --> Helper loaded: form_helper
INFO - 2025-07-03 09:40:00 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:40:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:40:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:40:00 --> Controller Class Initialized
INFO - 2025-07-03 09:40:00 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:40:00 --> Model "User_model" initialized
INFO - 2025-07-03 09:40:00 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:40:00 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:40:00 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/level.php
INFO - 2025-07-03 09:40:00 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:40:00 --> Final output sent to browser
DEBUG - 2025-07-03 09:40:00 --> Total execution time: 0.0465
INFO - 2025-07-03 09:40:00 --> Config Class Initialized
INFO - 2025-07-03 09:40:00 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:40:00 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:40:00 --> Utf8 Class Initialized
INFO - 2025-07-03 09:40:00 --> URI Class Initialized
INFO - 2025-07-03 09:40:00 --> Router Class Initialized
INFO - 2025-07-03 09:40:00 --> Output Class Initialized
INFO - 2025-07-03 09:40:00 --> Security Class Initialized
DEBUG - 2025-07-03 09:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:40:00 --> Input Class Initialized
INFO - 2025-07-03 09:40:00 --> Language Class Initialized
INFO - 2025-07-03 09:40:00 --> Loader Class Initialized
INFO - 2025-07-03 09:40:00 --> Helper loaded: url_helper
INFO - 2025-07-03 09:40:00 --> Helper loaded: form_helper
INFO - 2025-07-03 09:40:00 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:40:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:40:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:40:00 --> Controller Class Initialized
INFO - 2025-07-03 09:40:00 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:40:00 --> Model "User_model" initialized
INFO - 2025-07-03 09:40:00 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:40:00 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:40:01 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-07-03 09:40:01 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:40:01 --> Final output sent to browser
DEBUG - 2025-07-03 09:40:01 --> Total execution time: 0.0393
INFO - 2025-07-03 09:40:08 --> Config Class Initialized
INFO - 2025-07-03 09:40:08 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:40:08 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:40:08 --> Utf8 Class Initialized
INFO - 2025-07-03 09:40:08 --> URI Class Initialized
INFO - 2025-07-03 09:40:08 --> Router Class Initialized
INFO - 2025-07-03 09:40:08 --> Output Class Initialized
INFO - 2025-07-03 09:40:08 --> Security Class Initialized
DEBUG - 2025-07-03 09:40:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:40:08 --> Input Class Initialized
INFO - 2025-07-03 09:40:08 --> Language Class Initialized
INFO - 2025-07-03 09:40:08 --> Loader Class Initialized
INFO - 2025-07-03 09:40:08 --> Helper loaded: url_helper
INFO - 2025-07-03 09:40:08 --> Helper loaded: form_helper
INFO - 2025-07-03 09:40:08 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:40:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:40:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:40:08 --> Controller Class Initialized
INFO - 2025-07-03 09:40:08 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:40:08 --> Model "User_model" initialized
INFO - 2025-07-03 09:40:08 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:40:08 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:40:08 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-07-03 09:40:08 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:40:08 --> Final output sent to browser
DEBUG - 2025-07-03 09:40:08 --> Total execution time: 0.0507
INFO - 2025-07-03 09:40:10 --> Config Class Initialized
INFO - 2025-07-03 09:40:10 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:40:10 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:40:10 --> Utf8 Class Initialized
INFO - 2025-07-03 09:40:10 --> URI Class Initialized
INFO - 2025-07-03 09:40:10 --> Router Class Initialized
INFO - 2025-07-03 09:40:10 --> Output Class Initialized
INFO - 2025-07-03 09:40:10 --> Security Class Initialized
DEBUG - 2025-07-03 09:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:40:10 --> Input Class Initialized
INFO - 2025-07-03 09:40:10 --> Language Class Initialized
INFO - 2025-07-03 09:40:10 --> Loader Class Initialized
INFO - 2025-07-03 09:40:10 --> Helper loaded: url_helper
INFO - 2025-07-03 09:40:10 --> Helper loaded: form_helper
INFO - 2025-07-03 09:40:10 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:40:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:40:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:40:10 --> Controller Class Initialized
INFO - 2025-07-03 09:40:10 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:40:10 --> Model "User_model" initialized
INFO - 2025-07-03 09:40:10 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:40:10 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:40:10 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-07-03 09:40:10 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:40:10 --> Final output sent to browser
DEBUG - 2025-07-03 09:40:10 --> Total execution time: 0.0380
INFO - 2025-07-03 09:40:11 --> Config Class Initialized
INFO - 2025-07-03 09:40:11 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:40:11 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:40:11 --> Utf8 Class Initialized
INFO - 2025-07-03 09:40:11 --> URI Class Initialized
INFO - 2025-07-03 09:40:11 --> Router Class Initialized
INFO - 2025-07-03 09:40:11 --> Output Class Initialized
INFO - 2025-07-03 09:40:11 --> Security Class Initialized
DEBUG - 2025-07-03 09:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:40:11 --> Input Class Initialized
INFO - 2025-07-03 09:40:11 --> Language Class Initialized
INFO - 2025-07-03 09:40:11 --> Loader Class Initialized
INFO - 2025-07-03 09:40:11 --> Helper loaded: url_helper
INFO - 2025-07-03 09:40:11 --> Helper loaded: form_helper
INFO - 2025-07-03 09:40:11 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:40:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:40:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:40:11 --> Controller Class Initialized
INFO - 2025-07-03 09:40:11 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:40:11 --> Model "User_model" initialized
INFO - 2025-07-03 09:40:11 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:40:11 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:40:11 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/level.php
INFO - 2025-07-03 09:40:11 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:40:11 --> Final output sent to browser
DEBUG - 2025-07-03 09:40:11 --> Total execution time: 0.0367
INFO - 2025-07-03 09:40:12 --> Config Class Initialized
INFO - 2025-07-03 09:40:12 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:40:12 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:40:12 --> Utf8 Class Initialized
INFO - 2025-07-03 09:40:12 --> URI Class Initialized
INFO - 2025-07-03 09:40:12 --> Router Class Initialized
INFO - 2025-07-03 09:40:12 --> Output Class Initialized
INFO - 2025-07-03 09:40:12 --> Security Class Initialized
DEBUG - 2025-07-03 09:40:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:40:12 --> Input Class Initialized
INFO - 2025-07-03 09:40:12 --> Language Class Initialized
INFO - 2025-07-03 09:40:12 --> Loader Class Initialized
INFO - 2025-07-03 09:40:12 --> Helper loaded: url_helper
INFO - 2025-07-03 09:40:12 --> Helper loaded: form_helper
INFO - 2025-07-03 09:40:12 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:40:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:40:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:40:12 --> Controller Class Initialized
INFO - 2025-07-03 09:40:12 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:40:12 --> Model "User_model" initialized
INFO - 2025-07-03 09:40:12 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:40:12 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:40:12 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-07-03 09:40:12 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:40:12 --> Final output sent to browser
DEBUG - 2025-07-03 09:40:12 --> Total execution time: 0.0721
INFO - 2025-07-03 09:40:19 --> Config Class Initialized
INFO - 2025-07-03 09:40:19 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:40:19 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:40:19 --> Utf8 Class Initialized
INFO - 2025-07-03 09:40:19 --> URI Class Initialized
INFO - 2025-07-03 09:40:19 --> Router Class Initialized
INFO - 2025-07-03 09:40:19 --> Output Class Initialized
INFO - 2025-07-03 09:40:19 --> Security Class Initialized
DEBUG - 2025-07-03 09:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:40:19 --> Input Class Initialized
INFO - 2025-07-03 09:40:19 --> Language Class Initialized
INFO - 2025-07-03 09:40:19 --> Loader Class Initialized
INFO - 2025-07-03 09:40:19 --> Helper loaded: url_helper
INFO - 2025-07-03 09:40:19 --> Helper loaded: form_helper
INFO - 2025-07-03 09:40:19 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:40:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:40:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:40:19 --> Controller Class Initialized
INFO - 2025-07-03 09:40:19 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:40:19 --> Model "User_model" initialized
INFO - 2025-07-03 09:40:19 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:40:19 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:40:19 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-07-03 09:40:19 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:40:19 --> Final output sent to browser
DEBUG - 2025-07-03 09:40:19 --> Total execution time: 0.0532
INFO - 2025-07-03 09:40:30 --> Config Class Initialized
INFO - 2025-07-03 09:40:30 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:40:30 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:40:30 --> Utf8 Class Initialized
INFO - 2025-07-03 09:40:30 --> URI Class Initialized
INFO - 2025-07-03 09:40:30 --> Router Class Initialized
INFO - 2025-07-03 09:40:30 --> Output Class Initialized
INFO - 2025-07-03 09:40:30 --> Security Class Initialized
DEBUG - 2025-07-03 09:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:40:30 --> Input Class Initialized
INFO - 2025-07-03 09:40:30 --> Language Class Initialized
INFO - 2025-07-03 09:40:30 --> Loader Class Initialized
INFO - 2025-07-03 09:40:30 --> Helper loaded: url_helper
INFO - 2025-07-03 09:40:30 --> Helper loaded: form_helper
INFO - 2025-07-03 09:40:30 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:40:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:40:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:40:30 --> Controller Class Initialized
INFO - 2025-07-03 09:40:30 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:40:30 --> Model "User_model" initialized
INFO - 2025-07-03 09:40:30 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:40:30 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:40:30 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-07-03 09:40:30 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:40:30 --> Final output sent to browser
DEBUG - 2025-07-03 09:40:30 --> Total execution time: 0.0388
INFO - 2025-07-03 09:40:31 --> Config Class Initialized
INFO - 2025-07-03 09:40:31 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:40:31 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:40:31 --> Utf8 Class Initialized
INFO - 2025-07-03 09:40:31 --> URI Class Initialized
INFO - 2025-07-03 09:40:31 --> Router Class Initialized
INFO - 2025-07-03 09:40:31 --> Output Class Initialized
INFO - 2025-07-03 09:40:31 --> Security Class Initialized
DEBUG - 2025-07-03 09:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:40:31 --> Input Class Initialized
INFO - 2025-07-03 09:40:31 --> Language Class Initialized
INFO - 2025-07-03 09:40:31 --> Loader Class Initialized
INFO - 2025-07-03 09:40:31 --> Helper loaded: url_helper
INFO - 2025-07-03 09:40:31 --> Helper loaded: form_helper
INFO - 2025-07-03 09:40:31 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:40:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:40:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:40:31 --> Controller Class Initialized
INFO - 2025-07-03 09:40:31 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:40:31 --> Model "User_model" initialized
INFO - 2025-07-03 09:40:31 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:40:31 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:40:31 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/level.php
INFO - 2025-07-03 09:40:31 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:40:31 --> Final output sent to browser
DEBUG - 2025-07-03 09:40:31 --> Total execution time: 0.0391
INFO - 2025-07-03 09:40:34 --> Config Class Initialized
INFO - 2025-07-03 09:40:34 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:40:34 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:40:34 --> Utf8 Class Initialized
INFO - 2025-07-03 09:40:34 --> URI Class Initialized
INFO - 2025-07-03 09:40:34 --> Router Class Initialized
INFO - 2025-07-03 09:40:34 --> Output Class Initialized
INFO - 2025-07-03 09:40:34 --> Security Class Initialized
DEBUG - 2025-07-03 09:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:40:34 --> Input Class Initialized
INFO - 2025-07-03 09:40:34 --> Language Class Initialized
INFO - 2025-07-03 09:40:34 --> Loader Class Initialized
INFO - 2025-07-03 09:40:34 --> Helper loaded: url_helper
INFO - 2025-07-03 09:40:34 --> Helper loaded: form_helper
INFO - 2025-07-03 09:40:34 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:40:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:40:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:40:34 --> Controller Class Initialized
INFO - 2025-07-03 09:40:34 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:40:34 --> Model "User_model" initialized
INFO - 2025-07-03 09:40:34 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:40:34 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:40:34 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/level.php
INFO - 2025-07-03 09:40:34 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:40:34 --> Final output sent to browser
DEBUG - 2025-07-03 09:40:34 --> Total execution time: 0.0439
INFO - 2025-07-03 09:40:35 --> Config Class Initialized
INFO - 2025-07-03 09:40:35 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:40:35 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:40:35 --> Utf8 Class Initialized
INFO - 2025-07-03 09:40:35 --> URI Class Initialized
INFO - 2025-07-03 09:40:35 --> Router Class Initialized
INFO - 2025-07-03 09:40:35 --> Output Class Initialized
INFO - 2025-07-03 09:40:35 --> Security Class Initialized
DEBUG - 2025-07-03 09:40:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:40:35 --> Input Class Initialized
INFO - 2025-07-03 09:40:35 --> Language Class Initialized
INFO - 2025-07-03 09:40:35 --> Loader Class Initialized
INFO - 2025-07-03 09:40:35 --> Helper loaded: url_helper
INFO - 2025-07-03 09:40:35 --> Helper loaded: form_helper
INFO - 2025-07-03 09:40:35 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:40:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:40:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:40:35 --> Controller Class Initialized
INFO - 2025-07-03 09:40:35 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:40:35 --> Model "User_model" initialized
INFO - 2025-07-03 09:40:35 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:40:35 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:40:35 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-07-03 09:40:35 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:40:35 --> Final output sent to browser
DEBUG - 2025-07-03 09:40:35 --> Total execution time: 0.0393
INFO - 2025-07-03 09:45:25 --> Config Class Initialized
INFO - 2025-07-03 09:45:25 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:45:25 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:45:25 --> Utf8 Class Initialized
INFO - 2025-07-03 09:45:26 --> URI Class Initialized
INFO - 2025-07-03 09:45:26 --> Router Class Initialized
INFO - 2025-07-03 09:45:26 --> Output Class Initialized
INFO - 2025-07-03 09:45:26 --> Security Class Initialized
DEBUG - 2025-07-03 09:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:45:26 --> Input Class Initialized
INFO - 2025-07-03 09:45:26 --> Language Class Initialized
INFO - 2025-07-03 09:45:26 --> Loader Class Initialized
INFO - 2025-07-03 09:45:26 --> Helper loaded: url_helper
INFO - 2025-07-03 09:45:26 --> Helper loaded: form_helper
INFO - 2025-07-03 09:45:26 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:45:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:45:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:45:26 --> Controller Class Initialized
INFO - 2025-07-03 09:45:26 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:45:26 --> Model "User_model" initialized
INFO - 2025-07-03 09:45:26 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:45:26 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:45:26 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-07-03 09:45:26 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:45:26 --> Final output sent to browser
DEBUG - 2025-07-03 09:45:26 --> Total execution time: 0.0354
INFO - 2025-07-03 09:45:32 --> Config Class Initialized
INFO - 2025-07-03 09:45:32 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:45:32 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:45:32 --> Utf8 Class Initialized
INFO - 2025-07-03 09:45:32 --> URI Class Initialized
INFO - 2025-07-03 09:45:32 --> Router Class Initialized
INFO - 2025-07-03 09:45:32 --> Output Class Initialized
INFO - 2025-07-03 09:45:32 --> Security Class Initialized
DEBUG - 2025-07-03 09:45:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:45:32 --> Input Class Initialized
INFO - 2025-07-03 09:45:32 --> Language Class Initialized
INFO - 2025-07-03 09:45:32 --> Loader Class Initialized
INFO - 2025-07-03 09:45:32 --> Helper loaded: url_helper
INFO - 2025-07-03 09:45:32 --> Helper loaded: form_helper
INFO - 2025-07-03 09:45:32 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:45:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:45:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:45:33 --> Controller Class Initialized
INFO - 2025-07-03 09:45:33 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:45:33 --> Model "User_model" initialized
INFO - 2025-07-03 09:45:33 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:45:33 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:45:33 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-07-03 09:45:33 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:45:33 --> Final output sent to browser
DEBUG - 2025-07-03 09:45:33 --> Total execution time: 0.0380
INFO - 2025-07-03 09:45:35 --> Config Class Initialized
INFO - 2025-07-03 09:45:35 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:45:35 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:45:35 --> Utf8 Class Initialized
INFO - 2025-07-03 09:45:35 --> URI Class Initialized
INFO - 2025-07-03 09:45:35 --> Router Class Initialized
INFO - 2025-07-03 09:45:35 --> Output Class Initialized
INFO - 2025-07-03 09:45:35 --> Security Class Initialized
DEBUG - 2025-07-03 09:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:45:35 --> Input Class Initialized
INFO - 2025-07-03 09:45:35 --> Language Class Initialized
INFO - 2025-07-03 09:45:35 --> Loader Class Initialized
INFO - 2025-07-03 09:45:35 --> Helper loaded: url_helper
INFO - 2025-07-03 09:45:35 --> Helper loaded: form_helper
INFO - 2025-07-03 09:45:35 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:45:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:45:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:45:35 --> Controller Class Initialized
INFO - 2025-07-03 09:45:35 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:45:35 --> Model "User_model" initialized
INFO - 2025-07-03 09:45:35 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:45:35 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:45:35 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/level.php
INFO - 2025-07-03 09:45:35 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:45:35 --> Final output sent to browser
DEBUG - 2025-07-03 09:45:35 --> Total execution time: 0.0396
INFO - 2025-07-03 09:45:37 --> Config Class Initialized
INFO - 2025-07-03 09:45:37 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:45:37 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:45:37 --> Utf8 Class Initialized
INFO - 2025-07-03 09:45:37 --> URI Class Initialized
INFO - 2025-07-03 09:45:37 --> Router Class Initialized
INFO - 2025-07-03 09:45:37 --> Output Class Initialized
INFO - 2025-07-03 09:45:37 --> Security Class Initialized
DEBUG - 2025-07-03 09:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:45:37 --> Input Class Initialized
INFO - 2025-07-03 09:45:37 --> Language Class Initialized
INFO - 2025-07-03 09:45:37 --> Loader Class Initialized
INFO - 2025-07-03 09:45:37 --> Helper loaded: url_helper
INFO - 2025-07-03 09:45:37 --> Helper loaded: form_helper
INFO - 2025-07-03 09:45:37 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:45:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:45:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:45:37 --> Controller Class Initialized
INFO - 2025-07-03 09:45:37 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:45:37 --> Model "User_model" initialized
INFO - 2025-07-03 09:45:37 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:45:37 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:45:37 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/level.php
INFO - 2025-07-03 09:45:37 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:45:37 --> Final output sent to browser
DEBUG - 2025-07-03 09:45:37 --> Total execution time: 0.0401
INFO - 2025-07-03 09:45:38 --> Config Class Initialized
INFO - 2025-07-03 09:45:38 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:45:38 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:45:38 --> Utf8 Class Initialized
INFO - 2025-07-03 09:45:38 --> URI Class Initialized
INFO - 2025-07-03 09:45:38 --> Router Class Initialized
INFO - 2025-07-03 09:45:38 --> Output Class Initialized
INFO - 2025-07-03 09:45:38 --> Security Class Initialized
DEBUG - 2025-07-03 09:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:45:38 --> Input Class Initialized
INFO - 2025-07-03 09:45:38 --> Language Class Initialized
INFO - 2025-07-03 09:45:38 --> Loader Class Initialized
INFO - 2025-07-03 09:45:38 --> Helper loaded: url_helper
INFO - 2025-07-03 09:45:38 --> Helper loaded: form_helper
INFO - 2025-07-03 09:45:38 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:45:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:45:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:45:38 --> Controller Class Initialized
INFO - 2025-07-03 09:45:38 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:45:38 --> Model "User_model" initialized
INFO - 2025-07-03 09:45:38 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:45:38 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:45:38 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-07-03 09:45:38 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:45:38 --> Final output sent to browser
DEBUG - 2025-07-03 09:45:38 --> Total execution time: 0.0366
INFO - 2025-07-03 09:45:40 --> Config Class Initialized
INFO - 2025-07-03 09:45:40 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:45:40 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:45:40 --> Utf8 Class Initialized
INFO - 2025-07-03 09:45:40 --> URI Class Initialized
INFO - 2025-07-03 09:45:40 --> Router Class Initialized
INFO - 2025-07-03 09:45:40 --> Output Class Initialized
INFO - 2025-07-03 09:45:40 --> Security Class Initialized
DEBUG - 2025-07-03 09:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:45:40 --> Input Class Initialized
INFO - 2025-07-03 09:45:40 --> Language Class Initialized
INFO - 2025-07-03 09:45:40 --> Loader Class Initialized
INFO - 2025-07-03 09:45:40 --> Helper loaded: url_helper
INFO - 2025-07-03 09:45:40 --> Helper loaded: form_helper
INFO - 2025-07-03 09:45:40 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:45:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:45:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:45:40 --> Controller Class Initialized
INFO - 2025-07-03 09:45:40 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:45:40 --> Model "User_model" initialized
INFO - 2025-07-03 09:45:40 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:45:40 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:45:40 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-07-03 09:45:40 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:45:40 --> Final output sent to browser
DEBUG - 2025-07-03 09:45:40 --> Total execution time: 0.0464
INFO - 2025-07-03 09:45:43 --> Config Class Initialized
INFO - 2025-07-03 09:45:43 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:45:43 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:45:43 --> Utf8 Class Initialized
INFO - 2025-07-03 09:45:43 --> URI Class Initialized
INFO - 2025-07-03 09:45:43 --> Router Class Initialized
INFO - 2025-07-03 09:45:43 --> Output Class Initialized
INFO - 2025-07-03 09:45:43 --> Security Class Initialized
DEBUG - 2025-07-03 09:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:45:43 --> Input Class Initialized
INFO - 2025-07-03 09:45:43 --> Language Class Initialized
INFO - 2025-07-03 09:45:43 --> Loader Class Initialized
INFO - 2025-07-03 09:45:43 --> Helper loaded: url_helper
INFO - 2025-07-03 09:45:43 --> Helper loaded: form_helper
INFO - 2025-07-03 09:45:43 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:45:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:45:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:45:43 --> Controller Class Initialized
INFO - 2025-07-03 09:45:43 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:45:43 --> Model "User_model" initialized
INFO - 2025-07-03 09:45:43 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:45:43 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:45:43 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-07-03 09:45:43 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:45:43 --> Final output sent to browser
DEBUG - 2025-07-03 09:45:43 --> Total execution time: 0.0382
INFO - 2025-07-03 09:45:48 --> Config Class Initialized
INFO - 2025-07-03 09:45:48 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:45:48 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:45:48 --> Utf8 Class Initialized
INFO - 2025-07-03 09:45:48 --> URI Class Initialized
INFO - 2025-07-03 09:45:48 --> Router Class Initialized
INFO - 2025-07-03 09:45:48 --> Output Class Initialized
INFO - 2025-07-03 09:45:48 --> Security Class Initialized
DEBUG - 2025-07-03 09:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:45:48 --> Input Class Initialized
INFO - 2025-07-03 09:45:48 --> Language Class Initialized
INFO - 2025-07-03 09:45:48 --> Loader Class Initialized
INFO - 2025-07-03 09:45:48 --> Helper loaded: url_helper
INFO - 2025-07-03 09:45:48 --> Helper loaded: form_helper
INFO - 2025-07-03 09:45:48 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:45:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:45:48 --> Controller Class Initialized
INFO - 2025-07-03 09:45:48 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:45:48 --> Model "User_model" initialized
INFO - 2025-07-03 09:45:48 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:45:48 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:45:48 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/level.php
INFO - 2025-07-03 09:45:48 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:45:48 --> Final output sent to browser
DEBUG - 2025-07-03 09:45:48 --> Total execution time: 0.0388
INFO - 2025-07-03 09:45:49 --> Config Class Initialized
INFO - 2025-07-03 09:45:49 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:45:49 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:45:49 --> Utf8 Class Initialized
INFO - 2025-07-03 09:45:49 --> URI Class Initialized
INFO - 2025-07-03 09:45:49 --> Router Class Initialized
INFO - 2025-07-03 09:45:49 --> Output Class Initialized
INFO - 2025-07-03 09:45:49 --> Security Class Initialized
DEBUG - 2025-07-03 09:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:45:49 --> Input Class Initialized
INFO - 2025-07-03 09:45:49 --> Language Class Initialized
INFO - 2025-07-03 09:45:49 --> Loader Class Initialized
INFO - 2025-07-03 09:45:49 --> Helper loaded: url_helper
INFO - 2025-07-03 09:45:49 --> Helper loaded: form_helper
INFO - 2025-07-03 09:45:49 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:45:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:45:49 --> Controller Class Initialized
INFO - 2025-07-03 09:45:49 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:45:49 --> Model "User_model" initialized
INFO - 2025-07-03 09:45:49 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:45:49 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:45:49 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-07-03 09:45:49 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:45:49 --> Final output sent to browser
DEBUG - 2025-07-03 09:45:49 --> Total execution time: 0.0371
INFO - 2025-07-03 09:46:20 --> Config Class Initialized
INFO - 2025-07-03 09:46:20 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:46:20 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:46:20 --> Utf8 Class Initialized
INFO - 2025-07-03 09:46:20 --> URI Class Initialized
INFO - 2025-07-03 09:46:20 --> Router Class Initialized
INFO - 2025-07-03 09:46:20 --> Output Class Initialized
INFO - 2025-07-03 09:46:20 --> Security Class Initialized
DEBUG - 2025-07-03 09:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:46:20 --> Input Class Initialized
INFO - 2025-07-03 09:46:20 --> Language Class Initialized
INFO - 2025-07-03 09:46:20 --> Loader Class Initialized
INFO - 2025-07-03 09:46:20 --> Helper loaded: url_helper
INFO - 2025-07-03 09:46:20 --> Helper loaded: form_helper
INFO - 2025-07-03 09:46:20 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:46:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:46:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:46:20 --> Controller Class Initialized
INFO - 2025-07-03 09:46:20 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:46:20 --> Model "User_model" initialized
INFO - 2025-07-03 09:46:20 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:46:20 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:46:20 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-07-03 09:46:20 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:46:20 --> Final output sent to browser
DEBUG - 2025-07-03 09:46:20 --> Total execution time: 0.0375
INFO - 2025-07-03 09:46:30 --> Config Class Initialized
INFO - 2025-07-03 09:46:30 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:46:30 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:46:30 --> Utf8 Class Initialized
INFO - 2025-07-03 09:46:30 --> URI Class Initialized
INFO - 2025-07-03 09:46:30 --> Router Class Initialized
INFO - 2025-07-03 09:46:30 --> Output Class Initialized
INFO - 2025-07-03 09:46:30 --> Security Class Initialized
DEBUG - 2025-07-03 09:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:46:30 --> Input Class Initialized
INFO - 2025-07-03 09:46:30 --> Language Class Initialized
INFO - 2025-07-03 09:46:30 --> Loader Class Initialized
INFO - 2025-07-03 09:46:30 --> Helper loaded: url_helper
INFO - 2025-07-03 09:46:30 --> Helper loaded: form_helper
INFO - 2025-07-03 09:46:30 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:46:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:46:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:46:30 --> Controller Class Initialized
INFO - 2025-07-03 09:46:30 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:46:30 --> Model "User_model" initialized
INFO - 2025-07-03 09:46:30 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:46:30 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:46:30 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-07-03 09:46:30 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:46:30 --> Final output sent to browser
DEBUG - 2025-07-03 09:46:30 --> Total execution time: 0.0380
INFO - 2025-07-03 09:46:33 --> Config Class Initialized
INFO - 2025-07-03 09:46:33 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:46:33 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:46:33 --> Utf8 Class Initialized
INFO - 2025-07-03 09:46:33 --> URI Class Initialized
INFO - 2025-07-03 09:46:33 --> Router Class Initialized
INFO - 2025-07-03 09:46:33 --> Output Class Initialized
INFO - 2025-07-03 09:46:33 --> Security Class Initialized
DEBUG - 2025-07-03 09:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:46:33 --> Input Class Initialized
INFO - 2025-07-03 09:46:33 --> Language Class Initialized
INFO - 2025-07-03 09:46:33 --> Loader Class Initialized
INFO - 2025-07-03 09:46:33 --> Helper loaded: url_helper
INFO - 2025-07-03 09:46:33 --> Helper loaded: form_helper
INFO - 2025-07-03 09:46:33 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:46:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:46:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:46:33 --> Controller Class Initialized
INFO - 2025-07-03 09:46:33 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:46:33 --> Model "User_model" initialized
INFO - 2025-07-03 09:46:33 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:46:33 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:46:33 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/level.php
INFO - 2025-07-03 09:46:33 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:46:33 --> Final output sent to browser
DEBUG - 2025-07-03 09:46:33 --> Total execution time: 0.0400
INFO - 2025-07-03 09:46:34 --> Config Class Initialized
INFO - 2025-07-03 09:46:34 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:46:34 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:46:34 --> Utf8 Class Initialized
INFO - 2025-07-03 09:46:34 --> URI Class Initialized
INFO - 2025-07-03 09:46:34 --> Router Class Initialized
INFO - 2025-07-03 09:46:34 --> Output Class Initialized
INFO - 2025-07-03 09:46:34 --> Security Class Initialized
DEBUG - 2025-07-03 09:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:46:34 --> Input Class Initialized
INFO - 2025-07-03 09:46:34 --> Language Class Initialized
INFO - 2025-07-03 09:46:34 --> Loader Class Initialized
INFO - 2025-07-03 09:46:34 --> Helper loaded: url_helper
INFO - 2025-07-03 09:46:34 --> Helper loaded: form_helper
INFO - 2025-07-03 09:46:34 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:46:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:46:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:46:34 --> Controller Class Initialized
INFO - 2025-07-03 09:46:34 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:46:34 --> Model "User_model" initialized
INFO - 2025-07-03 09:46:34 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:46:34 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:46:34 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-07-03 09:46:34 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:46:34 --> Final output sent to browser
DEBUG - 2025-07-03 09:46:34 --> Total execution time: 0.0406
INFO - 2025-07-03 09:46:42 --> Config Class Initialized
INFO - 2025-07-03 09:46:42 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:46:42 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:46:42 --> Utf8 Class Initialized
INFO - 2025-07-03 09:46:42 --> URI Class Initialized
INFO - 2025-07-03 09:46:42 --> Router Class Initialized
INFO - 2025-07-03 09:46:42 --> Output Class Initialized
INFO - 2025-07-03 09:46:42 --> Security Class Initialized
DEBUG - 2025-07-03 09:46:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:46:42 --> Input Class Initialized
INFO - 2025-07-03 09:46:42 --> Language Class Initialized
INFO - 2025-07-03 09:46:42 --> Loader Class Initialized
INFO - 2025-07-03 09:46:42 --> Helper loaded: url_helper
INFO - 2025-07-03 09:46:42 --> Helper loaded: form_helper
INFO - 2025-07-03 09:46:42 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:46:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:46:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:46:42 --> Controller Class Initialized
INFO - 2025-07-03 09:46:42 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:46:42 --> Model "User_model" initialized
INFO - 2025-07-03 09:46:42 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:46:42 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:46:42 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-07-03 09:46:42 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:46:42 --> Final output sent to browser
DEBUG - 2025-07-03 09:46:42 --> Total execution time: 0.0390
INFO - 2025-07-03 09:47:35 --> Config Class Initialized
INFO - 2025-07-03 09:47:35 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:47:35 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:47:35 --> Utf8 Class Initialized
INFO - 2025-07-03 09:47:35 --> URI Class Initialized
INFO - 2025-07-03 09:47:35 --> Router Class Initialized
INFO - 2025-07-03 09:47:35 --> Output Class Initialized
INFO - 2025-07-03 09:47:35 --> Security Class Initialized
DEBUG - 2025-07-03 09:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:47:35 --> Input Class Initialized
INFO - 2025-07-03 09:47:35 --> Language Class Initialized
INFO - 2025-07-03 09:47:35 --> Loader Class Initialized
INFO - 2025-07-03 09:47:35 --> Helper loaded: url_helper
INFO - 2025-07-03 09:47:35 --> Helper loaded: form_helper
INFO - 2025-07-03 09:47:35 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:47:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:47:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:47:35 --> Controller Class Initialized
INFO - 2025-07-03 09:47:35 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:47:35 --> Model "User_model" initialized
INFO - 2025-07-03 09:47:35 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:47:35 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:47:35 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-07-03 09:47:35 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:47:35 --> Final output sent to browser
DEBUG - 2025-07-03 09:47:35 --> Total execution time: 0.0399
INFO - 2025-07-03 09:47:58 --> Config Class Initialized
INFO - 2025-07-03 09:47:58 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:47:58 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:47:58 --> Utf8 Class Initialized
INFO - 2025-07-03 09:47:58 --> URI Class Initialized
INFO - 2025-07-03 09:47:58 --> Router Class Initialized
INFO - 2025-07-03 09:47:58 --> Output Class Initialized
INFO - 2025-07-03 09:47:58 --> Security Class Initialized
DEBUG - 2025-07-03 09:47:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:47:58 --> Input Class Initialized
INFO - 2025-07-03 09:47:58 --> Language Class Initialized
INFO - 2025-07-03 09:47:58 --> Loader Class Initialized
INFO - 2025-07-03 09:47:58 --> Helper loaded: url_helper
INFO - 2025-07-03 09:47:58 --> Helper loaded: form_helper
INFO - 2025-07-03 09:47:58 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:47:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:47:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:47:58 --> Controller Class Initialized
INFO - 2025-07-03 09:47:58 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:47:58 --> Model "User_model" initialized
INFO - 2025-07-03 09:47:58 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:47:58 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:47:58 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-07-03 09:47:58 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:47:58 --> Final output sent to browser
DEBUG - 2025-07-03 09:47:58 --> Total execution time: 0.0369
INFO - 2025-07-03 09:48:01 --> Config Class Initialized
INFO - 2025-07-03 09:48:01 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:48:01 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:48:01 --> Utf8 Class Initialized
INFO - 2025-07-03 09:48:01 --> URI Class Initialized
INFO - 2025-07-03 09:48:01 --> Router Class Initialized
INFO - 2025-07-03 09:48:01 --> Output Class Initialized
INFO - 2025-07-03 09:48:01 --> Security Class Initialized
DEBUG - 2025-07-03 09:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:48:01 --> Input Class Initialized
INFO - 2025-07-03 09:48:01 --> Language Class Initialized
INFO - 2025-07-03 09:48:01 --> Loader Class Initialized
INFO - 2025-07-03 09:48:01 --> Helper loaded: url_helper
INFO - 2025-07-03 09:48:01 --> Helper loaded: form_helper
INFO - 2025-07-03 09:48:01 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:48:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:48:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:48:01 --> Controller Class Initialized
INFO - 2025-07-03 09:48:01 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:48:01 --> Model "User_model" initialized
INFO - 2025-07-03 09:48:01 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:48:01 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:48:01 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-07-03 09:48:01 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:48:01 --> Final output sent to browser
DEBUG - 2025-07-03 09:48:01 --> Total execution time: 0.0387
INFO - 2025-07-03 09:48:48 --> Config Class Initialized
INFO - 2025-07-03 09:48:48 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:48:48 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:48:48 --> Utf8 Class Initialized
INFO - 2025-07-03 09:48:48 --> URI Class Initialized
INFO - 2025-07-03 09:48:48 --> Router Class Initialized
INFO - 2025-07-03 09:48:48 --> Output Class Initialized
INFO - 2025-07-03 09:48:48 --> Security Class Initialized
DEBUG - 2025-07-03 09:48:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:48:48 --> Input Class Initialized
INFO - 2025-07-03 09:48:48 --> Language Class Initialized
INFO - 2025-07-03 09:48:48 --> Loader Class Initialized
INFO - 2025-07-03 09:48:48 --> Helper loaded: url_helper
INFO - 2025-07-03 09:48:48 --> Helper loaded: form_helper
INFO - 2025-07-03 09:48:48 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:48:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:48:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:48:48 --> Controller Class Initialized
INFO - 2025-07-03 09:48:48 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:48:48 --> Model "User_model" initialized
INFO - 2025-07-03 09:48:48 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:48:48 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:48:48 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-07-03 09:48:48 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:48:48 --> Final output sent to browser
DEBUG - 2025-07-03 09:48:48 --> Total execution time: 0.0361
INFO - 2025-07-03 09:49:05 --> Config Class Initialized
INFO - 2025-07-03 09:49:05 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:49:05 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:49:05 --> Utf8 Class Initialized
INFO - 2025-07-03 09:49:05 --> URI Class Initialized
INFO - 2025-07-03 09:49:05 --> Router Class Initialized
INFO - 2025-07-03 09:49:05 --> Output Class Initialized
INFO - 2025-07-03 09:49:05 --> Security Class Initialized
DEBUG - 2025-07-03 09:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:49:05 --> Input Class Initialized
INFO - 2025-07-03 09:49:05 --> Language Class Initialized
INFO - 2025-07-03 09:49:05 --> Loader Class Initialized
INFO - 2025-07-03 09:49:05 --> Helper loaded: url_helper
INFO - 2025-07-03 09:49:05 --> Helper loaded: form_helper
INFO - 2025-07-03 09:49:05 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:49:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:49:05 --> Controller Class Initialized
INFO - 2025-07-03 09:49:05 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:49:05 --> Model "User_model" initialized
INFO - 2025-07-03 09:49:05 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:49:05 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:49:05 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-07-03 09:49:05 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:49:05 --> Final output sent to browser
DEBUG - 2025-07-03 09:49:05 --> Total execution time: 0.0423
INFO - 2025-07-03 09:49:07 --> Config Class Initialized
INFO - 2025-07-03 09:49:07 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:49:07 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:49:07 --> Utf8 Class Initialized
INFO - 2025-07-03 09:49:07 --> URI Class Initialized
INFO - 2025-07-03 09:49:07 --> Router Class Initialized
INFO - 2025-07-03 09:49:07 --> Output Class Initialized
INFO - 2025-07-03 09:49:07 --> Security Class Initialized
DEBUG - 2025-07-03 09:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:49:07 --> Input Class Initialized
INFO - 2025-07-03 09:49:07 --> Language Class Initialized
INFO - 2025-07-03 09:49:07 --> Loader Class Initialized
INFO - 2025-07-03 09:49:07 --> Helper loaded: url_helper
INFO - 2025-07-03 09:49:07 --> Helper loaded: form_helper
INFO - 2025-07-03 09:49:07 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:49:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:49:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:49:07 --> Controller Class Initialized
INFO - 2025-07-03 09:49:07 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:49:07 --> Model "User_model" initialized
INFO - 2025-07-03 09:49:07 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:49:07 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:49:07 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/level.php
INFO - 2025-07-03 09:49:07 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:49:07 --> Final output sent to browser
DEBUG - 2025-07-03 09:49:07 --> Total execution time: 0.0350
INFO - 2025-07-03 09:49:11 --> Config Class Initialized
INFO - 2025-07-03 09:49:11 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:49:11 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:49:11 --> Utf8 Class Initialized
INFO - 2025-07-03 09:49:11 --> URI Class Initialized
INFO - 2025-07-03 09:49:11 --> Router Class Initialized
INFO - 2025-07-03 09:49:11 --> Output Class Initialized
INFO - 2025-07-03 09:49:11 --> Security Class Initialized
DEBUG - 2025-07-03 09:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:49:11 --> Input Class Initialized
INFO - 2025-07-03 09:49:11 --> Language Class Initialized
INFO - 2025-07-03 09:49:11 --> Loader Class Initialized
INFO - 2025-07-03 09:49:11 --> Helper loaded: url_helper
INFO - 2025-07-03 09:49:11 --> Helper loaded: form_helper
INFO - 2025-07-03 09:49:11 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:49:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:49:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:49:11 --> Controller Class Initialized
INFO - 2025-07-03 09:49:11 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:49:11 --> Model "User_model" initialized
INFO - 2025-07-03 09:49:11 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:49:11 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:49:11 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/level.php
INFO - 2025-07-03 09:49:11 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:49:11 --> Final output sent to browser
DEBUG - 2025-07-03 09:49:11 --> Total execution time: 0.0345
INFO - 2025-07-03 09:49:12 --> Config Class Initialized
INFO - 2025-07-03 09:49:12 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:49:12 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:49:12 --> Utf8 Class Initialized
INFO - 2025-07-03 09:49:12 --> URI Class Initialized
INFO - 2025-07-03 09:49:12 --> Router Class Initialized
INFO - 2025-07-03 09:49:12 --> Output Class Initialized
INFO - 2025-07-03 09:49:12 --> Security Class Initialized
DEBUG - 2025-07-03 09:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:49:12 --> Input Class Initialized
INFO - 2025-07-03 09:49:12 --> Language Class Initialized
INFO - 2025-07-03 09:49:12 --> Loader Class Initialized
INFO - 2025-07-03 09:49:12 --> Helper loaded: url_helper
INFO - 2025-07-03 09:49:12 --> Helper loaded: form_helper
INFO - 2025-07-03 09:49:12 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:49:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:49:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:49:12 --> Controller Class Initialized
INFO - 2025-07-03 09:49:12 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:49:12 --> Model "User_model" initialized
INFO - 2025-07-03 09:49:12 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:49:12 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:49:12 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-07-03 09:49:12 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:49:12 --> Final output sent to browser
DEBUG - 2025-07-03 09:49:12 --> Total execution time: 0.0362
INFO - 2025-07-03 09:49:25 --> Config Class Initialized
INFO - 2025-07-03 09:49:25 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:49:25 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:49:25 --> Utf8 Class Initialized
INFO - 2025-07-03 09:49:25 --> URI Class Initialized
INFO - 2025-07-03 09:49:25 --> Router Class Initialized
INFO - 2025-07-03 09:49:25 --> Output Class Initialized
INFO - 2025-07-03 09:49:25 --> Security Class Initialized
DEBUG - 2025-07-03 09:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:49:25 --> Input Class Initialized
INFO - 2025-07-03 09:49:25 --> Language Class Initialized
INFO - 2025-07-03 09:49:25 --> Loader Class Initialized
INFO - 2025-07-03 09:49:25 --> Helper loaded: url_helper
INFO - 2025-07-03 09:49:25 --> Helper loaded: form_helper
INFO - 2025-07-03 09:49:25 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:49:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:49:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:49:25 --> Controller Class Initialized
INFO - 2025-07-03 09:49:25 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:49:25 --> Model "User_model" initialized
INFO - 2025-07-03 09:49:25 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:49:25 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:49:25 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-07-03 09:49:25 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:49:25 --> Final output sent to browser
DEBUG - 2025-07-03 09:49:25 --> Total execution time: 0.0380
INFO - 2025-07-03 09:49:36 --> Config Class Initialized
INFO - 2025-07-03 09:49:36 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:49:36 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:49:36 --> Utf8 Class Initialized
INFO - 2025-07-03 09:49:36 --> URI Class Initialized
INFO - 2025-07-03 09:49:36 --> Router Class Initialized
INFO - 2025-07-03 09:49:36 --> Output Class Initialized
INFO - 2025-07-03 09:49:36 --> Security Class Initialized
DEBUG - 2025-07-03 09:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:49:36 --> Input Class Initialized
INFO - 2025-07-03 09:49:36 --> Language Class Initialized
INFO - 2025-07-03 09:49:36 --> Loader Class Initialized
INFO - 2025-07-03 09:49:36 --> Helper loaded: url_helper
INFO - 2025-07-03 09:49:36 --> Helper loaded: form_helper
INFO - 2025-07-03 09:49:36 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:49:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:49:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:49:36 --> Controller Class Initialized
INFO - 2025-07-03 09:49:36 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:49:36 --> Model "User_model" initialized
INFO - 2025-07-03 09:49:36 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:49:36 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:49:36 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-07-03 09:49:36 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:49:36 --> Final output sent to browser
DEBUG - 2025-07-03 09:49:36 --> Total execution time: 0.0416
INFO - 2025-07-03 09:49:38 --> Config Class Initialized
INFO - 2025-07-03 09:49:38 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:49:38 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:49:38 --> Utf8 Class Initialized
INFO - 2025-07-03 09:49:38 --> URI Class Initialized
INFO - 2025-07-03 09:49:38 --> Router Class Initialized
INFO - 2025-07-03 09:49:38 --> Output Class Initialized
INFO - 2025-07-03 09:49:38 --> Security Class Initialized
DEBUG - 2025-07-03 09:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:49:38 --> Input Class Initialized
INFO - 2025-07-03 09:49:38 --> Language Class Initialized
INFO - 2025-07-03 09:49:38 --> Loader Class Initialized
INFO - 2025-07-03 09:49:38 --> Helper loaded: url_helper
INFO - 2025-07-03 09:49:38 --> Helper loaded: form_helper
INFO - 2025-07-03 09:49:38 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:49:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:49:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:49:38 --> Controller Class Initialized
INFO - 2025-07-03 09:49:38 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:49:38 --> Model "User_model" initialized
INFO - 2025-07-03 09:49:38 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:49:38 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:49:38 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-07-03 09:49:38 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:49:38 --> Final output sent to browser
DEBUG - 2025-07-03 09:49:38 --> Total execution time: 0.0406
INFO - 2025-07-03 09:49:43 --> Config Class Initialized
INFO - 2025-07-03 09:49:43 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:49:43 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:49:43 --> Utf8 Class Initialized
INFO - 2025-07-03 09:49:43 --> URI Class Initialized
INFO - 2025-07-03 09:49:43 --> Router Class Initialized
INFO - 2025-07-03 09:49:43 --> Output Class Initialized
INFO - 2025-07-03 09:49:43 --> Security Class Initialized
DEBUG - 2025-07-03 09:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:49:43 --> Input Class Initialized
INFO - 2025-07-03 09:49:43 --> Language Class Initialized
INFO - 2025-07-03 09:49:43 --> Loader Class Initialized
INFO - 2025-07-03 09:49:43 --> Helper loaded: url_helper
INFO - 2025-07-03 09:49:43 --> Helper loaded: form_helper
INFO - 2025-07-03 09:49:43 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:49:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:49:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:49:43 --> Controller Class Initialized
INFO - 2025-07-03 09:49:43 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:49:43 --> Model "User_model" initialized
INFO - 2025-07-03 09:49:43 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:49:43 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:49:43 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/level.php
INFO - 2025-07-03 09:49:43 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:49:43 --> Final output sent to browser
DEBUG - 2025-07-03 09:49:43 --> Total execution time: 0.0356
INFO - 2025-07-03 09:49:44 --> Config Class Initialized
INFO - 2025-07-03 09:49:44 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:49:44 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:49:44 --> Utf8 Class Initialized
INFO - 2025-07-03 09:49:44 --> URI Class Initialized
INFO - 2025-07-03 09:49:44 --> Router Class Initialized
INFO - 2025-07-03 09:49:44 --> Output Class Initialized
INFO - 2025-07-03 09:49:44 --> Security Class Initialized
DEBUG - 2025-07-03 09:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:49:44 --> Input Class Initialized
INFO - 2025-07-03 09:49:44 --> Language Class Initialized
INFO - 2025-07-03 09:49:44 --> Loader Class Initialized
INFO - 2025-07-03 09:49:44 --> Helper loaded: url_helper
INFO - 2025-07-03 09:49:44 --> Helper loaded: form_helper
INFO - 2025-07-03 09:49:44 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:49:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:49:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:49:44 --> Controller Class Initialized
INFO - 2025-07-03 09:49:44 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:49:44 --> Model "User_model" initialized
INFO - 2025-07-03 09:49:44 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:49:44 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:49:44 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-07-03 09:49:44 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:49:44 --> Final output sent to browser
DEBUG - 2025-07-03 09:49:44 --> Total execution time: 0.0365
INFO - 2025-07-03 09:49:53 --> Config Class Initialized
INFO - 2025-07-03 09:49:53 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:49:53 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:49:53 --> Utf8 Class Initialized
INFO - 2025-07-03 09:49:53 --> URI Class Initialized
INFO - 2025-07-03 09:49:53 --> Router Class Initialized
INFO - 2025-07-03 09:49:53 --> Output Class Initialized
INFO - 2025-07-03 09:49:53 --> Security Class Initialized
DEBUG - 2025-07-03 09:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:49:53 --> Input Class Initialized
INFO - 2025-07-03 09:49:53 --> Language Class Initialized
INFO - 2025-07-03 09:49:53 --> Loader Class Initialized
INFO - 2025-07-03 09:49:53 --> Helper loaded: url_helper
INFO - 2025-07-03 09:49:53 --> Helper loaded: form_helper
INFO - 2025-07-03 09:49:53 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:49:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:49:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:49:53 --> Controller Class Initialized
INFO - 2025-07-03 09:49:53 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:49:53 --> Model "User_model" initialized
INFO - 2025-07-03 09:49:53 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:49:53 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:49:53 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/level.php
INFO - 2025-07-03 09:49:53 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:49:53 --> Final output sent to browser
DEBUG - 2025-07-03 09:49:53 --> Total execution time: 0.0422
INFO - 2025-07-03 09:49:54 --> Config Class Initialized
INFO - 2025-07-03 09:49:54 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:49:54 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:49:54 --> Utf8 Class Initialized
INFO - 2025-07-03 09:49:54 --> URI Class Initialized
INFO - 2025-07-03 09:49:54 --> Router Class Initialized
INFO - 2025-07-03 09:49:54 --> Output Class Initialized
INFO - 2025-07-03 09:49:54 --> Security Class Initialized
DEBUG - 2025-07-03 09:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:49:54 --> Input Class Initialized
INFO - 2025-07-03 09:49:54 --> Language Class Initialized
INFO - 2025-07-03 09:49:54 --> Loader Class Initialized
INFO - 2025-07-03 09:49:54 --> Helper loaded: url_helper
INFO - 2025-07-03 09:49:54 --> Helper loaded: form_helper
INFO - 2025-07-03 09:49:54 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:49:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:49:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:49:54 --> Controller Class Initialized
INFO - 2025-07-03 09:49:54 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:49:54 --> Model "User_model" initialized
INFO - 2025-07-03 09:49:54 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:49:54 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:49:54 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-07-03 09:49:54 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:49:54 --> Final output sent to browser
DEBUG - 2025-07-03 09:49:54 --> Total execution time: 0.0424
INFO - 2025-07-03 09:50:00 --> Config Class Initialized
INFO - 2025-07-03 09:50:00 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:50:00 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:50:00 --> Utf8 Class Initialized
INFO - 2025-07-03 09:50:00 --> URI Class Initialized
INFO - 2025-07-03 09:50:00 --> Router Class Initialized
INFO - 2025-07-03 09:50:00 --> Output Class Initialized
INFO - 2025-07-03 09:50:00 --> Security Class Initialized
DEBUG - 2025-07-03 09:50:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:50:00 --> Input Class Initialized
INFO - 2025-07-03 09:50:00 --> Language Class Initialized
INFO - 2025-07-03 09:50:00 --> Loader Class Initialized
INFO - 2025-07-03 09:50:00 --> Helper loaded: url_helper
INFO - 2025-07-03 09:50:00 --> Helper loaded: form_helper
INFO - 2025-07-03 09:50:00 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:50:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:50:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:50:00 --> Controller Class Initialized
INFO - 2025-07-03 09:50:00 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:50:00 --> Model "User_model" initialized
INFO - 2025-07-03 09:50:00 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:50:00 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:50:00 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-07-03 09:50:00 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:50:00 --> Final output sent to browser
DEBUG - 2025-07-03 09:50:00 --> Total execution time: 0.0377
INFO - 2025-07-03 09:50:31 --> Config Class Initialized
INFO - 2025-07-03 09:50:31 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:50:31 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:50:31 --> Utf8 Class Initialized
INFO - 2025-07-03 09:50:31 --> URI Class Initialized
INFO - 2025-07-03 09:50:31 --> Router Class Initialized
INFO - 2025-07-03 09:50:31 --> Output Class Initialized
INFO - 2025-07-03 09:50:31 --> Security Class Initialized
DEBUG - 2025-07-03 09:50:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:50:31 --> Input Class Initialized
INFO - 2025-07-03 09:50:31 --> Language Class Initialized
INFO - 2025-07-03 09:50:31 --> Loader Class Initialized
INFO - 2025-07-03 09:50:31 --> Helper loaded: url_helper
INFO - 2025-07-03 09:50:31 --> Helper loaded: form_helper
INFO - 2025-07-03 09:50:31 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:50:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:50:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:50:31 --> Controller Class Initialized
INFO - 2025-07-03 09:50:31 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:50:31 --> Model "User_model" initialized
INFO - 2025-07-03 09:50:31 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:50:31 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:50:31 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-07-03 09:50:31 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:50:31 --> Final output sent to browser
DEBUG - 2025-07-03 09:50:31 --> Total execution time: 0.0368
INFO - 2025-07-03 09:50:32 --> Config Class Initialized
INFO - 2025-07-03 09:50:32 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:50:32 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:50:32 --> Utf8 Class Initialized
INFO - 2025-07-03 09:50:32 --> URI Class Initialized
INFO - 2025-07-03 09:50:32 --> Router Class Initialized
INFO - 2025-07-03 09:50:32 --> Output Class Initialized
INFO - 2025-07-03 09:50:32 --> Security Class Initialized
DEBUG - 2025-07-03 09:50:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:50:32 --> Input Class Initialized
INFO - 2025-07-03 09:50:32 --> Language Class Initialized
INFO - 2025-07-03 09:50:32 --> Loader Class Initialized
INFO - 2025-07-03 09:50:32 --> Helper loaded: url_helper
INFO - 2025-07-03 09:50:32 --> Helper loaded: form_helper
INFO - 2025-07-03 09:50:32 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:50:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:50:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:50:32 --> Controller Class Initialized
INFO - 2025-07-03 09:50:32 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:50:32 --> Model "User_model" initialized
INFO - 2025-07-03 09:50:32 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:50:32 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:50:32 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/level.php
INFO - 2025-07-03 09:50:32 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:50:32 --> Final output sent to browser
DEBUG - 2025-07-03 09:50:32 --> Total execution time: 0.0366
INFO - 2025-07-03 09:50:34 --> Config Class Initialized
INFO - 2025-07-03 09:50:34 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:50:34 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:50:34 --> Utf8 Class Initialized
INFO - 2025-07-03 09:50:34 --> URI Class Initialized
INFO - 2025-07-03 09:50:34 --> Router Class Initialized
INFO - 2025-07-03 09:50:34 --> Output Class Initialized
INFO - 2025-07-03 09:50:34 --> Security Class Initialized
DEBUG - 2025-07-03 09:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:50:34 --> Input Class Initialized
INFO - 2025-07-03 09:50:34 --> Language Class Initialized
INFO - 2025-07-03 09:50:34 --> Loader Class Initialized
INFO - 2025-07-03 09:50:34 --> Helper loaded: url_helper
INFO - 2025-07-03 09:50:34 --> Helper loaded: form_helper
INFO - 2025-07-03 09:50:34 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:50:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:50:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:50:34 --> Controller Class Initialized
INFO - 2025-07-03 09:50:34 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:50:34 --> Model "User_model" initialized
INFO - 2025-07-03 09:50:34 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:50:34 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:50:34 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-07-03 09:50:34 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:50:34 --> Final output sent to browser
DEBUG - 2025-07-03 09:50:34 --> Total execution time: 0.0364
INFO - 2025-07-03 09:50:36 --> Config Class Initialized
INFO - 2025-07-03 09:50:36 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:50:36 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:50:36 --> Utf8 Class Initialized
INFO - 2025-07-03 09:50:36 --> URI Class Initialized
INFO - 2025-07-03 09:50:36 --> Router Class Initialized
INFO - 2025-07-03 09:50:36 --> Output Class Initialized
INFO - 2025-07-03 09:50:36 --> Security Class Initialized
DEBUG - 2025-07-03 09:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:50:36 --> Input Class Initialized
INFO - 2025-07-03 09:50:36 --> Language Class Initialized
INFO - 2025-07-03 09:50:36 --> Loader Class Initialized
INFO - 2025-07-03 09:50:36 --> Helper loaded: url_helper
INFO - 2025-07-03 09:50:36 --> Helper loaded: form_helper
INFO - 2025-07-03 09:50:36 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:50:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:50:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:50:36 --> Controller Class Initialized
INFO - 2025-07-03 09:50:36 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:50:36 --> Model "User_model" initialized
INFO - 2025-07-03 09:50:36 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:50:36 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:50:36 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/level.php
INFO - 2025-07-03 09:50:36 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:50:36 --> Final output sent to browser
DEBUG - 2025-07-03 09:50:36 --> Total execution time: 0.0350
INFO - 2025-07-03 09:50:38 --> Config Class Initialized
INFO - 2025-07-03 09:50:38 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:50:38 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:50:38 --> Utf8 Class Initialized
INFO - 2025-07-03 09:50:38 --> URI Class Initialized
INFO - 2025-07-03 09:50:38 --> Router Class Initialized
INFO - 2025-07-03 09:50:38 --> Output Class Initialized
INFO - 2025-07-03 09:50:38 --> Security Class Initialized
DEBUG - 2025-07-03 09:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:50:38 --> Input Class Initialized
INFO - 2025-07-03 09:50:38 --> Language Class Initialized
INFO - 2025-07-03 09:50:38 --> Loader Class Initialized
INFO - 2025-07-03 09:50:38 --> Helper loaded: url_helper
INFO - 2025-07-03 09:50:38 --> Helper loaded: form_helper
INFO - 2025-07-03 09:50:38 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:50:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:50:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:50:38 --> Controller Class Initialized
INFO - 2025-07-03 09:50:38 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:50:38 --> Model "User_model" initialized
INFO - 2025-07-03 09:50:38 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:50:38 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:50:38 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-07-03 09:50:38 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:50:38 --> Final output sent to browser
DEBUG - 2025-07-03 09:50:38 --> Total execution time: 0.0365
INFO - 2025-07-03 09:50:40 --> Config Class Initialized
INFO - 2025-07-03 09:50:40 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:50:40 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:50:40 --> Utf8 Class Initialized
INFO - 2025-07-03 09:50:40 --> URI Class Initialized
INFO - 2025-07-03 09:50:40 --> Router Class Initialized
INFO - 2025-07-03 09:50:40 --> Output Class Initialized
INFO - 2025-07-03 09:50:40 --> Security Class Initialized
DEBUG - 2025-07-03 09:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:50:40 --> Input Class Initialized
INFO - 2025-07-03 09:50:40 --> Language Class Initialized
INFO - 2025-07-03 09:50:40 --> Loader Class Initialized
INFO - 2025-07-03 09:50:40 --> Helper loaded: url_helper
INFO - 2025-07-03 09:50:40 --> Helper loaded: form_helper
INFO - 2025-07-03 09:50:40 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:50:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:50:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:50:40 --> Controller Class Initialized
INFO - 2025-07-03 09:50:40 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:50:40 --> Model "User_model" initialized
INFO - 2025-07-03 09:50:40 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:50:40 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:50:40 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-07-03 09:50:40 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:50:40 --> Final output sent to browser
DEBUG - 2025-07-03 09:50:40 --> Total execution time: 0.0453
INFO - 2025-07-03 09:50:45 --> Config Class Initialized
INFO - 2025-07-03 09:50:45 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:50:45 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:50:45 --> Utf8 Class Initialized
INFO - 2025-07-03 09:50:45 --> URI Class Initialized
INFO - 2025-07-03 09:50:45 --> Router Class Initialized
INFO - 2025-07-03 09:50:45 --> Output Class Initialized
INFO - 2025-07-03 09:50:45 --> Security Class Initialized
DEBUG - 2025-07-03 09:50:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:50:45 --> Input Class Initialized
INFO - 2025-07-03 09:50:45 --> Language Class Initialized
INFO - 2025-07-03 09:50:45 --> Loader Class Initialized
INFO - 2025-07-03 09:50:45 --> Helper loaded: url_helper
INFO - 2025-07-03 09:50:45 --> Helper loaded: form_helper
INFO - 2025-07-03 09:50:45 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:50:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:50:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:50:45 --> Controller Class Initialized
INFO - 2025-07-03 09:50:45 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:50:45 --> Model "User_model" initialized
INFO - 2025-07-03 09:50:45 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:50:45 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:50:45 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/level.php
INFO - 2025-07-03 09:50:45 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:50:45 --> Final output sent to browser
DEBUG - 2025-07-03 09:50:45 --> Total execution time: 0.0363
INFO - 2025-07-03 09:50:47 --> Config Class Initialized
INFO - 2025-07-03 09:50:47 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:50:47 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:50:47 --> Utf8 Class Initialized
INFO - 2025-07-03 09:50:47 --> URI Class Initialized
INFO - 2025-07-03 09:50:47 --> Router Class Initialized
INFO - 2025-07-03 09:50:47 --> Output Class Initialized
INFO - 2025-07-03 09:50:47 --> Security Class Initialized
DEBUG - 2025-07-03 09:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:50:47 --> Input Class Initialized
INFO - 2025-07-03 09:50:47 --> Language Class Initialized
INFO - 2025-07-03 09:50:47 --> Loader Class Initialized
INFO - 2025-07-03 09:50:47 --> Helper loaded: url_helper
INFO - 2025-07-03 09:50:47 --> Helper loaded: form_helper
INFO - 2025-07-03 09:50:47 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:50:47 --> Controller Class Initialized
INFO - 2025-07-03 09:50:47 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:50:47 --> Model "User_model" initialized
INFO - 2025-07-03 09:50:47 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:50:47 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:50:47 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-07-03 09:50:47 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:50:47 --> Final output sent to browser
DEBUG - 2025-07-03 09:50:47 --> Total execution time: 0.0381
INFO - 2025-07-03 09:52:13 --> Config Class Initialized
INFO - 2025-07-03 09:52:13 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:52:13 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:52:13 --> Utf8 Class Initialized
INFO - 2025-07-03 09:52:13 --> URI Class Initialized
INFO - 2025-07-03 09:52:13 --> Router Class Initialized
INFO - 2025-07-03 09:52:13 --> Output Class Initialized
INFO - 2025-07-03 09:52:13 --> Security Class Initialized
DEBUG - 2025-07-03 09:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:52:13 --> Input Class Initialized
INFO - 2025-07-03 09:52:13 --> Language Class Initialized
INFO - 2025-07-03 09:52:13 --> Loader Class Initialized
INFO - 2025-07-03 09:52:13 --> Helper loaded: url_helper
INFO - 2025-07-03 09:52:13 --> Helper loaded: form_helper
INFO - 2025-07-03 09:52:13 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:52:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:52:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:52:13 --> Controller Class Initialized
INFO - 2025-07-03 09:52:13 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:52:13 --> Model "User_model" initialized
INFO - 2025-07-03 09:52:13 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:52:13 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:52:13 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/level.php
INFO - 2025-07-03 09:52:13 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:52:13 --> Final output sent to browser
DEBUG - 2025-07-03 09:52:13 --> Total execution time: 0.0370
INFO - 2025-07-03 09:52:14 --> Config Class Initialized
INFO - 2025-07-03 09:52:14 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:52:14 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:52:14 --> Utf8 Class Initialized
INFO - 2025-07-03 09:52:14 --> URI Class Initialized
INFO - 2025-07-03 09:52:14 --> Router Class Initialized
INFO - 2025-07-03 09:52:14 --> Output Class Initialized
INFO - 2025-07-03 09:52:14 --> Security Class Initialized
DEBUG - 2025-07-03 09:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:52:14 --> Input Class Initialized
INFO - 2025-07-03 09:52:14 --> Language Class Initialized
INFO - 2025-07-03 09:52:14 --> Loader Class Initialized
INFO - 2025-07-03 09:52:14 --> Helper loaded: url_helper
INFO - 2025-07-03 09:52:14 --> Helper loaded: form_helper
INFO - 2025-07-03 09:52:14 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:52:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:52:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:52:14 --> Controller Class Initialized
INFO - 2025-07-03 09:52:14 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:52:14 --> Model "User_model" initialized
INFO - 2025-07-03 09:52:14 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:52:14 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:52:14 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-07-03 09:52:14 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:52:14 --> Final output sent to browser
DEBUG - 2025-07-03 09:52:14 --> Total execution time: 0.0324
INFO - 2025-07-03 09:52:15 --> Config Class Initialized
INFO - 2025-07-03 09:52:15 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:52:15 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:52:15 --> Utf8 Class Initialized
INFO - 2025-07-03 09:52:15 --> URI Class Initialized
INFO - 2025-07-03 09:52:15 --> Router Class Initialized
INFO - 2025-07-03 09:52:15 --> Output Class Initialized
INFO - 2025-07-03 09:52:15 --> Security Class Initialized
DEBUG - 2025-07-03 09:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:52:15 --> Input Class Initialized
INFO - 2025-07-03 09:52:15 --> Language Class Initialized
INFO - 2025-07-03 09:52:15 --> Loader Class Initialized
INFO - 2025-07-03 09:52:15 --> Helper loaded: url_helper
INFO - 2025-07-03 09:52:15 --> Helper loaded: form_helper
INFO - 2025-07-03 09:52:15 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:52:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:52:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:52:15 --> Controller Class Initialized
INFO - 2025-07-03 09:52:15 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:52:15 --> Model "User_model" initialized
INFO - 2025-07-03 09:52:15 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:52:15 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:52:15 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-07-03 09:52:15 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:52:15 --> Final output sent to browser
DEBUG - 2025-07-03 09:52:15 --> Total execution time: 0.0385
INFO - 2025-07-03 09:52:16 --> Config Class Initialized
INFO - 2025-07-03 09:52:16 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:52:16 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:52:16 --> Utf8 Class Initialized
INFO - 2025-07-03 09:52:16 --> URI Class Initialized
INFO - 2025-07-03 09:52:16 --> Router Class Initialized
INFO - 2025-07-03 09:52:16 --> Output Class Initialized
INFO - 2025-07-03 09:52:16 --> Security Class Initialized
DEBUG - 2025-07-03 09:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:52:16 --> Input Class Initialized
INFO - 2025-07-03 09:52:16 --> Language Class Initialized
INFO - 2025-07-03 09:52:16 --> Loader Class Initialized
INFO - 2025-07-03 09:52:16 --> Helper loaded: url_helper
INFO - 2025-07-03 09:52:16 --> Helper loaded: form_helper
INFO - 2025-07-03 09:52:16 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:52:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:52:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:52:16 --> Controller Class Initialized
INFO - 2025-07-03 09:52:16 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:52:16 --> Model "User_model" initialized
INFO - 2025-07-03 09:52:16 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:52:16 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:52:16 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/level.php
INFO - 2025-07-03 09:52:16 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:52:16 --> Final output sent to browser
DEBUG - 2025-07-03 09:52:16 --> Total execution time: 0.0391
INFO - 2025-07-03 09:52:17 --> Config Class Initialized
INFO - 2025-07-03 09:52:17 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:52:17 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:52:17 --> Utf8 Class Initialized
INFO - 2025-07-03 09:52:17 --> URI Class Initialized
INFO - 2025-07-03 09:52:17 --> Router Class Initialized
INFO - 2025-07-03 09:52:17 --> Output Class Initialized
INFO - 2025-07-03 09:52:17 --> Security Class Initialized
DEBUG - 2025-07-03 09:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:52:17 --> Input Class Initialized
INFO - 2025-07-03 09:52:17 --> Language Class Initialized
INFO - 2025-07-03 09:52:17 --> Loader Class Initialized
INFO - 2025-07-03 09:52:17 --> Helper loaded: url_helper
INFO - 2025-07-03 09:52:17 --> Helper loaded: form_helper
INFO - 2025-07-03 09:52:17 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:52:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:52:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:52:17 --> Controller Class Initialized
INFO - 2025-07-03 09:52:17 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:52:17 --> Model "User_model" initialized
INFO - 2025-07-03 09:52:17 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:52:17 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:52:17 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-07-03 09:52:17 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:52:17 --> Final output sent to browser
DEBUG - 2025-07-03 09:52:17 --> Total execution time: 0.0419
INFO - 2025-07-03 09:52:47 --> Config Class Initialized
INFO - 2025-07-03 09:52:47 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:52:47 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:52:47 --> Utf8 Class Initialized
INFO - 2025-07-03 09:52:47 --> URI Class Initialized
INFO - 2025-07-03 09:52:47 --> Router Class Initialized
INFO - 2025-07-03 09:52:47 --> Output Class Initialized
INFO - 2025-07-03 09:52:47 --> Security Class Initialized
DEBUG - 2025-07-03 09:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:52:47 --> Input Class Initialized
INFO - 2025-07-03 09:52:47 --> Language Class Initialized
INFO - 2025-07-03 09:52:47 --> Loader Class Initialized
INFO - 2025-07-03 09:52:47 --> Helper loaded: url_helper
INFO - 2025-07-03 09:52:47 --> Helper loaded: form_helper
INFO - 2025-07-03 09:52:47 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:52:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:52:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:52:47 --> Controller Class Initialized
INFO - 2025-07-03 09:52:47 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:52:47 --> Model "User_model" initialized
INFO - 2025-07-03 09:52:47 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:52:47 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:52:47 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-07-03 09:52:47 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:52:47 --> Final output sent to browser
DEBUG - 2025-07-03 09:52:47 --> Total execution time: 0.0424
INFO - 2025-07-03 09:53:37 --> Config Class Initialized
INFO - 2025-07-03 09:53:37 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:53:37 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:53:37 --> Utf8 Class Initialized
INFO - 2025-07-03 09:53:37 --> URI Class Initialized
INFO - 2025-07-03 09:53:37 --> Router Class Initialized
INFO - 2025-07-03 09:53:37 --> Output Class Initialized
INFO - 2025-07-03 09:53:37 --> Security Class Initialized
DEBUG - 2025-07-03 09:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:53:37 --> Input Class Initialized
INFO - 2025-07-03 09:53:37 --> Language Class Initialized
INFO - 2025-07-03 09:53:37 --> Loader Class Initialized
INFO - 2025-07-03 09:53:37 --> Helper loaded: url_helper
INFO - 2025-07-03 09:53:37 --> Helper loaded: form_helper
INFO - 2025-07-03 09:53:37 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:53:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:53:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:53:37 --> Controller Class Initialized
INFO - 2025-07-03 09:53:37 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:53:37 --> Model "User_model" initialized
INFO - 2025-07-03 09:53:37 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:53:37 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:53:37 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-07-03 09:53:37 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:53:37 --> Final output sent to browser
DEBUG - 2025-07-03 09:53:37 --> Total execution time: 0.0347
INFO - 2025-07-03 09:53:40 --> Config Class Initialized
INFO - 2025-07-03 09:53:40 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:53:40 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:53:40 --> Utf8 Class Initialized
INFO - 2025-07-03 09:53:40 --> URI Class Initialized
INFO - 2025-07-03 09:53:40 --> Router Class Initialized
INFO - 2025-07-03 09:53:40 --> Output Class Initialized
INFO - 2025-07-03 09:53:40 --> Security Class Initialized
DEBUG - 2025-07-03 09:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:53:40 --> Input Class Initialized
INFO - 2025-07-03 09:53:40 --> Language Class Initialized
INFO - 2025-07-03 09:53:40 --> Loader Class Initialized
INFO - 2025-07-03 09:53:40 --> Helper loaded: url_helper
INFO - 2025-07-03 09:53:40 --> Helper loaded: form_helper
INFO - 2025-07-03 09:53:40 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:53:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:53:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:53:40 --> Controller Class Initialized
INFO - 2025-07-03 09:53:40 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:53:40 --> Model "User_model" initialized
INFO - 2025-07-03 09:53:40 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:53:40 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:53:40 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-07-03 09:53:40 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:53:40 --> Final output sent to browser
DEBUG - 2025-07-03 09:53:40 --> Total execution time: 0.0380
INFO - 2025-07-03 09:53:42 --> Config Class Initialized
INFO - 2025-07-03 09:53:42 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:53:42 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:53:42 --> Utf8 Class Initialized
INFO - 2025-07-03 09:53:42 --> URI Class Initialized
INFO - 2025-07-03 09:53:42 --> Router Class Initialized
INFO - 2025-07-03 09:53:42 --> Output Class Initialized
INFO - 2025-07-03 09:53:42 --> Security Class Initialized
DEBUG - 2025-07-03 09:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:53:42 --> Input Class Initialized
INFO - 2025-07-03 09:53:42 --> Language Class Initialized
INFO - 2025-07-03 09:53:42 --> Loader Class Initialized
INFO - 2025-07-03 09:53:42 --> Helper loaded: url_helper
INFO - 2025-07-03 09:53:42 --> Helper loaded: form_helper
INFO - 2025-07-03 09:53:42 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:53:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:53:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:53:42 --> Controller Class Initialized
INFO - 2025-07-03 09:53:42 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:53:42 --> Model "User_model" initialized
INFO - 2025-07-03 09:53:42 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:53:42 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:53:42 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/level.php
INFO - 2025-07-03 09:53:42 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:53:42 --> Final output sent to browser
DEBUG - 2025-07-03 09:53:42 --> Total execution time: 0.0426
INFO - 2025-07-03 09:53:44 --> Config Class Initialized
INFO - 2025-07-03 09:53:44 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:53:44 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:53:44 --> Utf8 Class Initialized
INFO - 2025-07-03 09:53:44 --> URI Class Initialized
INFO - 2025-07-03 09:53:44 --> Router Class Initialized
INFO - 2025-07-03 09:53:44 --> Output Class Initialized
INFO - 2025-07-03 09:53:44 --> Security Class Initialized
DEBUG - 2025-07-03 09:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:53:44 --> Input Class Initialized
INFO - 2025-07-03 09:53:44 --> Language Class Initialized
INFO - 2025-07-03 09:53:44 --> Loader Class Initialized
INFO - 2025-07-03 09:53:44 --> Helper loaded: url_helper
INFO - 2025-07-03 09:53:44 --> Helper loaded: form_helper
INFO - 2025-07-03 09:53:44 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:53:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:53:44 --> Controller Class Initialized
INFO - 2025-07-03 09:53:44 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:53:44 --> Model "User_model" initialized
INFO - 2025-07-03 09:53:44 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:53:44 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:53:44 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-07-03 09:53:44 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:53:44 --> Final output sent to browser
DEBUG - 2025-07-03 09:53:44 --> Total execution time: 0.0435
INFO - 2025-07-03 09:54:41 --> Config Class Initialized
INFO - 2025-07-03 09:54:41 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:54:41 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:54:41 --> Utf8 Class Initialized
INFO - 2025-07-03 09:54:41 --> URI Class Initialized
INFO - 2025-07-03 09:54:41 --> Router Class Initialized
INFO - 2025-07-03 09:54:41 --> Output Class Initialized
INFO - 2025-07-03 09:54:41 --> Security Class Initialized
DEBUG - 2025-07-03 09:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:54:41 --> Input Class Initialized
INFO - 2025-07-03 09:54:41 --> Language Class Initialized
INFO - 2025-07-03 09:54:41 --> Loader Class Initialized
INFO - 2025-07-03 09:54:41 --> Helper loaded: url_helper
INFO - 2025-07-03 09:54:41 --> Helper loaded: form_helper
INFO - 2025-07-03 09:54:41 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:54:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:54:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:54:41 --> Controller Class Initialized
INFO - 2025-07-03 09:54:41 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:54:41 --> Model "User_model" initialized
INFO - 2025-07-03 09:54:41 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:54:41 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:54:41 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/level.php
INFO - 2025-07-03 09:54:41 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:54:41 --> Final output sent to browser
DEBUG - 2025-07-03 09:54:41 --> Total execution time: 0.0390
INFO - 2025-07-03 09:54:43 --> Config Class Initialized
INFO - 2025-07-03 09:54:43 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:54:43 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:54:43 --> Utf8 Class Initialized
INFO - 2025-07-03 09:54:43 --> URI Class Initialized
INFO - 2025-07-03 09:54:43 --> Router Class Initialized
INFO - 2025-07-03 09:54:43 --> Output Class Initialized
INFO - 2025-07-03 09:54:43 --> Security Class Initialized
DEBUG - 2025-07-03 09:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:54:43 --> Input Class Initialized
INFO - 2025-07-03 09:54:43 --> Language Class Initialized
INFO - 2025-07-03 09:54:43 --> Loader Class Initialized
INFO - 2025-07-03 09:54:43 --> Helper loaded: url_helper
INFO - 2025-07-03 09:54:43 --> Helper loaded: form_helper
INFO - 2025-07-03 09:54:43 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:54:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:54:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:54:43 --> Controller Class Initialized
INFO - 2025-07-03 09:54:43 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:54:43 --> Model "User_model" initialized
INFO - 2025-07-03 09:54:43 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:54:43 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:54:43 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-07-03 09:54:43 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:54:43 --> Final output sent to browser
DEBUG - 2025-07-03 09:54:43 --> Total execution time: 0.0362
INFO - 2025-07-03 09:57:42 --> Config Class Initialized
INFO - 2025-07-03 09:57:42 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:57:42 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:57:42 --> Utf8 Class Initialized
INFO - 2025-07-03 09:57:42 --> URI Class Initialized
INFO - 2025-07-03 09:57:42 --> Router Class Initialized
INFO - 2025-07-03 09:57:42 --> Output Class Initialized
INFO - 2025-07-03 09:57:42 --> Security Class Initialized
DEBUG - 2025-07-03 09:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:57:42 --> Input Class Initialized
INFO - 2025-07-03 09:57:42 --> Language Class Initialized
INFO - 2025-07-03 09:57:42 --> Loader Class Initialized
INFO - 2025-07-03 09:57:42 --> Helper loaded: url_helper
INFO - 2025-07-03 09:57:42 --> Helper loaded: form_helper
INFO - 2025-07-03 09:57:42 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:57:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:57:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:57:42 --> Controller Class Initialized
INFO - 2025-07-03 09:57:42 --> Model "User_model" initialized
INFO - 2025-07-03 09:57:42 --> Model "Community_model" initialized
INFO - 2025-07-03 09:57:42 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:57:42 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:57:42 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/community.php
INFO - 2025-07-03 09:57:42 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:57:42 --> Final output sent to browser
DEBUG - 2025-07-03 09:57:42 --> Total execution time: 0.0452
INFO - 2025-07-03 09:57:43 --> Config Class Initialized
INFO - 2025-07-03 09:57:43 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:57:43 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:57:43 --> Utf8 Class Initialized
INFO - 2025-07-03 09:57:43 --> URI Class Initialized
INFO - 2025-07-03 09:57:43 --> Router Class Initialized
INFO - 2025-07-03 09:57:43 --> Output Class Initialized
INFO - 2025-07-03 09:57:43 --> Security Class Initialized
DEBUG - 2025-07-03 09:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:57:43 --> Input Class Initialized
INFO - 2025-07-03 09:57:43 --> Language Class Initialized
INFO - 2025-07-03 09:57:43 --> Loader Class Initialized
INFO - 2025-07-03 09:57:43 --> Helper loaded: url_helper
INFO - 2025-07-03 09:57:43 --> Helper loaded: form_helper
INFO - 2025-07-03 09:57:43 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:57:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:57:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:57:43 --> Controller Class Initialized
INFO - 2025-07-03 09:57:43 --> Model "Progress_model" initialized
INFO - 2025-07-03 09:57:43 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:57:43 --> Model "User_model" initialized
INFO - 2025-07-03 09:57:43 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:57:43 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:57:43 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/progress_view.php
INFO - 2025-07-03 09:57:43 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:57:43 --> Final output sent to browser
DEBUG - 2025-07-03 09:57:43 --> Total execution time: 0.0332
INFO - 2025-07-03 09:57:43 --> Config Class Initialized
INFO - 2025-07-03 09:57:43 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:57:43 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:57:43 --> Utf8 Class Initialized
INFO - 2025-07-03 09:57:43 --> URI Class Initialized
INFO - 2025-07-03 09:57:43 --> Router Class Initialized
INFO - 2025-07-03 09:57:43 --> Output Class Initialized
INFO - 2025-07-03 09:57:43 --> Security Class Initialized
DEBUG - 2025-07-03 09:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:57:43 --> Input Class Initialized
INFO - 2025-07-03 09:57:43 --> Language Class Initialized
INFO - 2025-07-03 09:57:43 --> Loader Class Initialized
INFO - 2025-07-03 09:57:43 --> Helper loaded: url_helper
INFO - 2025-07-03 09:57:43 --> Helper loaded: form_helper
INFO - 2025-07-03 09:57:43 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:57:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:57:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:57:43 --> Controller Class Initialized
INFO - 2025-07-03 09:57:43 --> Model "Progress_model" initialized
INFO - 2025-07-03 09:57:43 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:57:43 --> Model "User_model" initialized
INFO - 2025-07-03 09:57:43 --> Final output sent to browser
DEBUG - 2025-07-03 09:57:43 --> Total execution time: 0.0385
INFO - 2025-07-03 09:57:45 --> Config Class Initialized
INFO - 2025-07-03 09:57:45 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:57:45 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:57:45 --> Utf8 Class Initialized
INFO - 2025-07-03 09:57:45 --> URI Class Initialized
INFO - 2025-07-03 09:57:45 --> Router Class Initialized
INFO - 2025-07-03 09:57:45 --> Output Class Initialized
INFO - 2025-07-03 09:57:45 --> Security Class Initialized
DEBUG - 2025-07-03 09:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:57:45 --> Input Class Initialized
INFO - 2025-07-03 09:57:45 --> Language Class Initialized
INFO - 2025-07-03 09:57:45 --> Loader Class Initialized
INFO - 2025-07-03 09:57:45 --> Helper loaded: url_helper
INFO - 2025-07-03 09:57:45 --> Helper loaded: form_helper
INFO - 2025-07-03 09:57:45 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:57:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:57:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:57:45 --> Controller Class Initialized
INFO - 2025-07-03 09:57:45 --> Model "Progress_model" initialized
INFO - 2025-07-03 09:57:45 --> Model "Olahraga_model" initialized
INFO - 2025-07-03 09:57:45 --> Model "User_model" initialized
INFO - 2025-07-03 09:57:45 --> Final output sent to browser
DEBUG - 2025-07-03 09:57:45 --> Total execution time: 0.0341
INFO - 2025-07-03 09:57:49 --> Config Class Initialized
INFO - 2025-07-03 09:57:49 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:57:49 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:57:49 --> Utf8 Class Initialized
INFO - 2025-07-03 09:57:49 --> URI Class Initialized
INFO - 2025-07-03 09:57:49 --> Router Class Initialized
INFO - 2025-07-03 09:57:49 --> Output Class Initialized
INFO - 2025-07-03 09:57:49 --> Security Class Initialized
DEBUG - 2025-07-03 09:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:57:49 --> Input Class Initialized
INFO - 2025-07-03 09:57:49 --> Language Class Initialized
INFO - 2025-07-03 09:57:49 --> Loader Class Initialized
INFO - 2025-07-03 09:57:49 --> Helper loaded: url_helper
INFO - 2025-07-03 09:57:49 --> Helper loaded: form_helper
INFO - 2025-07-03 09:57:49 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:57:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:57:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:57:49 --> Controller Class Initialized
INFO - 2025-07-03 09:57:49 --> Model "User_model" initialized
INFO - 2025-07-03 09:57:49 --> Model "Progress_model" initialized
INFO - 2025-07-03 09:57:49 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:57:49 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:57:49 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/guide.php
INFO - 2025-07-03 09:57:49 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:57:49 --> Final output sent to browser
DEBUG - 2025-07-03 09:57:49 --> Total execution time: 0.0322
INFO - 2025-07-03 09:57:52 --> Config Class Initialized
INFO - 2025-07-03 09:57:52 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:57:52 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:57:52 --> Utf8 Class Initialized
INFO - 2025-07-03 09:57:52 --> URI Class Initialized
INFO - 2025-07-03 09:57:52 --> Router Class Initialized
INFO - 2025-07-03 09:57:52 --> Output Class Initialized
INFO - 2025-07-03 09:57:52 --> Security Class Initialized
DEBUG - 2025-07-03 09:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:57:52 --> Input Class Initialized
INFO - 2025-07-03 09:57:52 --> Language Class Initialized
INFO - 2025-07-03 09:57:52 --> Loader Class Initialized
INFO - 2025-07-03 09:57:52 --> Helper loaded: url_helper
INFO - 2025-07-03 09:57:52 --> Helper loaded: form_helper
INFO - 2025-07-03 09:57:52 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:57:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:57:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:57:52 --> Controller Class Initialized
INFO - 2025-07-03 09:57:52 --> Model "User_model" initialized
INFO - 2025-07-03 09:57:52 --> Model "Progress_model" initialized
INFO - 2025-07-03 09:57:52 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:57:52 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:57:52 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/dashboard.php
INFO - 2025-07-03 09:57:52 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:57:52 --> Final output sent to browser
DEBUG - 2025-07-03 09:57:52 --> Total execution time: 0.0398
INFO - 2025-07-03 09:58:00 --> Config Class Initialized
INFO - 2025-07-03 09:58:00 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:58:00 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:58:00 --> Utf8 Class Initialized
INFO - 2025-07-03 09:58:00 --> URI Class Initialized
INFO - 2025-07-03 09:58:00 --> Router Class Initialized
INFO - 2025-07-03 09:58:00 --> Output Class Initialized
INFO - 2025-07-03 09:58:00 --> Security Class Initialized
DEBUG - 2025-07-03 09:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:58:00 --> Input Class Initialized
INFO - 2025-07-03 09:58:00 --> Language Class Initialized
INFO - 2025-07-03 09:58:00 --> Loader Class Initialized
INFO - 2025-07-03 09:58:00 --> Helper loaded: url_helper
INFO - 2025-07-03 09:58:00 --> Helper loaded: form_helper
INFO - 2025-07-03 09:58:00 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:58:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:58:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:58:00 --> Controller Class Initialized
INFO - 2025-07-03 09:58:00 --> Model "User_model" initialized
INFO - 2025-07-03 09:58:00 --> Model "Progress_model" initialized
INFO - 2025-07-03 09:58:00 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:58:00 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:58:00 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/dashboard.php
INFO - 2025-07-03 09:58:00 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:58:00 --> Final output sent to browser
DEBUG - 2025-07-03 09:58:00 --> Total execution time: 0.0366
INFO - 2025-07-03 09:58:03 --> Config Class Initialized
INFO - 2025-07-03 09:58:03 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:58:03 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:58:03 --> Utf8 Class Initialized
INFO - 2025-07-03 09:58:03 --> URI Class Initialized
INFO - 2025-07-03 09:58:03 --> Router Class Initialized
INFO - 2025-07-03 09:58:03 --> Output Class Initialized
INFO - 2025-07-03 09:58:03 --> Security Class Initialized
DEBUG - 2025-07-03 09:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:58:03 --> Input Class Initialized
INFO - 2025-07-03 09:58:03 --> Language Class Initialized
INFO - 2025-07-03 09:58:03 --> Loader Class Initialized
INFO - 2025-07-03 09:58:03 --> Helper loaded: url_helper
INFO - 2025-07-03 09:58:03 --> Helper loaded: form_helper
INFO - 2025-07-03 09:58:03 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:58:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:58:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:58:03 --> Controller Class Initialized
INFO - 2025-07-03 09:58:03 --> Model "User_model" initialized
INFO - 2025-07-03 09:58:03 --> Model "Progress_model" initialized
INFO - 2025-07-03 09:58:03 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-03 09:58:03 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-03 09:58:03 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/dashboard.php
INFO - 2025-07-03 09:58:03 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-03 09:58:03 --> Final output sent to browser
DEBUG - 2025-07-03 09:58:03 --> Total execution time: 0.0362
INFO - 2025-07-03 09:58:14 --> Config Class Initialized
INFO - 2025-07-03 09:58:14 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:58:14 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:58:14 --> Utf8 Class Initialized
INFO - 2025-07-03 09:58:14 --> URI Class Initialized
INFO - 2025-07-03 09:58:14 --> Router Class Initialized
INFO - 2025-07-03 09:58:14 --> Output Class Initialized
INFO - 2025-07-03 09:58:14 --> Security Class Initialized
DEBUG - 2025-07-03 09:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:58:14 --> Input Class Initialized
INFO - 2025-07-03 09:58:14 --> Language Class Initialized
INFO - 2025-07-03 09:58:14 --> Loader Class Initialized
INFO - 2025-07-03 09:58:14 --> Helper loaded: url_helper
INFO - 2025-07-03 09:58:14 --> Helper loaded: form_helper
INFO - 2025-07-03 09:58:14 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:58:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:58:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:58:14 --> Controller Class Initialized
INFO - 2025-07-03 09:58:14 --> Model "User_model" initialized
INFO - 2025-07-03 09:58:14 --> Form Validation Class Initialized
INFO - 2025-07-03 09:58:14 --> Config Class Initialized
INFO - 2025-07-03 09:58:14 --> Hooks Class Initialized
DEBUG - 2025-07-03 09:58:14 --> UTF-8 Support Enabled
INFO - 2025-07-03 09:58:14 --> Utf8 Class Initialized
INFO - 2025-07-03 09:58:14 --> URI Class Initialized
INFO - 2025-07-03 09:58:14 --> Router Class Initialized
INFO - 2025-07-03 09:58:14 --> Output Class Initialized
INFO - 2025-07-03 09:58:14 --> Security Class Initialized
DEBUG - 2025-07-03 09:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-03 09:58:14 --> Input Class Initialized
INFO - 2025-07-03 09:58:14 --> Language Class Initialized
INFO - 2025-07-03 09:58:14 --> Loader Class Initialized
INFO - 2025-07-03 09:58:14 --> Helper loaded: url_helper
INFO - 2025-07-03 09:58:14 --> Helper loaded: form_helper
INFO - 2025-07-03 09:58:14 --> Database Driver Class Initialized
DEBUG - 2025-07-03 09:58:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-03 09:58:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-03 09:58:14 --> Controller Class Initialized
INFO - 2025-07-03 09:58:14 --> Model "User_model" initialized
INFO - 2025-07-03 09:58:14 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-07-03 09:58:14 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\landing_page/home.php
INFO - 2025-07-03 09:58:14 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-07-03 09:58:14 --> Final output sent to browser
DEBUG - 2025-07-03 09:58:14 --> Total execution time: 0.0287
