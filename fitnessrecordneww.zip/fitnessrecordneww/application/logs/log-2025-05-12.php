<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-05-12 11:37:02 --> Config Class Initialized
INFO - 2025-05-12 11:37:02 --> Hooks Class Initialized
DEBUG - 2025-05-12 11:37:02 --> UTF-8 Support Enabled
INFO - 2025-05-12 11:37:02 --> Utf8 Class Initialized
INFO - 2025-05-12 11:37:02 --> URI Class Initialized
DEBUG - 2025-05-12 11:37:02 --> No URI present. Default controller set.
INFO - 2025-05-12 11:37:02 --> Router Class Initialized
INFO - 2025-05-12 11:37:02 --> Output Class Initialized
INFO - 2025-05-12 11:37:02 --> Security Class Initialized
DEBUG - 2025-05-12 11:37:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 11:37:02 --> Input Class Initialized
INFO - 2025-05-12 11:37:02 --> Language Class Initialized
INFO - 2025-05-12 11:37:02 --> Loader Class Initialized
INFO - 2025-05-12 11:37:02 --> Helper loaded: url_helper
INFO - 2025-05-12 11:37:02 --> Helper loaded: form_helper
INFO - 2025-05-12 11:37:03 --> Database Driver Class Initialized
DEBUG - 2025-05-12 11:37:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 11:37:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 11:37:03 --> Controller Class Initialized
INFO - 2025-05-12 11:37:03 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-12 11:37:03 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-12 11:37:03 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-12 11:37:03 --> Final output sent to browser
DEBUG - 2025-05-12 11:37:03 --> Total execution time: 0.1414
INFO - 2025-05-12 11:37:08 --> Config Class Initialized
INFO - 2025-05-12 11:37:08 --> Hooks Class Initialized
DEBUG - 2025-05-12 11:37:08 --> UTF-8 Support Enabled
INFO - 2025-05-12 11:37:08 --> Utf8 Class Initialized
INFO - 2025-05-12 11:37:08 --> URI Class Initialized
INFO - 2025-05-12 11:37:08 --> Router Class Initialized
INFO - 2025-05-12 11:37:08 --> Output Class Initialized
INFO - 2025-05-12 11:37:08 --> Security Class Initialized
DEBUG - 2025-05-12 11:37:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 11:37:08 --> Input Class Initialized
INFO - 2025-05-12 11:37:08 --> Language Class Initialized
INFO - 2025-05-12 11:37:08 --> Loader Class Initialized
INFO - 2025-05-12 11:37:08 --> Helper loaded: url_helper
INFO - 2025-05-12 11:37:08 --> Helper loaded: form_helper
INFO - 2025-05-12 11:37:08 --> Database Driver Class Initialized
DEBUG - 2025-05-12 11:37:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 11:37:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 11:37:08 --> Controller Class Initialized
INFO - 2025-05-12 11:37:08 --> Model "User_model" initialized
INFO - 2025-05-12 11:37:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-12 11:37:08 --> Final output sent to browser
DEBUG - 2025-05-12 11:37:08 --> Total execution time: 0.1026
INFO - 2025-05-12 11:37:15 --> Config Class Initialized
INFO - 2025-05-12 11:37:15 --> Hooks Class Initialized
DEBUG - 2025-05-12 11:37:15 --> UTF-8 Support Enabled
INFO - 2025-05-12 11:37:15 --> Utf8 Class Initialized
INFO - 2025-05-12 11:37:15 --> URI Class Initialized
INFO - 2025-05-12 11:37:15 --> Router Class Initialized
INFO - 2025-05-12 11:37:15 --> Output Class Initialized
INFO - 2025-05-12 11:37:15 --> Security Class Initialized
DEBUG - 2025-05-12 11:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 11:37:15 --> Input Class Initialized
INFO - 2025-05-12 11:37:15 --> Language Class Initialized
INFO - 2025-05-12 11:37:15 --> Loader Class Initialized
INFO - 2025-05-12 11:37:15 --> Helper loaded: url_helper
INFO - 2025-05-12 11:37:15 --> Helper loaded: form_helper
INFO - 2025-05-12 11:37:15 --> Database Driver Class Initialized
DEBUG - 2025-05-12 11:37:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 11:37:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 11:37:15 --> Controller Class Initialized
INFO - 2025-05-12 11:37:15 --> Model "User_model" initialized
INFO - 2025-05-12 11:37:15 --> Config Class Initialized
INFO - 2025-05-12 11:37:15 --> Hooks Class Initialized
DEBUG - 2025-05-12 11:37:15 --> UTF-8 Support Enabled
INFO - 2025-05-12 11:37:15 --> Utf8 Class Initialized
INFO - 2025-05-12 11:37:15 --> URI Class Initialized
INFO - 2025-05-12 11:37:15 --> Router Class Initialized
INFO - 2025-05-12 11:37:15 --> Output Class Initialized
INFO - 2025-05-12 11:37:15 --> Security Class Initialized
DEBUG - 2025-05-12 11:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 11:37:15 --> Input Class Initialized
INFO - 2025-05-12 11:37:15 --> Language Class Initialized
INFO - 2025-05-12 11:37:15 --> Loader Class Initialized
INFO - 2025-05-12 11:37:15 --> Helper loaded: url_helper
INFO - 2025-05-12 11:37:15 --> Helper loaded: form_helper
INFO - 2025-05-12 11:37:15 --> Database Driver Class Initialized
DEBUG - 2025-05-12 11:37:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 11:37:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 11:37:15 --> Controller Class Initialized
INFO - 2025-05-12 11:37:15 --> Model "User_model" initialized
INFO - 2025-05-12 11:37:15 --> Model "Workout_model" initialized
INFO - 2025-05-12 11:37:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard.php
INFO - 2025-05-12 11:37:15 --> Final output sent to browser
DEBUG - 2025-05-12 11:37:15 --> Total execution time: 0.1037
INFO - 2025-05-12 11:37:25 --> Config Class Initialized
INFO - 2025-05-12 11:37:25 --> Hooks Class Initialized
DEBUG - 2025-05-12 11:37:25 --> UTF-8 Support Enabled
INFO - 2025-05-12 11:37:25 --> Utf8 Class Initialized
INFO - 2025-05-12 11:37:25 --> URI Class Initialized
INFO - 2025-05-12 11:37:25 --> Router Class Initialized
INFO - 2025-05-12 11:37:25 --> Output Class Initialized
INFO - 2025-05-12 11:37:25 --> Security Class Initialized
DEBUG - 2025-05-12 11:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 11:37:25 --> Input Class Initialized
INFO - 2025-05-12 11:37:25 --> Language Class Initialized
INFO - 2025-05-12 11:37:26 --> Loader Class Initialized
INFO - 2025-05-12 11:37:26 --> Helper loaded: url_helper
INFO - 2025-05-12 11:37:26 --> Helper loaded: form_helper
INFO - 2025-05-12 11:37:26 --> Database Driver Class Initialized
DEBUG - 2025-05-12 11:37:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 11:37:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 11:37:26 --> Controller Class Initialized
INFO - 2025-05-12 11:37:26 --> Model "User_model" initialized
INFO - 2025-05-12 11:37:26 --> Model "Workout_model" initialized
INFO - 2025-05-12 11:37:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard.php
INFO - 2025-05-12 11:37:26 --> Final output sent to browser
DEBUG - 2025-05-12 11:37:26 --> Total execution time: 0.1008
INFO - 2025-05-12 11:37:32 --> Config Class Initialized
INFO - 2025-05-12 11:37:32 --> Hooks Class Initialized
DEBUG - 2025-05-12 11:37:32 --> UTF-8 Support Enabled
INFO - 2025-05-12 11:37:32 --> Utf8 Class Initialized
INFO - 2025-05-12 11:37:32 --> URI Class Initialized
INFO - 2025-05-12 11:37:32 --> Router Class Initialized
INFO - 2025-05-12 11:37:32 --> Output Class Initialized
INFO - 2025-05-12 11:37:32 --> Security Class Initialized
DEBUG - 2025-05-12 11:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 11:37:32 --> Input Class Initialized
INFO - 2025-05-12 11:37:32 --> Language Class Initialized
INFO - 2025-05-12 11:37:32 --> Loader Class Initialized
INFO - 2025-05-12 11:37:32 --> Helper loaded: url_helper
INFO - 2025-05-12 11:37:32 --> Helper loaded: form_helper
INFO - 2025-05-12 11:37:32 --> Database Driver Class Initialized
DEBUG - 2025-05-12 11:37:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 11:37:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 11:37:32 --> Controller Class Initialized
INFO - 2025-05-12 11:37:32 --> Model "User_model" initialized
INFO - 2025-05-12 11:37:32 --> Model "Workout_model" initialized
INFO - 2025-05-12 11:37:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard.php
INFO - 2025-05-12 11:37:32 --> Final output sent to browser
DEBUG - 2025-05-12 11:37:32 --> Total execution time: 0.1039
INFO - 2025-05-12 11:41:13 --> Config Class Initialized
INFO - 2025-05-12 11:41:13 --> Hooks Class Initialized
DEBUG - 2025-05-12 11:41:13 --> UTF-8 Support Enabled
INFO - 2025-05-12 11:41:13 --> Utf8 Class Initialized
INFO - 2025-05-12 11:41:13 --> URI Class Initialized
DEBUG - 2025-05-12 11:41:13 --> No URI present. Default controller set.
INFO - 2025-05-12 11:41:13 --> Router Class Initialized
INFO - 2025-05-12 11:41:13 --> Output Class Initialized
INFO - 2025-05-12 11:41:13 --> Security Class Initialized
DEBUG - 2025-05-12 11:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 11:41:13 --> Input Class Initialized
INFO - 2025-05-12 11:41:13 --> Language Class Initialized
INFO - 2025-05-12 11:41:13 --> Loader Class Initialized
INFO - 2025-05-12 11:41:13 --> Helper loaded: url_helper
INFO - 2025-05-12 11:41:13 --> Helper loaded: form_helper
INFO - 2025-05-12 11:41:13 --> Database Driver Class Initialized
DEBUG - 2025-05-12 11:41:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 11:41:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 11:41:13 --> Controller Class Initialized
INFO - 2025-05-12 11:41:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-12 11:41:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-12 11:41:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-12 11:41:13 --> Final output sent to browser
DEBUG - 2025-05-12 11:41:13 --> Total execution time: 0.1268
INFO - 2025-05-12 11:41:49 --> Config Class Initialized
INFO - 2025-05-12 11:41:49 --> Hooks Class Initialized
DEBUG - 2025-05-12 11:41:49 --> UTF-8 Support Enabled
INFO - 2025-05-12 11:41:49 --> Utf8 Class Initialized
INFO - 2025-05-12 11:41:49 --> URI Class Initialized
INFO - 2025-05-12 11:41:49 --> Router Class Initialized
INFO - 2025-05-12 11:41:49 --> Output Class Initialized
INFO - 2025-05-12 11:41:49 --> Security Class Initialized
DEBUG - 2025-05-12 11:41:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 11:41:49 --> Input Class Initialized
INFO - 2025-05-12 11:41:49 --> Language Class Initialized
INFO - 2025-05-12 11:41:49 --> Loader Class Initialized
INFO - 2025-05-12 11:41:49 --> Helper loaded: url_helper
INFO - 2025-05-12 11:41:49 --> Helper loaded: form_helper
INFO - 2025-05-12 11:41:49 --> Database Driver Class Initialized
DEBUG - 2025-05-12 11:41:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 11:41:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 11:41:49 --> Controller Class Initialized
INFO - 2025-05-12 11:41:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-12 11:41:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/artikel.php
INFO - 2025-05-12 11:41:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-12 11:41:49 --> Final output sent to browser
DEBUG - 2025-05-12 11:41:49 --> Total execution time: 0.1071
INFO - 2025-05-12 11:42:24 --> Config Class Initialized
INFO - 2025-05-12 11:42:24 --> Hooks Class Initialized
DEBUG - 2025-05-12 11:42:24 --> UTF-8 Support Enabled
INFO - 2025-05-12 11:42:24 --> Utf8 Class Initialized
INFO - 2025-05-12 11:42:24 --> URI Class Initialized
INFO - 2025-05-12 11:42:24 --> Router Class Initialized
INFO - 2025-05-12 11:42:24 --> Output Class Initialized
INFO - 2025-05-12 11:42:24 --> Security Class Initialized
DEBUG - 2025-05-12 11:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 11:42:24 --> Input Class Initialized
INFO - 2025-05-12 11:42:24 --> Language Class Initialized
INFO - 2025-05-12 11:42:24 --> Loader Class Initialized
INFO - 2025-05-12 11:42:24 --> Helper loaded: url_helper
INFO - 2025-05-12 11:42:24 --> Helper loaded: form_helper
INFO - 2025-05-12 11:42:24 --> Database Driver Class Initialized
DEBUG - 2025-05-12 11:42:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 11:42:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 11:42:24 --> Controller Class Initialized
INFO - 2025-05-12 11:42:24 --> Model "User_model" initialized
INFO - 2025-05-12 11:42:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-12 11:42:24 --> Final output sent to browser
DEBUG - 2025-05-12 11:42:24 --> Total execution time: 0.0802
INFO - 2025-05-12 11:42:46 --> Config Class Initialized
INFO - 2025-05-12 11:42:46 --> Hooks Class Initialized
DEBUG - 2025-05-12 11:42:46 --> UTF-8 Support Enabled
INFO - 2025-05-12 11:42:46 --> Utf8 Class Initialized
INFO - 2025-05-12 11:42:46 --> URI Class Initialized
INFO - 2025-05-12 11:42:46 --> Router Class Initialized
INFO - 2025-05-12 11:42:46 --> Output Class Initialized
INFO - 2025-05-12 11:42:46 --> Security Class Initialized
DEBUG - 2025-05-12 11:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 11:42:46 --> Input Class Initialized
INFO - 2025-05-12 11:42:46 --> Language Class Initialized
INFO - 2025-05-12 11:42:46 --> Loader Class Initialized
INFO - 2025-05-12 11:42:46 --> Helper loaded: url_helper
INFO - 2025-05-12 11:42:46 --> Helper loaded: form_helper
INFO - 2025-05-12 11:42:46 --> Database Driver Class Initialized
DEBUG - 2025-05-12 11:42:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 11:42:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 11:42:46 --> Controller Class Initialized
INFO - 2025-05-12 11:42:46 --> Model "User_model" initialized
INFO - 2025-05-12 11:42:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/register.php
INFO - 2025-05-12 11:42:46 --> Final output sent to browser
DEBUG - 2025-05-12 11:42:46 --> Total execution time: 0.0740
INFO - 2025-05-12 11:44:21 --> Config Class Initialized
INFO - 2025-05-12 11:44:21 --> Hooks Class Initialized
DEBUG - 2025-05-12 11:44:21 --> UTF-8 Support Enabled
INFO - 2025-05-12 11:44:21 --> Utf8 Class Initialized
INFO - 2025-05-12 11:44:21 --> URI Class Initialized
INFO - 2025-05-12 11:44:21 --> Router Class Initialized
INFO - 2025-05-12 11:44:21 --> Output Class Initialized
INFO - 2025-05-12 11:44:21 --> Security Class Initialized
DEBUG - 2025-05-12 11:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 11:44:21 --> Input Class Initialized
INFO - 2025-05-12 11:44:21 --> Language Class Initialized
INFO - 2025-05-12 11:44:21 --> Loader Class Initialized
INFO - 2025-05-12 11:44:21 --> Helper loaded: url_helper
INFO - 2025-05-12 11:44:21 --> Helper loaded: form_helper
INFO - 2025-05-12 11:44:21 --> Database Driver Class Initialized
DEBUG - 2025-05-12 11:44:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 11:44:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 11:44:21 --> Controller Class Initialized
INFO - 2025-05-12 11:44:21 --> Model "User_model" initialized
INFO - 2025-05-12 11:44:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-12 11:44:21 --> Final output sent to browser
DEBUG - 2025-05-12 11:44:21 --> Total execution time: 0.0984
INFO - 2025-05-12 11:44:32 --> Config Class Initialized
INFO - 2025-05-12 11:44:32 --> Hooks Class Initialized
DEBUG - 2025-05-12 11:44:32 --> UTF-8 Support Enabled
INFO - 2025-05-12 11:44:32 --> Utf8 Class Initialized
INFO - 2025-05-12 11:44:32 --> URI Class Initialized
INFO - 2025-05-12 11:44:32 --> Router Class Initialized
INFO - 2025-05-12 11:44:32 --> Output Class Initialized
INFO - 2025-05-12 11:44:32 --> Security Class Initialized
DEBUG - 2025-05-12 11:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 11:44:32 --> Input Class Initialized
INFO - 2025-05-12 11:44:32 --> Language Class Initialized
INFO - 2025-05-12 11:44:32 --> Loader Class Initialized
INFO - 2025-05-12 11:44:32 --> Helper loaded: url_helper
INFO - 2025-05-12 11:44:32 --> Helper loaded: form_helper
INFO - 2025-05-12 11:44:32 --> Database Driver Class Initialized
DEBUG - 2025-05-12 11:44:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 11:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 11:44:32 --> Controller Class Initialized
INFO - 2025-05-12 11:44:32 --> Model "User_model" initialized
INFO - 2025-05-12 11:44:32 --> Config Class Initialized
INFO - 2025-05-12 11:44:32 --> Hooks Class Initialized
DEBUG - 2025-05-12 11:44:32 --> UTF-8 Support Enabled
INFO - 2025-05-12 11:44:32 --> Utf8 Class Initialized
INFO - 2025-05-12 11:44:32 --> URI Class Initialized
INFO - 2025-05-12 11:44:32 --> Router Class Initialized
INFO - 2025-05-12 11:44:32 --> Output Class Initialized
INFO - 2025-05-12 11:44:32 --> Security Class Initialized
DEBUG - 2025-05-12 11:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 11:44:33 --> Input Class Initialized
INFO - 2025-05-12 11:44:33 --> Language Class Initialized
INFO - 2025-05-12 11:44:33 --> Loader Class Initialized
INFO - 2025-05-12 11:44:33 --> Helper loaded: url_helper
INFO - 2025-05-12 11:44:33 --> Helper loaded: form_helper
INFO - 2025-05-12 11:44:33 --> Database Driver Class Initialized
DEBUG - 2025-05-12 11:44:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 11:44:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 11:44:33 --> Controller Class Initialized
INFO - 2025-05-12 11:44:33 --> Model "User_model" initialized
INFO - 2025-05-12 11:44:33 --> Model "Workout_model" initialized
INFO - 2025-05-12 11:44:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard.php
INFO - 2025-05-12 11:44:33 --> Final output sent to browser
DEBUG - 2025-05-12 11:44:33 --> Total execution time: 0.1154
INFO - 2025-05-12 12:15:55 --> Config Class Initialized
INFO - 2025-05-12 12:15:55 --> Hooks Class Initialized
DEBUG - 2025-05-12 12:15:55 --> UTF-8 Support Enabled
INFO - 2025-05-12 12:15:55 --> Utf8 Class Initialized
INFO - 2025-05-12 12:15:55 --> URI Class Initialized
INFO - 2025-05-12 12:15:55 --> Router Class Initialized
INFO - 2025-05-12 12:15:55 --> Output Class Initialized
INFO - 2025-05-12 12:15:56 --> Security Class Initialized
DEBUG - 2025-05-12 12:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 12:15:56 --> Input Class Initialized
INFO - 2025-05-12 12:15:56 --> Language Class Initialized
INFO - 2025-05-12 12:15:56 --> Loader Class Initialized
INFO - 2025-05-12 12:15:56 --> Helper loaded: url_helper
INFO - 2025-05-12 12:15:56 --> Helper loaded: form_helper
INFO - 2025-05-12 12:15:56 --> Database Driver Class Initialized
DEBUG - 2025-05-12 12:15:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 12:15:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 12:15:56 --> Controller Class Initialized
INFO - 2025-05-12 12:15:57 --> Model "User_model" initialized
INFO - 2025-05-12 12:15:57 --> Model "Workout_model" initialized
INFO - 2025-05-12 12:15:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 12:15:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 12:15:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-12 12:15:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 12:15:57 --> Final output sent to browser
DEBUG - 2025-05-12 12:15:57 --> Total execution time: 2.0484
INFO - 2025-05-12 12:24:28 --> Config Class Initialized
INFO - 2025-05-12 12:24:28 --> Hooks Class Initialized
DEBUG - 2025-05-12 12:24:28 --> UTF-8 Support Enabled
INFO - 2025-05-12 12:24:28 --> Utf8 Class Initialized
INFO - 2025-05-12 12:24:28 --> URI Class Initialized
INFO - 2025-05-12 12:24:28 --> Router Class Initialized
INFO - 2025-05-12 12:24:28 --> Output Class Initialized
INFO - 2025-05-12 12:24:28 --> Security Class Initialized
DEBUG - 2025-05-12 12:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 12:24:28 --> Input Class Initialized
INFO - 2025-05-12 12:24:28 --> Language Class Initialized
INFO - 2025-05-12 12:24:28 --> Loader Class Initialized
INFO - 2025-05-12 12:24:28 --> Helper loaded: url_helper
INFO - 2025-05-12 12:24:28 --> Helper loaded: form_helper
INFO - 2025-05-12 12:24:28 --> Database Driver Class Initialized
DEBUG - 2025-05-12 12:24:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 12:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 12:24:28 --> Controller Class Initialized
INFO - 2025-05-12 12:24:28 --> Model "Workout_model" initialized
INFO - 2025-05-12 12:24:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-12 12:24:28 --> Final output sent to browser
DEBUG - 2025-05-12 12:24:28 --> Total execution time: 0.1306
INFO - 2025-05-12 12:24:31 --> Config Class Initialized
INFO - 2025-05-12 12:24:31 --> Hooks Class Initialized
DEBUG - 2025-05-12 12:24:31 --> UTF-8 Support Enabled
INFO - 2025-05-12 12:24:31 --> Utf8 Class Initialized
INFO - 2025-05-12 12:24:31 --> URI Class Initialized
INFO - 2025-05-12 12:24:31 --> Router Class Initialized
INFO - 2025-05-12 12:24:31 --> Output Class Initialized
INFO - 2025-05-12 12:24:31 --> Security Class Initialized
DEBUG - 2025-05-12 12:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 12:24:31 --> Input Class Initialized
INFO - 2025-05-12 12:24:31 --> Language Class Initialized
INFO - 2025-05-12 12:24:31 --> Loader Class Initialized
INFO - 2025-05-12 12:24:31 --> Helper loaded: url_helper
INFO - 2025-05-12 12:24:31 --> Helper loaded: form_helper
INFO - 2025-05-12 12:24:31 --> Database Driver Class Initialized
DEBUG - 2025-05-12 12:24:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 12:24:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 12:24:31 --> Controller Class Initialized
INFO - 2025-05-12 12:24:31 --> Model "Workout_model" initialized
INFO - 2025-05-12 12:24:31 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/add.php
INFO - 2025-05-12 12:24:31 --> Final output sent to browser
DEBUG - 2025-05-12 12:24:31 --> Total execution time: 0.1167
INFO - 2025-05-12 12:24:41 --> Config Class Initialized
INFO - 2025-05-12 12:24:41 --> Hooks Class Initialized
DEBUG - 2025-05-12 12:24:41 --> UTF-8 Support Enabled
INFO - 2025-05-12 12:24:41 --> Utf8 Class Initialized
INFO - 2025-05-12 12:24:41 --> URI Class Initialized
INFO - 2025-05-12 12:24:41 --> Router Class Initialized
INFO - 2025-05-12 12:24:41 --> Output Class Initialized
INFO - 2025-05-12 12:24:41 --> Security Class Initialized
DEBUG - 2025-05-12 12:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 12:24:41 --> Input Class Initialized
INFO - 2025-05-12 12:24:41 --> Language Class Initialized
INFO - 2025-05-12 12:24:41 --> Loader Class Initialized
INFO - 2025-05-12 12:24:41 --> Helper loaded: url_helper
INFO - 2025-05-12 12:24:41 --> Helper loaded: form_helper
INFO - 2025-05-12 12:24:41 --> Database Driver Class Initialized
DEBUG - 2025-05-12 12:24:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 12:24:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 12:24:41 --> Controller Class Initialized
INFO - 2025-05-12 12:24:41 --> Model "Workout_model" initialized
INFO - 2025-05-12 12:24:41 --> Config Class Initialized
INFO - 2025-05-12 12:24:41 --> Hooks Class Initialized
DEBUG - 2025-05-12 12:24:41 --> UTF-8 Support Enabled
INFO - 2025-05-12 12:24:41 --> Utf8 Class Initialized
INFO - 2025-05-12 12:24:41 --> URI Class Initialized
INFO - 2025-05-12 12:24:41 --> Router Class Initialized
INFO - 2025-05-12 12:24:41 --> Output Class Initialized
INFO - 2025-05-12 12:24:41 --> Security Class Initialized
DEBUG - 2025-05-12 12:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 12:24:41 --> Input Class Initialized
INFO - 2025-05-12 12:24:41 --> Language Class Initialized
INFO - 2025-05-12 12:24:41 --> Loader Class Initialized
INFO - 2025-05-12 12:24:41 --> Helper loaded: url_helper
INFO - 2025-05-12 12:24:41 --> Helper loaded: form_helper
INFO - 2025-05-12 12:24:41 --> Database Driver Class Initialized
DEBUG - 2025-05-12 12:24:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 12:24:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 12:24:41 --> Controller Class Initialized
INFO - 2025-05-12 12:24:41 --> Model "Workout_model" initialized
INFO - 2025-05-12 12:24:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-12 12:24:41 --> Final output sent to browser
DEBUG - 2025-05-12 12:24:41 --> Total execution time: 0.0884
INFO - 2025-05-12 12:24:43 --> Config Class Initialized
INFO - 2025-05-12 12:24:43 --> Hooks Class Initialized
DEBUG - 2025-05-12 12:24:43 --> UTF-8 Support Enabled
INFO - 2025-05-12 12:24:43 --> Utf8 Class Initialized
INFO - 2025-05-12 12:24:43 --> URI Class Initialized
INFO - 2025-05-12 12:24:43 --> Router Class Initialized
INFO - 2025-05-12 12:24:43 --> Output Class Initialized
INFO - 2025-05-12 12:24:43 --> Security Class Initialized
DEBUG - 2025-05-12 12:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 12:24:43 --> Input Class Initialized
INFO - 2025-05-12 12:24:43 --> Language Class Initialized
INFO - 2025-05-12 12:24:43 --> Loader Class Initialized
INFO - 2025-05-12 12:24:43 --> Helper loaded: url_helper
INFO - 2025-05-12 12:24:43 --> Helper loaded: form_helper
INFO - 2025-05-12 12:24:43 --> Database Driver Class Initialized
DEBUG - 2025-05-12 12:24:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 12:24:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 12:24:43 --> Controller Class Initialized
INFO - 2025-05-12 12:24:43 --> Model "Workout_model" initialized
INFO - 2025-05-12 12:24:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/start.php
INFO - 2025-05-12 12:24:43 --> Final output sent to browser
DEBUG - 2025-05-12 12:24:43 --> Total execution time: 0.1808
INFO - 2025-05-12 12:24:49 --> Config Class Initialized
INFO - 2025-05-12 12:24:49 --> Hooks Class Initialized
DEBUG - 2025-05-12 12:24:49 --> UTF-8 Support Enabled
INFO - 2025-05-12 12:24:49 --> Utf8 Class Initialized
INFO - 2025-05-12 12:24:49 --> URI Class Initialized
INFO - 2025-05-12 12:24:49 --> Router Class Initialized
INFO - 2025-05-12 12:24:49 --> Output Class Initialized
INFO - 2025-05-12 12:24:49 --> Security Class Initialized
DEBUG - 2025-05-12 12:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 12:24:49 --> Input Class Initialized
INFO - 2025-05-12 12:24:49 --> Language Class Initialized
INFO - 2025-05-12 12:24:49 --> Loader Class Initialized
INFO - 2025-05-12 12:24:49 --> Helper loaded: url_helper
INFO - 2025-05-12 12:24:49 --> Helper loaded: form_helper
INFO - 2025-05-12 12:24:49 --> Database Driver Class Initialized
DEBUG - 2025-05-12 12:24:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 12:24:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 12:24:49 --> Controller Class Initialized
INFO - 2025-05-12 12:24:49 --> Model "Workout_model" initialized
INFO - 2025-05-12 12:24:49 --> Final output sent to browser
DEBUG - 2025-05-12 12:24:49 --> Total execution time: 0.0786
INFO - 2025-05-12 12:24:49 --> Config Class Initialized
INFO - 2025-05-12 12:24:49 --> Hooks Class Initialized
DEBUG - 2025-05-12 12:24:49 --> UTF-8 Support Enabled
INFO - 2025-05-12 12:24:49 --> Utf8 Class Initialized
INFO - 2025-05-12 12:24:49 --> URI Class Initialized
INFO - 2025-05-12 12:24:49 --> Router Class Initialized
INFO - 2025-05-12 12:24:49 --> Output Class Initialized
INFO - 2025-05-12 12:24:49 --> Security Class Initialized
DEBUG - 2025-05-12 12:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 12:24:49 --> Input Class Initialized
INFO - 2025-05-12 12:24:49 --> Language Class Initialized
INFO - 2025-05-12 12:24:49 --> Loader Class Initialized
INFO - 2025-05-12 12:24:49 --> Helper loaded: url_helper
INFO - 2025-05-12 12:24:49 --> Helper loaded: form_helper
INFO - 2025-05-12 12:24:49 --> Database Driver Class Initialized
DEBUG - 2025-05-12 12:24:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 12:24:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 12:24:49 --> Controller Class Initialized
INFO - 2025-05-12 12:24:49 --> Model "Workout_model" initialized
INFO - 2025-05-12 12:24:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-12 12:24:49 --> Final output sent to browser
DEBUG - 2025-05-12 12:24:49 --> Total execution time: 0.0993
INFO - 2025-05-12 12:25:00 --> Config Class Initialized
INFO - 2025-05-12 12:25:00 --> Hooks Class Initialized
DEBUG - 2025-05-12 12:25:00 --> UTF-8 Support Enabled
INFO - 2025-05-12 12:25:00 --> Utf8 Class Initialized
INFO - 2025-05-12 12:25:00 --> URI Class Initialized
INFO - 2025-05-12 12:25:00 --> Router Class Initialized
INFO - 2025-05-12 12:25:00 --> Output Class Initialized
INFO - 2025-05-12 12:25:00 --> Security Class Initialized
DEBUG - 2025-05-12 12:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 12:25:00 --> Input Class Initialized
INFO - 2025-05-12 12:25:00 --> Language Class Initialized
INFO - 2025-05-12 12:25:00 --> Loader Class Initialized
INFO - 2025-05-12 12:25:00 --> Helper loaded: url_helper
INFO - 2025-05-12 12:25:00 --> Helper loaded: form_helper
INFO - 2025-05-12 12:25:00 --> Database Driver Class Initialized
DEBUG - 2025-05-12 12:25:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 12:25:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 12:25:00 --> Controller Class Initialized
INFO - 2025-05-12 12:25:00 --> Model "Workout_model" initialized
INFO - 2025-05-12 12:25:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/add.php
INFO - 2025-05-12 12:25:00 --> Final output sent to browser
DEBUG - 2025-05-12 12:25:00 --> Total execution time: 0.0868
INFO - 2025-05-12 12:25:13 --> Config Class Initialized
INFO - 2025-05-12 12:25:13 --> Hooks Class Initialized
DEBUG - 2025-05-12 12:25:13 --> UTF-8 Support Enabled
INFO - 2025-05-12 12:25:13 --> Utf8 Class Initialized
INFO - 2025-05-12 12:25:13 --> URI Class Initialized
INFO - 2025-05-12 12:25:13 --> Router Class Initialized
INFO - 2025-05-12 12:25:13 --> Output Class Initialized
INFO - 2025-05-12 12:25:13 --> Security Class Initialized
DEBUG - 2025-05-12 12:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 12:25:13 --> Input Class Initialized
INFO - 2025-05-12 12:25:13 --> Language Class Initialized
INFO - 2025-05-12 12:25:13 --> Loader Class Initialized
INFO - 2025-05-12 12:25:13 --> Helper loaded: url_helper
INFO - 2025-05-12 12:25:13 --> Helper loaded: form_helper
INFO - 2025-05-12 12:25:13 --> Database Driver Class Initialized
DEBUG - 2025-05-12 12:25:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 12:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 12:25:13 --> Controller Class Initialized
INFO - 2025-05-12 12:25:13 --> Model "Workout_model" initialized
INFO - 2025-05-12 12:25:13 --> Config Class Initialized
INFO - 2025-05-12 12:25:13 --> Hooks Class Initialized
DEBUG - 2025-05-12 12:25:13 --> UTF-8 Support Enabled
INFO - 2025-05-12 12:25:13 --> Utf8 Class Initialized
INFO - 2025-05-12 12:25:13 --> URI Class Initialized
INFO - 2025-05-12 12:25:13 --> Router Class Initialized
INFO - 2025-05-12 12:25:13 --> Output Class Initialized
INFO - 2025-05-12 12:25:13 --> Security Class Initialized
DEBUG - 2025-05-12 12:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 12:25:13 --> Input Class Initialized
INFO - 2025-05-12 12:25:13 --> Language Class Initialized
INFO - 2025-05-12 12:25:13 --> Loader Class Initialized
INFO - 2025-05-12 12:25:13 --> Helper loaded: url_helper
INFO - 2025-05-12 12:25:13 --> Helper loaded: form_helper
INFO - 2025-05-12 12:25:13 --> Database Driver Class Initialized
DEBUG - 2025-05-12 12:25:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 12:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 12:25:13 --> Controller Class Initialized
INFO - 2025-05-12 12:25:13 --> Model "Workout_model" initialized
INFO - 2025-05-12 12:25:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-12 12:25:13 --> Final output sent to browser
DEBUG - 2025-05-12 12:25:13 --> Total execution time: 0.0880
INFO - 2025-05-12 12:25:16 --> Config Class Initialized
INFO - 2025-05-12 12:25:16 --> Hooks Class Initialized
DEBUG - 2025-05-12 12:25:16 --> UTF-8 Support Enabled
INFO - 2025-05-12 12:25:16 --> Utf8 Class Initialized
INFO - 2025-05-12 12:25:16 --> URI Class Initialized
INFO - 2025-05-12 12:25:16 --> Router Class Initialized
INFO - 2025-05-12 12:25:16 --> Output Class Initialized
INFO - 2025-05-12 12:25:16 --> Security Class Initialized
DEBUG - 2025-05-12 12:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 12:25:16 --> Input Class Initialized
INFO - 2025-05-12 12:25:16 --> Language Class Initialized
INFO - 2025-05-12 12:25:16 --> Loader Class Initialized
INFO - 2025-05-12 12:25:16 --> Helper loaded: url_helper
INFO - 2025-05-12 12:25:16 --> Helper loaded: form_helper
INFO - 2025-05-12 12:25:16 --> Database Driver Class Initialized
DEBUG - 2025-05-12 12:25:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 12:25:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 12:25:16 --> Controller Class Initialized
INFO - 2025-05-12 12:25:16 --> Model "Workout_model" initialized
INFO - 2025-05-12 12:25:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/start.php
INFO - 2025-05-12 12:25:16 --> Final output sent to browser
DEBUG - 2025-05-12 12:25:16 --> Total execution time: 0.0770
INFO - 2025-05-12 12:25:21 --> Config Class Initialized
INFO - 2025-05-12 12:25:21 --> Hooks Class Initialized
DEBUG - 2025-05-12 12:25:21 --> UTF-8 Support Enabled
INFO - 2025-05-12 12:25:21 --> Utf8 Class Initialized
INFO - 2025-05-12 12:25:21 --> URI Class Initialized
INFO - 2025-05-12 12:25:21 --> Router Class Initialized
INFO - 2025-05-12 12:25:21 --> Output Class Initialized
INFO - 2025-05-12 12:25:21 --> Security Class Initialized
DEBUG - 2025-05-12 12:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 12:25:21 --> Input Class Initialized
INFO - 2025-05-12 12:25:21 --> Language Class Initialized
INFO - 2025-05-12 12:25:21 --> Loader Class Initialized
INFO - 2025-05-12 12:25:21 --> Helper loaded: url_helper
INFO - 2025-05-12 12:25:21 --> Helper loaded: form_helper
INFO - 2025-05-12 12:25:21 --> Database Driver Class Initialized
DEBUG - 2025-05-12 12:25:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 12:25:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 12:25:21 --> Controller Class Initialized
INFO - 2025-05-12 12:25:21 --> Model "Workout_model" initialized
INFO - 2025-05-12 12:25:21 --> Final output sent to browser
DEBUG - 2025-05-12 12:25:21 --> Total execution time: 0.0827
INFO - 2025-05-12 12:25:21 --> Config Class Initialized
INFO - 2025-05-12 12:25:21 --> Hooks Class Initialized
DEBUG - 2025-05-12 12:25:21 --> UTF-8 Support Enabled
INFO - 2025-05-12 12:25:21 --> Utf8 Class Initialized
INFO - 2025-05-12 12:25:21 --> URI Class Initialized
INFO - 2025-05-12 12:25:21 --> Router Class Initialized
INFO - 2025-05-12 12:25:21 --> Output Class Initialized
INFO - 2025-05-12 12:25:21 --> Security Class Initialized
DEBUG - 2025-05-12 12:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 12:25:21 --> Input Class Initialized
INFO - 2025-05-12 12:25:21 --> Language Class Initialized
INFO - 2025-05-12 12:25:21 --> Loader Class Initialized
INFO - 2025-05-12 12:25:21 --> Helper loaded: url_helper
INFO - 2025-05-12 12:25:21 --> Helper loaded: form_helper
INFO - 2025-05-12 12:25:21 --> Database Driver Class Initialized
DEBUG - 2025-05-12 12:25:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 12:25:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 12:25:21 --> Controller Class Initialized
INFO - 2025-05-12 12:25:21 --> Model "Workout_model" initialized
INFO - 2025-05-12 12:25:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-12 12:25:21 --> Final output sent to browser
DEBUG - 2025-05-12 12:25:21 --> Total execution time: 0.0891
INFO - 2025-05-12 12:27:31 --> Config Class Initialized
INFO - 2025-05-12 12:27:31 --> Hooks Class Initialized
DEBUG - 2025-05-12 12:27:31 --> UTF-8 Support Enabled
INFO - 2025-05-12 12:27:31 --> Utf8 Class Initialized
INFO - 2025-05-12 12:27:31 --> URI Class Initialized
INFO - 2025-05-12 12:27:31 --> Router Class Initialized
INFO - 2025-05-12 12:27:31 --> Output Class Initialized
INFO - 2025-05-12 12:27:31 --> Security Class Initialized
DEBUG - 2025-05-12 12:27:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 12:27:31 --> Input Class Initialized
INFO - 2025-05-12 12:27:31 --> Language Class Initialized
INFO - 2025-05-12 12:27:31 --> Loader Class Initialized
INFO - 2025-05-12 12:27:31 --> Helper loaded: url_helper
INFO - 2025-05-12 12:27:31 --> Helper loaded: form_helper
INFO - 2025-05-12 12:27:31 --> Database Driver Class Initialized
DEBUG - 2025-05-12 12:27:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 12:27:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 12:27:31 --> Controller Class Initialized
INFO - 2025-05-12 12:27:31 --> Model "Workout_model" initialized
INFO - 2025-05-12 12:27:31 --> Config Class Initialized
INFO - 2025-05-12 12:27:31 --> Hooks Class Initialized
DEBUG - 2025-05-12 12:27:31 --> UTF-8 Support Enabled
INFO - 2025-05-12 12:27:31 --> Utf8 Class Initialized
INFO - 2025-05-12 12:27:31 --> URI Class Initialized
INFO - 2025-05-12 12:27:31 --> Router Class Initialized
INFO - 2025-05-12 12:27:31 --> Output Class Initialized
INFO - 2025-05-12 12:27:31 --> Security Class Initialized
DEBUG - 2025-05-12 12:27:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 12:27:31 --> Input Class Initialized
INFO - 2025-05-12 12:27:31 --> Language Class Initialized
INFO - 2025-05-12 12:27:31 --> Loader Class Initialized
INFO - 2025-05-12 12:27:31 --> Helper loaded: url_helper
INFO - 2025-05-12 12:27:31 --> Helper loaded: form_helper
INFO - 2025-05-12 12:27:31 --> Database Driver Class Initialized
DEBUG - 2025-05-12 12:27:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 12:27:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 12:27:31 --> Controller Class Initialized
INFO - 2025-05-12 12:27:31 --> Model "Workout_model" initialized
INFO - 2025-05-12 12:27:31 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-12 12:27:31 --> Final output sent to browser
DEBUG - 2025-05-12 12:27:31 --> Total execution time: 0.0888
INFO - 2025-05-12 12:27:34 --> Config Class Initialized
INFO - 2025-05-12 12:27:34 --> Hooks Class Initialized
DEBUG - 2025-05-12 12:27:34 --> UTF-8 Support Enabled
INFO - 2025-05-12 12:27:34 --> Utf8 Class Initialized
INFO - 2025-05-12 12:27:34 --> URI Class Initialized
INFO - 2025-05-12 12:27:34 --> Router Class Initialized
INFO - 2025-05-12 12:27:34 --> Output Class Initialized
INFO - 2025-05-12 12:27:34 --> Security Class Initialized
DEBUG - 2025-05-12 12:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 12:27:34 --> Input Class Initialized
INFO - 2025-05-12 12:27:34 --> Language Class Initialized
INFO - 2025-05-12 12:27:34 --> Loader Class Initialized
INFO - 2025-05-12 12:27:34 --> Helper loaded: url_helper
INFO - 2025-05-12 12:27:34 --> Helper loaded: form_helper
INFO - 2025-05-12 12:27:34 --> Database Driver Class Initialized
DEBUG - 2025-05-12 12:27:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 12:27:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 12:27:34 --> Controller Class Initialized
INFO - 2025-05-12 12:27:34 --> Model "Workout_model" initialized
INFO - 2025-05-12 12:27:34 --> Config Class Initialized
INFO - 2025-05-12 12:27:34 --> Hooks Class Initialized
DEBUG - 2025-05-12 12:27:34 --> UTF-8 Support Enabled
INFO - 2025-05-12 12:27:34 --> Utf8 Class Initialized
INFO - 2025-05-12 12:27:34 --> URI Class Initialized
INFO - 2025-05-12 12:27:34 --> Router Class Initialized
INFO - 2025-05-12 12:27:34 --> Output Class Initialized
INFO - 2025-05-12 12:27:34 --> Security Class Initialized
DEBUG - 2025-05-12 12:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 12:27:34 --> Input Class Initialized
INFO - 2025-05-12 12:27:34 --> Language Class Initialized
INFO - 2025-05-12 12:27:34 --> Loader Class Initialized
INFO - 2025-05-12 12:27:34 --> Helper loaded: url_helper
INFO - 2025-05-12 12:27:34 --> Helper loaded: form_helper
INFO - 2025-05-12 12:27:34 --> Database Driver Class Initialized
DEBUG - 2025-05-12 12:27:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 12:27:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 12:27:34 --> Controller Class Initialized
INFO - 2025-05-12 12:27:34 --> Model "Workout_model" initialized
INFO - 2025-05-12 12:27:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-12 12:27:34 --> Final output sent to browser
DEBUG - 2025-05-12 12:27:34 --> Total execution time: 0.0857
INFO - 2025-05-12 12:28:26 --> Config Class Initialized
INFO - 2025-05-12 12:28:26 --> Hooks Class Initialized
DEBUG - 2025-05-12 12:28:26 --> UTF-8 Support Enabled
INFO - 2025-05-12 12:28:26 --> Utf8 Class Initialized
INFO - 2025-05-12 12:28:26 --> URI Class Initialized
INFO - 2025-05-12 12:28:26 --> Router Class Initialized
INFO - 2025-05-12 12:28:26 --> Output Class Initialized
INFO - 2025-05-12 12:28:26 --> Security Class Initialized
DEBUG - 2025-05-12 12:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 12:28:26 --> Input Class Initialized
INFO - 2025-05-12 12:28:26 --> Language Class Initialized
INFO - 2025-05-12 12:28:26 --> Loader Class Initialized
INFO - 2025-05-12 12:28:26 --> Helper loaded: url_helper
INFO - 2025-05-12 12:28:26 --> Helper loaded: form_helper
INFO - 2025-05-12 12:28:26 --> Database Driver Class Initialized
DEBUG - 2025-05-12 12:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 12:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 12:28:26 --> Controller Class Initialized
INFO - 2025-05-12 12:28:26 --> Model "Workout_model" initialized
INFO - 2025-05-12 12:28:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-12 12:28:26 --> Final output sent to browser
DEBUG - 2025-05-12 12:28:26 --> Total execution time: 0.0802
INFO - 2025-05-12 12:28:28 --> Config Class Initialized
INFO - 2025-05-12 12:28:28 --> Hooks Class Initialized
DEBUG - 2025-05-12 12:28:28 --> UTF-8 Support Enabled
INFO - 2025-05-12 12:28:28 --> Utf8 Class Initialized
INFO - 2025-05-12 12:28:28 --> URI Class Initialized
INFO - 2025-05-12 12:28:28 --> Router Class Initialized
INFO - 2025-05-12 12:28:28 --> Output Class Initialized
INFO - 2025-05-12 12:28:28 --> Security Class Initialized
DEBUG - 2025-05-12 12:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 12:28:28 --> Input Class Initialized
INFO - 2025-05-12 12:28:28 --> Language Class Initialized
INFO - 2025-05-12 12:28:28 --> Loader Class Initialized
INFO - 2025-05-12 12:28:28 --> Helper loaded: url_helper
INFO - 2025-05-12 12:28:28 --> Helper loaded: form_helper
INFO - 2025-05-12 12:28:28 --> Database Driver Class Initialized
DEBUG - 2025-05-12 12:28:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 12:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 12:28:28 --> Controller Class Initialized
INFO - 2025-05-12 12:28:28 --> Model "Workout_model" initialized
INFO - 2025-05-12 12:28:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/add.php
INFO - 2025-05-12 12:28:28 --> Final output sent to browser
DEBUG - 2025-05-12 12:28:28 --> Total execution time: 0.0706
INFO - 2025-05-12 12:28:36 --> Config Class Initialized
INFO - 2025-05-12 12:28:36 --> Hooks Class Initialized
DEBUG - 2025-05-12 12:28:36 --> UTF-8 Support Enabled
INFO - 2025-05-12 12:28:36 --> Utf8 Class Initialized
INFO - 2025-05-12 12:28:36 --> URI Class Initialized
INFO - 2025-05-12 12:28:36 --> Router Class Initialized
INFO - 2025-05-12 12:28:36 --> Output Class Initialized
INFO - 2025-05-12 12:28:36 --> Security Class Initialized
DEBUG - 2025-05-12 12:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 12:28:36 --> Input Class Initialized
INFO - 2025-05-12 12:28:36 --> Language Class Initialized
INFO - 2025-05-12 12:28:36 --> Loader Class Initialized
INFO - 2025-05-12 12:28:36 --> Helper loaded: url_helper
INFO - 2025-05-12 12:28:36 --> Helper loaded: form_helper
INFO - 2025-05-12 12:28:36 --> Database Driver Class Initialized
DEBUG - 2025-05-12 12:28:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 12:28:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 12:28:36 --> Controller Class Initialized
INFO - 2025-05-12 12:28:36 --> Model "Workout_model" initialized
INFO - 2025-05-12 12:28:36 --> Config Class Initialized
INFO - 2025-05-12 12:28:36 --> Hooks Class Initialized
DEBUG - 2025-05-12 12:28:36 --> UTF-8 Support Enabled
INFO - 2025-05-12 12:28:36 --> Utf8 Class Initialized
INFO - 2025-05-12 12:28:36 --> URI Class Initialized
INFO - 2025-05-12 12:28:36 --> Router Class Initialized
INFO - 2025-05-12 12:28:36 --> Output Class Initialized
INFO - 2025-05-12 12:28:36 --> Security Class Initialized
DEBUG - 2025-05-12 12:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 12:28:36 --> Input Class Initialized
INFO - 2025-05-12 12:28:36 --> Language Class Initialized
INFO - 2025-05-12 12:28:36 --> Loader Class Initialized
INFO - 2025-05-12 12:28:36 --> Helper loaded: url_helper
INFO - 2025-05-12 12:28:36 --> Helper loaded: form_helper
INFO - 2025-05-12 12:28:37 --> Database Driver Class Initialized
DEBUG - 2025-05-12 12:28:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 12:28:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 12:28:37 --> Controller Class Initialized
INFO - 2025-05-12 12:28:37 --> Model "Workout_model" initialized
INFO - 2025-05-12 12:28:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-12 12:28:37 --> Final output sent to browser
DEBUG - 2025-05-12 12:28:37 --> Total execution time: 0.0853
INFO - 2025-05-12 12:28:39 --> Config Class Initialized
INFO - 2025-05-12 12:28:39 --> Hooks Class Initialized
DEBUG - 2025-05-12 12:28:39 --> UTF-8 Support Enabled
INFO - 2025-05-12 12:28:39 --> Utf8 Class Initialized
INFO - 2025-05-12 12:28:39 --> URI Class Initialized
INFO - 2025-05-12 12:28:39 --> Router Class Initialized
INFO - 2025-05-12 12:28:39 --> Output Class Initialized
INFO - 2025-05-12 12:28:39 --> Security Class Initialized
DEBUG - 2025-05-12 12:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 12:28:39 --> Input Class Initialized
INFO - 2025-05-12 12:28:39 --> Language Class Initialized
INFO - 2025-05-12 12:28:39 --> Loader Class Initialized
INFO - 2025-05-12 12:28:39 --> Helper loaded: url_helper
INFO - 2025-05-12 12:28:39 --> Helper loaded: form_helper
INFO - 2025-05-12 12:28:39 --> Database Driver Class Initialized
DEBUG - 2025-05-12 12:28:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 12:28:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 12:28:39 --> Controller Class Initialized
INFO - 2025-05-12 12:28:39 --> Model "Workout_model" initialized
INFO - 2025-05-12 12:28:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/start.php
INFO - 2025-05-12 12:28:39 --> Final output sent to browser
DEBUG - 2025-05-12 12:28:39 --> Total execution time: 0.0752
INFO - 2025-05-12 12:28:44 --> Config Class Initialized
INFO - 2025-05-12 12:28:44 --> Hooks Class Initialized
DEBUG - 2025-05-12 12:28:44 --> UTF-8 Support Enabled
INFO - 2025-05-12 12:28:44 --> Utf8 Class Initialized
INFO - 2025-05-12 12:28:44 --> URI Class Initialized
INFO - 2025-05-12 12:28:44 --> Router Class Initialized
INFO - 2025-05-12 12:28:44 --> Output Class Initialized
INFO - 2025-05-12 12:28:44 --> Security Class Initialized
DEBUG - 2025-05-12 12:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 12:28:44 --> Input Class Initialized
INFO - 2025-05-12 12:28:44 --> Language Class Initialized
INFO - 2025-05-12 12:28:44 --> Loader Class Initialized
INFO - 2025-05-12 12:28:44 --> Helper loaded: url_helper
INFO - 2025-05-12 12:28:44 --> Helper loaded: form_helper
INFO - 2025-05-12 12:28:44 --> Database Driver Class Initialized
DEBUG - 2025-05-12 12:28:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 12:28:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 12:28:44 --> Controller Class Initialized
INFO - 2025-05-12 12:28:44 --> Model "Workout_model" initialized
INFO - 2025-05-12 12:28:44 --> Final output sent to browser
DEBUG - 2025-05-12 12:28:44 --> Total execution time: 0.0991
INFO - 2025-05-12 12:28:44 --> Config Class Initialized
INFO - 2025-05-12 12:28:44 --> Hooks Class Initialized
DEBUG - 2025-05-12 12:28:44 --> UTF-8 Support Enabled
INFO - 2025-05-12 12:28:44 --> Utf8 Class Initialized
INFO - 2025-05-12 12:28:44 --> URI Class Initialized
INFO - 2025-05-12 12:28:44 --> Router Class Initialized
INFO - 2025-05-12 12:28:44 --> Output Class Initialized
INFO - 2025-05-12 12:28:44 --> Security Class Initialized
DEBUG - 2025-05-12 12:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 12:28:44 --> Input Class Initialized
INFO - 2025-05-12 12:28:44 --> Language Class Initialized
INFO - 2025-05-12 12:28:44 --> Loader Class Initialized
INFO - 2025-05-12 12:28:44 --> Helper loaded: url_helper
INFO - 2025-05-12 12:28:44 --> Helper loaded: form_helper
INFO - 2025-05-12 12:28:44 --> Database Driver Class Initialized
DEBUG - 2025-05-12 12:28:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 12:28:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 12:28:44 --> Controller Class Initialized
INFO - 2025-05-12 12:28:44 --> Model "Workout_model" initialized
INFO - 2025-05-12 12:28:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-12 12:28:44 --> Final output sent to browser
DEBUG - 2025-05-12 12:28:44 --> Total execution time: 0.0794
INFO - 2025-05-12 12:28:47 --> Config Class Initialized
INFO - 2025-05-12 12:28:47 --> Hooks Class Initialized
DEBUG - 2025-05-12 12:28:47 --> UTF-8 Support Enabled
INFO - 2025-05-12 12:28:47 --> Utf8 Class Initialized
INFO - 2025-05-12 12:28:47 --> URI Class Initialized
INFO - 2025-05-12 12:28:47 --> Router Class Initialized
INFO - 2025-05-12 12:28:47 --> Output Class Initialized
INFO - 2025-05-12 12:28:47 --> Security Class Initialized
DEBUG - 2025-05-12 12:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 12:28:47 --> Input Class Initialized
INFO - 2025-05-12 12:28:47 --> Language Class Initialized
INFO - 2025-05-12 12:28:47 --> Loader Class Initialized
INFO - 2025-05-12 12:28:47 --> Helper loaded: url_helper
INFO - 2025-05-12 12:28:47 --> Helper loaded: form_helper
INFO - 2025-05-12 12:28:47 --> Database Driver Class Initialized
DEBUG - 2025-05-12 12:28:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 12:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 12:28:47 --> Controller Class Initialized
INFO - 2025-05-12 12:28:47 --> Model "Workout_model" initialized
INFO - 2025-05-12 12:28:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/add.php
INFO - 2025-05-12 12:28:47 --> Final output sent to browser
DEBUG - 2025-05-12 12:28:47 --> Total execution time: 0.0752
INFO - 2025-05-12 12:28:59 --> Config Class Initialized
INFO - 2025-05-12 12:28:59 --> Hooks Class Initialized
DEBUG - 2025-05-12 12:28:59 --> UTF-8 Support Enabled
INFO - 2025-05-12 12:28:59 --> Utf8 Class Initialized
INFO - 2025-05-12 12:28:59 --> URI Class Initialized
INFO - 2025-05-12 12:28:59 --> Router Class Initialized
INFO - 2025-05-12 12:28:59 --> Output Class Initialized
INFO - 2025-05-12 12:28:59 --> Security Class Initialized
DEBUG - 2025-05-12 12:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 12:28:59 --> Input Class Initialized
INFO - 2025-05-12 12:28:59 --> Language Class Initialized
INFO - 2025-05-12 12:28:59 --> Loader Class Initialized
INFO - 2025-05-12 12:28:59 --> Helper loaded: url_helper
INFO - 2025-05-12 12:28:59 --> Helper loaded: form_helper
INFO - 2025-05-12 12:28:59 --> Database Driver Class Initialized
DEBUG - 2025-05-12 12:28:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 12:28:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 12:28:59 --> Controller Class Initialized
INFO - 2025-05-12 12:28:59 --> Model "Workout_model" initialized
INFO - 2025-05-12 12:29:00 --> Config Class Initialized
INFO - 2025-05-12 12:29:00 --> Hooks Class Initialized
DEBUG - 2025-05-12 12:29:00 --> UTF-8 Support Enabled
INFO - 2025-05-12 12:29:00 --> Utf8 Class Initialized
INFO - 2025-05-12 12:29:00 --> URI Class Initialized
INFO - 2025-05-12 12:29:00 --> Router Class Initialized
INFO - 2025-05-12 12:29:00 --> Output Class Initialized
INFO - 2025-05-12 12:29:00 --> Security Class Initialized
DEBUG - 2025-05-12 12:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 12:29:00 --> Input Class Initialized
INFO - 2025-05-12 12:29:00 --> Language Class Initialized
INFO - 2025-05-12 12:29:00 --> Loader Class Initialized
INFO - 2025-05-12 12:29:00 --> Helper loaded: url_helper
INFO - 2025-05-12 12:29:00 --> Helper loaded: form_helper
INFO - 2025-05-12 12:29:00 --> Database Driver Class Initialized
DEBUG - 2025-05-12 12:29:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 12:29:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 12:29:00 --> Controller Class Initialized
INFO - 2025-05-12 12:29:00 --> Model "Workout_model" initialized
INFO - 2025-05-12 12:29:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-12 12:29:00 --> Final output sent to browser
DEBUG - 2025-05-12 12:29:00 --> Total execution time: 0.0951
INFO - 2025-05-12 12:29:02 --> Config Class Initialized
INFO - 2025-05-12 12:29:02 --> Hooks Class Initialized
DEBUG - 2025-05-12 12:29:02 --> UTF-8 Support Enabled
INFO - 2025-05-12 12:29:02 --> Utf8 Class Initialized
INFO - 2025-05-12 12:29:02 --> URI Class Initialized
INFO - 2025-05-12 12:29:02 --> Router Class Initialized
INFO - 2025-05-12 12:29:02 --> Output Class Initialized
INFO - 2025-05-12 12:29:02 --> Security Class Initialized
DEBUG - 2025-05-12 12:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 12:29:02 --> Input Class Initialized
INFO - 2025-05-12 12:29:02 --> Language Class Initialized
INFO - 2025-05-12 12:29:02 --> Loader Class Initialized
INFO - 2025-05-12 12:29:02 --> Helper loaded: url_helper
INFO - 2025-05-12 12:29:02 --> Helper loaded: form_helper
INFO - 2025-05-12 12:29:02 --> Database Driver Class Initialized
DEBUG - 2025-05-12 12:29:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 12:29:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 12:29:02 --> Controller Class Initialized
INFO - 2025-05-12 12:29:02 --> Model "Workout_model" initialized
INFO - 2025-05-12 12:29:02 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/start.php
INFO - 2025-05-12 12:29:02 --> Final output sent to browser
DEBUG - 2025-05-12 12:29:02 --> Total execution time: 0.0791
INFO - 2025-05-12 12:29:07 --> Config Class Initialized
INFO - 2025-05-12 12:29:07 --> Hooks Class Initialized
DEBUG - 2025-05-12 12:29:07 --> UTF-8 Support Enabled
INFO - 2025-05-12 12:29:07 --> Utf8 Class Initialized
INFO - 2025-05-12 12:29:07 --> URI Class Initialized
INFO - 2025-05-12 12:29:07 --> Router Class Initialized
INFO - 2025-05-12 12:29:07 --> Output Class Initialized
INFO - 2025-05-12 12:29:07 --> Security Class Initialized
DEBUG - 2025-05-12 12:29:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 12:29:07 --> Input Class Initialized
INFO - 2025-05-12 12:29:07 --> Language Class Initialized
INFO - 2025-05-12 12:29:07 --> Loader Class Initialized
INFO - 2025-05-12 12:29:07 --> Helper loaded: url_helper
INFO - 2025-05-12 12:29:07 --> Helper loaded: form_helper
INFO - 2025-05-12 12:29:07 --> Database Driver Class Initialized
DEBUG - 2025-05-12 12:29:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 12:29:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 12:29:07 --> Controller Class Initialized
INFO - 2025-05-12 12:29:07 --> Model "Workout_model" initialized
INFO - 2025-05-12 12:29:07 --> Final output sent to browser
DEBUG - 2025-05-12 12:29:07 --> Total execution time: 0.1178
INFO - 2025-05-12 12:29:07 --> Config Class Initialized
INFO - 2025-05-12 12:29:07 --> Hooks Class Initialized
DEBUG - 2025-05-12 12:29:07 --> UTF-8 Support Enabled
INFO - 2025-05-12 12:29:07 --> Utf8 Class Initialized
INFO - 2025-05-12 12:29:07 --> URI Class Initialized
INFO - 2025-05-12 12:29:07 --> Router Class Initialized
INFO - 2025-05-12 12:29:07 --> Output Class Initialized
INFO - 2025-05-12 12:29:07 --> Security Class Initialized
DEBUG - 2025-05-12 12:29:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 12:29:07 --> Input Class Initialized
INFO - 2025-05-12 12:29:07 --> Language Class Initialized
INFO - 2025-05-12 12:29:07 --> Loader Class Initialized
INFO - 2025-05-12 12:29:07 --> Helper loaded: url_helper
INFO - 2025-05-12 12:29:07 --> Helper loaded: form_helper
INFO - 2025-05-12 12:29:07 --> Database Driver Class Initialized
DEBUG - 2025-05-12 12:29:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 12:29:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 12:29:07 --> Controller Class Initialized
INFO - 2025-05-12 12:29:07 --> Model "Workout_model" initialized
INFO - 2025-05-12 12:29:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-12 12:29:07 --> Final output sent to browser
DEBUG - 2025-05-12 12:29:07 --> Total execution time: 0.0778
INFO - 2025-05-12 12:29:22 --> Config Class Initialized
INFO - 2025-05-12 12:29:22 --> Hooks Class Initialized
DEBUG - 2025-05-12 12:29:22 --> UTF-8 Support Enabled
INFO - 2025-05-12 12:29:22 --> Utf8 Class Initialized
INFO - 2025-05-12 12:29:22 --> URI Class Initialized
INFO - 2025-05-12 12:29:22 --> Router Class Initialized
INFO - 2025-05-12 12:29:22 --> Output Class Initialized
INFO - 2025-05-12 12:29:22 --> Security Class Initialized
DEBUG - 2025-05-12 12:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 12:29:22 --> Input Class Initialized
INFO - 2025-05-12 12:29:22 --> Language Class Initialized
INFO - 2025-05-12 12:29:22 --> Loader Class Initialized
INFO - 2025-05-12 12:29:22 --> Helper loaded: url_helper
INFO - 2025-05-12 12:29:22 --> Helper loaded: form_helper
INFO - 2025-05-12 12:29:22 --> Database Driver Class Initialized
DEBUG - 2025-05-12 12:29:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 12:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 12:29:22 --> Controller Class Initialized
INFO - 2025-05-12 12:29:22 --> Model "Workout_model" initialized
INFO - 2025-05-12 12:29:22 --> Config Class Initialized
INFO - 2025-05-12 12:29:22 --> Hooks Class Initialized
DEBUG - 2025-05-12 12:29:22 --> UTF-8 Support Enabled
INFO - 2025-05-12 12:29:22 --> Utf8 Class Initialized
INFO - 2025-05-12 12:29:22 --> URI Class Initialized
INFO - 2025-05-12 12:29:22 --> Router Class Initialized
INFO - 2025-05-12 12:29:22 --> Output Class Initialized
INFO - 2025-05-12 12:29:22 --> Security Class Initialized
DEBUG - 2025-05-12 12:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 12:29:22 --> Input Class Initialized
INFO - 2025-05-12 12:29:22 --> Language Class Initialized
INFO - 2025-05-12 12:29:22 --> Loader Class Initialized
INFO - 2025-05-12 12:29:22 --> Helper loaded: url_helper
INFO - 2025-05-12 12:29:22 --> Helper loaded: form_helper
INFO - 2025-05-12 12:29:22 --> Database Driver Class Initialized
DEBUG - 2025-05-12 12:29:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 12:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 12:29:22 --> Controller Class Initialized
INFO - 2025-05-12 12:29:22 --> Model "Workout_model" initialized
INFO - 2025-05-12 12:29:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-12 12:29:22 --> Final output sent to browser
DEBUG - 2025-05-12 12:29:22 --> Total execution time: 0.0881
INFO - 2025-05-12 12:29:26 --> Config Class Initialized
INFO - 2025-05-12 12:29:26 --> Hooks Class Initialized
DEBUG - 2025-05-12 12:29:26 --> UTF-8 Support Enabled
INFO - 2025-05-12 12:29:26 --> Utf8 Class Initialized
INFO - 2025-05-12 12:29:26 --> URI Class Initialized
INFO - 2025-05-12 12:29:26 --> Router Class Initialized
INFO - 2025-05-12 12:29:26 --> Output Class Initialized
INFO - 2025-05-12 12:29:26 --> Security Class Initialized
DEBUG - 2025-05-12 12:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 12:29:26 --> Input Class Initialized
INFO - 2025-05-12 12:29:26 --> Language Class Initialized
INFO - 2025-05-12 12:29:26 --> Loader Class Initialized
INFO - 2025-05-12 12:29:26 --> Helper loaded: url_helper
INFO - 2025-05-12 12:29:26 --> Helper loaded: form_helper
INFO - 2025-05-12 12:29:26 --> Database Driver Class Initialized
DEBUG - 2025-05-12 12:29:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 12:29:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 12:29:26 --> Controller Class Initialized
INFO - 2025-05-12 12:29:26 --> Model "Workout_model" initialized
INFO - 2025-05-12 12:29:26 --> Config Class Initialized
INFO - 2025-05-12 12:29:26 --> Hooks Class Initialized
DEBUG - 2025-05-12 12:29:26 --> UTF-8 Support Enabled
INFO - 2025-05-12 12:29:26 --> Utf8 Class Initialized
INFO - 2025-05-12 12:29:26 --> URI Class Initialized
INFO - 2025-05-12 12:29:26 --> Router Class Initialized
INFO - 2025-05-12 12:29:26 --> Output Class Initialized
INFO - 2025-05-12 12:29:26 --> Security Class Initialized
DEBUG - 2025-05-12 12:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 12:29:26 --> Input Class Initialized
INFO - 2025-05-12 12:29:26 --> Language Class Initialized
INFO - 2025-05-12 12:29:26 --> Loader Class Initialized
INFO - 2025-05-12 12:29:26 --> Helper loaded: url_helper
INFO - 2025-05-12 12:29:26 --> Helper loaded: form_helper
INFO - 2025-05-12 12:29:26 --> Database Driver Class Initialized
DEBUG - 2025-05-12 12:29:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 12:29:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 12:29:26 --> Controller Class Initialized
INFO - 2025-05-12 12:29:26 --> Model "Workout_model" initialized
INFO - 2025-05-12 12:29:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-12 12:29:26 --> Final output sent to browser
DEBUG - 2025-05-12 12:29:26 --> Total execution time: 0.0815
INFO - 2025-05-12 12:29:53 --> Config Class Initialized
INFO - 2025-05-12 12:29:53 --> Hooks Class Initialized
DEBUG - 2025-05-12 12:29:53 --> UTF-8 Support Enabled
INFO - 2025-05-12 12:29:53 --> Utf8 Class Initialized
INFO - 2025-05-12 12:29:53 --> URI Class Initialized
INFO - 2025-05-12 12:29:53 --> Router Class Initialized
INFO - 2025-05-12 12:29:53 --> Output Class Initialized
INFO - 2025-05-12 12:29:53 --> Security Class Initialized
DEBUG - 2025-05-12 12:29:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 12:29:53 --> Input Class Initialized
INFO - 2025-05-12 12:29:53 --> Language Class Initialized
INFO - 2025-05-12 12:29:53 --> Loader Class Initialized
INFO - 2025-05-12 12:29:53 --> Helper loaded: url_helper
INFO - 2025-05-12 12:29:53 --> Helper loaded: form_helper
INFO - 2025-05-12 12:29:53 --> Database Driver Class Initialized
DEBUG - 2025-05-12 12:29:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 12:29:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 12:29:53 --> Controller Class Initialized
INFO - 2025-05-12 12:29:53 --> Model "User_model" initialized
INFO - 2025-05-12 12:29:53 --> Model "Workout_model" initialized
INFO - 2025-05-12 12:29:53 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 12:29:53 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 12:29:53 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-12 12:29:53 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 12:29:53 --> Final output sent to browser
DEBUG - 2025-05-12 12:29:53 --> Total execution time: 0.0920
INFO - 2025-05-12 12:31:31 --> Config Class Initialized
INFO - 2025-05-12 12:31:31 --> Hooks Class Initialized
DEBUG - 2025-05-12 12:31:31 --> UTF-8 Support Enabled
INFO - 2025-05-12 12:31:31 --> Utf8 Class Initialized
INFO - 2025-05-12 12:31:31 --> URI Class Initialized
INFO - 2025-05-12 12:31:31 --> Router Class Initialized
INFO - 2025-05-12 12:31:31 --> Output Class Initialized
INFO - 2025-05-12 12:31:31 --> Security Class Initialized
DEBUG - 2025-05-12 12:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 12:31:31 --> Input Class Initialized
INFO - 2025-05-12 12:31:31 --> Language Class Initialized
INFO - 2025-05-12 12:31:31 --> Loader Class Initialized
INFO - 2025-05-12 12:31:31 --> Helper loaded: url_helper
INFO - 2025-05-12 12:31:31 --> Helper loaded: form_helper
INFO - 2025-05-12 12:31:31 --> Database Driver Class Initialized
DEBUG - 2025-05-12 12:31:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 12:31:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 12:31:31 --> Controller Class Initialized
INFO - 2025-05-12 12:31:31 --> Model "User_model" initialized
INFO - 2025-05-12 12:31:31 --> Model "Workout_model" initialized
ERROR - 2025-05-12 12:31:31 --> Severity: Warning --> Undefined variable $user C:\laragon\www\Project\fitnessrecord\application\views\dashboard\layout\header.php 30
ERROR - 2025-05-12 12:31:31 --> Severity: Warning --> Attempt to read property "name" on null C:\laragon\www\Project\fitnessrecord\application\views\dashboard\layout\header.php 30
INFO - 2025-05-12 12:31:31 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 12:31:31 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 12:31:31 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-12 12:31:31 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 12:31:31 --> Final output sent to browser
DEBUG - 2025-05-12 12:31:31 --> Total execution time: 0.2430
INFO - 2025-05-12 12:32:01 --> Config Class Initialized
INFO - 2025-05-12 12:32:01 --> Hooks Class Initialized
DEBUG - 2025-05-12 12:32:01 --> UTF-8 Support Enabled
INFO - 2025-05-12 12:32:01 --> Utf8 Class Initialized
INFO - 2025-05-12 12:32:01 --> URI Class Initialized
INFO - 2025-05-12 12:32:01 --> Router Class Initialized
INFO - 2025-05-12 12:32:01 --> Output Class Initialized
INFO - 2025-05-12 12:32:01 --> Security Class Initialized
DEBUG - 2025-05-12 12:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 12:32:01 --> Input Class Initialized
INFO - 2025-05-12 12:32:01 --> Language Class Initialized
INFO - 2025-05-12 12:32:01 --> Loader Class Initialized
INFO - 2025-05-12 12:32:01 --> Helper loaded: url_helper
INFO - 2025-05-12 12:32:01 --> Helper loaded: form_helper
INFO - 2025-05-12 12:32:01 --> Database Driver Class Initialized
DEBUG - 2025-05-12 12:32:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 12:32:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 12:32:01 --> Controller Class Initialized
INFO - 2025-05-12 12:32:01 --> Model "User_model" initialized
INFO - 2025-05-12 12:32:01 --> Model "Workout_model" initialized
INFO - 2025-05-12 12:32:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 12:32:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 12:32:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-12 12:32:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 12:32:01 --> Final output sent to browser
DEBUG - 2025-05-12 12:32:01 --> Total execution time: 0.0891
INFO - 2025-05-12 12:38:13 --> Config Class Initialized
INFO - 2025-05-12 12:38:13 --> Hooks Class Initialized
DEBUG - 2025-05-12 12:38:13 --> UTF-8 Support Enabled
INFO - 2025-05-12 12:38:13 --> Utf8 Class Initialized
INFO - 2025-05-12 12:38:13 --> URI Class Initialized
INFO - 2025-05-12 12:38:13 --> Router Class Initialized
INFO - 2025-05-12 12:38:13 --> Output Class Initialized
INFO - 2025-05-12 12:38:13 --> Security Class Initialized
DEBUG - 2025-05-12 12:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 12:38:13 --> Input Class Initialized
INFO - 2025-05-12 12:38:13 --> Language Class Initialized
INFO - 2025-05-12 12:38:13 --> Loader Class Initialized
INFO - 2025-05-12 12:38:13 --> Helper loaded: url_helper
INFO - 2025-05-12 12:38:13 --> Helper loaded: form_helper
INFO - 2025-05-12 12:38:13 --> Database Driver Class Initialized
DEBUG - 2025-05-12 12:38:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 12:38:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 12:38:13 --> Controller Class Initialized
INFO - 2025-05-12 12:38:13 --> Model "User_model" initialized
INFO - 2025-05-12 12:38:13 --> Model "Workout_model" initialized
INFO - 2025-05-12 12:38:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 12:38:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 12:38:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-12 12:38:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 12:38:13 --> Final output sent to browser
DEBUG - 2025-05-12 12:38:13 --> Total execution time: 0.0858
INFO - 2025-05-12 12:38:41 --> Config Class Initialized
INFO - 2025-05-12 12:38:41 --> Hooks Class Initialized
DEBUG - 2025-05-12 12:38:41 --> UTF-8 Support Enabled
INFO - 2025-05-12 12:38:41 --> Utf8 Class Initialized
INFO - 2025-05-12 12:38:41 --> URI Class Initialized
INFO - 2025-05-12 12:38:41 --> Router Class Initialized
INFO - 2025-05-12 12:38:41 --> Output Class Initialized
INFO - 2025-05-12 12:38:41 --> Security Class Initialized
DEBUG - 2025-05-12 12:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 12:38:41 --> Input Class Initialized
INFO - 2025-05-12 12:38:41 --> Language Class Initialized
INFO - 2025-05-12 12:38:41 --> Loader Class Initialized
INFO - 2025-05-12 12:38:41 --> Helper loaded: url_helper
INFO - 2025-05-12 12:38:41 --> Helper loaded: form_helper
INFO - 2025-05-12 12:38:41 --> Database Driver Class Initialized
DEBUG - 2025-05-12 12:38:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 12:38:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 12:38:41 --> Controller Class Initialized
INFO - 2025-05-12 12:38:41 --> Model "User_model" initialized
INFO - 2025-05-12 12:38:41 --> Model "Workout_model" initialized
INFO - 2025-05-12 12:38:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 12:38:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 12:38:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-12 12:38:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 12:38:41 --> Final output sent to browser
DEBUG - 2025-05-12 12:38:41 --> Total execution time: 0.0834
INFO - 2025-05-12 12:38:48 --> Config Class Initialized
INFO - 2025-05-12 12:38:48 --> Hooks Class Initialized
DEBUG - 2025-05-12 12:38:48 --> UTF-8 Support Enabled
INFO - 2025-05-12 12:38:48 --> Utf8 Class Initialized
INFO - 2025-05-12 12:38:48 --> URI Class Initialized
INFO - 2025-05-12 12:38:48 --> Router Class Initialized
INFO - 2025-05-12 12:38:48 --> Output Class Initialized
INFO - 2025-05-12 12:38:48 --> Security Class Initialized
DEBUG - 2025-05-12 12:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 12:38:48 --> Input Class Initialized
INFO - 2025-05-12 12:38:48 --> Language Class Initialized
INFO - 2025-05-12 12:38:48 --> Loader Class Initialized
INFO - 2025-05-12 12:38:48 --> Helper loaded: url_helper
INFO - 2025-05-12 12:38:48 --> Helper loaded: form_helper
INFO - 2025-05-12 12:38:48 --> Database Driver Class Initialized
DEBUG - 2025-05-12 12:38:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 12:38:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 12:38:48 --> Controller Class Initialized
INFO - 2025-05-12 12:38:48 --> Model "Workout_model" initialized
INFO - 2025-05-12 12:38:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-12 12:38:48 --> Final output sent to browser
DEBUG - 2025-05-12 12:38:48 --> Total execution time: 0.0889
INFO - 2025-05-12 12:38:50 --> Config Class Initialized
INFO - 2025-05-12 12:38:50 --> Hooks Class Initialized
DEBUG - 2025-05-12 12:38:50 --> UTF-8 Support Enabled
INFO - 2025-05-12 12:38:50 --> Utf8 Class Initialized
INFO - 2025-05-12 12:38:50 --> URI Class Initialized
INFO - 2025-05-12 12:38:50 --> Router Class Initialized
INFO - 2025-05-12 12:38:50 --> Output Class Initialized
INFO - 2025-05-12 12:38:50 --> Security Class Initialized
DEBUG - 2025-05-12 12:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 12:38:50 --> Input Class Initialized
INFO - 2025-05-12 12:38:50 --> Language Class Initialized
INFO - 2025-05-12 12:38:50 --> Loader Class Initialized
INFO - 2025-05-12 12:38:50 --> Helper loaded: url_helper
INFO - 2025-05-12 12:38:50 --> Helper loaded: form_helper
INFO - 2025-05-12 12:38:50 --> Database Driver Class Initialized
DEBUG - 2025-05-12 12:38:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 12:38:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 12:38:50 --> Controller Class Initialized
INFO - 2025-05-12 12:38:50 --> Model "Workout_model" initialized
INFO - 2025-05-12 12:38:50 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/add.php
INFO - 2025-05-12 12:38:50 --> Final output sent to browser
DEBUG - 2025-05-12 12:38:50 --> Total execution time: 0.0718
INFO - 2025-05-12 12:38:59 --> Config Class Initialized
INFO - 2025-05-12 12:38:59 --> Hooks Class Initialized
DEBUG - 2025-05-12 12:38:59 --> UTF-8 Support Enabled
INFO - 2025-05-12 12:38:59 --> Utf8 Class Initialized
INFO - 2025-05-12 12:38:59 --> URI Class Initialized
INFO - 2025-05-12 12:38:59 --> Router Class Initialized
INFO - 2025-05-12 12:38:59 --> Output Class Initialized
INFO - 2025-05-12 12:38:59 --> Security Class Initialized
DEBUG - 2025-05-12 12:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 12:38:59 --> Input Class Initialized
INFO - 2025-05-12 12:38:59 --> Language Class Initialized
INFO - 2025-05-12 12:38:59 --> Loader Class Initialized
INFO - 2025-05-12 12:38:59 --> Helper loaded: url_helper
INFO - 2025-05-12 12:38:59 --> Helper loaded: form_helper
INFO - 2025-05-12 12:38:59 --> Database Driver Class Initialized
DEBUG - 2025-05-12 12:38:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 12:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 12:38:59 --> Controller Class Initialized
INFO - 2025-05-12 12:38:59 --> Model "Workout_model" initialized
INFO - 2025-05-12 12:38:59 --> Config Class Initialized
INFO - 2025-05-12 12:38:59 --> Hooks Class Initialized
DEBUG - 2025-05-12 12:38:59 --> UTF-8 Support Enabled
INFO - 2025-05-12 12:38:59 --> Utf8 Class Initialized
INFO - 2025-05-12 12:38:59 --> URI Class Initialized
INFO - 2025-05-12 12:38:59 --> Router Class Initialized
INFO - 2025-05-12 12:38:59 --> Output Class Initialized
INFO - 2025-05-12 12:38:59 --> Security Class Initialized
DEBUG - 2025-05-12 12:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 12:38:59 --> Input Class Initialized
INFO - 2025-05-12 12:38:59 --> Language Class Initialized
INFO - 2025-05-12 12:38:59 --> Loader Class Initialized
INFO - 2025-05-12 12:38:59 --> Helper loaded: url_helper
INFO - 2025-05-12 12:38:59 --> Helper loaded: form_helper
INFO - 2025-05-12 12:38:59 --> Database Driver Class Initialized
DEBUG - 2025-05-12 12:38:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 12:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 12:38:59 --> Controller Class Initialized
INFO - 2025-05-12 12:38:59 --> Model "Workout_model" initialized
INFO - 2025-05-12 12:38:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-12 12:38:59 --> Final output sent to browser
DEBUG - 2025-05-12 12:38:59 --> Total execution time: 0.0731
INFO - 2025-05-12 12:39:02 --> Config Class Initialized
INFO - 2025-05-12 12:39:02 --> Hooks Class Initialized
DEBUG - 2025-05-12 12:39:02 --> UTF-8 Support Enabled
INFO - 2025-05-12 12:39:02 --> Utf8 Class Initialized
INFO - 2025-05-12 12:39:02 --> URI Class Initialized
INFO - 2025-05-12 12:39:02 --> Router Class Initialized
INFO - 2025-05-12 12:39:02 --> Output Class Initialized
INFO - 2025-05-12 12:39:02 --> Security Class Initialized
DEBUG - 2025-05-12 12:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 12:39:02 --> Input Class Initialized
INFO - 2025-05-12 12:39:02 --> Language Class Initialized
INFO - 2025-05-12 12:39:02 --> Loader Class Initialized
INFO - 2025-05-12 12:39:02 --> Helper loaded: url_helper
INFO - 2025-05-12 12:39:02 --> Helper loaded: form_helper
INFO - 2025-05-12 12:39:02 --> Database Driver Class Initialized
DEBUG - 2025-05-12 12:39:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 12:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 12:39:02 --> Controller Class Initialized
INFO - 2025-05-12 12:39:02 --> Model "Workout_model" initialized
INFO - 2025-05-12 12:39:02 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/add.php
INFO - 2025-05-12 12:39:02 --> Final output sent to browser
DEBUG - 2025-05-12 12:39:02 --> Total execution time: 0.0755
INFO - 2025-05-12 12:39:15 --> Config Class Initialized
INFO - 2025-05-12 12:39:15 --> Hooks Class Initialized
DEBUG - 2025-05-12 12:39:15 --> UTF-8 Support Enabled
INFO - 2025-05-12 12:39:15 --> Utf8 Class Initialized
INFO - 2025-05-12 12:39:15 --> URI Class Initialized
INFO - 2025-05-12 12:39:15 --> Router Class Initialized
INFO - 2025-05-12 12:39:15 --> Output Class Initialized
INFO - 2025-05-12 12:39:15 --> Security Class Initialized
DEBUG - 2025-05-12 12:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 12:39:15 --> Input Class Initialized
INFO - 2025-05-12 12:39:15 --> Language Class Initialized
INFO - 2025-05-12 12:39:15 --> Loader Class Initialized
INFO - 2025-05-12 12:39:15 --> Helper loaded: url_helper
INFO - 2025-05-12 12:39:15 --> Helper loaded: form_helper
INFO - 2025-05-12 12:39:15 --> Database Driver Class Initialized
DEBUG - 2025-05-12 12:39:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 12:39:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 12:39:15 --> Controller Class Initialized
INFO - 2025-05-12 12:39:15 --> Model "Workout_model" initialized
INFO - 2025-05-12 12:39:15 --> Config Class Initialized
INFO - 2025-05-12 12:39:15 --> Hooks Class Initialized
DEBUG - 2025-05-12 12:39:15 --> UTF-8 Support Enabled
INFO - 2025-05-12 12:39:15 --> Utf8 Class Initialized
INFO - 2025-05-12 12:39:15 --> URI Class Initialized
INFO - 2025-05-12 12:39:15 --> Router Class Initialized
INFO - 2025-05-12 12:39:15 --> Output Class Initialized
INFO - 2025-05-12 12:39:15 --> Security Class Initialized
DEBUG - 2025-05-12 12:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 12:39:15 --> Input Class Initialized
INFO - 2025-05-12 12:39:15 --> Language Class Initialized
INFO - 2025-05-12 12:39:15 --> Loader Class Initialized
INFO - 2025-05-12 12:39:15 --> Helper loaded: url_helper
INFO - 2025-05-12 12:39:15 --> Helper loaded: form_helper
INFO - 2025-05-12 12:39:15 --> Database Driver Class Initialized
DEBUG - 2025-05-12 12:39:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 12:39:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 12:39:15 --> Controller Class Initialized
INFO - 2025-05-12 12:39:15 --> Model "Workout_model" initialized
INFO - 2025-05-12 12:39:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-12 12:39:15 --> Final output sent to browser
DEBUG - 2025-05-12 12:39:15 --> Total execution time: 0.0843
INFO - 2025-05-12 12:39:18 --> Config Class Initialized
INFO - 2025-05-12 12:39:18 --> Hooks Class Initialized
DEBUG - 2025-05-12 12:39:18 --> UTF-8 Support Enabled
INFO - 2025-05-12 12:39:18 --> Utf8 Class Initialized
INFO - 2025-05-12 12:39:18 --> URI Class Initialized
INFO - 2025-05-12 12:39:18 --> Router Class Initialized
INFO - 2025-05-12 12:39:18 --> Output Class Initialized
INFO - 2025-05-12 12:39:18 --> Security Class Initialized
DEBUG - 2025-05-12 12:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 12:39:18 --> Input Class Initialized
INFO - 2025-05-12 12:39:18 --> Language Class Initialized
INFO - 2025-05-12 12:39:18 --> Loader Class Initialized
INFO - 2025-05-12 12:39:18 --> Helper loaded: url_helper
INFO - 2025-05-12 12:39:18 --> Helper loaded: form_helper
INFO - 2025-05-12 12:39:18 --> Database Driver Class Initialized
DEBUG - 2025-05-12 12:39:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 12:39:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 12:39:18 --> Controller Class Initialized
INFO - 2025-05-12 12:39:18 --> Model "Workout_model" initialized
INFO - 2025-05-12 12:39:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/start.php
INFO - 2025-05-12 12:39:18 --> Final output sent to browser
DEBUG - 2025-05-12 12:39:18 --> Total execution time: 0.0716
INFO - 2025-05-12 12:39:21 --> Config Class Initialized
INFO - 2025-05-12 12:39:21 --> Hooks Class Initialized
DEBUG - 2025-05-12 12:39:21 --> UTF-8 Support Enabled
INFO - 2025-05-12 12:39:21 --> Utf8 Class Initialized
INFO - 2025-05-12 12:39:21 --> URI Class Initialized
INFO - 2025-05-12 12:39:21 --> Router Class Initialized
INFO - 2025-05-12 12:39:21 --> Output Class Initialized
INFO - 2025-05-12 12:39:21 --> Security Class Initialized
DEBUG - 2025-05-12 12:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 12:39:21 --> Input Class Initialized
INFO - 2025-05-12 12:39:21 --> Language Class Initialized
INFO - 2025-05-12 12:39:21 --> Loader Class Initialized
INFO - 2025-05-12 12:39:21 --> Helper loaded: url_helper
INFO - 2025-05-12 12:39:21 --> Helper loaded: form_helper
INFO - 2025-05-12 12:39:21 --> Database Driver Class Initialized
DEBUG - 2025-05-12 12:39:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 12:39:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 12:39:21 --> Controller Class Initialized
INFO - 2025-05-12 12:39:21 --> Model "Workout_model" initialized
INFO - 2025-05-12 12:39:21 --> Final output sent to browser
DEBUG - 2025-05-12 12:39:21 --> Total execution time: 0.0759
INFO - 2025-05-12 12:39:21 --> Config Class Initialized
INFO - 2025-05-12 12:39:21 --> Hooks Class Initialized
DEBUG - 2025-05-12 12:39:21 --> UTF-8 Support Enabled
INFO - 2025-05-12 12:39:21 --> Utf8 Class Initialized
INFO - 2025-05-12 12:39:21 --> URI Class Initialized
INFO - 2025-05-12 12:39:21 --> Router Class Initialized
INFO - 2025-05-12 12:39:21 --> Output Class Initialized
INFO - 2025-05-12 12:39:21 --> Security Class Initialized
DEBUG - 2025-05-12 12:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 12:39:21 --> Input Class Initialized
INFO - 2025-05-12 12:39:21 --> Language Class Initialized
INFO - 2025-05-12 12:39:21 --> Loader Class Initialized
INFO - 2025-05-12 12:39:21 --> Helper loaded: url_helper
INFO - 2025-05-12 12:39:21 --> Helper loaded: form_helper
INFO - 2025-05-12 12:39:21 --> Database Driver Class Initialized
DEBUG - 2025-05-12 12:39:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 12:39:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 12:39:21 --> Controller Class Initialized
INFO - 2025-05-12 12:39:21 --> Model "Workout_model" initialized
INFO - 2025-05-12 12:39:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-12 12:39:21 --> Final output sent to browser
DEBUG - 2025-05-12 12:39:21 --> Total execution time: 0.0735
INFO - 2025-05-12 12:39:23 --> Config Class Initialized
INFO - 2025-05-12 12:39:23 --> Hooks Class Initialized
DEBUG - 2025-05-12 12:39:23 --> UTF-8 Support Enabled
INFO - 2025-05-12 12:39:23 --> Utf8 Class Initialized
INFO - 2025-05-12 12:39:23 --> URI Class Initialized
INFO - 2025-05-12 12:39:23 --> Router Class Initialized
INFO - 2025-05-12 12:39:23 --> Output Class Initialized
INFO - 2025-05-12 12:39:23 --> Security Class Initialized
DEBUG - 2025-05-12 12:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 12:39:23 --> Input Class Initialized
INFO - 2025-05-12 12:39:23 --> Language Class Initialized
INFO - 2025-05-12 12:39:23 --> Loader Class Initialized
INFO - 2025-05-12 12:39:23 --> Helper loaded: url_helper
INFO - 2025-05-12 12:39:23 --> Helper loaded: form_helper
INFO - 2025-05-12 12:39:23 --> Database Driver Class Initialized
DEBUG - 2025-05-12 12:39:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 12:39:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 12:39:23 --> Controller Class Initialized
INFO - 2025-05-12 12:39:23 --> Model "Workout_model" initialized
INFO - 2025-05-12 12:39:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/start.php
INFO - 2025-05-12 12:39:23 --> Final output sent to browser
DEBUG - 2025-05-12 12:39:23 --> Total execution time: 0.0733
INFO - 2025-05-12 12:39:27 --> Config Class Initialized
INFO - 2025-05-12 12:39:27 --> Hooks Class Initialized
DEBUG - 2025-05-12 12:39:27 --> UTF-8 Support Enabled
INFO - 2025-05-12 12:39:27 --> Utf8 Class Initialized
INFO - 2025-05-12 12:39:27 --> URI Class Initialized
INFO - 2025-05-12 12:39:27 --> Router Class Initialized
INFO - 2025-05-12 12:39:27 --> Output Class Initialized
INFO - 2025-05-12 12:39:27 --> Security Class Initialized
DEBUG - 2025-05-12 12:39:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 12:39:27 --> Input Class Initialized
INFO - 2025-05-12 12:39:27 --> Language Class Initialized
INFO - 2025-05-12 12:39:27 --> Loader Class Initialized
INFO - 2025-05-12 12:39:27 --> Helper loaded: url_helper
INFO - 2025-05-12 12:39:27 --> Helper loaded: form_helper
INFO - 2025-05-12 12:39:27 --> Database Driver Class Initialized
DEBUG - 2025-05-12 12:39:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 12:39:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 12:39:27 --> Controller Class Initialized
INFO - 2025-05-12 12:39:27 --> Model "Workout_model" initialized
INFO - 2025-05-12 12:39:27 --> Final output sent to browser
DEBUG - 2025-05-12 12:39:27 --> Total execution time: 0.0758
INFO - 2025-05-12 12:39:27 --> Config Class Initialized
INFO - 2025-05-12 12:39:27 --> Hooks Class Initialized
DEBUG - 2025-05-12 12:39:27 --> UTF-8 Support Enabled
INFO - 2025-05-12 12:39:27 --> Utf8 Class Initialized
INFO - 2025-05-12 12:39:27 --> URI Class Initialized
INFO - 2025-05-12 12:39:27 --> Router Class Initialized
INFO - 2025-05-12 12:39:27 --> Output Class Initialized
INFO - 2025-05-12 12:39:27 --> Security Class Initialized
DEBUG - 2025-05-12 12:39:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 12:39:27 --> Input Class Initialized
INFO - 2025-05-12 12:39:27 --> Language Class Initialized
INFO - 2025-05-12 12:39:27 --> Loader Class Initialized
INFO - 2025-05-12 12:39:27 --> Helper loaded: url_helper
INFO - 2025-05-12 12:39:27 --> Helper loaded: form_helper
INFO - 2025-05-12 12:39:27 --> Database Driver Class Initialized
DEBUG - 2025-05-12 12:39:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 12:39:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 12:39:27 --> Controller Class Initialized
INFO - 2025-05-12 12:39:27 --> Model "Workout_model" initialized
INFO - 2025-05-12 12:39:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-12 12:39:27 --> Final output sent to browser
DEBUG - 2025-05-12 12:39:27 --> Total execution time: 0.0786
INFO - 2025-05-12 12:39:31 --> Config Class Initialized
INFO - 2025-05-12 12:39:31 --> Hooks Class Initialized
DEBUG - 2025-05-12 12:39:31 --> UTF-8 Support Enabled
INFO - 2025-05-12 12:39:31 --> Utf8 Class Initialized
INFO - 2025-05-12 12:39:31 --> URI Class Initialized
INFO - 2025-05-12 12:39:31 --> Router Class Initialized
INFO - 2025-05-12 12:39:31 --> Output Class Initialized
INFO - 2025-05-12 12:39:31 --> Security Class Initialized
DEBUG - 2025-05-12 12:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 12:39:31 --> Input Class Initialized
INFO - 2025-05-12 12:39:31 --> Language Class Initialized
INFO - 2025-05-12 12:39:31 --> Loader Class Initialized
INFO - 2025-05-12 12:39:31 --> Helper loaded: url_helper
INFO - 2025-05-12 12:39:32 --> Helper loaded: form_helper
INFO - 2025-05-12 12:39:32 --> Database Driver Class Initialized
DEBUG - 2025-05-12 12:39:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 12:39:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 12:39:32 --> Controller Class Initialized
INFO - 2025-05-12 12:39:32 --> Model "User_model" initialized
INFO - 2025-05-12 12:39:32 --> Model "Workout_model" initialized
INFO - 2025-05-12 12:39:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 12:39:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 12:39:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-12 12:39:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 12:39:32 --> Final output sent to browser
DEBUG - 2025-05-12 12:39:32 --> Total execution time: 0.0981
INFO - 2025-05-12 12:41:18 --> Config Class Initialized
INFO - 2025-05-12 12:41:18 --> Hooks Class Initialized
DEBUG - 2025-05-12 12:41:18 --> UTF-8 Support Enabled
INFO - 2025-05-12 12:41:18 --> Utf8 Class Initialized
INFO - 2025-05-12 12:41:18 --> URI Class Initialized
INFO - 2025-05-12 12:41:18 --> Router Class Initialized
INFO - 2025-05-12 12:41:18 --> Output Class Initialized
INFO - 2025-05-12 12:41:18 --> Security Class Initialized
DEBUG - 2025-05-12 12:41:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 12:41:18 --> Input Class Initialized
INFO - 2025-05-12 12:41:18 --> Language Class Initialized
INFO - 2025-05-12 12:41:18 --> Loader Class Initialized
INFO - 2025-05-12 12:41:18 --> Helper loaded: url_helper
INFO - 2025-05-12 12:41:18 --> Helper loaded: form_helper
INFO - 2025-05-12 12:41:18 --> Database Driver Class Initialized
DEBUG - 2025-05-12 12:41:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 12:41:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 12:41:18 --> Controller Class Initialized
INFO - 2025-05-12 12:41:18 --> Model "User_model" initialized
INFO - 2025-05-12 12:41:18 --> Model "Workout_model" initialized
INFO - 2025-05-12 12:41:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 12:41:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 12:41:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-12 12:41:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 12:41:18 --> Final output sent to browser
DEBUG - 2025-05-12 12:41:18 --> Total execution time: 0.0979
INFO - 2025-05-12 12:48:36 --> Config Class Initialized
INFO - 2025-05-12 12:48:36 --> Hooks Class Initialized
DEBUG - 2025-05-12 12:48:36 --> UTF-8 Support Enabled
INFO - 2025-05-12 12:48:36 --> Utf8 Class Initialized
INFO - 2025-05-12 12:48:36 --> URI Class Initialized
INFO - 2025-05-12 12:48:36 --> Router Class Initialized
INFO - 2025-05-12 12:48:36 --> Output Class Initialized
INFO - 2025-05-12 12:48:36 --> Security Class Initialized
DEBUG - 2025-05-12 12:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 12:48:36 --> Input Class Initialized
INFO - 2025-05-12 12:48:36 --> Language Class Initialized
INFO - 2025-05-12 12:48:36 --> Loader Class Initialized
INFO - 2025-05-12 12:48:36 --> Helper loaded: url_helper
INFO - 2025-05-12 12:48:36 --> Helper loaded: form_helper
INFO - 2025-05-12 12:48:36 --> Database Driver Class Initialized
DEBUG - 2025-05-12 12:48:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 12:48:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 12:48:36 --> Controller Class Initialized
INFO - 2025-05-12 12:48:36 --> Model "User_model" initialized
INFO - 2025-05-12 12:48:36 --> Model "Workout_model" initialized
INFO - 2025-05-12 12:48:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 12:48:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 12:48:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-12 12:48:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 12:48:36 --> Final output sent to browser
DEBUG - 2025-05-12 12:48:36 --> Total execution time: 0.1307
INFO - 2025-05-12 12:49:27 --> Config Class Initialized
INFO - 2025-05-12 12:49:27 --> Hooks Class Initialized
DEBUG - 2025-05-12 12:49:27 --> UTF-8 Support Enabled
INFO - 2025-05-12 12:49:27 --> Utf8 Class Initialized
INFO - 2025-05-12 12:49:27 --> URI Class Initialized
INFO - 2025-05-12 12:49:27 --> Router Class Initialized
INFO - 2025-05-12 12:49:27 --> Output Class Initialized
INFO - 2025-05-12 12:49:27 --> Security Class Initialized
DEBUG - 2025-05-12 12:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 12:49:27 --> Input Class Initialized
INFO - 2025-05-12 12:49:27 --> Language Class Initialized
INFO - 2025-05-12 12:49:27 --> Loader Class Initialized
INFO - 2025-05-12 12:49:27 --> Helper loaded: url_helper
INFO - 2025-05-12 12:49:27 --> Helper loaded: form_helper
INFO - 2025-05-12 12:49:27 --> Database Driver Class Initialized
DEBUG - 2025-05-12 12:49:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 12:49:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 12:49:27 --> Controller Class Initialized
INFO - 2025-05-12 12:49:27 --> Model "User_model" initialized
INFO - 2025-05-12 12:49:27 --> Model "Workout_model" initialized
INFO - 2025-05-12 12:49:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 12:49:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 12:49:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-12 12:49:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 12:49:27 --> Final output sent to browser
DEBUG - 2025-05-12 12:49:27 --> Total execution time: 0.0985
INFO - 2025-05-12 12:50:36 --> Config Class Initialized
INFO - 2025-05-12 12:50:36 --> Hooks Class Initialized
DEBUG - 2025-05-12 12:50:36 --> UTF-8 Support Enabled
INFO - 2025-05-12 12:50:36 --> Utf8 Class Initialized
INFO - 2025-05-12 12:50:36 --> URI Class Initialized
INFO - 2025-05-12 12:50:36 --> Router Class Initialized
INFO - 2025-05-12 12:50:36 --> Output Class Initialized
INFO - 2025-05-12 12:50:36 --> Security Class Initialized
DEBUG - 2025-05-12 12:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 12:50:36 --> Input Class Initialized
INFO - 2025-05-12 12:50:36 --> Language Class Initialized
INFO - 2025-05-12 12:50:36 --> Loader Class Initialized
INFO - 2025-05-12 12:50:36 --> Helper loaded: url_helper
INFO - 2025-05-12 12:50:36 --> Helper loaded: form_helper
INFO - 2025-05-12 12:50:36 --> Database Driver Class Initialized
DEBUG - 2025-05-12 12:50:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 12:50:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 12:50:36 --> Controller Class Initialized
INFO - 2025-05-12 12:50:36 --> Model "User_model" initialized
INFO - 2025-05-12 12:50:36 --> Model "Workout_model" initialized
INFO - 2025-05-12 12:50:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 12:50:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 12:50:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-12 12:50:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 12:50:36 --> Final output sent to browser
DEBUG - 2025-05-12 12:50:36 --> Total execution time: 0.1025
INFO - 2025-05-12 12:58:56 --> Config Class Initialized
INFO - 2025-05-12 12:58:56 --> Hooks Class Initialized
DEBUG - 2025-05-12 12:58:56 --> UTF-8 Support Enabled
INFO - 2025-05-12 12:58:56 --> Utf8 Class Initialized
INFO - 2025-05-12 12:58:56 --> URI Class Initialized
INFO - 2025-05-12 12:58:56 --> Router Class Initialized
INFO - 2025-05-12 12:58:56 --> Output Class Initialized
INFO - 2025-05-12 12:58:56 --> Security Class Initialized
DEBUG - 2025-05-12 12:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 12:58:56 --> Input Class Initialized
INFO - 2025-05-12 12:58:56 --> Language Class Initialized
INFO - 2025-05-12 12:58:56 --> Loader Class Initialized
INFO - 2025-05-12 12:58:56 --> Helper loaded: url_helper
INFO - 2025-05-12 12:58:56 --> Helper loaded: form_helper
INFO - 2025-05-12 12:58:56 --> Database Driver Class Initialized
DEBUG - 2025-05-12 12:58:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 12:58:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 12:58:56 --> Controller Class Initialized
INFO - 2025-05-12 12:58:56 --> Model "User_model" initialized
INFO - 2025-05-12 12:58:56 --> Model "Workout_model" initialized
INFO - 2025-05-12 12:58:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 12:58:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 12:58:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-12 12:58:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 12:58:56 --> Final output sent to browser
DEBUG - 2025-05-12 12:58:56 --> Total execution time: 0.1033
INFO - 2025-05-12 12:59:06 --> Config Class Initialized
INFO - 2025-05-12 12:59:06 --> Hooks Class Initialized
DEBUG - 2025-05-12 12:59:06 --> UTF-8 Support Enabled
INFO - 2025-05-12 12:59:06 --> Utf8 Class Initialized
INFO - 2025-05-12 12:59:06 --> URI Class Initialized
INFO - 2025-05-12 12:59:06 --> Router Class Initialized
INFO - 2025-05-12 12:59:06 --> Output Class Initialized
INFO - 2025-05-12 12:59:06 --> Security Class Initialized
DEBUG - 2025-05-12 12:59:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 12:59:06 --> Input Class Initialized
INFO - 2025-05-12 12:59:06 --> Language Class Initialized
INFO - 2025-05-12 12:59:06 --> Loader Class Initialized
INFO - 2025-05-12 12:59:06 --> Helper loaded: url_helper
INFO - 2025-05-12 12:59:06 --> Helper loaded: form_helper
INFO - 2025-05-12 12:59:06 --> Database Driver Class Initialized
DEBUG - 2025-05-12 12:59:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 12:59:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 12:59:06 --> Controller Class Initialized
INFO - 2025-05-12 12:59:06 --> Model "User_model" initialized
INFO - 2025-05-12 12:59:06 --> Model "Workout_model" initialized
INFO - 2025-05-12 12:59:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 12:59:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 12:59:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-12 12:59:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 12:59:06 --> Final output sent to browser
DEBUG - 2025-05-12 12:59:06 --> Total execution time: 0.1406
INFO - 2025-05-12 12:59:46 --> Config Class Initialized
INFO - 2025-05-12 12:59:46 --> Hooks Class Initialized
DEBUG - 2025-05-12 12:59:46 --> UTF-8 Support Enabled
INFO - 2025-05-12 12:59:46 --> Utf8 Class Initialized
INFO - 2025-05-12 12:59:46 --> URI Class Initialized
INFO - 2025-05-12 12:59:46 --> Router Class Initialized
INFO - 2025-05-12 12:59:46 --> Output Class Initialized
INFO - 2025-05-12 12:59:46 --> Security Class Initialized
DEBUG - 2025-05-12 12:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 12:59:46 --> Input Class Initialized
INFO - 2025-05-12 12:59:46 --> Language Class Initialized
INFO - 2025-05-12 12:59:46 --> Loader Class Initialized
INFO - 2025-05-12 12:59:46 --> Helper loaded: url_helper
INFO - 2025-05-12 12:59:46 --> Helper loaded: form_helper
INFO - 2025-05-12 12:59:46 --> Database Driver Class Initialized
DEBUG - 2025-05-12 12:59:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 12:59:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 12:59:46 --> Controller Class Initialized
INFO - 2025-05-12 12:59:46 --> Model "User_model" initialized
INFO - 2025-05-12 12:59:46 --> Model "Workout_model" initialized
INFO - 2025-05-12 12:59:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 12:59:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 12:59:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-12 12:59:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 12:59:46 --> Final output sent to browser
DEBUG - 2025-05-12 12:59:46 --> Total execution time: 0.1075
INFO - 2025-05-12 13:03:18 --> Config Class Initialized
INFO - 2025-05-12 13:03:18 --> Hooks Class Initialized
DEBUG - 2025-05-12 13:03:18 --> UTF-8 Support Enabled
INFO - 2025-05-12 13:03:18 --> Utf8 Class Initialized
INFO - 2025-05-12 13:03:18 --> URI Class Initialized
INFO - 2025-05-12 13:03:18 --> Router Class Initialized
INFO - 2025-05-12 13:03:18 --> Output Class Initialized
INFO - 2025-05-12 13:03:18 --> Security Class Initialized
DEBUG - 2025-05-12 13:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 13:03:18 --> Input Class Initialized
INFO - 2025-05-12 13:03:18 --> Language Class Initialized
INFO - 2025-05-12 13:03:18 --> Loader Class Initialized
INFO - 2025-05-12 13:03:18 --> Helper loaded: url_helper
INFO - 2025-05-12 13:03:18 --> Helper loaded: form_helper
INFO - 2025-05-12 13:03:18 --> Database Driver Class Initialized
DEBUG - 2025-05-12 13:03:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 13:03:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 13:03:18 --> Controller Class Initialized
INFO - 2025-05-12 13:03:18 --> Model "User_model" initialized
INFO - 2025-05-12 13:03:18 --> Model "Workout_model" initialized
INFO - 2025-05-12 13:03:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 13:03:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 13:03:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-12 13:03:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 13:03:18 --> Final output sent to browser
DEBUG - 2025-05-12 13:03:18 --> Total execution time: 0.0887
INFO - 2025-05-12 13:03:37 --> Config Class Initialized
INFO - 2025-05-12 13:03:37 --> Hooks Class Initialized
DEBUG - 2025-05-12 13:03:37 --> UTF-8 Support Enabled
INFO - 2025-05-12 13:03:37 --> Utf8 Class Initialized
INFO - 2025-05-12 13:03:37 --> URI Class Initialized
INFO - 2025-05-12 13:03:37 --> Router Class Initialized
INFO - 2025-05-12 13:03:37 --> Output Class Initialized
INFO - 2025-05-12 13:03:37 --> Security Class Initialized
DEBUG - 2025-05-12 13:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 13:03:37 --> Input Class Initialized
INFO - 2025-05-12 13:03:37 --> Language Class Initialized
INFO - 2025-05-12 13:03:37 --> Loader Class Initialized
INFO - 2025-05-12 13:03:37 --> Helper loaded: url_helper
INFO - 2025-05-12 13:03:37 --> Helper loaded: form_helper
INFO - 2025-05-12 13:03:37 --> Database Driver Class Initialized
DEBUG - 2025-05-12 13:03:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 13:03:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 13:03:37 --> Controller Class Initialized
INFO - 2025-05-12 13:03:37 --> Model "User_model" initialized
INFO - 2025-05-12 13:03:37 --> Model "Workout_model" initialized
INFO - 2025-05-12 13:03:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 13:03:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 13:03:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-12 13:03:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 13:03:37 --> Final output sent to browser
DEBUG - 2025-05-12 13:03:37 --> Total execution time: 0.1190
INFO - 2025-05-12 13:03:52 --> Config Class Initialized
INFO - 2025-05-12 13:03:52 --> Hooks Class Initialized
DEBUG - 2025-05-12 13:03:52 --> UTF-8 Support Enabled
INFO - 2025-05-12 13:03:52 --> Utf8 Class Initialized
INFO - 2025-05-12 13:03:52 --> URI Class Initialized
INFO - 2025-05-12 13:03:52 --> Router Class Initialized
INFO - 2025-05-12 13:03:52 --> Output Class Initialized
INFO - 2025-05-12 13:03:52 --> Security Class Initialized
DEBUG - 2025-05-12 13:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 13:03:52 --> Input Class Initialized
INFO - 2025-05-12 13:03:52 --> Language Class Initialized
INFO - 2025-05-12 13:03:52 --> Loader Class Initialized
INFO - 2025-05-12 13:03:52 --> Helper loaded: url_helper
INFO - 2025-05-12 13:03:52 --> Helper loaded: form_helper
INFO - 2025-05-12 13:03:52 --> Database Driver Class Initialized
DEBUG - 2025-05-12 13:03:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 13:03:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 13:03:52 --> Controller Class Initialized
INFO - 2025-05-12 13:03:52 --> Model "User_model" initialized
INFO - 2025-05-12 13:03:52 --> Model "Workout_model" initialized
INFO - 2025-05-12 13:03:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 13:03:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 13:03:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-12 13:03:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 13:03:52 --> Final output sent to browser
DEBUG - 2025-05-12 13:03:52 --> Total execution time: 0.1331
INFO - 2025-05-12 13:07:13 --> Config Class Initialized
INFO - 2025-05-12 13:07:13 --> Hooks Class Initialized
DEBUG - 2025-05-12 13:07:13 --> UTF-8 Support Enabled
INFO - 2025-05-12 13:07:13 --> Utf8 Class Initialized
INFO - 2025-05-12 13:07:13 --> URI Class Initialized
INFO - 2025-05-12 13:07:13 --> Router Class Initialized
INFO - 2025-05-12 13:07:13 --> Output Class Initialized
INFO - 2025-05-12 13:07:13 --> Security Class Initialized
DEBUG - 2025-05-12 13:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 13:07:13 --> Input Class Initialized
INFO - 2025-05-12 13:07:13 --> Language Class Initialized
INFO - 2025-05-12 13:07:13 --> Loader Class Initialized
INFO - 2025-05-12 13:07:13 --> Helper loaded: url_helper
INFO - 2025-05-12 13:07:13 --> Helper loaded: form_helper
INFO - 2025-05-12 13:07:13 --> Database Driver Class Initialized
DEBUG - 2025-05-12 13:07:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 13:07:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 13:07:13 --> Controller Class Initialized
INFO - 2025-05-12 13:07:13 --> Model "User_model" initialized
INFO - 2025-05-12 13:07:13 --> Model "Workout_model" initialized
INFO - 2025-05-12 13:07:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 13:07:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 13:07:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-12 13:07:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 13:07:13 --> Final output sent to browser
DEBUG - 2025-05-12 13:07:13 --> Total execution time: 0.0992
INFO - 2025-05-12 13:25:15 --> Config Class Initialized
INFO - 2025-05-12 13:25:15 --> Hooks Class Initialized
DEBUG - 2025-05-12 13:25:15 --> UTF-8 Support Enabled
INFO - 2025-05-12 13:25:15 --> Utf8 Class Initialized
INFO - 2025-05-12 13:25:15 --> URI Class Initialized
INFO - 2025-05-12 13:25:15 --> Router Class Initialized
INFO - 2025-05-12 13:25:15 --> Output Class Initialized
INFO - 2025-05-12 13:25:15 --> Security Class Initialized
DEBUG - 2025-05-12 13:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 13:25:15 --> Input Class Initialized
INFO - 2025-05-12 13:25:15 --> Language Class Initialized
INFO - 2025-05-12 13:25:15 --> Loader Class Initialized
INFO - 2025-05-12 13:25:15 --> Helper loaded: url_helper
INFO - 2025-05-12 13:25:15 --> Helper loaded: form_helper
INFO - 2025-05-12 13:25:15 --> Database Driver Class Initialized
DEBUG - 2025-05-12 13:25:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 13:25:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 13:25:15 --> Controller Class Initialized
INFO - 2025-05-12 13:25:15 --> Model "User_model" initialized
INFO - 2025-05-12 13:25:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\account/profile.php
INFO - 2025-05-12 13:25:15 --> Final output sent to browser
DEBUG - 2025-05-12 13:25:15 --> Total execution time: 0.1922
INFO - 2025-05-12 13:40:31 --> Config Class Initialized
INFO - 2025-05-12 13:40:31 --> Hooks Class Initialized
DEBUG - 2025-05-12 13:40:31 --> UTF-8 Support Enabled
INFO - 2025-05-12 13:40:31 --> Utf8 Class Initialized
INFO - 2025-05-12 13:40:31 --> URI Class Initialized
INFO - 2025-05-12 13:40:31 --> Router Class Initialized
INFO - 2025-05-12 13:40:31 --> Output Class Initialized
INFO - 2025-05-12 13:40:31 --> Security Class Initialized
DEBUG - 2025-05-12 13:40:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 13:40:31 --> Input Class Initialized
INFO - 2025-05-12 13:40:31 --> Language Class Initialized
INFO - 2025-05-12 13:40:31 --> Loader Class Initialized
INFO - 2025-05-12 13:40:31 --> Helper loaded: url_helper
INFO - 2025-05-12 13:40:31 --> Helper loaded: form_helper
INFO - 2025-05-12 13:40:31 --> Database Driver Class Initialized
DEBUG - 2025-05-12 13:40:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 13:40:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 13:40:31 --> Controller Class Initialized
INFO - 2025-05-12 13:40:31 --> Model "User_model" initialized
INFO - 2025-05-12 13:40:31 --> Model "Workout_model" initialized
INFO - 2025-05-12 13:40:31 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 13:40:31 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 13:40:31 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-12 13:40:31 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 13:40:31 --> Final output sent to browser
DEBUG - 2025-05-12 13:40:31 --> Total execution time: 0.1181
INFO - 2025-05-12 13:42:13 --> Config Class Initialized
INFO - 2025-05-12 13:42:13 --> Hooks Class Initialized
DEBUG - 2025-05-12 13:42:13 --> UTF-8 Support Enabled
INFO - 2025-05-12 13:42:13 --> Utf8 Class Initialized
INFO - 2025-05-12 13:42:13 --> URI Class Initialized
INFO - 2025-05-12 13:42:13 --> Router Class Initialized
INFO - 2025-05-12 13:42:13 --> Output Class Initialized
INFO - 2025-05-12 13:42:13 --> Security Class Initialized
DEBUG - 2025-05-12 13:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 13:42:13 --> Input Class Initialized
INFO - 2025-05-12 13:42:13 --> Language Class Initialized
INFO - 2025-05-12 13:42:13 --> Loader Class Initialized
INFO - 2025-05-12 13:42:13 --> Helper loaded: url_helper
INFO - 2025-05-12 13:42:13 --> Helper loaded: form_helper
INFO - 2025-05-12 13:42:13 --> Database Driver Class Initialized
DEBUG - 2025-05-12 13:42:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 13:42:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 13:42:13 --> Controller Class Initialized
INFO - 2025-05-12 13:42:13 --> Model "User_model" initialized
INFO - 2025-05-12 13:42:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/profile.php
INFO - 2025-05-12 13:42:13 --> Final output sent to browser
DEBUG - 2025-05-12 13:42:13 --> Total execution time: 0.1067
INFO - 2025-05-12 13:43:24 --> Config Class Initialized
INFO - 2025-05-12 13:43:24 --> Hooks Class Initialized
DEBUG - 2025-05-12 13:43:24 --> UTF-8 Support Enabled
INFO - 2025-05-12 13:43:24 --> Utf8 Class Initialized
INFO - 2025-05-12 13:43:24 --> URI Class Initialized
INFO - 2025-05-12 13:43:24 --> Router Class Initialized
INFO - 2025-05-12 13:43:24 --> Output Class Initialized
INFO - 2025-05-12 13:43:24 --> Security Class Initialized
DEBUG - 2025-05-12 13:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 13:43:24 --> Input Class Initialized
INFO - 2025-05-12 13:43:24 --> Language Class Initialized
INFO - 2025-05-12 13:43:24 --> Loader Class Initialized
INFO - 2025-05-12 13:43:24 --> Helper loaded: url_helper
INFO - 2025-05-12 13:43:24 --> Helper loaded: form_helper
INFO - 2025-05-12 13:43:24 --> Database Driver Class Initialized
DEBUG - 2025-05-12 13:43:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 13:43:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 13:43:24 --> Controller Class Initialized
INFO - 2025-05-12 13:43:24 --> Model "User_model" initialized
INFO - 2025-05-12 13:43:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 13:43:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 13:43:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/profile.php
INFO - 2025-05-12 13:43:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 13:43:24 --> Final output sent to browser
DEBUG - 2025-05-12 13:43:24 --> Total execution time: 0.0957
INFO - 2025-05-12 13:43:32 --> Config Class Initialized
INFO - 2025-05-12 13:43:32 --> Hooks Class Initialized
DEBUG - 2025-05-12 13:43:32 --> UTF-8 Support Enabled
INFO - 2025-05-12 13:43:32 --> Utf8 Class Initialized
INFO - 2025-05-12 13:43:32 --> URI Class Initialized
INFO - 2025-05-12 13:43:32 --> Router Class Initialized
INFO - 2025-05-12 13:43:32 --> Output Class Initialized
INFO - 2025-05-12 13:43:32 --> Security Class Initialized
DEBUG - 2025-05-12 13:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 13:43:32 --> Input Class Initialized
INFO - 2025-05-12 13:43:32 --> Language Class Initialized
INFO - 2025-05-12 13:43:32 --> Loader Class Initialized
INFO - 2025-05-12 13:43:32 --> Helper loaded: url_helper
INFO - 2025-05-12 13:43:32 --> Helper loaded: form_helper
INFO - 2025-05-12 13:43:32 --> Database Driver Class Initialized
DEBUG - 2025-05-12 13:43:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 13:43:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 13:43:32 --> Controller Class Initialized
INFO - 2025-05-12 13:43:32 --> Model "User_model" initialized
INFO - 2025-05-12 13:43:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 13:43:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 13:43:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/profile.php
INFO - 2025-05-12 13:43:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 13:43:32 --> Final output sent to browser
DEBUG - 2025-05-12 13:43:32 --> Total execution time: 0.0996
INFO - 2025-05-12 13:43:54 --> Config Class Initialized
INFO - 2025-05-12 13:43:54 --> Hooks Class Initialized
DEBUG - 2025-05-12 13:43:54 --> UTF-8 Support Enabled
INFO - 2025-05-12 13:43:54 --> Utf8 Class Initialized
INFO - 2025-05-12 13:43:54 --> URI Class Initialized
INFO - 2025-05-12 13:43:54 --> Router Class Initialized
INFO - 2025-05-12 13:43:54 --> Output Class Initialized
INFO - 2025-05-12 13:43:54 --> Security Class Initialized
DEBUG - 2025-05-12 13:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 13:43:54 --> Input Class Initialized
INFO - 2025-05-12 13:43:54 --> Language Class Initialized
INFO - 2025-05-12 13:43:54 --> Loader Class Initialized
INFO - 2025-05-12 13:43:54 --> Helper loaded: url_helper
INFO - 2025-05-12 13:43:54 --> Helper loaded: form_helper
INFO - 2025-05-12 13:43:54 --> Database Driver Class Initialized
DEBUG - 2025-05-12 13:43:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 13:43:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 13:43:54 --> Controller Class Initialized
INFO - 2025-05-12 13:43:54 --> Model "User_model" initialized
INFO - 2025-05-12 13:43:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 13:43:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 13:43:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/profile.php
INFO - 2025-05-12 13:43:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 13:43:54 --> Final output sent to browser
DEBUG - 2025-05-12 13:43:54 --> Total execution time: 0.1168
INFO - 2025-05-12 13:44:38 --> Config Class Initialized
INFO - 2025-05-12 13:44:38 --> Hooks Class Initialized
DEBUG - 2025-05-12 13:44:38 --> UTF-8 Support Enabled
INFO - 2025-05-12 13:44:38 --> Utf8 Class Initialized
INFO - 2025-05-12 13:44:38 --> URI Class Initialized
INFO - 2025-05-12 13:44:38 --> Router Class Initialized
INFO - 2025-05-12 13:44:38 --> Output Class Initialized
INFO - 2025-05-12 13:44:38 --> Security Class Initialized
DEBUG - 2025-05-12 13:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 13:44:38 --> Input Class Initialized
INFO - 2025-05-12 13:44:38 --> Language Class Initialized
INFO - 2025-05-12 13:44:38 --> Loader Class Initialized
INFO - 2025-05-12 13:44:38 --> Helper loaded: url_helper
INFO - 2025-05-12 13:44:38 --> Helper loaded: form_helper
INFO - 2025-05-12 13:44:38 --> Database Driver Class Initialized
DEBUG - 2025-05-12 13:44:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 13:44:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 13:44:38 --> Controller Class Initialized
INFO - 2025-05-12 13:44:38 --> Model "User_model" initialized
INFO - 2025-05-12 13:44:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 13:44:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 13:44:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/profile.php
INFO - 2025-05-12 13:44:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 13:44:38 --> Final output sent to browser
DEBUG - 2025-05-12 13:44:38 --> Total execution time: 0.0876
INFO - 2025-05-12 13:45:16 --> Config Class Initialized
INFO - 2025-05-12 13:45:16 --> Hooks Class Initialized
DEBUG - 2025-05-12 13:45:16 --> UTF-8 Support Enabled
INFO - 2025-05-12 13:45:16 --> Utf8 Class Initialized
INFO - 2025-05-12 13:45:16 --> URI Class Initialized
INFO - 2025-05-12 13:45:16 --> Router Class Initialized
INFO - 2025-05-12 13:45:16 --> Output Class Initialized
INFO - 2025-05-12 13:45:16 --> Security Class Initialized
DEBUG - 2025-05-12 13:45:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 13:45:16 --> Input Class Initialized
INFO - 2025-05-12 13:45:16 --> Language Class Initialized
INFO - 2025-05-12 13:45:16 --> Loader Class Initialized
INFO - 2025-05-12 13:45:16 --> Helper loaded: url_helper
INFO - 2025-05-12 13:45:16 --> Helper loaded: form_helper
INFO - 2025-05-12 13:45:16 --> Database Driver Class Initialized
DEBUG - 2025-05-12 13:45:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 13:45:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 13:45:16 --> Controller Class Initialized
INFO - 2025-05-12 13:45:16 --> Model "User_model" initialized
INFO - 2025-05-12 13:45:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 13:45:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 13:45:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/profile.php
INFO - 2025-05-12 13:45:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 13:45:17 --> Final output sent to browser
DEBUG - 2025-05-12 13:45:17 --> Total execution time: 0.0987
INFO - 2025-05-12 13:46:30 --> Config Class Initialized
INFO - 2025-05-12 13:46:30 --> Hooks Class Initialized
DEBUG - 2025-05-12 13:46:30 --> UTF-8 Support Enabled
INFO - 2025-05-12 13:46:30 --> Utf8 Class Initialized
INFO - 2025-05-12 13:46:30 --> URI Class Initialized
INFO - 2025-05-12 13:46:30 --> Router Class Initialized
INFO - 2025-05-12 13:46:30 --> Output Class Initialized
INFO - 2025-05-12 13:46:30 --> Security Class Initialized
DEBUG - 2025-05-12 13:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 13:46:30 --> Input Class Initialized
INFO - 2025-05-12 13:46:30 --> Language Class Initialized
INFO - 2025-05-12 13:46:30 --> Loader Class Initialized
INFO - 2025-05-12 13:46:30 --> Helper loaded: url_helper
INFO - 2025-05-12 13:46:30 --> Helper loaded: form_helper
INFO - 2025-05-12 13:46:30 --> Database Driver Class Initialized
DEBUG - 2025-05-12 13:46:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 13:46:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 13:46:30 --> Controller Class Initialized
INFO - 2025-05-12 13:46:30 --> Model "User_model" initialized
INFO - 2025-05-12 13:46:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 13:46:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 13:46:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/profile.php
INFO - 2025-05-12 13:46:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 13:46:30 --> Final output sent to browser
DEBUG - 2025-05-12 13:46:30 --> Total execution time: 0.1170
INFO - 2025-05-12 13:46:32 --> Config Class Initialized
INFO - 2025-05-12 13:46:32 --> Hooks Class Initialized
DEBUG - 2025-05-12 13:46:32 --> UTF-8 Support Enabled
INFO - 2025-05-12 13:46:32 --> Utf8 Class Initialized
INFO - 2025-05-12 13:46:32 --> URI Class Initialized
INFO - 2025-05-12 13:46:32 --> Router Class Initialized
INFO - 2025-05-12 13:46:32 --> Output Class Initialized
INFO - 2025-05-12 13:46:32 --> Security Class Initialized
DEBUG - 2025-05-12 13:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 13:46:32 --> Input Class Initialized
INFO - 2025-05-12 13:46:32 --> Language Class Initialized
INFO - 2025-05-12 13:46:32 --> Loader Class Initialized
INFO - 2025-05-12 13:46:32 --> Helper loaded: url_helper
INFO - 2025-05-12 13:46:32 --> Helper loaded: form_helper
INFO - 2025-05-12 13:46:32 --> Database Driver Class Initialized
DEBUG - 2025-05-12 13:46:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 13:46:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 13:46:32 --> Controller Class Initialized
INFO - 2025-05-12 13:46:32 --> Model "User_model" initialized
INFO - 2025-05-12 13:46:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 13:46:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 13:46:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/profile.php
INFO - 2025-05-12 13:46:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 13:46:32 --> Final output sent to browser
DEBUG - 2025-05-12 13:46:32 --> Total execution time: 0.0963
INFO - 2025-05-12 13:47:00 --> Config Class Initialized
INFO - 2025-05-12 13:47:00 --> Hooks Class Initialized
DEBUG - 2025-05-12 13:47:00 --> UTF-8 Support Enabled
INFO - 2025-05-12 13:47:00 --> Utf8 Class Initialized
INFO - 2025-05-12 13:47:00 --> URI Class Initialized
INFO - 2025-05-12 13:47:00 --> Router Class Initialized
INFO - 2025-05-12 13:47:00 --> Output Class Initialized
INFO - 2025-05-12 13:47:00 --> Security Class Initialized
DEBUG - 2025-05-12 13:47:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 13:47:00 --> Input Class Initialized
INFO - 2025-05-12 13:47:00 --> Language Class Initialized
INFO - 2025-05-12 13:47:00 --> Loader Class Initialized
INFO - 2025-05-12 13:47:00 --> Helper loaded: url_helper
INFO - 2025-05-12 13:47:00 --> Helper loaded: form_helper
INFO - 2025-05-12 13:47:00 --> Database Driver Class Initialized
DEBUG - 2025-05-12 13:47:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 13:47:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 13:47:00 --> Controller Class Initialized
INFO - 2025-05-12 13:47:00 --> Model "User_model" initialized
INFO - 2025-05-12 13:47:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 13:47:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 13:47:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/profile.php
INFO - 2025-05-12 13:47:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 13:47:00 --> Final output sent to browser
DEBUG - 2025-05-12 13:47:00 --> Total execution time: 0.0827
INFO - 2025-05-12 13:47:37 --> Config Class Initialized
INFO - 2025-05-12 13:47:37 --> Hooks Class Initialized
DEBUG - 2025-05-12 13:47:37 --> UTF-8 Support Enabled
INFO - 2025-05-12 13:47:37 --> Utf8 Class Initialized
INFO - 2025-05-12 13:47:37 --> URI Class Initialized
INFO - 2025-05-12 13:47:37 --> Router Class Initialized
INFO - 2025-05-12 13:47:37 --> Output Class Initialized
INFO - 2025-05-12 13:47:37 --> Security Class Initialized
DEBUG - 2025-05-12 13:47:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 13:47:37 --> Input Class Initialized
INFO - 2025-05-12 13:47:37 --> Language Class Initialized
INFO - 2025-05-12 13:47:37 --> Loader Class Initialized
INFO - 2025-05-12 13:47:37 --> Helper loaded: url_helper
INFO - 2025-05-12 13:47:37 --> Helper loaded: form_helper
INFO - 2025-05-12 13:47:38 --> Database Driver Class Initialized
DEBUG - 2025-05-12 13:47:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 13:47:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 13:47:38 --> Controller Class Initialized
INFO - 2025-05-12 13:47:38 --> Model "User_model" initialized
INFO - 2025-05-12 13:47:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 13:47:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 13:47:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/profile.php
INFO - 2025-05-12 13:47:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 13:47:38 --> Final output sent to browser
DEBUG - 2025-05-12 13:47:38 --> Total execution time: 0.0883
INFO - 2025-05-12 13:47:39 --> Config Class Initialized
INFO - 2025-05-12 13:47:39 --> Hooks Class Initialized
DEBUG - 2025-05-12 13:47:39 --> UTF-8 Support Enabled
INFO - 2025-05-12 13:47:39 --> Utf8 Class Initialized
INFO - 2025-05-12 13:47:39 --> URI Class Initialized
INFO - 2025-05-12 13:47:39 --> Router Class Initialized
INFO - 2025-05-12 13:47:39 --> Output Class Initialized
INFO - 2025-05-12 13:47:39 --> Security Class Initialized
DEBUG - 2025-05-12 13:47:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 13:47:39 --> Input Class Initialized
INFO - 2025-05-12 13:47:39 --> Language Class Initialized
INFO - 2025-05-12 13:47:39 --> Loader Class Initialized
INFO - 2025-05-12 13:47:39 --> Helper loaded: url_helper
INFO - 2025-05-12 13:47:39 --> Helper loaded: form_helper
INFO - 2025-05-12 13:47:39 --> Database Driver Class Initialized
DEBUG - 2025-05-12 13:47:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 13:47:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 13:47:39 --> Controller Class Initialized
INFO - 2025-05-12 13:47:39 --> Model "User_model" initialized
INFO - 2025-05-12 13:47:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\account/edit_profile.php
INFO - 2025-05-12 13:47:39 --> Final output sent to browser
DEBUG - 2025-05-12 13:47:39 --> Total execution time: 0.1008
INFO - 2025-05-12 13:52:37 --> Config Class Initialized
INFO - 2025-05-12 13:52:37 --> Hooks Class Initialized
DEBUG - 2025-05-12 13:52:37 --> UTF-8 Support Enabled
INFO - 2025-05-12 13:52:37 --> Utf8 Class Initialized
INFO - 2025-05-12 13:52:37 --> URI Class Initialized
INFO - 2025-05-12 13:52:37 --> Router Class Initialized
INFO - 2025-05-12 13:52:37 --> Output Class Initialized
INFO - 2025-05-12 13:52:37 --> Security Class Initialized
DEBUG - 2025-05-12 13:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 13:52:37 --> Input Class Initialized
INFO - 2025-05-12 13:52:37 --> Language Class Initialized
INFO - 2025-05-12 13:52:37 --> Loader Class Initialized
INFO - 2025-05-12 13:52:37 --> Helper loaded: url_helper
INFO - 2025-05-12 13:52:37 --> Helper loaded: form_helper
INFO - 2025-05-12 13:52:37 --> Database Driver Class Initialized
DEBUG - 2025-05-12 13:52:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 13:52:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 13:52:37 --> Controller Class Initialized
INFO - 2025-05-12 13:52:37 --> Model "User_model" initialized
INFO - 2025-05-12 13:52:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 13:52:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 13:52:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/profile.php
INFO - 2025-05-12 13:52:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 13:52:37 --> Final output sent to browser
DEBUG - 2025-05-12 13:52:37 --> Total execution time: 0.0856
INFO - 2025-05-12 13:52:39 --> Config Class Initialized
INFO - 2025-05-12 13:52:39 --> Hooks Class Initialized
DEBUG - 2025-05-12 13:52:39 --> UTF-8 Support Enabled
INFO - 2025-05-12 13:52:39 --> Utf8 Class Initialized
INFO - 2025-05-12 13:52:39 --> URI Class Initialized
INFO - 2025-05-12 13:52:39 --> Router Class Initialized
INFO - 2025-05-12 13:52:39 --> Output Class Initialized
INFO - 2025-05-12 13:52:39 --> Security Class Initialized
DEBUG - 2025-05-12 13:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 13:52:39 --> Input Class Initialized
INFO - 2025-05-12 13:52:39 --> Language Class Initialized
INFO - 2025-05-12 13:52:39 --> Loader Class Initialized
INFO - 2025-05-12 13:52:39 --> Helper loaded: url_helper
INFO - 2025-05-12 13:52:39 --> Helper loaded: form_helper
INFO - 2025-05-12 13:52:39 --> Database Driver Class Initialized
DEBUG - 2025-05-12 13:52:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 13:52:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 13:52:39 --> Controller Class Initialized
INFO - 2025-05-12 13:52:39 --> Model "User_model" initialized
INFO - 2025-05-12 13:52:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 13:52:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 13:52:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/profile.php
INFO - 2025-05-12 13:52:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 13:52:39 --> Final output sent to browser
DEBUG - 2025-05-12 13:52:39 --> Total execution time: 0.0769
INFO - 2025-05-12 13:52:40 --> Config Class Initialized
INFO - 2025-05-12 13:52:40 --> Hooks Class Initialized
DEBUG - 2025-05-12 13:52:40 --> UTF-8 Support Enabled
INFO - 2025-05-12 13:52:40 --> Utf8 Class Initialized
INFO - 2025-05-12 13:52:40 --> URI Class Initialized
INFO - 2025-05-12 13:52:40 --> Router Class Initialized
INFO - 2025-05-12 13:52:40 --> Output Class Initialized
INFO - 2025-05-12 13:52:40 --> Security Class Initialized
DEBUG - 2025-05-12 13:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 13:52:40 --> Input Class Initialized
INFO - 2025-05-12 13:52:40 --> Language Class Initialized
INFO - 2025-05-12 13:52:40 --> Loader Class Initialized
INFO - 2025-05-12 13:52:40 --> Helper loaded: url_helper
INFO - 2025-05-12 13:52:40 --> Helper loaded: form_helper
INFO - 2025-05-12 13:52:40 --> Database Driver Class Initialized
DEBUG - 2025-05-12 13:52:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 13:52:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 13:52:40 --> Controller Class Initialized
INFO - 2025-05-12 13:52:40 --> Model "User_model" initialized
INFO - 2025-05-12 13:52:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 13:52:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 13:52:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/profile.php
INFO - 2025-05-12 13:52:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 13:52:40 --> Final output sent to browser
DEBUG - 2025-05-12 13:52:40 --> Total execution time: 0.1049
INFO - 2025-05-12 13:52:43 --> Config Class Initialized
INFO - 2025-05-12 13:52:43 --> Hooks Class Initialized
DEBUG - 2025-05-12 13:52:43 --> UTF-8 Support Enabled
INFO - 2025-05-12 13:52:43 --> Utf8 Class Initialized
INFO - 2025-05-12 13:52:43 --> URI Class Initialized
INFO - 2025-05-12 13:52:43 --> Router Class Initialized
INFO - 2025-05-12 13:52:43 --> Output Class Initialized
INFO - 2025-05-12 13:52:43 --> Security Class Initialized
DEBUG - 2025-05-12 13:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 13:52:43 --> Input Class Initialized
INFO - 2025-05-12 13:52:43 --> Language Class Initialized
INFO - 2025-05-12 13:52:43 --> Loader Class Initialized
INFO - 2025-05-12 13:52:43 --> Helper loaded: url_helper
INFO - 2025-05-12 13:52:43 --> Helper loaded: form_helper
INFO - 2025-05-12 13:52:43 --> Database Driver Class Initialized
DEBUG - 2025-05-12 13:52:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 13:52:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 13:52:43 --> Controller Class Initialized
INFO - 2025-05-12 13:52:43 --> Model "User_model" initialized
INFO - 2025-05-12 13:52:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 13:52:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 13:52:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/profile.php
INFO - 2025-05-12 13:52:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 13:52:43 --> Final output sent to browser
DEBUG - 2025-05-12 13:52:43 --> Total execution time: 0.0914
INFO - 2025-05-12 13:52:57 --> Config Class Initialized
INFO - 2025-05-12 13:52:57 --> Hooks Class Initialized
DEBUG - 2025-05-12 13:52:57 --> UTF-8 Support Enabled
INFO - 2025-05-12 13:52:57 --> Utf8 Class Initialized
INFO - 2025-05-12 13:52:57 --> URI Class Initialized
INFO - 2025-05-12 13:52:57 --> Router Class Initialized
INFO - 2025-05-12 13:52:57 --> Output Class Initialized
INFO - 2025-05-12 13:52:57 --> Security Class Initialized
DEBUG - 2025-05-12 13:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 13:52:57 --> Input Class Initialized
INFO - 2025-05-12 13:52:57 --> Language Class Initialized
INFO - 2025-05-12 13:52:57 --> Loader Class Initialized
INFO - 2025-05-12 13:52:57 --> Helper loaded: url_helper
INFO - 2025-05-12 13:52:57 --> Helper loaded: form_helper
INFO - 2025-05-12 13:52:57 --> Database Driver Class Initialized
DEBUG - 2025-05-12 13:52:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 13:52:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 13:52:57 --> Controller Class Initialized
INFO - 2025-05-12 13:52:57 --> Model "User_model" initialized
INFO - 2025-05-12 13:52:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 13:52:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 13:52:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/profile.php
INFO - 2025-05-12 13:52:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 13:52:57 --> Final output sent to browser
DEBUG - 2025-05-12 13:52:57 --> Total execution time: 0.0900
INFO - 2025-05-12 13:52:59 --> Config Class Initialized
INFO - 2025-05-12 13:52:59 --> Hooks Class Initialized
DEBUG - 2025-05-12 13:52:59 --> UTF-8 Support Enabled
INFO - 2025-05-12 13:52:59 --> Utf8 Class Initialized
INFO - 2025-05-12 13:52:59 --> URI Class Initialized
INFO - 2025-05-12 13:52:59 --> Router Class Initialized
INFO - 2025-05-12 13:52:59 --> Output Class Initialized
INFO - 2025-05-12 13:52:59 --> Security Class Initialized
DEBUG - 2025-05-12 13:52:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 13:52:59 --> Input Class Initialized
INFO - 2025-05-12 13:52:59 --> Language Class Initialized
INFO - 2025-05-12 13:52:59 --> Loader Class Initialized
INFO - 2025-05-12 13:52:59 --> Helper loaded: url_helper
INFO - 2025-05-12 13:52:59 --> Helper loaded: form_helper
INFO - 2025-05-12 13:52:59 --> Database Driver Class Initialized
DEBUG - 2025-05-12 13:52:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 13:52:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 13:52:59 --> Controller Class Initialized
INFO - 2025-05-12 13:52:59 --> Model "User_model" initialized
INFO - 2025-05-12 13:52:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 13:52:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 13:52:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/profile.php
INFO - 2025-05-12 13:52:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 13:52:59 --> Final output sent to browser
DEBUG - 2025-05-12 13:52:59 --> Total execution time: 0.0996
INFO - 2025-05-12 13:53:00 --> Config Class Initialized
INFO - 2025-05-12 13:53:00 --> Hooks Class Initialized
DEBUG - 2025-05-12 13:53:00 --> UTF-8 Support Enabled
INFO - 2025-05-12 13:53:00 --> Utf8 Class Initialized
INFO - 2025-05-12 13:53:00 --> URI Class Initialized
INFO - 2025-05-12 13:53:00 --> Router Class Initialized
INFO - 2025-05-12 13:53:00 --> Output Class Initialized
INFO - 2025-05-12 13:53:00 --> Security Class Initialized
DEBUG - 2025-05-12 13:53:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 13:53:00 --> Input Class Initialized
INFO - 2025-05-12 13:53:00 --> Language Class Initialized
INFO - 2025-05-12 13:53:00 --> Loader Class Initialized
INFO - 2025-05-12 13:53:00 --> Helper loaded: url_helper
INFO - 2025-05-12 13:53:00 --> Helper loaded: form_helper
INFO - 2025-05-12 13:53:00 --> Database Driver Class Initialized
DEBUG - 2025-05-12 13:53:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 13:53:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 13:53:00 --> Controller Class Initialized
INFO - 2025-05-12 13:53:00 --> Model "User_model" initialized
INFO - 2025-05-12 13:53:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 13:53:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 13:53:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/profile.php
INFO - 2025-05-12 13:53:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 13:53:00 --> Final output sent to browser
DEBUG - 2025-05-12 13:53:00 --> Total execution time: 0.0982
INFO - 2025-05-12 13:55:43 --> Config Class Initialized
INFO - 2025-05-12 13:55:43 --> Hooks Class Initialized
DEBUG - 2025-05-12 13:55:43 --> UTF-8 Support Enabled
INFO - 2025-05-12 13:55:43 --> Utf8 Class Initialized
INFO - 2025-05-12 13:55:43 --> URI Class Initialized
INFO - 2025-05-12 13:55:43 --> Router Class Initialized
INFO - 2025-05-12 13:55:43 --> Output Class Initialized
INFO - 2025-05-12 13:55:43 --> Security Class Initialized
DEBUG - 2025-05-12 13:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 13:55:43 --> Input Class Initialized
INFO - 2025-05-12 13:55:43 --> Language Class Initialized
INFO - 2025-05-12 13:55:43 --> Loader Class Initialized
INFO - 2025-05-12 13:55:43 --> Helper loaded: url_helper
INFO - 2025-05-12 13:55:43 --> Helper loaded: form_helper
INFO - 2025-05-12 13:55:43 --> Database Driver Class Initialized
DEBUG - 2025-05-12 13:55:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 13:55:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 13:55:43 --> Controller Class Initialized
INFO - 2025-05-12 13:55:43 --> Model "User_model" initialized
INFO - 2025-05-12 13:55:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 13:55:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 13:55:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/profile.php
INFO - 2025-05-12 13:55:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 13:55:43 --> Final output sent to browser
DEBUG - 2025-05-12 13:55:43 --> Total execution time: 0.0785
INFO - 2025-05-12 13:55:45 --> Config Class Initialized
INFO - 2025-05-12 13:55:45 --> Hooks Class Initialized
DEBUG - 2025-05-12 13:55:45 --> UTF-8 Support Enabled
INFO - 2025-05-12 13:55:45 --> Utf8 Class Initialized
INFO - 2025-05-12 13:55:45 --> URI Class Initialized
INFO - 2025-05-12 13:55:45 --> Router Class Initialized
INFO - 2025-05-12 13:55:45 --> Output Class Initialized
INFO - 2025-05-12 13:55:45 --> Security Class Initialized
DEBUG - 2025-05-12 13:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 13:55:45 --> Input Class Initialized
INFO - 2025-05-12 13:55:45 --> Language Class Initialized
INFO - 2025-05-12 13:55:45 --> Loader Class Initialized
INFO - 2025-05-12 13:55:45 --> Helper loaded: url_helper
INFO - 2025-05-12 13:55:45 --> Helper loaded: form_helper
INFO - 2025-05-12 13:55:45 --> Database Driver Class Initialized
DEBUG - 2025-05-12 13:55:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 13:55:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 13:55:45 --> Controller Class Initialized
INFO - 2025-05-12 13:55:45 --> Model "User_model" initialized
INFO - 2025-05-12 13:55:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\account/edit_profile.php
INFO - 2025-05-12 13:55:45 --> Final output sent to browser
DEBUG - 2025-05-12 13:55:45 --> Total execution time: 0.0811
INFO - 2025-05-12 14:01:13 --> Config Class Initialized
INFO - 2025-05-12 14:01:13 --> Hooks Class Initialized
DEBUG - 2025-05-12 14:01:13 --> UTF-8 Support Enabled
INFO - 2025-05-12 14:01:13 --> Utf8 Class Initialized
INFO - 2025-05-12 14:01:13 --> URI Class Initialized
INFO - 2025-05-12 14:01:13 --> Router Class Initialized
INFO - 2025-05-12 14:01:13 --> Output Class Initialized
INFO - 2025-05-12 14:01:13 --> Security Class Initialized
DEBUG - 2025-05-12 14:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 14:01:13 --> Input Class Initialized
INFO - 2025-05-12 14:01:13 --> Language Class Initialized
INFO - 2025-05-12 14:01:13 --> Loader Class Initialized
INFO - 2025-05-12 14:01:13 --> Helper loaded: url_helper
INFO - 2025-05-12 14:01:13 --> Helper loaded: form_helper
INFO - 2025-05-12 14:01:13 --> Database Driver Class Initialized
DEBUG - 2025-05-12 14:01:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 14:01:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 14:01:13 --> Controller Class Initialized
INFO - 2025-05-12 14:01:13 --> Model "User_model" initialized
INFO - 2025-05-12 14:01:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 14:01:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 14:01:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/profile.php
INFO - 2025-05-12 14:01:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 14:01:13 --> Final output sent to browser
DEBUG - 2025-05-12 14:01:13 --> Total execution time: 0.1073
INFO - 2025-05-12 14:01:25 --> Config Class Initialized
INFO - 2025-05-12 14:01:25 --> Hooks Class Initialized
DEBUG - 2025-05-12 14:01:25 --> UTF-8 Support Enabled
INFO - 2025-05-12 14:01:25 --> Utf8 Class Initialized
INFO - 2025-05-12 14:01:25 --> URI Class Initialized
INFO - 2025-05-12 14:01:25 --> Router Class Initialized
INFO - 2025-05-12 14:01:25 --> Output Class Initialized
INFO - 2025-05-12 14:01:25 --> Security Class Initialized
DEBUG - 2025-05-12 14:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 14:01:25 --> Input Class Initialized
INFO - 2025-05-12 14:01:25 --> Language Class Initialized
INFO - 2025-05-12 14:01:25 --> Loader Class Initialized
INFO - 2025-05-12 14:01:25 --> Helper loaded: url_helper
INFO - 2025-05-12 14:01:25 --> Helper loaded: form_helper
INFO - 2025-05-12 14:01:25 --> Database Driver Class Initialized
DEBUG - 2025-05-12 14:01:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 14:01:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 14:01:25 --> Controller Class Initialized
INFO - 2025-05-12 14:01:25 --> Model "User_model" initialized
INFO - 2025-05-12 14:01:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 14:01:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 14:01:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/profile.php
INFO - 2025-05-12 14:01:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 14:01:25 --> Final output sent to browser
DEBUG - 2025-05-12 14:01:25 --> Total execution time: 0.0980
INFO - 2025-05-12 14:09:15 --> Config Class Initialized
INFO - 2025-05-12 14:09:15 --> Hooks Class Initialized
DEBUG - 2025-05-12 14:09:16 --> UTF-8 Support Enabled
INFO - 2025-05-12 14:09:16 --> Utf8 Class Initialized
INFO - 2025-05-12 14:09:16 --> URI Class Initialized
INFO - 2025-05-12 14:09:16 --> Router Class Initialized
INFO - 2025-05-12 14:09:16 --> Output Class Initialized
INFO - 2025-05-12 14:09:16 --> Security Class Initialized
DEBUG - 2025-05-12 14:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 14:09:16 --> Input Class Initialized
INFO - 2025-05-12 14:09:16 --> Language Class Initialized
INFO - 2025-05-12 14:09:16 --> Loader Class Initialized
INFO - 2025-05-12 14:09:16 --> Helper loaded: url_helper
INFO - 2025-05-12 14:09:16 --> Helper loaded: form_helper
INFO - 2025-05-12 14:09:16 --> Database Driver Class Initialized
DEBUG - 2025-05-12 14:09:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 14:09:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 14:09:16 --> Controller Class Initialized
INFO - 2025-05-12 14:09:16 --> Model "User_model" initialized
INFO - 2025-05-12 14:09:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 14:09:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 14:09:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/profile.php
INFO - 2025-05-12 14:09:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 14:09:16 --> Final output sent to browser
DEBUG - 2025-05-12 14:09:16 --> Total execution time: 0.0843
INFO - 2025-05-12 14:09:17 --> Config Class Initialized
INFO - 2025-05-12 14:09:17 --> Hooks Class Initialized
DEBUG - 2025-05-12 14:09:17 --> UTF-8 Support Enabled
INFO - 2025-05-12 14:09:17 --> Utf8 Class Initialized
INFO - 2025-05-12 14:09:17 --> URI Class Initialized
INFO - 2025-05-12 14:09:17 --> Router Class Initialized
INFO - 2025-05-12 14:09:17 --> Output Class Initialized
INFO - 2025-05-12 14:09:17 --> Security Class Initialized
DEBUG - 2025-05-12 14:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 14:09:17 --> Input Class Initialized
INFO - 2025-05-12 14:09:17 --> Language Class Initialized
INFO - 2025-05-12 14:09:17 --> Loader Class Initialized
INFO - 2025-05-12 14:09:17 --> Helper loaded: url_helper
INFO - 2025-05-12 14:09:17 --> Helper loaded: form_helper
INFO - 2025-05-12 14:09:17 --> Database Driver Class Initialized
DEBUG - 2025-05-12 14:09:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 14:09:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 14:09:17 --> Controller Class Initialized
INFO - 2025-05-12 14:09:17 --> Model "User_model" initialized
INFO - 2025-05-12 14:09:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 14:09:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 14:09:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/edit_profile.php
INFO - 2025-05-12 14:09:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 14:09:17 --> Final output sent to browser
DEBUG - 2025-05-12 14:09:17 --> Total execution time: 0.0873
INFO - 2025-05-12 14:09:54 --> Config Class Initialized
INFO - 2025-05-12 14:09:54 --> Hooks Class Initialized
DEBUG - 2025-05-12 14:09:54 --> UTF-8 Support Enabled
INFO - 2025-05-12 14:09:54 --> Utf8 Class Initialized
INFO - 2025-05-12 14:09:54 --> URI Class Initialized
INFO - 2025-05-12 14:09:54 --> Router Class Initialized
INFO - 2025-05-12 14:09:54 --> Output Class Initialized
INFO - 2025-05-12 14:09:54 --> Security Class Initialized
DEBUG - 2025-05-12 14:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 14:09:54 --> Input Class Initialized
INFO - 2025-05-12 14:09:54 --> Language Class Initialized
INFO - 2025-05-12 14:09:54 --> Loader Class Initialized
INFO - 2025-05-12 14:09:54 --> Helper loaded: url_helper
INFO - 2025-05-12 14:09:54 --> Helper loaded: form_helper
INFO - 2025-05-12 14:09:54 --> Database Driver Class Initialized
DEBUG - 2025-05-12 14:09:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 14:09:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 14:09:54 --> Controller Class Initialized
INFO - 2025-05-12 14:09:54 --> Model "User_model" initialized
INFO - 2025-05-12 14:09:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 14:09:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 14:09:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/edit_profile.php
INFO - 2025-05-12 14:09:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 14:09:54 --> Final output sent to browser
DEBUG - 2025-05-12 14:09:54 --> Total execution time: 0.0964
INFO - 2025-05-12 14:13:02 --> Config Class Initialized
INFO - 2025-05-12 14:13:02 --> Hooks Class Initialized
DEBUG - 2025-05-12 14:13:02 --> UTF-8 Support Enabled
INFO - 2025-05-12 14:13:02 --> Utf8 Class Initialized
INFO - 2025-05-12 14:13:02 --> URI Class Initialized
INFO - 2025-05-12 14:13:02 --> Router Class Initialized
INFO - 2025-05-12 14:13:02 --> Output Class Initialized
INFO - 2025-05-12 14:13:02 --> Security Class Initialized
DEBUG - 2025-05-12 14:13:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 14:13:02 --> Input Class Initialized
INFO - 2025-05-12 14:13:02 --> Language Class Initialized
INFO - 2025-05-12 14:13:02 --> Loader Class Initialized
INFO - 2025-05-12 14:13:02 --> Helper loaded: url_helper
INFO - 2025-05-12 14:13:02 --> Helper loaded: form_helper
INFO - 2025-05-12 14:13:02 --> Database Driver Class Initialized
DEBUG - 2025-05-12 14:13:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 14:13:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 14:13:02 --> Controller Class Initialized
INFO - 2025-05-12 14:13:02 --> Model "User_model" initialized
INFO - 2025-05-12 14:13:02 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 14:13:02 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 14:13:02 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/edit_profile.php
INFO - 2025-05-12 14:13:02 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 14:13:02 --> Final output sent to browser
DEBUG - 2025-05-12 14:13:02 --> Total execution time: 0.1001
INFO - 2025-05-12 14:13:23 --> Config Class Initialized
INFO - 2025-05-12 14:13:23 --> Hooks Class Initialized
DEBUG - 2025-05-12 14:13:23 --> UTF-8 Support Enabled
INFO - 2025-05-12 14:13:23 --> Utf8 Class Initialized
INFO - 2025-05-12 14:13:23 --> URI Class Initialized
INFO - 2025-05-12 14:13:23 --> Router Class Initialized
INFO - 2025-05-12 14:13:24 --> Output Class Initialized
INFO - 2025-05-12 14:13:24 --> Security Class Initialized
DEBUG - 2025-05-12 14:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 14:13:24 --> Input Class Initialized
INFO - 2025-05-12 14:13:24 --> Language Class Initialized
INFO - 2025-05-12 14:13:24 --> Loader Class Initialized
INFO - 2025-05-12 14:13:24 --> Helper loaded: url_helper
INFO - 2025-05-12 14:13:24 --> Helper loaded: form_helper
INFO - 2025-05-12 14:13:24 --> Database Driver Class Initialized
DEBUG - 2025-05-12 14:13:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 14:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 14:13:24 --> Controller Class Initialized
INFO - 2025-05-12 14:13:24 --> Model "User_model" initialized
INFO - 2025-05-12 14:13:24 --> Config Class Initialized
INFO - 2025-05-12 14:13:24 --> Hooks Class Initialized
DEBUG - 2025-05-12 14:13:24 --> UTF-8 Support Enabled
INFO - 2025-05-12 14:13:24 --> Utf8 Class Initialized
INFO - 2025-05-12 14:13:24 --> URI Class Initialized
INFO - 2025-05-12 14:13:24 --> Router Class Initialized
INFO - 2025-05-12 14:13:24 --> Output Class Initialized
INFO - 2025-05-12 14:13:24 --> Security Class Initialized
DEBUG - 2025-05-12 14:13:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 14:13:24 --> Input Class Initialized
INFO - 2025-05-12 14:13:24 --> Language Class Initialized
INFO - 2025-05-12 14:13:24 --> Loader Class Initialized
INFO - 2025-05-12 14:13:24 --> Helper loaded: url_helper
INFO - 2025-05-12 14:13:24 --> Helper loaded: form_helper
INFO - 2025-05-12 14:13:24 --> Database Driver Class Initialized
DEBUG - 2025-05-12 14:13:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 14:13:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 14:13:24 --> Controller Class Initialized
INFO - 2025-05-12 14:13:24 --> Model "User_model" initialized
INFO - 2025-05-12 14:13:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 14:13:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 14:13:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/profile.php
INFO - 2025-05-12 14:13:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 14:13:24 --> Final output sent to browser
DEBUG - 2025-05-12 14:13:24 --> Total execution time: 0.0757
INFO - 2025-05-12 14:13:48 --> Config Class Initialized
INFO - 2025-05-12 14:13:48 --> Hooks Class Initialized
DEBUG - 2025-05-12 14:13:48 --> UTF-8 Support Enabled
INFO - 2025-05-12 14:13:48 --> Utf8 Class Initialized
INFO - 2025-05-12 14:13:48 --> URI Class Initialized
INFO - 2025-05-12 14:13:48 --> Router Class Initialized
INFO - 2025-05-12 14:13:48 --> Output Class Initialized
INFO - 2025-05-12 14:13:48 --> Security Class Initialized
DEBUG - 2025-05-12 14:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 14:13:48 --> Input Class Initialized
INFO - 2025-05-12 14:13:48 --> Language Class Initialized
INFO - 2025-05-12 14:13:48 --> Loader Class Initialized
INFO - 2025-05-12 14:13:48 --> Helper loaded: url_helper
INFO - 2025-05-12 14:13:48 --> Helper loaded: form_helper
INFO - 2025-05-12 14:13:48 --> Database Driver Class Initialized
DEBUG - 2025-05-12 14:13:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 14:13:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 14:13:48 --> Controller Class Initialized
INFO - 2025-05-12 14:13:48 --> Model "User_model" initialized
INFO - 2025-05-12 14:13:48 --> Model "Workout_model" initialized
INFO - 2025-05-12 14:13:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 14:13:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 14:13:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-12 14:13:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 14:13:48 --> Final output sent to browser
DEBUG - 2025-05-12 14:13:48 --> Total execution time: 0.0838
INFO - 2025-05-12 14:14:32 --> Config Class Initialized
INFO - 2025-05-12 14:14:32 --> Hooks Class Initialized
DEBUG - 2025-05-12 14:14:32 --> UTF-8 Support Enabled
INFO - 2025-05-12 14:14:32 --> Utf8 Class Initialized
INFO - 2025-05-12 14:14:32 --> URI Class Initialized
INFO - 2025-05-12 14:14:32 --> Router Class Initialized
INFO - 2025-05-12 14:14:32 --> Output Class Initialized
INFO - 2025-05-12 14:14:32 --> Security Class Initialized
DEBUG - 2025-05-12 14:14:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 14:14:32 --> Input Class Initialized
INFO - 2025-05-12 14:14:32 --> Language Class Initialized
INFO - 2025-05-12 14:14:32 --> Loader Class Initialized
INFO - 2025-05-12 14:14:32 --> Helper loaded: url_helper
INFO - 2025-05-12 14:14:32 --> Helper loaded: form_helper
INFO - 2025-05-12 14:14:32 --> Database Driver Class Initialized
DEBUG - 2025-05-12 14:14:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 14:14:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 14:14:32 --> Controller Class Initialized
INFO - 2025-05-12 14:14:32 --> Model "User_model" initialized
INFO - 2025-05-12 14:14:32 --> Model "Workout_model" initialized
INFO - 2025-05-12 14:14:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 14:14:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 14:14:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-12 14:14:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 14:14:32 --> Final output sent to browser
DEBUG - 2025-05-12 14:14:32 --> Total execution time: 0.0958
INFO - 2025-05-12 14:14:34 --> Config Class Initialized
INFO - 2025-05-12 14:14:34 --> Hooks Class Initialized
DEBUG - 2025-05-12 14:14:34 --> UTF-8 Support Enabled
INFO - 2025-05-12 14:14:34 --> Utf8 Class Initialized
INFO - 2025-05-12 14:14:34 --> URI Class Initialized
INFO - 2025-05-12 14:14:34 --> Router Class Initialized
INFO - 2025-05-12 14:14:34 --> Output Class Initialized
INFO - 2025-05-12 14:14:34 --> Security Class Initialized
DEBUG - 2025-05-12 14:14:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 14:14:34 --> Input Class Initialized
INFO - 2025-05-12 14:14:34 --> Language Class Initialized
INFO - 2025-05-12 14:14:34 --> Loader Class Initialized
INFO - 2025-05-12 14:14:34 --> Helper loaded: url_helper
INFO - 2025-05-12 14:14:34 --> Helper loaded: form_helper
INFO - 2025-05-12 14:14:34 --> Database Driver Class Initialized
DEBUG - 2025-05-12 14:14:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 14:14:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 14:14:34 --> Controller Class Initialized
INFO - 2025-05-12 14:14:34 --> Model "User_model" initialized
INFO - 2025-05-12 14:14:34 --> Model "Workout_model" initialized
INFO - 2025-05-12 14:14:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 14:14:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 14:14:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-12 14:14:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 14:14:34 --> Final output sent to browser
DEBUG - 2025-05-12 14:14:34 --> Total execution time: 0.1027
INFO - 2025-05-12 14:16:03 --> Config Class Initialized
INFO - 2025-05-12 14:16:03 --> Hooks Class Initialized
DEBUG - 2025-05-12 14:16:03 --> UTF-8 Support Enabled
INFO - 2025-05-12 14:16:03 --> Utf8 Class Initialized
INFO - 2025-05-12 14:16:03 --> URI Class Initialized
INFO - 2025-05-12 14:16:03 --> Router Class Initialized
INFO - 2025-05-12 14:16:03 --> Output Class Initialized
INFO - 2025-05-12 14:16:03 --> Security Class Initialized
DEBUG - 2025-05-12 14:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 14:16:03 --> Input Class Initialized
INFO - 2025-05-12 14:16:03 --> Language Class Initialized
INFO - 2025-05-12 14:16:03 --> Loader Class Initialized
INFO - 2025-05-12 14:16:03 --> Helper loaded: url_helper
INFO - 2025-05-12 14:16:03 --> Helper loaded: form_helper
INFO - 2025-05-12 14:16:03 --> Database Driver Class Initialized
DEBUG - 2025-05-12 14:16:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 14:16:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 14:16:03 --> Controller Class Initialized
INFO - 2025-05-12 14:16:03 --> Model "User_model" initialized
INFO - 2025-05-12 14:16:03 --> Model "Workout_model" initialized
INFO - 2025-05-12 14:16:03 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 14:16:03 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 14:16:03 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-12 14:16:03 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 14:16:03 --> Final output sent to browser
DEBUG - 2025-05-12 14:16:03 --> Total execution time: 0.1043
INFO - 2025-05-12 14:16:07 --> Config Class Initialized
INFO - 2025-05-12 14:16:07 --> Hooks Class Initialized
DEBUG - 2025-05-12 14:16:07 --> UTF-8 Support Enabled
INFO - 2025-05-12 14:16:07 --> Utf8 Class Initialized
INFO - 2025-05-12 14:16:07 --> URI Class Initialized
INFO - 2025-05-12 14:16:07 --> Router Class Initialized
INFO - 2025-05-12 14:16:07 --> Output Class Initialized
INFO - 2025-05-12 14:16:07 --> Security Class Initialized
DEBUG - 2025-05-12 14:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 14:16:07 --> Input Class Initialized
INFO - 2025-05-12 14:16:07 --> Language Class Initialized
INFO - 2025-05-12 14:16:07 --> Loader Class Initialized
INFO - 2025-05-12 14:16:07 --> Helper loaded: url_helper
INFO - 2025-05-12 14:16:07 --> Helper loaded: form_helper
INFO - 2025-05-12 14:16:07 --> Database Driver Class Initialized
DEBUG - 2025-05-12 14:16:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 14:16:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 14:16:07 --> Controller Class Initialized
INFO - 2025-05-12 14:16:07 --> Model "User_model" initialized
INFO - 2025-05-12 14:16:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 14:16:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 14:16:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/profile.php
INFO - 2025-05-12 14:16:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 14:16:07 --> Final output sent to browser
DEBUG - 2025-05-12 14:16:07 --> Total execution time: 0.1148
INFO - 2025-05-12 14:16:09 --> Config Class Initialized
INFO - 2025-05-12 14:16:09 --> Hooks Class Initialized
DEBUG - 2025-05-12 14:16:09 --> UTF-8 Support Enabled
INFO - 2025-05-12 14:16:09 --> Utf8 Class Initialized
INFO - 2025-05-12 14:16:09 --> URI Class Initialized
INFO - 2025-05-12 14:16:09 --> Router Class Initialized
INFO - 2025-05-12 14:16:09 --> Output Class Initialized
INFO - 2025-05-12 14:16:09 --> Security Class Initialized
DEBUG - 2025-05-12 14:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 14:16:09 --> Input Class Initialized
INFO - 2025-05-12 14:16:09 --> Language Class Initialized
INFO - 2025-05-12 14:16:09 --> Loader Class Initialized
INFO - 2025-05-12 14:16:09 --> Helper loaded: url_helper
INFO - 2025-05-12 14:16:09 --> Helper loaded: form_helper
INFO - 2025-05-12 14:16:09 --> Database Driver Class Initialized
DEBUG - 2025-05-12 14:16:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 14:16:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 14:16:09 --> Controller Class Initialized
INFO - 2025-05-12 14:16:09 --> Model "User_model" initialized
INFO - 2025-05-12 14:16:09 --> Model "Workout_model" initialized
INFO - 2025-05-12 14:16:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 14:16:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 14:16:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-12 14:16:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 14:16:09 --> Final output sent to browser
DEBUG - 2025-05-12 14:16:09 --> Total execution time: 0.1186
INFO - 2025-05-12 14:16:56 --> Config Class Initialized
INFO - 2025-05-12 14:16:56 --> Hooks Class Initialized
DEBUG - 2025-05-12 14:16:56 --> UTF-8 Support Enabled
INFO - 2025-05-12 14:16:56 --> Utf8 Class Initialized
INFO - 2025-05-12 14:16:56 --> URI Class Initialized
INFO - 2025-05-12 14:16:56 --> Router Class Initialized
INFO - 2025-05-12 14:16:56 --> Output Class Initialized
INFO - 2025-05-12 14:16:56 --> Security Class Initialized
DEBUG - 2025-05-12 14:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 14:16:56 --> Input Class Initialized
INFO - 2025-05-12 14:16:56 --> Language Class Initialized
INFO - 2025-05-12 14:16:56 --> Loader Class Initialized
INFO - 2025-05-12 14:16:56 --> Helper loaded: url_helper
INFO - 2025-05-12 14:16:56 --> Helper loaded: form_helper
INFO - 2025-05-12 14:16:56 --> Database Driver Class Initialized
DEBUG - 2025-05-12 14:16:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 14:16:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 14:16:56 --> Controller Class Initialized
INFO - 2025-05-12 14:16:56 --> Model "User_model" initialized
INFO - 2025-05-12 14:16:56 --> Model "Workout_model" initialized
INFO - 2025-05-12 14:16:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 14:16:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 14:16:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-12 14:16:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 14:16:56 --> Final output sent to browser
DEBUG - 2025-05-12 14:16:56 --> Total execution time: 0.0882
INFO - 2025-05-12 14:20:31 --> Config Class Initialized
INFO - 2025-05-12 14:20:31 --> Hooks Class Initialized
DEBUG - 2025-05-12 14:20:31 --> UTF-8 Support Enabled
INFO - 2025-05-12 14:20:31 --> Utf8 Class Initialized
INFO - 2025-05-12 14:20:31 --> URI Class Initialized
INFO - 2025-05-12 14:20:31 --> Router Class Initialized
INFO - 2025-05-12 14:20:31 --> Output Class Initialized
INFO - 2025-05-12 14:20:31 --> Security Class Initialized
DEBUG - 2025-05-12 14:20:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 14:20:31 --> Input Class Initialized
INFO - 2025-05-12 14:20:31 --> Language Class Initialized
INFO - 2025-05-12 14:20:31 --> Loader Class Initialized
INFO - 2025-05-12 14:20:31 --> Helper loaded: url_helper
INFO - 2025-05-12 14:20:31 --> Helper loaded: form_helper
INFO - 2025-05-12 14:20:31 --> Database Driver Class Initialized
DEBUG - 2025-05-12 14:20:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 14:20:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 14:20:31 --> Controller Class Initialized
INFO - 2025-05-12 14:20:31 --> Model "User_model" initialized
INFO - 2025-05-12 14:20:31 --> Model "Workout_model" initialized
INFO - 2025-05-12 14:20:31 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 14:20:31 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 14:20:31 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-12 14:20:31 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 14:20:31 --> Final output sent to browser
DEBUG - 2025-05-12 14:20:31 --> Total execution time: 0.0916
INFO - 2025-05-12 14:20:36 --> Config Class Initialized
INFO - 2025-05-12 14:20:36 --> Hooks Class Initialized
DEBUG - 2025-05-12 14:20:36 --> UTF-8 Support Enabled
INFO - 2025-05-12 14:20:36 --> Utf8 Class Initialized
INFO - 2025-05-12 14:20:36 --> URI Class Initialized
INFO - 2025-05-12 14:20:36 --> Router Class Initialized
INFO - 2025-05-12 14:20:36 --> Output Class Initialized
INFO - 2025-05-12 14:20:36 --> Security Class Initialized
DEBUG - 2025-05-12 14:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 14:20:36 --> Input Class Initialized
INFO - 2025-05-12 14:20:36 --> Language Class Initialized
INFO - 2025-05-12 14:20:36 --> Loader Class Initialized
INFO - 2025-05-12 14:20:36 --> Helper loaded: url_helper
INFO - 2025-05-12 14:20:36 --> Helper loaded: form_helper
INFO - 2025-05-12 14:20:36 --> Database Driver Class Initialized
DEBUG - 2025-05-12 14:20:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 14:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 14:20:36 --> Controller Class Initialized
INFO - 2025-05-12 14:20:36 --> Model "User_model" initialized
INFO - 2025-05-12 14:20:36 --> Model "Workout_model" initialized
INFO - 2025-05-12 14:20:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 14:20:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 14:20:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-12 14:20:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 14:20:36 --> Final output sent to browser
DEBUG - 2025-05-12 14:20:36 --> Total execution time: 0.1282
INFO - 2025-05-12 14:20:43 --> Config Class Initialized
INFO - 2025-05-12 14:20:43 --> Hooks Class Initialized
DEBUG - 2025-05-12 14:20:43 --> UTF-8 Support Enabled
INFO - 2025-05-12 14:20:43 --> Utf8 Class Initialized
INFO - 2025-05-12 14:20:43 --> URI Class Initialized
INFO - 2025-05-12 14:20:43 --> Router Class Initialized
INFO - 2025-05-12 14:20:43 --> Output Class Initialized
INFO - 2025-05-12 14:20:43 --> Security Class Initialized
DEBUG - 2025-05-12 14:20:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 14:20:43 --> Input Class Initialized
INFO - 2025-05-12 14:20:43 --> Language Class Initialized
INFO - 2025-05-12 14:20:43 --> Loader Class Initialized
INFO - 2025-05-12 14:20:43 --> Helper loaded: url_helper
INFO - 2025-05-12 14:20:43 --> Helper loaded: form_helper
INFO - 2025-05-12 14:20:43 --> Database Driver Class Initialized
DEBUG - 2025-05-12 14:20:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 14:20:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 14:20:43 --> Controller Class Initialized
INFO - 2025-05-12 14:20:43 --> Model "User_model" initialized
INFO - 2025-05-12 14:20:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 14:20:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 14:20:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/profile.php
INFO - 2025-05-12 14:20:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 14:20:43 --> Final output sent to browser
DEBUG - 2025-05-12 14:20:43 --> Total execution time: 0.0752
INFO - 2025-05-12 14:21:09 --> Config Class Initialized
INFO - 2025-05-12 14:21:09 --> Hooks Class Initialized
DEBUG - 2025-05-12 14:21:09 --> UTF-8 Support Enabled
INFO - 2025-05-12 14:21:09 --> Utf8 Class Initialized
INFO - 2025-05-12 14:21:09 --> URI Class Initialized
INFO - 2025-05-12 14:21:09 --> Router Class Initialized
INFO - 2025-05-12 14:21:09 --> Output Class Initialized
INFO - 2025-05-12 14:21:09 --> Security Class Initialized
DEBUG - 2025-05-12 14:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 14:21:09 --> Input Class Initialized
INFO - 2025-05-12 14:21:09 --> Language Class Initialized
INFO - 2025-05-12 14:21:09 --> Loader Class Initialized
INFO - 2025-05-12 14:21:09 --> Helper loaded: url_helper
INFO - 2025-05-12 14:21:09 --> Helper loaded: form_helper
INFO - 2025-05-12 14:21:09 --> Database Driver Class Initialized
DEBUG - 2025-05-12 14:21:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 14:21:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 14:21:09 --> Controller Class Initialized
INFO - 2025-05-12 14:21:09 --> Model "User_model" initialized
INFO - 2025-05-12 14:21:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 14:21:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 14:21:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/profile.php
INFO - 2025-05-12 14:21:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 14:21:09 --> Final output sent to browser
DEBUG - 2025-05-12 14:21:09 --> Total execution time: 0.1075
INFO - 2025-05-12 14:21:13 --> Config Class Initialized
INFO - 2025-05-12 14:21:13 --> Hooks Class Initialized
DEBUG - 2025-05-12 14:21:13 --> UTF-8 Support Enabled
INFO - 2025-05-12 14:21:13 --> Utf8 Class Initialized
INFO - 2025-05-12 14:21:13 --> URI Class Initialized
INFO - 2025-05-12 14:21:13 --> Router Class Initialized
INFO - 2025-05-12 14:21:13 --> Output Class Initialized
INFO - 2025-05-12 14:21:13 --> Security Class Initialized
DEBUG - 2025-05-12 14:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 14:21:13 --> Input Class Initialized
INFO - 2025-05-12 14:21:13 --> Language Class Initialized
INFO - 2025-05-12 14:21:13 --> Loader Class Initialized
INFO - 2025-05-12 14:21:13 --> Helper loaded: url_helper
INFO - 2025-05-12 14:21:13 --> Helper loaded: form_helper
INFO - 2025-05-12 14:21:13 --> Database Driver Class Initialized
DEBUG - 2025-05-12 14:21:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 14:21:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 14:21:13 --> Controller Class Initialized
INFO - 2025-05-12 14:21:13 --> Model "User_model" initialized
INFO - 2025-05-12 14:21:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 14:21:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 14:21:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/profile.php
INFO - 2025-05-12 14:21:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 14:21:13 --> Final output sent to browser
DEBUG - 2025-05-12 14:21:13 --> Total execution time: 0.0852
INFO - 2025-05-12 14:22:34 --> Config Class Initialized
INFO - 2025-05-12 14:22:34 --> Hooks Class Initialized
DEBUG - 2025-05-12 14:22:34 --> UTF-8 Support Enabled
INFO - 2025-05-12 14:22:34 --> Utf8 Class Initialized
INFO - 2025-05-12 14:22:34 --> URI Class Initialized
INFO - 2025-05-12 14:22:34 --> Router Class Initialized
INFO - 2025-05-12 14:22:34 --> Output Class Initialized
INFO - 2025-05-12 14:22:34 --> Security Class Initialized
DEBUG - 2025-05-12 14:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 14:22:34 --> Input Class Initialized
INFO - 2025-05-12 14:22:34 --> Language Class Initialized
INFO - 2025-05-12 14:22:34 --> Loader Class Initialized
INFO - 2025-05-12 14:22:34 --> Helper loaded: url_helper
INFO - 2025-05-12 14:22:34 --> Helper loaded: form_helper
INFO - 2025-05-12 14:22:34 --> Database Driver Class Initialized
DEBUG - 2025-05-12 14:22:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 14:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 14:22:34 --> Controller Class Initialized
INFO - 2025-05-12 14:22:34 --> Model "User_model" initialized
INFO - 2025-05-12 14:22:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 14:22:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 14:22:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/profile.php
INFO - 2025-05-12 14:22:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 14:22:34 --> Final output sent to browser
DEBUG - 2025-05-12 14:22:34 --> Total execution time: 0.0899
INFO - 2025-05-12 14:22:39 --> Config Class Initialized
INFO - 2025-05-12 14:22:39 --> Hooks Class Initialized
DEBUG - 2025-05-12 14:22:39 --> UTF-8 Support Enabled
INFO - 2025-05-12 14:22:39 --> Utf8 Class Initialized
INFO - 2025-05-12 14:22:39 --> URI Class Initialized
INFO - 2025-05-12 14:22:39 --> Router Class Initialized
INFO - 2025-05-12 14:22:39 --> Output Class Initialized
INFO - 2025-05-12 14:22:39 --> Security Class Initialized
DEBUG - 2025-05-12 14:22:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 14:22:39 --> Input Class Initialized
INFO - 2025-05-12 14:22:39 --> Language Class Initialized
INFO - 2025-05-12 14:22:39 --> Loader Class Initialized
INFO - 2025-05-12 14:22:39 --> Helper loaded: url_helper
INFO - 2025-05-12 14:22:39 --> Helper loaded: form_helper
INFO - 2025-05-12 14:22:39 --> Database Driver Class Initialized
DEBUG - 2025-05-12 14:22:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 14:22:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 14:22:39 --> Controller Class Initialized
INFO - 2025-05-12 14:22:39 --> Model "User_model" initialized
INFO - 2025-05-12 14:22:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 14:22:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 14:22:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/profile.php
INFO - 2025-05-12 14:22:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 14:22:39 --> Final output sent to browser
DEBUG - 2025-05-12 14:22:39 --> Total execution time: 0.1200
INFO - 2025-05-12 14:22:42 --> Config Class Initialized
INFO - 2025-05-12 14:22:42 --> Hooks Class Initialized
DEBUG - 2025-05-12 14:22:42 --> UTF-8 Support Enabled
INFO - 2025-05-12 14:22:42 --> Utf8 Class Initialized
INFO - 2025-05-12 14:22:42 --> URI Class Initialized
INFO - 2025-05-12 14:22:42 --> Router Class Initialized
INFO - 2025-05-12 14:22:42 --> Output Class Initialized
INFO - 2025-05-12 14:22:42 --> Security Class Initialized
DEBUG - 2025-05-12 14:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 14:22:42 --> Input Class Initialized
INFO - 2025-05-12 14:22:42 --> Language Class Initialized
INFO - 2025-05-12 14:22:42 --> Loader Class Initialized
INFO - 2025-05-12 14:22:42 --> Helper loaded: url_helper
INFO - 2025-05-12 14:22:42 --> Helper loaded: form_helper
INFO - 2025-05-12 14:22:42 --> Database Driver Class Initialized
DEBUG - 2025-05-12 14:22:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 14:22:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 14:22:42 --> Controller Class Initialized
INFO - 2025-05-12 14:22:42 --> Model "User_model" initialized
INFO - 2025-05-12 14:22:42 --> Model "Workout_model" initialized
INFO - 2025-05-12 14:22:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 14:22:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 14:22:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-12 14:22:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 14:22:42 --> Final output sent to browser
DEBUG - 2025-05-12 14:22:42 --> Total execution time: 0.0898
INFO - 2025-05-12 14:24:19 --> Config Class Initialized
INFO - 2025-05-12 14:24:19 --> Hooks Class Initialized
DEBUG - 2025-05-12 14:24:19 --> UTF-8 Support Enabled
INFO - 2025-05-12 14:24:19 --> Utf8 Class Initialized
INFO - 2025-05-12 14:24:19 --> URI Class Initialized
INFO - 2025-05-12 14:24:19 --> Router Class Initialized
INFO - 2025-05-12 14:24:19 --> Output Class Initialized
INFO - 2025-05-12 14:24:19 --> Security Class Initialized
DEBUG - 2025-05-12 14:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 14:24:19 --> Input Class Initialized
INFO - 2025-05-12 14:24:19 --> Language Class Initialized
INFO - 2025-05-12 14:24:19 --> Loader Class Initialized
INFO - 2025-05-12 14:24:20 --> Helper loaded: url_helper
INFO - 2025-05-12 14:24:20 --> Helper loaded: form_helper
INFO - 2025-05-12 14:24:20 --> Database Driver Class Initialized
DEBUG - 2025-05-12 14:24:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 14:24:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 14:24:20 --> Controller Class Initialized
INFO - 2025-05-12 14:24:20 --> Model "User_model" initialized
INFO - 2025-05-12 14:24:20 --> Model "Workout_model" initialized
INFO - 2025-05-12 14:24:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 14:24:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 14:24:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-12 14:24:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 14:24:20 --> Final output sent to browser
DEBUG - 2025-05-12 14:24:20 --> Total execution time: 0.1008
INFO - 2025-05-12 14:24:21 --> Config Class Initialized
INFO - 2025-05-12 14:24:21 --> Hooks Class Initialized
DEBUG - 2025-05-12 14:24:21 --> UTF-8 Support Enabled
INFO - 2025-05-12 14:24:21 --> Utf8 Class Initialized
INFO - 2025-05-12 14:24:21 --> URI Class Initialized
INFO - 2025-05-12 14:24:21 --> Router Class Initialized
INFO - 2025-05-12 14:24:21 --> Output Class Initialized
INFO - 2025-05-12 14:24:21 --> Security Class Initialized
DEBUG - 2025-05-12 14:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 14:24:21 --> Input Class Initialized
INFO - 2025-05-12 14:24:21 --> Language Class Initialized
INFO - 2025-05-12 14:24:21 --> Loader Class Initialized
INFO - 2025-05-12 14:24:21 --> Helper loaded: url_helper
INFO - 2025-05-12 14:24:21 --> Helper loaded: form_helper
INFO - 2025-05-12 14:24:21 --> Database Driver Class Initialized
DEBUG - 2025-05-12 14:24:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 14:24:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 14:24:21 --> Controller Class Initialized
INFO - 2025-05-12 14:24:21 --> Model "User_model" initialized
INFO - 2025-05-12 14:24:21 --> Model "Workout_model" initialized
INFO - 2025-05-12 14:24:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 14:24:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 14:24:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-12 14:24:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 14:24:21 --> Final output sent to browser
DEBUG - 2025-05-12 14:24:21 --> Total execution time: 0.1273
INFO - 2025-05-12 14:24:24 --> Config Class Initialized
INFO - 2025-05-12 14:24:24 --> Hooks Class Initialized
DEBUG - 2025-05-12 14:24:24 --> UTF-8 Support Enabled
INFO - 2025-05-12 14:24:24 --> Utf8 Class Initialized
INFO - 2025-05-12 14:24:24 --> URI Class Initialized
INFO - 2025-05-12 14:24:24 --> Router Class Initialized
INFO - 2025-05-12 14:24:24 --> Output Class Initialized
INFO - 2025-05-12 14:24:24 --> Security Class Initialized
DEBUG - 2025-05-12 14:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 14:24:24 --> Input Class Initialized
INFO - 2025-05-12 14:24:24 --> Language Class Initialized
INFO - 2025-05-12 14:24:24 --> Loader Class Initialized
INFO - 2025-05-12 14:24:24 --> Helper loaded: url_helper
INFO - 2025-05-12 14:24:24 --> Helper loaded: form_helper
INFO - 2025-05-12 14:24:24 --> Database Driver Class Initialized
DEBUG - 2025-05-12 14:24:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 14:24:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 14:24:24 --> Controller Class Initialized
INFO - 2025-05-12 14:24:24 --> Model "User_model" initialized
INFO - 2025-05-12 14:24:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 14:24:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 14:24:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/profile.php
INFO - 2025-05-12 14:24:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 14:24:24 --> Final output sent to browser
DEBUG - 2025-05-12 14:24:24 --> Total execution time: 0.0850
INFO - 2025-05-12 14:24:27 --> Config Class Initialized
INFO - 2025-05-12 14:24:27 --> Hooks Class Initialized
DEBUG - 2025-05-12 14:24:27 --> UTF-8 Support Enabled
INFO - 2025-05-12 14:24:27 --> Utf8 Class Initialized
INFO - 2025-05-12 14:24:27 --> URI Class Initialized
INFO - 2025-05-12 14:24:27 --> Router Class Initialized
INFO - 2025-05-12 14:24:27 --> Output Class Initialized
INFO - 2025-05-12 14:24:27 --> Security Class Initialized
DEBUG - 2025-05-12 14:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 14:24:27 --> Input Class Initialized
INFO - 2025-05-12 14:24:27 --> Language Class Initialized
INFO - 2025-05-12 14:24:27 --> Loader Class Initialized
INFO - 2025-05-12 14:24:27 --> Helper loaded: url_helper
INFO - 2025-05-12 14:24:27 --> Helper loaded: form_helper
INFO - 2025-05-12 14:24:27 --> Database Driver Class Initialized
DEBUG - 2025-05-12 14:24:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 14:24:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 14:24:27 --> Controller Class Initialized
INFO - 2025-05-12 14:24:27 --> Model "User_model" initialized
INFO - 2025-05-12 14:24:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 14:24:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 14:24:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/profile.php
INFO - 2025-05-12 14:24:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 14:24:27 --> Final output sent to browser
DEBUG - 2025-05-12 14:24:27 --> Total execution time: 0.1045
INFO - 2025-05-12 14:24:54 --> Config Class Initialized
INFO - 2025-05-12 14:24:54 --> Hooks Class Initialized
DEBUG - 2025-05-12 14:24:54 --> UTF-8 Support Enabled
INFO - 2025-05-12 14:24:54 --> Utf8 Class Initialized
INFO - 2025-05-12 14:24:54 --> URI Class Initialized
INFO - 2025-05-12 14:24:54 --> Router Class Initialized
INFO - 2025-05-12 14:24:54 --> Output Class Initialized
INFO - 2025-05-12 14:24:54 --> Security Class Initialized
DEBUG - 2025-05-12 14:24:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 14:24:54 --> Input Class Initialized
INFO - 2025-05-12 14:24:54 --> Language Class Initialized
INFO - 2025-05-12 14:24:54 --> Loader Class Initialized
INFO - 2025-05-12 14:24:54 --> Helper loaded: url_helper
INFO - 2025-05-12 14:24:54 --> Helper loaded: form_helper
INFO - 2025-05-12 14:24:54 --> Database Driver Class Initialized
DEBUG - 2025-05-12 14:24:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 14:24:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 14:24:54 --> Controller Class Initialized
INFO - 2025-05-12 14:24:54 --> Model "User_model" initialized
INFO - 2025-05-12 14:24:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 14:24:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 14:24:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/profile.php
INFO - 2025-05-12 14:24:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 14:24:54 --> Final output sent to browser
DEBUG - 2025-05-12 14:24:54 --> Total execution time: 0.0833
INFO - 2025-05-12 14:24:59 --> Config Class Initialized
INFO - 2025-05-12 14:24:59 --> Hooks Class Initialized
DEBUG - 2025-05-12 14:24:59 --> UTF-8 Support Enabled
INFO - 2025-05-12 14:24:59 --> Utf8 Class Initialized
INFO - 2025-05-12 14:24:59 --> URI Class Initialized
INFO - 2025-05-12 14:24:59 --> Router Class Initialized
INFO - 2025-05-12 14:24:59 --> Output Class Initialized
INFO - 2025-05-12 14:24:59 --> Security Class Initialized
DEBUG - 2025-05-12 14:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 14:24:59 --> Input Class Initialized
INFO - 2025-05-12 14:24:59 --> Language Class Initialized
INFO - 2025-05-12 14:24:59 --> Loader Class Initialized
INFO - 2025-05-12 14:24:59 --> Helper loaded: url_helper
INFO - 2025-05-12 14:24:59 --> Helper loaded: form_helper
INFO - 2025-05-12 14:24:59 --> Database Driver Class Initialized
DEBUG - 2025-05-12 14:24:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 14:24:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 14:24:59 --> Controller Class Initialized
INFO - 2025-05-12 14:24:59 --> Model "User_model" initialized
INFO - 2025-05-12 14:24:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 14:24:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 14:24:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/profile.php
INFO - 2025-05-12 14:24:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 14:24:59 --> Final output sent to browser
DEBUG - 2025-05-12 14:24:59 --> Total execution time: 0.1191
INFO - 2025-05-12 14:25:02 --> Config Class Initialized
INFO - 2025-05-12 14:25:02 --> Hooks Class Initialized
DEBUG - 2025-05-12 14:25:02 --> UTF-8 Support Enabled
INFO - 2025-05-12 14:25:02 --> Utf8 Class Initialized
INFO - 2025-05-12 14:25:02 --> URI Class Initialized
INFO - 2025-05-12 14:25:02 --> Router Class Initialized
INFO - 2025-05-12 14:25:02 --> Output Class Initialized
INFO - 2025-05-12 14:25:02 --> Security Class Initialized
DEBUG - 2025-05-12 14:25:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 14:25:02 --> Input Class Initialized
INFO - 2025-05-12 14:25:02 --> Language Class Initialized
INFO - 2025-05-12 14:25:02 --> Loader Class Initialized
INFO - 2025-05-12 14:25:02 --> Helper loaded: url_helper
INFO - 2025-05-12 14:25:02 --> Helper loaded: form_helper
INFO - 2025-05-12 14:25:02 --> Database Driver Class Initialized
DEBUG - 2025-05-12 14:25:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 14:25:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 14:25:02 --> Controller Class Initialized
INFO - 2025-05-12 14:25:02 --> Model "User_model" initialized
INFO - 2025-05-12 14:25:02 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 14:25:02 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 14:25:02 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/edit_profile.php
INFO - 2025-05-12 14:25:02 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 14:25:02 --> Final output sent to browser
DEBUG - 2025-05-12 14:25:02 --> Total execution time: 0.0786
INFO - 2025-05-12 14:25:14 --> Config Class Initialized
INFO - 2025-05-12 14:25:14 --> Hooks Class Initialized
DEBUG - 2025-05-12 14:25:14 --> UTF-8 Support Enabled
INFO - 2025-05-12 14:25:14 --> Utf8 Class Initialized
INFO - 2025-05-12 14:25:14 --> URI Class Initialized
INFO - 2025-05-12 14:25:14 --> Router Class Initialized
INFO - 2025-05-12 14:25:14 --> Output Class Initialized
INFO - 2025-05-12 14:25:14 --> Security Class Initialized
DEBUG - 2025-05-12 14:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 14:25:14 --> Input Class Initialized
INFO - 2025-05-12 14:25:14 --> Language Class Initialized
INFO - 2025-05-12 14:25:14 --> Loader Class Initialized
INFO - 2025-05-12 14:25:14 --> Helper loaded: url_helper
INFO - 2025-05-12 14:25:14 --> Helper loaded: form_helper
INFO - 2025-05-12 14:25:14 --> Database Driver Class Initialized
DEBUG - 2025-05-12 14:25:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 14:25:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 14:25:14 --> Controller Class Initialized
INFO - 2025-05-12 14:25:14 --> Model "User_model" initialized
INFO - 2025-05-12 14:25:14 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 14:25:14 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 14:25:14 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/profile.php
INFO - 2025-05-12 14:25:14 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 14:25:14 --> Final output sent to browser
DEBUG - 2025-05-12 14:25:14 --> Total execution time: 0.0763
INFO - 2025-05-12 14:25:20 --> Config Class Initialized
INFO - 2025-05-12 14:25:20 --> Hooks Class Initialized
DEBUG - 2025-05-12 14:25:20 --> UTF-8 Support Enabled
INFO - 2025-05-12 14:25:20 --> Utf8 Class Initialized
INFO - 2025-05-12 14:25:20 --> URI Class Initialized
INFO - 2025-05-12 14:25:20 --> Router Class Initialized
INFO - 2025-05-12 14:25:20 --> Output Class Initialized
INFO - 2025-05-12 14:25:20 --> Security Class Initialized
DEBUG - 2025-05-12 14:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 14:25:20 --> Input Class Initialized
INFO - 2025-05-12 14:25:20 --> Language Class Initialized
INFO - 2025-05-12 14:25:20 --> Loader Class Initialized
INFO - 2025-05-12 14:25:20 --> Helper loaded: url_helper
INFO - 2025-05-12 14:25:20 --> Helper loaded: form_helper
INFO - 2025-05-12 14:25:20 --> Database Driver Class Initialized
DEBUG - 2025-05-12 14:25:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 14:25:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 14:25:20 --> Controller Class Initialized
INFO - 2025-05-12 14:25:20 --> Model "User_model" initialized
INFO - 2025-05-12 14:25:20 --> Model "Workout_model" initialized
INFO - 2025-05-12 14:25:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 14:25:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 14:25:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-12 14:25:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 14:25:20 --> Final output sent to browser
DEBUG - 2025-05-12 14:25:20 --> Total execution time: 0.0930
INFO - 2025-05-12 14:25:22 --> Config Class Initialized
INFO - 2025-05-12 14:25:22 --> Hooks Class Initialized
DEBUG - 2025-05-12 14:25:22 --> UTF-8 Support Enabled
INFO - 2025-05-12 14:25:22 --> Utf8 Class Initialized
INFO - 2025-05-12 14:25:22 --> URI Class Initialized
INFO - 2025-05-12 14:25:22 --> Router Class Initialized
INFO - 2025-05-12 14:25:22 --> Output Class Initialized
INFO - 2025-05-12 14:25:22 --> Security Class Initialized
DEBUG - 2025-05-12 14:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 14:25:22 --> Input Class Initialized
INFO - 2025-05-12 14:25:22 --> Language Class Initialized
INFO - 2025-05-12 14:25:22 --> Loader Class Initialized
INFO - 2025-05-12 14:25:22 --> Helper loaded: url_helper
INFO - 2025-05-12 14:25:22 --> Helper loaded: form_helper
INFO - 2025-05-12 14:25:22 --> Database Driver Class Initialized
DEBUG - 2025-05-12 14:25:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 14:25:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 14:25:22 --> Controller Class Initialized
INFO - 2025-05-12 14:25:22 --> Model "User_model" initialized
INFO - 2025-05-12 14:25:22 --> Model "Workout_model" initialized
INFO - 2025-05-12 14:25:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 14:25:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 14:25:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-12 14:25:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 14:25:22 --> Final output sent to browser
DEBUG - 2025-05-12 14:25:22 --> Total execution time: 0.0998
INFO - 2025-05-12 14:25:28 --> Config Class Initialized
INFO - 2025-05-12 14:25:28 --> Hooks Class Initialized
DEBUG - 2025-05-12 14:25:28 --> UTF-8 Support Enabled
INFO - 2025-05-12 14:25:28 --> Utf8 Class Initialized
INFO - 2025-05-12 14:25:28 --> URI Class Initialized
INFO - 2025-05-12 14:25:28 --> Router Class Initialized
INFO - 2025-05-12 14:25:28 --> Output Class Initialized
INFO - 2025-05-12 14:25:28 --> Security Class Initialized
DEBUG - 2025-05-12 14:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 14:25:28 --> Input Class Initialized
INFO - 2025-05-12 14:25:28 --> Language Class Initialized
INFO - 2025-05-12 14:25:28 --> Loader Class Initialized
INFO - 2025-05-12 14:25:28 --> Helper loaded: url_helper
INFO - 2025-05-12 14:25:28 --> Helper loaded: form_helper
INFO - 2025-05-12 14:25:28 --> Database Driver Class Initialized
DEBUG - 2025-05-12 14:25:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 14:25:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 14:25:28 --> Controller Class Initialized
INFO - 2025-05-12 14:25:28 --> Model "User_model" initialized
INFO - 2025-05-12 14:25:28 --> Config Class Initialized
INFO - 2025-05-12 14:25:28 --> Hooks Class Initialized
DEBUG - 2025-05-12 14:25:28 --> UTF-8 Support Enabled
INFO - 2025-05-12 14:25:28 --> Utf8 Class Initialized
INFO - 2025-05-12 14:25:28 --> URI Class Initialized
INFO - 2025-05-12 14:25:28 --> Router Class Initialized
INFO - 2025-05-12 14:25:28 --> Output Class Initialized
INFO - 2025-05-12 14:25:28 --> Security Class Initialized
DEBUG - 2025-05-12 14:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 14:25:28 --> Input Class Initialized
INFO - 2025-05-12 14:25:28 --> Language Class Initialized
INFO - 2025-05-12 14:25:28 --> Loader Class Initialized
INFO - 2025-05-12 14:25:28 --> Helper loaded: url_helper
INFO - 2025-05-12 14:25:28 --> Helper loaded: form_helper
INFO - 2025-05-12 14:25:28 --> Database Driver Class Initialized
DEBUG - 2025-05-12 14:25:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 14:25:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 14:25:28 --> Controller Class Initialized
INFO - 2025-05-12 14:25:28 --> Model "User_model" initialized
INFO - 2025-05-12 14:25:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-12 14:25:28 --> Final output sent to browser
DEBUG - 2025-05-12 14:25:28 --> Total execution time: 0.1596
INFO - 2025-05-12 14:25:40 --> Config Class Initialized
INFO - 2025-05-12 14:25:40 --> Hooks Class Initialized
DEBUG - 2025-05-12 14:25:40 --> UTF-8 Support Enabled
INFO - 2025-05-12 14:25:40 --> Utf8 Class Initialized
INFO - 2025-05-12 14:25:40 --> URI Class Initialized
INFO - 2025-05-12 14:25:40 --> Router Class Initialized
INFO - 2025-05-12 14:25:40 --> Output Class Initialized
INFO - 2025-05-12 14:25:40 --> Security Class Initialized
DEBUG - 2025-05-12 14:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 14:25:40 --> Input Class Initialized
INFO - 2025-05-12 14:25:40 --> Language Class Initialized
INFO - 2025-05-12 14:25:40 --> Loader Class Initialized
INFO - 2025-05-12 14:25:40 --> Helper loaded: url_helper
INFO - 2025-05-12 14:25:40 --> Helper loaded: form_helper
INFO - 2025-05-12 14:25:41 --> Database Driver Class Initialized
DEBUG - 2025-05-12 14:25:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 14:25:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 14:25:41 --> Controller Class Initialized
INFO - 2025-05-12 14:25:41 --> Model "User_model" initialized
INFO - 2025-05-12 14:25:41 --> Config Class Initialized
INFO - 2025-05-12 14:25:41 --> Hooks Class Initialized
DEBUG - 2025-05-12 14:25:41 --> UTF-8 Support Enabled
INFO - 2025-05-12 14:25:41 --> Utf8 Class Initialized
INFO - 2025-05-12 14:25:41 --> URI Class Initialized
INFO - 2025-05-12 14:25:41 --> Router Class Initialized
INFO - 2025-05-12 14:25:41 --> Output Class Initialized
INFO - 2025-05-12 14:25:41 --> Security Class Initialized
DEBUG - 2025-05-12 14:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 14:25:41 --> Input Class Initialized
INFO - 2025-05-12 14:25:41 --> Language Class Initialized
INFO - 2025-05-12 14:25:41 --> Loader Class Initialized
INFO - 2025-05-12 14:25:41 --> Helper loaded: url_helper
INFO - 2025-05-12 14:25:41 --> Helper loaded: form_helper
INFO - 2025-05-12 14:25:41 --> Database Driver Class Initialized
DEBUG - 2025-05-12 14:25:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 14:25:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 14:25:41 --> Controller Class Initialized
INFO - 2025-05-12 14:25:41 --> Model "User_model" initialized
INFO - 2025-05-12 14:25:41 --> Model "Workout_model" initialized
INFO - 2025-05-12 14:25:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 14:25:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 14:25:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-12 14:25:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 14:25:41 --> Final output sent to browser
DEBUG - 2025-05-12 14:25:41 --> Total execution time: 0.0954
INFO - 2025-05-12 14:25:52 --> Config Class Initialized
INFO - 2025-05-12 14:25:52 --> Hooks Class Initialized
DEBUG - 2025-05-12 14:25:52 --> UTF-8 Support Enabled
INFO - 2025-05-12 14:25:52 --> Utf8 Class Initialized
INFO - 2025-05-12 14:25:52 --> URI Class Initialized
INFO - 2025-05-12 14:25:52 --> Router Class Initialized
INFO - 2025-05-12 14:25:52 --> Output Class Initialized
INFO - 2025-05-12 14:25:52 --> Security Class Initialized
DEBUG - 2025-05-12 14:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 14:25:52 --> Input Class Initialized
INFO - 2025-05-12 14:25:52 --> Language Class Initialized
INFO - 2025-05-12 14:25:53 --> Loader Class Initialized
INFO - 2025-05-12 14:25:53 --> Helper loaded: url_helper
INFO - 2025-05-12 14:25:53 --> Helper loaded: form_helper
INFO - 2025-05-12 14:25:53 --> Database Driver Class Initialized
DEBUG - 2025-05-12 14:25:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 14:25:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 14:25:53 --> Controller Class Initialized
INFO - 2025-05-12 14:25:53 --> Model "User_model" initialized
INFO - 2025-05-12 14:25:53 --> Model "Workout_model" initialized
INFO - 2025-05-12 14:25:53 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 14:25:53 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 14:25:53 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-12 14:25:53 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 14:25:53 --> Final output sent to browser
DEBUG - 2025-05-12 14:25:53 --> Total execution time: 0.1072
INFO - 2025-05-12 14:26:04 --> Config Class Initialized
INFO - 2025-05-12 14:26:04 --> Hooks Class Initialized
DEBUG - 2025-05-12 14:26:04 --> UTF-8 Support Enabled
INFO - 2025-05-12 14:26:04 --> Utf8 Class Initialized
INFO - 2025-05-12 14:26:04 --> URI Class Initialized
INFO - 2025-05-12 14:26:04 --> Router Class Initialized
INFO - 2025-05-12 14:26:04 --> Output Class Initialized
INFO - 2025-05-12 14:26:04 --> Security Class Initialized
DEBUG - 2025-05-12 14:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 14:26:04 --> Input Class Initialized
INFO - 2025-05-12 14:26:04 --> Language Class Initialized
INFO - 2025-05-12 14:26:04 --> Loader Class Initialized
INFO - 2025-05-12 14:26:04 --> Helper loaded: url_helper
INFO - 2025-05-12 14:26:04 --> Helper loaded: form_helper
INFO - 2025-05-12 14:26:04 --> Database Driver Class Initialized
DEBUG - 2025-05-12 14:26:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 14:26:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 14:26:04 --> Controller Class Initialized
INFO - 2025-05-12 14:26:04 --> Model "User_model" initialized
INFO - 2025-05-12 14:26:04 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 14:26:04 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 14:26:04 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/profile.php
INFO - 2025-05-12 14:26:04 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 14:26:04 --> Final output sent to browser
DEBUG - 2025-05-12 14:26:04 --> Total execution time: 0.0696
INFO - 2025-05-12 14:26:09 --> Config Class Initialized
INFO - 2025-05-12 14:26:09 --> Hooks Class Initialized
DEBUG - 2025-05-12 14:26:09 --> UTF-8 Support Enabled
INFO - 2025-05-12 14:26:09 --> Utf8 Class Initialized
INFO - 2025-05-12 14:26:09 --> URI Class Initialized
INFO - 2025-05-12 14:26:09 --> Router Class Initialized
INFO - 2025-05-12 14:26:09 --> Output Class Initialized
INFO - 2025-05-12 14:26:09 --> Security Class Initialized
DEBUG - 2025-05-12 14:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 14:26:09 --> Input Class Initialized
INFO - 2025-05-12 14:26:09 --> Language Class Initialized
INFO - 2025-05-12 14:26:09 --> Loader Class Initialized
INFO - 2025-05-12 14:26:09 --> Helper loaded: url_helper
INFO - 2025-05-12 14:26:09 --> Helper loaded: form_helper
INFO - 2025-05-12 14:26:09 --> Database Driver Class Initialized
DEBUG - 2025-05-12 14:26:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 14:26:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 14:26:09 --> Controller Class Initialized
INFO - 2025-05-12 14:26:09 --> Model "User_model" initialized
INFO - 2025-05-12 14:26:09 --> Config Class Initialized
INFO - 2025-05-12 14:26:09 --> Hooks Class Initialized
DEBUG - 2025-05-12 14:26:09 --> UTF-8 Support Enabled
INFO - 2025-05-12 14:26:09 --> Utf8 Class Initialized
INFO - 2025-05-12 14:26:09 --> URI Class Initialized
INFO - 2025-05-12 14:26:09 --> Router Class Initialized
INFO - 2025-05-12 14:26:09 --> Output Class Initialized
INFO - 2025-05-12 14:26:09 --> Security Class Initialized
DEBUG - 2025-05-12 14:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 14:26:09 --> Input Class Initialized
INFO - 2025-05-12 14:26:09 --> Language Class Initialized
INFO - 2025-05-12 14:26:09 --> Loader Class Initialized
INFO - 2025-05-12 14:26:09 --> Helper loaded: url_helper
INFO - 2025-05-12 14:26:09 --> Helper loaded: form_helper
INFO - 2025-05-12 14:26:09 --> Database Driver Class Initialized
DEBUG - 2025-05-12 14:26:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 14:26:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 14:26:09 --> Controller Class Initialized
INFO - 2025-05-12 14:26:09 --> Model "User_model" initialized
INFO - 2025-05-12 14:26:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-12 14:26:09 --> Final output sent to browser
DEBUG - 2025-05-12 14:26:09 --> Total execution time: 0.0853
INFO - 2025-05-12 14:26:14 --> Config Class Initialized
INFO - 2025-05-12 14:26:14 --> Hooks Class Initialized
DEBUG - 2025-05-12 14:26:14 --> UTF-8 Support Enabled
INFO - 2025-05-12 14:26:14 --> Utf8 Class Initialized
INFO - 2025-05-12 14:26:14 --> URI Class Initialized
INFO - 2025-05-12 14:26:14 --> Router Class Initialized
INFO - 2025-05-12 14:26:14 --> Output Class Initialized
INFO - 2025-05-12 14:26:14 --> Security Class Initialized
DEBUG - 2025-05-12 14:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 14:26:14 --> Input Class Initialized
INFO - 2025-05-12 14:26:14 --> Language Class Initialized
INFO - 2025-05-12 14:26:14 --> Loader Class Initialized
INFO - 2025-05-12 14:26:14 --> Helper loaded: url_helper
INFO - 2025-05-12 14:26:15 --> Helper loaded: form_helper
INFO - 2025-05-12 14:26:15 --> Database Driver Class Initialized
DEBUG - 2025-05-12 14:26:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 14:26:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 14:26:15 --> Controller Class Initialized
INFO - 2025-05-12 14:26:15 --> Model "User_model" initialized
INFO - 2025-05-12 14:26:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-12 14:26:15 --> Final output sent to browser
DEBUG - 2025-05-12 14:26:15 --> Total execution time: 0.0827
INFO - 2025-05-12 14:26:26 --> Config Class Initialized
INFO - 2025-05-12 14:26:26 --> Hooks Class Initialized
DEBUG - 2025-05-12 14:26:26 --> UTF-8 Support Enabled
INFO - 2025-05-12 14:26:26 --> Utf8 Class Initialized
INFO - 2025-05-12 14:26:26 --> URI Class Initialized
INFO - 2025-05-12 14:26:26 --> Router Class Initialized
INFO - 2025-05-12 14:26:26 --> Output Class Initialized
INFO - 2025-05-12 14:26:26 --> Security Class Initialized
DEBUG - 2025-05-12 14:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 14:26:26 --> Input Class Initialized
INFO - 2025-05-12 14:26:26 --> Language Class Initialized
INFO - 2025-05-12 14:26:26 --> Loader Class Initialized
INFO - 2025-05-12 14:26:26 --> Helper loaded: url_helper
INFO - 2025-05-12 14:26:26 --> Helper loaded: form_helper
INFO - 2025-05-12 14:26:26 --> Database Driver Class Initialized
DEBUG - 2025-05-12 14:26:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 14:26:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 14:26:26 --> Controller Class Initialized
INFO - 2025-05-12 14:26:26 --> Model "User_model" initialized
INFO - 2025-05-12 14:26:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-12 14:26:26 --> Final output sent to browser
DEBUG - 2025-05-12 14:26:26 --> Total execution time: 0.0810
INFO - 2025-05-12 14:26:37 --> Config Class Initialized
INFO - 2025-05-12 14:26:37 --> Hooks Class Initialized
DEBUG - 2025-05-12 14:26:37 --> UTF-8 Support Enabled
INFO - 2025-05-12 14:26:37 --> Utf8 Class Initialized
INFO - 2025-05-12 14:26:37 --> URI Class Initialized
INFO - 2025-05-12 14:26:37 --> Router Class Initialized
INFO - 2025-05-12 14:26:37 --> Output Class Initialized
INFO - 2025-05-12 14:26:37 --> Security Class Initialized
DEBUG - 2025-05-12 14:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 14:26:37 --> Input Class Initialized
INFO - 2025-05-12 14:26:37 --> Language Class Initialized
INFO - 2025-05-12 14:26:37 --> Loader Class Initialized
INFO - 2025-05-12 14:26:37 --> Helper loaded: url_helper
INFO - 2025-05-12 14:26:37 --> Helper loaded: form_helper
INFO - 2025-05-12 14:26:37 --> Database Driver Class Initialized
DEBUG - 2025-05-12 14:26:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 14:26:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 14:26:37 --> Controller Class Initialized
INFO - 2025-05-12 14:26:37 --> Model "User_model" initialized
INFO - 2025-05-12 14:26:37 --> Config Class Initialized
INFO - 2025-05-12 14:26:37 --> Hooks Class Initialized
DEBUG - 2025-05-12 14:26:37 --> UTF-8 Support Enabled
INFO - 2025-05-12 14:26:37 --> Utf8 Class Initialized
INFO - 2025-05-12 14:26:37 --> URI Class Initialized
INFO - 2025-05-12 14:26:37 --> Router Class Initialized
INFO - 2025-05-12 14:26:37 --> Output Class Initialized
INFO - 2025-05-12 14:26:37 --> Security Class Initialized
DEBUG - 2025-05-12 14:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 14:26:37 --> Input Class Initialized
INFO - 2025-05-12 14:26:37 --> Language Class Initialized
INFO - 2025-05-12 14:26:37 --> Loader Class Initialized
INFO - 2025-05-12 14:26:37 --> Helper loaded: url_helper
INFO - 2025-05-12 14:26:37 --> Helper loaded: form_helper
INFO - 2025-05-12 14:26:37 --> Database Driver Class Initialized
DEBUG - 2025-05-12 14:26:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 14:26:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 14:26:37 --> Controller Class Initialized
INFO - 2025-05-12 14:26:37 --> Model "User_model" initialized
INFO - 2025-05-12 14:26:37 --> Model "Workout_model" initialized
INFO - 2025-05-12 14:26:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 14:26:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 14:26:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-12 14:26:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 14:26:37 --> Final output sent to browser
DEBUG - 2025-05-12 14:26:37 --> Total execution time: 0.0998
INFO - 2025-05-12 14:32:29 --> Config Class Initialized
INFO - 2025-05-12 14:32:29 --> Hooks Class Initialized
DEBUG - 2025-05-12 14:32:30 --> UTF-8 Support Enabled
INFO - 2025-05-12 14:32:30 --> Utf8 Class Initialized
INFO - 2025-05-12 14:32:30 --> URI Class Initialized
INFO - 2025-05-12 14:32:30 --> Router Class Initialized
INFO - 2025-05-12 14:32:30 --> Output Class Initialized
INFO - 2025-05-12 14:32:30 --> Security Class Initialized
DEBUG - 2025-05-12 14:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 14:32:30 --> Input Class Initialized
INFO - 2025-05-12 14:32:30 --> Language Class Initialized
INFO - 2025-05-12 14:32:30 --> Loader Class Initialized
INFO - 2025-05-12 14:32:30 --> Helper loaded: url_helper
INFO - 2025-05-12 14:32:30 --> Helper loaded: form_helper
INFO - 2025-05-12 14:32:30 --> Database Driver Class Initialized
DEBUG - 2025-05-12 14:32:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 14:32:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 14:32:30 --> Controller Class Initialized
INFO - 2025-05-12 14:32:30 --> Model "User_model" initialized
INFO - 2025-05-12 14:32:30 --> Model "Workout_model" initialized
INFO - 2025-05-12 14:32:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 14:32:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 14:32:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-12 14:32:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 14:32:30 --> Final output sent to browser
DEBUG - 2025-05-12 14:32:30 --> Total execution time: 0.0974
INFO - 2025-05-12 14:38:56 --> Config Class Initialized
INFO - 2025-05-12 14:38:56 --> Hooks Class Initialized
DEBUG - 2025-05-12 14:38:56 --> UTF-8 Support Enabled
INFO - 2025-05-12 14:38:56 --> Utf8 Class Initialized
INFO - 2025-05-12 14:38:56 --> URI Class Initialized
INFO - 2025-05-12 14:38:56 --> Router Class Initialized
INFO - 2025-05-12 14:38:56 --> Output Class Initialized
INFO - 2025-05-12 14:38:56 --> Security Class Initialized
DEBUG - 2025-05-12 14:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 14:38:56 --> Input Class Initialized
INFO - 2025-05-12 14:38:56 --> Language Class Initialized
INFO - 2025-05-12 14:38:56 --> Loader Class Initialized
INFO - 2025-05-12 14:38:56 --> Helper loaded: url_helper
INFO - 2025-05-12 14:38:56 --> Helper loaded: form_helper
INFO - 2025-05-12 14:38:56 --> Database Driver Class Initialized
DEBUG - 2025-05-12 14:38:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 14:38:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 14:38:56 --> Controller Class Initialized
INFO - 2025-05-12 14:38:56 --> Model "User_model" initialized
INFO - 2025-05-12 14:38:56 --> Model "Workout_model" initialized
INFO - 2025-05-12 14:38:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 14:38:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 14:38:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-12 14:38:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 14:38:56 --> Final output sent to browser
DEBUG - 2025-05-12 14:38:56 --> Total execution time: 0.0880
INFO - 2025-05-12 14:39:59 --> Config Class Initialized
INFO - 2025-05-12 14:39:59 --> Hooks Class Initialized
DEBUG - 2025-05-12 14:39:59 --> UTF-8 Support Enabled
INFO - 2025-05-12 14:39:59 --> Utf8 Class Initialized
INFO - 2025-05-12 14:39:59 --> URI Class Initialized
INFO - 2025-05-12 14:39:59 --> Router Class Initialized
INFO - 2025-05-12 14:39:59 --> Output Class Initialized
INFO - 2025-05-12 14:39:59 --> Security Class Initialized
DEBUG - 2025-05-12 14:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 14:39:59 --> Input Class Initialized
INFO - 2025-05-12 14:39:59 --> Language Class Initialized
INFO - 2025-05-12 14:39:59 --> Loader Class Initialized
INFO - 2025-05-12 14:39:59 --> Helper loaded: url_helper
INFO - 2025-05-12 14:39:59 --> Helper loaded: form_helper
INFO - 2025-05-12 14:39:59 --> Database Driver Class Initialized
DEBUG - 2025-05-12 14:39:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 14:39:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 14:39:59 --> Controller Class Initialized
INFO - 2025-05-12 14:39:59 --> Model "User_model" initialized
INFO - 2025-05-12 14:39:59 --> Model "Workout_model" initialized
INFO - 2025-05-12 14:39:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 14:39:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 14:39:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-12 14:39:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 14:39:59 --> Final output sent to browser
DEBUG - 2025-05-12 14:39:59 --> Total execution time: 0.1075
INFO - 2025-05-12 15:04:28 --> Config Class Initialized
INFO - 2025-05-12 15:04:28 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:04:28 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:04:28 --> Utf8 Class Initialized
INFO - 2025-05-12 15:04:28 --> URI Class Initialized
INFO - 2025-05-12 15:04:28 --> Router Class Initialized
INFO - 2025-05-12 15:04:28 --> Output Class Initialized
INFO - 2025-05-12 15:04:28 --> Security Class Initialized
DEBUG - 2025-05-12 15:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:04:28 --> Input Class Initialized
INFO - 2025-05-12 15:04:28 --> Language Class Initialized
INFO - 2025-05-12 15:04:28 --> Loader Class Initialized
INFO - 2025-05-12 15:04:28 --> Helper loaded: url_helper
INFO - 2025-05-12 15:04:28 --> Helper loaded: form_helper
INFO - 2025-05-12 15:04:28 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:04:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:04:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:04:28 --> Controller Class Initialized
INFO - 2025-05-12 15:04:28 --> Model "User_model" initialized
INFO - 2025-05-12 15:04:28 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:04:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:04:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:04:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-12 15:04:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:04:28 --> Final output sent to browser
DEBUG - 2025-05-12 15:04:28 --> Total execution time: 0.1127
INFO - 2025-05-12 15:04:29 --> Config Class Initialized
INFO - 2025-05-12 15:04:29 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:04:29 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:04:29 --> Utf8 Class Initialized
INFO - 2025-05-12 15:04:29 --> URI Class Initialized
INFO - 2025-05-12 15:04:29 --> Router Class Initialized
INFO - 2025-05-12 15:04:29 --> Output Class Initialized
INFO - 2025-05-12 15:04:29 --> Security Class Initialized
DEBUG - 2025-05-12 15:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:04:29 --> Input Class Initialized
INFO - 2025-05-12 15:04:29 --> Language Class Initialized
INFO - 2025-05-12 15:04:29 --> Loader Class Initialized
INFO - 2025-05-12 15:04:29 --> Helper loaded: url_helper
INFO - 2025-05-12 15:04:29 --> Helper loaded: form_helper
INFO - 2025-05-12 15:04:29 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:04:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:04:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:04:29 --> Controller Class Initialized
INFO - 2025-05-12 15:04:29 --> Model "User_model" initialized
INFO - 2025-05-12 15:04:29 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:04:29 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:04:29 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:04:29 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-12 15:04:29 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:04:29 --> Final output sent to browser
DEBUG - 2025-05-12 15:04:29 --> Total execution time: 0.0817
INFO - 2025-05-12 15:04:42 --> Config Class Initialized
INFO - 2025-05-12 15:04:42 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:04:42 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:04:42 --> Utf8 Class Initialized
INFO - 2025-05-12 15:04:42 --> URI Class Initialized
INFO - 2025-05-12 15:04:42 --> Router Class Initialized
INFO - 2025-05-12 15:04:42 --> Output Class Initialized
INFO - 2025-05-12 15:04:42 --> Security Class Initialized
DEBUG - 2025-05-12 15:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:04:42 --> Input Class Initialized
INFO - 2025-05-12 15:04:42 --> Language Class Initialized
INFO - 2025-05-12 15:04:42 --> Loader Class Initialized
INFO - 2025-05-12 15:04:42 --> Helper loaded: url_helper
INFO - 2025-05-12 15:04:42 --> Helper loaded: form_helper
INFO - 2025-05-12 15:04:42 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:04:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:04:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:04:42 --> Controller Class Initialized
INFO - 2025-05-12 15:04:42 --> Model "User_model" initialized
INFO - 2025-05-12 15:04:42 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:04:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:04:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:04:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-12 15:04:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:04:42 --> Final output sent to browser
DEBUG - 2025-05-12 15:04:42 --> Total execution time: 0.1544
INFO - 2025-05-12 15:04:53 --> Config Class Initialized
INFO - 2025-05-12 15:04:53 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:04:53 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:04:53 --> Utf8 Class Initialized
INFO - 2025-05-12 15:04:53 --> URI Class Initialized
INFO - 2025-05-12 15:04:53 --> Router Class Initialized
INFO - 2025-05-12 15:04:53 --> Output Class Initialized
INFO - 2025-05-12 15:04:53 --> Security Class Initialized
DEBUG - 2025-05-12 15:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:04:53 --> Input Class Initialized
INFO - 2025-05-12 15:04:53 --> Language Class Initialized
INFO - 2025-05-12 15:04:53 --> Loader Class Initialized
INFO - 2025-05-12 15:04:53 --> Helper loaded: url_helper
INFO - 2025-05-12 15:04:53 --> Helper loaded: form_helper
INFO - 2025-05-12 15:04:53 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:04:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:04:53 --> Controller Class Initialized
INFO - 2025-05-12 15:04:53 --> Model "User_model" initialized
INFO - 2025-05-12 15:04:53 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:04:53 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:04:53 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:04:53 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-12 15:04:53 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:04:53 --> Final output sent to browser
DEBUG - 2025-05-12 15:04:53 --> Total execution time: 0.1152
INFO - 2025-05-12 15:05:24 --> Config Class Initialized
INFO - 2025-05-12 15:05:24 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:05:24 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:05:24 --> Utf8 Class Initialized
INFO - 2025-05-12 15:05:24 --> URI Class Initialized
INFO - 2025-05-12 15:05:24 --> Router Class Initialized
INFO - 2025-05-12 15:05:24 --> Output Class Initialized
INFO - 2025-05-12 15:05:24 --> Security Class Initialized
DEBUG - 2025-05-12 15:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:05:24 --> Input Class Initialized
INFO - 2025-05-12 15:05:24 --> Language Class Initialized
INFO - 2025-05-12 15:05:24 --> Loader Class Initialized
INFO - 2025-05-12 15:05:24 --> Helper loaded: url_helper
INFO - 2025-05-12 15:05:24 --> Helper loaded: form_helper
INFO - 2025-05-12 15:05:24 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:05:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:05:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:05:24 --> Controller Class Initialized
INFO - 2025-05-12 15:05:24 --> Model "User_model" initialized
INFO - 2025-05-12 15:05:24 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:05:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:05:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:05:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-12 15:05:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:05:24 --> Final output sent to browser
DEBUG - 2025-05-12 15:05:24 --> Total execution time: 0.0957
INFO - 2025-05-12 15:27:15 --> Config Class Initialized
INFO - 2025-05-12 15:27:15 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:27:15 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:27:15 --> Utf8 Class Initialized
INFO - 2025-05-12 15:27:15 --> URI Class Initialized
INFO - 2025-05-12 15:27:15 --> Router Class Initialized
INFO - 2025-05-12 15:27:15 --> Output Class Initialized
INFO - 2025-05-12 15:27:15 --> Security Class Initialized
DEBUG - 2025-05-12 15:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:27:15 --> Input Class Initialized
INFO - 2025-05-12 15:27:15 --> Language Class Initialized
INFO - 2025-05-12 15:27:15 --> Loader Class Initialized
INFO - 2025-05-12 15:27:15 --> Helper loaded: url_helper
INFO - 2025-05-12 15:27:15 --> Helper loaded: form_helper
INFO - 2025-05-12 15:27:15 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:27:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:27:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:27:15 --> Controller Class Initialized
INFO - 2025-05-12 15:27:15 --> Model "User_model" initialized
INFO - 2025-05-12 15:27:15 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:27:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:27:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:27:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-12 15:27:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:27:15 --> Final output sent to browser
DEBUG - 2025-05-12 15:27:15 --> Total execution time: 0.0997
INFO - 2025-05-12 15:27:17 --> Config Class Initialized
INFO - 2025-05-12 15:27:17 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:27:17 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:27:17 --> Utf8 Class Initialized
INFO - 2025-05-12 15:27:17 --> URI Class Initialized
INFO - 2025-05-12 15:27:17 --> Router Class Initialized
INFO - 2025-05-12 15:27:17 --> Output Class Initialized
INFO - 2025-05-12 15:27:17 --> Security Class Initialized
DEBUG - 2025-05-12 15:27:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:27:17 --> Input Class Initialized
INFO - 2025-05-12 15:27:17 --> Language Class Initialized
INFO - 2025-05-12 15:27:17 --> Loader Class Initialized
INFO - 2025-05-12 15:27:17 --> Helper loaded: url_helper
INFO - 2025-05-12 15:27:17 --> Helper loaded: form_helper
INFO - 2025-05-12 15:27:17 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:27:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:27:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:27:17 --> Controller Class Initialized
INFO - 2025-05-12 15:27:17 --> Model "Workout_model" initialized
ERROR - 2025-05-12 15:27:17 --> Severity: Warning --> Undefined property: Workout::$User_model C:\laragon\www\Project\fitnessrecord\application\controllers\Workout.php 31
ERROR - 2025-05-12 15:27:17 --> Severity: error --> Exception: Call to a member function get_by_id() on null C:\laragon\www\Project\fitnessrecord\application\controllers\Workout.php 31
INFO - 2025-05-12 15:27:48 --> Config Class Initialized
INFO - 2025-05-12 15:27:48 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:27:48 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:27:48 --> Utf8 Class Initialized
INFO - 2025-05-12 15:27:48 --> URI Class Initialized
INFO - 2025-05-12 15:27:48 --> Router Class Initialized
INFO - 2025-05-12 15:27:48 --> Output Class Initialized
INFO - 2025-05-12 15:27:48 --> Security Class Initialized
DEBUG - 2025-05-12 15:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:27:48 --> Input Class Initialized
INFO - 2025-05-12 15:27:48 --> Language Class Initialized
INFO - 2025-05-12 15:27:48 --> Loader Class Initialized
INFO - 2025-05-12 15:27:48 --> Helper loaded: url_helper
INFO - 2025-05-12 15:27:48 --> Helper loaded: form_helper
INFO - 2025-05-12 15:27:48 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:27:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:27:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:27:48 --> Controller Class Initialized
INFO - 2025-05-12 15:27:48 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:27:48 --> Model "User_model" initialized
INFO - 2025-05-12 15:27:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:27:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:27:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-12 15:27:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:27:48 --> Final output sent to browser
DEBUG - 2025-05-12 15:27:48 --> Total execution time: 0.1074
INFO - 2025-05-12 15:28:22 --> Config Class Initialized
INFO - 2025-05-12 15:28:22 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:28:22 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:28:22 --> Utf8 Class Initialized
INFO - 2025-05-12 15:28:22 --> URI Class Initialized
INFO - 2025-05-12 15:28:22 --> Router Class Initialized
INFO - 2025-05-12 15:28:22 --> Output Class Initialized
INFO - 2025-05-12 15:28:22 --> Security Class Initialized
DEBUG - 2025-05-12 15:28:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:28:22 --> Input Class Initialized
INFO - 2025-05-12 15:28:22 --> Language Class Initialized
INFO - 2025-05-12 15:28:22 --> Loader Class Initialized
INFO - 2025-05-12 15:28:22 --> Helper loaded: url_helper
INFO - 2025-05-12 15:28:22 --> Helper loaded: form_helper
INFO - 2025-05-12 15:28:22 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:28:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:28:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:28:22 --> Controller Class Initialized
INFO - 2025-05-12 15:28:22 --> Model "User_model" initialized
INFO - 2025-05-12 15:28:22 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:28:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:28:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:28:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-12 15:28:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:28:22 --> Final output sent to browser
DEBUG - 2025-05-12 15:28:22 --> Total execution time: 0.1035
INFO - 2025-05-12 15:28:26 --> Config Class Initialized
INFO - 2025-05-12 15:28:26 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:28:26 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:28:26 --> Utf8 Class Initialized
INFO - 2025-05-12 15:28:26 --> URI Class Initialized
INFO - 2025-05-12 15:28:26 --> Router Class Initialized
INFO - 2025-05-12 15:28:26 --> Output Class Initialized
INFO - 2025-05-12 15:28:26 --> Security Class Initialized
DEBUG - 2025-05-12 15:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:28:26 --> Input Class Initialized
INFO - 2025-05-12 15:28:26 --> Language Class Initialized
INFO - 2025-05-12 15:28:26 --> Loader Class Initialized
INFO - 2025-05-12 15:28:26 --> Helper loaded: url_helper
INFO - 2025-05-12 15:28:26 --> Helper loaded: form_helper
INFO - 2025-05-12 15:28:26 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:28:26 --> Controller Class Initialized
INFO - 2025-05-12 15:28:26 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:28:26 --> Model "User_model" initialized
INFO - 2025-05-12 15:28:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:28:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:28:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-12 15:28:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:28:26 --> Final output sent to browser
DEBUG - 2025-05-12 15:28:26 --> Total execution time: 0.0909
INFO - 2025-05-12 15:28:28 --> Config Class Initialized
INFO - 2025-05-12 15:28:28 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:28:28 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:28:28 --> Utf8 Class Initialized
INFO - 2025-05-12 15:28:28 --> URI Class Initialized
INFO - 2025-05-12 15:28:28 --> Router Class Initialized
INFO - 2025-05-12 15:28:28 --> Output Class Initialized
INFO - 2025-05-12 15:28:28 --> Security Class Initialized
DEBUG - 2025-05-12 15:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:28:28 --> Input Class Initialized
INFO - 2025-05-12 15:28:28 --> Language Class Initialized
INFO - 2025-05-12 15:28:28 --> Loader Class Initialized
INFO - 2025-05-12 15:28:28 --> Helper loaded: url_helper
INFO - 2025-05-12 15:28:28 --> Helper loaded: form_helper
INFO - 2025-05-12 15:28:28 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:28:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:28:28 --> Controller Class Initialized
INFO - 2025-05-12 15:28:28 --> Model "User_model" initialized
INFO - 2025-05-12 15:28:28 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:28:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:28:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:28:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-12 15:28:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:28:28 --> Final output sent to browser
DEBUG - 2025-05-12 15:28:28 --> Total execution time: 0.0913
INFO - 2025-05-12 15:29:25 --> Config Class Initialized
INFO - 2025-05-12 15:29:25 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:29:25 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:29:25 --> Utf8 Class Initialized
INFO - 2025-05-12 15:29:25 --> URI Class Initialized
INFO - 2025-05-12 15:29:25 --> Router Class Initialized
INFO - 2025-05-12 15:29:25 --> Output Class Initialized
INFO - 2025-05-12 15:29:25 --> Security Class Initialized
DEBUG - 2025-05-12 15:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:29:25 --> Input Class Initialized
INFO - 2025-05-12 15:29:25 --> Language Class Initialized
INFO - 2025-05-12 15:29:25 --> Loader Class Initialized
INFO - 2025-05-12 15:29:25 --> Helper loaded: url_helper
INFO - 2025-05-12 15:29:25 --> Helper loaded: form_helper
INFO - 2025-05-12 15:29:25 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:29:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:29:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:29:25 --> Controller Class Initialized
INFO - 2025-05-12 15:29:25 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:29:25 --> Model "User_model" initialized
INFO - 2025-05-12 15:29:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:29:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:29:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-12 15:29:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:29:25 --> Final output sent to browser
DEBUG - 2025-05-12 15:29:25 --> Total execution time: 0.1131
INFO - 2025-05-12 15:30:04 --> Config Class Initialized
INFO - 2025-05-12 15:30:04 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:30:04 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:30:04 --> Utf8 Class Initialized
INFO - 2025-05-12 15:30:04 --> URI Class Initialized
INFO - 2025-05-12 15:30:04 --> Router Class Initialized
INFO - 2025-05-12 15:30:04 --> Output Class Initialized
INFO - 2025-05-12 15:30:04 --> Security Class Initialized
DEBUG - 2025-05-12 15:30:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:30:04 --> Input Class Initialized
INFO - 2025-05-12 15:30:04 --> Language Class Initialized
INFO - 2025-05-12 15:30:04 --> Loader Class Initialized
INFO - 2025-05-12 15:30:04 --> Helper loaded: url_helper
INFO - 2025-05-12 15:30:04 --> Helper loaded: form_helper
INFO - 2025-05-12 15:30:04 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:30:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:30:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:30:05 --> Controller Class Initialized
INFO - 2025-05-12 15:30:05 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:30:05 --> Model "User_model" initialized
INFO - 2025-05-12 15:30:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:30:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:30:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-12 15:30:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:30:05 --> Final output sent to browser
DEBUG - 2025-05-12 15:30:05 --> Total execution time: 0.1201
INFO - 2025-05-12 15:30:27 --> Config Class Initialized
INFO - 2025-05-12 15:30:27 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:30:27 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:30:27 --> Utf8 Class Initialized
INFO - 2025-05-12 15:30:27 --> URI Class Initialized
INFO - 2025-05-12 15:30:27 --> Router Class Initialized
INFO - 2025-05-12 15:30:27 --> Output Class Initialized
INFO - 2025-05-12 15:30:27 --> Security Class Initialized
DEBUG - 2025-05-12 15:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:30:27 --> Input Class Initialized
INFO - 2025-05-12 15:30:27 --> Language Class Initialized
INFO - 2025-05-12 15:30:27 --> Loader Class Initialized
INFO - 2025-05-12 15:30:27 --> Helper loaded: url_helper
INFO - 2025-05-12 15:30:27 --> Helper loaded: form_helper
INFO - 2025-05-12 15:30:27 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:30:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:30:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:30:27 --> Controller Class Initialized
INFO - 2025-05-12 15:30:27 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:30:27 --> Model "User_model" initialized
INFO - 2025-05-12 15:30:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:30:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:30:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-12 15:30:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:30:27 --> Final output sent to browser
DEBUG - 2025-05-12 15:30:27 --> Total execution time: 0.0994
INFO - 2025-05-12 15:30:29 --> Config Class Initialized
INFO - 2025-05-12 15:30:29 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:30:29 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:30:29 --> Utf8 Class Initialized
INFO - 2025-05-12 15:30:29 --> URI Class Initialized
INFO - 2025-05-12 15:30:29 --> Router Class Initialized
INFO - 2025-05-12 15:30:29 --> Output Class Initialized
INFO - 2025-05-12 15:30:29 --> Security Class Initialized
DEBUG - 2025-05-12 15:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:30:29 --> Input Class Initialized
INFO - 2025-05-12 15:30:29 --> Language Class Initialized
INFO - 2025-05-12 15:30:29 --> Loader Class Initialized
INFO - 2025-05-12 15:30:29 --> Helper loaded: url_helper
INFO - 2025-05-12 15:30:29 --> Helper loaded: form_helper
INFO - 2025-05-12 15:30:29 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:30:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:30:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:30:29 --> Controller Class Initialized
INFO - 2025-05-12 15:30:29 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:30:29 --> Model "User_model" initialized
INFO - 2025-05-12 15:30:29 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/add.php
INFO - 2025-05-12 15:30:29 --> Final output sent to browser
DEBUG - 2025-05-12 15:30:29 --> Total execution time: 0.1024
INFO - 2025-05-12 15:30:41 --> Config Class Initialized
INFO - 2025-05-12 15:30:41 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:30:41 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:30:41 --> Utf8 Class Initialized
INFO - 2025-05-12 15:30:41 --> URI Class Initialized
INFO - 2025-05-12 15:30:41 --> Router Class Initialized
INFO - 2025-05-12 15:30:41 --> Output Class Initialized
INFO - 2025-05-12 15:30:41 --> Security Class Initialized
DEBUG - 2025-05-12 15:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:30:41 --> Input Class Initialized
INFO - 2025-05-12 15:30:41 --> Language Class Initialized
INFO - 2025-05-12 15:30:41 --> Loader Class Initialized
INFO - 2025-05-12 15:30:41 --> Helper loaded: url_helper
INFO - 2025-05-12 15:30:41 --> Helper loaded: form_helper
INFO - 2025-05-12 15:30:41 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:30:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:30:41 --> Controller Class Initialized
INFO - 2025-05-12 15:30:41 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:30:41 --> Model "User_model" initialized
INFO - 2025-05-12 15:30:41 --> Config Class Initialized
INFO - 2025-05-12 15:30:41 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:30:41 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:30:41 --> Utf8 Class Initialized
INFO - 2025-05-12 15:30:41 --> URI Class Initialized
INFO - 2025-05-12 15:30:41 --> Router Class Initialized
INFO - 2025-05-12 15:30:41 --> Output Class Initialized
INFO - 2025-05-12 15:30:41 --> Security Class Initialized
DEBUG - 2025-05-12 15:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:30:41 --> Input Class Initialized
INFO - 2025-05-12 15:30:41 --> Language Class Initialized
INFO - 2025-05-12 15:30:41 --> Loader Class Initialized
INFO - 2025-05-12 15:30:41 --> Helper loaded: url_helper
INFO - 2025-05-12 15:30:41 --> Helper loaded: form_helper
INFO - 2025-05-12 15:30:41 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:30:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:30:41 --> Controller Class Initialized
INFO - 2025-05-12 15:30:41 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:30:41 --> Model "User_model" initialized
INFO - 2025-05-12 15:30:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:30:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:30:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-12 15:30:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:30:41 --> Final output sent to browser
DEBUG - 2025-05-12 15:30:41 --> Total execution time: 0.0961
INFO - 2025-05-12 15:32:56 --> Config Class Initialized
INFO - 2025-05-12 15:32:56 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:32:56 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:32:56 --> Utf8 Class Initialized
INFO - 2025-05-12 15:32:56 --> URI Class Initialized
INFO - 2025-05-12 15:32:56 --> Router Class Initialized
INFO - 2025-05-12 15:32:56 --> Output Class Initialized
INFO - 2025-05-12 15:32:56 --> Security Class Initialized
DEBUG - 2025-05-12 15:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:32:56 --> Input Class Initialized
INFO - 2025-05-12 15:32:56 --> Language Class Initialized
INFO - 2025-05-12 15:32:56 --> Loader Class Initialized
INFO - 2025-05-12 15:32:56 --> Helper loaded: url_helper
INFO - 2025-05-12 15:32:56 --> Helper loaded: form_helper
INFO - 2025-05-12 15:32:56 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:32:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:32:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:32:56 --> Controller Class Initialized
INFO - 2025-05-12 15:32:56 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:32:56 --> Model "User_model" initialized
INFO - 2025-05-12 15:32:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:32:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:32:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-12 15:32:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:32:56 --> Final output sent to browser
DEBUG - 2025-05-12 15:32:56 --> Total execution time: 0.1273
INFO - 2025-05-12 15:33:55 --> Config Class Initialized
INFO - 2025-05-12 15:33:55 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:33:55 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:33:55 --> Utf8 Class Initialized
INFO - 2025-05-12 15:33:55 --> URI Class Initialized
INFO - 2025-05-12 15:33:55 --> Router Class Initialized
INFO - 2025-05-12 15:33:55 --> Output Class Initialized
INFO - 2025-05-12 15:33:55 --> Security Class Initialized
DEBUG - 2025-05-12 15:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:33:55 --> Input Class Initialized
INFO - 2025-05-12 15:33:55 --> Language Class Initialized
INFO - 2025-05-12 15:33:55 --> Loader Class Initialized
INFO - 2025-05-12 15:33:55 --> Helper loaded: url_helper
INFO - 2025-05-12 15:33:55 --> Helper loaded: form_helper
INFO - 2025-05-12 15:33:55 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:33:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:33:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:33:55 --> Controller Class Initialized
INFO - 2025-05-12 15:33:55 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:33:55 --> Model "User_model" initialized
INFO - 2025-05-12 15:33:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:33:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:33:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-12 15:33:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:33:55 --> Final output sent to browser
DEBUG - 2025-05-12 15:33:55 --> Total execution time: 0.1243
INFO - 2025-05-12 15:34:30 --> Config Class Initialized
INFO - 2025-05-12 15:34:30 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:34:30 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:34:30 --> Utf8 Class Initialized
INFO - 2025-05-12 15:34:30 --> URI Class Initialized
INFO - 2025-05-12 15:34:30 --> Router Class Initialized
INFO - 2025-05-12 15:34:30 --> Output Class Initialized
INFO - 2025-05-12 15:34:30 --> Security Class Initialized
DEBUG - 2025-05-12 15:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:34:30 --> Input Class Initialized
INFO - 2025-05-12 15:34:30 --> Language Class Initialized
INFO - 2025-05-12 15:34:30 --> Loader Class Initialized
INFO - 2025-05-12 15:34:30 --> Helper loaded: url_helper
INFO - 2025-05-12 15:34:30 --> Helper loaded: form_helper
INFO - 2025-05-12 15:34:30 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:34:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:34:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:34:30 --> Controller Class Initialized
INFO - 2025-05-12 15:34:30 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:34:30 --> Model "User_model" initialized
INFO - 2025-05-12 15:34:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:34:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:34:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-12 15:34:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:34:30 --> Final output sent to browser
DEBUG - 2025-05-12 15:34:30 --> Total execution time: 0.0978
INFO - 2025-05-12 15:34:47 --> Config Class Initialized
INFO - 2025-05-12 15:34:47 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:34:47 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:34:47 --> Utf8 Class Initialized
INFO - 2025-05-12 15:34:47 --> URI Class Initialized
INFO - 2025-05-12 15:34:47 --> Router Class Initialized
INFO - 2025-05-12 15:34:47 --> Output Class Initialized
INFO - 2025-05-12 15:34:47 --> Security Class Initialized
DEBUG - 2025-05-12 15:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:34:47 --> Input Class Initialized
INFO - 2025-05-12 15:34:47 --> Language Class Initialized
INFO - 2025-05-12 15:34:47 --> Loader Class Initialized
INFO - 2025-05-12 15:34:47 --> Helper loaded: url_helper
INFO - 2025-05-12 15:34:47 --> Helper loaded: form_helper
INFO - 2025-05-12 15:34:47 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:34:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:34:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:34:47 --> Controller Class Initialized
INFO - 2025-05-12 15:34:47 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:34:47 --> Model "User_model" initialized
INFO - 2025-05-12 15:34:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:34:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:34:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-12 15:34:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:34:47 --> Final output sent to browser
DEBUG - 2025-05-12 15:34:47 --> Total execution time: 0.0859
INFO - 2025-05-12 15:35:04 --> Config Class Initialized
INFO - 2025-05-12 15:35:04 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:35:04 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:35:04 --> Utf8 Class Initialized
INFO - 2025-05-12 15:35:04 --> URI Class Initialized
INFO - 2025-05-12 15:35:04 --> Router Class Initialized
INFO - 2025-05-12 15:35:04 --> Output Class Initialized
INFO - 2025-05-12 15:35:04 --> Security Class Initialized
DEBUG - 2025-05-12 15:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:35:04 --> Input Class Initialized
INFO - 2025-05-12 15:35:04 --> Language Class Initialized
INFO - 2025-05-12 15:35:04 --> Loader Class Initialized
INFO - 2025-05-12 15:35:04 --> Helper loaded: url_helper
INFO - 2025-05-12 15:35:04 --> Helper loaded: form_helper
INFO - 2025-05-12 15:35:04 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:35:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:35:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:35:04 --> Controller Class Initialized
INFO - 2025-05-12 15:35:04 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:35:04 --> Model "User_model" initialized
INFO - 2025-05-12 15:35:04 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:35:04 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:35:04 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-12 15:35:04 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:35:04 --> Final output sent to browser
DEBUG - 2025-05-12 15:35:04 --> Total execution time: 0.1205
INFO - 2025-05-12 15:35:25 --> Config Class Initialized
INFO - 2025-05-12 15:35:25 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:35:25 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:35:25 --> Utf8 Class Initialized
INFO - 2025-05-12 15:35:25 --> URI Class Initialized
INFO - 2025-05-12 15:35:25 --> Router Class Initialized
INFO - 2025-05-12 15:35:25 --> Output Class Initialized
INFO - 2025-05-12 15:35:25 --> Security Class Initialized
DEBUG - 2025-05-12 15:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:35:25 --> Input Class Initialized
INFO - 2025-05-12 15:35:25 --> Language Class Initialized
INFO - 2025-05-12 15:35:25 --> Loader Class Initialized
INFO - 2025-05-12 15:35:25 --> Helper loaded: url_helper
INFO - 2025-05-12 15:35:25 --> Helper loaded: form_helper
INFO - 2025-05-12 15:35:25 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:35:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:35:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:35:25 --> Controller Class Initialized
INFO - 2025-05-12 15:35:25 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:35:25 --> Model "User_model" initialized
INFO - 2025-05-12 15:35:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:35:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:35:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-12 15:35:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:35:25 --> Final output sent to browser
DEBUG - 2025-05-12 15:35:25 --> Total execution time: 0.0900
INFO - 2025-05-12 15:35:32 --> Config Class Initialized
INFO - 2025-05-12 15:35:32 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:35:32 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:35:32 --> Utf8 Class Initialized
INFO - 2025-05-12 15:35:32 --> URI Class Initialized
INFO - 2025-05-12 15:35:32 --> Router Class Initialized
INFO - 2025-05-12 15:35:32 --> Output Class Initialized
INFO - 2025-05-12 15:35:32 --> Security Class Initialized
DEBUG - 2025-05-12 15:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:35:32 --> Input Class Initialized
INFO - 2025-05-12 15:35:32 --> Language Class Initialized
INFO - 2025-05-12 15:35:32 --> Loader Class Initialized
INFO - 2025-05-12 15:35:32 --> Helper loaded: url_helper
INFO - 2025-05-12 15:35:32 --> Helper loaded: form_helper
INFO - 2025-05-12 15:35:32 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:35:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:35:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:35:32 --> Controller Class Initialized
INFO - 2025-05-12 15:35:32 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:35:32 --> Model "User_model" initialized
INFO - 2025-05-12 15:35:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:35:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:35:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-12 15:35:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:35:32 --> Final output sent to browser
DEBUG - 2025-05-12 15:35:32 --> Total execution time: 0.1245
INFO - 2025-05-12 15:35:45 --> Config Class Initialized
INFO - 2025-05-12 15:35:45 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:35:45 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:35:45 --> Utf8 Class Initialized
INFO - 2025-05-12 15:35:45 --> URI Class Initialized
INFO - 2025-05-12 15:35:45 --> Router Class Initialized
INFO - 2025-05-12 15:35:45 --> Output Class Initialized
INFO - 2025-05-12 15:35:45 --> Security Class Initialized
DEBUG - 2025-05-12 15:35:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:35:45 --> Input Class Initialized
INFO - 2025-05-12 15:35:45 --> Language Class Initialized
INFO - 2025-05-12 15:35:45 --> Loader Class Initialized
INFO - 2025-05-12 15:35:45 --> Helper loaded: url_helper
INFO - 2025-05-12 15:35:45 --> Helper loaded: form_helper
INFO - 2025-05-12 15:35:45 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:35:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:35:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:35:45 --> Controller Class Initialized
INFO - 2025-05-12 15:35:45 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:35:45 --> Model "User_model" initialized
INFO - 2025-05-12 15:35:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:35:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:35:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-12 15:35:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:35:45 --> Final output sent to browser
DEBUG - 2025-05-12 15:35:45 --> Total execution time: 0.0988
INFO - 2025-05-12 15:37:55 --> Config Class Initialized
INFO - 2025-05-12 15:37:55 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:37:55 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:37:55 --> Utf8 Class Initialized
INFO - 2025-05-12 15:37:55 --> URI Class Initialized
INFO - 2025-05-12 15:37:55 --> Router Class Initialized
INFO - 2025-05-12 15:37:55 --> Output Class Initialized
INFO - 2025-05-12 15:37:55 --> Security Class Initialized
DEBUG - 2025-05-12 15:37:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:37:55 --> Input Class Initialized
INFO - 2025-05-12 15:37:55 --> Language Class Initialized
INFO - 2025-05-12 15:37:55 --> Loader Class Initialized
INFO - 2025-05-12 15:37:55 --> Helper loaded: url_helper
INFO - 2025-05-12 15:37:55 --> Helper loaded: form_helper
INFO - 2025-05-12 15:37:55 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:37:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:37:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:37:56 --> Controller Class Initialized
INFO - 2025-05-12 15:37:56 --> Model "User_model" initialized
INFO - 2025-05-12 15:37:56 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:37:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:37:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:37:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-12 15:37:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:37:56 --> Final output sent to browser
DEBUG - 2025-05-12 15:37:56 --> Total execution time: 0.1039
INFO - 2025-05-12 15:37:59 --> Config Class Initialized
INFO - 2025-05-12 15:37:59 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:37:59 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:37:59 --> Utf8 Class Initialized
INFO - 2025-05-12 15:37:59 --> URI Class Initialized
INFO - 2025-05-12 15:37:59 --> Router Class Initialized
INFO - 2025-05-12 15:37:59 --> Output Class Initialized
INFO - 2025-05-12 15:37:59 --> Security Class Initialized
DEBUG - 2025-05-12 15:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:37:59 --> Input Class Initialized
INFO - 2025-05-12 15:37:59 --> Language Class Initialized
INFO - 2025-05-12 15:37:59 --> Loader Class Initialized
INFO - 2025-05-12 15:37:59 --> Helper loaded: url_helper
INFO - 2025-05-12 15:38:00 --> Helper loaded: form_helper
INFO - 2025-05-12 15:38:00 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:38:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:38:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:38:00 --> Controller Class Initialized
INFO - 2025-05-12 15:38:00 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:38:00 --> Model "User_model" initialized
INFO - 2025-05-12 15:38:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:38:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:38:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-12 15:38:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:38:00 --> Final output sent to browser
DEBUG - 2025-05-12 15:38:00 --> Total execution time: 0.1027
INFO - 2025-05-12 15:38:01 --> Config Class Initialized
INFO - 2025-05-12 15:38:01 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:38:01 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:38:01 --> Utf8 Class Initialized
INFO - 2025-05-12 15:38:01 --> URI Class Initialized
INFO - 2025-05-12 15:38:01 --> Router Class Initialized
INFO - 2025-05-12 15:38:01 --> Output Class Initialized
INFO - 2025-05-12 15:38:01 --> Security Class Initialized
DEBUG - 2025-05-12 15:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:38:01 --> Input Class Initialized
INFO - 2025-05-12 15:38:01 --> Language Class Initialized
INFO - 2025-05-12 15:38:01 --> Loader Class Initialized
INFO - 2025-05-12 15:38:01 --> Helper loaded: url_helper
INFO - 2025-05-12 15:38:01 --> Helper loaded: form_helper
INFO - 2025-05-12 15:38:01 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:38:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:38:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:38:01 --> Controller Class Initialized
INFO - 2025-05-12 15:38:01 --> Model "User_model" initialized
INFO - 2025-05-12 15:38:01 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:38:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:38:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:38:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-12 15:38:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:38:01 --> Final output sent to browser
DEBUG - 2025-05-12 15:38:01 --> Total execution time: 0.1333
INFO - 2025-05-12 15:38:02 --> Config Class Initialized
INFO - 2025-05-12 15:38:02 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:38:02 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:38:02 --> Utf8 Class Initialized
INFO - 2025-05-12 15:38:02 --> URI Class Initialized
INFO - 2025-05-12 15:38:02 --> Router Class Initialized
INFO - 2025-05-12 15:38:02 --> Output Class Initialized
INFO - 2025-05-12 15:38:02 --> Security Class Initialized
DEBUG - 2025-05-12 15:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:38:02 --> Input Class Initialized
INFO - 2025-05-12 15:38:02 --> Language Class Initialized
INFO - 2025-05-12 15:38:02 --> Loader Class Initialized
INFO - 2025-05-12 15:38:02 --> Helper loaded: url_helper
INFO - 2025-05-12 15:38:02 --> Helper loaded: form_helper
INFO - 2025-05-12 15:38:02 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:38:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:38:02 --> Controller Class Initialized
INFO - 2025-05-12 15:38:02 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:38:02 --> Model "User_model" initialized
INFO - 2025-05-12 15:38:02 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:38:02 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:38:02 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-12 15:38:02 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:38:02 --> Final output sent to browser
DEBUG - 2025-05-12 15:38:02 --> Total execution time: 0.1191
INFO - 2025-05-12 15:38:04 --> Config Class Initialized
INFO - 2025-05-12 15:38:04 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:38:04 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:38:04 --> Utf8 Class Initialized
INFO - 2025-05-12 15:38:04 --> URI Class Initialized
INFO - 2025-05-12 15:38:04 --> Router Class Initialized
INFO - 2025-05-12 15:38:04 --> Output Class Initialized
INFO - 2025-05-12 15:38:04 --> Security Class Initialized
DEBUG - 2025-05-12 15:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:38:04 --> Input Class Initialized
INFO - 2025-05-12 15:38:04 --> Language Class Initialized
INFO - 2025-05-12 15:38:04 --> Loader Class Initialized
INFO - 2025-05-12 15:38:04 --> Helper loaded: url_helper
INFO - 2025-05-12 15:38:04 --> Helper loaded: form_helper
INFO - 2025-05-12 15:38:04 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:38:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:38:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:38:04 --> Controller Class Initialized
INFO - 2025-05-12 15:38:04 --> Model "User_model" initialized
INFO - 2025-05-12 15:38:04 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:38:04 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:38:04 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:38:04 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-12 15:38:04 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:38:04 --> Final output sent to browser
DEBUG - 2025-05-12 15:38:04 --> Total execution time: 0.0806
INFO - 2025-05-12 15:38:05 --> Config Class Initialized
INFO - 2025-05-12 15:38:05 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:38:05 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:38:05 --> Utf8 Class Initialized
INFO - 2025-05-12 15:38:05 --> URI Class Initialized
INFO - 2025-05-12 15:38:05 --> Router Class Initialized
INFO - 2025-05-12 15:38:05 --> Output Class Initialized
INFO - 2025-05-12 15:38:05 --> Security Class Initialized
DEBUG - 2025-05-12 15:38:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:38:05 --> Input Class Initialized
INFO - 2025-05-12 15:38:05 --> Language Class Initialized
INFO - 2025-05-12 15:38:05 --> Loader Class Initialized
INFO - 2025-05-12 15:38:05 --> Helper loaded: url_helper
INFO - 2025-05-12 15:38:05 --> Helper loaded: form_helper
INFO - 2025-05-12 15:38:05 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:38:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:38:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:38:05 --> Controller Class Initialized
INFO - 2025-05-12 15:38:05 --> Model "User_model" initialized
INFO - 2025-05-12 15:38:05 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:38:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:38:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:38:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-12 15:38:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:38:05 --> Final output sent to browser
DEBUG - 2025-05-12 15:38:05 --> Total execution time: 0.0847
INFO - 2025-05-12 15:38:06 --> Config Class Initialized
INFO - 2025-05-12 15:38:06 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:38:06 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:38:06 --> Utf8 Class Initialized
INFO - 2025-05-12 15:38:06 --> URI Class Initialized
INFO - 2025-05-12 15:38:06 --> Router Class Initialized
INFO - 2025-05-12 15:38:06 --> Output Class Initialized
INFO - 2025-05-12 15:38:06 --> Security Class Initialized
DEBUG - 2025-05-12 15:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:38:06 --> Input Class Initialized
INFO - 2025-05-12 15:38:06 --> Language Class Initialized
INFO - 2025-05-12 15:38:06 --> Loader Class Initialized
INFO - 2025-05-12 15:38:06 --> Helper loaded: url_helper
INFO - 2025-05-12 15:38:06 --> Helper loaded: form_helper
INFO - 2025-05-12 15:38:06 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:38:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:38:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:38:06 --> Controller Class Initialized
INFO - 2025-05-12 15:38:06 --> Model "User_model" initialized
INFO - 2025-05-12 15:38:06 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:38:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:38:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:38:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-12 15:38:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:38:06 --> Final output sent to browser
DEBUG - 2025-05-12 15:38:06 --> Total execution time: 0.0752
INFO - 2025-05-12 15:38:08 --> Config Class Initialized
INFO - 2025-05-12 15:38:08 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:38:08 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:38:08 --> Utf8 Class Initialized
INFO - 2025-05-12 15:38:08 --> URI Class Initialized
INFO - 2025-05-12 15:38:08 --> Router Class Initialized
INFO - 2025-05-12 15:38:08 --> Output Class Initialized
INFO - 2025-05-12 15:38:08 --> Security Class Initialized
DEBUG - 2025-05-12 15:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:38:08 --> Input Class Initialized
INFO - 2025-05-12 15:38:08 --> Language Class Initialized
INFO - 2025-05-12 15:38:08 --> Loader Class Initialized
INFO - 2025-05-12 15:38:08 --> Helper loaded: url_helper
INFO - 2025-05-12 15:38:08 --> Helper loaded: form_helper
INFO - 2025-05-12 15:38:08 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:38:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:38:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:38:08 --> Controller Class Initialized
INFO - 2025-05-12 15:38:08 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:38:08 --> Model "User_model" initialized
INFO - 2025-05-12 15:38:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:38:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:38:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-12 15:38:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:38:08 --> Final output sent to browser
DEBUG - 2025-05-12 15:38:08 --> Total execution time: 0.1034
INFO - 2025-05-12 15:38:09 --> Config Class Initialized
INFO - 2025-05-12 15:38:09 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:38:09 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:38:09 --> Utf8 Class Initialized
INFO - 2025-05-12 15:38:09 --> URI Class Initialized
INFO - 2025-05-12 15:38:09 --> Router Class Initialized
INFO - 2025-05-12 15:38:09 --> Output Class Initialized
INFO - 2025-05-12 15:38:09 --> Security Class Initialized
DEBUG - 2025-05-12 15:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:38:09 --> Input Class Initialized
INFO - 2025-05-12 15:38:09 --> Language Class Initialized
INFO - 2025-05-12 15:38:09 --> Loader Class Initialized
INFO - 2025-05-12 15:38:09 --> Helper loaded: url_helper
INFO - 2025-05-12 15:38:09 --> Helper loaded: form_helper
INFO - 2025-05-12 15:38:09 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:38:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:38:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:38:09 --> Controller Class Initialized
INFO - 2025-05-12 15:38:09 --> Model "User_model" initialized
INFO - 2025-05-12 15:38:09 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:38:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:38:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:38:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-12 15:38:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:38:09 --> Final output sent to browser
DEBUG - 2025-05-12 15:38:09 --> Total execution time: 0.1011
INFO - 2025-05-12 15:38:10 --> Config Class Initialized
INFO - 2025-05-12 15:38:10 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:38:10 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:38:10 --> Utf8 Class Initialized
INFO - 2025-05-12 15:38:10 --> URI Class Initialized
INFO - 2025-05-12 15:38:10 --> Router Class Initialized
INFO - 2025-05-12 15:38:10 --> Output Class Initialized
INFO - 2025-05-12 15:38:10 --> Security Class Initialized
DEBUG - 2025-05-12 15:38:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:38:10 --> Input Class Initialized
INFO - 2025-05-12 15:38:10 --> Language Class Initialized
INFO - 2025-05-12 15:38:10 --> Loader Class Initialized
INFO - 2025-05-12 15:38:10 --> Helper loaded: url_helper
INFO - 2025-05-12 15:38:10 --> Helper loaded: form_helper
INFO - 2025-05-12 15:38:10 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:38:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:38:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:38:10 --> Controller Class Initialized
INFO - 2025-05-12 15:38:10 --> Model "User_model" initialized
INFO - 2025-05-12 15:38:10 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:38:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:38:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:38:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-12 15:38:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:38:10 --> Final output sent to browser
DEBUG - 2025-05-12 15:38:10 --> Total execution time: 0.1085
INFO - 2025-05-12 15:38:12 --> Config Class Initialized
INFO - 2025-05-12 15:38:12 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:38:12 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:38:12 --> Utf8 Class Initialized
INFO - 2025-05-12 15:38:12 --> URI Class Initialized
INFO - 2025-05-12 15:38:12 --> Router Class Initialized
INFO - 2025-05-12 15:38:12 --> Output Class Initialized
INFO - 2025-05-12 15:38:12 --> Security Class Initialized
DEBUG - 2025-05-12 15:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:38:12 --> Input Class Initialized
INFO - 2025-05-12 15:38:12 --> Language Class Initialized
INFO - 2025-05-12 15:38:12 --> Loader Class Initialized
INFO - 2025-05-12 15:38:12 --> Helper loaded: url_helper
INFO - 2025-05-12 15:38:12 --> Helper loaded: form_helper
INFO - 2025-05-12 15:38:12 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:38:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:38:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:38:12 --> Controller Class Initialized
INFO - 2025-05-12 15:38:12 --> Model "User_model" initialized
INFO - 2025-05-12 15:38:12 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:38:12 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:38:12 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:38:12 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-12 15:38:12 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:38:12 --> Final output sent to browser
DEBUG - 2025-05-12 15:38:12 --> Total execution time: 0.1040
INFO - 2025-05-12 15:38:14 --> Config Class Initialized
INFO - 2025-05-12 15:38:14 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:38:14 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:38:14 --> Utf8 Class Initialized
INFO - 2025-05-12 15:38:14 --> URI Class Initialized
INFO - 2025-05-12 15:38:14 --> Router Class Initialized
INFO - 2025-05-12 15:38:14 --> Output Class Initialized
INFO - 2025-05-12 15:38:14 --> Security Class Initialized
DEBUG - 2025-05-12 15:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:38:14 --> Input Class Initialized
INFO - 2025-05-12 15:38:14 --> Language Class Initialized
INFO - 2025-05-12 15:38:14 --> Loader Class Initialized
INFO - 2025-05-12 15:38:14 --> Helper loaded: url_helper
INFO - 2025-05-12 15:38:14 --> Helper loaded: form_helper
INFO - 2025-05-12 15:38:14 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:38:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:38:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:38:14 --> Controller Class Initialized
INFO - 2025-05-12 15:38:14 --> Model "User_model" initialized
INFO - 2025-05-12 15:38:14 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:38:14 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:38:14 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:38:14 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-12 15:38:14 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:38:14 --> Final output sent to browser
DEBUG - 2025-05-12 15:38:14 --> Total execution time: 0.0965
INFO - 2025-05-12 15:39:32 --> Config Class Initialized
INFO - 2025-05-12 15:39:32 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:39:32 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:39:32 --> Utf8 Class Initialized
INFO - 2025-05-12 15:39:32 --> URI Class Initialized
INFO - 2025-05-12 15:39:32 --> Router Class Initialized
INFO - 2025-05-12 15:39:32 --> Output Class Initialized
INFO - 2025-05-12 15:39:32 --> Security Class Initialized
DEBUG - 2025-05-12 15:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:39:32 --> Input Class Initialized
INFO - 2025-05-12 15:39:32 --> Language Class Initialized
INFO - 2025-05-12 15:39:32 --> Loader Class Initialized
INFO - 2025-05-12 15:39:32 --> Helper loaded: url_helper
INFO - 2025-05-12 15:39:32 --> Helper loaded: form_helper
INFO - 2025-05-12 15:39:32 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:39:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:39:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:39:32 --> Controller Class Initialized
INFO - 2025-05-12 15:39:32 --> Model "User_model" initialized
INFO - 2025-05-12 15:39:32 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:39:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:39:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:39:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-12 15:39:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:39:32 --> Final output sent to browser
DEBUG - 2025-05-12 15:39:32 --> Total execution time: 0.0913
INFO - 2025-05-12 15:39:34 --> Config Class Initialized
INFO - 2025-05-12 15:39:34 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:39:34 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:39:34 --> Utf8 Class Initialized
INFO - 2025-05-12 15:39:34 --> URI Class Initialized
INFO - 2025-05-12 15:39:34 --> Router Class Initialized
INFO - 2025-05-12 15:39:34 --> Output Class Initialized
INFO - 2025-05-12 15:39:34 --> Security Class Initialized
DEBUG - 2025-05-12 15:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:39:34 --> Input Class Initialized
INFO - 2025-05-12 15:39:34 --> Language Class Initialized
INFO - 2025-05-12 15:39:34 --> Loader Class Initialized
INFO - 2025-05-12 15:39:34 --> Helper loaded: url_helper
INFO - 2025-05-12 15:39:34 --> Helper loaded: form_helper
INFO - 2025-05-12 15:39:34 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:39:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:39:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:39:34 --> Controller Class Initialized
INFO - 2025-05-12 15:39:34 --> Model "User_model" initialized
INFO - 2025-05-12 15:39:34 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:39:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:39:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:39:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-12 15:39:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:39:34 --> Final output sent to browser
DEBUG - 2025-05-12 15:39:34 --> Total execution time: 0.0993
INFO - 2025-05-12 15:39:35 --> Config Class Initialized
INFO - 2025-05-12 15:39:35 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:39:35 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:39:35 --> Utf8 Class Initialized
INFO - 2025-05-12 15:39:35 --> URI Class Initialized
INFO - 2025-05-12 15:39:35 --> Router Class Initialized
INFO - 2025-05-12 15:39:35 --> Output Class Initialized
INFO - 2025-05-12 15:39:35 --> Security Class Initialized
DEBUG - 2025-05-12 15:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:39:35 --> Input Class Initialized
INFO - 2025-05-12 15:39:35 --> Language Class Initialized
INFO - 2025-05-12 15:39:35 --> Loader Class Initialized
INFO - 2025-05-12 15:39:35 --> Helper loaded: url_helper
INFO - 2025-05-12 15:39:35 --> Helper loaded: form_helper
INFO - 2025-05-12 15:39:35 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:39:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:39:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:39:36 --> Controller Class Initialized
INFO - 2025-05-12 15:39:36 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:39:36 --> Model "User_model" initialized
INFO - 2025-05-12 15:39:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:39:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:39:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-12 15:39:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:39:36 --> Final output sent to browser
DEBUG - 2025-05-12 15:39:36 --> Total execution time: 0.1029
INFO - 2025-05-12 15:39:49 --> Config Class Initialized
INFO - 2025-05-12 15:39:49 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:39:49 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:39:49 --> Utf8 Class Initialized
INFO - 2025-05-12 15:39:49 --> URI Class Initialized
INFO - 2025-05-12 15:39:49 --> Router Class Initialized
INFO - 2025-05-12 15:39:49 --> Output Class Initialized
INFO - 2025-05-12 15:39:49 --> Security Class Initialized
DEBUG - 2025-05-12 15:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:39:49 --> Input Class Initialized
INFO - 2025-05-12 15:39:49 --> Language Class Initialized
INFO - 2025-05-12 15:39:49 --> Loader Class Initialized
INFO - 2025-05-12 15:39:49 --> Helper loaded: url_helper
INFO - 2025-05-12 15:39:49 --> Helper loaded: form_helper
INFO - 2025-05-12 15:39:49 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:39:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:39:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:39:49 --> Controller Class Initialized
INFO - 2025-05-12 15:39:49 --> Model "User_model" initialized
INFO - 2025-05-12 15:39:49 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:39:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:39:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:39:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-12 15:39:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:39:49 --> Final output sent to browser
DEBUG - 2025-05-12 15:39:49 --> Total execution time: 0.1131
INFO - 2025-05-12 15:39:50 --> Config Class Initialized
INFO - 2025-05-12 15:39:50 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:39:50 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:39:50 --> Utf8 Class Initialized
INFO - 2025-05-12 15:39:50 --> URI Class Initialized
INFO - 2025-05-12 15:39:50 --> Router Class Initialized
INFO - 2025-05-12 15:39:50 --> Output Class Initialized
INFO - 2025-05-12 15:39:50 --> Security Class Initialized
DEBUG - 2025-05-12 15:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:39:50 --> Input Class Initialized
INFO - 2025-05-12 15:39:50 --> Language Class Initialized
INFO - 2025-05-12 15:39:50 --> Loader Class Initialized
INFO - 2025-05-12 15:39:50 --> Helper loaded: url_helper
INFO - 2025-05-12 15:39:50 --> Helper loaded: form_helper
INFO - 2025-05-12 15:39:50 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:39:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:39:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:39:50 --> Controller Class Initialized
INFO - 2025-05-12 15:39:50 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:39:50 --> Model "User_model" initialized
INFO - 2025-05-12 15:39:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:39:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:39:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-12 15:39:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:39:51 --> Final output sent to browser
DEBUG - 2025-05-12 15:39:51 --> Total execution time: 0.0963
INFO - 2025-05-12 15:39:52 --> Config Class Initialized
INFO - 2025-05-12 15:39:52 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:39:52 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:39:52 --> Utf8 Class Initialized
INFO - 2025-05-12 15:39:52 --> URI Class Initialized
INFO - 2025-05-12 15:39:52 --> Router Class Initialized
INFO - 2025-05-12 15:39:52 --> Output Class Initialized
INFO - 2025-05-12 15:39:52 --> Security Class Initialized
DEBUG - 2025-05-12 15:39:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:39:52 --> Input Class Initialized
INFO - 2025-05-12 15:39:52 --> Language Class Initialized
INFO - 2025-05-12 15:39:52 --> Loader Class Initialized
INFO - 2025-05-12 15:39:52 --> Helper loaded: url_helper
INFO - 2025-05-12 15:39:53 --> Helper loaded: form_helper
INFO - 2025-05-12 15:39:53 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:39:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:39:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:39:53 --> Controller Class Initialized
INFO - 2025-05-12 15:39:53 --> Model "User_model" initialized
INFO - 2025-05-12 15:39:53 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:39:53 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:39:53 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:39:53 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-12 15:39:53 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:39:53 --> Final output sent to browser
DEBUG - 2025-05-12 15:39:53 --> Total execution time: 0.1050
INFO - 2025-05-12 15:39:54 --> Config Class Initialized
INFO - 2025-05-12 15:39:54 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:39:54 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:39:54 --> Utf8 Class Initialized
INFO - 2025-05-12 15:39:54 --> URI Class Initialized
INFO - 2025-05-12 15:39:54 --> Router Class Initialized
INFO - 2025-05-12 15:39:54 --> Output Class Initialized
INFO - 2025-05-12 15:39:54 --> Security Class Initialized
DEBUG - 2025-05-12 15:39:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:39:54 --> Input Class Initialized
INFO - 2025-05-12 15:39:54 --> Language Class Initialized
INFO - 2025-05-12 15:39:54 --> Loader Class Initialized
INFO - 2025-05-12 15:39:54 --> Helper loaded: url_helper
INFO - 2025-05-12 15:39:54 --> Helper loaded: form_helper
INFO - 2025-05-12 15:39:55 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:39:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:39:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:39:55 --> Controller Class Initialized
INFO - 2025-05-12 15:39:55 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:39:55 --> Model "User_model" initialized
INFO - 2025-05-12 15:39:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:39:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:39:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-12 15:39:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:39:55 --> Final output sent to browser
DEBUG - 2025-05-12 15:39:55 --> Total execution time: 0.0833
INFO - 2025-05-12 15:40:19 --> Config Class Initialized
INFO - 2025-05-12 15:40:19 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:40:19 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:40:19 --> Utf8 Class Initialized
INFO - 2025-05-12 15:40:19 --> URI Class Initialized
INFO - 2025-05-12 15:40:19 --> Router Class Initialized
INFO - 2025-05-12 15:40:19 --> Output Class Initialized
INFO - 2025-05-12 15:40:19 --> Security Class Initialized
DEBUG - 2025-05-12 15:40:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:40:19 --> Input Class Initialized
INFO - 2025-05-12 15:40:19 --> Language Class Initialized
INFO - 2025-05-12 15:40:19 --> Loader Class Initialized
INFO - 2025-05-12 15:40:19 --> Helper loaded: url_helper
INFO - 2025-05-12 15:40:19 --> Helper loaded: form_helper
INFO - 2025-05-12 15:40:19 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:40:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:40:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:40:19 --> Controller Class Initialized
INFO - 2025-05-12 15:40:19 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:40:19 --> Model "User_model" initialized
INFO - 2025-05-12 15:40:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:40:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:40:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-12 15:40:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:40:19 --> Final output sent to browser
DEBUG - 2025-05-12 15:40:19 --> Total execution time: 0.1052
INFO - 2025-05-12 15:41:14 --> Config Class Initialized
INFO - 2025-05-12 15:41:14 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:41:14 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:41:14 --> Utf8 Class Initialized
INFO - 2025-05-12 15:41:14 --> URI Class Initialized
INFO - 2025-05-12 15:41:14 --> Router Class Initialized
INFO - 2025-05-12 15:41:14 --> Output Class Initialized
INFO - 2025-05-12 15:41:14 --> Security Class Initialized
DEBUG - 2025-05-12 15:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:41:14 --> Input Class Initialized
INFO - 2025-05-12 15:41:14 --> Language Class Initialized
INFO - 2025-05-12 15:41:14 --> Loader Class Initialized
INFO - 2025-05-12 15:41:14 --> Helper loaded: url_helper
INFO - 2025-05-12 15:41:14 --> Helper loaded: form_helper
INFO - 2025-05-12 15:41:14 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:41:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:41:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:41:14 --> Controller Class Initialized
INFO - 2025-05-12 15:41:14 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:41:14 --> Model "User_model" initialized
INFO - 2025-05-12 15:41:14 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:41:14 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:41:14 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-12 15:41:14 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:41:14 --> Final output sent to browser
DEBUG - 2025-05-12 15:41:14 --> Total execution time: 0.0937
INFO - 2025-05-12 15:41:17 --> Config Class Initialized
INFO - 2025-05-12 15:41:17 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:41:17 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:41:17 --> Utf8 Class Initialized
INFO - 2025-05-12 15:41:17 --> URI Class Initialized
INFO - 2025-05-12 15:41:17 --> Router Class Initialized
INFO - 2025-05-12 15:41:17 --> Output Class Initialized
INFO - 2025-05-12 15:41:17 --> Security Class Initialized
DEBUG - 2025-05-12 15:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:41:17 --> Input Class Initialized
INFO - 2025-05-12 15:41:17 --> Language Class Initialized
INFO - 2025-05-12 15:41:17 --> Loader Class Initialized
INFO - 2025-05-12 15:41:17 --> Helper loaded: url_helper
INFO - 2025-05-12 15:41:17 --> Helper loaded: form_helper
INFO - 2025-05-12 15:41:17 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:41:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:41:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:41:17 --> Controller Class Initialized
INFO - 2025-05-12 15:41:17 --> Model "User_model" initialized
INFO - 2025-05-12 15:41:17 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:41:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:41:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:41:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-12 15:41:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:41:17 --> Final output sent to browser
DEBUG - 2025-05-12 15:41:17 --> Total execution time: 0.1055
INFO - 2025-05-12 15:41:20 --> Config Class Initialized
INFO - 2025-05-12 15:41:20 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:41:20 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:41:20 --> Utf8 Class Initialized
INFO - 2025-05-12 15:41:20 --> URI Class Initialized
INFO - 2025-05-12 15:41:20 --> Router Class Initialized
INFO - 2025-05-12 15:41:20 --> Output Class Initialized
INFO - 2025-05-12 15:41:20 --> Security Class Initialized
DEBUG - 2025-05-12 15:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:41:20 --> Input Class Initialized
INFO - 2025-05-12 15:41:20 --> Language Class Initialized
INFO - 2025-05-12 15:41:20 --> Loader Class Initialized
INFO - 2025-05-12 15:41:20 --> Helper loaded: url_helper
INFO - 2025-05-12 15:41:20 --> Helper loaded: form_helper
INFO - 2025-05-12 15:41:20 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:41:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:41:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:41:20 --> Controller Class Initialized
INFO - 2025-05-12 15:41:20 --> Model "User_model" initialized
INFO - 2025-05-12 15:41:20 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:41:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:41:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:41:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-12 15:41:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:41:20 --> Final output sent to browser
DEBUG - 2025-05-12 15:41:20 --> Total execution time: 0.1048
INFO - 2025-05-12 15:41:22 --> Config Class Initialized
INFO - 2025-05-12 15:41:22 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:41:22 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:41:22 --> Utf8 Class Initialized
INFO - 2025-05-12 15:41:22 --> URI Class Initialized
INFO - 2025-05-12 15:41:22 --> Router Class Initialized
INFO - 2025-05-12 15:41:22 --> Output Class Initialized
INFO - 2025-05-12 15:41:22 --> Security Class Initialized
DEBUG - 2025-05-12 15:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:41:22 --> Input Class Initialized
INFO - 2025-05-12 15:41:22 --> Language Class Initialized
INFO - 2025-05-12 15:41:22 --> Loader Class Initialized
INFO - 2025-05-12 15:41:22 --> Helper loaded: url_helper
INFO - 2025-05-12 15:41:22 --> Helper loaded: form_helper
INFO - 2025-05-12 15:41:22 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:41:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:41:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:41:22 --> Controller Class Initialized
INFO - 2025-05-12 15:41:22 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:41:22 --> Model "User_model" initialized
INFO - 2025-05-12 15:41:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:41:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:41:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-12 15:41:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:41:22 --> Final output sent to browser
DEBUG - 2025-05-12 15:41:22 --> Total execution time: 0.1012
INFO - 2025-05-12 15:42:05 --> Config Class Initialized
INFO - 2025-05-12 15:42:05 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:42:05 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:42:05 --> Utf8 Class Initialized
INFO - 2025-05-12 15:42:05 --> URI Class Initialized
INFO - 2025-05-12 15:42:05 --> Router Class Initialized
INFO - 2025-05-12 15:42:05 --> Output Class Initialized
INFO - 2025-05-12 15:42:05 --> Security Class Initialized
DEBUG - 2025-05-12 15:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:42:05 --> Input Class Initialized
INFO - 2025-05-12 15:42:05 --> Language Class Initialized
INFO - 2025-05-12 15:42:05 --> Loader Class Initialized
INFO - 2025-05-12 15:42:05 --> Helper loaded: url_helper
INFO - 2025-05-12 15:42:05 --> Helper loaded: form_helper
INFO - 2025-05-12 15:42:05 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:42:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:42:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:42:05 --> Controller Class Initialized
INFO - 2025-05-12 15:42:05 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:42:05 --> Model "User_model" initialized
INFO - 2025-05-12 15:42:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:42:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:42:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-12 15:42:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:42:05 --> Final output sent to browser
DEBUG - 2025-05-12 15:42:05 --> Total execution time: 0.0871
INFO - 2025-05-12 15:42:07 --> Config Class Initialized
INFO - 2025-05-12 15:42:07 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:42:07 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:42:07 --> Utf8 Class Initialized
INFO - 2025-05-12 15:42:07 --> URI Class Initialized
INFO - 2025-05-12 15:42:07 --> Router Class Initialized
INFO - 2025-05-12 15:42:07 --> Output Class Initialized
INFO - 2025-05-12 15:42:07 --> Security Class Initialized
DEBUG - 2025-05-12 15:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:42:07 --> Input Class Initialized
INFO - 2025-05-12 15:42:07 --> Language Class Initialized
INFO - 2025-05-12 15:42:07 --> Loader Class Initialized
INFO - 2025-05-12 15:42:07 --> Helper loaded: url_helper
INFO - 2025-05-12 15:42:07 --> Helper loaded: form_helper
INFO - 2025-05-12 15:42:07 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:42:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:42:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:42:07 --> Controller Class Initialized
INFO - 2025-05-12 15:42:07 --> Model "User_model" initialized
INFO - 2025-05-12 15:42:07 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:42:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:42:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:42:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-12 15:42:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:42:07 --> Final output sent to browser
DEBUG - 2025-05-12 15:42:07 --> Total execution time: 0.1024
INFO - 2025-05-12 15:42:08 --> Config Class Initialized
INFO - 2025-05-12 15:42:08 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:42:08 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:42:08 --> Utf8 Class Initialized
INFO - 2025-05-12 15:42:08 --> URI Class Initialized
INFO - 2025-05-12 15:42:08 --> Router Class Initialized
INFO - 2025-05-12 15:42:08 --> Output Class Initialized
INFO - 2025-05-12 15:42:08 --> Security Class Initialized
DEBUG - 2025-05-12 15:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:42:08 --> Input Class Initialized
INFO - 2025-05-12 15:42:08 --> Language Class Initialized
INFO - 2025-05-12 15:42:08 --> Loader Class Initialized
INFO - 2025-05-12 15:42:08 --> Helper loaded: url_helper
INFO - 2025-05-12 15:42:08 --> Helper loaded: form_helper
INFO - 2025-05-12 15:42:08 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:42:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:42:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:42:08 --> Controller Class Initialized
INFO - 2025-05-12 15:42:08 --> Model "User_model" initialized
INFO - 2025-05-12 15:42:08 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:42:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:42:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:42:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-12 15:42:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:42:08 --> Final output sent to browser
DEBUG - 2025-05-12 15:42:08 --> Total execution time: 0.1057
INFO - 2025-05-12 15:42:09 --> Config Class Initialized
INFO - 2025-05-12 15:42:09 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:42:09 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:42:09 --> Utf8 Class Initialized
INFO - 2025-05-12 15:42:09 --> URI Class Initialized
INFO - 2025-05-12 15:42:09 --> Router Class Initialized
INFO - 2025-05-12 15:42:09 --> Output Class Initialized
INFO - 2025-05-12 15:42:09 --> Security Class Initialized
DEBUG - 2025-05-12 15:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:42:09 --> Input Class Initialized
INFO - 2025-05-12 15:42:09 --> Language Class Initialized
INFO - 2025-05-12 15:42:09 --> Loader Class Initialized
INFO - 2025-05-12 15:42:09 --> Helper loaded: url_helper
INFO - 2025-05-12 15:42:09 --> Helper loaded: form_helper
INFO - 2025-05-12 15:42:09 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:42:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:42:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:42:09 --> Controller Class Initialized
INFO - 2025-05-12 15:42:09 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:42:09 --> Model "User_model" initialized
INFO - 2025-05-12 15:42:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:42:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:42:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-12 15:42:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:42:09 --> Final output sent to browser
DEBUG - 2025-05-12 15:42:09 --> Total execution time: 0.0820
INFO - 2025-05-12 15:42:12 --> Config Class Initialized
INFO - 2025-05-12 15:42:12 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:42:12 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:42:12 --> Utf8 Class Initialized
INFO - 2025-05-12 15:42:12 --> URI Class Initialized
INFO - 2025-05-12 15:42:12 --> Router Class Initialized
INFO - 2025-05-12 15:42:12 --> Output Class Initialized
INFO - 2025-05-12 15:42:12 --> Security Class Initialized
DEBUG - 2025-05-12 15:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:42:12 --> Input Class Initialized
INFO - 2025-05-12 15:42:12 --> Language Class Initialized
INFO - 2025-05-12 15:42:12 --> Loader Class Initialized
INFO - 2025-05-12 15:42:12 --> Helper loaded: url_helper
INFO - 2025-05-12 15:42:12 --> Helper loaded: form_helper
INFO - 2025-05-12 15:42:12 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:42:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:42:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:42:12 --> Controller Class Initialized
INFO - 2025-05-12 15:42:12 --> Model "User_model" initialized
INFO - 2025-05-12 15:42:12 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:42:12 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:42:12 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:42:12 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-12 15:42:12 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:42:12 --> Final output sent to browser
DEBUG - 2025-05-12 15:42:12 --> Total execution time: 0.0866
INFO - 2025-05-12 15:42:15 --> Config Class Initialized
INFO - 2025-05-12 15:42:15 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:42:15 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:42:15 --> Utf8 Class Initialized
INFO - 2025-05-12 15:42:15 --> URI Class Initialized
INFO - 2025-05-12 15:42:15 --> Router Class Initialized
INFO - 2025-05-12 15:42:15 --> Output Class Initialized
INFO - 2025-05-12 15:42:15 --> Security Class Initialized
DEBUG - 2025-05-12 15:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:42:15 --> Input Class Initialized
INFO - 2025-05-12 15:42:15 --> Language Class Initialized
INFO - 2025-05-12 15:42:15 --> Loader Class Initialized
INFO - 2025-05-12 15:42:15 --> Helper loaded: url_helper
INFO - 2025-05-12 15:42:15 --> Helper loaded: form_helper
INFO - 2025-05-12 15:42:15 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:42:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:42:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:42:15 --> Controller Class Initialized
INFO - 2025-05-12 15:42:15 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:42:15 --> Model "User_model" initialized
INFO - 2025-05-12 15:42:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:42:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:42:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-12 15:42:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:42:15 --> Final output sent to browser
DEBUG - 2025-05-12 15:42:15 --> Total execution time: 0.0886
INFO - 2025-05-12 15:42:19 --> Config Class Initialized
INFO - 2025-05-12 15:42:19 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:42:19 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:42:19 --> Utf8 Class Initialized
INFO - 2025-05-12 15:42:19 --> URI Class Initialized
INFO - 2025-05-12 15:42:19 --> Router Class Initialized
INFO - 2025-05-12 15:42:19 --> Output Class Initialized
INFO - 2025-05-12 15:42:19 --> Security Class Initialized
DEBUG - 2025-05-12 15:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:42:19 --> Input Class Initialized
INFO - 2025-05-12 15:42:19 --> Language Class Initialized
INFO - 2025-05-12 15:42:19 --> Loader Class Initialized
INFO - 2025-05-12 15:42:19 --> Helper loaded: url_helper
INFO - 2025-05-12 15:42:19 --> Helper loaded: form_helper
INFO - 2025-05-12 15:42:19 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:42:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:42:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:42:19 --> Controller Class Initialized
INFO - 2025-05-12 15:42:19 --> Model "User_model" initialized
INFO - 2025-05-12 15:42:19 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:42:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:42:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:42:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-12 15:42:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:42:19 --> Final output sent to browser
DEBUG - 2025-05-12 15:42:19 --> Total execution time: 0.0881
INFO - 2025-05-12 15:42:21 --> Config Class Initialized
INFO - 2025-05-12 15:42:21 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:42:21 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:42:21 --> Utf8 Class Initialized
INFO - 2025-05-12 15:42:21 --> URI Class Initialized
INFO - 2025-05-12 15:42:21 --> Router Class Initialized
INFO - 2025-05-12 15:42:21 --> Output Class Initialized
INFO - 2025-05-12 15:42:21 --> Security Class Initialized
DEBUG - 2025-05-12 15:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:42:21 --> Input Class Initialized
INFO - 2025-05-12 15:42:21 --> Language Class Initialized
INFO - 2025-05-12 15:42:21 --> Loader Class Initialized
INFO - 2025-05-12 15:42:21 --> Helper loaded: url_helper
INFO - 2025-05-12 15:42:21 --> Helper loaded: form_helper
INFO - 2025-05-12 15:42:21 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:42:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:42:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:42:21 --> Controller Class Initialized
INFO - 2025-05-12 15:42:21 --> Model "User_model" initialized
INFO - 2025-05-12 15:42:21 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:42:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:42:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:42:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-12 15:42:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:42:21 --> Final output sent to browser
DEBUG - 2025-05-12 15:42:21 --> Total execution time: 0.0869
INFO - 2025-05-12 15:42:22 --> Config Class Initialized
INFO - 2025-05-12 15:42:22 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:42:22 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:42:22 --> Utf8 Class Initialized
INFO - 2025-05-12 15:42:23 --> URI Class Initialized
INFO - 2025-05-12 15:42:23 --> Router Class Initialized
INFO - 2025-05-12 15:42:23 --> Output Class Initialized
INFO - 2025-05-12 15:42:23 --> Security Class Initialized
DEBUG - 2025-05-12 15:42:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:42:23 --> Input Class Initialized
INFO - 2025-05-12 15:42:23 --> Language Class Initialized
INFO - 2025-05-12 15:42:23 --> Loader Class Initialized
INFO - 2025-05-12 15:42:23 --> Helper loaded: url_helper
INFO - 2025-05-12 15:42:23 --> Helper loaded: form_helper
INFO - 2025-05-12 15:42:23 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:42:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:42:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:42:23 --> Controller Class Initialized
INFO - 2025-05-12 15:42:23 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:42:23 --> Model "User_model" initialized
INFO - 2025-05-12 15:42:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:42:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:42:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-12 15:42:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:42:23 --> Final output sent to browser
DEBUG - 2025-05-12 15:42:23 --> Total execution time: 0.1018
INFO - 2025-05-12 15:42:33 --> Config Class Initialized
INFO - 2025-05-12 15:42:33 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:42:33 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:42:33 --> Utf8 Class Initialized
INFO - 2025-05-12 15:42:33 --> URI Class Initialized
INFO - 2025-05-12 15:42:33 --> Router Class Initialized
INFO - 2025-05-12 15:42:33 --> Output Class Initialized
INFO - 2025-05-12 15:42:33 --> Security Class Initialized
DEBUG - 2025-05-12 15:42:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:42:33 --> Input Class Initialized
INFO - 2025-05-12 15:42:33 --> Language Class Initialized
INFO - 2025-05-12 15:42:33 --> Loader Class Initialized
INFO - 2025-05-12 15:42:33 --> Helper loaded: url_helper
INFO - 2025-05-12 15:42:33 --> Helper loaded: form_helper
INFO - 2025-05-12 15:42:33 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:42:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:42:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:42:33 --> Controller Class Initialized
INFO - 2025-05-12 15:42:33 --> Model "User_model" initialized
INFO - 2025-05-12 15:42:33 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:42:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:42:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:42:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-12 15:42:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:42:33 --> Final output sent to browser
DEBUG - 2025-05-12 15:42:33 --> Total execution time: 0.1023
INFO - 2025-05-12 15:43:01 --> Config Class Initialized
INFO - 2025-05-12 15:43:01 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:43:01 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:43:01 --> Utf8 Class Initialized
INFO - 2025-05-12 15:43:01 --> URI Class Initialized
INFO - 2025-05-12 15:43:01 --> Router Class Initialized
INFO - 2025-05-12 15:43:01 --> Output Class Initialized
INFO - 2025-05-12 15:43:01 --> Security Class Initialized
DEBUG - 2025-05-12 15:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:43:01 --> Input Class Initialized
INFO - 2025-05-12 15:43:01 --> Language Class Initialized
INFO - 2025-05-12 15:43:01 --> Loader Class Initialized
INFO - 2025-05-12 15:43:01 --> Helper loaded: url_helper
INFO - 2025-05-12 15:43:01 --> Helper loaded: form_helper
INFO - 2025-05-12 15:43:01 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:43:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:43:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:43:01 --> Controller Class Initialized
INFO - 2025-05-12 15:43:01 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:43:01 --> Model "User_model" initialized
INFO - 2025-05-12 15:43:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:43:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:43:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-12 15:43:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:43:01 --> Final output sent to browser
DEBUG - 2025-05-12 15:43:01 --> Total execution time: 0.1043
INFO - 2025-05-12 15:44:05 --> Config Class Initialized
INFO - 2025-05-12 15:44:05 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:44:05 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:44:05 --> Utf8 Class Initialized
INFO - 2025-05-12 15:44:05 --> URI Class Initialized
INFO - 2025-05-12 15:44:05 --> Router Class Initialized
INFO - 2025-05-12 15:44:05 --> Output Class Initialized
INFO - 2025-05-12 15:44:05 --> Security Class Initialized
DEBUG - 2025-05-12 15:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:44:05 --> Input Class Initialized
INFO - 2025-05-12 15:44:05 --> Language Class Initialized
INFO - 2025-05-12 15:44:06 --> Loader Class Initialized
INFO - 2025-05-12 15:44:06 --> Helper loaded: url_helper
INFO - 2025-05-12 15:44:06 --> Helper loaded: form_helper
INFO - 2025-05-12 15:44:06 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:44:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:44:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:44:06 --> Controller Class Initialized
INFO - 2025-05-12 15:44:06 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:44:06 --> Model "User_model" initialized
INFO - 2025-05-12 15:44:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:44:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:44:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-12 15:44:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:44:06 --> Final output sent to browser
DEBUG - 2025-05-12 15:44:06 --> Total execution time: 0.1043
INFO - 2025-05-12 15:44:18 --> Config Class Initialized
INFO - 2025-05-12 15:44:18 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:44:18 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:44:18 --> Utf8 Class Initialized
INFO - 2025-05-12 15:44:18 --> URI Class Initialized
INFO - 2025-05-12 15:44:18 --> Router Class Initialized
INFO - 2025-05-12 15:44:18 --> Output Class Initialized
INFO - 2025-05-12 15:44:18 --> Security Class Initialized
DEBUG - 2025-05-12 15:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:44:18 --> Input Class Initialized
INFO - 2025-05-12 15:44:18 --> Language Class Initialized
INFO - 2025-05-12 15:44:18 --> Loader Class Initialized
INFO - 2025-05-12 15:44:18 --> Helper loaded: url_helper
INFO - 2025-05-12 15:44:18 --> Helper loaded: form_helper
INFO - 2025-05-12 15:44:18 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:44:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:44:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:44:18 --> Controller Class Initialized
INFO - 2025-05-12 15:44:18 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:44:18 --> Model "User_model" initialized
INFO - 2025-05-12 15:44:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:44:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:44:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-12 15:44:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:44:18 --> Final output sent to browser
DEBUG - 2025-05-12 15:44:18 --> Total execution time: 0.0877
INFO - 2025-05-12 15:44:29 --> Config Class Initialized
INFO - 2025-05-12 15:44:29 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:44:29 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:44:29 --> Utf8 Class Initialized
INFO - 2025-05-12 15:44:29 --> URI Class Initialized
INFO - 2025-05-12 15:44:29 --> Router Class Initialized
INFO - 2025-05-12 15:44:29 --> Output Class Initialized
INFO - 2025-05-12 15:44:29 --> Security Class Initialized
DEBUG - 2025-05-12 15:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:44:29 --> Input Class Initialized
INFO - 2025-05-12 15:44:29 --> Language Class Initialized
INFO - 2025-05-12 15:44:29 --> Loader Class Initialized
INFO - 2025-05-12 15:44:29 --> Helper loaded: url_helper
INFO - 2025-05-12 15:44:29 --> Helper loaded: form_helper
INFO - 2025-05-12 15:44:29 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:44:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:44:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:44:29 --> Controller Class Initialized
INFO - 2025-05-12 15:44:29 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:44:29 --> Model "User_model" initialized
INFO - 2025-05-12 15:44:29 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:44:29 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:44:29 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-12 15:44:29 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:44:29 --> Final output sent to browser
DEBUG - 2025-05-12 15:44:29 --> Total execution time: 0.1072
INFO - 2025-05-12 15:44:42 --> Config Class Initialized
INFO - 2025-05-12 15:44:42 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:44:42 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:44:42 --> Utf8 Class Initialized
INFO - 2025-05-12 15:44:42 --> URI Class Initialized
INFO - 2025-05-12 15:44:42 --> Router Class Initialized
INFO - 2025-05-12 15:44:42 --> Output Class Initialized
INFO - 2025-05-12 15:44:42 --> Security Class Initialized
DEBUG - 2025-05-12 15:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:44:42 --> Input Class Initialized
INFO - 2025-05-12 15:44:42 --> Language Class Initialized
INFO - 2025-05-12 15:44:42 --> Loader Class Initialized
INFO - 2025-05-12 15:44:42 --> Helper loaded: url_helper
INFO - 2025-05-12 15:44:42 --> Helper loaded: form_helper
INFO - 2025-05-12 15:44:42 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:44:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:44:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:44:42 --> Controller Class Initialized
INFO - 2025-05-12 15:44:42 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:44:42 --> Model "User_model" initialized
INFO - 2025-05-12 15:44:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:44:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:44:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-12 15:44:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:44:42 --> Final output sent to browser
DEBUG - 2025-05-12 15:44:42 --> Total execution time: 0.1080
INFO - 2025-05-12 15:45:03 --> Config Class Initialized
INFO - 2025-05-12 15:45:03 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:45:03 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:45:03 --> Utf8 Class Initialized
INFO - 2025-05-12 15:45:03 --> URI Class Initialized
INFO - 2025-05-12 15:45:03 --> Router Class Initialized
INFO - 2025-05-12 15:45:03 --> Output Class Initialized
INFO - 2025-05-12 15:45:03 --> Security Class Initialized
DEBUG - 2025-05-12 15:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:45:03 --> Input Class Initialized
INFO - 2025-05-12 15:45:03 --> Language Class Initialized
INFO - 2025-05-12 15:45:03 --> Loader Class Initialized
INFO - 2025-05-12 15:45:03 --> Helper loaded: url_helper
INFO - 2025-05-12 15:45:03 --> Helper loaded: form_helper
INFO - 2025-05-12 15:45:03 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:45:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:45:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:45:03 --> Controller Class Initialized
INFO - 2025-05-12 15:45:03 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:45:03 --> Model "User_model" initialized
INFO - 2025-05-12 15:45:03 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:45:03 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:45:03 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-12 15:45:03 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:45:03 --> Final output sent to browser
DEBUG - 2025-05-12 15:45:03 --> Total execution time: 0.0878
INFO - 2025-05-12 15:47:24 --> Config Class Initialized
INFO - 2025-05-12 15:47:24 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:47:24 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:47:24 --> Utf8 Class Initialized
INFO - 2025-05-12 15:47:24 --> URI Class Initialized
INFO - 2025-05-12 15:47:24 --> Router Class Initialized
INFO - 2025-05-12 15:47:24 --> Output Class Initialized
INFO - 2025-05-12 15:47:24 --> Security Class Initialized
DEBUG - 2025-05-12 15:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:47:24 --> Input Class Initialized
INFO - 2025-05-12 15:47:24 --> Language Class Initialized
INFO - 2025-05-12 15:47:24 --> Loader Class Initialized
INFO - 2025-05-12 15:47:24 --> Helper loaded: url_helper
INFO - 2025-05-12 15:47:24 --> Helper loaded: form_helper
INFO - 2025-05-12 15:47:24 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:47:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:47:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:47:24 --> Controller Class Initialized
INFO - 2025-05-12 15:47:24 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:47:24 --> Model "User_model" initialized
INFO - 2025-05-12 15:47:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:47:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:47:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-12 15:47:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:47:24 --> Final output sent to browser
DEBUG - 2025-05-12 15:47:24 --> Total execution time: 0.0850
INFO - 2025-05-12 15:47:36 --> Config Class Initialized
INFO - 2025-05-12 15:47:36 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:47:36 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:47:36 --> Utf8 Class Initialized
INFO - 2025-05-12 15:47:36 --> URI Class Initialized
INFO - 2025-05-12 15:47:36 --> Router Class Initialized
INFO - 2025-05-12 15:47:36 --> Output Class Initialized
INFO - 2025-05-12 15:47:36 --> Security Class Initialized
DEBUG - 2025-05-12 15:47:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:47:36 --> Input Class Initialized
INFO - 2025-05-12 15:47:36 --> Language Class Initialized
INFO - 2025-05-12 15:47:36 --> Loader Class Initialized
INFO - 2025-05-12 15:47:36 --> Helper loaded: url_helper
INFO - 2025-05-12 15:47:36 --> Helper loaded: form_helper
INFO - 2025-05-12 15:47:36 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:47:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:47:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:47:36 --> Controller Class Initialized
INFO - 2025-05-12 15:47:36 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:47:36 --> Model "User_model" initialized
INFO - 2025-05-12 15:47:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:47:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:47:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-12 15:47:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:47:36 --> Final output sent to browser
DEBUG - 2025-05-12 15:47:36 --> Total execution time: 0.0874
INFO - 2025-05-12 15:47:57 --> Config Class Initialized
INFO - 2025-05-12 15:47:57 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:47:57 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:47:57 --> Utf8 Class Initialized
INFO - 2025-05-12 15:47:57 --> URI Class Initialized
INFO - 2025-05-12 15:47:57 --> Router Class Initialized
INFO - 2025-05-12 15:47:57 --> Output Class Initialized
INFO - 2025-05-12 15:47:57 --> Security Class Initialized
DEBUG - 2025-05-12 15:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:47:57 --> Input Class Initialized
INFO - 2025-05-12 15:47:57 --> Language Class Initialized
INFO - 2025-05-12 15:47:57 --> Loader Class Initialized
INFO - 2025-05-12 15:47:57 --> Helper loaded: url_helper
INFO - 2025-05-12 15:47:57 --> Helper loaded: form_helper
INFO - 2025-05-12 15:47:57 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:47:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:47:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:47:57 --> Controller Class Initialized
INFO - 2025-05-12 15:47:57 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:47:57 --> Model "User_model" initialized
INFO - 2025-05-12 15:47:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:47:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:47:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-12 15:47:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:47:57 --> Final output sent to browser
DEBUG - 2025-05-12 15:47:57 --> Total execution time: 0.1019
INFO - 2025-05-12 15:48:21 --> Config Class Initialized
INFO - 2025-05-12 15:48:21 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:48:21 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:48:21 --> Utf8 Class Initialized
INFO - 2025-05-12 15:48:21 --> URI Class Initialized
INFO - 2025-05-12 15:48:22 --> Router Class Initialized
INFO - 2025-05-12 15:48:22 --> Output Class Initialized
INFO - 2025-05-12 15:48:22 --> Security Class Initialized
DEBUG - 2025-05-12 15:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:48:22 --> Input Class Initialized
INFO - 2025-05-12 15:48:22 --> Language Class Initialized
INFO - 2025-05-12 15:48:22 --> Loader Class Initialized
INFO - 2025-05-12 15:48:22 --> Helper loaded: url_helper
INFO - 2025-05-12 15:48:22 --> Helper loaded: form_helper
INFO - 2025-05-12 15:48:22 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:48:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:48:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:48:22 --> Controller Class Initialized
INFO - 2025-05-12 15:48:22 --> Model "User_model" initialized
INFO - 2025-05-12 15:48:22 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:48:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:48:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:48:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-12 15:48:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:48:22 --> Final output sent to browser
DEBUG - 2025-05-12 15:48:22 --> Total execution time: 0.1241
INFO - 2025-05-12 15:48:29 --> Config Class Initialized
INFO - 2025-05-12 15:48:29 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:48:29 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:48:29 --> Utf8 Class Initialized
INFO - 2025-05-12 15:48:29 --> URI Class Initialized
INFO - 2025-05-12 15:48:29 --> Router Class Initialized
INFO - 2025-05-12 15:48:29 --> Output Class Initialized
INFO - 2025-05-12 15:48:29 --> Security Class Initialized
DEBUG - 2025-05-12 15:48:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:48:29 --> Input Class Initialized
INFO - 2025-05-12 15:48:29 --> Language Class Initialized
INFO - 2025-05-12 15:48:29 --> Loader Class Initialized
INFO - 2025-05-12 15:48:29 --> Helper loaded: url_helper
INFO - 2025-05-12 15:48:29 --> Helper loaded: form_helper
INFO - 2025-05-12 15:48:29 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:48:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:48:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:48:29 --> Controller Class Initialized
INFO - 2025-05-12 15:48:29 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:48:29 --> Model "User_model" initialized
INFO - 2025-05-12 15:48:29 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:48:29 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:48:29 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-12 15:48:29 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:48:29 --> Final output sent to browser
DEBUG - 2025-05-12 15:48:29 --> Total execution time: 0.1101
INFO - 2025-05-12 15:48:32 --> Config Class Initialized
INFO - 2025-05-12 15:48:32 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:48:32 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:48:32 --> Utf8 Class Initialized
INFO - 2025-05-12 15:48:32 --> URI Class Initialized
INFO - 2025-05-12 15:48:32 --> Router Class Initialized
INFO - 2025-05-12 15:48:32 --> Output Class Initialized
INFO - 2025-05-12 15:48:32 --> Security Class Initialized
DEBUG - 2025-05-12 15:48:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:48:32 --> Input Class Initialized
INFO - 2025-05-12 15:48:32 --> Language Class Initialized
INFO - 2025-05-12 15:48:32 --> Loader Class Initialized
INFO - 2025-05-12 15:48:32 --> Helper loaded: url_helper
INFO - 2025-05-12 15:48:32 --> Helper loaded: form_helper
INFO - 2025-05-12 15:48:32 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:48:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:48:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:48:32 --> Controller Class Initialized
INFO - 2025-05-12 15:48:32 --> Model "User_model" initialized
INFO - 2025-05-12 15:48:32 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:48:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:48:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:48:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-12 15:48:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:48:32 --> Final output sent to browser
DEBUG - 2025-05-12 15:48:32 --> Total execution time: 0.1243
INFO - 2025-05-12 15:49:12 --> Config Class Initialized
INFO - 2025-05-12 15:49:12 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:49:12 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:49:12 --> Utf8 Class Initialized
INFO - 2025-05-12 15:49:12 --> URI Class Initialized
INFO - 2025-05-12 15:49:12 --> Router Class Initialized
INFO - 2025-05-12 15:49:12 --> Output Class Initialized
INFO - 2025-05-12 15:49:12 --> Security Class Initialized
DEBUG - 2025-05-12 15:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:49:12 --> Input Class Initialized
INFO - 2025-05-12 15:49:12 --> Language Class Initialized
INFO - 2025-05-12 15:49:12 --> Loader Class Initialized
INFO - 2025-05-12 15:49:12 --> Helper loaded: url_helper
INFO - 2025-05-12 15:49:12 --> Helper loaded: form_helper
INFO - 2025-05-12 15:49:12 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:49:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:49:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:49:12 --> Controller Class Initialized
INFO - 2025-05-12 15:49:12 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:49:12 --> Model "User_model" initialized
INFO - 2025-05-12 15:49:12 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:49:12 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:49:12 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-12 15:49:12 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:49:12 --> Final output sent to browser
DEBUG - 2025-05-12 15:49:12 --> Total execution time: 0.1008
INFO - 2025-05-12 15:49:34 --> Config Class Initialized
INFO - 2025-05-12 15:49:34 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:49:34 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:49:34 --> Utf8 Class Initialized
INFO - 2025-05-12 15:49:34 --> URI Class Initialized
INFO - 2025-05-12 15:49:34 --> Router Class Initialized
INFO - 2025-05-12 15:49:34 --> Output Class Initialized
INFO - 2025-05-12 15:49:34 --> Security Class Initialized
DEBUG - 2025-05-12 15:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:49:34 --> Input Class Initialized
INFO - 2025-05-12 15:49:34 --> Language Class Initialized
INFO - 2025-05-12 15:49:34 --> Loader Class Initialized
INFO - 2025-05-12 15:49:34 --> Helper loaded: url_helper
INFO - 2025-05-12 15:49:34 --> Helper loaded: form_helper
INFO - 2025-05-12 15:49:34 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:49:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:49:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:49:34 --> Controller Class Initialized
INFO - 2025-05-12 15:49:34 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:49:34 --> Model "User_model" initialized
INFO - 2025-05-12 15:49:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:49:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:49:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-12 15:49:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:49:34 --> Final output sent to browser
DEBUG - 2025-05-12 15:49:34 --> Total execution time: 0.1083
INFO - 2025-05-12 15:49:56 --> Config Class Initialized
INFO - 2025-05-12 15:49:56 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:49:56 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:49:56 --> Utf8 Class Initialized
INFO - 2025-05-12 15:49:56 --> URI Class Initialized
INFO - 2025-05-12 15:49:56 --> Router Class Initialized
INFO - 2025-05-12 15:49:56 --> Output Class Initialized
INFO - 2025-05-12 15:49:56 --> Security Class Initialized
DEBUG - 2025-05-12 15:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:49:56 --> Input Class Initialized
INFO - 2025-05-12 15:49:56 --> Language Class Initialized
INFO - 2025-05-12 15:49:56 --> Loader Class Initialized
INFO - 2025-05-12 15:49:56 --> Helper loaded: url_helper
INFO - 2025-05-12 15:49:56 --> Helper loaded: form_helper
INFO - 2025-05-12 15:49:56 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:49:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:49:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:49:56 --> Controller Class Initialized
INFO - 2025-05-12 15:49:56 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:49:56 --> Model "User_model" initialized
INFO - 2025-05-12 15:49:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:49:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:49:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-12 15:49:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:49:56 --> Final output sent to browser
DEBUG - 2025-05-12 15:49:56 --> Total execution time: 0.0987
INFO - 2025-05-12 15:50:47 --> Config Class Initialized
INFO - 2025-05-12 15:50:47 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:50:47 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:50:47 --> Utf8 Class Initialized
INFO - 2025-05-12 15:50:47 --> URI Class Initialized
INFO - 2025-05-12 15:50:47 --> Router Class Initialized
INFO - 2025-05-12 15:50:47 --> Output Class Initialized
INFO - 2025-05-12 15:50:47 --> Security Class Initialized
DEBUG - 2025-05-12 15:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:50:47 --> Input Class Initialized
INFO - 2025-05-12 15:50:47 --> Language Class Initialized
INFO - 2025-05-12 15:50:47 --> Loader Class Initialized
INFO - 2025-05-12 15:50:47 --> Helper loaded: url_helper
INFO - 2025-05-12 15:50:47 --> Helper loaded: form_helper
INFO - 2025-05-12 15:50:47 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:50:47 --> Controller Class Initialized
INFO - 2025-05-12 15:50:47 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:50:47 --> Model "User_model" initialized
INFO - 2025-05-12 15:50:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:50:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:50:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-12 15:50:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:50:47 --> Final output sent to browser
DEBUG - 2025-05-12 15:50:47 --> Total execution time: 0.0980
INFO - 2025-05-12 15:51:33 --> Config Class Initialized
INFO - 2025-05-12 15:51:33 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:51:33 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:51:33 --> Utf8 Class Initialized
INFO - 2025-05-12 15:51:33 --> URI Class Initialized
INFO - 2025-05-12 15:51:33 --> Router Class Initialized
INFO - 2025-05-12 15:51:33 --> Output Class Initialized
INFO - 2025-05-12 15:51:33 --> Security Class Initialized
DEBUG - 2025-05-12 15:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:51:33 --> Input Class Initialized
INFO - 2025-05-12 15:51:33 --> Language Class Initialized
INFO - 2025-05-12 15:51:33 --> Loader Class Initialized
INFO - 2025-05-12 15:51:33 --> Helper loaded: url_helper
INFO - 2025-05-12 15:51:33 --> Helper loaded: form_helper
INFO - 2025-05-12 15:51:33 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:51:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:51:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:51:33 --> Controller Class Initialized
INFO - 2025-05-12 15:51:33 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:51:33 --> Model "User_model" initialized
INFO - 2025-05-12 15:51:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:51:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:51:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-12 15:51:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:51:33 --> Final output sent to browser
DEBUG - 2025-05-12 15:51:33 --> Total execution time: 0.0977
INFO - 2025-05-12 15:51:46 --> Config Class Initialized
INFO - 2025-05-12 15:51:46 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:51:46 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:51:46 --> Utf8 Class Initialized
INFO - 2025-05-12 15:51:46 --> URI Class Initialized
INFO - 2025-05-12 15:51:46 --> Router Class Initialized
INFO - 2025-05-12 15:51:46 --> Output Class Initialized
INFO - 2025-05-12 15:51:46 --> Security Class Initialized
DEBUG - 2025-05-12 15:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:51:46 --> Input Class Initialized
INFO - 2025-05-12 15:51:46 --> Language Class Initialized
INFO - 2025-05-12 15:51:46 --> Loader Class Initialized
INFO - 2025-05-12 15:51:46 --> Helper loaded: url_helper
INFO - 2025-05-12 15:51:46 --> Helper loaded: form_helper
INFO - 2025-05-12 15:51:46 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:51:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:51:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:51:46 --> Controller Class Initialized
INFO - 2025-05-12 15:51:46 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:51:46 --> Model "User_model" initialized
INFO - 2025-05-12 15:51:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:51:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:51:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-12 15:51:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:51:46 --> Final output sent to browser
DEBUG - 2025-05-12 15:51:46 --> Total execution time: 0.0905
INFO - 2025-05-12 15:52:38 --> Config Class Initialized
INFO - 2025-05-12 15:52:38 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:52:38 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:52:38 --> Utf8 Class Initialized
INFO - 2025-05-12 15:52:38 --> URI Class Initialized
INFO - 2025-05-12 15:52:38 --> Router Class Initialized
INFO - 2025-05-12 15:52:38 --> Output Class Initialized
INFO - 2025-05-12 15:52:38 --> Security Class Initialized
DEBUG - 2025-05-12 15:52:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:52:38 --> Input Class Initialized
INFO - 2025-05-12 15:52:38 --> Language Class Initialized
INFO - 2025-05-12 15:52:38 --> Loader Class Initialized
INFO - 2025-05-12 15:52:38 --> Helper loaded: url_helper
INFO - 2025-05-12 15:52:38 --> Helper loaded: form_helper
INFO - 2025-05-12 15:52:38 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:52:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:52:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:52:38 --> Controller Class Initialized
INFO - 2025-05-12 15:52:38 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:52:38 --> Model "User_model" initialized
INFO - 2025-05-12 15:52:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:52:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:52:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-12 15:52:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:52:38 --> Final output sent to browser
DEBUG - 2025-05-12 15:52:38 --> Total execution time: 0.1181
INFO - 2025-05-12 15:53:25 --> Config Class Initialized
INFO - 2025-05-12 15:53:25 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:53:25 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:53:25 --> Utf8 Class Initialized
INFO - 2025-05-12 15:53:25 --> URI Class Initialized
INFO - 2025-05-12 15:53:25 --> Router Class Initialized
INFO - 2025-05-12 15:53:25 --> Output Class Initialized
INFO - 2025-05-12 15:53:25 --> Security Class Initialized
DEBUG - 2025-05-12 15:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:53:25 --> Input Class Initialized
INFO - 2025-05-12 15:53:25 --> Language Class Initialized
INFO - 2025-05-12 15:53:25 --> Loader Class Initialized
INFO - 2025-05-12 15:53:25 --> Helper loaded: url_helper
INFO - 2025-05-12 15:53:25 --> Helper loaded: form_helper
INFO - 2025-05-12 15:53:25 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:53:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:53:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:53:25 --> Controller Class Initialized
INFO - 2025-05-12 15:53:25 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:53:25 --> Model "User_model" initialized
INFO - 2025-05-12 15:53:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:53:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:53:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-12 15:53:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:53:25 --> Final output sent to browser
DEBUG - 2025-05-12 15:53:25 --> Total execution time: 0.1223
INFO - 2025-05-12 15:53:58 --> Config Class Initialized
INFO - 2025-05-12 15:53:58 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:53:58 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:53:58 --> Utf8 Class Initialized
INFO - 2025-05-12 15:53:58 --> URI Class Initialized
INFO - 2025-05-12 15:53:58 --> Router Class Initialized
INFO - 2025-05-12 15:53:58 --> Output Class Initialized
INFO - 2025-05-12 15:53:58 --> Security Class Initialized
DEBUG - 2025-05-12 15:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:53:58 --> Input Class Initialized
INFO - 2025-05-12 15:53:58 --> Language Class Initialized
INFO - 2025-05-12 15:53:58 --> Loader Class Initialized
INFO - 2025-05-12 15:53:58 --> Helper loaded: url_helper
INFO - 2025-05-12 15:53:58 --> Helper loaded: form_helper
INFO - 2025-05-12 15:53:58 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:53:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:53:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:53:58 --> Controller Class Initialized
INFO - 2025-05-12 15:53:58 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:53:58 --> Model "User_model" initialized
INFO - 2025-05-12 15:53:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:53:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:53:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-12 15:53:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:53:58 --> Final output sent to browser
DEBUG - 2025-05-12 15:53:58 --> Total execution time: 0.1077
INFO - 2025-05-12 15:56:11 --> Config Class Initialized
INFO - 2025-05-12 15:56:11 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:56:11 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:56:11 --> Utf8 Class Initialized
INFO - 2025-05-12 15:56:11 --> URI Class Initialized
INFO - 2025-05-12 15:56:11 --> Router Class Initialized
INFO - 2025-05-12 15:56:11 --> Output Class Initialized
INFO - 2025-05-12 15:56:11 --> Security Class Initialized
DEBUG - 2025-05-12 15:56:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:56:11 --> Input Class Initialized
INFO - 2025-05-12 15:56:11 --> Language Class Initialized
INFO - 2025-05-12 15:56:11 --> Loader Class Initialized
INFO - 2025-05-12 15:56:11 --> Helper loaded: url_helper
INFO - 2025-05-12 15:56:11 --> Helper loaded: form_helper
INFO - 2025-05-12 15:56:11 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:56:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:56:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:56:11 --> Controller Class Initialized
INFO - 2025-05-12 15:56:11 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:56:11 --> Model "User_model" initialized
INFO - 2025-05-12 15:56:11 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:56:11 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:56:11 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-12 15:56:11 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:56:11 --> Final output sent to browser
DEBUG - 2025-05-12 15:56:11 --> Total execution time: 0.1127
INFO - 2025-05-12 15:57:18 --> Config Class Initialized
INFO - 2025-05-12 15:57:18 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:57:18 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:57:18 --> Utf8 Class Initialized
INFO - 2025-05-12 15:57:18 --> URI Class Initialized
INFO - 2025-05-12 15:57:18 --> Router Class Initialized
INFO - 2025-05-12 15:57:18 --> Output Class Initialized
INFO - 2025-05-12 15:57:18 --> Security Class Initialized
DEBUG - 2025-05-12 15:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:57:18 --> Input Class Initialized
INFO - 2025-05-12 15:57:18 --> Language Class Initialized
INFO - 2025-05-12 15:57:18 --> Loader Class Initialized
INFO - 2025-05-12 15:57:18 --> Helper loaded: url_helper
INFO - 2025-05-12 15:57:18 --> Helper loaded: form_helper
INFO - 2025-05-12 15:57:18 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:57:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:57:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:57:19 --> Controller Class Initialized
INFO - 2025-05-12 15:57:19 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:57:19 --> Model "User_model" initialized
INFO - 2025-05-12 15:57:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:57:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:57:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-12 15:57:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:57:19 --> Final output sent to browser
DEBUG - 2025-05-12 15:57:19 --> Total execution time: 0.1136
INFO - 2025-05-12 15:57:52 --> Config Class Initialized
INFO - 2025-05-12 15:57:52 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:57:52 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:57:52 --> Utf8 Class Initialized
INFO - 2025-05-12 15:57:52 --> URI Class Initialized
INFO - 2025-05-12 15:57:52 --> Router Class Initialized
INFO - 2025-05-12 15:57:52 --> Output Class Initialized
INFO - 2025-05-12 15:57:52 --> Security Class Initialized
DEBUG - 2025-05-12 15:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:57:52 --> Input Class Initialized
INFO - 2025-05-12 15:57:52 --> Language Class Initialized
INFO - 2025-05-12 15:57:52 --> Loader Class Initialized
INFO - 2025-05-12 15:57:52 --> Helper loaded: url_helper
INFO - 2025-05-12 15:57:52 --> Helper loaded: form_helper
INFO - 2025-05-12 15:57:52 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:57:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:57:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:57:52 --> Controller Class Initialized
INFO - 2025-05-12 15:57:52 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:57:52 --> Model "User_model" initialized
INFO - 2025-05-12 15:57:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:57:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:57:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-12 15:57:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:57:52 --> Final output sent to browser
DEBUG - 2025-05-12 15:57:52 --> Total execution time: 0.0882
INFO - 2025-05-12 15:57:58 --> Config Class Initialized
INFO - 2025-05-12 15:57:58 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:57:58 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:57:58 --> Utf8 Class Initialized
INFO - 2025-05-12 15:57:58 --> URI Class Initialized
INFO - 2025-05-12 15:57:58 --> Router Class Initialized
INFO - 2025-05-12 15:57:58 --> Output Class Initialized
INFO - 2025-05-12 15:57:58 --> Security Class Initialized
DEBUG - 2025-05-12 15:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:57:58 --> Input Class Initialized
INFO - 2025-05-12 15:57:58 --> Language Class Initialized
INFO - 2025-05-12 15:57:58 --> Loader Class Initialized
INFO - 2025-05-12 15:57:58 --> Helper loaded: url_helper
INFO - 2025-05-12 15:57:58 --> Helper loaded: form_helper
INFO - 2025-05-12 15:57:58 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:57:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:57:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:57:58 --> Controller Class Initialized
INFO - 2025-05-12 15:57:58 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:57:58 --> Model "User_model" initialized
INFO - 2025-05-12 15:57:58 --> Config Class Initialized
INFO - 2025-05-12 15:57:58 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:57:58 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:57:58 --> Utf8 Class Initialized
INFO - 2025-05-12 15:57:58 --> URI Class Initialized
INFO - 2025-05-12 15:57:58 --> Router Class Initialized
INFO - 2025-05-12 15:57:58 --> Output Class Initialized
INFO - 2025-05-12 15:57:58 --> Security Class Initialized
DEBUG - 2025-05-12 15:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:57:58 --> Input Class Initialized
INFO - 2025-05-12 15:57:58 --> Language Class Initialized
INFO - 2025-05-12 15:57:58 --> Loader Class Initialized
INFO - 2025-05-12 15:57:58 --> Helper loaded: url_helper
INFO - 2025-05-12 15:57:58 --> Helper loaded: form_helper
INFO - 2025-05-12 15:57:58 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:57:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:57:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:57:58 --> Controller Class Initialized
INFO - 2025-05-12 15:57:58 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:57:58 --> Model "User_model" initialized
INFO - 2025-05-12 15:57:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:57:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
ERROR - 2025-05-12 15:57:58 --> Severity: Warning --> Undefined variable $h C:\laragon\www\Project\fitnessrecord\application\views\dashboard\jadwal_record.php 140
ERROR - 2025-05-12 15:57:58 --> Severity: Warning --> Attempt to read property "id" on null C:\laragon\www\Project\fitnessrecord\application\views\dashboard\jadwal_record.php 140
INFO - 2025-05-12 15:57:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-12 15:57:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:57:58 --> Final output sent to browser
DEBUG - 2025-05-12 15:57:58 --> Total execution time: 0.0967
INFO - 2025-05-12 15:58:30 --> Config Class Initialized
INFO - 2025-05-12 15:58:30 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:58:30 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:58:30 --> Utf8 Class Initialized
INFO - 2025-05-12 15:58:30 --> URI Class Initialized
INFO - 2025-05-12 15:58:30 --> Router Class Initialized
INFO - 2025-05-12 15:58:30 --> Output Class Initialized
INFO - 2025-05-12 15:58:30 --> Security Class Initialized
DEBUG - 2025-05-12 15:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:58:30 --> Input Class Initialized
INFO - 2025-05-12 15:58:30 --> Language Class Initialized
INFO - 2025-05-12 15:58:30 --> Loader Class Initialized
INFO - 2025-05-12 15:58:30 --> Helper loaded: url_helper
INFO - 2025-05-12 15:58:30 --> Helper loaded: form_helper
INFO - 2025-05-12 15:58:30 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:58:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:58:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:58:30 --> Controller Class Initialized
INFO - 2025-05-12 15:58:30 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:58:30 --> Model "User_model" initialized
INFO - 2025-05-12 15:58:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:58:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:58:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-12 15:58:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:58:30 --> Final output sent to browser
DEBUG - 2025-05-12 15:58:30 --> Total execution time: 0.0968
INFO - 2025-05-12 15:58:33 --> Config Class Initialized
INFO - 2025-05-12 15:58:33 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:58:33 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:58:33 --> Utf8 Class Initialized
INFO - 2025-05-12 15:58:33 --> URI Class Initialized
INFO - 2025-05-12 15:58:33 --> Router Class Initialized
INFO - 2025-05-12 15:58:33 --> Output Class Initialized
INFO - 2025-05-12 15:58:33 --> Security Class Initialized
DEBUG - 2025-05-12 15:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:58:33 --> Input Class Initialized
INFO - 2025-05-12 15:58:33 --> Language Class Initialized
INFO - 2025-05-12 15:58:33 --> Loader Class Initialized
INFO - 2025-05-12 15:58:33 --> Helper loaded: url_helper
INFO - 2025-05-12 15:58:33 --> Helper loaded: form_helper
INFO - 2025-05-12 15:58:33 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:58:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:58:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:58:33 --> Controller Class Initialized
INFO - 2025-05-12 15:58:33 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:58:33 --> Model "User_model" initialized
INFO - 2025-05-12 15:58:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/start.php
INFO - 2025-05-12 15:58:33 --> Final output sent to browser
DEBUG - 2025-05-12 15:58:33 --> Total execution time: 0.1093
INFO - 2025-05-12 15:58:36 --> Config Class Initialized
INFO - 2025-05-12 15:58:36 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:58:36 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:58:36 --> Utf8 Class Initialized
INFO - 2025-05-12 15:58:36 --> URI Class Initialized
INFO - 2025-05-12 15:58:36 --> Router Class Initialized
INFO - 2025-05-12 15:58:36 --> Output Class Initialized
INFO - 2025-05-12 15:58:36 --> Security Class Initialized
DEBUG - 2025-05-12 15:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:58:36 --> Input Class Initialized
INFO - 2025-05-12 15:58:36 --> Language Class Initialized
INFO - 2025-05-12 15:58:36 --> Loader Class Initialized
INFO - 2025-05-12 15:58:36 --> Helper loaded: url_helper
INFO - 2025-05-12 15:58:36 --> Helper loaded: form_helper
INFO - 2025-05-12 15:58:36 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:58:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:58:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:58:36 --> Controller Class Initialized
INFO - 2025-05-12 15:58:36 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:58:36 --> Model "User_model" initialized
INFO - 2025-05-12 15:58:36 --> Final output sent to browser
DEBUG - 2025-05-12 15:58:36 --> Total execution time: 0.1040
INFO - 2025-05-12 15:58:36 --> Config Class Initialized
INFO - 2025-05-12 15:58:36 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:58:36 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:58:36 --> Utf8 Class Initialized
INFO - 2025-05-12 15:58:36 --> URI Class Initialized
INFO - 2025-05-12 15:58:36 --> Router Class Initialized
INFO - 2025-05-12 15:58:36 --> Output Class Initialized
INFO - 2025-05-12 15:58:36 --> Security Class Initialized
DEBUG - 2025-05-12 15:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:58:36 --> Input Class Initialized
INFO - 2025-05-12 15:58:36 --> Language Class Initialized
INFO - 2025-05-12 15:58:36 --> Loader Class Initialized
INFO - 2025-05-12 15:58:36 --> Helper loaded: url_helper
INFO - 2025-05-12 15:58:36 --> Helper loaded: form_helper
INFO - 2025-05-12 15:58:36 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:58:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:58:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:58:36 --> Controller Class Initialized
INFO - 2025-05-12 15:58:36 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:58:36 --> Model "User_model" initialized
INFO - 2025-05-12 15:58:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:58:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:58:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-12 15:58:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:58:36 --> Final output sent to browser
DEBUG - 2025-05-12 15:58:36 --> Total execution time: 0.0979
INFO - 2025-05-12 15:58:40 --> Config Class Initialized
INFO - 2025-05-12 15:58:40 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:58:40 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:58:40 --> Utf8 Class Initialized
INFO - 2025-05-12 15:58:40 --> URI Class Initialized
INFO - 2025-05-12 15:58:40 --> Router Class Initialized
INFO - 2025-05-12 15:58:40 --> Output Class Initialized
INFO - 2025-05-12 15:58:40 --> Security Class Initialized
DEBUG - 2025-05-12 15:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:58:40 --> Input Class Initialized
INFO - 2025-05-12 15:58:40 --> Language Class Initialized
INFO - 2025-05-12 15:58:40 --> Loader Class Initialized
INFO - 2025-05-12 15:58:40 --> Helper loaded: url_helper
INFO - 2025-05-12 15:58:40 --> Helper loaded: form_helper
INFO - 2025-05-12 15:58:40 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:58:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:58:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:58:40 --> Controller Class Initialized
INFO - 2025-05-12 15:58:40 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:58:40 --> Model "User_model" initialized
INFO - 2025-05-12 15:58:40 --> Config Class Initialized
INFO - 2025-05-12 15:58:40 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:58:40 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:58:40 --> Utf8 Class Initialized
INFO - 2025-05-12 15:58:40 --> URI Class Initialized
INFO - 2025-05-12 15:58:40 --> Router Class Initialized
INFO - 2025-05-12 15:58:40 --> Output Class Initialized
INFO - 2025-05-12 15:58:40 --> Security Class Initialized
DEBUG - 2025-05-12 15:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:58:40 --> Input Class Initialized
INFO - 2025-05-12 15:58:40 --> Language Class Initialized
INFO - 2025-05-12 15:58:40 --> Loader Class Initialized
INFO - 2025-05-12 15:58:40 --> Helper loaded: url_helper
INFO - 2025-05-12 15:58:40 --> Helper loaded: form_helper
INFO - 2025-05-12 15:58:40 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:58:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:58:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:58:40 --> Controller Class Initialized
INFO - 2025-05-12 15:58:40 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:58:40 --> Model "User_model" initialized
INFO - 2025-05-12 15:58:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:58:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:58:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-12 15:58:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:58:40 --> Final output sent to browser
DEBUG - 2025-05-12 15:58:40 --> Total execution time: 0.0821
INFO - 2025-05-12 15:58:49 --> Config Class Initialized
INFO - 2025-05-12 15:58:49 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:58:49 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:58:49 --> Utf8 Class Initialized
INFO - 2025-05-12 15:58:49 --> URI Class Initialized
INFO - 2025-05-12 15:58:49 --> Router Class Initialized
INFO - 2025-05-12 15:58:49 --> Output Class Initialized
INFO - 2025-05-12 15:58:49 --> Security Class Initialized
DEBUG - 2025-05-12 15:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:58:49 --> Input Class Initialized
INFO - 2025-05-12 15:58:49 --> Language Class Initialized
INFO - 2025-05-12 15:58:49 --> Loader Class Initialized
INFO - 2025-05-12 15:58:49 --> Helper loaded: url_helper
INFO - 2025-05-12 15:58:49 --> Helper loaded: form_helper
INFO - 2025-05-12 15:58:49 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:58:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:58:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:58:49 --> Controller Class Initialized
INFO - 2025-05-12 15:58:49 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:58:49 --> Model "User_model" initialized
INFO - 2025-05-12 15:58:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:58:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:58:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-12 15:58:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:58:49 --> Final output sent to browser
DEBUG - 2025-05-12 15:58:49 --> Total execution time: 0.1267
INFO - 2025-05-12 15:58:51 --> Config Class Initialized
INFO - 2025-05-12 15:58:51 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:58:51 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:58:51 --> Utf8 Class Initialized
INFO - 2025-05-12 15:58:51 --> URI Class Initialized
INFO - 2025-05-12 15:58:51 --> Router Class Initialized
INFO - 2025-05-12 15:58:51 --> Output Class Initialized
INFO - 2025-05-12 15:58:51 --> Security Class Initialized
DEBUG - 2025-05-12 15:58:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:58:51 --> Input Class Initialized
INFO - 2025-05-12 15:58:51 --> Language Class Initialized
INFO - 2025-05-12 15:58:51 --> Loader Class Initialized
INFO - 2025-05-12 15:58:51 --> Helper loaded: url_helper
INFO - 2025-05-12 15:58:51 --> Helper loaded: form_helper
INFO - 2025-05-12 15:58:51 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:58:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:58:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:58:51 --> Controller Class Initialized
INFO - 2025-05-12 15:58:51 --> Model "User_model" initialized
INFO - 2025-05-12 15:58:51 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:58:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:58:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:58:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-12 15:58:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:58:51 --> Final output sent to browser
DEBUG - 2025-05-12 15:58:51 --> Total execution time: 0.0903
INFO - 2025-05-12 15:58:52 --> Config Class Initialized
INFO - 2025-05-12 15:58:52 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:58:52 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:58:52 --> Utf8 Class Initialized
INFO - 2025-05-12 15:58:53 --> URI Class Initialized
INFO - 2025-05-12 15:58:53 --> Router Class Initialized
INFO - 2025-05-12 15:58:53 --> Output Class Initialized
INFO - 2025-05-12 15:58:53 --> Security Class Initialized
DEBUG - 2025-05-12 15:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:58:53 --> Input Class Initialized
INFO - 2025-05-12 15:58:53 --> Language Class Initialized
INFO - 2025-05-12 15:58:53 --> Loader Class Initialized
INFO - 2025-05-12 15:58:53 --> Helper loaded: url_helper
INFO - 2025-05-12 15:58:53 --> Helper loaded: form_helper
INFO - 2025-05-12 15:58:53 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:58:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:58:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:58:53 --> Controller Class Initialized
INFO - 2025-05-12 15:58:53 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:58:53 --> Model "User_model" initialized
INFO - 2025-05-12 15:58:53 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:58:53 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:58:53 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-12 15:58:53 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:58:53 --> Final output sent to browser
DEBUG - 2025-05-12 15:58:53 --> Total execution time: 0.0786
INFO - 2025-05-12 15:58:58 --> Config Class Initialized
INFO - 2025-05-12 15:58:58 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:58:58 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:58:58 --> Utf8 Class Initialized
INFO - 2025-05-12 15:58:58 --> URI Class Initialized
INFO - 2025-05-12 15:58:58 --> Router Class Initialized
INFO - 2025-05-12 15:58:58 --> Output Class Initialized
INFO - 2025-05-12 15:58:58 --> Security Class Initialized
DEBUG - 2025-05-12 15:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:58:58 --> Input Class Initialized
INFO - 2025-05-12 15:58:58 --> Language Class Initialized
INFO - 2025-05-12 15:58:58 --> Loader Class Initialized
INFO - 2025-05-12 15:58:58 --> Helper loaded: url_helper
INFO - 2025-05-12 15:58:58 --> Helper loaded: form_helper
INFO - 2025-05-12 15:58:58 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:58:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:58:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:58:58 --> Controller Class Initialized
INFO - 2025-05-12 15:58:58 --> Model "User_model" initialized
INFO - 2025-05-12 15:58:58 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:58:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:58:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:58:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-12 15:58:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:58:58 --> Final output sent to browser
DEBUG - 2025-05-12 15:58:58 --> Total execution time: 0.0975
INFO - 2025-05-12 15:58:59 --> Config Class Initialized
INFO - 2025-05-12 15:58:59 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:58:59 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:58:59 --> Utf8 Class Initialized
INFO - 2025-05-12 15:58:59 --> URI Class Initialized
INFO - 2025-05-12 15:58:59 --> Router Class Initialized
INFO - 2025-05-12 15:58:59 --> Output Class Initialized
INFO - 2025-05-12 15:58:59 --> Security Class Initialized
DEBUG - 2025-05-12 15:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:58:59 --> Input Class Initialized
INFO - 2025-05-12 15:58:59 --> Language Class Initialized
INFO - 2025-05-12 15:58:59 --> Loader Class Initialized
INFO - 2025-05-12 15:58:59 --> Helper loaded: url_helper
INFO - 2025-05-12 15:58:59 --> Helper loaded: form_helper
INFO - 2025-05-12 15:58:59 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:58:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:58:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:58:59 --> Controller Class Initialized
INFO - 2025-05-12 15:58:59 --> Model "User_model" initialized
INFO - 2025-05-12 15:58:59 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:58:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:58:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:58:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-12 15:58:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:58:59 --> Final output sent to browser
DEBUG - 2025-05-12 15:58:59 --> Total execution time: 0.0805
INFO - 2025-05-12 15:59:01 --> Config Class Initialized
INFO - 2025-05-12 15:59:01 --> Hooks Class Initialized
DEBUG - 2025-05-12 15:59:01 --> UTF-8 Support Enabled
INFO - 2025-05-12 15:59:01 --> Utf8 Class Initialized
INFO - 2025-05-12 15:59:01 --> URI Class Initialized
INFO - 2025-05-12 15:59:01 --> Router Class Initialized
INFO - 2025-05-12 15:59:01 --> Output Class Initialized
INFO - 2025-05-12 15:59:01 --> Security Class Initialized
DEBUG - 2025-05-12 15:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 15:59:01 --> Input Class Initialized
INFO - 2025-05-12 15:59:01 --> Language Class Initialized
INFO - 2025-05-12 15:59:01 --> Loader Class Initialized
INFO - 2025-05-12 15:59:01 --> Helper loaded: url_helper
INFO - 2025-05-12 15:59:01 --> Helper loaded: form_helper
INFO - 2025-05-12 15:59:01 --> Database Driver Class Initialized
DEBUG - 2025-05-12 15:59:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 15:59:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 15:59:01 --> Controller Class Initialized
INFO - 2025-05-12 15:59:01 --> Model "Workout_model" initialized
INFO - 2025-05-12 15:59:01 --> Model "User_model" initialized
INFO - 2025-05-12 15:59:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 15:59:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 15:59:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-12 15:59:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 15:59:01 --> Final output sent to browser
DEBUG - 2025-05-12 15:59:01 --> Total execution time: 0.0865
INFO - 2025-05-12 16:11:59 --> Config Class Initialized
INFO - 2025-05-12 16:11:59 --> Hooks Class Initialized
DEBUG - 2025-05-12 16:11:59 --> UTF-8 Support Enabled
INFO - 2025-05-12 16:11:59 --> Utf8 Class Initialized
INFO - 2025-05-12 16:11:59 --> URI Class Initialized
INFO - 2025-05-12 16:11:59 --> Router Class Initialized
INFO - 2025-05-12 16:11:59 --> Output Class Initialized
INFO - 2025-05-12 16:11:59 --> Security Class Initialized
DEBUG - 2025-05-12 16:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 16:11:59 --> Input Class Initialized
INFO - 2025-05-12 16:11:59 --> Language Class Initialized
INFO - 2025-05-12 16:11:59 --> Loader Class Initialized
INFO - 2025-05-12 16:11:59 --> Helper loaded: url_helper
INFO - 2025-05-12 16:11:59 --> Helper loaded: form_helper
INFO - 2025-05-12 16:11:59 --> Database Driver Class Initialized
DEBUG - 2025-05-12 16:11:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 16:11:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 16:11:59 --> Controller Class Initialized
INFO - 2025-05-12 16:11:59 --> Model "Workout_model" initialized
INFO - 2025-05-12 16:11:59 --> Model "User_model" initialized
INFO - 2025-05-12 16:11:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 16:11:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 16:11:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-12 16:11:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 16:11:59 --> Final output sent to browser
DEBUG - 2025-05-12 16:11:59 --> Total execution time: 0.0936
INFO - 2025-05-12 16:12:01 --> Config Class Initialized
INFO - 2025-05-12 16:12:01 --> Hooks Class Initialized
DEBUG - 2025-05-12 16:12:01 --> UTF-8 Support Enabled
INFO - 2025-05-12 16:12:01 --> Utf8 Class Initialized
INFO - 2025-05-12 16:12:01 --> URI Class Initialized
INFO - 2025-05-12 16:12:01 --> Router Class Initialized
INFO - 2025-05-12 16:12:01 --> Output Class Initialized
INFO - 2025-05-12 16:12:01 --> Security Class Initialized
DEBUG - 2025-05-12 16:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 16:12:01 --> Input Class Initialized
INFO - 2025-05-12 16:12:01 --> Language Class Initialized
INFO - 2025-05-12 16:12:01 --> Loader Class Initialized
INFO - 2025-05-12 16:12:01 --> Helper loaded: url_helper
INFO - 2025-05-12 16:12:01 --> Helper loaded: form_helper
INFO - 2025-05-12 16:12:01 --> Database Driver Class Initialized
DEBUG - 2025-05-12 16:12:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 16:12:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 16:12:01 --> Controller Class Initialized
INFO - 2025-05-12 16:12:01 --> Model "Workout_model" initialized
INFO - 2025-05-12 16:12:01 --> Model "User_model" initialized
ERROR - 2025-05-12 16:12:01 --> Severity: Warning --> Undefined variable $data C:\laragon\www\Project\fitnessrecord\application\controllers\Workout.php 56
ERROR - 2025-05-12 16:12:01 --> Severity: Warning --> Undefined variable $user C:\laragon\www\Project\fitnessrecord\application\views\dashboard\layout\header.php 30
ERROR - 2025-05-12 16:12:01 --> Severity: Warning --> Attempt to read property "name" on null C:\laragon\www\Project\fitnessrecord\application\views\dashboard\layout\header.php 30
INFO - 2025-05-12 16:12:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 16:12:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 16:12:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/add_jadwal.php
INFO - 2025-05-12 16:12:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 16:12:01 --> Final output sent to browser
DEBUG - 2025-05-12 16:12:01 --> Total execution time: 0.1110
INFO - 2025-05-12 16:12:33 --> Config Class Initialized
INFO - 2025-05-12 16:12:33 --> Hooks Class Initialized
DEBUG - 2025-05-12 16:12:33 --> UTF-8 Support Enabled
INFO - 2025-05-12 16:12:33 --> Utf8 Class Initialized
INFO - 2025-05-12 16:12:33 --> URI Class Initialized
INFO - 2025-05-12 16:12:33 --> Router Class Initialized
INFO - 2025-05-12 16:12:33 --> Output Class Initialized
INFO - 2025-05-12 16:12:33 --> Security Class Initialized
DEBUG - 2025-05-12 16:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 16:12:33 --> Input Class Initialized
INFO - 2025-05-12 16:12:33 --> Language Class Initialized
INFO - 2025-05-12 16:12:33 --> Loader Class Initialized
INFO - 2025-05-12 16:12:33 --> Helper loaded: url_helper
INFO - 2025-05-12 16:12:33 --> Helper loaded: form_helper
INFO - 2025-05-12 16:12:33 --> Database Driver Class Initialized
DEBUG - 2025-05-12 16:12:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 16:12:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 16:12:33 --> Controller Class Initialized
INFO - 2025-05-12 16:12:33 --> Model "Workout_model" initialized
INFO - 2025-05-12 16:12:33 --> Model "User_model" initialized
INFO - 2025-05-12 16:12:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 16:12:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 16:12:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/add_jadwal.php
INFO - 2025-05-12 16:12:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 16:12:33 --> Final output sent to browser
DEBUG - 2025-05-12 16:12:33 --> Total execution time: 0.0831
INFO - 2025-05-12 16:13:54 --> Config Class Initialized
INFO - 2025-05-12 16:13:54 --> Hooks Class Initialized
DEBUG - 2025-05-12 16:13:54 --> UTF-8 Support Enabled
INFO - 2025-05-12 16:13:54 --> Utf8 Class Initialized
INFO - 2025-05-12 16:13:54 --> URI Class Initialized
INFO - 2025-05-12 16:13:54 --> Router Class Initialized
INFO - 2025-05-12 16:13:54 --> Output Class Initialized
INFO - 2025-05-12 16:13:54 --> Security Class Initialized
DEBUG - 2025-05-12 16:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 16:13:54 --> Input Class Initialized
INFO - 2025-05-12 16:13:54 --> Language Class Initialized
INFO - 2025-05-12 16:13:54 --> Loader Class Initialized
INFO - 2025-05-12 16:13:54 --> Helper loaded: url_helper
INFO - 2025-05-12 16:13:54 --> Helper loaded: form_helper
INFO - 2025-05-12 16:13:54 --> Database Driver Class Initialized
DEBUG - 2025-05-12 16:13:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 16:13:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 16:13:54 --> Controller Class Initialized
INFO - 2025-05-12 16:13:54 --> Model "Workout_model" initialized
INFO - 2025-05-12 16:13:54 --> Model "User_model" initialized
INFO - 2025-05-12 16:13:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 16:13:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 16:13:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/add_jadwal.php
INFO - 2025-05-12 16:13:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 16:13:54 --> Final output sent to browser
DEBUG - 2025-05-12 16:13:54 --> Total execution time: 0.1057
INFO - 2025-05-12 16:14:10 --> Config Class Initialized
INFO - 2025-05-12 16:14:10 --> Hooks Class Initialized
DEBUG - 2025-05-12 16:14:10 --> UTF-8 Support Enabled
INFO - 2025-05-12 16:14:10 --> Utf8 Class Initialized
INFO - 2025-05-12 16:14:10 --> URI Class Initialized
INFO - 2025-05-12 16:14:10 --> Router Class Initialized
INFO - 2025-05-12 16:14:10 --> Output Class Initialized
INFO - 2025-05-12 16:14:10 --> Security Class Initialized
DEBUG - 2025-05-12 16:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 16:14:10 --> Input Class Initialized
INFO - 2025-05-12 16:14:10 --> Language Class Initialized
INFO - 2025-05-12 16:14:10 --> Loader Class Initialized
INFO - 2025-05-12 16:14:10 --> Helper loaded: url_helper
INFO - 2025-05-12 16:14:10 --> Helper loaded: form_helper
INFO - 2025-05-12 16:14:10 --> Database Driver Class Initialized
DEBUG - 2025-05-12 16:14:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 16:14:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 16:14:10 --> Controller Class Initialized
INFO - 2025-05-12 16:14:10 --> Model "Workout_model" initialized
INFO - 2025-05-12 16:14:10 --> Model "User_model" initialized
INFO - 2025-05-12 16:14:10 --> Config Class Initialized
INFO - 2025-05-12 16:14:10 --> Hooks Class Initialized
DEBUG - 2025-05-12 16:14:10 --> UTF-8 Support Enabled
INFO - 2025-05-12 16:14:10 --> Utf8 Class Initialized
INFO - 2025-05-12 16:14:10 --> URI Class Initialized
INFO - 2025-05-12 16:14:10 --> Router Class Initialized
INFO - 2025-05-12 16:14:10 --> Output Class Initialized
INFO - 2025-05-12 16:14:10 --> Security Class Initialized
DEBUG - 2025-05-12 16:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 16:14:10 --> Input Class Initialized
INFO - 2025-05-12 16:14:10 --> Language Class Initialized
INFO - 2025-05-12 16:14:10 --> Loader Class Initialized
INFO - 2025-05-12 16:14:10 --> Helper loaded: url_helper
INFO - 2025-05-12 16:14:10 --> Helper loaded: form_helper
INFO - 2025-05-12 16:14:10 --> Database Driver Class Initialized
DEBUG - 2025-05-12 16:14:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 16:14:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 16:14:10 --> Controller Class Initialized
INFO - 2025-05-12 16:14:10 --> Model "Workout_model" initialized
INFO - 2025-05-12 16:14:10 --> Model "User_model" initialized
INFO - 2025-05-12 16:14:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 16:14:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 16:14:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-12 16:14:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 16:14:10 --> Final output sent to browser
DEBUG - 2025-05-12 16:14:10 --> Total execution time: 0.0776
INFO - 2025-05-12 16:14:21 --> Config Class Initialized
INFO - 2025-05-12 16:14:21 --> Hooks Class Initialized
DEBUG - 2025-05-12 16:14:21 --> UTF-8 Support Enabled
INFO - 2025-05-12 16:14:21 --> Utf8 Class Initialized
INFO - 2025-05-12 16:14:21 --> URI Class Initialized
INFO - 2025-05-12 16:14:21 --> Router Class Initialized
INFO - 2025-05-12 16:14:21 --> Output Class Initialized
INFO - 2025-05-12 16:14:21 --> Security Class Initialized
DEBUG - 2025-05-12 16:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 16:14:21 --> Input Class Initialized
INFO - 2025-05-12 16:14:21 --> Language Class Initialized
INFO - 2025-05-12 16:14:21 --> Loader Class Initialized
INFO - 2025-05-12 16:14:21 --> Helper loaded: url_helper
INFO - 2025-05-12 16:14:21 --> Helper loaded: form_helper
INFO - 2025-05-12 16:14:21 --> Database Driver Class Initialized
DEBUG - 2025-05-12 16:14:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 16:14:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 16:14:21 --> Controller Class Initialized
INFO - 2025-05-12 16:14:21 --> Model "Workout_model" initialized
INFO - 2025-05-12 16:14:21 --> Model "User_model" initialized
INFO - 2025-05-12 16:14:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/start.php
INFO - 2025-05-12 16:14:21 --> Final output sent to browser
DEBUG - 2025-05-12 16:14:21 --> Total execution time: 0.0883
INFO - 2025-05-12 16:14:28 --> Config Class Initialized
INFO - 2025-05-12 16:14:28 --> Hooks Class Initialized
DEBUG - 2025-05-12 16:14:28 --> UTF-8 Support Enabled
INFO - 2025-05-12 16:14:28 --> Utf8 Class Initialized
INFO - 2025-05-12 16:14:28 --> URI Class Initialized
INFO - 2025-05-12 16:14:28 --> Router Class Initialized
INFO - 2025-05-12 16:14:28 --> Output Class Initialized
INFO - 2025-05-12 16:14:28 --> Security Class Initialized
DEBUG - 2025-05-12 16:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 16:14:28 --> Input Class Initialized
INFO - 2025-05-12 16:14:28 --> Language Class Initialized
INFO - 2025-05-12 16:14:28 --> Loader Class Initialized
INFO - 2025-05-12 16:14:28 --> Helper loaded: url_helper
INFO - 2025-05-12 16:14:28 --> Helper loaded: form_helper
INFO - 2025-05-12 16:14:28 --> Database Driver Class Initialized
DEBUG - 2025-05-12 16:14:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 16:14:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 16:14:28 --> Controller Class Initialized
INFO - 2025-05-12 16:14:28 --> Model "Workout_model" initialized
INFO - 2025-05-12 16:14:28 --> Model "User_model" initialized
INFO - 2025-05-12 16:14:28 --> Final output sent to browser
DEBUG - 2025-05-12 16:14:28 --> Total execution time: 0.0894
INFO - 2025-05-12 16:14:28 --> Config Class Initialized
INFO - 2025-05-12 16:14:28 --> Hooks Class Initialized
DEBUG - 2025-05-12 16:14:28 --> UTF-8 Support Enabled
INFO - 2025-05-12 16:14:28 --> Utf8 Class Initialized
INFO - 2025-05-12 16:14:28 --> URI Class Initialized
INFO - 2025-05-12 16:14:28 --> Router Class Initialized
INFO - 2025-05-12 16:14:28 --> Output Class Initialized
INFO - 2025-05-12 16:14:28 --> Security Class Initialized
DEBUG - 2025-05-12 16:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 16:14:28 --> Input Class Initialized
INFO - 2025-05-12 16:14:28 --> Language Class Initialized
INFO - 2025-05-12 16:14:28 --> Loader Class Initialized
INFO - 2025-05-12 16:14:28 --> Helper loaded: url_helper
INFO - 2025-05-12 16:14:28 --> Helper loaded: form_helper
INFO - 2025-05-12 16:14:28 --> Database Driver Class Initialized
DEBUG - 2025-05-12 16:14:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 16:14:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 16:14:28 --> Controller Class Initialized
INFO - 2025-05-12 16:14:28 --> Model "Workout_model" initialized
INFO - 2025-05-12 16:14:28 --> Model "User_model" initialized
INFO - 2025-05-12 16:14:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 16:14:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 16:14:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-12 16:14:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 16:14:28 --> Final output sent to browser
DEBUG - 2025-05-12 16:14:28 --> Total execution time: 0.0849
INFO - 2025-05-12 16:14:37 --> Config Class Initialized
INFO - 2025-05-12 16:14:37 --> Hooks Class Initialized
DEBUG - 2025-05-12 16:14:37 --> UTF-8 Support Enabled
INFO - 2025-05-12 16:14:37 --> Utf8 Class Initialized
INFO - 2025-05-12 16:14:37 --> URI Class Initialized
INFO - 2025-05-12 16:14:37 --> Router Class Initialized
INFO - 2025-05-12 16:14:37 --> Output Class Initialized
INFO - 2025-05-12 16:14:37 --> Security Class Initialized
DEBUG - 2025-05-12 16:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 16:14:37 --> Input Class Initialized
INFO - 2025-05-12 16:14:37 --> Language Class Initialized
INFO - 2025-05-12 16:14:37 --> Loader Class Initialized
INFO - 2025-05-12 16:14:37 --> Helper loaded: url_helper
INFO - 2025-05-12 16:14:37 --> Helper loaded: form_helper
INFO - 2025-05-12 16:14:37 --> Database Driver Class Initialized
DEBUG - 2025-05-12 16:14:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 16:14:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 16:14:37 --> Controller Class Initialized
INFO - 2025-05-12 16:14:37 --> Model "Workout_model" initialized
INFO - 2025-05-12 16:14:37 --> Model "User_model" initialized
INFO - 2025-05-12 16:14:37 --> Config Class Initialized
INFO - 2025-05-12 16:14:37 --> Hooks Class Initialized
DEBUG - 2025-05-12 16:14:37 --> UTF-8 Support Enabled
INFO - 2025-05-12 16:14:37 --> Utf8 Class Initialized
INFO - 2025-05-12 16:14:37 --> URI Class Initialized
INFO - 2025-05-12 16:14:37 --> Router Class Initialized
INFO - 2025-05-12 16:14:37 --> Output Class Initialized
INFO - 2025-05-12 16:14:37 --> Security Class Initialized
DEBUG - 2025-05-12 16:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 16:14:37 --> Input Class Initialized
INFO - 2025-05-12 16:14:37 --> Language Class Initialized
INFO - 2025-05-12 16:14:37 --> Loader Class Initialized
INFO - 2025-05-12 16:14:37 --> Helper loaded: url_helper
INFO - 2025-05-12 16:14:37 --> Helper loaded: form_helper
INFO - 2025-05-12 16:14:37 --> Database Driver Class Initialized
DEBUG - 2025-05-12 16:14:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 16:14:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 16:14:37 --> Controller Class Initialized
INFO - 2025-05-12 16:14:37 --> Model "Workout_model" initialized
INFO - 2025-05-12 16:14:37 --> Model "User_model" initialized
INFO - 2025-05-12 16:14:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 16:14:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 16:14:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-12 16:14:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 16:14:37 --> Final output sent to browser
DEBUG - 2025-05-12 16:14:37 --> Total execution time: 0.0835
INFO - 2025-05-12 16:23:40 --> Config Class Initialized
INFO - 2025-05-12 16:23:40 --> Hooks Class Initialized
DEBUG - 2025-05-12 16:23:40 --> UTF-8 Support Enabled
INFO - 2025-05-12 16:23:40 --> Utf8 Class Initialized
INFO - 2025-05-12 16:23:40 --> URI Class Initialized
INFO - 2025-05-12 16:23:40 --> Router Class Initialized
INFO - 2025-05-12 16:23:40 --> Output Class Initialized
INFO - 2025-05-12 16:23:40 --> Security Class Initialized
DEBUG - 2025-05-12 16:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 16:23:40 --> Input Class Initialized
INFO - 2025-05-12 16:23:40 --> Language Class Initialized
INFO - 2025-05-12 16:23:40 --> Loader Class Initialized
INFO - 2025-05-12 16:23:40 --> Helper loaded: url_helper
INFO - 2025-05-12 16:23:40 --> Helper loaded: form_helper
INFO - 2025-05-12 16:23:40 --> Database Driver Class Initialized
DEBUG - 2025-05-12 16:23:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 16:23:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 16:23:40 --> Controller Class Initialized
INFO - 2025-05-12 16:23:40 --> Model "Workout_model" initialized
INFO - 2025-05-12 16:23:40 --> Model "User_model" initialized
INFO - 2025-05-12 16:23:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 16:23:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 16:23:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-12 16:23:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 16:23:40 --> Final output sent to browser
DEBUG - 2025-05-12 16:23:40 --> Total execution time: 0.0885
INFO - 2025-05-12 16:23:42 --> Config Class Initialized
INFO - 2025-05-12 16:23:42 --> Hooks Class Initialized
DEBUG - 2025-05-12 16:23:42 --> UTF-8 Support Enabled
INFO - 2025-05-12 16:23:42 --> Utf8 Class Initialized
INFO - 2025-05-12 16:23:42 --> URI Class Initialized
INFO - 2025-05-12 16:23:42 --> Router Class Initialized
INFO - 2025-05-12 16:23:42 --> Output Class Initialized
INFO - 2025-05-12 16:23:42 --> Security Class Initialized
DEBUG - 2025-05-12 16:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 16:23:42 --> Input Class Initialized
INFO - 2025-05-12 16:23:42 --> Language Class Initialized
INFO - 2025-05-12 16:23:42 --> Loader Class Initialized
INFO - 2025-05-12 16:23:42 --> Helper loaded: url_helper
INFO - 2025-05-12 16:23:42 --> Helper loaded: form_helper
INFO - 2025-05-12 16:23:42 --> Database Driver Class Initialized
DEBUG - 2025-05-12 16:23:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 16:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 16:23:42 --> Controller Class Initialized
INFO - 2025-05-12 16:23:42 --> Model "Workout_model" initialized
INFO - 2025-05-12 16:23:42 --> Model "User_model" initialized
INFO - 2025-05-12 16:23:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 16:23:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 16:23:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/add_jadwal.php
INFO - 2025-05-12 16:23:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 16:23:42 --> Final output sent to browser
DEBUG - 2025-05-12 16:23:42 --> Total execution time: 0.0806
INFO - 2025-05-12 16:23:51 --> Config Class Initialized
INFO - 2025-05-12 16:23:51 --> Hooks Class Initialized
DEBUG - 2025-05-12 16:23:51 --> UTF-8 Support Enabled
INFO - 2025-05-12 16:23:51 --> Utf8 Class Initialized
INFO - 2025-05-12 16:23:51 --> URI Class Initialized
INFO - 2025-05-12 16:23:51 --> Router Class Initialized
INFO - 2025-05-12 16:23:51 --> Output Class Initialized
INFO - 2025-05-12 16:23:51 --> Security Class Initialized
DEBUG - 2025-05-12 16:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 16:23:51 --> Input Class Initialized
INFO - 2025-05-12 16:23:51 --> Language Class Initialized
INFO - 2025-05-12 16:23:51 --> Loader Class Initialized
INFO - 2025-05-12 16:23:51 --> Helper loaded: url_helper
INFO - 2025-05-12 16:23:51 --> Helper loaded: form_helper
INFO - 2025-05-12 16:23:51 --> Database Driver Class Initialized
DEBUG - 2025-05-12 16:23:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 16:23:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 16:23:51 --> Controller Class Initialized
INFO - 2025-05-12 16:23:51 --> Model "Workout_model" initialized
INFO - 2025-05-12 16:23:51 --> Model "User_model" initialized
INFO - 2025-05-12 16:23:51 --> Config Class Initialized
INFO - 2025-05-12 16:23:51 --> Hooks Class Initialized
DEBUG - 2025-05-12 16:23:51 --> UTF-8 Support Enabled
INFO - 2025-05-12 16:23:51 --> Utf8 Class Initialized
INFO - 2025-05-12 16:23:51 --> URI Class Initialized
INFO - 2025-05-12 16:23:51 --> Router Class Initialized
INFO - 2025-05-12 16:23:51 --> Output Class Initialized
INFO - 2025-05-12 16:23:51 --> Security Class Initialized
DEBUG - 2025-05-12 16:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 16:23:51 --> Input Class Initialized
INFO - 2025-05-12 16:23:51 --> Language Class Initialized
INFO - 2025-05-12 16:23:51 --> Loader Class Initialized
INFO - 2025-05-12 16:23:51 --> Helper loaded: url_helper
INFO - 2025-05-12 16:23:51 --> Helper loaded: form_helper
INFO - 2025-05-12 16:23:51 --> Database Driver Class Initialized
DEBUG - 2025-05-12 16:23:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 16:23:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 16:23:51 --> Controller Class Initialized
INFO - 2025-05-12 16:23:51 --> Model "Workout_model" initialized
INFO - 2025-05-12 16:23:51 --> Model "User_model" initialized
INFO - 2025-05-12 16:23:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 16:23:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 16:23:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-12 16:23:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 16:23:51 --> Final output sent to browser
DEBUG - 2025-05-12 16:23:51 --> Total execution time: 0.0828
INFO - 2025-05-12 16:23:53 --> Config Class Initialized
INFO - 2025-05-12 16:23:53 --> Hooks Class Initialized
DEBUG - 2025-05-12 16:23:53 --> UTF-8 Support Enabled
INFO - 2025-05-12 16:23:53 --> Utf8 Class Initialized
INFO - 2025-05-12 16:23:53 --> URI Class Initialized
INFO - 2025-05-12 16:23:53 --> Router Class Initialized
INFO - 2025-05-12 16:23:53 --> Output Class Initialized
INFO - 2025-05-12 16:23:53 --> Security Class Initialized
DEBUG - 2025-05-12 16:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 16:23:53 --> Input Class Initialized
INFO - 2025-05-12 16:23:53 --> Language Class Initialized
INFO - 2025-05-12 16:23:53 --> Loader Class Initialized
INFO - 2025-05-12 16:23:53 --> Helper loaded: url_helper
INFO - 2025-05-12 16:23:53 --> Helper loaded: form_helper
INFO - 2025-05-12 16:23:53 --> Database Driver Class Initialized
DEBUG - 2025-05-12 16:23:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 16:23:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 16:23:53 --> Controller Class Initialized
INFO - 2025-05-12 16:23:53 --> Model "Workout_model" initialized
INFO - 2025-05-12 16:23:53 --> Model "User_model" initialized
INFO - 2025-05-12 16:23:53 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/start.php
INFO - 2025-05-12 16:23:53 --> Final output sent to browser
DEBUG - 2025-05-12 16:23:53 --> Total execution time: 0.0799
INFO - 2025-05-12 16:24:09 --> Config Class Initialized
INFO - 2025-05-12 16:24:09 --> Hooks Class Initialized
DEBUG - 2025-05-12 16:24:09 --> UTF-8 Support Enabled
INFO - 2025-05-12 16:24:09 --> Utf8 Class Initialized
INFO - 2025-05-12 16:24:09 --> URI Class Initialized
INFO - 2025-05-12 16:24:09 --> Router Class Initialized
INFO - 2025-05-12 16:24:09 --> Output Class Initialized
INFO - 2025-05-12 16:24:09 --> Security Class Initialized
DEBUG - 2025-05-12 16:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 16:24:09 --> Input Class Initialized
INFO - 2025-05-12 16:24:09 --> Language Class Initialized
INFO - 2025-05-12 16:24:09 --> Loader Class Initialized
INFO - 2025-05-12 16:24:09 --> Helper loaded: url_helper
INFO - 2025-05-12 16:24:09 --> Helper loaded: form_helper
INFO - 2025-05-12 16:24:09 --> Database Driver Class Initialized
DEBUG - 2025-05-12 16:24:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 16:24:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 16:24:09 --> Controller Class Initialized
INFO - 2025-05-12 16:24:09 --> Model "Workout_model" initialized
INFO - 2025-05-12 16:24:09 --> Model "User_model" initialized
INFO - 2025-05-12 16:24:09 --> Final output sent to browser
DEBUG - 2025-05-12 16:24:09 --> Total execution time: 0.1096
INFO - 2025-05-12 16:24:09 --> Config Class Initialized
INFO - 2025-05-12 16:24:09 --> Hooks Class Initialized
DEBUG - 2025-05-12 16:24:09 --> UTF-8 Support Enabled
INFO - 2025-05-12 16:24:09 --> Utf8 Class Initialized
INFO - 2025-05-12 16:24:09 --> URI Class Initialized
INFO - 2025-05-12 16:24:09 --> Router Class Initialized
INFO - 2025-05-12 16:24:09 --> Output Class Initialized
INFO - 2025-05-12 16:24:09 --> Security Class Initialized
DEBUG - 2025-05-12 16:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 16:24:09 --> Input Class Initialized
INFO - 2025-05-12 16:24:09 --> Language Class Initialized
INFO - 2025-05-12 16:24:09 --> Loader Class Initialized
INFO - 2025-05-12 16:24:09 --> Helper loaded: url_helper
INFO - 2025-05-12 16:24:09 --> Helper loaded: form_helper
INFO - 2025-05-12 16:24:09 --> Database Driver Class Initialized
DEBUG - 2025-05-12 16:24:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 16:24:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 16:24:09 --> Controller Class Initialized
INFO - 2025-05-12 16:24:09 --> Model "Workout_model" initialized
INFO - 2025-05-12 16:24:09 --> Model "User_model" initialized
INFO - 2025-05-12 16:24:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 16:24:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 16:24:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-12 16:24:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 16:24:09 --> Final output sent to browser
DEBUG - 2025-05-12 16:24:09 --> Total execution time: 0.1021
INFO - 2025-05-12 16:24:18 --> Config Class Initialized
INFO - 2025-05-12 16:24:18 --> Hooks Class Initialized
DEBUG - 2025-05-12 16:24:18 --> UTF-8 Support Enabled
INFO - 2025-05-12 16:24:18 --> Utf8 Class Initialized
INFO - 2025-05-12 16:24:18 --> URI Class Initialized
INFO - 2025-05-12 16:24:18 --> Router Class Initialized
INFO - 2025-05-12 16:24:18 --> Output Class Initialized
INFO - 2025-05-12 16:24:18 --> Security Class Initialized
DEBUG - 2025-05-12 16:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 16:24:18 --> Input Class Initialized
INFO - 2025-05-12 16:24:18 --> Language Class Initialized
INFO - 2025-05-12 16:24:18 --> Loader Class Initialized
INFO - 2025-05-12 16:24:18 --> Helper loaded: url_helper
INFO - 2025-05-12 16:24:18 --> Helper loaded: form_helper
INFO - 2025-05-12 16:24:18 --> Database Driver Class Initialized
DEBUG - 2025-05-12 16:24:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 16:24:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 16:24:18 --> Controller Class Initialized
INFO - 2025-05-12 16:24:18 --> Model "Workout_model" initialized
INFO - 2025-05-12 16:24:18 --> Model "User_model" initialized
INFO - 2025-05-12 16:24:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 16:24:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 16:24:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/add_jadwal.php
INFO - 2025-05-12 16:24:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 16:24:18 --> Final output sent to browser
DEBUG - 2025-05-12 16:24:18 --> Total execution time: 0.0956
INFO - 2025-05-12 16:24:30 --> Config Class Initialized
INFO - 2025-05-12 16:24:30 --> Hooks Class Initialized
DEBUG - 2025-05-12 16:24:30 --> UTF-8 Support Enabled
INFO - 2025-05-12 16:24:30 --> Utf8 Class Initialized
INFO - 2025-05-12 16:24:30 --> URI Class Initialized
INFO - 2025-05-12 16:24:30 --> Router Class Initialized
INFO - 2025-05-12 16:24:30 --> Output Class Initialized
INFO - 2025-05-12 16:24:30 --> Security Class Initialized
DEBUG - 2025-05-12 16:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 16:24:30 --> Input Class Initialized
INFO - 2025-05-12 16:24:30 --> Language Class Initialized
INFO - 2025-05-12 16:24:30 --> Loader Class Initialized
INFO - 2025-05-12 16:24:30 --> Helper loaded: url_helper
INFO - 2025-05-12 16:24:30 --> Helper loaded: form_helper
INFO - 2025-05-12 16:24:30 --> Database Driver Class Initialized
DEBUG - 2025-05-12 16:24:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 16:24:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 16:24:30 --> Controller Class Initialized
INFO - 2025-05-12 16:24:30 --> Model "Workout_model" initialized
INFO - 2025-05-12 16:24:30 --> Model "User_model" initialized
INFO - 2025-05-12 16:24:30 --> Config Class Initialized
INFO - 2025-05-12 16:24:30 --> Hooks Class Initialized
DEBUG - 2025-05-12 16:24:30 --> UTF-8 Support Enabled
INFO - 2025-05-12 16:24:30 --> Utf8 Class Initialized
INFO - 2025-05-12 16:24:30 --> URI Class Initialized
INFO - 2025-05-12 16:24:30 --> Router Class Initialized
INFO - 2025-05-12 16:24:30 --> Output Class Initialized
INFO - 2025-05-12 16:24:30 --> Security Class Initialized
DEBUG - 2025-05-12 16:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 16:24:30 --> Input Class Initialized
INFO - 2025-05-12 16:24:30 --> Language Class Initialized
INFO - 2025-05-12 16:24:30 --> Loader Class Initialized
INFO - 2025-05-12 16:24:30 --> Helper loaded: url_helper
INFO - 2025-05-12 16:24:30 --> Helper loaded: form_helper
INFO - 2025-05-12 16:24:30 --> Database Driver Class Initialized
DEBUG - 2025-05-12 16:24:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 16:24:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 16:24:30 --> Controller Class Initialized
INFO - 2025-05-12 16:24:30 --> Model "Workout_model" initialized
INFO - 2025-05-12 16:24:30 --> Model "User_model" initialized
INFO - 2025-05-12 16:24:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 16:24:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 16:24:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-12 16:24:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 16:24:30 --> Final output sent to browser
DEBUG - 2025-05-12 16:24:30 --> Total execution time: 0.1035
INFO - 2025-05-12 16:24:34 --> Config Class Initialized
INFO - 2025-05-12 16:24:34 --> Hooks Class Initialized
DEBUG - 2025-05-12 16:24:34 --> UTF-8 Support Enabled
INFO - 2025-05-12 16:24:34 --> Utf8 Class Initialized
INFO - 2025-05-12 16:24:34 --> URI Class Initialized
INFO - 2025-05-12 16:24:34 --> Router Class Initialized
INFO - 2025-05-12 16:24:34 --> Output Class Initialized
INFO - 2025-05-12 16:24:34 --> Security Class Initialized
DEBUG - 2025-05-12 16:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 16:24:34 --> Input Class Initialized
INFO - 2025-05-12 16:24:34 --> Language Class Initialized
INFO - 2025-05-12 16:24:34 --> Loader Class Initialized
INFO - 2025-05-12 16:24:34 --> Helper loaded: url_helper
INFO - 2025-05-12 16:24:34 --> Helper loaded: form_helper
INFO - 2025-05-12 16:24:34 --> Database Driver Class Initialized
DEBUG - 2025-05-12 16:24:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 16:24:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 16:24:34 --> Controller Class Initialized
INFO - 2025-05-12 16:24:34 --> Model "Workout_model" initialized
INFO - 2025-05-12 16:24:34 --> Model "User_model" initialized
INFO - 2025-05-12 16:24:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/start.php
INFO - 2025-05-12 16:24:34 --> Final output sent to browser
DEBUG - 2025-05-12 16:24:34 --> Total execution time: 0.0739
INFO - 2025-05-12 16:24:49 --> Config Class Initialized
INFO - 2025-05-12 16:24:49 --> Hooks Class Initialized
DEBUG - 2025-05-12 16:24:49 --> UTF-8 Support Enabled
INFO - 2025-05-12 16:24:49 --> Utf8 Class Initialized
INFO - 2025-05-12 16:24:49 --> URI Class Initialized
INFO - 2025-05-12 16:24:49 --> Router Class Initialized
INFO - 2025-05-12 16:24:49 --> Output Class Initialized
INFO - 2025-05-12 16:24:49 --> Security Class Initialized
DEBUG - 2025-05-12 16:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 16:24:49 --> Input Class Initialized
INFO - 2025-05-12 16:24:49 --> Language Class Initialized
INFO - 2025-05-12 16:24:49 --> Loader Class Initialized
INFO - 2025-05-12 16:24:49 --> Helper loaded: url_helper
INFO - 2025-05-12 16:24:49 --> Helper loaded: form_helper
INFO - 2025-05-12 16:24:49 --> Database Driver Class Initialized
DEBUG - 2025-05-12 16:24:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 16:24:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 16:24:49 --> Controller Class Initialized
INFO - 2025-05-12 16:24:49 --> Model "Workout_model" initialized
INFO - 2025-05-12 16:24:49 --> Model "User_model" initialized
INFO - 2025-05-12 16:24:49 --> Final output sent to browser
DEBUG - 2025-05-12 16:24:49 --> Total execution time: 0.0875
INFO - 2025-05-12 16:24:49 --> Config Class Initialized
INFO - 2025-05-12 16:24:49 --> Hooks Class Initialized
DEBUG - 2025-05-12 16:24:49 --> UTF-8 Support Enabled
INFO - 2025-05-12 16:24:49 --> Utf8 Class Initialized
INFO - 2025-05-12 16:24:49 --> URI Class Initialized
INFO - 2025-05-12 16:24:49 --> Router Class Initialized
INFO - 2025-05-12 16:24:49 --> Output Class Initialized
INFO - 2025-05-12 16:24:49 --> Security Class Initialized
DEBUG - 2025-05-12 16:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 16:24:49 --> Input Class Initialized
INFO - 2025-05-12 16:24:49 --> Language Class Initialized
INFO - 2025-05-12 16:24:49 --> Loader Class Initialized
INFO - 2025-05-12 16:24:49 --> Helper loaded: url_helper
INFO - 2025-05-12 16:24:49 --> Helper loaded: form_helper
INFO - 2025-05-12 16:24:49 --> Database Driver Class Initialized
DEBUG - 2025-05-12 16:24:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 16:24:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 16:24:49 --> Controller Class Initialized
INFO - 2025-05-12 16:24:49 --> Model "Workout_model" initialized
INFO - 2025-05-12 16:24:49 --> Model "User_model" initialized
INFO - 2025-05-12 16:24:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 16:24:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 16:24:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-12 16:24:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 16:24:49 --> Final output sent to browser
DEBUG - 2025-05-12 16:24:49 --> Total execution time: 0.0918
INFO - 2025-05-12 16:24:56 --> Config Class Initialized
INFO - 2025-05-12 16:24:56 --> Hooks Class Initialized
DEBUG - 2025-05-12 16:24:56 --> UTF-8 Support Enabled
INFO - 2025-05-12 16:24:56 --> Utf8 Class Initialized
INFO - 2025-05-12 16:24:56 --> URI Class Initialized
INFO - 2025-05-12 16:24:56 --> Router Class Initialized
INFO - 2025-05-12 16:24:56 --> Output Class Initialized
INFO - 2025-05-12 16:24:56 --> Security Class Initialized
DEBUG - 2025-05-12 16:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 16:24:56 --> Input Class Initialized
INFO - 2025-05-12 16:24:56 --> Language Class Initialized
INFO - 2025-05-12 16:24:56 --> Loader Class Initialized
INFO - 2025-05-12 16:24:56 --> Helper loaded: url_helper
INFO - 2025-05-12 16:24:56 --> Helper loaded: form_helper
INFO - 2025-05-12 16:24:56 --> Database Driver Class Initialized
DEBUG - 2025-05-12 16:24:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 16:24:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 16:24:56 --> Controller Class Initialized
INFO - 2025-05-12 16:24:56 --> Model "Workout_model" initialized
INFO - 2025-05-12 16:24:56 --> Model "User_model" initialized
INFO - 2025-05-12 16:24:56 --> Config Class Initialized
INFO - 2025-05-12 16:24:56 --> Hooks Class Initialized
DEBUG - 2025-05-12 16:24:56 --> UTF-8 Support Enabled
INFO - 2025-05-12 16:24:56 --> Utf8 Class Initialized
INFO - 2025-05-12 16:24:56 --> URI Class Initialized
INFO - 2025-05-12 16:24:56 --> Router Class Initialized
INFO - 2025-05-12 16:24:56 --> Output Class Initialized
INFO - 2025-05-12 16:24:56 --> Security Class Initialized
DEBUG - 2025-05-12 16:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 16:24:56 --> Input Class Initialized
INFO - 2025-05-12 16:24:56 --> Language Class Initialized
INFO - 2025-05-12 16:24:56 --> Loader Class Initialized
INFO - 2025-05-12 16:24:56 --> Helper loaded: url_helper
INFO - 2025-05-12 16:24:56 --> Helper loaded: form_helper
INFO - 2025-05-12 16:24:56 --> Database Driver Class Initialized
DEBUG - 2025-05-12 16:24:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 16:24:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 16:24:56 --> Controller Class Initialized
INFO - 2025-05-12 16:24:56 --> Model "Workout_model" initialized
INFO - 2025-05-12 16:24:56 --> Model "User_model" initialized
INFO - 2025-05-12 16:24:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 16:24:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 16:24:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-12 16:24:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 16:24:56 --> Final output sent to browser
DEBUG - 2025-05-12 16:24:56 --> Total execution time: 0.0871
INFO - 2025-05-12 16:25:38 --> Config Class Initialized
INFO - 2025-05-12 16:25:38 --> Hooks Class Initialized
DEBUG - 2025-05-12 16:25:38 --> UTF-8 Support Enabled
INFO - 2025-05-12 16:25:38 --> Utf8 Class Initialized
INFO - 2025-05-12 16:25:38 --> URI Class Initialized
INFO - 2025-05-12 16:25:38 --> Router Class Initialized
INFO - 2025-05-12 16:25:38 --> Output Class Initialized
INFO - 2025-05-12 16:25:38 --> Security Class Initialized
DEBUG - 2025-05-12 16:25:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 16:25:38 --> Input Class Initialized
INFO - 2025-05-12 16:25:38 --> Language Class Initialized
INFO - 2025-05-12 16:25:38 --> Loader Class Initialized
INFO - 2025-05-12 16:25:38 --> Helper loaded: url_helper
INFO - 2025-05-12 16:25:38 --> Helper loaded: form_helper
INFO - 2025-05-12 16:25:38 --> Database Driver Class Initialized
DEBUG - 2025-05-12 16:25:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 16:25:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 16:25:38 --> Controller Class Initialized
INFO - 2025-05-12 16:25:38 --> Model "Workout_model" initialized
INFO - 2025-05-12 16:25:38 --> Model "User_model" initialized
INFO - 2025-05-12 16:25:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 16:25:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 16:25:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-12 16:25:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 16:25:38 --> Final output sent to browser
DEBUG - 2025-05-12 16:25:38 --> Total execution time: 0.1110
INFO - 2025-05-12 16:25:39 --> Config Class Initialized
INFO - 2025-05-12 16:25:39 --> Hooks Class Initialized
DEBUG - 2025-05-12 16:25:39 --> UTF-8 Support Enabled
INFO - 2025-05-12 16:25:39 --> Utf8 Class Initialized
INFO - 2025-05-12 16:25:39 --> URI Class Initialized
INFO - 2025-05-12 16:25:39 --> Router Class Initialized
INFO - 2025-05-12 16:25:39 --> Output Class Initialized
INFO - 2025-05-12 16:25:39 --> Security Class Initialized
DEBUG - 2025-05-12 16:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 16:25:39 --> Input Class Initialized
INFO - 2025-05-12 16:25:39 --> Language Class Initialized
INFO - 2025-05-12 16:25:39 --> Loader Class Initialized
INFO - 2025-05-12 16:25:39 --> Helper loaded: url_helper
INFO - 2025-05-12 16:25:39 --> Helper loaded: form_helper
INFO - 2025-05-12 16:25:39 --> Database Driver Class Initialized
DEBUG - 2025-05-12 16:25:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 16:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 16:25:39 --> Controller Class Initialized
INFO - 2025-05-12 16:25:39 --> Model "Workout_model" initialized
INFO - 2025-05-12 16:25:39 --> Model "User_model" initialized
INFO - 2025-05-12 16:25:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 16:25:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 16:25:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/add_jadwal.php
INFO - 2025-05-12 16:25:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 16:25:39 --> Final output sent to browser
DEBUG - 2025-05-12 16:25:39 --> Total execution time: 0.0853
INFO - 2025-05-12 16:25:50 --> Config Class Initialized
INFO - 2025-05-12 16:25:50 --> Hooks Class Initialized
DEBUG - 2025-05-12 16:25:50 --> UTF-8 Support Enabled
INFO - 2025-05-12 16:25:50 --> Utf8 Class Initialized
INFO - 2025-05-12 16:25:50 --> URI Class Initialized
INFO - 2025-05-12 16:25:50 --> Router Class Initialized
INFO - 2025-05-12 16:25:50 --> Output Class Initialized
INFO - 2025-05-12 16:25:50 --> Security Class Initialized
DEBUG - 2025-05-12 16:25:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 16:25:50 --> Input Class Initialized
INFO - 2025-05-12 16:25:50 --> Language Class Initialized
INFO - 2025-05-12 16:25:50 --> Loader Class Initialized
INFO - 2025-05-12 16:25:50 --> Helper loaded: url_helper
INFO - 2025-05-12 16:25:50 --> Helper loaded: form_helper
INFO - 2025-05-12 16:25:50 --> Database Driver Class Initialized
DEBUG - 2025-05-12 16:25:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 16:25:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 16:25:50 --> Controller Class Initialized
INFO - 2025-05-12 16:25:50 --> Model "Workout_model" initialized
INFO - 2025-05-12 16:25:50 --> Model "User_model" initialized
INFO - 2025-05-12 16:25:50 --> Config Class Initialized
INFO - 2025-05-12 16:25:50 --> Hooks Class Initialized
DEBUG - 2025-05-12 16:25:50 --> UTF-8 Support Enabled
INFO - 2025-05-12 16:25:50 --> Utf8 Class Initialized
INFO - 2025-05-12 16:25:50 --> URI Class Initialized
INFO - 2025-05-12 16:25:50 --> Router Class Initialized
INFO - 2025-05-12 16:25:50 --> Output Class Initialized
INFO - 2025-05-12 16:25:50 --> Security Class Initialized
DEBUG - 2025-05-12 16:25:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 16:25:50 --> Input Class Initialized
INFO - 2025-05-12 16:25:50 --> Language Class Initialized
INFO - 2025-05-12 16:25:50 --> Loader Class Initialized
INFO - 2025-05-12 16:25:50 --> Helper loaded: url_helper
INFO - 2025-05-12 16:25:50 --> Helper loaded: form_helper
INFO - 2025-05-12 16:25:50 --> Database Driver Class Initialized
DEBUG - 2025-05-12 16:25:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 16:25:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 16:25:50 --> Controller Class Initialized
INFO - 2025-05-12 16:25:50 --> Model "Workout_model" initialized
INFO - 2025-05-12 16:25:50 --> Model "User_model" initialized
INFO - 2025-05-12 16:25:50 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 16:25:50 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 16:25:50 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-12 16:25:50 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 16:25:50 --> Final output sent to browser
DEBUG - 2025-05-12 16:25:50 --> Total execution time: 0.0809
INFO - 2025-05-12 16:25:52 --> Config Class Initialized
INFO - 2025-05-12 16:25:52 --> Hooks Class Initialized
DEBUG - 2025-05-12 16:25:52 --> UTF-8 Support Enabled
INFO - 2025-05-12 16:25:52 --> Utf8 Class Initialized
INFO - 2025-05-12 16:25:52 --> URI Class Initialized
INFO - 2025-05-12 16:25:52 --> Router Class Initialized
INFO - 2025-05-12 16:25:52 --> Output Class Initialized
INFO - 2025-05-12 16:25:52 --> Security Class Initialized
DEBUG - 2025-05-12 16:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 16:25:52 --> Input Class Initialized
INFO - 2025-05-12 16:25:52 --> Language Class Initialized
INFO - 2025-05-12 16:25:52 --> Loader Class Initialized
INFO - 2025-05-12 16:25:52 --> Helper loaded: url_helper
INFO - 2025-05-12 16:25:52 --> Helper loaded: form_helper
INFO - 2025-05-12 16:25:52 --> Database Driver Class Initialized
DEBUG - 2025-05-12 16:25:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 16:25:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 16:25:52 --> Controller Class Initialized
INFO - 2025-05-12 16:25:52 --> Model "Workout_model" initialized
INFO - 2025-05-12 16:25:52 --> Model "User_model" initialized
INFO - 2025-05-12 16:25:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/start.php
INFO - 2025-05-12 16:25:52 --> Final output sent to browser
DEBUG - 2025-05-12 16:25:52 --> Total execution time: 0.0921
INFO - 2025-05-12 16:25:56 --> Config Class Initialized
INFO - 2025-05-12 16:25:56 --> Hooks Class Initialized
DEBUG - 2025-05-12 16:25:56 --> UTF-8 Support Enabled
INFO - 2025-05-12 16:25:56 --> Utf8 Class Initialized
INFO - 2025-05-12 16:25:56 --> URI Class Initialized
INFO - 2025-05-12 16:25:56 --> Router Class Initialized
INFO - 2025-05-12 16:25:56 --> Output Class Initialized
INFO - 2025-05-12 16:25:56 --> Security Class Initialized
DEBUG - 2025-05-12 16:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 16:25:56 --> Input Class Initialized
INFO - 2025-05-12 16:25:56 --> Language Class Initialized
INFO - 2025-05-12 16:25:56 --> Loader Class Initialized
INFO - 2025-05-12 16:25:56 --> Helper loaded: url_helper
INFO - 2025-05-12 16:25:56 --> Helper loaded: form_helper
INFO - 2025-05-12 16:25:56 --> Database Driver Class Initialized
DEBUG - 2025-05-12 16:25:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 16:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 16:25:56 --> Controller Class Initialized
INFO - 2025-05-12 16:25:56 --> Model "Workout_model" initialized
INFO - 2025-05-12 16:25:56 --> Model "User_model" initialized
INFO - 2025-05-12 16:25:56 --> Final output sent to browser
DEBUG - 2025-05-12 16:25:56 --> Total execution time: 0.1095
INFO - 2025-05-12 16:25:56 --> Config Class Initialized
INFO - 2025-05-12 16:25:56 --> Hooks Class Initialized
DEBUG - 2025-05-12 16:25:56 --> UTF-8 Support Enabled
INFO - 2025-05-12 16:25:56 --> Utf8 Class Initialized
INFO - 2025-05-12 16:25:56 --> URI Class Initialized
INFO - 2025-05-12 16:25:56 --> Router Class Initialized
INFO - 2025-05-12 16:25:56 --> Output Class Initialized
INFO - 2025-05-12 16:25:56 --> Security Class Initialized
DEBUG - 2025-05-12 16:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 16:25:56 --> Input Class Initialized
INFO - 2025-05-12 16:25:56 --> Language Class Initialized
INFO - 2025-05-12 16:25:56 --> Loader Class Initialized
INFO - 2025-05-12 16:25:56 --> Helper loaded: url_helper
INFO - 2025-05-12 16:25:56 --> Helper loaded: form_helper
INFO - 2025-05-12 16:25:56 --> Database Driver Class Initialized
DEBUG - 2025-05-12 16:25:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 16:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 16:25:56 --> Controller Class Initialized
INFO - 2025-05-12 16:25:56 --> Model "Workout_model" initialized
INFO - 2025-05-12 16:25:56 --> Model "User_model" initialized
INFO - 2025-05-12 16:25:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 16:25:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 16:25:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-12 16:25:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 16:25:56 --> Final output sent to browser
DEBUG - 2025-05-12 16:25:56 --> Total execution time: 0.1099
INFO - 2025-05-12 16:26:00 --> Config Class Initialized
INFO - 2025-05-12 16:26:00 --> Hooks Class Initialized
DEBUG - 2025-05-12 16:26:00 --> UTF-8 Support Enabled
INFO - 2025-05-12 16:26:00 --> Utf8 Class Initialized
INFO - 2025-05-12 16:26:00 --> URI Class Initialized
INFO - 2025-05-12 16:26:00 --> Router Class Initialized
INFO - 2025-05-12 16:26:00 --> Output Class Initialized
INFO - 2025-05-12 16:26:00 --> Security Class Initialized
DEBUG - 2025-05-12 16:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 16:26:00 --> Input Class Initialized
INFO - 2025-05-12 16:26:00 --> Language Class Initialized
INFO - 2025-05-12 16:26:00 --> Loader Class Initialized
INFO - 2025-05-12 16:26:00 --> Helper loaded: url_helper
INFO - 2025-05-12 16:26:00 --> Helper loaded: form_helper
INFO - 2025-05-12 16:26:00 --> Database Driver Class Initialized
DEBUG - 2025-05-12 16:26:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 16:26:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 16:26:00 --> Controller Class Initialized
INFO - 2025-05-12 16:26:00 --> Model "Workout_model" initialized
INFO - 2025-05-12 16:26:00 --> Model "User_model" initialized
INFO - 2025-05-12 16:26:00 --> Config Class Initialized
INFO - 2025-05-12 16:26:00 --> Hooks Class Initialized
DEBUG - 2025-05-12 16:26:00 --> UTF-8 Support Enabled
INFO - 2025-05-12 16:26:00 --> Utf8 Class Initialized
INFO - 2025-05-12 16:26:00 --> URI Class Initialized
INFO - 2025-05-12 16:26:00 --> Router Class Initialized
INFO - 2025-05-12 16:26:00 --> Output Class Initialized
INFO - 2025-05-12 16:26:00 --> Security Class Initialized
DEBUG - 2025-05-12 16:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 16:26:00 --> Input Class Initialized
INFO - 2025-05-12 16:26:00 --> Language Class Initialized
INFO - 2025-05-12 16:26:00 --> Loader Class Initialized
INFO - 2025-05-12 16:26:00 --> Helper loaded: url_helper
INFO - 2025-05-12 16:26:00 --> Helper loaded: form_helper
INFO - 2025-05-12 16:26:00 --> Database Driver Class Initialized
DEBUG - 2025-05-12 16:26:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 16:26:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 16:26:00 --> Controller Class Initialized
INFO - 2025-05-12 16:26:00 --> Model "Workout_model" initialized
INFO - 2025-05-12 16:26:00 --> Model "User_model" initialized
INFO - 2025-05-12 16:26:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 16:26:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 16:26:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-12 16:26:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 16:26:00 --> Final output sent to browser
DEBUG - 2025-05-12 16:26:00 --> Total execution time: 0.0849
INFO - 2025-05-12 16:26:02 --> Config Class Initialized
INFO - 2025-05-12 16:26:02 --> Hooks Class Initialized
DEBUG - 2025-05-12 16:26:02 --> UTF-8 Support Enabled
INFO - 2025-05-12 16:26:02 --> Utf8 Class Initialized
INFO - 2025-05-12 16:26:02 --> URI Class Initialized
INFO - 2025-05-12 16:26:02 --> Router Class Initialized
INFO - 2025-05-12 16:26:02 --> Output Class Initialized
INFO - 2025-05-12 16:26:02 --> Security Class Initialized
DEBUG - 2025-05-12 16:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 16:26:02 --> Input Class Initialized
INFO - 2025-05-12 16:26:02 --> Language Class Initialized
INFO - 2025-05-12 16:26:02 --> Loader Class Initialized
INFO - 2025-05-12 16:26:02 --> Helper loaded: url_helper
INFO - 2025-05-12 16:26:02 --> Helper loaded: form_helper
INFO - 2025-05-12 16:26:02 --> Database Driver Class Initialized
DEBUG - 2025-05-12 16:26:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 16:26:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 16:26:02 --> Controller Class Initialized
INFO - 2025-05-12 16:26:02 --> Model "User_model" initialized
INFO - 2025-05-12 16:26:02 --> Model "Workout_model" initialized
INFO - 2025-05-12 16:26:02 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 16:26:02 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 16:26:02 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-12 16:26:02 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 16:26:02 --> Final output sent to browser
DEBUG - 2025-05-12 16:26:02 --> Total execution time: 0.0951
INFO - 2025-05-12 16:26:03 --> Config Class Initialized
INFO - 2025-05-12 16:26:03 --> Hooks Class Initialized
DEBUG - 2025-05-12 16:26:03 --> UTF-8 Support Enabled
INFO - 2025-05-12 16:26:03 --> Utf8 Class Initialized
INFO - 2025-05-12 16:26:03 --> URI Class Initialized
INFO - 2025-05-12 16:26:03 --> Router Class Initialized
INFO - 2025-05-12 16:26:03 --> Output Class Initialized
INFO - 2025-05-12 16:26:03 --> Security Class Initialized
DEBUG - 2025-05-12 16:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 16:26:03 --> Input Class Initialized
INFO - 2025-05-12 16:26:03 --> Language Class Initialized
INFO - 2025-05-12 16:26:03 --> Loader Class Initialized
INFO - 2025-05-12 16:26:03 --> Helper loaded: url_helper
INFO - 2025-05-12 16:26:03 --> Helper loaded: form_helper
INFO - 2025-05-12 16:26:03 --> Database Driver Class Initialized
DEBUG - 2025-05-12 16:26:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 16:26:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 16:26:03 --> Controller Class Initialized
INFO - 2025-05-12 16:26:03 --> Model "Workout_model" initialized
INFO - 2025-05-12 16:26:03 --> Model "User_model" initialized
INFO - 2025-05-12 16:26:03 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 16:26:03 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 16:26:03 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-12 16:26:03 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 16:26:03 --> Final output sent to browser
DEBUG - 2025-05-12 16:26:03 --> Total execution time: 0.0791
INFO - 2025-05-12 16:28:42 --> Config Class Initialized
INFO - 2025-05-12 16:28:42 --> Hooks Class Initialized
DEBUG - 2025-05-12 16:28:42 --> UTF-8 Support Enabled
INFO - 2025-05-12 16:28:42 --> Utf8 Class Initialized
INFO - 2025-05-12 16:28:42 --> URI Class Initialized
INFO - 2025-05-12 16:28:42 --> Router Class Initialized
INFO - 2025-05-12 16:28:42 --> Output Class Initialized
INFO - 2025-05-12 16:28:42 --> Security Class Initialized
DEBUG - 2025-05-12 16:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 16:28:42 --> Input Class Initialized
INFO - 2025-05-12 16:28:42 --> Language Class Initialized
INFO - 2025-05-12 16:28:42 --> Loader Class Initialized
INFO - 2025-05-12 16:28:42 --> Helper loaded: url_helper
INFO - 2025-05-12 16:28:42 --> Helper loaded: form_helper
INFO - 2025-05-12 16:28:42 --> Database Driver Class Initialized
DEBUG - 2025-05-12 16:28:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 16:28:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 16:28:42 --> Controller Class Initialized
INFO - 2025-05-12 16:28:42 --> Model "Community_model" initialized
INFO - 2025-05-12 16:28:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\community/index.php
INFO - 2025-05-12 16:28:42 --> Final output sent to browser
DEBUG - 2025-05-12 16:28:42 --> Total execution time: 0.3161
INFO - 2025-05-12 16:28:50 --> Config Class Initialized
INFO - 2025-05-12 16:28:50 --> Hooks Class Initialized
DEBUG - 2025-05-12 16:28:50 --> UTF-8 Support Enabled
INFO - 2025-05-12 16:28:50 --> Utf8 Class Initialized
INFO - 2025-05-12 16:28:50 --> URI Class Initialized
INFO - 2025-05-12 16:28:50 --> Router Class Initialized
INFO - 2025-05-12 16:28:50 --> Output Class Initialized
INFO - 2025-05-12 16:28:50 --> Security Class Initialized
DEBUG - 2025-05-12 16:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 16:28:50 --> Input Class Initialized
INFO - 2025-05-12 16:28:50 --> Language Class Initialized
INFO - 2025-05-12 16:28:50 --> Loader Class Initialized
INFO - 2025-05-12 16:28:50 --> Helper loaded: url_helper
INFO - 2025-05-12 16:28:50 --> Helper loaded: form_helper
INFO - 2025-05-12 16:28:50 --> Database Driver Class Initialized
DEBUG - 2025-05-12 16:28:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 16:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 16:28:50 --> Controller Class Initialized
INFO - 2025-05-12 16:28:50 --> Model "Community_model" initialized
INFO - 2025-05-12 16:28:50 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\community/explore.php
INFO - 2025-05-12 16:28:50 --> Final output sent to browser
DEBUG - 2025-05-12 16:28:50 --> Total execution time: 0.0785
INFO - 2025-05-12 16:29:00 --> Config Class Initialized
INFO - 2025-05-12 16:29:00 --> Hooks Class Initialized
DEBUG - 2025-05-12 16:29:00 --> UTF-8 Support Enabled
INFO - 2025-05-12 16:29:00 --> Utf8 Class Initialized
INFO - 2025-05-12 16:29:00 --> URI Class Initialized
INFO - 2025-05-12 16:29:00 --> Router Class Initialized
INFO - 2025-05-12 16:29:00 --> Output Class Initialized
INFO - 2025-05-12 16:29:00 --> Security Class Initialized
DEBUG - 2025-05-12 16:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 16:29:00 --> Input Class Initialized
INFO - 2025-05-12 16:29:00 --> Language Class Initialized
INFO - 2025-05-12 16:29:00 --> Loader Class Initialized
INFO - 2025-05-12 16:29:00 --> Helper loaded: url_helper
INFO - 2025-05-12 16:29:00 --> Helper loaded: form_helper
INFO - 2025-05-12 16:29:00 --> Database Driver Class Initialized
DEBUG - 2025-05-12 16:29:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 16:29:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 16:29:00 --> Controller Class Initialized
INFO - 2025-05-12 16:29:00 --> Model "Community_model" initialized
INFO - 2025-05-12 16:29:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\community/index.php
INFO - 2025-05-12 16:29:00 --> Final output sent to browser
DEBUG - 2025-05-12 16:29:00 --> Total execution time: 0.0846
INFO - 2025-05-12 16:29:02 --> Config Class Initialized
INFO - 2025-05-12 16:29:02 --> Hooks Class Initialized
DEBUG - 2025-05-12 16:29:02 --> UTF-8 Support Enabled
INFO - 2025-05-12 16:29:02 --> Utf8 Class Initialized
INFO - 2025-05-12 16:29:02 --> URI Class Initialized
INFO - 2025-05-12 16:29:02 --> Router Class Initialized
INFO - 2025-05-12 16:29:02 --> Output Class Initialized
INFO - 2025-05-12 16:29:02 --> Security Class Initialized
DEBUG - 2025-05-12 16:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 16:29:02 --> Input Class Initialized
INFO - 2025-05-12 16:29:02 --> Language Class Initialized
INFO - 2025-05-12 16:29:02 --> Loader Class Initialized
INFO - 2025-05-12 16:29:02 --> Helper loaded: url_helper
INFO - 2025-05-12 16:29:02 --> Helper loaded: form_helper
INFO - 2025-05-12 16:29:02 --> Database Driver Class Initialized
DEBUG - 2025-05-12 16:29:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 16:29:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 16:29:02 --> Controller Class Initialized
INFO - 2025-05-12 16:29:02 --> Model "Community_model" initialized
INFO - 2025-05-12 16:29:02 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\community/discussion.php
INFO - 2025-05-12 16:29:02 --> Final output sent to browser
DEBUG - 2025-05-12 16:29:02 --> Total execution time: 0.1125
INFO - 2025-05-12 16:29:10 --> Config Class Initialized
INFO - 2025-05-12 16:29:10 --> Hooks Class Initialized
DEBUG - 2025-05-12 16:29:10 --> UTF-8 Support Enabled
INFO - 2025-05-12 16:29:10 --> Utf8 Class Initialized
INFO - 2025-05-12 16:29:10 --> URI Class Initialized
INFO - 2025-05-12 16:29:10 --> Router Class Initialized
INFO - 2025-05-12 16:29:10 --> Output Class Initialized
INFO - 2025-05-12 16:29:10 --> Security Class Initialized
DEBUG - 2025-05-12 16:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 16:29:10 --> Input Class Initialized
INFO - 2025-05-12 16:29:10 --> Language Class Initialized
INFO - 2025-05-12 16:29:10 --> Loader Class Initialized
INFO - 2025-05-12 16:29:10 --> Helper loaded: url_helper
INFO - 2025-05-12 16:29:10 --> Helper loaded: form_helper
INFO - 2025-05-12 16:29:10 --> Database Driver Class Initialized
DEBUG - 2025-05-12 16:29:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 16:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 16:29:10 --> Controller Class Initialized
INFO - 2025-05-12 16:29:10 --> Model "Community_model" initialized
INFO - 2025-05-12 16:29:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\community/index.php
INFO - 2025-05-12 16:29:10 --> Final output sent to browser
DEBUG - 2025-05-12 16:29:10 --> Total execution time: 0.1117
INFO - 2025-05-12 16:49:10 --> Config Class Initialized
INFO - 2025-05-12 16:49:10 --> Hooks Class Initialized
DEBUG - 2025-05-12 16:49:10 --> UTF-8 Support Enabled
INFO - 2025-05-12 16:49:10 --> Utf8 Class Initialized
INFO - 2025-05-12 16:49:10 --> URI Class Initialized
INFO - 2025-05-12 16:49:10 --> Router Class Initialized
INFO - 2025-05-12 16:49:10 --> Output Class Initialized
INFO - 2025-05-12 16:49:10 --> Security Class Initialized
DEBUG - 2025-05-12 16:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 16:49:10 --> Input Class Initialized
INFO - 2025-05-12 16:49:10 --> Language Class Initialized
INFO - 2025-05-12 16:49:10 --> Loader Class Initialized
INFO - 2025-05-12 16:49:10 --> Helper loaded: url_helper
INFO - 2025-05-12 16:49:10 --> Helper loaded: form_helper
INFO - 2025-05-12 16:49:10 --> Database Driver Class Initialized
DEBUG - 2025-05-12 16:49:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 16:49:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 16:49:10 --> Controller Class Initialized
INFO - 2025-05-12 16:49:10 --> Model "Community_model" initialized
INFO - 2025-05-12 16:49:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\community/discussion.php
INFO - 2025-05-12 16:49:10 --> Final output sent to browser
DEBUG - 2025-05-12 16:49:10 --> Total execution time: 0.0994
INFO - 2025-05-12 16:49:12 --> Config Class Initialized
INFO - 2025-05-12 16:49:12 --> Hooks Class Initialized
DEBUG - 2025-05-12 16:49:12 --> UTF-8 Support Enabled
INFO - 2025-05-12 16:49:12 --> Utf8 Class Initialized
INFO - 2025-05-12 16:49:12 --> URI Class Initialized
INFO - 2025-05-12 16:49:12 --> Router Class Initialized
INFO - 2025-05-12 16:49:12 --> Output Class Initialized
INFO - 2025-05-12 16:49:12 --> Security Class Initialized
DEBUG - 2025-05-12 16:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 16:49:12 --> Input Class Initialized
INFO - 2025-05-12 16:49:12 --> Language Class Initialized
INFO - 2025-05-12 16:49:12 --> Loader Class Initialized
INFO - 2025-05-12 16:49:12 --> Helper loaded: url_helper
INFO - 2025-05-12 16:49:12 --> Helper loaded: form_helper
INFO - 2025-05-12 16:49:12 --> Database Driver Class Initialized
DEBUG - 2025-05-12 16:49:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 16:49:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 16:49:12 --> Controller Class Initialized
INFO - 2025-05-12 16:49:12 --> Model "Community_model" initialized
INFO - 2025-05-12 16:49:12 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\community/index.php
INFO - 2025-05-12 16:49:12 --> Final output sent to browser
DEBUG - 2025-05-12 16:49:12 --> Total execution time: 0.0862
INFO - 2025-05-12 16:49:15 --> Config Class Initialized
INFO - 2025-05-12 16:49:15 --> Hooks Class Initialized
DEBUG - 2025-05-12 16:49:15 --> UTF-8 Support Enabled
INFO - 2025-05-12 16:49:15 --> Utf8 Class Initialized
INFO - 2025-05-12 16:49:15 --> URI Class Initialized
INFO - 2025-05-12 16:49:15 --> Router Class Initialized
INFO - 2025-05-12 16:49:15 --> Output Class Initialized
INFO - 2025-05-12 16:49:15 --> Security Class Initialized
DEBUG - 2025-05-12 16:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 16:49:15 --> Input Class Initialized
INFO - 2025-05-12 16:49:15 --> Language Class Initialized
INFO - 2025-05-12 16:49:15 --> Loader Class Initialized
INFO - 2025-05-12 16:49:15 --> Helper loaded: url_helper
INFO - 2025-05-12 16:49:15 --> Helper loaded: form_helper
INFO - 2025-05-12 16:49:15 --> Database Driver Class Initialized
DEBUG - 2025-05-12 16:49:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 16:49:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 16:49:15 --> Controller Class Initialized
INFO - 2025-05-12 16:49:15 --> Model "Community_model" initialized
INFO - 2025-05-12 16:49:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\community/explore.php
INFO - 2025-05-12 16:49:15 --> Final output sent to browser
DEBUG - 2025-05-12 16:49:15 --> Total execution time: 0.0889
INFO - 2025-05-12 16:49:25 --> Config Class Initialized
INFO - 2025-05-12 16:49:25 --> Hooks Class Initialized
DEBUG - 2025-05-12 16:49:25 --> UTF-8 Support Enabled
INFO - 2025-05-12 16:49:25 --> Utf8 Class Initialized
INFO - 2025-05-12 16:49:25 --> URI Class Initialized
INFO - 2025-05-12 16:49:25 --> Router Class Initialized
INFO - 2025-05-12 16:49:25 --> Output Class Initialized
INFO - 2025-05-12 16:49:25 --> Security Class Initialized
DEBUG - 2025-05-12 16:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 16:49:25 --> Input Class Initialized
INFO - 2025-05-12 16:49:25 --> Language Class Initialized
INFO - 2025-05-12 16:49:25 --> Loader Class Initialized
INFO - 2025-05-12 16:49:25 --> Helper loaded: url_helper
INFO - 2025-05-12 16:49:25 --> Helper loaded: form_helper
INFO - 2025-05-12 16:49:25 --> Database Driver Class Initialized
DEBUG - 2025-05-12 16:49:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 16:49:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 16:49:25 --> Controller Class Initialized
INFO - 2025-05-12 16:49:25 --> Model "Community_model" initialized
INFO - 2025-05-12 16:49:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\community/index.php
INFO - 2025-05-12 16:49:25 --> Final output sent to browser
DEBUG - 2025-05-12 16:49:25 --> Total execution time: 0.0804
INFO - 2025-05-12 16:54:33 --> Config Class Initialized
INFO - 2025-05-12 16:54:33 --> Hooks Class Initialized
DEBUG - 2025-05-12 16:54:33 --> UTF-8 Support Enabled
INFO - 2025-05-12 16:54:33 --> Utf8 Class Initialized
INFO - 2025-05-12 16:54:33 --> URI Class Initialized
INFO - 2025-05-12 16:54:33 --> Router Class Initialized
INFO - 2025-05-12 16:54:33 --> Output Class Initialized
INFO - 2025-05-12 16:54:33 --> Security Class Initialized
DEBUG - 2025-05-12 16:54:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 16:54:33 --> Input Class Initialized
INFO - 2025-05-12 16:54:33 --> Language Class Initialized
INFO - 2025-05-12 16:54:33 --> Loader Class Initialized
INFO - 2025-05-12 16:54:33 --> Helper loaded: url_helper
INFO - 2025-05-12 16:54:33 --> Helper loaded: form_helper
INFO - 2025-05-12 16:54:33 --> Database Driver Class Initialized
DEBUG - 2025-05-12 16:54:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 16:54:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 16:54:33 --> Controller Class Initialized
INFO - 2025-05-12 16:54:33 --> Model "Community_model" initialized
INFO - 2025-05-12 16:54:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\community/discussion.php
INFO - 2025-05-12 16:54:33 --> Final output sent to browser
DEBUG - 2025-05-12 16:54:33 --> Total execution time: 0.0873
INFO - 2025-05-12 16:54:39 --> Config Class Initialized
INFO - 2025-05-12 16:54:39 --> Hooks Class Initialized
DEBUG - 2025-05-12 16:54:39 --> UTF-8 Support Enabled
INFO - 2025-05-12 16:54:39 --> Utf8 Class Initialized
INFO - 2025-05-12 16:54:39 --> URI Class Initialized
INFO - 2025-05-12 16:54:39 --> Router Class Initialized
INFO - 2025-05-12 16:54:39 --> Output Class Initialized
INFO - 2025-05-12 16:54:39 --> Security Class Initialized
DEBUG - 2025-05-12 16:54:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 16:54:39 --> Input Class Initialized
INFO - 2025-05-12 16:54:39 --> Language Class Initialized
INFO - 2025-05-12 16:54:39 --> Loader Class Initialized
INFO - 2025-05-12 16:54:39 --> Helper loaded: url_helper
INFO - 2025-05-12 16:54:39 --> Helper loaded: form_helper
INFO - 2025-05-12 16:54:39 --> Database Driver Class Initialized
DEBUG - 2025-05-12 16:54:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 16:54:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 16:54:39 --> Controller Class Initialized
INFO - 2025-05-12 16:54:39 --> Model "Community_model" initialized
INFO - 2025-05-12 16:54:39 --> Config Class Initialized
INFO - 2025-05-12 16:54:39 --> Hooks Class Initialized
DEBUG - 2025-05-12 16:54:39 --> UTF-8 Support Enabled
INFO - 2025-05-12 16:54:39 --> Utf8 Class Initialized
INFO - 2025-05-12 16:54:39 --> URI Class Initialized
INFO - 2025-05-12 16:54:39 --> Router Class Initialized
INFO - 2025-05-12 16:54:39 --> Output Class Initialized
INFO - 2025-05-12 16:54:39 --> Security Class Initialized
DEBUG - 2025-05-12 16:54:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 16:54:39 --> Input Class Initialized
INFO - 2025-05-12 16:54:39 --> Language Class Initialized
INFO - 2025-05-12 16:54:39 --> Loader Class Initialized
INFO - 2025-05-12 16:54:39 --> Helper loaded: url_helper
INFO - 2025-05-12 16:54:39 --> Helper loaded: form_helper
INFO - 2025-05-12 16:54:39 --> Database Driver Class Initialized
DEBUG - 2025-05-12 16:54:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 16:54:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 16:54:39 --> Controller Class Initialized
INFO - 2025-05-12 16:54:39 --> Model "Community_model" initialized
INFO - 2025-05-12 16:54:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\community/discussion.php
INFO - 2025-05-12 16:54:39 --> Final output sent to browser
DEBUG - 2025-05-12 16:54:39 --> Total execution time: 0.0801
INFO - 2025-05-12 16:54:43 --> Config Class Initialized
INFO - 2025-05-12 16:54:43 --> Hooks Class Initialized
DEBUG - 2025-05-12 16:54:43 --> UTF-8 Support Enabled
INFO - 2025-05-12 16:54:43 --> Utf8 Class Initialized
INFO - 2025-05-12 16:54:43 --> URI Class Initialized
INFO - 2025-05-12 16:54:43 --> Router Class Initialized
INFO - 2025-05-12 16:54:43 --> Output Class Initialized
INFO - 2025-05-12 16:54:43 --> Security Class Initialized
DEBUG - 2025-05-12 16:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 16:54:43 --> Input Class Initialized
INFO - 2025-05-12 16:54:43 --> Language Class Initialized
INFO - 2025-05-12 16:54:43 --> Loader Class Initialized
INFO - 2025-05-12 16:54:43 --> Helper loaded: url_helper
INFO - 2025-05-12 16:54:43 --> Helper loaded: form_helper
INFO - 2025-05-12 16:54:43 --> Database Driver Class Initialized
DEBUG - 2025-05-12 16:54:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 16:54:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 16:54:43 --> Controller Class Initialized
INFO - 2025-05-12 16:54:43 --> Model "Community_model" initialized
INFO - 2025-05-12 16:54:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\community/index.php
INFO - 2025-05-12 16:54:43 --> Final output sent to browser
DEBUG - 2025-05-12 16:54:43 --> Total execution time: 0.0888
INFO - 2025-05-12 16:54:45 --> Config Class Initialized
INFO - 2025-05-12 16:54:45 --> Hooks Class Initialized
DEBUG - 2025-05-12 16:54:45 --> UTF-8 Support Enabled
INFO - 2025-05-12 16:54:45 --> Utf8 Class Initialized
INFO - 2025-05-12 16:54:45 --> URI Class Initialized
INFO - 2025-05-12 16:54:45 --> Router Class Initialized
INFO - 2025-05-12 16:54:45 --> Output Class Initialized
INFO - 2025-05-12 16:54:45 --> Security Class Initialized
DEBUG - 2025-05-12 16:54:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 16:54:45 --> Input Class Initialized
INFO - 2025-05-12 16:54:45 --> Language Class Initialized
INFO - 2025-05-12 16:54:45 --> Loader Class Initialized
INFO - 2025-05-12 16:54:45 --> Helper loaded: url_helper
INFO - 2025-05-12 16:54:45 --> Helper loaded: form_helper
INFO - 2025-05-12 16:54:45 --> Database Driver Class Initialized
DEBUG - 2025-05-12 16:54:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 16:54:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 16:54:45 --> Controller Class Initialized
INFO - 2025-05-12 16:54:45 --> Model "User_model" initialized
INFO - 2025-05-12 16:54:45 --> Model "Workout_model" initialized
INFO - 2025-05-12 16:54:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 16:54:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 16:54:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-12 16:54:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 16:54:45 --> Final output sent to browser
DEBUG - 2025-05-12 16:54:45 --> Total execution time: 0.1200
INFO - 2025-05-12 16:54:49 --> Config Class Initialized
INFO - 2025-05-12 16:54:49 --> Hooks Class Initialized
DEBUG - 2025-05-12 16:54:49 --> UTF-8 Support Enabled
INFO - 2025-05-12 16:54:49 --> Utf8 Class Initialized
INFO - 2025-05-12 16:54:49 --> URI Class Initialized
INFO - 2025-05-12 16:54:49 --> Router Class Initialized
INFO - 2025-05-12 16:54:49 --> Output Class Initialized
INFO - 2025-05-12 16:54:49 --> Security Class Initialized
DEBUG - 2025-05-12 16:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 16:54:49 --> Input Class Initialized
INFO - 2025-05-12 16:54:49 --> Language Class Initialized
INFO - 2025-05-12 16:54:49 --> Loader Class Initialized
INFO - 2025-05-12 16:54:49 --> Helper loaded: url_helper
INFO - 2025-05-12 16:54:49 --> Helper loaded: form_helper
INFO - 2025-05-12 16:54:49 --> Database Driver Class Initialized
DEBUG - 2025-05-12 16:54:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 16:54:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 16:54:49 --> Controller Class Initialized
INFO - 2025-05-12 16:54:49 --> Model "User_model" initialized
INFO - 2025-05-12 16:54:49 --> Config Class Initialized
INFO - 2025-05-12 16:54:49 --> Hooks Class Initialized
DEBUG - 2025-05-12 16:54:49 --> UTF-8 Support Enabled
INFO - 2025-05-12 16:54:49 --> Utf8 Class Initialized
INFO - 2025-05-12 16:54:49 --> URI Class Initialized
INFO - 2025-05-12 16:54:49 --> Router Class Initialized
INFO - 2025-05-12 16:54:49 --> Output Class Initialized
INFO - 2025-05-12 16:54:49 --> Security Class Initialized
DEBUG - 2025-05-12 16:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 16:54:49 --> Input Class Initialized
INFO - 2025-05-12 16:54:49 --> Language Class Initialized
INFO - 2025-05-12 16:54:49 --> Loader Class Initialized
INFO - 2025-05-12 16:54:49 --> Helper loaded: url_helper
INFO - 2025-05-12 16:54:49 --> Helper loaded: form_helper
INFO - 2025-05-12 16:54:49 --> Database Driver Class Initialized
DEBUG - 2025-05-12 16:54:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 16:54:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 16:54:49 --> Controller Class Initialized
INFO - 2025-05-12 16:54:49 --> Model "User_model" initialized
INFO - 2025-05-12 16:54:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-12 16:54:49 --> Final output sent to browser
DEBUG - 2025-05-12 16:54:49 --> Total execution time: 0.0848
INFO - 2025-05-12 16:54:58 --> Config Class Initialized
INFO - 2025-05-12 16:54:58 --> Hooks Class Initialized
DEBUG - 2025-05-12 16:54:58 --> UTF-8 Support Enabled
INFO - 2025-05-12 16:54:58 --> Utf8 Class Initialized
INFO - 2025-05-12 16:54:58 --> URI Class Initialized
INFO - 2025-05-12 16:54:58 --> Router Class Initialized
INFO - 2025-05-12 16:54:58 --> Output Class Initialized
INFO - 2025-05-12 16:54:58 --> Security Class Initialized
DEBUG - 2025-05-12 16:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 16:54:58 --> Input Class Initialized
INFO - 2025-05-12 16:54:58 --> Language Class Initialized
INFO - 2025-05-12 16:54:58 --> Loader Class Initialized
INFO - 2025-05-12 16:54:58 --> Helper loaded: url_helper
INFO - 2025-05-12 16:54:58 --> Helper loaded: form_helper
INFO - 2025-05-12 16:54:58 --> Database Driver Class Initialized
DEBUG - 2025-05-12 16:54:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 16:54:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 16:54:58 --> Controller Class Initialized
INFO - 2025-05-12 16:54:58 --> Model "User_model" initialized
INFO - 2025-05-12 16:54:58 --> Config Class Initialized
INFO - 2025-05-12 16:54:58 --> Hooks Class Initialized
DEBUG - 2025-05-12 16:54:58 --> UTF-8 Support Enabled
INFO - 2025-05-12 16:54:58 --> Utf8 Class Initialized
INFO - 2025-05-12 16:54:58 --> URI Class Initialized
INFO - 2025-05-12 16:54:58 --> Router Class Initialized
INFO - 2025-05-12 16:54:58 --> Output Class Initialized
INFO - 2025-05-12 16:54:58 --> Security Class Initialized
DEBUG - 2025-05-12 16:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 16:54:58 --> Input Class Initialized
INFO - 2025-05-12 16:54:58 --> Language Class Initialized
INFO - 2025-05-12 16:54:58 --> Loader Class Initialized
INFO - 2025-05-12 16:54:58 --> Helper loaded: url_helper
INFO - 2025-05-12 16:54:58 --> Helper loaded: form_helper
INFO - 2025-05-12 16:54:58 --> Database Driver Class Initialized
DEBUG - 2025-05-12 16:54:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 16:54:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 16:54:58 --> Controller Class Initialized
INFO - 2025-05-12 16:54:58 --> Model "User_model" initialized
INFO - 2025-05-12 16:54:58 --> Model "Workout_model" initialized
INFO - 2025-05-12 16:54:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 16:54:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 16:54:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-12 16:54:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 16:54:58 --> Final output sent to browser
DEBUG - 2025-05-12 16:54:58 --> Total execution time: 0.0829
INFO - 2025-05-12 16:55:04 --> Config Class Initialized
INFO - 2025-05-12 16:55:04 --> Hooks Class Initialized
DEBUG - 2025-05-12 16:55:04 --> UTF-8 Support Enabled
INFO - 2025-05-12 16:55:04 --> Utf8 Class Initialized
INFO - 2025-05-12 16:55:04 --> URI Class Initialized
INFO - 2025-05-12 16:55:04 --> Router Class Initialized
INFO - 2025-05-12 16:55:04 --> Output Class Initialized
INFO - 2025-05-12 16:55:04 --> Security Class Initialized
DEBUG - 2025-05-12 16:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 16:55:04 --> Input Class Initialized
INFO - 2025-05-12 16:55:04 --> Language Class Initialized
INFO - 2025-05-12 16:55:04 --> Loader Class Initialized
INFO - 2025-05-12 16:55:04 --> Helper loaded: url_helper
INFO - 2025-05-12 16:55:04 --> Helper loaded: form_helper
INFO - 2025-05-12 16:55:04 --> Database Driver Class Initialized
DEBUG - 2025-05-12 16:55:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 16:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 16:55:04 --> Controller Class Initialized
INFO - 2025-05-12 16:55:04 --> Model "Community_model" initialized
INFO - 2025-05-12 16:55:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\community/index.php
INFO - 2025-05-12 16:55:05 --> Final output sent to browser
DEBUG - 2025-05-12 16:55:05 --> Total execution time: 0.0950
INFO - 2025-05-12 16:55:07 --> Config Class Initialized
INFO - 2025-05-12 16:55:07 --> Hooks Class Initialized
DEBUG - 2025-05-12 16:55:07 --> UTF-8 Support Enabled
INFO - 2025-05-12 16:55:07 --> Utf8 Class Initialized
INFO - 2025-05-12 16:55:07 --> URI Class Initialized
INFO - 2025-05-12 16:55:07 --> Router Class Initialized
INFO - 2025-05-12 16:55:07 --> Output Class Initialized
INFO - 2025-05-12 16:55:07 --> Security Class Initialized
DEBUG - 2025-05-12 16:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 16:55:07 --> Input Class Initialized
INFO - 2025-05-12 16:55:07 --> Language Class Initialized
INFO - 2025-05-12 16:55:07 --> Loader Class Initialized
INFO - 2025-05-12 16:55:07 --> Helper loaded: url_helper
INFO - 2025-05-12 16:55:07 --> Helper loaded: form_helper
INFO - 2025-05-12 16:55:07 --> Database Driver Class Initialized
DEBUG - 2025-05-12 16:55:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 16:55:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 16:55:07 --> Controller Class Initialized
INFO - 2025-05-12 16:55:07 --> Model "Community_model" initialized
INFO - 2025-05-12 16:55:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\community/explore.php
INFO - 2025-05-12 16:55:07 --> Final output sent to browser
DEBUG - 2025-05-12 16:55:07 --> Total execution time: 0.0938
INFO - 2025-05-12 16:55:12 --> Config Class Initialized
INFO - 2025-05-12 16:55:12 --> Hooks Class Initialized
DEBUG - 2025-05-12 16:55:12 --> UTF-8 Support Enabled
INFO - 2025-05-12 16:55:12 --> Utf8 Class Initialized
INFO - 2025-05-12 16:55:12 --> URI Class Initialized
INFO - 2025-05-12 16:55:12 --> Router Class Initialized
INFO - 2025-05-12 16:55:12 --> Output Class Initialized
INFO - 2025-05-12 16:55:12 --> Security Class Initialized
DEBUG - 2025-05-12 16:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 16:55:12 --> Input Class Initialized
INFO - 2025-05-12 16:55:12 --> Language Class Initialized
INFO - 2025-05-12 16:55:12 --> Loader Class Initialized
INFO - 2025-05-12 16:55:12 --> Helper loaded: url_helper
INFO - 2025-05-12 16:55:12 --> Helper loaded: form_helper
INFO - 2025-05-12 16:55:12 --> Database Driver Class Initialized
DEBUG - 2025-05-12 16:55:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 16:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 16:55:12 --> Controller Class Initialized
INFO - 2025-05-12 16:55:12 --> Model "Community_model" initialized
INFO - 2025-05-12 16:55:12 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\community/index.php
INFO - 2025-05-12 16:55:12 --> Final output sent to browser
DEBUG - 2025-05-12 16:55:12 --> Total execution time: 0.0994
INFO - 2025-05-12 16:56:54 --> Config Class Initialized
INFO - 2025-05-12 16:56:54 --> Hooks Class Initialized
DEBUG - 2025-05-12 16:56:54 --> UTF-8 Support Enabled
INFO - 2025-05-12 16:56:54 --> Utf8 Class Initialized
INFO - 2025-05-12 16:56:54 --> URI Class Initialized
INFO - 2025-05-12 16:56:54 --> Router Class Initialized
INFO - 2025-05-12 16:56:54 --> Output Class Initialized
INFO - 2025-05-12 16:56:54 --> Security Class Initialized
DEBUG - 2025-05-12 16:56:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 16:56:54 --> Input Class Initialized
INFO - 2025-05-12 16:56:54 --> Language Class Initialized
INFO - 2025-05-12 16:56:54 --> Loader Class Initialized
INFO - 2025-05-12 16:56:54 --> Helper loaded: url_helper
INFO - 2025-05-12 16:56:54 --> Helper loaded: form_helper
INFO - 2025-05-12 16:56:54 --> Database Driver Class Initialized
DEBUG - 2025-05-12 16:56:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 16:56:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 16:56:54 --> Controller Class Initialized
INFO - 2025-05-12 16:56:54 --> Model "Community_model" initialized
INFO - 2025-05-12 16:56:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\community/explore.php
INFO - 2025-05-12 16:56:54 --> Final output sent to browser
DEBUG - 2025-05-12 16:56:54 --> Total execution time: 0.0886
INFO - 2025-05-12 16:57:38 --> Config Class Initialized
INFO - 2025-05-12 16:57:38 --> Hooks Class Initialized
DEBUG - 2025-05-12 16:57:38 --> UTF-8 Support Enabled
INFO - 2025-05-12 16:57:38 --> Utf8 Class Initialized
INFO - 2025-05-12 16:57:38 --> URI Class Initialized
INFO - 2025-05-12 16:57:38 --> Router Class Initialized
INFO - 2025-05-12 16:57:38 --> Output Class Initialized
INFO - 2025-05-12 16:57:38 --> Security Class Initialized
DEBUG - 2025-05-12 16:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 16:57:38 --> Input Class Initialized
INFO - 2025-05-12 16:57:38 --> Language Class Initialized
INFO - 2025-05-12 16:57:38 --> Loader Class Initialized
INFO - 2025-05-12 16:57:38 --> Helper loaded: url_helper
INFO - 2025-05-12 16:57:38 --> Helper loaded: form_helper
INFO - 2025-05-12 16:57:38 --> Database Driver Class Initialized
DEBUG - 2025-05-12 16:57:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 16:57:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 16:57:38 --> Controller Class Initialized
INFO - 2025-05-12 16:57:38 --> Model "Community_model" initialized
INFO - 2025-05-12 16:57:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\community/explore.php
INFO - 2025-05-12 16:57:38 --> Final output sent to browser
DEBUG - 2025-05-12 16:57:38 --> Total execution time: 0.0819
INFO - 2025-05-12 16:57:40 --> Config Class Initialized
INFO - 2025-05-12 16:57:40 --> Hooks Class Initialized
DEBUG - 2025-05-12 16:57:40 --> UTF-8 Support Enabled
INFO - 2025-05-12 16:57:40 --> Utf8 Class Initialized
INFO - 2025-05-12 16:57:40 --> URI Class Initialized
INFO - 2025-05-12 16:57:40 --> Router Class Initialized
INFO - 2025-05-12 16:57:40 --> Output Class Initialized
INFO - 2025-05-12 16:57:40 --> Security Class Initialized
DEBUG - 2025-05-12 16:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 16:57:40 --> Input Class Initialized
INFO - 2025-05-12 16:57:40 --> Language Class Initialized
INFO - 2025-05-12 16:57:40 --> Loader Class Initialized
INFO - 2025-05-12 16:57:40 --> Helper loaded: url_helper
INFO - 2025-05-12 16:57:40 --> Helper loaded: form_helper
INFO - 2025-05-12 16:57:40 --> Database Driver Class Initialized
DEBUG - 2025-05-12 16:57:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 16:57:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 16:57:40 --> Controller Class Initialized
INFO - 2025-05-12 16:57:40 --> Model "Community_model" initialized
INFO - 2025-05-12 16:57:40 --> Config Class Initialized
INFO - 2025-05-12 16:57:40 --> Hooks Class Initialized
DEBUG - 2025-05-12 16:57:40 --> UTF-8 Support Enabled
INFO - 2025-05-12 16:57:40 --> Utf8 Class Initialized
INFO - 2025-05-12 16:57:40 --> URI Class Initialized
INFO - 2025-05-12 16:57:40 --> Router Class Initialized
INFO - 2025-05-12 16:57:40 --> Output Class Initialized
INFO - 2025-05-12 16:57:40 --> Security Class Initialized
DEBUG - 2025-05-12 16:57:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 16:57:40 --> Input Class Initialized
INFO - 2025-05-12 16:57:40 --> Language Class Initialized
INFO - 2025-05-12 16:57:40 --> Loader Class Initialized
INFO - 2025-05-12 16:57:40 --> Helper loaded: url_helper
INFO - 2025-05-12 16:57:40 --> Helper loaded: form_helper
INFO - 2025-05-12 16:57:40 --> Database Driver Class Initialized
DEBUG - 2025-05-12 16:57:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 16:57:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 16:57:40 --> Controller Class Initialized
INFO - 2025-05-12 16:57:40 --> Model "Community_model" initialized
INFO - 2025-05-12 16:57:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\community/index.php
INFO - 2025-05-12 16:57:40 --> Final output sent to browser
DEBUG - 2025-05-12 16:57:40 --> Total execution time: 0.0777
INFO - 2025-05-12 16:57:42 --> Config Class Initialized
INFO - 2025-05-12 16:57:42 --> Hooks Class Initialized
DEBUG - 2025-05-12 16:57:42 --> UTF-8 Support Enabled
INFO - 2025-05-12 16:57:42 --> Utf8 Class Initialized
INFO - 2025-05-12 16:57:42 --> URI Class Initialized
INFO - 2025-05-12 16:57:42 --> Router Class Initialized
INFO - 2025-05-12 16:57:42 --> Output Class Initialized
INFO - 2025-05-12 16:57:42 --> Security Class Initialized
DEBUG - 2025-05-12 16:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 16:57:42 --> Input Class Initialized
INFO - 2025-05-12 16:57:42 --> Language Class Initialized
INFO - 2025-05-12 16:57:42 --> Loader Class Initialized
INFO - 2025-05-12 16:57:42 --> Helper loaded: url_helper
INFO - 2025-05-12 16:57:42 --> Helper loaded: form_helper
INFO - 2025-05-12 16:57:42 --> Database Driver Class Initialized
DEBUG - 2025-05-12 16:57:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 16:57:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 16:57:42 --> Controller Class Initialized
INFO - 2025-05-12 16:57:42 --> Model "Community_model" initialized
INFO - 2025-05-12 16:57:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\community/discussion.php
INFO - 2025-05-12 16:57:42 --> Final output sent to browser
DEBUG - 2025-05-12 16:57:42 --> Total execution time: 0.0826
INFO - 2025-05-12 16:57:45 --> Config Class Initialized
INFO - 2025-05-12 16:57:45 --> Hooks Class Initialized
DEBUG - 2025-05-12 16:57:45 --> UTF-8 Support Enabled
INFO - 2025-05-12 16:57:45 --> Utf8 Class Initialized
INFO - 2025-05-12 16:57:45 --> URI Class Initialized
INFO - 2025-05-12 16:57:45 --> Router Class Initialized
INFO - 2025-05-12 16:57:45 --> Output Class Initialized
INFO - 2025-05-12 16:57:45 --> Security Class Initialized
DEBUG - 2025-05-12 16:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 16:57:45 --> Input Class Initialized
INFO - 2025-05-12 16:57:45 --> Language Class Initialized
INFO - 2025-05-12 16:57:45 --> Loader Class Initialized
INFO - 2025-05-12 16:57:45 --> Helper loaded: url_helper
INFO - 2025-05-12 16:57:45 --> Helper loaded: form_helper
INFO - 2025-05-12 16:57:45 --> Database Driver Class Initialized
DEBUG - 2025-05-12 16:57:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 16:57:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 16:57:45 --> Controller Class Initialized
INFO - 2025-05-12 16:57:45 --> Model "Community_model" initialized
INFO - 2025-05-12 16:57:45 --> Config Class Initialized
INFO - 2025-05-12 16:57:45 --> Hooks Class Initialized
DEBUG - 2025-05-12 16:57:45 --> UTF-8 Support Enabled
INFO - 2025-05-12 16:57:45 --> Utf8 Class Initialized
INFO - 2025-05-12 16:57:45 --> URI Class Initialized
INFO - 2025-05-12 16:57:45 --> Router Class Initialized
INFO - 2025-05-12 16:57:45 --> Output Class Initialized
INFO - 2025-05-12 16:57:45 --> Security Class Initialized
DEBUG - 2025-05-12 16:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 16:57:45 --> Input Class Initialized
INFO - 2025-05-12 16:57:45 --> Language Class Initialized
INFO - 2025-05-12 16:57:46 --> Loader Class Initialized
INFO - 2025-05-12 16:57:46 --> Helper loaded: url_helper
INFO - 2025-05-12 16:57:46 --> Helper loaded: form_helper
INFO - 2025-05-12 16:57:46 --> Database Driver Class Initialized
DEBUG - 2025-05-12 16:57:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 16:57:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 16:57:46 --> Controller Class Initialized
INFO - 2025-05-12 16:57:46 --> Model "Community_model" initialized
INFO - 2025-05-12 16:57:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\community/discussion.php
INFO - 2025-05-12 16:57:46 --> Final output sent to browser
DEBUG - 2025-05-12 16:57:46 --> Total execution time: 0.0719
INFO - 2025-05-12 16:57:48 --> Config Class Initialized
INFO - 2025-05-12 16:57:48 --> Hooks Class Initialized
DEBUG - 2025-05-12 16:57:48 --> UTF-8 Support Enabled
INFO - 2025-05-12 16:57:48 --> Utf8 Class Initialized
INFO - 2025-05-12 16:57:48 --> URI Class Initialized
INFO - 2025-05-12 16:57:48 --> Router Class Initialized
INFO - 2025-05-12 16:57:48 --> Output Class Initialized
INFO - 2025-05-12 16:57:48 --> Security Class Initialized
DEBUG - 2025-05-12 16:57:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 16:57:48 --> Input Class Initialized
INFO - 2025-05-12 16:57:48 --> Language Class Initialized
INFO - 2025-05-12 16:57:48 --> Loader Class Initialized
INFO - 2025-05-12 16:57:48 --> Helper loaded: url_helper
INFO - 2025-05-12 16:57:48 --> Helper loaded: form_helper
INFO - 2025-05-12 16:57:48 --> Database Driver Class Initialized
DEBUG - 2025-05-12 16:57:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 16:57:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 16:57:48 --> Controller Class Initialized
INFO - 2025-05-12 16:57:48 --> Model "Community_model" initialized
INFO - 2025-05-12 16:57:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\community/index.php
INFO - 2025-05-12 16:57:48 --> Final output sent to browser
DEBUG - 2025-05-12 16:57:48 --> Total execution time: 0.0818
INFO - 2025-05-12 16:57:50 --> Config Class Initialized
INFO - 2025-05-12 16:57:50 --> Hooks Class Initialized
DEBUG - 2025-05-12 16:57:50 --> UTF-8 Support Enabled
INFO - 2025-05-12 16:57:50 --> Utf8 Class Initialized
INFO - 2025-05-12 16:57:50 --> URI Class Initialized
INFO - 2025-05-12 16:57:50 --> Router Class Initialized
INFO - 2025-05-12 16:57:50 --> Output Class Initialized
INFO - 2025-05-12 16:57:50 --> Security Class Initialized
DEBUG - 2025-05-12 16:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 16:57:50 --> Input Class Initialized
INFO - 2025-05-12 16:57:50 --> Language Class Initialized
INFO - 2025-05-12 16:57:50 --> Loader Class Initialized
INFO - 2025-05-12 16:57:50 --> Helper loaded: url_helper
INFO - 2025-05-12 16:57:50 --> Helper loaded: form_helper
INFO - 2025-05-12 16:57:50 --> Database Driver Class Initialized
DEBUG - 2025-05-12 16:57:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 16:57:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 16:57:50 --> Controller Class Initialized
INFO - 2025-05-12 16:57:50 --> Model "Community_model" initialized
INFO - 2025-05-12 16:57:50 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\community/explore.php
INFO - 2025-05-12 16:57:50 --> Final output sent to browser
DEBUG - 2025-05-12 16:57:50 --> Total execution time: 0.0961
INFO - 2025-05-12 16:57:52 --> Config Class Initialized
INFO - 2025-05-12 16:57:52 --> Hooks Class Initialized
DEBUG - 2025-05-12 16:57:52 --> UTF-8 Support Enabled
INFO - 2025-05-12 16:57:52 --> Utf8 Class Initialized
INFO - 2025-05-12 16:57:52 --> URI Class Initialized
INFO - 2025-05-12 16:57:52 --> Router Class Initialized
INFO - 2025-05-12 16:57:52 --> Output Class Initialized
INFO - 2025-05-12 16:57:52 --> Security Class Initialized
DEBUG - 2025-05-12 16:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 16:57:52 --> Input Class Initialized
INFO - 2025-05-12 16:57:52 --> Language Class Initialized
INFO - 2025-05-12 16:57:52 --> Loader Class Initialized
INFO - 2025-05-12 16:57:52 --> Helper loaded: url_helper
INFO - 2025-05-12 16:57:52 --> Helper loaded: form_helper
INFO - 2025-05-12 16:57:52 --> Database Driver Class Initialized
DEBUG - 2025-05-12 16:57:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 16:57:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 16:57:52 --> Controller Class Initialized
INFO - 2025-05-12 16:57:52 --> Model "Community_model" initialized
INFO - 2025-05-12 16:57:52 --> Config Class Initialized
INFO - 2025-05-12 16:57:52 --> Hooks Class Initialized
DEBUG - 2025-05-12 16:57:52 --> UTF-8 Support Enabled
INFO - 2025-05-12 16:57:52 --> Utf8 Class Initialized
INFO - 2025-05-12 16:57:52 --> URI Class Initialized
INFO - 2025-05-12 16:57:52 --> Router Class Initialized
INFO - 2025-05-12 16:57:52 --> Output Class Initialized
INFO - 2025-05-12 16:57:52 --> Security Class Initialized
DEBUG - 2025-05-12 16:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 16:57:52 --> Input Class Initialized
INFO - 2025-05-12 16:57:52 --> Language Class Initialized
INFO - 2025-05-12 16:57:52 --> Loader Class Initialized
INFO - 2025-05-12 16:57:52 --> Helper loaded: url_helper
INFO - 2025-05-12 16:57:52 --> Helper loaded: form_helper
INFO - 2025-05-12 16:57:52 --> Database Driver Class Initialized
DEBUG - 2025-05-12 16:57:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 16:57:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 16:57:52 --> Controller Class Initialized
INFO - 2025-05-12 16:57:52 --> Model "Community_model" initialized
INFO - 2025-05-12 16:57:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\community/index.php
INFO - 2025-05-12 16:57:52 --> Final output sent to browser
DEBUG - 2025-05-12 16:57:52 --> Total execution time: 0.0739
INFO - 2025-05-12 16:57:57 --> Config Class Initialized
INFO - 2025-05-12 16:57:57 --> Hooks Class Initialized
DEBUG - 2025-05-12 16:57:57 --> UTF-8 Support Enabled
INFO - 2025-05-12 16:57:57 --> Utf8 Class Initialized
INFO - 2025-05-12 16:57:57 --> URI Class Initialized
INFO - 2025-05-12 16:57:57 --> Router Class Initialized
INFO - 2025-05-12 16:57:57 --> Output Class Initialized
INFO - 2025-05-12 16:57:57 --> Security Class Initialized
DEBUG - 2025-05-12 16:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-12 16:57:57 --> Input Class Initialized
INFO - 2025-05-12 16:57:57 --> Language Class Initialized
INFO - 2025-05-12 16:57:57 --> Loader Class Initialized
INFO - 2025-05-12 16:57:57 --> Helper loaded: url_helper
INFO - 2025-05-12 16:57:57 --> Helper loaded: form_helper
INFO - 2025-05-12 16:57:57 --> Database Driver Class Initialized
DEBUG - 2025-05-12 16:57:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-12 16:57:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-12 16:57:57 --> Controller Class Initialized
INFO - 2025-05-12 16:57:57 --> Model "User_model" initialized
INFO - 2025-05-12 16:57:57 --> Model "Workout_model" initialized
INFO - 2025-05-12 16:57:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-12 16:57:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-12 16:57:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-12 16:57:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-12 16:57:57 --> Final output sent to browser
DEBUG - 2025-05-12 16:57:57 --> Total execution time: 0.1139
