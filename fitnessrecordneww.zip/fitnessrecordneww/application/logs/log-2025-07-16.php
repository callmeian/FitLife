<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-07-16 10:23:21 --> Config Class Initialized
INFO - 2025-07-16 10:23:21 --> Hooks Class Initialized
DEBUG - 2025-07-16 10:23:21 --> UTF-8 Support Enabled
INFO - 2025-07-16 10:23:21 --> Utf8 Class Initialized
INFO - 2025-07-16 10:23:21 --> URI Class Initialized
DEBUG - 2025-07-16 10:23:21 --> No URI present. Default controller set.
INFO - 2025-07-16 10:23:21 --> Router Class Initialized
INFO - 2025-07-16 10:23:22 --> Output Class Initialized
INFO - 2025-07-16 10:23:22 --> Security Class Initialized
DEBUG - 2025-07-16 10:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-16 10:23:22 --> Input Class Initialized
INFO - 2025-07-16 10:23:22 --> Language Class Initialized
INFO - 2025-07-16 10:23:22 --> Loader Class Initialized
INFO - 2025-07-16 10:23:22 --> Helper loaded: url_helper
INFO - 2025-07-16 10:23:22 --> Helper loaded: form_helper
INFO - 2025-07-16 10:23:23 --> Database Driver Class Initialized
DEBUG - 2025-07-16 10:23:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-16 10:23:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-16 10:23:23 --> Controller Class Initialized
INFO - 2025-07-16 10:23:23 --> Model "User_model" initialized
INFO - 2025-07-16 10:23:23 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-07-16 10:23:23 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/home.php
INFO - 2025-07-16 10:23:23 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-07-16 10:23:23 --> Final output sent to browser
DEBUG - 2025-07-16 10:23:23 --> Total execution time: 2.9875
INFO - 2025-07-16 10:23:28 --> Config Class Initialized
INFO - 2025-07-16 10:23:28 --> Hooks Class Initialized
DEBUG - 2025-07-16 10:23:28 --> UTF-8 Support Enabled
INFO - 2025-07-16 10:23:28 --> Utf8 Class Initialized
INFO - 2025-07-16 10:23:28 --> URI Class Initialized
INFO - 2025-07-16 10:23:28 --> Router Class Initialized
INFO - 2025-07-16 10:23:28 --> Output Class Initialized
INFO - 2025-07-16 10:23:28 --> Security Class Initialized
DEBUG - 2025-07-16 10:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-16 10:23:28 --> Input Class Initialized
INFO - 2025-07-16 10:23:28 --> Language Class Initialized
INFO - 2025-07-16 10:23:28 --> Loader Class Initialized
INFO - 2025-07-16 10:23:28 --> Helper loaded: url_helper
INFO - 2025-07-16 10:23:28 --> Helper loaded: form_helper
INFO - 2025-07-16 10:23:28 --> Database Driver Class Initialized
DEBUG - 2025-07-16 10:23:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-16 10:23:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-16 10:23:28 --> Controller Class Initialized
INFO - 2025-07-16 10:23:28 --> Model "User_model" initialized
INFO - 2025-07-16 10:23:28 --> Form Validation Class Initialized
INFO - 2025-07-16 10:23:28 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\auth/login.php
INFO - 2025-07-16 10:23:28 --> Final output sent to browser
DEBUG - 2025-07-16 10:23:28 --> Total execution time: 0.4602
INFO - 2025-07-16 10:24:32 --> Config Class Initialized
INFO - 2025-07-16 10:24:32 --> Hooks Class Initialized
DEBUG - 2025-07-16 10:24:32 --> UTF-8 Support Enabled
INFO - 2025-07-16 10:24:32 --> Utf8 Class Initialized
INFO - 2025-07-16 10:24:32 --> URI Class Initialized
INFO - 2025-07-16 10:24:32 --> Router Class Initialized
INFO - 2025-07-16 10:24:32 --> Output Class Initialized
INFO - 2025-07-16 10:24:32 --> Security Class Initialized
DEBUG - 2025-07-16 10:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-16 10:24:32 --> Input Class Initialized
INFO - 2025-07-16 10:24:32 --> Language Class Initialized
INFO - 2025-07-16 10:24:32 --> Loader Class Initialized
INFO - 2025-07-16 10:24:32 --> Helper loaded: url_helper
INFO - 2025-07-16 10:24:32 --> Helper loaded: form_helper
INFO - 2025-07-16 10:24:32 --> Database Driver Class Initialized
DEBUG - 2025-07-16 10:24:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-16 10:24:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-16 10:24:32 --> Controller Class Initialized
INFO - 2025-07-16 10:24:32 --> Model "User_model" initialized
INFO - 2025-07-16 10:24:32 --> Form Validation Class Initialized
DEBUG - 2025-07-16 10:24:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-07-16 10:24:33 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\auth/register.php
INFO - 2025-07-16 10:24:33 --> Final output sent to browser
DEBUG - 2025-07-16 10:24:33 --> Total execution time: 0.2289
INFO - 2025-07-16 10:25:26 --> Config Class Initialized
INFO - 2025-07-16 10:25:26 --> Hooks Class Initialized
DEBUG - 2025-07-16 10:25:26 --> UTF-8 Support Enabled
INFO - 2025-07-16 10:25:26 --> Utf8 Class Initialized
INFO - 2025-07-16 10:25:26 --> URI Class Initialized
INFO - 2025-07-16 10:25:26 --> Router Class Initialized
INFO - 2025-07-16 10:25:26 --> Output Class Initialized
INFO - 2025-07-16 10:25:26 --> Security Class Initialized
DEBUG - 2025-07-16 10:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-16 10:25:26 --> Input Class Initialized
INFO - 2025-07-16 10:25:26 --> Language Class Initialized
INFO - 2025-07-16 10:25:26 --> Loader Class Initialized
INFO - 2025-07-16 10:25:26 --> Helper loaded: url_helper
INFO - 2025-07-16 10:25:26 --> Helper loaded: form_helper
INFO - 2025-07-16 10:25:26 --> Database Driver Class Initialized
DEBUG - 2025-07-16 10:25:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-16 10:25:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-16 10:25:26 --> Controller Class Initialized
INFO - 2025-07-16 10:25:26 --> Model "User_model" initialized
INFO - 2025-07-16 10:25:26 --> Form Validation Class Initialized
INFO - 2025-07-16 10:25:26 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\auth/login.php
INFO - 2025-07-16 10:25:26 --> Final output sent to browser
DEBUG - 2025-07-16 10:25:26 --> Total execution time: 0.1335
INFO - 2025-07-16 10:25:34 --> Config Class Initialized
INFO - 2025-07-16 10:25:34 --> Hooks Class Initialized
DEBUG - 2025-07-16 10:25:34 --> UTF-8 Support Enabled
INFO - 2025-07-16 10:25:34 --> Utf8 Class Initialized
INFO - 2025-07-16 10:25:34 --> URI Class Initialized
INFO - 2025-07-16 10:25:34 --> Router Class Initialized
INFO - 2025-07-16 10:25:34 --> Output Class Initialized
INFO - 2025-07-16 10:25:34 --> Security Class Initialized
DEBUG - 2025-07-16 10:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-16 10:25:34 --> Input Class Initialized
INFO - 2025-07-16 10:25:34 --> Language Class Initialized
INFO - 2025-07-16 10:25:34 --> Loader Class Initialized
INFO - 2025-07-16 10:25:34 --> Helper loaded: url_helper
INFO - 2025-07-16 10:25:34 --> Helper loaded: form_helper
INFO - 2025-07-16 10:25:34 --> Database Driver Class Initialized
DEBUG - 2025-07-16 10:25:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-16 10:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-16 10:25:34 --> Controller Class Initialized
INFO - 2025-07-16 10:25:34 --> Model "User_model" initialized
INFO - 2025-07-16 10:25:34 --> Form Validation Class Initialized
INFO - 2025-07-16 10:25:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-07-16 10:25:34 --> Config Class Initialized
INFO - 2025-07-16 10:25:34 --> Hooks Class Initialized
DEBUG - 2025-07-16 10:25:34 --> UTF-8 Support Enabled
INFO - 2025-07-16 10:25:34 --> Utf8 Class Initialized
INFO - 2025-07-16 10:25:34 --> URI Class Initialized
INFO - 2025-07-16 10:25:34 --> Router Class Initialized
INFO - 2025-07-16 10:25:34 --> Output Class Initialized
INFO - 2025-07-16 10:25:34 --> Security Class Initialized
DEBUG - 2025-07-16 10:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-16 10:25:34 --> Input Class Initialized
INFO - 2025-07-16 10:25:34 --> Language Class Initialized
INFO - 2025-07-16 10:25:34 --> Loader Class Initialized
INFO - 2025-07-16 10:25:34 --> Helper loaded: url_helper
INFO - 2025-07-16 10:25:34 --> Helper loaded: form_helper
INFO - 2025-07-16 10:25:34 --> Database Driver Class Initialized
DEBUG - 2025-07-16 10:25:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-16 10:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-16 10:25:34 --> Controller Class Initialized
INFO - 2025-07-16 10:25:34 --> Model "User_model" initialized
INFO - 2025-07-16 10:25:34 --> Form Validation Class Initialized
INFO - 2025-07-16 10:25:34 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\auth/login.php
INFO - 2025-07-16 10:25:34 --> Final output sent to browser
DEBUG - 2025-07-16 10:25:34 --> Total execution time: 0.0863
INFO - 2025-07-16 10:25:41 --> Config Class Initialized
INFO - 2025-07-16 10:25:41 --> Hooks Class Initialized
DEBUG - 2025-07-16 10:25:41 --> UTF-8 Support Enabled
INFO - 2025-07-16 10:25:41 --> Utf8 Class Initialized
INFO - 2025-07-16 10:25:41 --> URI Class Initialized
INFO - 2025-07-16 10:25:41 --> Router Class Initialized
INFO - 2025-07-16 10:25:41 --> Output Class Initialized
INFO - 2025-07-16 10:25:41 --> Security Class Initialized
DEBUG - 2025-07-16 10:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-16 10:25:41 --> Input Class Initialized
INFO - 2025-07-16 10:25:41 --> Language Class Initialized
INFO - 2025-07-16 10:25:41 --> Loader Class Initialized
INFO - 2025-07-16 10:25:41 --> Helper loaded: url_helper
INFO - 2025-07-16 10:25:41 --> Helper loaded: form_helper
INFO - 2025-07-16 10:25:41 --> Database Driver Class Initialized
DEBUG - 2025-07-16 10:25:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-16 10:25:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-16 10:25:41 --> Controller Class Initialized
INFO - 2025-07-16 10:25:41 --> Model "User_model" initialized
INFO - 2025-07-16 10:25:41 --> Form Validation Class Initialized
INFO - 2025-07-16 10:25:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-07-16 10:25:42 --> Config Class Initialized
INFO - 2025-07-16 10:25:42 --> Hooks Class Initialized
DEBUG - 2025-07-16 10:25:42 --> UTF-8 Support Enabled
INFO - 2025-07-16 10:25:42 --> Utf8 Class Initialized
INFO - 2025-07-16 10:25:42 --> URI Class Initialized
INFO - 2025-07-16 10:25:42 --> Router Class Initialized
INFO - 2025-07-16 10:25:42 --> Output Class Initialized
INFO - 2025-07-16 10:25:42 --> Security Class Initialized
DEBUG - 2025-07-16 10:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-16 10:25:42 --> Input Class Initialized
INFO - 2025-07-16 10:25:42 --> Language Class Initialized
INFO - 2025-07-16 10:25:42 --> Loader Class Initialized
INFO - 2025-07-16 10:25:42 --> Helper loaded: url_helper
INFO - 2025-07-16 10:25:42 --> Helper loaded: form_helper
INFO - 2025-07-16 10:25:42 --> Database Driver Class Initialized
DEBUG - 2025-07-16 10:25:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-16 10:25:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-16 10:25:42 --> Controller Class Initialized
INFO - 2025-07-16 10:25:42 --> Model "User_model" initialized
INFO - 2025-07-16 10:25:42 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-07-16 10:25:42 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/home.php
INFO - 2025-07-16 10:25:42 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-07-16 10:25:42 --> Final output sent to browser
DEBUG - 2025-07-16 10:25:42 --> Total execution time: 0.0977
INFO - 2025-07-16 10:25:45 --> Config Class Initialized
INFO - 2025-07-16 10:25:45 --> Hooks Class Initialized
DEBUG - 2025-07-16 10:25:45 --> UTF-8 Support Enabled
INFO - 2025-07-16 10:25:45 --> Utf8 Class Initialized
INFO - 2025-07-16 10:25:45 --> URI Class Initialized
INFO - 2025-07-16 10:25:45 --> Router Class Initialized
INFO - 2025-07-16 10:25:45 --> Output Class Initialized
INFO - 2025-07-16 10:25:45 --> Security Class Initialized
DEBUG - 2025-07-16 10:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-16 10:25:45 --> Input Class Initialized
INFO - 2025-07-16 10:25:45 --> Language Class Initialized
INFO - 2025-07-16 10:25:45 --> Loader Class Initialized
INFO - 2025-07-16 10:25:45 --> Helper loaded: url_helper
INFO - 2025-07-16 10:25:45 --> Helper loaded: form_helper
INFO - 2025-07-16 10:25:45 --> Database Driver Class Initialized
DEBUG - 2025-07-16 10:25:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-16 10:25:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-16 10:25:45 --> Controller Class Initialized
INFO - 2025-07-16 10:25:45 --> Model "User_model" initialized
INFO - 2025-07-16 10:25:45 --> Model "Progress_model" initialized
INFO - 2025-07-16 10:25:45 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-16 10:25:45 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-16 10:25:45 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/dashboard.php
INFO - 2025-07-16 10:25:46 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-16 10:25:46 --> Final output sent to browser
DEBUG - 2025-07-16 10:25:46 --> Total execution time: 0.6423
INFO - 2025-07-16 10:25:52 --> Config Class Initialized
INFO - 2025-07-16 10:25:52 --> Hooks Class Initialized
DEBUG - 2025-07-16 10:25:52 --> UTF-8 Support Enabled
INFO - 2025-07-16 10:25:52 --> Utf8 Class Initialized
INFO - 2025-07-16 10:25:52 --> URI Class Initialized
INFO - 2025-07-16 10:25:52 --> Router Class Initialized
INFO - 2025-07-16 10:25:52 --> Output Class Initialized
INFO - 2025-07-16 10:25:52 --> Security Class Initialized
DEBUG - 2025-07-16 10:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-16 10:25:52 --> Input Class Initialized
INFO - 2025-07-16 10:25:52 --> Language Class Initialized
INFO - 2025-07-16 10:25:52 --> Loader Class Initialized
INFO - 2025-07-16 10:25:52 --> Helper loaded: url_helper
INFO - 2025-07-16 10:25:52 --> Helper loaded: form_helper
INFO - 2025-07-16 10:25:52 --> Database Driver Class Initialized
DEBUG - 2025-07-16 10:25:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-16 10:25:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-16 10:25:52 --> Controller Class Initialized
INFO - 2025-07-16 10:25:52 --> Model "User_model" initialized
INFO - 2025-07-16 10:25:52 --> Model "Progress_model" initialized
INFO - 2025-07-16 10:25:52 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-16 10:25:52 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-16 10:25:52 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/dashboard.php
INFO - 2025-07-16 10:25:52 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-16 10:25:52 --> Final output sent to browser
DEBUG - 2025-07-16 10:25:52 --> Total execution time: 0.0983
INFO - 2025-07-16 10:25:54 --> Config Class Initialized
INFO - 2025-07-16 10:25:54 --> Hooks Class Initialized
DEBUG - 2025-07-16 10:25:54 --> UTF-8 Support Enabled
INFO - 2025-07-16 10:25:54 --> Utf8 Class Initialized
INFO - 2025-07-16 10:25:54 --> URI Class Initialized
INFO - 2025-07-16 10:25:54 --> Router Class Initialized
INFO - 2025-07-16 10:25:54 --> Output Class Initialized
INFO - 2025-07-16 10:25:54 --> Security Class Initialized
DEBUG - 2025-07-16 10:25:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-16 10:25:54 --> Input Class Initialized
INFO - 2025-07-16 10:25:54 --> Language Class Initialized
INFO - 2025-07-16 10:25:54 --> Loader Class Initialized
INFO - 2025-07-16 10:25:54 --> Helper loaded: url_helper
INFO - 2025-07-16 10:25:54 --> Helper loaded: form_helper
INFO - 2025-07-16 10:25:54 --> Database Driver Class Initialized
DEBUG - 2025-07-16 10:25:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-16 10:25:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-16 10:25:54 --> Controller Class Initialized
INFO - 2025-07-16 10:25:54 --> Model "User_model" initialized
INFO - 2025-07-16 10:25:54 --> Model "Progress_model" initialized
INFO - 2025-07-16 10:25:54 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-16 10:25:54 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-16 10:25:54 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/dashboard.php
INFO - 2025-07-16 10:25:54 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-16 10:25:54 --> Final output sent to browser
DEBUG - 2025-07-16 10:25:54 --> Total execution time: 0.0863
INFO - 2025-07-16 10:26:43 --> Config Class Initialized
INFO - 2025-07-16 10:26:43 --> Hooks Class Initialized
DEBUG - 2025-07-16 10:26:43 --> UTF-8 Support Enabled
INFO - 2025-07-16 10:26:43 --> Utf8 Class Initialized
INFO - 2025-07-16 10:26:43 --> URI Class Initialized
INFO - 2025-07-16 10:26:43 --> Router Class Initialized
INFO - 2025-07-16 10:26:43 --> Output Class Initialized
INFO - 2025-07-16 10:26:43 --> Security Class Initialized
DEBUG - 2025-07-16 10:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-16 10:26:43 --> Input Class Initialized
INFO - 2025-07-16 10:26:43 --> Language Class Initialized
INFO - 2025-07-16 10:26:43 --> Loader Class Initialized
INFO - 2025-07-16 10:26:43 --> Helper loaded: url_helper
INFO - 2025-07-16 10:26:43 --> Helper loaded: form_helper
INFO - 2025-07-16 10:26:43 --> Database Driver Class Initialized
DEBUG - 2025-07-16 10:26:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-16 10:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-16 10:26:43 --> Controller Class Initialized
INFO - 2025-07-16 10:26:43 --> Model "User_model" initialized
INFO - 2025-07-16 10:26:43 --> Model "Progress_model" initialized
INFO - 2025-07-16 10:26:43 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-16 10:26:43 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-16 10:26:43 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/guide.php
INFO - 2025-07-16 10:26:43 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-16 10:26:43 --> Final output sent to browser
DEBUG - 2025-07-16 10:26:43 --> Total execution time: 0.1408
INFO - 2025-07-16 10:27:25 --> Config Class Initialized
INFO - 2025-07-16 10:27:25 --> Hooks Class Initialized
DEBUG - 2025-07-16 10:27:25 --> UTF-8 Support Enabled
INFO - 2025-07-16 10:27:25 --> Utf8 Class Initialized
INFO - 2025-07-16 10:27:25 --> URI Class Initialized
INFO - 2025-07-16 10:27:25 --> Router Class Initialized
INFO - 2025-07-16 10:27:25 --> Output Class Initialized
INFO - 2025-07-16 10:27:25 --> Security Class Initialized
DEBUG - 2025-07-16 10:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-16 10:27:25 --> Input Class Initialized
INFO - 2025-07-16 10:27:25 --> Language Class Initialized
INFO - 2025-07-16 10:27:25 --> Loader Class Initialized
INFO - 2025-07-16 10:27:25 --> Helper loaded: url_helper
INFO - 2025-07-16 10:27:25 --> Helper loaded: form_helper
INFO - 2025-07-16 10:27:25 --> Database Driver Class Initialized
DEBUG - 2025-07-16 10:27:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-16 10:27:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-16 10:27:25 --> Controller Class Initialized
INFO - 2025-07-16 10:27:25 --> Model "Progress_model" initialized
INFO - 2025-07-16 10:27:25 --> Model "Olahraga_model" initialized
INFO - 2025-07-16 10:27:25 --> Model "User_model" initialized
INFO - 2025-07-16 10:27:25 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-16 10:27:25 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-16 10:27:25 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/progress_view.php
INFO - 2025-07-16 10:27:25 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-16 10:27:25 --> Final output sent to browser
DEBUG - 2025-07-16 10:27:25 --> Total execution time: 0.3134
INFO - 2025-07-16 10:27:26 --> Config Class Initialized
INFO - 2025-07-16 10:27:26 --> Hooks Class Initialized
DEBUG - 2025-07-16 10:27:26 --> UTF-8 Support Enabled
INFO - 2025-07-16 10:27:26 --> Utf8 Class Initialized
INFO - 2025-07-16 10:27:26 --> URI Class Initialized
INFO - 2025-07-16 10:27:26 --> Router Class Initialized
INFO - 2025-07-16 10:27:26 --> Output Class Initialized
INFO - 2025-07-16 10:27:26 --> Security Class Initialized
DEBUG - 2025-07-16 10:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-16 10:27:26 --> Input Class Initialized
INFO - 2025-07-16 10:27:26 --> Language Class Initialized
INFO - 2025-07-16 10:27:26 --> Loader Class Initialized
INFO - 2025-07-16 10:27:26 --> Helper loaded: url_helper
INFO - 2025-07-16 10:27:26 --> Helper loaded: form_helper
INFO - 2025-07-16 10:27:26 --> Database Driver Class Initialized
DEBUG - 2025-07-16 10:27:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-16 10:27:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-16 10:27:26 --> Controller Class Initialized
INFO - 2025-07-16 10:27:26 --> Model "Progress_model" initialized
INFO - 2025-07-16 10:27:26 --> Model "Olahraga_model" initialized
INFO - 2025-07-16 10:27:26 --> Model "User_model" initialized
INFO - 2025-07-16 10:27:26 --> Final output sent to browser
DEBUG - 2025-07-16 10:27:26 --> Total execution time: 0.5046
INFO - 2025-07-16 10:27:29 --> Config Class Initialized
INFO - 2025-07-16 10:27:29 --> Hooks Class Initialized
DEBUG - 2025-07-16 10:27:29 --> UTF-8 Support Enabled
INFO - 2025-07-16 10:27:29 --> Utf8 Class Initialized
INFO - 2025-07-16 10:27:29 --> URI Class Initialized
INFO - 2025-07-16 10:27:29 --> Router Class Initialized
INFO - 2025-07-16 10:27:29 --> Output Class Initialized
INFO - 2025-07-16 10:27:29 --> Security Class Initialized
DEBUG - 2025-07-16 10:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-16 10:27:29 --> Input Class Initialized
INFO - 2025-07-16 10:27:29 --> Language Class Initialized
INFO - 2025-07-16 10:27:29 --> Loader Class Initialized
INFO - 2025-07-16 10:27:29 --> Helper loaded: url_helper
INFO - 2025-07-16 10:27:29 --> Helper loaded: form_helper
INFO - 2025-07-16 10:27:29 --> Database Driver Class Initialized
DEBUG - 2025-07-16 10:27:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-16 10:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-16 10:27:29 --> Controller Class Initialized
INFO - 2025-07-16 10:27:29 --> Model "Progress_model" initialized
INFO - 2025-07-16 10:27:29 --> Model "Olahraga_model" initialized
INFO - 2025-07-16 10:27:29 --> Model "User_model" initialized
INFO - 2025-07-16 10:27:29 --> Final output sent to browser
DEBUG - 2025-07-16 10:27:29 --> Total execution time: 0.0889
INFO - 2025-07-16 10:28:11 --> Config Class Initialized
INFO - 2025-07-16 10:28:11 --> Hooks Class Initialized
DEBUG - 2025-07-16 10:28:11 --> UTF-8 Support Enabled
INFO - 2025-07-16 10:28:11 --> Utf8 Class Initialized
INFO - 2025-07-16 10:28:11 --> URI Class Initialized
INFO - 2025-07-16 10:28:11 --> Router Class Initialized
INFO - 2025-07-16 10:28:11 --> Output Class Initialized
INFO - 2025-07-16 10:28:11 --> Security Class Initialized
DEBUG - 2025-07-16 10:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-16 10:28:11 --> Input Class Initialized
INFO - 2025-07-16 10:28:11 --> Language Class Initialized
INFO - 2025-07-16 10:28:11 --> Loader Class Initialized
INFO - 2025-07-16 10:28:11 --> Helper loaded: url_helper
INFO - 2025-07-16 10:28:11 --> Helper loaded: form_helper
INFO - 2025-07-16 10:28:11 --> Database Driver Class Initialized
DEBUG - 2025-07-16 10:28:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-16 10:28:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-16 10:28:11 --> Controller Class Initialized
INFO - 2025-07-16 10:28:11 --> Model "Olahraga_model" initialized
INFO - 2025-07-16 10:28:11 --> Model "User_model" initialized
INFO - 2025-07-16 10:28:11 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-16 10:28:11 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-16 10:28:11 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-07-16 10:28:11 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-16 10:28:11 --> Final output sent to browser
DEBUG - 2025-07-16 10:28:11 --> Total execution time: 0.2222
INFO - 2025-07-16 10:30:09 --> Config Class Initialized
INFO - 2025-07-16 10:30:09 --> Hooks Class Initialized
DEBUG - 2025-07-16 10:30:09 --> UTF-8 Support Enabled
INFO - 2025-07-16 10:30:09 --> Utf8 Class Initialized
INFO - 2025-07-16 10:30:09 --> URI Class Initialized
INFO - 2025-07-16 10:30:09 --> Router Class Initialized
INFO - 2025-07-16 10:30:09 --> Output Class Initialized
INFO - 2025-07-16 10:30:09 --> Security Class Initialized
DEBUG - 2025-07-16 10:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-16 10:30:09 --> Input Class Initialized
INFO - 2025-07-16 10:30:09 --> Language Class Initialized
INFO - 2025-07-16 10:30:09 --> Loader Class Initialized
INFO - 2025-07-16 10:30:09 --> Helper loaded: url_helper
INFO - 2025-07-16 10:30:09 --> Helper loaded: form_helper
INFO - 2025-07-16 10:30:09 --> Database Driver Class Initialized
DEBUG - 2025-07-16 10:30:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-16 10:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-16 10:30:09 --> Controller Class Initialized
INFO - 2025-07-16 10:30:09 --> Model "User_model" initialized
INFO - 2025-07-16 10:30:09 --> Model "Community_model" initialized
INFO - 2025-07-16 10:30:09 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-16 10:30:09 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-16 10:30:09 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/community.php
INFO - 2025-07-16 10:30:09 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-16 10:30:09 --> Final output sent to browser
DEBUG - 2025-07-16 10:30:09 --> Total execution time: 0.3116
