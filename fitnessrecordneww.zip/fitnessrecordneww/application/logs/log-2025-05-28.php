<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-05-28 13:21:26 --> Config Class Initialized
INFO - 2025-05-28 13:21:26 --> Hooks Class Initialized
DEBUG - 2025-05-28 13:21:26 --> UTF-8 Support Enabled
INFO - 2025-05-28 13:21:26 --> Utf8 Class Initialized
INFO - 2025-05-28 13:21:26 --> URI Class Initialized
DEBUG - 2025-05-28 13:21:26 --> No URI present. Default controller set.
INFO - 2025-05-28 13:21:26 --> Router Class Initialized
INFO - 2025-05-28 13:21:26 --> Output Class Initialized
INFO - 2025-05-28 13:21:26 --> Security Class Initialized
DEBUG - 2025-05-28 13:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 13:21:26 --> Input Class Initialized
INFO - 2025-05-28 13:21:26 --> Language Class Initialized
INFO - 2025-05-28 13:21:26 --> Loader Class Initialized
INFO - 2025-05-28 13:21:26 --> Helper loaded: url_helper
INFO - 2025-05-28 13:21:26 --> Helper loaded: form_helper
INFO - 2025-05-28 13:21:26 --> Database Driver Class Initialized
DEBUG - 2025-05-28 13:21:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 13:21:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 13:21:26 --> Controller Class Initialized
INFO - 2025-05-28 13:21:26 --> Model "User_model" initialized
INFO - 2025-05-28 13:21:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-28 13:21:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-28 13:21:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-28 13:21:26 --> Final output sent to browser
DEBUG - 2025-05-28 13:21:26 --> Total execution time: 0.2118
INFO - 2025-05-28 13:31:52 --> Config Class Initialized
INFO - 2025-05-28 13:31:52 --> Hooks Class Initialized
DEBUG - 2025-05-28 13:31:52 --> UTF-8 Support Enabled
INFO - 2025-05-28 13:31:52 --> Utf8 Class Initialized
INFO - 2025-05-28 13:31:52 --> URI Class Initialized
DEBUG - 2025-05-28 13:31:52 --> No URI present. Default controller set.
INFO - 2025-05-28 13:31:52 --> Router Class Initialized
INFO - 2025-05-28 13:31:52 --> Output Class Initialized
INFO - 2025-05-28 13:31:53 --> Security Class Initialized
DEBUG - 2025-05-28 13:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 13:31:53 --> Input Class Initialized
INFO - 2025-05-28 13:31:53 --> Language Class Initialized
INFO - 2025-05-28 13:31:53 --> Loader Class Initialized
INFO - 2025-05-28 13:31:53 --> Helper loaded: url_helper
INFO - 2025-05-28 13:31:53 --> Helper loaded: form_helper
INFO - 2025-05-28 13:31:53 --> Database Driver Class Initialized
DEBUG - 2025-05-28 13:31:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 13:31:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 13:31:53 --> Controller Class Initialized
INFO - 2025-05-28 13:31:53 --> Model "User_model" initialized
INFO - 2025-05-28 13:31:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-28 13:31:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-28 13:31:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-28 13:31:54 --> Final output sent to browser
DEBUG - 2025-05-28 13:31:54 --> Total execution time: 1.7782
INFO - 2025-05-28 13:31:56 --> Config Class Initialized
INFO - 2025-05-28 13:31:56 --> Hooks Class Initialized
DEBUG - 2025-05-28 13:31:56 --> UTF-8 Support Enabled
INFO - 2025-05-28 13:31:56 --> Utf8 Class Initialized
INFO - 2025-05-28 13:31:56 --> URI Class Initialized
INFO - 2025-05-28 13:31:56 --> Router Class Initialized
INFO - 2025-05-28 13:31:56 --> Output Class Initialized
INFO - 2025-05-28 13:31:56 --> Security Class Initialized
DEBUG - 2025-05-28 13:31:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 13:31:56 --> Input Class Initialized
INFO - 2025-05-28 13:31:56 --> Language Class Initialized
INFO - 2025-05-28 13:31:56 --> Loader Class Initialized
INFO - 2025-05-28 13:31:56 --> Helper loaded: url_helper
INFO - 2025-05-28 13:31:56 --> Helper loaded: form_helper
INFO - 2025-05-28 13:31:56 --> Database Driver Class Initialized
DEBUG - 2025-05-28 13:31:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 13:31:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 13:31:56 --> Controller Class Initialized
INFO - 2025-05-28 13:31:56 --> Model "User_model" initialized
INFO - 2025-05-28 13:31:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-28 13:31:56 --> Final output sent to browser
DEBUG - 2025-05-28 13:31:56 --> Total execution time: 0.1786
INFO - 2025-05-28 13:31:58 --> Config Class Initialized
INFO - 2025-05-28 13:31:58 --> Hooks Class Initialized
DEBUG - 2025-05-28 13:31:58 --> UTF-8 Support Enabled
INFO - 2025-05-28 13:31:58 --> Utf8 Class Initialized
INFO - 2025-05-28 13:31:58 --> URI Class Initialized
DEBUG - 2025-05-28 13:31:58 --> No URI present. Default controller set.
INFO - 2025-05-28 13:31:58 --> Router Class Initialized
INFO - 2025-05-28 13:31:58 --> Output Class Initialized
INFO - 2025-05-28 13:31:58 --> Security Class Initialized
DEBUG - 2025-05-28 13:31:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 13:31:58 --> Input Class Initialized
INFO - 2025-05-28 13:31:58 --> Language Class Initialized
INFO - 2025-05-28 13:31:58 --> Loader Class Initialized
INFO - 2025-05-28 13:31:58 --> Helper loaded: url_helper
INFO - 2025-05-28 13:31:58 --> Helper loaded: form_helper
INFO - 2025-05-28 13:31:58 --> Database Driver Class Initialized
DEBUG - 2025-05-28 13:31:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 13:31:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 13:31:58 --> Controller Class Initialized
INFO - 2025-05-28 13:31:58 --> Model "User_model" initialized
INFO - 2025-05-28 13:31:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-28 13:31:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-28 13:31:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-28 13:31:58 --> Final output sent to browser
DEBUG - 2025-05-28 13:31:58 --> Total execution time: 0.0666
INFO - 2025-05-28 13:32:00 --> Config Class Initialized
INFO - 2025-05-28 13:32:00 --> Hooks Class Initialized
DEBUG - 2025-05-28 13:32:00 --> UTF-8 Support Enabled
INFO - 2025-05-28 13:32:00 --> Utf8 Class Initialized
INFO - 2025-05-28 13:32:00 --> URI Class Initialized
INFO - 2025-05-28 13:32:00 --> Router Class Initialized
INFO - 2025-05-28 13:32:00 --> Output Class Initialized
INFO - 2025-05-28 13:32:00 --> Security Class Initialized
DEBUG - 2025-05-28 13:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 13:32:00 --> Input Class Initialized
INFO - 2025-05-28 13:32:00 --> Language Class Initialized
INFO - 2025-05-28 13:32:00 --> Loader Class Initialized
INFO - 2025-05-28 13:32:00 --> Helper loaded: url_helper
INFO - 2025-05-28 13:32:00 --> Helper loaded: form_helper
INFO - 2025-05-28 13:32:00 --> Database Driver Class Initialized
DEBUG - 2025-05-28 13:32:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 13:32:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 13:32:00 --> Controller Class Initialized
INFO - 2025-05-28 13:32:00 --> Model "User_model" initialized
INFO - 2025-05-28 13:32:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-28 13:32:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/artikel.php
INFO - 2025-05-28 13:32:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-28 13:32:00 --> Final output sent to browser
DEBUG - 2025-05-28 13:32:00 --> Total execution time: 0.0887
INFO - 2025-05-28 13:34:13 --> Config Class Initialized
INFO - 2025-05-28 13:34:13 --> Hooks Class Initialized
DEBUG - 2025-05-28 13:34:13 --> UTF-8 Support Enabled
INFO - 2025-05-28 13:34:13 --> Utf8 Class Initialized
INFO - 2025-05-28 13:34:13 --> URI Class Initialized
DEBUG - 2025-05-28 13:34:13 --> No URI present. Default controller set.
INFO - 2025-05-28 13:34:13 --> Router Class Initialized
INFO - 2025-05-28 13:34:13 --> Output Class Initialized
INFO - 2025-05-28 13:34:13 --> Security Class Initialized
DEBUG - 2025-05-28 13:34:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 13:34:13 --> Input Class Initialized
INFO - 2025-05-28 13:34:13 --> Language Class Initialized
INFO - 2025-05-28 13:34:13 --> Loader Class Initialized
INFO - 2025-05-28 13:34:13 --> Helper loaded: url_helper
INFO - 2025-05-28 13:34:13 --> Helper loaded: form_helper
INFO - 2025-05-28 13:34:13 --> Database Driver Class Initialized
DEBUG - 2025-05-28 13:34:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 13:34:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 13:34:13 --> Controller Class Initialized
INFO - 2025-05-28 13:34:13 --> Model "User_model" initialized
INFO - 2025-05-28 13:34:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-28 13:34:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-28 13:34:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-28 13:34:13 --> Final output sent to browser
DEBUG - 2025-05-28 13:34:13 --> Total execution time: 0.0671
INFO - 2025-05-28 13:34:33 --> Config Class Initialized
INFO - 2025-05-28 13:34:33 --> Hooks Class Initialized
DEBUG - 2025-05-28 13:34:33 --> UTF-8 Support Enabled
INFO - 2025-05-28 13:34:33 --> Utf8 Class Initialized
INFO - 2025-05-28 13:34:34 --> URI Class Initialized
INFO - 2025-05-28 13:34:34 --> Router Class Initialized
INFO - 2025-05-28 13:34:34 --> Output Class Initialized
INFO - 2025-05-28 13:34:34 --> Security Class Initialized
DEBUG - 2025-05-28 13:34:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 13:34:34 --> Input Class Initialized
INFO - 2025-05-28 13:34:34 --> Language Class Initialized
INFO - 2025-05-28 13:34:34 --> Loader Class Initialized
INFO - 2025-05-28 13:34:34 --> Helper loaded: url_helper
INFO - 2025-05-28 13:34:34 --> Helper loaded: form_helper
INFO - 2025-05-28 13:34:34 --> Database Driver Class Initialized
DEBUG - 2025-05-28 13:34:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 13:34:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 13:34:34 --> Controller Class Initialized
INFO - 2025-05-28 13:34:34 --> Model "User_model" initialized
INFO - 2025-05-28 13:34:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-28 13:34:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/artikel.php
INFO - 2025-05-28 13:34:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-28 13:34:34 --> Final output sent to browser
DEBUG - 2025-05-28 13:34:34 --> Total execution time: 0.0760
INFO - 2025-05-28 13:34:43 --> Config Class Initialized
INFO - 2025-05-28 13:34:43 --> Hooks Class Initialized
DEBUG - 2025-05-28 13:34:43 --> UTF-8 Support Enabled
INFO - 2025-05-28 13:34:43 --> Utf8 Class Initialized
INFO - 2025-05-28 13:34:43 --> URI Class Initialized
INFO - 2025-05-28 13:34:43 --> Router Class Initialized
INFO - 2025-05-28 13:34:43 --> Output Class Initialized
INFO - 2025-05-28 13:34:43 --> Security Class Initialized
DEBUG - 2025-05-28 13:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 13:34:43 --> Input Class Initialized
INFO - 2025-05-28 13:34:43 --> Language Class Initialized
INFO - 2025-05-28 13:34:43 --> Loader Class Initialized
INFO - 2025-05-28 13:34:43 --> Helper loaded: url_helper
INFO - 2025-05-28 13:34:43 --> Helper loaded: form_helper
INFO - 2025-05-28 13:34:43 --> Database Driver Class Initialized
DEBUG - 2025-05-28 13:34:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 13:34:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 13:34:43 --> Controller Class Initialized
INFO - 2025-05-28 13:34:43 --> Model "User_model" initialized
INFO - 2025-05-28 13:34:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-28 13:34:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-28 13:34:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-28 13:34:43 --> Final output sent to browser
DEBUG - 2025-05-28 13:34:43 --> Total execution time: 0.0684
INFO - 2025-05-28 13:35:32 --> Config Class Initialized
INFO - 2025-05-28 13:35:32 --> Hooks Class Initialized
DEBUG - 2025-05-28 13:35:32 --> UTF-8 Support Enabled
INFO - 2025-05-28 13:35:32 --> Utf8 Class Initialized
INFO - 2025-05-28 13:35:32 --> URI Class Initialized
INFO - 2025-05-28 13:35:32 --> Router Class Initialized
INFO - 2025-05-28 13:35:32 --> Output Class Initialized
INFO - 2025-05-28 13:35:32 --> Security Class Initialized
DEBUG - 2025-05-28 13:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 13:35:32 --> Input Class Initialized
INFO - 2025-05-28 13:35:32 --> Language Class Initialized
INFO - 2025-05-28 13:35:32 --> Loader Class Initialized
INFO - 2025-05-28 13:35:32 --> Helper loaded: url_helper
INFO - 2025-05-28 13:35:32 --> Helper loaded: form_helper
INFO - 2025-05-28 13:35:32 --> Database Driver Class Initialized
DEBUG - 2025-05-28 13:35:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 13:35:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 13:35:32 --> Controller Class Initialized
INFO - 2025-05-28 13:35:32 --> Model "User_model" initialized
INFO - 2025-05-28 13:35:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-28 13:35:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-28 13:35:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-28 13:35:32 --> Final output sent to browser
DEBUG - 2025-05-28 13:35:32 --> Total execution time: 0.0761
INFO - 2025-05-28 13:35:34 --> Config Class Initialized
INFO - 2025-05-28 13:35:34 --> Hooks Class Initialized
DEBUG - 2025-05-28 13:35:34 --> UTF-8 Support Enabled
INFO - 2025-05-28 13:35:34 --> Utf8 Class Initialized
INFO - 2025-05-28 13:35:34 --> URI Class Initialized
INFO - 2025-05-28 13:35:34 --> Router Class Initialized
INFO - 2025-05-28 13:35:34 --> Output Class Initialized
INFO - 2025-05-28 13:35:34 --> Security Class Initialized
DEBUG - 2025-05-28 13:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 13:35:34 --> Input Class Initialized
INFO - 2025-05-28 13:35:34 --> Language Class Initialized
INFO - 2025-05-28 13:35:34 --> Loader Class Initialized
INFO - 2025-05-28 13:35:34 --> Helper loaded: url_helper
INFO - 2025-05-28 13:35:34 --> Helper loaded: form_helper
INFO - 2025-05-28 13:35:34 --> Database Driver Class Initialized
DEBUG - 2025-05-28 13:35:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 13:35:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 13:35:34 --> Controller Class Initialized
INFO - 2025-05-28 13:35:34 --> Model "User_model" initialized
INFO - 2025-05-28 13:35:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-28 13:35:34 --> Final output sent to browser
DEBUG - 2025-05-28 13:35:34 --> Total execution time: 0.0645
INFO - 2025-05-28 13:35:38 --> Config Class Initialized
INFO - 2025-05-28 13:35:38 --> Hooks Class Initialized
DEBUG - 2025-05-28 13:35:38 --> UTF-8 Support Enabled
INFO - 2025-05-28 13:35:38 --> Utf8 Class Initialized
INFO - 2025-05-28 13:35:38 --> URI Class Initialized
INFO - 2025-05-28 13:35:38 --> Router Class Initialized
INFO - 2025-05-28 13:35:38 --> Output Class Initialized
INFO - 2025-05-28 13:35:38 --> Security Class Initialized
DEBUG - 2025-05-28 13:35:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 13:35:38 --> Input Class Initialized
INFO - 2025-05-28 13:35:38 --> Language Class Initialized
INFO - 2025-05-28 13:35:38 --> Loader Class Initialized
INFO - 2025-05-28 13:35:38 --> Helper loaded: url_helper
INFO - 2025-05-28 13:35:38 --> Helper loaded: form_helper
INFO - 2025-05-28 13:35:38 --> Database Driver Class Initialized
DEBUG - 2025-05-28 13:35:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 13:35:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 13:35:38 --> Controller Class Initialized
INFO - 2025-05-28 13:35:38 --> Model "User_model" initialized
INFO - 2025-05-28 13:35:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-28 13:35:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/artikel.php
INFO - 2025-05-28 13:35:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-28 13:35:38 --> Final output sent to browser
DEBUG - 2025-05-28 13:35:38 --> Total execution time: 0.0641
INFO - 2025-05-28 13:35:43 --> Config Class Initialized
INFO - 2025-05-28 13:35:43 --> Hooks Class Initialized
DEBUG - 2025-05-28 13:35:43 --> UTF-8 Support Enabled
INFO - 2025-05-28 13:35:43 --> Utf8 Class Initialized
INFO - 2025-05-28 13:35:43 --> URI Class Initialized
INFO - 2025-05-28 13:35:43 --> Router Class Initialized
INFO - 2025-05-28 13:35:43 --> Output Class Initialized
INFO - 2025-05-28 13:35:43 --> Security Class Initialized
DEBUG - 2025-05-28 13:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 13:35:43 --> Input Class Initialized
INFO - 2025-05-28 13:35:43 --> Language Class Initialized
INFO - 2025-05-28 13:35:43 --> Loader Class Initialized
INFO - 2025-05-28 13:35:43 --> Helper loaded: url_helper
INFO - 2025-05-28 13:35:43 --> Helper loaded: form_helper
INFO - 2025-05-28 13:35:43 --> Database Driver Class Initialized
DEBUG - 2025-05-28 13:35:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 13:35:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 13:35:43 --> Controller Class Initialized
INFO - 2025-05-28 13:35:43 --> Model "User_model" initialized
INFO - 2025-05-28 13:35:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-28 13:35:43 --> Final output sent to browser
DEBUG - 2025-05-28 13:35:43 --> Total execution time: 0.0665
INFO - 2025-05-28 13:35:48 --> Config Class Initialized
INFO - 2025-05-28 13:35:48 --> Hooks Class Initialized
DEBUG - 2025-05-28 13:35:48 --> UTF-8 Support Enabled
INFO - 2025-05-28 13:35:48 --> Utf8 Class Initialized
INFO - 2025-05-28 13:35:48 --> URI Class Initialized
INFO - 2025-05-28 13:35:48 --> Router Class Initialized
INFO - 2025-05-28 13:35:48 --> Output Class Initialized
INFO - 2025-05-28 13:35:48 --> Security Class Initialized
DEBUG - 2025-05-28 13:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 13:35:48 --> Input Class Initialized
INFO - 2025-05-28 13:35:48 --> Language Class Initialized
INFO - 2025-05-28 13:35:48 --> Loader Class Initialized
INFO - 2025-05-28 13:35:48 --> Helper loaded: url_helper
INFO - 2025-05-28 13:35:48 --> Helper loaded: form_helper
INFO - 2025-05-28 13:35:48 --> Database Driver Class Initialized
DEBUG - 2025-05-28 13:35:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 13:35:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 13:35:48 --> Controller Class Initialized
INFO - 2025-05-28 13:35:48 --> Model "User_model" initialized
INFO - 2025-05-28 13:35:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-28 13:35:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/artikel.php
INFO - 2025-05-28 13:35:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-28 13:35:48 --> Final output sent to browser
DEBUG - 2025-05-28 13:35:48 --> Total execution time: 0.0680
INFO - 2025-05-28 13:35:56 --> Config Class Initialized
INFO - 2025-05-28 13:35:56 --> Hooks Class Initialized
DEBUG - 2025-05-28 13:35:56 --> UTF-8 Support Enabled
INFO - 2025-05-28 13:35:56 --> Utf8 Class Initialized
INFO - 2025-05-28 13:35:56 --> URI Class Initialized
INFO - 2025-05-28 13:35:56 --> Router Class Initialized
INFO - 2025-05-28 13:35:56 --> Output Class Initialized
INFO - 2025-05-28 13:35:56 --> Security Class Initialized
DEBUG - 2025-05-28 13:35:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 13:35:56 --> Input Class Initialized
INFO - 2025-05-28 13:35:56 --> Language Class Initialized
INFO - 2025-05-28 13:35:56 --> Loader Class Initialized
INFO - 2025-05-28 13:35:56 --> Helper loaded: url_helper
INFO - 2025-05-28 13:35:56 --> Helper loaded: form_helper
INFO - 2025-05-28 13:35:56 --> Database Driver Class Initialized
DEBUG - 2025-05-28 13:35:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 13:35:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 13:35:56 --> Controller Class Initialized
INFO - 2025-05-28 13:35:56 --> Model "User_model" initialized
INFO - 2025-05-28 13:35:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-28 13:35:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/artikel.php
INFO - 2025-05-28 13:35:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-28 13:35:56 --> Final output sent to browser
DEBUG - 2025-05-28 13:35:56 --> Total execution time: 0.0692
INFO - 2025-05-28 13:36:19 --> Config Class Initialized
INFO - 2025-05-28 13:36:19 --> Hooks Class Initialized
DEBUG - 2025-05-28 13:36:19 --> UTF-8 Support Enabled
INFO - 2025-05-28 13:36:19 --> Utf8 Class Initialized
INFO - 2025-05-28 13:36:19 --> URI Class Initialized
INFO - 2025-05-28 13:36:19 --> Router Class Initialized
INFO - 2025-05-28 13:36:19 --> Output Class Initialized
INFO - 2025-05-28 13:36:19 --> Security Class Initialized
DEBUG - 2025-05-28 13:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 13:36:19 --> Input Class Initialized
INFO - 2025-05-28 13:36:19 --> Language Class Initialized
INFO - 2025-05-28 13:36:19 --> Loader Class Initialized
INFO - 2025-05-28 13:36:19 --> Helper loaded: url_helper
INFO - 2025-05-28 13:36:19 --> Helper loaded: form_helper
INFO - 2025-05-28 13:36:19 --> Database Driver Class Initialized
DEBUG - 2025-05-28 13:36:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 13:36:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 13:36:19 --> Controller Class Initialized
INFO - 2025-05-28 13:36:19 --> Model "User_model" initialized
INFO - 2025-05-28 13:36:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-28 13:36:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-28 13:36:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-28 13:36:19 --> Final output sent to browser
DEBUG - 2025-05-28 13:36:19 --> Total execution time: 0.0876
INFO - 2025-05-28 13:38:27 --> Config Class Initialized
INFO - 2025-05-28 13:38:27 --> Hooks Class Initialized
DEBUG - 2025-05-28 13:38:27 --> UTF-8 Support Enabled
INFO - 2025-05-28 13:38:27 --> Utf8 Class Initialized
INFO - 2025-05-28 13:38:27 --> URI Class Initialized
INFO - 2025-05-28 13:38:27 --> Router Class Initialized
INFO - 2025-05-28 13:38:27 --> Output Class Initialized
INFO - 2025-05-28 13:38:27 --> Security Class Initialized
DEBUG - 2025-05-28 13:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 13:38:27 --> Input Class Initialized
INFO - 2025-05-28 13:38:27 --> Language Class Initialized
INFO - 2025-05-28 13:38:27 --> Loader Class Initialized
INFO - 2025-05-28 13:38:27 --> Helper loaded: url_helper
INFO - 2025-05-28 13:38:27 --> Helper loaded: form_helper
INFO - 2025-05-28 13:38:27 --> Database Driver Class Initialized
DEBUG - 2025-05-28 13:38:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 13:38:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 13:38:27 --> Controller Class Initialized
INFO - 2025-05-28 13:38:27 --> Model "User_model" initialized
INFO - 2025-05-28 13:38:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-28 13:38:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-28 13:38:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-28 13:38:27 --> Final output sent to browser
DEBUG - 2025-05-28 13:38:27 --> Total execution time: 0.0708
INFO - 2025-05-28 13:38:29 --> Config Class Initialized
INFO - 2025-05-28 13:38:29 --> Hooks Class Initialized
DEBUG - 2025-05-28 13:38:29 --> UTF-8 Support Enabled
INFO - 2025-05-28 13:38:29 --> Utf8 Class Initialized
INFO - 2025-05-28 13:38:29 --> URI Class Initialized
INFO - 2025-05-28 13:38:29 --> Router Class Initialized
INFO - 2025-05-28 13:38:29 --> Output Class Initialized
INFO - 2025-05-28 13:38:29 --> Security Class Initialized
DEBUG - 2025-05-28 13:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 13:38:29 --> Input Class Initialized
INFO - 2025-05-28 13:38:29 --> Language Class Initialized
INFO - 2025-05-28 13:38:29 --> Loader Class Initialized
INFO - 2025-05-28 13:38:29 --> Helper loaded: url_helper
INFO - 2025-05-28 13:38:29 --> Helper loaded: form_helper
INFO - 2025-05-28 13:38:29 --> Database Driver Class Initialized
DEBUG - 2025-05-28 13:38:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 13:38:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 13:38:29 --> Controller Class Initialized
INFO - 2025-05-28 13:38:29 --> Model "User_model" initialized
ERROR - 2025-05-28 13:38:29 --> Severity: Warning --> Undefined variable $data C:\laragon\www\Project\fitnessrecord\application\controllers\Auth.php 32
INFO - 2025-05-28 13:38:29 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-28 13:38:29 --> Final output sent to browser
DEBUG - 2025-05-28 13:38:29 --> Total execution time: 0.1695
INFO - 2025-05-28 13:38:46 --> Config Class Initialized
INFO - 2025-05-28 13:38:46 --> Hooks Class Initialized
DEBUG - 2025-05-28 13:38:46 --> UTF-8 Support Enabled
INFO - 2025-05-28 13:38:46 --> Utf8 Class Initialized
INFO - 2025-05-28 13:38:46 --> URI Class Initialized
INFO - 2025-05-28 13:38:46 --> Router Class Initialized
INFO - 2025-05-28 13:38:46 --> Output Class Initialized
INFO - 2025-05-28 13:38:46 --> Security Class Initialized
DEBUG - 2025-05-28 13:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 13:38:46 --> Input Class Initialized
INFO - 2025-05-28 13:38:46 --> Language Class Initialized
INFO - 2025-05-28 13:38:46 --> Loader Class Initialized
INFO - 2025-05-28 13:38:46 --> Helper loaded: url_helper
INFO - 2025-05-28 13:38:46 --> Helper loaded: form_helper
INFO - 2025-05-28 13:38:46 --> Database Driver Class Initialized
DEBUG - 2025-05-28 13:38:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 13:38:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 13:38:46 --> Controller Class Initialized
INFO - 2025-05-28 13:38:46 --> Model "User_model" initialized
INFO - 2025-05-28 13:38:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-28 13:38:46 --> Final output sent to browser
DEBUG - 2025-05-28 13:38:46 --> Total execution time: 0.0581
INFO - 2025-05-28 13:38:59 --> Config Class Initialized
INFO - 2025-05-28 13:38:59 --> Hooks Class Initialized
DEBUG - 2025-05-28 13:38:59 --> UTF-8 Support Enabled
INFO - 2025-05-28 13:38:59 --> Utf8 Class Initialized
INFO - 2025-05-28 13:38:59 --> URI Class Initialized
INFO - 2025-05-28 13:38:59 --> Router Class Initialized
INFO - 2025-05-28 13:38:59 --> Output Class Initialized
INFO - 2025-05-28 13:38:59 --> Security Class Initialized
DEBUG - 2025-05-28 13:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 13:38:59 --> Input Class Initialized
INFO - 2025-05-28 13:38:59 --> Language Class Initialized
INFO - 2025-05-28 13:38:59 --> Loader Class Initialized
INFO - 2025-05-28 13:38:59 --> Helper loaded: url_helper
INFO - 2025-05-28 13:38:59 --> Helper loaded: form_helper
INFO - 2025-05-28 13:38:59 --> Database Driver Class Initialized
DEBUG - 2025-05-28 13:38:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 13:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 13:38:59 --> Controller Class Initialized
INFO - 2025-05-28 13:38:59 --> Model "User_model" initialized
INFO - 2025-05-28 13:38:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-28 13:38:59 --> Final output sent to browser
DEBUG - 2025-05-28 13:38:59 --> Total execution time: 0.0746
INFO - 2025-05-28 13:43:53 --> Config Class Initialized
INFO - 2025-05-28 13:43:53 --> Hooks Class Initialized
DEBUG - 2025-05-28 13:43:53 --> UTF-8 Support Enabled
INFO - 2025-05-28 13:43:53 --> Utf8 Class Initialized
INFO - 2025-05-28 13:43:53 --> URI Class Initialized
INFO - 2025-05-28 13:43:53 --> Router Class Initialized
INFO - 2025-05-28 13:43:53 --> Output Class Initialized
INFO - 2025-05-28 13:43:53 --> Security Class Initialized
DEBUG - 2025-05-28 13:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 13:43:53 --> Input Class Initialized
INFO - 2025-05-28 13:43:53 --> Language Class Initialized
INFO - 2025-05-28 13:43:53 --> Loader Class Initialized
INFO - 2025-05-28 13:43:53 --> Helper loaded: url_helper
INFO - 2025-05-28 13:43:53 --> Helper loaded: form_helper
INFO - 2025-05-28 13:43:53 --> Database Driver Class Initialized
DEBUG - 2025-05-28 13:43:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 13:43:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 13:43:53 --> Controller Class Initialized
INFO - 2025-05-28 13:43:53 --> Model "User_model" initialized
INFO - 2025-05-28 13:43:53 --> Form Validation Class Initialized
INFO - 2025-05-28 13:43:53 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-05-28 13:43:53 --> Config Class Initialized
INFO - 2025-05-28 13:43:53 --> Hooks Class Initialized
DEBUG - 2025-05-28 13:43:53 --> UTF-8 Support Enabled
INFO - 2025-05-28 13:43:53 --> Utf8 Class Initialized
INFO - 2025-05-28 13:43:53 --> URI Class Initialized
INFO - 2025-05-28 13:43:53 --> Router Class Initialized
INFO - 2025-05-28 13:43:53 --> Output Class Initialized
INFO - 2025-05-28 13:43:53 --> Security Class Initialized
DEBUG - 2025-05-28 13:43:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 13:43:53 --> Input Class Initialized
INFO - 2025-05-28 13:43:53 --> Language Class Initialized
INFO - 2025-05-28 13:43:53 --> Loader Class Initialized
INFO - 2025-05-28 13:43:53 --> Helper loaded: url_helper
INFO - 2025-05-28 13:43:53 --> Helper loaded: form_helper
INFO - 2025-05-28 13:43:54 --> Database Driver Class Initialized
DEBUG - 2025-05-28 13:43:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 13:43:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 13:43:54 --> Controller Class Initialized
INFO - 2025-05-28 13:43:54 --> Model "User_model" initialized
INFO - 2025-05-28 13:43:54 --> Form Validation Class Initialized
INFO - 2025-05-28 13:43:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-28 13:43:54 --> Final output sent to browser
DEBUG - 2025-05-28 13:43:54 --> Total execution time: 0.0816
INFO - 2025-05-28 13:44:10 --> Config Class Initialized
INFO - 2025-05-28 13:44:10 --> Hooks Class Initialized
DEBUG - 2025-05-28 13:44:10 --> UTF-8 Support Enabled
INFO - 2025-05-28 13:44:10 --> Utf8 Class Initialized
INFO - 2025-05-28 13:44:10 --> URI Class Initialized
INFO - 2025-05-28 13:44:10 --> Router Class Initialized
INFO - 2025-05-28 13:44:10 --> Output Class Initialized
INFO - 2025-05-28 13:44:10 --> Security Class Initialized
DEBUG - 2025-05-28 13:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 13:44:10 --> Input Class Initialized
INFO - 2025-05-28 13:44:10 --> Language Class Initialized
INFO - 2025-05-28 13:44:10 --> Loader Class Initialized
INFO - 2025-05-28 13:44:10 --> Helper loaded: url_helper
INFO - 2025-05-28 13:44:10 --> Helper loaded: form_helper
INFO - 2025-05-28 13:44:10 --> Database Driver Class Initialized
DEBUG - 2025-05-28 13:44:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 13:44:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 13:44:10 --> Controller Class Initialized
INFO - 2025-05-28 13:44:10 --> Model "User_model" initialized
INFO - 2025-05-28 13:44:10 --> Form Validation Class Initialized
INFO - 2025-05-28 13:44:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-05-28 13:44:10 --> Config Class Initialized
INFO - 2025-05-28 13:44:10 --> Hooks Class Initialized
DEBUG - 2025-05-28 13:44:10 --> UTF-8 Support Enabled
INFO - 2025-05-28 13:44:10 --> Utf8 Class Initialized
INFO - 2025-05-28 13:44:10 --> URI Class Initialized
INFO - 2025-05-28 13:44:10 --> Router Class Initialized
INFO - 2025-05-28 13:44:10 --> Output Class Initialized
INFO - 2025-05-28 13:44:10 --> Security Class Initialized
DEBUG - 2025-05-28 13:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 13:44:10 --> Input Class Initialized
INFO - 2025-05-28 13:44:10 --> Language Class Initialized
INFO - 2025-05-28 13:44:10 --> Loader Class Initialized
INFO - 2025-05-28 13:44:10 --> Helper loaded: url_helper
INFO - 2025-05-28 13:44:10 --> Helper loaded: form_helper
INFO - 2025-05-28 13:44:10 --> Database Driver Class Initialized
DEBUG - 2025-05-28 13:44:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 13:44:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 13:44:10 --> Controller Class Initialized
INFO - 2025-05-28 13:44:10 --> Model "User_model" initialized
INFO - 2025-05-28 13:44:10 --> Form Validation Class Initialized
INFO - 2025-05-28 13:44:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-28 13:44:10 --> Final output sent to browser
DEBUG - 2025-05-28 13:44:10 --> Total execution time: 0.0779
INFO - 2025-05-28 13:45:05 --> Config Class Initialized
INFO - 2025-05-28 13:45:05 --> Hooks Class Initialized
DEBUG - 2025-05-28 13:45:05 --> UTF-8 Support Enabled
INFO - 2025-05-28 13:45:05 --> Utf8 Class Initialized
INFO - 2025-05-28 13:45:05 --> URI Class Initialized
INFO - 2025-05-28 13:45:05 --> Router Class Initialized
INFO - 2025-05-28 13:45:05 --> Output Class Initialized
INFO - 2025-05-28 13:45:05 --> Security Class Initialized
DEBUG - 2025-05-28 13:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 13:45:05 --> Input Class Initialized
INFO - 2025-05-28 13:45:05 --> Language Class Initialized
INFO - 2025-05-28 13:45:05 --> Loader Class Initialized
INFO - 2025-05-28 13:45:05 --> Helper loaded: url_helper
INFO - 2025-05-28 13:45:05 --> Helper loaded: form_helper
INFO - 2025-05-28 13:45:05 --> Database Driver Class Initialized
DEBUG - 2025-05-28 13:45:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 13:45:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 13:45:05 --> Controller Class Initialized
INFO - 2025-05-28 13:45:05 --> Model "User_model" initialized
INFO - 2025-05-28 13:45:05 --> Form Validation Class Initialized
INFO - 2025-05-28 13:45:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-28 13:45:05 --> Final output sent to browser
DEBUG - 2025-05-28 13:45:05 --> Total execution time: 0.0615
INFO - 2025-05-28 13:45:14 --> Config Class Initialized
INFO - 2025-05-28 13:45:14 --> Hooks Class Initialized
DEBUG - 2025-05-28 13:45:14 --> UTF-8 Support Enabled
INFO - 2025-05-28 13:45:14 --> Utf8 Class Initialized
INFO - 2025-05-28 13:45:14 --> URI Class Initialized
INFO - 2025-05-28 13:45:14 --> Router Class Initialized
INFO - 2025-05-28 13:45:14 --> Output Class Initialized
INFO - 2025-05-28 13:45:14 --> Security Class Initialized
DEBUG - 2025-05-28 13:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 13:45:14 --> Input Class Initialized
INFO - 2025-05-28 13:45:14 --> Language Class Initialized
INFO - 2025-05-28 13:45:14 --> Loader Class Initialized
INFO - 2025-05-28 13:45:14 --> Helper loaded: url_helper
INFO - 2025-05-28 13:45:14 --> Helper loaded: form_helper
INFO - 2025-05-28 13:45:14 --> Database Driver Class Initialized
DEBUG - 2025-05-28 13:45:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 13:45:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 13:45:14 --> Controller Class Initialized
INFO - 2025-05-28 13:45:14 --> Model "User_model" initialized
INFO - 2025-05-28 13:45:14 --> Form Validation Class Initialized
INFO - 2025-05-28 13:45:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-05-28 13:45:14 --> Config Class Initialized
INFO - 2025-05-28 13:45:14 --> Hooks Class Initialized
DEBUG - 2025-05-28 13:45:14 --> UTF-8 Support Enabled
INFO - 2025-05-28 13:45:14 --> Utf8 Class Initialized
INFO - 2025-05-28 13:45:14 --> URI Class Initialized
INFO - 2025-05-28 13:45:14 --> Router Class Initialized
INFO - 2025-05-28 13:45:14 --> Output Class Initialized
INFO - 2025-05-28 13:45:14 --> Security Class Initialized
DEBUG - 2025-05-28 13:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 13:45:14 --> Input Class Initialized
INFO - 2025-05-28 13:45:14 --> Language Class Initialized
INFO - 2025-05-28 13:45:14 --> Loader Class Initialized
INFO - 2025-05-28 13:45:14 --> Helper loaded: url_helper
INFO - 2025-05-28 13:45:14 --> Helper loaded: form_helper
INFO - 2025-05-28 13:45:14 --> Database Driver Class Initialized
DEBUG - 2025-05-28 13:45:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 13:45:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 13:45:14 --> Controller Class Initialized
INFO - 2025-05-28 13:45:14 --> Model "User_model" initialized
INFO - 2025-05-28 13:45:14 --> Form Validation Class Initialized
INFO - 2025-05-28 13:45:14 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-28 13:45:14 --> Final output sent to browser
DEBUG - 2025-05-28 13:45:14 --> Total execution time: 0.0555
INFO - 2025-05-28 13:48:11 --> Config Class Initialized
INFO - 2025-05-28 13:48:11 --> Hooks Class Initialized
DEBUG - 2025-05-28 13:48:11 --> UTF-8 Support Enabled
INFO - 2025-05-28 13:48:11 --> Utf8 Class Initialized
INFO - 2025-05-28 13:48:11 --> URI Class Initialized
INFO - 2025-05-28 13:48:11 --> Router Class Initialized
INFO - 2025-05-28 13:48:11 --> Output Class Initialized
INFO - 2025-05-28 13:48:11 --> Security Class Initialized
DEBUG - 2025-05-28 13:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 13:48:11 --> Input Class Initialized
INFO - 2025-05-28 13:48:11 --> Language Class Initialized
INFO - 2025-05-28 13:48:11 --> Loader Class Initialized
INFO - 2025-05-28 13:48:11 --> Helper loaded: url_helper
INFO - 2025-05-28 13:48:11 --> Helper loaded: form_helper
INFO - 2025-05-28 13:48:11 --> Database Driver Class Initialized
DEBUG - 2025-05-28 13:48:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 13:48:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 13:48:11 --> Controller Class Initialized
INFO - 2025-05-28 13:48:11 --> Model "User_model" initialized
INFO - 2025-05-28 13:48:11 --> Form Validation Class Initialized
INFO - 2025-05-28 13:48:11 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-28 13:48:11 --> Final output sent to browser
DEBUG - 2025-05-28 13:48:11 --> Total execution time: 0.0938
INFO - 2025-05-28 13:48:12 --> Config Class Initialized
INFO - 2025-05-28 13:48:12 --> Hooks Class Initialized
DEBUG - 2025-05-28 13:48:12 --> UTF-8 Support Enabled
INFO - 2025-05-28 13:48:12 --> Utf8 Class Initialized
INFO - 2025-05-28 13:48:12 --> URI Class Initialized
INFO - 2025-05-28 13:48:12 --> Router Class Initialized
INFO - 2025-05-28 13:48:12 --> Output Class Initialized
INFO - 2025-05-28 13:48:12 --> Security Class Initialized
DEBUG - 2025-05-28 13:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 13:48:12 --> Input Class Initialized
INFO - 2025-05-28 13:48:12 --> Language Class Initialized
INFO - 2025-05-28 13:48:12 --> Loader Class Initialized
INFO - 2025-05-28 13:48:12 --> Helper loaded: url_helper
INFO - 2025-05-28 13:48:12 --> Helper loaded: form_helper
INFO - 2025-05-28 13:48:12 --> Database Driver Class Initialized
DEBUG - 2025-05-28 13:48:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 13:48:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 13:48:12 --> Controller Class Initialized
INFO - 2025-05-28 13:48:12 --> Model "User_model" initialized
INFO - 2025-05-28 13:48:12 --> Form Validation Class Initialized
INFO - 2025-05-28 13:48:12 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-28 13:48:12 --> Final output sent to browser
DEBUG - 2025-05-28 13:48:12 --> Total execution time: 0.0772
INFO - 2025-05-28 13:48:15 --> Config Class Initialized
INFO - 2025-05-28 13:48:15 --> Hooks Class Initialized
DEBUG - 2025-05-28 13:48:15 --> UTF-8 Support Enabled
INFO - 2025-05-28 13:48:15 --> Utf8 Class Initialized
INFO - 2025-05-28 13:48:15 --> URI Class Initialized
INFO - 2025-05-28 13:48:15 --> Router Class Initialized
INFO - 2025-05-28 13:48:15 --> Output Class Initialized
INFO - 2025-05-28 13:48:15 --> Security Class Initialized
DEBUG - 2025-05-28 13:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 13:48:15 --> Input Class Initialized
INFO - 2025-05-28 13:48:15 --> Language Class Initialized
INFO - 2025-05-28 13:48:15 --> Loader Class Initialized
INFO - 2025-05-28 13:48:15 --> Helper loaded: url_helper
INFO - 2025-05-28 13:48:15 --> Helper loaded: form_helper
INFO - 2025-05-28 13:48:15 --> Database Driver Class Initialized
DEBUG - 2025-05-28 13:48:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 13:48:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 13:48:15 --> Controller Class Initialized
INFO - 2025-05-28 13:48:15 --> Model "User_model" initialized
INFO - 2025-05-28 13:48:15 --> Form Validation Class Initialized
INFO - 2025-05-28 13:48:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-28 13:48:15 --> Final output sent to browser
DEBUG - 2025-05-28 13:48:15 --> Total execution time: 0.0776
INFO - 2025-05-28 13:48:37 --> Config Class Initialized
INFO - 2025-05-28 13:48:37 --> Hooks Class Initialized
DEBUG - 2025-05-28 13:48:37 --> UTF-8 Support Enabled
INFO - 2025-05-28 13:48:37 --> Utf8 Class Initialized
INFO - 2025-05-28 13:48:37 --> URI Class Initialized
DEBUG - 2025-05-28 13:48:37 --> No URI present. Default controller set.
INFO - 2025-05-28 13:48:37 --> Router Class Initialized
INFO - 2025-05-28 13:48:37 --> Output Class Initialized
INFO - 2025-05-28 13:48:37 --> Security Class Initialized
DEBUG - 2025-05-28 13:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 13:48:37 --> Input Class Initialized
INFO - 2025-05-28 13:48:37 --> Language Class Initialized
INFO - 2025-05-28 13:48:37 --> Loader Class Initialized
INFO - 2025-05-28 13:48:37 --> Helper loaded: url_helper
INFO - 2025-05-28 13:48:37 --> Helper loaded: form_helper
INFO - 2025-05-28 13:48:37 --> Database Driver Class Initialized
DEBUG - 2025-05-28 13:48:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 13:48:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 13:48:37 --> Controller Class Initialized
INFO - 2025-05-28 13:48:37 --> Model "User_model" initialized
INFO - 2025-05-28 13:48:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-28 13:48:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-28 13:48:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-28 13:48:37 --> Final output sent to browser
DEBUG - 2025-05-28 13:48:37 --> Total execution time: 0.0579
INFO - 2025-05-28 13:48:40 --> Config Class Initialized
INFO - 2025-05-28 13:48:40 --> Hooks Class Initialized
DEBUG - 2025-05-28 13:48:40 --> UTF-8 Support Enabled
INFO - 2025-05-28 13:48:40 --> Utf8 Class Initialized
INFO - 2025-05-28 13:48:40 --> URI Class Initialized
INFO - 2025-05-28 13:48:40 --> Router Class Initialized
INFO - 2025-05-28 13:48:40 --> Output Class Initialized
INFO - 2025-05-28 13:48:40 --> Security Class Initialized
DEBUG - 2025-05-28 13:48:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 13:48:40 --> Input Class Initialized
INFO - 2025-05-28 13:48:40 --> Language Class Initialized
INFO - 2025-05-28 13:48:40 --> Loader Class Initialized
INFO - 2025-05-28 13:48:40 --> Helper loaded: url_helper
INFO - 2025-05-28 13:48:40 --> Helper loaded: form_helper
INFO - 2025-05-28 13:48:40 --> Database Driver Class Initialized
DEBUG - 2025-05-28 13:48:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 13:48:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 13:48:40 --> Controller Class Initialized
INFO - 2025-05-28 13:48:40 --> Model "User_model" initialized
INFO - 2025-05-28 13:48:40 --> Form Validation Class Initialized
INFO - 2025-05-28 13:48:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-28 13:48:40 --> Final output sent to browser
DEBUG - 2025-05-28 13:48:40 --> Total execution time: 0.0602
INFO - 2025-05-28 13:48:48 --> Config Class Initialized
INFO - 2025-05-28 13:48:48 --> Hooks Class Initialized
DEBUG - 2025-05-28 13:48:48 --> UTF-8 Support Enabled
INFO - 2025-05-28 13:48:48 --> Utf8 Class Initialized
INFO - 2025-05-28 13:48:48 --> URI Class Initialized
INFO - 2025-05-28 13:48:48 --> Router Class Initialized
INFO - 2025-05-28 13:48:48 --> Output Class Initialized
INFO - 2025-05-28 13:48:48 --> Security Class Initialized
DEBUG - 2025-05-28 13:48:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 13:48:48 --> Input Class Initialized
INFO - 2025-05-28 13:48:48 --> Language Class Initialized
INFO - 2025-05-28 13:48:48 --> Loader Class Initialized
INFO - 2025-05-28 13:48:48 --> Helper loaded: url_helper
INFO - 2025-05-28 13:48:48 --> Helper loaded: form_helper
INFO - 2025-05-28 13:48:48 --> Database Driver Class Initialized
DEBUG - 2025-05-28 13:48:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 13:48:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 13:48:48 --> Controller Class Initialized
INFO - 2025-05-28 13:48:48 --> Model "User_model" initialized
INFO - 2025-05-28 13:48:48 --> Form Validation Class Initialized
INFO - 2025-05-28 13:48:48 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-05-28 13:48:48 --> Config Class Initialized
INFO - 2025-05-28 13:48:48 --> Hooks Class Initialized
DEBUG - 2025-05-28 13:48:48 --> UTF-8 Support Enabled
INFO - 2025-05-28 13:48:48 --> Utf8 Class Initialized
INFO - 2025-05-28 13:48:48 --> URI Class Initialized
INFO - 2025-05-28 13:48:48 --> Router Class Initialized
INFO - 2025-05-28 13:48:48 --> Output Class Initialized
INFO - 2025-05-28 13:48:48 --> Security Class Initialized
DEBUG - 2025-05-28 13:48:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 13:48:48 --> Input Class Initialized
INFO - 2025-05-28 13:48:48 --> Language Class Initialized
INFO - 2025-05-28 13:48:48 --> Loader Class Initialized
INFO - 2025-05-28 13:48:48 --> Helper loaded: url_helper
INFO - 2025-05-28 13:48:48 --> Helper loaded: form_helper
INFO - 2025-05-28 13:48:48 --> Database Driver Class Initialized
DEBUG - 2025-05-28 13:48:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 13:48:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 13:48:48 --> Controller Class Initialized
INFO - 2025-05-28 13:48:48 --> Model "User_model" initialized
INFO - 2025-05-28 13:48:48 --> Form Validation Class Initialized
INFO - 2025-05-28 13:48:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-28 13:48:48 --> Final output sent to browser
DEBUG - 2025-05-28 13:48:48 --> Total execution time: 0.0627
INFO - 2025-05-28 13:48:59 --> Config Class Initialized
INFO - 2025-05-28 13:48:59 --> Hooks Class Initialized
DEBUG - 2025-05-28 13:48:59 --> UTF-8 Support Enabled
INFO - 2025-05-28 13:48:59 --> Utf8 Class Initialized
INFO - 2025-05-28 13:48:59 --> URI Class Initialized
INFO - 2025-05-28 13:48:59 --> Router Class Initialized
INFO - 2025-05-28 13:48:59 --> Output Class Initialized
INFO - 2025-05-28 13:48:59 --> Security Class Initialized
DEBUG - 2025-05-28 13:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 13:48:59 --> Input Class Initialized
INFO - 2025-05-28 13:48:59 --> Language Class Initialized
INFO - 2025-05-28 13:49:00 --> Loader Class Initialized
INFO - 2025-05-28 13:49:00 --> Helper loaded: url_helper
INFO - 2025-05-28 13:49:00 --> Helper loaded: form_helper
INFO - 2025-05-28 13:49:00 --> Database Driver Class Initialized
DEBUG - 2025-05-28 13:49:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 13:49:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 13:49:00 --> Controller Class Initialized
INFO - 2025-05-28 13:49:00 --> Model "User_model" initialized
INFO - 2025-05-28 13:49:00 --> Form Validation Class Initialized
INFO - 2025-05-28 13:49:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-05-28 13:49:00 --> Config Class Initialized
INFO - 2025-05-28 13:49:00 --> Hooks Class Initialized
DEBUG - 2025-05-28 13:49:00 --> UTF-8 Support Enabled
INFO - 2025-05-28 13:49:00 --> Utf8 Class Initialized
INFO - 2025-05-28 13:49:00 --> URI Class Initialized
INFO - 2025-05-28 13:49:00 --> Router Class Initialized
INFO - 2025-05-28 13:49:00 --> Output Class Initialized
INFO - 2025-05-28 13:49:00 --> Security Class Initialized
DEBUG - 2025-05-28 13:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 13:49:00 --> Input Class Initialized
INFO - 2025-05-28 13:49:00 --> Language Class Initialized
INFO - 2025-05-28 13:49:00 --> Loader Class Initialized
INFO - 2025-05-28 13:49:00 --> Helper loaded: url_helper
INFO - 2025-05-28 13:49:00 --> Helper loaded: form_helper
INFO - 2025-05-28 13:49:00 --> Database Driver Class Initialized
DEBUG - 2025-05-28 13:49:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 13:49:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 13:49:00 --> Controller Class Initialized
INFO - 2025-05-28 13:49:00 --> Model "User_model" initialized
INFO - 2025-05-28 13:49:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-28 13:49:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-28 13:49:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-28 13:49:00 --> Final output sent to browser
DEBUG - 2025-05-28 13:49:00 --> Total execution time: 0.0567
INFO - 2025-05-28 14:00:03 --> Config Class Initialized
INFO - 2025-05-28 14:00:03 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:00:03 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:00:03 --> Utf8 Class Initialized
INFO - 2025-05-28 14:00:03 --> URI Class Initialized
INFO - 2025-05-28 14:00:03 --> Router Class Initialized
INFO - 2025-05-28 14:00:03 --> Output Class Initialized
INFO - 2025-05-28 14:00:03 --> Security Class Initialized
DEBUG - 2025-05-28 14:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:00:03 --> Input Class Initialized
INFO - 2025-05-28 14:00:03 --> Language Class Initialized
INFO - 2025-05-28 14:00:03 --> Loader Class Initialized
INFO - 2025-05-28 14:00:03 --> Helper loaded: url_helper
INFO - 2025-05-28 14:00:03 --> Helper loaded: form_helper
INFO - 2025-05-28 14:00:03 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:00:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:00:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:00:03 --> Controller Class Initialized
INFO - 2025-05-28 14:00:03 --> Model "User_model" initialized
INFO - 2025-05-28 14:00:03 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-28 14:00:03 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-28 14:00:03 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-28 14:00:03 --> Final output sent to browser
DEBUG - 2025-05-28 14:00:03 --> Total execution time: 0.0955
INFO - 2025-05-28 14:00:06 --> Config Class Initialized
INFO - 2025-05-28 14:00:06 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:00:06 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:00:06 --> Utf8 Class Initialized
INFO - 2025-05-28 14:00:06 --> URI Class Initialized
INFO - 2025-05-28 14:00:06 --> Router Class Initialized
INFO - 2025-05-28 14:00:06 --> Output Class Initialized
INFO - 2025-05-28 14:00:06 --> Security Class Initialized
DEBUG - 2025-05-28 14:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:00:06 --> Input Class Initialized
INFO - 2025-05-28 14:00:06 --> Language Class Initialized
INFO - 2025-05-28 14:00:06 --> Loader Class Initialized
INFO - 2025-05-28 14:00:06 --> Helper loaded: url_helper
INFO - 2025-05-28 14:00:06 --> Helper loaded: form_helper
INFO - 2025-05-28 14:00:06 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:00:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:00:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:00:06 --> Controller Class Initialized
INFO - 2025-05-28 14:00:06 --> Model "User_model" initialized
INFO - 2025-05-28 14:00:06 --> Form Validation Class Initialized
INFO - 2025-05-28 14:00:06 --> Config Class Initialized
INFO - 2025-05-28 14:00:06 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:00:06 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:00:06 --> Utf8 Class Initialized
INFO - 2025-05-28 14:00:06 --> URI Class Initialized
INFO - 2025-05-28 14:00:06 --> Router Class Initialized
INFO - 2025-05-28 14:00:06 --> Output Class Initialized
INFO - 2025-05-28 14:00:06 --> Security Class Initialized
DEBUG - 2025-05-28 14:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:00:06 --> Input Class Initialized
INFO - 2025-05-28 14:00:06 --> Language Class Initialized
INFO - 2025-05-28 14:00:06 --> Loader Class Initialized
INFO - 2025-05-28 14:00:06 --> Helper loaded: url_helper
INFO - 2025-05-28 14:00:06 --> Helper loaded: form_helper
INFO - 2025-05-28 14:00:06 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:00:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:00:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:00:06 --> Controller Class Initialized
INFO - 2025-05-28 14:00:06 --> Model "User_model" initialized
INFO - 2025-05-28 14:00:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-28 14:00:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-28 14:00:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-28 14:00:06 --> Final output sent to browser
DEBUG - 2025-05-28 14:00:06 --> Total execution time: 0.0557
INFO - 2025-05-28 14:00:12 --> Config Class Initialized
INFO - 2025-05-28 14:00:12 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:00:12 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:00:12 --> Utf8 Class Initialized
INFO - 2025-05-28 14:00:12 --> URI Class Initialized
INFO - 2025-05-28 14:00:12 --> Router Class Initialized
INFO - 2025-05-28 14:00:12 --> Output Class Initialized
INFO - 2025-05-28 14:00:12 --> Security Class Initialized
DEBUG - 2025-05-28 14:00:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:00:12 --> Input Class Initialized
INFO - 2025-05-28 14:00:12 --> Language Class Initialized
INFO - 2025-05-28 14:00:12 --> Loader Class Initialized
INFO - 2025-05-28 14:00:12 --> Helper loaded: url_helper
INFO - 2025-05-28 14:00:12 --> Helper loaded: form_helper
INFO - 2025-05-28 14:00:12 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:00:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:00:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:00:12 --> Controller Class Initialized
INFO - 2025-05-28 14:00:12 --> Model "User_model" initialized
INFO - 2025-05-28 14:00:12 --> Form Validation Class Initialized
INFO - 2025-05-28 14:00:12 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-28 14:00:12 --> Final output sent to browser
DEBUG - 2025-05-28 14:00:12 --> Total execution time: 0.0889
INFO - 2025-05-28 14:00:14 --> Config Class Initialized
INFO - 2025-05-28 14:00:14 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:00:14 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:00:14 --> Utf8 Class Initialized
INFO - 2025-05-28 14:00:14 --> URI Class Initialized
INFO - 2025-05-28 14:00:14 --> Router Class Initialized
INFO - 2025-05-28 14:00:14 --> Output Class Initialized
INFO - 2025-05-28 14:00:14 --> Security Class Initialized
DEBUG - 2025-05-28 14:00:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:00:14 --> Input Class Initialized
INFO - 2025-05-28 14:00:14 --> Language Class Initialized
INFO - 2025-05-28 14:00:14 --> Loader Class Initialized
INFO - 2025-05-28 14:00:14 --> Helper loaded: url_helper
INFO - 2025-05-28 14:00:14 --> Helper loaded: form_helper
INFO - 2025-05-28 14:00:14 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:00:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:00:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:00:14 --> Controller Class Initialized
INFO - 2025-05-28 14:00:14 --> Model "User_model" initialized
INFO - 2025-05-28 14:00:14 --> Form Validation Class Initialized
INFO - 2025-05-28 14:00:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-05-28 14:00:14 --> Config Class Initialized
INFO - 2025-05-28 14:00:14 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:00:14 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:00:14 --> Utf8 Class Initialized
INFO - 2025-05-28 14:00:14 --> URI Class Initialized
INFO - 2025-05-28 14:00:14 --> Router Class Initialized
INFO - 2025-05-28 14:00:14 --> Output Class Initialized
INFO - 2025-05-28 14:00:14 --> Security Class Initialized
DEBUG - 2025-05-28 14:00:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:00:14 --> Input Class Initialized
INFO - 2025-05-28 14:00:14 --> Language Class Initialized
INFO - 2025-05-28 14:00:14 --> Loader Class Initialized
INFO - 2025-05-28 14:00:14 --> Helper loaded: url_helper
INFO - 2025-05-28 14:00:14 --> Helper loaded: form_helper
INFO - 2025-05-28 14:00:14 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:00:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:00:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:00:14 --> Controller Class Initialized
INFO - 2025-05-28 14:00:14 --> Model "User_model" initialized
INFO - 2025-05-28 14:00:14 --> Form Validation Class Initialized
INFO - 2025-05-28 14:00:14 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-28 14:00:14 --> Final output sent to browser
DEBUG - 2025-05-28 14:00:14 --> Total execution time: 0.0552
INFO - 2025-05-28 14:00:25 --> Config Class Initialized
INFO - 2025-05-28 14:00:25 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:00:25 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:00:25 --> Utf8 Class Initialized
INFO - 2025-05-28 14:00:25 --> URI Class Initialized
INFO - 2025-05-28 14:00:25 --> Router Class Initialized
INFO - 2025-05-28 14:00:25 --> Output Class Initialized
INFO - 2025-05-28 14:00:25 --> Security Class Initialized
DEBUG - 2025-05-28 14:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:00:25 --> Input Class Initialized
INFO - 2025-05-28 14:00:25 --> Language Class Initialized
INFO - 2025-05-28 14:00:25 --> Loader Class Initialized
INFO - 2025-05-28 14:00:25 --> Helper loaded: url_helper
INFO - 2025-05-28 14:00:25 --> Helper loaded: form_helper
INFO - 2025-05-28 14:00:25 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:00:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:00:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:00:25 --> Controller Class Initialized
INFO - 2025-05-28 14:00:25 --> Model "User_model" initialized
INFO - 2025-05-28 14:00:25 --> Form Validation Class Initialized
INFO - 2025-05-28 14:00:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-05-28 14:00:25 --> Config Class Initialized
INFO - 2025-05-28 14:00:25 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:00:25 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:00:25 --> Utf8 Class Initialized
INFO - 2025-05-28 14:00:25 --> URI Class Initialized
INFO - 2025-05-28 14:00:25 --> Router Class Initialized
INFO - 2025-05-28 14:00:25 --> Output Class Initialized
INFO - 2025-05-28 14:00:25 --> Security Class Initialized
DEBUG - 2025-05-28 14:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:00:25 --> Input Class Initialized
INFO - 2025-05-28 14:00:25 --> Language Class Initialized
INFO - 2025-05-28 14:00:25 --> Loader Class Initialized
INFO - 2025-05-28 14:00:25 --> Helper loaded: url_helper
INFO - 2025-05-28 14:00:25 --> Helper loaded: form_helper
INFO - 2025-05-28 14:00:25 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:00:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:00:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:00:25 --> Controller Class Initialized
INFO - 2025-05-28 14:00:25 --> Model "User_model" initialized
INFO - 2025-05-28 14:00:25 --> Form Validation Class Initialized
INFO - 2025-05-28 14:00:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-28 14:00:25 --> Final output sent to browser
DEBUG - 2025-05-28 14:00:25 --> Total execution time: 0.0568
INFO - 2025-05-28 14:00:28 --> Config Class Initialized
INFO - 2025-05-28 14:00:28 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:00:28 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:00:28 --> Utf8 Class Initialized
INFO - 2025-05-28 14:00:28 --> URI Class Initialized
INFO - 2025-05-28 14:00:28 --> Router Class Initialized
INFO - 2025-05-28 14:00:28 --> Output Class Initialized
INFO - 2025-05-28 14:00:28 --> Security Class Initialized
DEBUG - 2025-05-28 14:00:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:00:28 --> Input Class Initialized
INFO - 2025-05-28 14:00:28 --> Language Class Initialized
INFO - 2025-05-28 14:00:28 --> Loader Class Initialized
INFO - 2025-05-28 14:00:28 --> Helper loaded: url_helper
INFO - 2025-05-28 14:00:28 --> Helper loaded: form_helper
INFO - 2025-05-28 14:00:28 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:00:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:00:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:00:28 --> Controller Class Initialized
INFO - 2025-05-28 14:00:28 --> Model "User_model" initialized
INFO - 2025-05-28 14:00:28 --> Form Validation Class Initialized
DEBUG - 2025-05-28 14:00:28 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-05-28 14:00:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/register.php
INFO - 2025-05-28 14:00:28 --> Final output sent to browser
DEBUG - 2025-05-28 14:00:28 --> Total execution time: 0.0623
INFO - 2025-05-28 14:00:29 --> Config Class Initialized
INFO - 2025-05-28 14:00:29 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:00:29 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:00:29 --> Utf8 Class Initialized
INFO - 2025-05-28 14:00:29 --> URI Class Initialized
INFO - 2025-05-28 14:00:29 --> Router Class Initialized
INFO - 2025-05-28 14:00:29 --> Output Class Initialized
INFO - 2025-05-28 14:00:29 --> Security Class Initialized
DEBUG - 2025-05-28 14:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:00:29 --> Input Class Initialized
INFO - 2025-05-28 14:00:29 --> Language Class Initialized
INFO - 2025-05-28 14:00:29 --> Loader Class Initialized
INFO - 2025-05-28 14:00:29 --> Helper loaded: url_helper
INFO - 2025-05-28 14:00:29 --> Helper loaded: form_helper
INFO - 2025-05-28 14:00:29 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:00:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:00:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:00:29 --> Controller Class Initialized
INFO - 2025-05-28 14:00:29 --> Model "User_model" initialized
INFO - 2025-05-28 14:00:29 --> Form Validation Class Initialized
DEBUG - 2025-05-28 14:00:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-05-28 14:00:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-05-28 14:00:29 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/register.php
INFO - 2025-05-28 14:00:29 --> Final output sent to browser
DEBUG - 2025-05-28 14:00:29 --> Total execution time: 0.0598
INFO - 2025-05-28 14:01:06 --> Config Class Initialized
INFO - 2025-05-28 14:01:06 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:01:06 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:01:06 --> Utf8 Class Initialized
INFO - 2025-05-28 14:01:06 --> URI Class Initialized
INFO - 2025-05-28 14:01:06 --> Router Class Initialized
INFO - 2025-05-28 14:01:06 --> Output Class Initialized
INFO - 2025-05-28 14:01:06 --> Security Class Initialized
DEBUG - 2025-05-28 14:01:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:01:06 --> Input Class Initialized
INFO - 2025-05-28 14:01:06 --> Language Class Initialized
INFO - 2025-05-28 14:01:06 --> Loader Class Initialized
INFO - 2025-05-28 14:01:06 --> Helper loaded: url_helper
INFO - 2025-05-28 14:01:06 --> Helper loaded: form_helper
INFO - 2025-05-28 14:01:06 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:01:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:01:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:01:06 --> Controller Class Initialized
INFO - 2025-05-28 14:01:06 --> Model "User_model" initialized
INFO - 2025-05-28 14:01:06 --> Form Validation Class Initialized
DEBUG - 2025-05-28 14:01:06 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-05-28 14:01:06 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-05-28 14:01:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/register.php
INFO - 2025-05-28 14:01:06 --> Final output sent to browser
DEBUG - 2025-05-28 14:01:06 --> Total execution time: 0.0777
INFO - 2025-05-28 14:01:16 --> Config Class Initialized
INFO - 2025-05-28 14:01:16 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:01:16 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:01:16 --> Utf8 Class Initialized
INFO - 2025-05-28 14:01:16 --> URI Class Initialized
INFO - 2025-05-28 14:01:16 --> Router Class Initialized
INFO - 2025-05-28 14:01:16 --> Output Class Initialized
INFO - 2025-05-28 14:01:16 --> Security Class Initialized
DEBUG - 2025-05-28 14:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:01:16 --> Input Class Initialized
INFO - 2025-05-28 14:01:16 --> Language Class Initialized
INFO - 2025-05-28 14:01:16 --> Loader Class Initialized
INFO - 2025-05-28 14:01:16 --> Helper loaded: url_helper
INFO - 2025-05-28 14:01:16 --> Helper loaded: form_helper
INFO - 2025-05-28 14:01:16 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:01:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:01:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:01:16 --> Controller Class Initialized
INFO - 2025-05-28 14:01:16 --> Model "User_model" initialized
INFO - 2025-05-28 14:01:16 --> Form Validation Class Initialized
DEBUG - 2025-05-28 14:01:16 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-05-28 14:01:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-05-28 14:01:17 --> Config Class Initialized
INFO - 2025-05-28 14:01:17 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:01:17 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:01:17 --> Utf8 Class Initialized
INFO - 2025-05-28 14:01:17 --> URI Class Initialized
INFO - 2025-05-28 14:01:17 --> Router Class Initialized
INFO - 2025-05-28 14:01:17 --> Output Class Initialized
INFO - 2025-05-28 14:01:17 --> Security Class Initialized
DEBUG - 2025-05-28 14:01:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:01:17 --> Input Class Initialized
INFO - 2025-05-28 14:01:17 --> Language Class Initialized
INFO - 2025-05-28 14:01:17 --> Loader Class Initialized
INFO - 2025-05-28 14:01:17 --> Helper loaded: url_helper
INFO - 2025-05-28 14:01:17 --> Helper loaded: form_helper
INFO - 2025-05-28 14:01:17 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:01:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:01:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:01:17 --> Controller Class Initialized
INFO - 2025-05-28 14:01:17 --> Model "User_model" initialized
INFO - 2025-05-28 14:01:17 --> Form Validation Class Initialized
INFO - 2025-05-28 14:01:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-28 14:01:17 --> Final output sent to browser
DEBUG - 2025-05-28 14:01:17 --> Total execution time: 0.0506
INFO - 2025-05-28 14:01:31 --> Config Class Initialized
INFO - 2025-05-28 14:01:31 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:01:31 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:01:31 --> Utf8 Class Initialized
INFO - 2025-05-28 14:01:31 --> URI Class Initialized
INFO - 2025-05-28 14:01:31 --> Router Class Initialized
INFO - 2025-05-28 14:01:31 --> Output Class Initialized
INFO - 2025-05-28 14:01:31 --> Security Class Initialized
DEBUG - 2025-05-28 14:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:01:31 --> Input Class Initialized
INFO - 2025-05-28 14:01:31 --> Language Class Initialized
INFO - 2025-05-28 14:01:31 --> Loader Class Initialized
INFO - 2025-05-28 14:01:31 --> Helper loaded: url_helper
INFO - 2025-05-28 14:01:31 --> Helper loaded: form_helper
INFO - 2025-05-28 14:01:31 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:01:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:01:31 --> Controller Class Initialized
INFO - 2025-05-28 14:01:31 --> Model "User_model" initialized
INFO - 2025-05-28 14:01:31 --> Form Validation Class Initialized
INFO - 2025-05-28 14:01:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-05-28 14:01:32 --> Config Class Initialized
INFO - 2025-05-28 14:01:32 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:01:32 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:01:32 --> Utf8 Class Initialized
INFO - 2025-05-28 14:01:32 --> URI Class Initialized
INFO - 2025-05-28 14:01:32 --> Router Class Initialized
INFO - 2025-05-28 14:01:32 --> Output Class Initialized
INFO - 2025-05-28 14:01:32 --> Security Class Initialized
DEBUG - 2025-05-28 14:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:01:32 --> Input Class Initialized
INFO - 2025-05-28 14:01:32 --> Language Class Initialized
INFO - 2025-05-28 14:01:32 --> Loader Class Initialized
INFO - 2025-05-28 14:01:32 --> Helper loaded: url_helper
INFO - 2025-05-28 14:01:32 --> Helper loaded: form_helper
INFO - 2025-05-28 14:01:32 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:01:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:01:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:01:32 --> Controller Class Initialized
INFO - 2025-05-28 14:01:32 --> Model "User_model" initialized
INFO - 2025-05-28 14:01:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-28 14:01:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-28 14:01:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-28 14:01:32 --> Final output sent to browser
DEBUG - 2025-05-28 14:01:32 --> Total execution time: 0.0674
INFO - 2025-05-28 14:07:02 --> Config Class Initialized
INFO - 2025-05-28 14:07:02 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:07:02 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:07:02 --> Utf8 Class Initialized
INFO - 2025-05-28 14:07:02 --> URI Class Initialized
INFO - 2025-05-28 14:07:02 --> Router Class Initialized
INFO - 2025-05-28 14:07:02 --> Output Class Initialized
INFO - 2025-05-28 14:07:02 --> Security Class Initialized
DEBUG - 2025-05-28 14:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:07:03 --> Input Class Initialized
INFO - 2025-05-28 14:07:03 --> Language Class Initialized
INFO - 2025-05-28 14:07:03 --> Loader Class Initialized
INFO - 2025-05-28 14:07:03 --> Helper loaded: url_helper
INFO - 2025-05-28 14:07:03 --> Helper loaded: form_helper
INFO - 2025-05-28 14:07:03 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:07:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:07:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:07:03 --> Controller Class Initialized
INFO - 2025-05-28 14:07:03 --> Model "User_model" initialized
INFO - 2025-05-28 14:07:03 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-28 14:07:03 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-28 14:07:03 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-28 14:07:03 --> Final output sent to browser
DEBUG - 2025-05-28 14:07:03 --> Total execution time: 0.0675
INFO - 2025-05-28 14:07:06 --> Config Class Initialized
INFO - 2025-05-28 14:07:06 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:07:06 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:07:06 --> Utf8 Class Initialized
INFO - 2025-05-28 14:07:06 --> URI Class Initialized
INFO - 2025-05-28 14:07:06 --> Router Class Initialized
INFO - 2025-05-28 14:07:06 --> Output Class Initialized
INFO - 2025-05-28 14:07:06 --> Security Class Initialized
DEBUG - 2025-05-28 14:07:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:07:06 --> Input Class Initialized
INFO - 2025-05-28 14:07:06 --> Language Class Initialized
INFO - 2025-05-28 14:07:06 --> Loader Class Initialized
INFO - 2025-05-28 14:07:06 --> Helper loaded: url_helper
INFO - 2025-05-28 14:07:06 --> Helper loaded: form_helper
INFO - 2025-05-28 14:07:06 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:07:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:07:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:07:06 --> Controller Class Initialized
INFO - 2025-05-28 14:07:06 --> Model "User_model" initialized
INFO - 2025-05-28 14:07:06 --> Form Validation Class Initialized
INFO - 2025-05-28 14:07:06 --> Config Class Initialized
INFO - 2025-05-28 14:07:06 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:07:06 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:07:06 --> Utf8 Class Initialized
INFO - 2025-05-28 14:07:06 --> URI Class Initialized
INFO - 2025-05-28 14:07:06 --> Router Class Initialized
INFO - 2025-05-28 14:07:06 --> Output Class Initialized
INFO - 2025-05-28 14:07:06 --> Security Class Initialized
DEBUG - 2025-05-28 14:07:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:07:06 --> Input Class Initialized
INFO - 2025-05-28 14:07:06 --> Language Class Initialized
INFO - 2025-05-28 14:07:06 --> Loader Class Initialized
INFO - 2025-05-28 14:07:06 --> Helper loaded: url_helper
INFO - 2025-05-28 14:07:06 --> Helper loaded: form_helper
INFO - 2025-05-28 14:07:06 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:07:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:07:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:07:06 --> Controller Class Initialized
INFO - 2025-05-28 14:07:06 --> Model "User_model" initialized
INFO - 2025-05-28 14:07:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-28 14:07:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-28 14:07:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-28 14:07:06 --> Final output sent to browser
DEBUG - 2025-05-28 14:07:06 --> Total execution time: 0.0777
INFO - 2025-05-28 14:07:08 --> Config Class Initialized
INFO - 2025-05-28 14:07:08 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:07:08 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:07:08 --> Utf8 Class Initialized
INFO - 2025-05-28 14:07:08 --> URI Class Initialized
INFO - 2025-05-28 14:07:08 --> Router Class Initialized
INFO - 2025-05-28 14:07:08 --> Output Class Initialized
INFO - 2025-05-28 14:07:08 --> Security Class Initialized
DEBUG - 2025-05-28 14:07:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:07:08 --> Input Class Initialized
INFO - 2025-05-28 14:07:08 --> Language Class Initialized
INFO - 2025-05-28 14:07:08 --> Loader Class Initialized
INFO - 2025-05-28 14:07:08 --> Helper loaded: url_helper
INFO - 2025-05-28 14:07:08 --> Helper loaded: form_helper
INFO - 2025-05-28 14:07:08 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:07:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:07:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:07:08 --> Controller Class Initialized
INFO - 2025-05-28 14:07:08 --> Model "User_model" initialized
INFO - 2025-05-28 14:07:08 --> Form Validation Class Initialized
INFO - 2025-05-28 14:07:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-28 14:07:08 --> Final output sent to browser
DEBUG - 2025-05-28 14:07:08 --> Total execution time: 0.0683
INFO - 2025-05-28 14:07:18 --> Config Class Initialized
INFO - 2025-05-28 14:07:18 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:07:18 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:07:18 --> Utf8 Class Initialized
INFO - 2025-05-28 14:07:18 --> URI Class Initialized
INFO - 2025-05-28 14:07:18 --> Router Class Initialized
INFO - 2025-05-28 14:07:18 --> Output Class Initialized
INFO - 2025-05-28 14:07:18 --> Security Class Initialized
DEBUG - 2025-05-28 14:07:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:07:18 --> Input Class Initialized
INFO - 2025-05-28 14:07:18 --> Language Class Initialized
INFO - 2025-05-28 14:07:18 --> Loader Class Initialized
INFO - 2025-05-28 14:07:18 --> Helper loaded: url_helper
INFO - 2025-05-28 14:07:18 --> Helper loaded: form_helper
INFO - 2025-05-28 14:07:18 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:07:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:07:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:07:18 --> Controller Class Initialized
INFO - 2025-05-28 14:07:18 --> Model "User_model" initialized
INFO - 2025-05-28 14:07:18 --> Form Validation Class Initialized
INFO - 2025-05-28 14:07:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-05-28 14:07:18 --> Config Class Initialized
INFO - 2025-05-28 14:07:18 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:07:18 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:07:18 --> Utf8 Class Initialized
INFO - 2025-05-28 14:07:18 --> URI Class Initialized
INFO - 2025-05-28 14:07:18 --> Router Class Initialized
INFO - 2025-05-28 14:07:18 --> Output Class Initialized
INFO - 2025-05-28 14:07:18 --> Security Class Initialized
DEBUG - 2025-05-28 14:07:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:07:18 --> Input Class Initialized
INFO - 2025-05-28 14:07:18 --> Language Class Initialized
INFO - 2025-05-28 14:07:18 --> Loader Class Initialized
INFO - 2025-05-28 14:07:18 --> Helper loaded: url_helper
INFO - 2025-05-28 14:07:18 --> Helper loaded: form_helper
INFO - 2025-05-28 14:07:18 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:07:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:07:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:07:18 --> Controller Class Initialized
INFO - 2025-05-28 14:07:18 --> Model "User_model" initialized
INFO - 2025-05-28 14:07:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-28 14:07:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-28 14:07:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-28 14:07:18 --> Final output sent to browser
DEBUG - 2025-05-28 14:07:18 --> Total execution time: 0.0688
INFO - 2025-05-28 14:07:43 --> Config Class Initialized
INFO - 2025-05-28 14:07:43 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:07:43 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:07:43 --> Utf8 Class Initialized
INFO - 2025-05-28 14:07:43 --> URI Class Initialized
INFO - 2025-05-28 14:07:43 --> Router Class Initialized
INFO - 2025-05-28 14:07:43 --> Output Class Initialized
INFO - 2025-05-28 14:07:43 --> Security Class Initialized
DEBUG - 2025-05-28 14:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:07:43 --> Input Class Initialized
INFO - 2025-05-28 14:07:43 --> Language Class Initialized
INFO - 2025-05-28 14:07:43 --> Loader Class Initialized
INFO - 2025-05-28 14:07:43 --> Helper loaded: url_helper
INFO - 2025-05-28 14:07:43 --> Helper loaded: form_helper
INFO - 2025-05-28 14:07:43 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:07:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:07:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:07:43 --> Controller Class Initialized
INFO - 2025-05-28 14:07:43 --> Model "User_model" initialized
INFO - 2025-05-28 14:07:43 --> Form Validation Class Initialized
INFO - 2025-05-28 14:07:43 --> Config Class Initialized
INFO - 2025-05-28 14:07:43 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:07:43 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:07:43 --> Utf8 Class Initialized
INFO - 2025-05-28 14:07:43 --> URI Class Initialized
INFO - 2025-05-28 14:07:43 --> Router Class Initialized
INFO - 2025-05-28 14:07:43 --> Output Class Initialized
INFO - 2025-05-28 14:07:43 --> Security Class Initialized
DEBUG - 2025-05-28 14:07:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:07:43 --> Input Class Initialized
INFO - 2025-05-28 14:07:43 --> Language Class Initialized
INFO - 2025-05-28 14:07:43 --> Loader Class Initialized
INFO - 2025-05-28 14:07:43 --> Helper loaded: url_helper
INFO - 2025-05-28 14:07:43 --> Helper loaded: form_helper
INFO - 2025-05-28 14:07:43 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:07:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:07:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:07:43 --> Controller Class Initialized
INFO - 2025-05-28 14:07:43 --> Model "User_model" initialized
INFO - 2025-05-28 14:07:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-28 14:07:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-28 14:07:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-28 14:07:43 --> Final output sent to browser
DEBUG - 2025-05-28 14:07:43 --> Total execution time: 0.0748
INFO - 2025-05-28 14:07:45 --> Config Class Initialized
INFO - 2025-05-28 14:07:45 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:07:45 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:07:45 --> Utf8 Class Initialized
INFO - 2025-05-28 14:07:45 --> URI Class Initialized
INFO - 2025-05-28 14:07:45 --> Router Class Initialized
INFO - 2025-05-28 14:07:45 --> Output Class Initialized
INFO - 2025-05-28 14:07:45 --> Security Class Initialized
DEBUG - 2025-05-28 14:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:07:45 --> Input Class Initialized
INFO - 2025-05-28 14:07:45 --> Language Class Initialized
INFO - 2025-05-28 14:07:45 --> Loader Class Initialized
INFO - 2025-05-28 14:07:45 --> Helper loaded: url_helper
INFO - 2025-05-28 14:07:45 --> Helper loaded: form_helper
INFO - 2025-05-28 14:07:45 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:07:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:07:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:07:45 --> Controller Class Initialized
INFO - 2025-05-28 14:07:45 --> Model "User_model" initialized
INFO - 2025-05-28 14:07:45 --> Form Validation Class Initialized
INFO - 2025-05-28 14:07:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-28 14:07:45 --> Final output sent to browser
DEBUG - 2025-05-28 14:07:45 --> Total execution time: 0.0589
INFO - 2025-05-28 14:07:51 --> Config Class Initialized
INFO - 2025-05-28 14:07:51 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:07:51 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:07:51 --> Utf8 Class Initialized
INFO - 2025-05-28 14:07:51 --> URI Class Initialized
INFO - 2025-05-28 14:07:51 --> Router Class Initialized
INFO - 2025-05-28 14:07:51 --> Output Class Initialized
INFO - 2025-05-28 14:07:51 --> Security Class Initialized
DEBUG - 2025-05-28 14:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:07:51 --> Input Class Initialized
INFO - 2025-05-28 14:07:51 --> Language Class Initialized
INFO - 2025-05-28 14:07:51 --> Loader Class Initialized
INFO - 2025-05-28 14:07:51 --> Helper loaded: url_helper
INFO - 2025-05-28 14:07:51 --> Helper loaded: form_helper
INFO - 2025-05-28 14:07:51 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:07:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:07:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:07:51 --> Controller Class Initialized
INFO - 2025-05-28 14:07:51 --> Model "User_model" initialized
INFO - 2025-05-28 14:07:51 --> Form Validation Class Initialized
INFO - 2025-05-28 14:07:51 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-05-28 14:07:51 --> Config Class Initialized
INFO - 2025-05-28 14:07:51 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:07:51 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:07:51 --> Utf8 Class Initialized
INFO - 2025-05-28 14:07:51 --> URI Class Initialized
INFO - 2025-05-28 14:07:51 --> Router Class Initialized
INFO - 2025-05-28 14:07:51 --> Output Class Initialized
INFO - 2025-05-28 14:07:51 --> Security Class Initialized
DEBUG - 2025-05-28 14:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:07:51 --> Input Class Initialized
INFO - 2025-05-28 14:07:51 --> Language Class Initialized
INFO - 2025-05-28 14:07:51 --> Loader Class Initialized
INFO - 2025-05-28 14:07:51 --> Helper loaded: url_helper
INFO - 2025-05-28 14:07:51 --> Helper loaded: form_helper
INFO - 2025-05-28 14:07:51 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:07:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:07:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:07:51 --> Controller Class Initialized
INFO - 2025-05-28 14:07:51 --> Model "User_model" initialized
INFO - 2025-05-28 14:07:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-28 14:07:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-28 14:07:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-28 14:07:51 --> Final output sent to browser
DEBUG - 2025-05-28 14:07:51 --> Total execution time: 0.0717
INFO - 2025-05-28 14:09:31 --> Config Class Initialized
INFO - 2025-05-28 14:09:31 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:09:31 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:09:31 --> Utf8 Class Initialized
INFO - 2025-05-28 14:09:31 --> URI Class Initialized
INFO - 2025-05-28 14:09:31 --> Router Class Initialized
INFO - 2025-05-28 14:09:31 --> Output Class Initialized
INFO - 2025-05-28 14:09:31 --> Security Class Initialized
DEBUG - 2025-05-28 14:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:09:31 --> Input Class Initialized
INFO - 2025-05-28 14:09:31 --> Language Class Initialized
INFO - 2025-05-28 14:09:31 --> Loader Class Initialized
INFO - 2025-05-28 14:09:31 --> Helper loaded: url_helper
INFO - 2025-05-28 14:09:31 --> Helper loaded: form_helper
INFO - 2025-05-28 14:09:31 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:09:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:09:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:09:31 --> Controller Class Initialized
INFO - 2025-05-28 14:09:31 --> Model "User_model" initialized
INFO - 2025-05-28 14:09:31 --> Form Validation Class Initialized
INFO - 2025-05-28 14:09:31 --> Config Class Initialized
INFO - 2025-05-28 14:09:31 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:09:31 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:09:31 --> Utf8 Class Initialized
INFO - 2025-05-28 14:09:31 --> URI Class Initialized
INFO - 2025-05-28 14:09:31 --> Router Class Initialized
INFO - 2025-05-28 14:09:31 --> Output Class Initialized
INFO - 2025-05-28 14:09:31 --> Security Class Initialized
DEBUG - 2025-05-28 14:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:09:31 --> Input Class Initialized
INFO - 2025-05-28 14:09:31 --> Language Class Initialized
INFO - 2025-05-28 14:09:31 --> Loader Class Initialized
INFO - 2025-05-28 14:09:31 --> Helper loaded: url_helper
INFO - 2025-05-28 14:09:31 --> Helper loaded: form_helper
INFO - 2025-05-28 14:09:31 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:09:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:09:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:09:31 --> Controller Class Initialized
INFO - 2025-05-28 14:09:31 --> Model "User_model" initialized
INFO - 2025-05-28 14:09:31 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-28 14:09:31 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-28 14:09:31 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-28 14:09:31 --> Final output sent to browser
DEBUG - 2025-05-28 14:09:31 --> Total execution time: 0.0560
INFO - 2025-05-28 14:09:36 --> Config Class Initialized
INFO - 2025-05-28 14:09:36 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:09:36 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:09:36 --> Utf8 Class Initialized
INFO - 2025-05-28 14:09:36 --> URI Class Initialized
INFO - 2025-05-28 14:09:36 --> Router Class Initialized
INFO - 2025-05-28 14:09:36 --> Output Class Initialized
INFO - 2025-05-28 14:09:36 --> Security Class Initialized
DEBUG - 2025-05-28 14:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:09:36 --> Input Class Initialized
INFO - 2025-05-28 14:09:36 --> Language Class Initialized
INFO - 2025-05-28 14:09:36 --> Loader Class Initialized
INFO - 2025-05-28 14:09:36 --> Helper loaded: url_helper
INFO - 2025-05-28 14:09:36 --> Helper loaded: form_helper
INFO - 2025-05-28 14:09:36 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:09:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:09:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:09:36 --> Controller Class Initialized
INFO - 2025-05-28 14:09:36 --> Model "User_model" initialized
INFO - 2025-05-28 14:09:36 --> Form Validation Class Initialized
INFO - 2025-05-28 14:09:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-28 14:09:36 --> Final output sent to browser
DEBUG - 2025-05-28 14:09:36 --> Total execution time: 0.0835
INFO - 2025-05-28 14:09:42 --> Config Class Initialized
INFO - 2025-05-28 14:09:42 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:09:42 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:09:43 --> Utf8 Class Initialized
INFO - 2025-05-28 14:09:43 --> URI Class Initialized
INFO - 2025-05-28 14:09:43 --> Router Class Initialized
INFO - 2025-05-28 14:09:43 --> Output Class Initialized
INFO - 2025-05-28 14:09:43 --> Security Class Initialized
DEBUG - 2025-05-28 14:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:09:43 --> Input Class Initialized
INFO - 2025-05-28 14:09:43 --> Language Class Initialized
INFO - 2025-05-28 14:09:43 --> Loader Class Initialized
INFO - 2025-05-28 14:09:43 --> Helper loaded: url_helper
INFO - 2025-05-28 14:09:43 --> Helper loaded: form_helper
INFO - 2025-05-28 14:09:43 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:09:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:09:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:09:43 --> Controller Class Initialized
INFO - 2025-05-28 14:09:43 --> Model "User_model" initialized
INFO - 2025-05-28 14:09:43 --> Form Validation Class Initialized
INFO - 2025-05-28 14:09:43 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-05-28 14:09:43 --> Config Class Initialized
INFO - 2025-05-28 14:09:43 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:09:43 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:09:43 --> Utf8 Class Initialized
INFO - 2025-05-28 14:09:43 --> URI Class Initialized
INFO - 2025-05-28 14:09:43 --> Router Class Initialized
INFO - 2025-05-28 14:09:43 --> Output Class Initialized
INFO - 2025-05-28 14:09:43 --> Security Class Initialized
DEBUG - 2025-05-28 14:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:09:43 --> Input Class Initialized
INFO - 2025-05-28 14:09:43 --> Language Class Initialized
INFO - 2025-05-28 14:09:43 --> Loader Class Initialized
INFO - 2025-05-28 14:09:43 --> Helper loaded: url_helper
INFO - 2025-05-28 14:09:43 --> Helper loaded: form_helper
INFO - 2025-05-28 14:09:43 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:09:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:09:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:09:43 --> Controller Class Initialized
INFO - 2025-05-28 14:09:43 --> Model "User_model" initialized
INFO - 2025-05-28 14:09:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-28 14:09:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-28 14:09:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-28 14:09:43 --> Final output sent to browser
DEBUG - 2025-05-28 14:09:43 --> Total execution time: 0.0737
INFO - 2025-05-28 14:19:23 --> Config Class Initialized
INFO - 2025-05-28 14:19:23 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:19:23 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:19:23 --> Utf8 Class Initialized
INFO - 2025-05-28 14:19:23 --> URI Class Initialized
INFO - 2025-05-28 14:19:23 --> Router Class Initialized
INFO - 2025-05-28 14:19:23 --> Output Class Initialized
INFO - 2025-05-28 14:19:23 --> Security Class Initialized
DEBUG - 2025-05-28 14:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:19:23 --> Input Class Initialized
INFO - 2025-05-28 14:19:23 --> Language Class Initialized
INFO - 2025-05-28 14:19:23 --> Loader Class Initialized
INFO - 2025-05-28 14:19:23 --> Helper loaded: url_helper
INFO - 2025-05-28 14:19:23 --> Helper loaded: form_helper
INFO - 2025-05-28 14:19:23 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:19:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:19:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:19:23 --> Controller Class Initialized
INFO - 2025-05-28 14:19:23 --> Model "User_model" initialized
INFO - 2025-05-28 14:19:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-28 14:19:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-28 14:19:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-28 14:19:23 --> Final output sent to browser
DEBUG - 2025-05-28 14:19:23 --> Total execution time: 0.0801
INFO - 2025-05-28 14:19:26 --> Config Class Initialized
INFO - 2025-05-28 14:19:26 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:19:26 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:19:26 --> Utf8 Class Initialized
INFO - 2025-05-28 14:19:26 --> URI Class Initialized
INFO - 2025-05-28 14:19:26 --> Router Class Initialized
INFO - 2025-05-28 14:19:26 --> Output Class Initialized
INFO - 2025-05-28 14:19:26 --> Security Class Initialized
DEBUG - 2025-05-28 14:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:19:26 --> Input Class Initialized
INFO - 2025-05-28 14:19:26 --> Language Class Initialized
INFO - 2025-05-28 14:19:26 --> Loader Class Initialized
INFO - 2025-05-28 14:19:26 --> Helper loaded: url_helper
INFO - 2025-05-28 14:19:26 --> Helper loaded: form_helper
INFO - 2025-05-28 14:19:26 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:19:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:19:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:19:26 --> Controller Class Initialized
INFO - 2025-05-28 14:19:26 --> Model "User_model" initialized
INFO - 2025-05-28 14:19:26 --> Form Validation Class Initialized
INFO - 2025-05-28 14:19:26 --> Config Class Initialized
INFO - 2025-05-28 14:19:26 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:19:26 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:19:26 --> Utf8 Class Initialized
INFO - 2025-05-28 14:19:26 --> URI Class Initialized
INFO - 2025-05-28 14:19:26 --> Router Class Initialized
INFO - 2025-05-28 14:19:26 --> Output Class Initialized
INFO - 2025-05-28 14:19:26 --> Security Class Initialized
DEBUG - 2025-05-28 14:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:19:26 --> Input Class Initialized
INFO - 2025-05-28 14:19:26 --> Language Class Initialized
INFO - 2025-05-28 14:19:26 --> Loader Class Initialized
INFO - 2025-05-28 14:19:26 --> Helper loaded: url_helper
INFO - 2025-05-28 14:19:26 --> Helper loaded: form_helper
INFO - 2025-05-28 14:19:26 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:19:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:19:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:19:26 --> Controller Class Initialized
INFO - 2025-05-28 14:19:26 --> Model "User_model" initialized
INFO - 2025-05-28 14:19:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-28 14:19:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-28 14:19:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-28 14:19:26 --> Final output sent to browser
DEBUG - 2025-05-28 14:19:26 --> Total execution time: 0.0565
INFO - 2025-05-28 14:19:28 --> Config Class Initialized
INFO - 2025-05-28 14:19:28 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:19:28 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:19:28 --> Utf8 Class Initialized
INFO - 2025-05-28 14:19:28 --> URI Class Initialized
INFO - 2025-05-28 14:19:28 --> Router Class Initialized
INFO - 2025-05-28 14:19:28 --> Output Class Initialized
INFO - 2025-05-28 14:19:28 --> Security Class Initialized
DEBUG - 2025-05-28 14:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:19:28 --> Input Class Initialized
INFO - 2025-05-28 14:19:28 --> Language Class Initialized
INFO - 2025-05-28 14:19:28 --> Loader Class Initialized
INFO - 2025-05-28 14:19:28 --> Helper loaded: url_helper
INFO - 2025-05-28 14:19:28 --> Helper loaded: form_helper
INFO - 2025-05-28 14:19:28 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:19:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:19:28 --> Controller Class Initialized
INFO - 2025-05-28 14:19:28 --> Model "User_model" initialized
INFO - 2025-05-28 14:19:28 --> Form Validation Class Initialized
INFO - 2025-05-28 14:19:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-28 14:19:28 --> Final output sent to browser
DEBUG - 2025-05-28 14:19:28 --> Total execution time: 0.0591
INFO - 2025-05-28 14:19:33 --> Config Class Initialized
INFO - 2025-05-28 14:19:33 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:19:33 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:19:33 --> Utf8 Class Initialized
INFO - 2025-05-28 14:19:33 --> URI Class Initialized
INFO - 2025-05-28 14:19:33 --> Router Class Initialized
INFO - 2025-05-28 14:19:33 --> Output Class Initialized
INFO - 2025-05-28 14:19:33 --> Security Class Initialized
DEBUG - 2025-05-28 14:19:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:19:33 --> Input Class Initialized
INFO - 2025-05-28 14:19:33 --> Language Class Initialized
INFO - 2025-05-28 14:19:33 --> Loader Class Initialized
INFO - 2025-05-28 14:19:33 --> Helper loaded: url_helper
INFO - 2025-05-28 14:19:33 --> Helper loaded: form_helper
INFO - 2025-05-28 14:19:33 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:19:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:19:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:19:33 --> Controller Class Initialized
INFO - 2025-05-28 14:19:33 --> Model "User_model" initialized
INFO - 2025-05-28 14:19:33 --> Form Validation Class Initialized
INFO - 2025-05-28 14:19:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-05-28 14:19:33 --> Config Class Initialized
INFO - 2025-05-28 14:19:33 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:19:33 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:19:33 --> Utf8 Class Initialized
INFO - 2025-05-28 14:19:33 --> URI Class Initialized
INFO - 2025-05-28 14:19:33 --> Router Class Initialized
INFO - 2025-05-28 14:19:33 --> Output Class Initialized
INFO - 2025-05-28 14:19:33 --> Security Class Initialized
DEBUG - 2025-05-28 14:19:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:19:33 --> Input Class Initialized
INFO - 2025-05-28 14:19:33 --> Language Class Initialized
INFO - 2025-05-28 14:19:33 --> Loader Class Initialized
INFO - 2025-05-28 14:19:33 --> Helper loaded: url_helper
INFO - 2025-05-28 14:19:33 --> Helper loaded: form_helper
INFO - 2025-05-28 14:19:33 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:19:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:19:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:19:33 --> Controller Class Initialized
INFO - 2025-05-28 14:19:33 --> Model "User_model" initialized
INFO - 2025-05-28 14:19:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-28 14:19:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-28 14:19:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-28 14:19:33 --> Final output sent to browser
DEBUG - 2025-05-28 14:19:33 --> Total execution time: 0.0692
INFO - 2025-05-28 14:22:14 --> Config Class Initialized
INFO - 2025-05-28 14:22:14 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:22:14 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:22:14 --> Utf8 Class Initialized
INFO - 2025-05-28 14:22:14 --> URI Class Initialized
INFO - 2025-05-28 14:22:14 --> Router Class Initialized
INFO - 2025-05-28 14:22:14 --> Output Class Initialized
INFO - 2025-05-28 14:22:14 --> Security Class Initialized
DEBUG - 2025-05-28 14:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:22:14 --> Input Class Initialized
INFO - 2025-05-28 14:22:14 --> Language Class Initialized
INFO - 2025-05-28 14:22:14 --> Loader Class Initialized
INFO - 2025-05-28 14:22:14 --> Helper loaded: url_helper
INFO - 2025-05-28 14:22:14 --> Helper loaded: form_helper
INFO - 2025-05-28 14:22:14 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:22:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:22:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:22:14 --> Controller Class Initialized
INFO - 2025-05-28 14:22:14 --> Model "User_model" initialized
INFO - 2025-05-28 14:22:14 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-28 14:22:14 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-28 14:22:14 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-28 14:22:14 --> Final output sent to browser
DEBUG - 2025-05-28 14:22:14 --> Total execution time: 0.0645
INFO - 2025-05-28 14:22:16 --> Config Class Initialized
INFO - 2025-05-28 14:22:16 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:22:16 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:22:16 --> Utf8 Class Initialized
INFO - 2025-05-28 14:22:16 --> URI Class Initialized
INFO - 2025-05-28 14:22:16 --> Router Class Initialized
INFO - 2025-05-28 14:22:16 --> Output Class Initialized
INFO - 2025-05-28 14:22:16 --> Security Class Initialized
DEBUG - 2025-05-28 14:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:22:16 --> Input Class Initialized
INFO - 2025-05-28 14:22:16 --> Language Class Initialized
INFO - 2025-05-28 14:22:16 --> Loader Class Initialized
INFO - 2025-05-28 14:22:16 --> Helper loaded: url_helper
INFO - 2025-05-28 14:22:16 --> Helper loaded: form_helper
INFO - 2025-05-28 14:22:16 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:22:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:22:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:22:16 --> Controller Class Initialized
INFO - 2025-05-28 14:22:16 --> Model "User_model" initialized
INFO - 2025-05-28 14:22:16 --> Form Validation Class Initialized
INFO - 2025-05-28 14:22:16 --> Config Class Initialized
INFO - 2025-05-28 14:22:16 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:22:16 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:22:16 --> Utf8 Class Initialized
INFO - 2025-05-28 14:22:16 --> URI Class Initialized
INFO - 2025-05-28 14:22:16 --> Router Class Initialized
INFO - 2025-05-28 14:22:16 --> Output Class Initialized
INFO - 2025-05-28 14:22:16 --> Security Class Initialized
DEBUG - 2025-05-28 14:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:22:16 --> Input Class Initialized
INFO - 2025-05-28 14:22:16 --> Language Class Initialized
INFO - 2025-05-28 14:22:16 --> Loader Class Initialized
INFO - 2025-05-28 14:22:16 --> Helper loaded: url_helper
INFO - 2025-05-28 14:22:16 --> Helper loaded: form_helper
INFO - 2025-05-28 14:22:16 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:22:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:22:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:22:16 --> Controller Class Initialized
INFO - 2025-05-28 14:22:16 --> Model "User_model" initialized
INFO - 2025-05-28 14:22:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-28 14:22:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-28 14:22:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-28 14:22:16 --> Final output sent to browser
DEBUG - 2025-05-28 14:22:16 --> Total execution time: 0.0758
INFO - 2025-05-28 14:22:17 --> Config Class Initialized
INFO - 2025-05-28 14:22:17 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:22:17 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:22:17 --> Utf8 Class Initialized
INFO - 2025-05-28 14:22:17 --> URI Class Initialized
INFO - 2025-05-28 14:22:17 --> Router Class Initialized
INFO - 2025-05-28 14:22:17 --> Output Class Initialized
INFO - 2025-05-28 14:22:17 --> Security Class Initialized
DEBUG - 2025-05-28 14:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:22:17 --> Input Class Initialized
INFO - 2025-05-28 14:22:17 --> Language Class Initialized
INFO - 2025-05-28 14:22:17 --> Loader Class Initialized
INFO - 2025-05-28 14:22:17 --> Helper loaded: url_helper
INFO - 2025-05-28 14:22:17 --> Helper loaded: form_helper
INFO - 2025-05-28 14:22:18 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:22:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:22:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:22:18 --> Controller Class Initialized
INFO - 2025-05-28 14:22:18 --> Model "User_model" initialized
INFO - 2025-05-28 14:22:18 --> Form Validation Class Initialized
INFO - 2025-05-28 14:22:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-28 14:22:18 --> Final output sent to browser
DEBUG - 2025-05-28 14:22:18 --> Total execution time: 0.0754
INFO - 2025-05-28 14:22:23 --> Config Class Initialized
INFO - 2025-05-28 14:22:23 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:22:23 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:22:23 --> Utf8 Class Initialized
INFO - 2025-05-28 14:22:23 --> URI Class Initialized
INFO - 2025-05-28 14:22:23 --> Router Class Initialized
INFO - 2025-05-28 14:22:23 --> Output Class Initialized
INFO - 2025-05-28 14:22:23 --> Security Class Initialized
DEBUG - 2025-05-28 14:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:22:23 --> Input Class Initialized
INFO - 2025-05-28 14:22:23 --> Language Class Initialized
INFO - 2025-05-28 14:22:23 --> Loader Class Initialized
INFO - 2025-05-28 14:22:23 --> Helper loaded: url_helper
INFO - 2025-05-28 14:22:23 --> Helper loaded: form_helper
INFO - 2025-05-28 14:22:23 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:22:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:22:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:22:23 --> Controller Class Initialized
INFO - 2025-05-28 14:22:23 --> Model "User_model" initialized
INFO - 2025-05-28 14:22:23 --> Form Validation Class Initialized
INFO - 2025-05-28 14:22:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-05-28 14:22:23 --> Config Class Initialized
INFO - 2025-05-28 14:22:23 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:22:23 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:22:23 --> Utf8 Class Initialized
INFO - 2025-05-28 14:22:23 --> URI Class Initialized
INFO - 2025-05-28 14:22:23 --> Router Class Initialized
INFO - 2025-05-28 14:22:23 --> Output Class Initialized
INFO - 2025-05-28 14:22:23 --> Security Class Initialized
DEBUG - 2025-05-28 14:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:22:23 --> Input Class Initialized
INFO - 2025-05-28 14:22:23 --> Language Class Initialized
INFO - 2025-05-28 14:22:23 --> Loader Class Initialized
INFO - 2025-05-28 14:22:23 --> Helper loaded: url_helper
INFO - 2025-05-28 14:22:23 --> Helper loaded: form_helper
INFO - 2025-05-28 14:22:23 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:22:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:22:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:22:23 --> Controller Class Initialized
INFO - 2025-05-28 14:22:23 --> Model "User_model" initialized
INFO - 2025-05-28 14:22:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-28 14:22:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-28 14:22:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-28 14:22:23 --> Final output sent to browser
DEBUG - 2025-05-28 14:22:23 --> Total execution time: 0.0688
INFO - 2025-05-28 14:23:49 --> Config Class Initialized
INFO - 2025-05-28 14:23:49 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:23:49 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:23:49 --> Utf8 Class Initialized
INFO - 2025-05-28 14:23:49 --> URI Class Initialized
INFO - 2025-05-28 14:23:49 --> Router Class Initialized
INFO - 2025-05-28 14:23:49 --> Output Class Initialized
INFO - 2025-05-28 14:23:49 --> Security Class Initialized
DEBUG - 2025-05-28 14:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:23:49 --> Input Class Initialized
INFO - 2025-05-28 14:23:49 --> Language Class Initialized
INFO - 2025-05-28 14:23:49 --> Loader Class Initialized
INFO - 2025-05-28 14:23:49 --> Helper loaded: url_helper
INFO - 2025-05-28 14:23:49 --> Helper loaded: form_helper
INFO - 2025-05-28 14:23:49 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:23:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:23:49 --> Controller Class Initialized
INFO - 2025-05-28 14:23:49 --> Model "User_model" initialized
INFO - 2025-05-28 14:23:49 --> Form Validation Class Initialized
INFO - 2025-05-28 14:23:49 --> Config Class Initialized
INFO - 2025-05-28 14:23:49 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:23:49 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:23:49 --> Utf8 Class Initialized
INFO - 2025-05-28 14:23:49 --> URI Class Initialized
INFO - 2025-05-28 14:23:49 --> Router Class Initialized
INFO - 2025-05-28 14:23:49 --> Output Class Initialized
INFO - 2025-05-28 14:23:49 --> Security Class Initialized
DEBUG - 2025-05-28 14:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:23:49 --> Input Class Initialized
INFO - 2025-05-28 14:23:49 --> Language Class Initialized
INFO - 2025-05-28 14:23:49 --> Loader Class Initialized
INFO - 2025-05-28 14:23:49 --> Helper loaded: url_helper
INFO - 2025-05-28 14:23:49 --> Helper loaded: form_helper
INFO - 2025-05-28 14:23:49 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:23:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:23:49 --> Controller Class Initialized
INFO - 2025-05-28 14:23:49 --> Model "User_model" initialized
INFO - 2025-05-28 14:23:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-28 14:23:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-28 14:23:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-28 14:23:49 --> Final output sent to browser
DEBUG - 2025-05-28 14:23:49 --> Total execution time: 0.0633
INFO - 2025-05-28 14:23:52 --> Config Class Initialized
INFO - 2025-05-28 14:23:52 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:23:52 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:23:52 --> Utf8 Class Initialized
INFO - 2025-05-28 14:23:52 --> URI Class Initialized
INFO - 2025-05-28 14:23:52 --> Router Class Initialized
INFO - 2025-05-28 14:23:52 --> Output Class Initialized
INFO - 2025-05-28 14:23:52 --> Security Class Initialized
DEBUG - 2025-05-28 14:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:23:52 --> Input Class Initialized
INFO - 2025-05-28 14:23:52 --> Language Class Initialized
INFO - 2025-05-28 14:23:52 --> Loader Class Initialized
INFO - 2025-05-28 14:23:52 --> Helper loaded: url_helper
INFO - 2025-05-28 14:23:52 --> Helper loaded: form_helper
INFO - 2025-05-28 14:23:52 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:23:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:23:52 --> Controller Class Initialized
INFO - 2025-05-28 14:23:52 --> Model "User_model" initialized
INFO - 2025-05-28 14:23:52 --> Form Validation Class Initialized
INFO - 2025-05-28 14:23:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-28 14:23:52 --> Final output sent to browser
DEBUG - 2025-05-28 14:23:52 --> Total execution time: 0.0896
INFO - 2025-05-28 14:23:58 --> Config Class Initialized
INFO - 2025-05-28 14:23:58 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:23:58 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:23:58 --> Utf8 Class Initialized
INFO - 2025-05-28 14:23:58 --> URI Class Initialized
INFO - 2025-05-28 14:23:58 --> Router Class Initialized
INFO - 2025-05-28 14:23:58 --> Output Class Initialized
INFO - 2025-05-28 14:23:58 --> Security Class Initialized
DEBUG - 2025-05-28 14:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:23:58 --> Input Class Initialized
INFO - 2025-05-28 14:23:58 --> Language Class Initialized
INFO - 2025-05-28 14:23:58 --> Loader Class Initialized
INFO - 2025-05-28 14:23:58 --> Helper loaded: url_helper
INFO - 2025-05-28 14:23:58 --> Helper loaded: form_helper
INFO - 2025-05-28 14:23:58 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:23:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:23:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:23:58 --> Controller Class Initialized
INFO - 2025-05-28 14:23:58 --> Model "User_model" initialized
INFO - 2025-05-28 14:23:58 --> Form Validation Class Initialized
INFO - 2025-05-28 14:23:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-05-28 14:23:58 --> Config Class Initialized
INFO - 2025-05-28 14:23:58 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:23:58 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:23:58 --> Utf8 Class Initialized
INFO - 2025-05-28 14:23:58 --> URI Class Initialized
INFO - 2025-05-28 14:23:58 --> Router Class Initialized
INFO - 2025-05-28 14:23:58 --> Output Class Initialized
INFO - 2025-05-28 14:23:58 --> Security Class Initialized
DEBUG - 2025-05-28 14:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:23:58 --> Input Class Initialized
INFO - 2025-05-28 14:23:58 --> Language Class Initialized
INFO - 2025-05-28 14:23:58 --> Loader Class Initialized
INFO - 2025-05-28 14:23:58 --> Helper loaded: url_helper
INFO - 2025-05-28 14:23:58 --> Helper loaded: form_helper
INFO - 2025-05-28 14:23:58 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:23:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:23:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:23:58 --> Controller Class Initialized
INFO - 2025-05-28 14:23:58 --> Model "User_model" initialized
INFO - 2025-05-28 14:23:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-28 14:23:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-28 14:23:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-28 14:23:58 --> Final output sent to browser
DEBUG - 2025-05-28 14:23:58 --> Total execution time: 0.0806
INFO - 2025-05-28 14:30:01 --> Config Class Initialized
INFO - 2025-05-28 14:30:01 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:30:01 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:30:01 --> Utf8 Class Initialized
INFO - 2025-05-28 14:30:01 --> URI Class Initialized
INFO - 2025-05-28 14:30:01 --> Router Class Initialized
INFO - 2025-05-28 14:30:01 --> Output Class Initialized
INFO - 2025-05-28 14:30:01 --> Security Class Initialized
DEBUG - 2025-05-28 14:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:30:01 --> Input Class Initialized
INFO - 2025-05-28 14:30:01 --> Language Class Initialized
INFO - 2025-05-28 14:30:01 --> Loader Class Initialized
INFO - 2025-05-28 14:30:01 --> Helper loaded: url_helper
INFO - 2025-05-28 14:30:01 --> Helper loaded: form_helper
INFO - 2025-05-28 14:30:01 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:30:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:30:01 --> Controller Class Initialized
INFO - 2025-05-28 14:30:01 --> Model "User_model" initialized
INFO - 2025-05-28 14:30:01 --> Form Validation Class Initialized
INFO - 2025-05-28 14:30:01 --> Config Class Initialized
INFO - 2025-05-28 14:30:01 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:30:01 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:30:01 --> Utf8 Class Initialized
INFO - 2025-05-28 14:30:01 --> URI Class Initialized
INFO - 2025-05-28 14:30:01 --> Router Class Initialized
INFO - 2025-05-28 14:30:01 --> Output Class Initialized
INFO - 2025-05-28 14:30:01 --> Security Class Initialized
DEBUG - 2025-05-28 14:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:30:01 --> Input Class Initialized
INFO - 2025-05-28 14:30:01 --> Language Class Initialized
INFO - 2025-05-28 14:30:01 --> Loader Class Initialized
INFO - 2025-05-28 14:30:01 --> Helper loaded: url_helper
INFO - 2025-05-28 14:30:01 --> Helper loaded: form_helper
INFO - 2025-05-28 14:30:01 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:30:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:30:01 --> Controller Class Initialized
INFO - 2025-05-28 14:30:01 --> Model "User_model" initialized
INFO - 2025-05-28 14:30:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-28 14:30:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-28 14:30:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-28 14:30:01 --> Final output sent to browser
DEBUG - 2025-05-28 14:30:01 --> Total execution time: 0.0685
INFO - 2025-05-28 14:30:03 --> Config Class Initialized
INFO - 2025-05-28 14:30:03 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:30:03 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:30:03 --> Utf8 Class Initialized
INFO - 2025-05-28 14:30:03 --> URI Class Initialized
INFO - 2025-05-28 14:30:03 --> Router Class Initialized
INFO - 2025-05-28 14:30:03 --> Output Class Initialized
INFO - 2025-05-28 14:30:03 --> Security Class Initialized
DEBUG - 2025-05-28 14:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:30:03 --> Input Class Initialized
INFO - 2025-05-28 14:30:03 --> Language Class Initialized
INFO - 2025-05-28 14:30:03 --> Loader Class Initialized
INFO - 2025-05-28 14:30:03 --> Helper loaded: url_helper
INFO - 2025-05-28 14:30:03 --> Helper loaded: form_helper
INFO - 2025-05-28 14:30:03 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:30:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:30:03 --> Controller Class Initialized
INFO - 2025-05-28 14:30:03 --> Model "User_model" initialized
INFO - 2025-05-28 14:30:03 --> Form Validation Class Initialized
INFO - 2025-05-28 14:30:03 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-28 14:30:03 --> Final output sent to browser
DEBUG - 2025-05-28 14:30:03 --> Total execution time: 0.0559
INFO - 2025-05-28 14:30:10 --> Config Class Initialized
INFO - 2025-05-28 14:30:10 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:30:10 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:30:10 --> Utf8 Class Initialized
INFO - 2025-05-28 14:30:10 --> URI Class Initialized
INFO - 2025-05-28 14:30:10 --> Router Class Initialized
INFO - 2025-05-28 14:30:10 --> Output Class Initialized
INFO - 2025-05-28 14:30:10 --> Security Class Initialized
DEBUG - 2025-05-28 14:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:30:10 --> Input Class Initialized
INFO - 2025-05-28 14:30:10 --> Language Class Initialized
INFO - 2025-05-28 14:30:10 --> Loader Class Initialized
INFO - 2025-05-28 14:30:10 --> Helper loaded: url_helper
INFO - 2025-05-28 14:30:10 --> Helper loaded: form_helper
INFO - 2025-05-28 14:30:10 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:30:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:30:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:30:10 --> Controller Class Initialized
INFO - 2025-05-28 14:30:10 --> Model "User_model" initialized
INFO - 2025-05-28 14:30:10 --> Form Validation Class Initialized
INFO - 2025-05-28 14:30:10 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-05-28 14:30:10 --> Config Class Initialized
INFO - 2025-05-28 14:30:10 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:30:10 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:30:10 --> Utf8 Class Initialized
INFO - 2025-05-28 14:30:10 --> URI Class Initialized
INFO - 2025-05-28 14:30:10 --> Router Class Initialized
INFO - 2025-05-28 14:30:10 --> Output Class Initialized
INFO - 2025-05-28 14:30:10 --> Security Class Initialized
DEBUG - 2025-05-28 14:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:30:10 --> Input Class Initialized
INFO - 2025-05-28 14:30:10 --> Language Class Initialized
INFO - 2025-05-28 14:30:10 --> Loader Class Initialized
INFO - 2025-05-28 14:30:10 --> Helper loaded: url_helper
INFO - 2025-05-28 14:30:10 --> Helper loaded: form_helper
INFO - 2025-05-28 14:30:10 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:30:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:30:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:30:10 --> Controller Class Initialized
INFO - 2025-05-28 14:30:10 --> Model "User_model" initialized
INFO - 2025-05-28 14:30:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-28 14:30:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-28 14:30:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-28 14:30:10 --> Final output sent to browser
DEBUG - 2025-05-28 14:30:10 --> Total execution time: 0.0634
INFO - 2025-05-28 14:36:24 --> Config Class Initialized
INFO - 2025-05-28 14:36:24 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:36:24 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:36:24 --> Utf8 Class Initialized
INFO - 2025-05-28 14:36:24 --> URI Class Initialized
INFO - 2025-05-28 14:36:24 --> Router Class Initialized
INFO - 2025-05-28 14:36:24 --> Output Class Initialized
INFO - 2025-05-28 14:36:24 --> Security Class Initialized
DEBUG - 2025-05-28 14:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:36:24 --> Input Class Initialized
INFO - 2025-05-28 14:36:24 --> Language Class Initialized
INFO - 2025-05-28 14:36:24 --> Loader Class Initialized
INFO - 2025-05-28 14:36:24 --> Helper loaded: url_helper
INFO - 2025-05-28 14:36:24 --> Helper loaded: form_helper
INFO - 2025-05-28 14:36:24 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:36:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:36:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:36:24 --> Controller Class Initialized
INFO - 2025-05-28 14:36:24 --> Model "User_model" initialized
INFO - 2025-05-28 14:36:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-28 14:36:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-28 14:36:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-28 14:36:24 --> Final output sent to browser
DEBUG - 2025-05-28 14:36:24 --> Total execution time: 0.0740
INFO - 2025-05-28 14:36:33 --> Config Class Initialized
INFO - 2025-05-28 14:36:33 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:36:33 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:36:33 --> Utf8 Class Initialized
INFO - 2025-05-28 14:36:33 --> URI Class Initialized
INFO - 2025-05-28 14:36:33 --> Router Class Initialized
INFO - 2025-05-28 14:36:33 --> Output Class Initialized
INFO - 2025-05-28 14:36:33 --> Security Class Initialized
DEBUG - 2025-05-28 14:36:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:36:33 --> Input Class Initialized
INFO - 2025-05-28 14:36:33 --> Language Class Initialized
INFO - 2025-05-28 14:36:33 --> Loader Class Initialized
INFO - 2025-05-28 14:36:33 --> Helper loaded: url_helper
INFO - 2025-05-28 14:36:33 --> Helper loaded: form_helper
INFO - 2025-05-28 14:36:33 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:36:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:36:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:36:33 --> Controller Class Initialized
INFO - 2025-05-28 14:36:33 --> Model "User_model" initialized
INFO - 2025-05-28 14:36:33 --> Form Validation Class Initialized
INFO - 2025-05-28 14:36:33 --> Config Class Initialized
INFO - 2025-05-28 14:36:33 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:36:33 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:36:33 --> Utf8 Class Initialized
INFO - 2025-05-28 14:36:33 --> URI Class Initialized
INFO - 2025-05-28 14:36:33 --> Router Class Initialized
INFO - 2025-05-28 14:36:33 --> Output Class Initialized
INFO - 2025-05-28 14:36:33 --> Security Class Initialized
DEBUG - 2025-05-28 14:36:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:36:33 --> Input Class Initialized
INFO - 2025-05-28 14:36:33 --> Language Class Initialized
INFO - 2025-05-28 14:36:33 --> Loader Class Initialized
INFO - 2025-05-28 14:36:33 --> Helper loaded: url_helper
INFO - 2025-05-28 14:36:33 --> Helper loaded: form_helper
INFO - 2025-05-28 14:36:33 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:36:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:36:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:36:33 --> Controller Class Initialized
INFO - 2025-05-28 14:36:33 --> Model "User_model" initialized
INFO - 2025-05-28 14:36:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-28 14:36:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-28 14:36:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-28 14:36:33 --> Final output sent to browser
DEBUG - 2025-05-28 14:36:33 --> Total execution time: 0.0679
INFO - 2025-05-28 14:36:35 --> Config Class Initialized
INFO - 2025-05-28 14:36:35 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:36:35 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:36:35 --> Utf8 Class Initialized
INFO - 2025-05-28 14:36:35 --> URI Class Initialized
INFO - 2025-05-28 14:36:35 --> Router Class Initialized
INFO - 2025-05-28 14:36:35 --> Output Class Initialized
INFO - 2025-05-28 14:36:35 --> Security Class Initialized
DEBUG - 2025-05-28 14:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:36:35 --> Input Class Initialized
INFO - 2025-05-28 14:36:35 --> Language Class Initialized
INFO - 2025-05-28 14:36:35 --> Loader Class Initialized
INFO - 2025-05-28 14:36:35 --> Helper loaded: url_helper
INFO - 2025-05-28 14:36:35 --> Helper loaded: form_helper
INFO - 2025-05-28 14:36:35 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:36:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:36:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:36:35 --> Controller Class Initialized
INFO - 2025-05-28 14:36:35 --> Model "User_model" initialized
INFO - 2025-05-28 14:36:35 --> Form Validation Class Initialized
INFO - 2025-05-28 14:36:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-28 14:36:35 --> Final output sent to browser
DEBUG - 2025-05-28 14:36:35 --> Total execution time: 0.0624
INFO - 2025-05-28 14:36:42 --> Config Class Initialized
INFO - 2025-05-28 14:36:42 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:36:42 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:36:42 --> Utf8 Class Initialized
INFO - 2025-05-28 14:36:42 --> URI Class Initialized
INFO - 2025-05-28 14:36:42 --> Router Class Initialized
INFO - 2025-05-28 14:36:42 --> Output Class Initialized
INFO - 2025-05-28 14:36:42 --> Security Class Initialized
DEBUG - 2025-05-28 14:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:36:42 --> Input Class Initialized
INFO - 2025-05-28 14:36:42 --> Language Class Initialized
INFO - 2025-05-28 14:36:42 --> Loader Class Initialized
INFO - 2025-05-28 14:36:42 --> Helper loaded: url_helper
INFO - 2025-05-28 14:36:42 --> Helper loaded: form_helper
INFO - 2025-05-28 14:36:42 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:36:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:36:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:36:42 --> Controller Class Initialized
INFO - 2025-05-28 14:36:42 --> Model "User_model" initialized
INFO - 2025-05-28 14:36:42 --> Form Validation Class Initialized
INFO - 2025-05-28 14:36:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-05-28 14:36:42 --> Config Class Initialized
INFO - 2025-05-28 14:36:42 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:36:42 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:36:42 --> Utf8 Class Initialized
INFO - 2025-05-28 14:36:42 --> URI Class Initialized
INFO - 2025-05-28 14:36:42 --> Router Class Initialized
INFO - 2025-05-28 14:36:42 --> Output Class Initialized
INFO - 2025-05-28 14:36:42 --> Security Class Initialized
DEBUG - 2025-05-28 14:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:36:42 --> Input Class Initialized
INFO - 2025-05-28 14:36:42 --> Language Class Initialized
INFO - 2025-05-28 14:36:42 --> Loader Class Initialized
INFO - 2025-05-28 14:36:42 --> Helper loaded: url_helper
INFO - 2025-05-28 14:36:42 --> Helper loaded: form_helper
INFO - 2025-05-28 14:36:42 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:36:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:36:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:36:42 --> Controller Class Initialized
INFO - 2025-05-28 14:36:42 --> Model "User_model" initialized
INFO - 2025-05-28 14:36:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-28 14:36:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-28 14:36:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-28 14:36:42 --> Final output sent to browser
DEBUG - 2025-05-28 14:36:42 --> Total execution time: 0.0580
INFO - 2025-05-28 14:38:06 --> Config Class Initialized
INFO - 2025-05-28 14:38:06 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:38:06 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:38:06 --> Utf8 Class Initialized
INFO - 2025-05-28 14:38:06 --> URI Class Initialized
INFO - 2025-05-28 14:38:06 --> Router Class Initialized
INFO - 2025-05-28 14:38:06 --> Output Class Initialized
INFO - 2025-05-28 14:38:06 --> Security Class Initialized
DEBUG - 2025-05-28 14:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:38:06 --> Input Class Initialized
INFO - 2025-05-28 14:38:06 --> Language Class Initialized
INFO - 2025-05-28 14:38:06 --> Loader Class Initialized
INFO - 2025-05-28 14:38:06 --> Helper loaded: url_helper
INFO - 2025-05-28 14:38:06 --> Helper loaded: form_helper
INFO - 2025-05-28 14:38:06 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:38:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:38:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:38:06 --> Controller Class Initialized
INFO - 2025-05-28 14:38:06 --> Model "User_model" initialized
INFO - 2025-05-28 14:38:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-28 14:38:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-28 14:38:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-28 14:38:06 --> Final output sent to browser
DEBUG - 2025-05-28 14:38:06 --> Total execution time: 0.0904
INFO - 2025-05-28 14:40:25 --> Config Class Initialized
INFO - 2025-05-28 14:40:25 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:40:25 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:40:25 --> Utf8 Class Initialized
INFO - 2025-05-28 14:40:25 --> URI Class Initialized
INFO - 2025-05-28 14:40:25 --> Router Class Initialized
INFO - 2025-05-28 14:40:25 --> Output Class Initialized
INFO - 2025-05-28 14:40:25 --> Security Class Initialized
DEBUG - 2025-05-28 14:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:40:25 --> Input Class Initialized
INFO - 2025-05-28 14:40:25 --> Language Class Initialized
INFO - 2025-05-28 14:40:25 --> Loader Class Initialized
INFO - 2025-05-28 14:40:25 --> Helper loaded: url_helper
INFO - 2025-05-28 14:40:25 --> Helper loaded: form_helper
INFO - 2025-05-28 14:40:25 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:40:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:40:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:40:25 --> Controller Class Initialized
INFO - 2025-05-28 14:40:25 --> Model "User_model" initialized
INFO - 2025-05-28 14:40:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-28 14:40:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-28 14:40:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-28 14:40:25 --> Final output sent to browser
DEBUG - 2025-05-28 14:40:25 --> Total execution time: 0.0598
INFO - 2025-05-28 14:40:42 --> Config Class Initialized
INFO - 2025-05-28 14:40:42 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:40:42 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:40:42 --> Utf8 Class Initialized
INFO - 2025-05-28 14:40:42 --> URI Class Initialized
INFO - 2025-05-28 14:40:42 --> Router Class Initialized
INFO - 2025-05-28 14:40:42 --> Output Class Initialized
INFO - 2025-05-28 14:40:42 --> Security Class Initialized
DEBUG - 2025-05-28 14:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:40:42 --> Input Class Initialized
INFO - 2025-05-28 14:40:42 --> Language Class Initialized
INFO - 2025-05-28 14:40:42 --> Loader Class Initialized
INFO - 2025-05-28 14:40:42 --> Helper loaded: url_helper
INFO - 2025-05-28 14:40:42 --> Helper loaded: form_helper
INFO - 2025-05-28 14:40:42 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:40:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:40:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:40:42 --> Controller Class Initialized
INFO - 2025-05-28 14:40:42 --> Model "User_model" initialized
INFO - 2025-05-28 14:40:42 --> Model "Progress_model" initialized
INFO - 2025-05-28 14:40:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-28 14:40:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-28 14:40:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-28 14:40:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-28 14:40:43 --> Final output sent to browser
DEBUG - 2025-05-28 14:40:43 --> Total execution time: 0.3358
INFO - 2025-05-28 14:41:59 --> Config Class Initialized
INFO - 2025-05-28 14:41:59 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:41:59 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:41:59 --> Utf8 Class Initialized
INFO - 2025-05-28 14:41:59 --> URI Class Initialized
INFO - 2025-05-28 14:41:59 --> Router Class Initialized
INFO - 2025-05-28 14:41:59 --> Output Class Initialized
INFO - 2025-05-28 14:41:59 --> Security Class Initialized
DEBUG - 2025-05-28 14:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:41:59 --> Input Class Initialized
INFO - 2025-05-28 14:41:59 --> Language Class Initialized
INFO - 2025-05-28 14:41:59 --> Loader Class Initialized
INFO - 2025-05-28 14:41:59 --> Helper loaded: url_helper
INFO - 2025-05-28 14:41:59 --> Helper loaded: form_helper
INFO - 2025-05-28 14:41:59 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:41:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:41:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:41:59 --> Controller Class Initialized
INFO - 2025-05-28 14:41:59 --> Model "User_model" initialized
INFO - 2025-05-28 14:41:59 --> Model "Progress_model" initialized
INFO - 2025-05-28 14:41:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-28 14:41:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-28 14:41:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-28 14:41:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-28 14:41:59 --> Final output sent to browser
DEBUG - 2025-05-28 14:41:59 --> Total execution time: 0.0883
INFO - 2025-05-28 14:42:42 --> Config Class Initialized
INFO - 2025-05-28 14:42:42 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:42:42 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:42:42 --> Utf8 Class Initialized
INFO - 2025-05-28 14:42:42 --> URI Class Initialized
INFO - 2025-05-28 14:42:42 --> Router Class Initialized
INFO - 2025-05-28 14:42:42 --> Output Class Initialized
INFO - 2025-05-28 14:42:42 --> Security Class Initialized
DEBUG - 2025-05-28 14:42:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:42:42 --> Input Class Initialized
INFO - 2025-05-28 14:42:42 --> Language Class Initialized
INFO - 2025-05-28 14:42:42 --> Loader Class Initialized
INFO - 2025-05-28 14:42:42 --> Helper loaded: url_helper
INFO - 2025-05-28 14:42:42 --> Helper loaded: form_helper
INFO - 2025-05-28 14:42:42 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:42:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:42:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:42:42 --> Controller Class Initialized
INFO - 2025-05-28 14:42:42 --> Model "User_model" initialized
INFO - 2025-05-28 14:42:42 --> Model "Progress_model" initialized
INFO - 2025-05-28 14:42:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-28 14:42:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-28 14:42:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-28 14:42:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-28 14:42:42 --> Final output sent to browser
DEBUG - 2025-05-28 14:42:42 --> Total execution time: 0.0730
INFO - 2025-05-28 14:42:52 --> Config Class Initialized
INFO - 2025-05-28 14:42:52 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:42:52 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:42:52 --> Utf8 Class Initialized
INFO - 2025-05-28 14:42:52 --> URI Class Initialized
INFO - 2025-05-28 14:42:52 --> Router Class Initialized
INFO - 2025-05-28 14:42:52 --> Output Class Initialized
INFO - 2025-05-28 14:42:52 --> Security Class Initialized
DEBUG - 2025-05-28 14:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:42:52 --> Input Class Initialized
INFO - 2025-05-28 14:42:52 --> Language Class Initialized
INFO - 2025-05-28 14:42:52 --> Loader Class Initialized
INFO - 2025-05-28 14:42:52 --> Helper loaded: url_helper
INFO - 2025-05-28 14:42:52 --> Helper loaded: form_helper
INFO - 2025-05-28 14:42:52 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:42:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:42:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:42:52 --> Controller Class Initialized
INFO - 2025-05-28 14:42:52 --> Model "User_model" initialized
INFO - 2025-05-28 14:42:52 --> Form Validation Class Initialized
INFO - 2025-05-28 14:42:52 --> Config Class Initialized
INFO - 2025-05-28 14:42:52 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:42:52 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:42:52 --> Utf8 Class Initialized
INFO - 2025-05-28 14:42:52 --> URI Class Initialized
INFO - 2025-05-28 14:42:52 --> Router Class Initialized
INFO - 2025-05-28 14:42:52 --> Output Class Initialized
INFO - 2025-05-28 14:42:52 --> Security Class Initialized
DEBUG - 2025-05-28 14:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:42:52 --> Input Class Initialized
INFO - 2025-05-28 14:42:52 --> Language Class Initialized
INFO - 2025-05-28 14:42:52 --> Loader Class Initialized
INFO - 2025-05-28 14:42:52 --> Helper loaded: url_helper
INFO - 2025-05-28 14:42:52 --> Helper loaded: form_helper
INFO - 2025-05-28 14:42:52 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:42:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:42:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:42:52 --> Controller Class Initialized
INFO - 2025-05-28 14:42:52 --> Model "User_model" initialized
INFO - 2025-05-28 14:42:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-28 14:42:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-28 14:42:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-28 14:42:52 --> Final output sent to browser
DEBUG - 2025-05-28 14:42:52 --> Total execution time: 0.0753
INFO - 2025-05-28 14:42:56 --> Config Class Initialized
INFO - 2025-05-28 14:42:56 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:42:56 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:42:56 --> Utf8 Class Initialized
INFO - 2025-05-28 14:42:56 --> URI Class Initialized
INFO - 2025-05-28 14:42:56 --> Router Class Initialized
INFO - 2025-05-28 14:42:56 --> Output Class Initialized
INFO - 2025-05-28 14:42:56 --> Security Class Initialized
DEBUG - 2025-05-28 14:42:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:42:56 --> Input Class Initialized
INFO - 2025-05-28 14:42:56 --> Language Class Initialized
INFO - 2025-05-28 14:42:56 --> Loader Class Initialized
INFO - 2025-05-28 14:42:56 --> Helper loaded: url_helper
INFO - 2025-05-28 14:42:56 --> Helper loaded: form_helper
INFO - 2025-05-28 14:42:56 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:42:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:42:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:42:56 --> Controller Class Initialized
INFO - 2025-05-28 14:42:56 --> Model "User_model" initialized
INFO - 2025-05-28 14:42:56 --> Form Validation Class Initialized
INFO - 2025-05-28 14:42:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-28 14:42:56 --> Final output sent to browser
DEBUG - 2025-05-28 14:42:56 --> Total execution time: 0.0684
INFO - 2025-05-28 14:43:00 --> Config Class Initialized
INFO - 2025-05-28 14:43:00 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:43:00 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:43:00 --> Utf8 Class Initialized
INFO - 2025-05-28 14:43:00 --> URI Class Initialized
INFO - 2025-05-28 14:43:00 --> Router Class Initialized
INFO - 2025-05-28 14:43:00 --> Output Class Initialized
INFO - 2025-05-28 14:43:00 --> Security Class Initialized
DEBUG - 2025-05-28 14:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:43:00 --> Input Class Initialized
INFO - 2025-05-28 14:43:00 --> Language Class Initialized
INFO - 2025-05-28 14:43:00 --> Loader Class Initialized
INFO - 2025-05-28 14:43:00 --> Helper loaded: url_helper
INFO - 2025-05-28 14:43:00 --> Helper loaded: form_helper
INFO - 2025-05-28 14:43:00 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:43:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:43:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:43:00 --> Controller Class Initialized
INFO - 2025-05-28 14:43:00 --> Model "User_model" initialized
INFO - 2025-05-28 14:43:00 --> Form Validation Class Initialized
INFO - 2025-05-28 14:43:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-05-28 14:43:00 --> Config Class Initialized
INFO - 2025-05-28 14:43:00 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:43:00 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:43:00 --> Utf8 Class Initialized
INFO - 2025-05-28 14:43:00 --> URI Class Initialized
INFO - 2025-05-28 14:43:00 --> Router Class Initialized
INFO - 2025-05-28 14:43:00 --> Output Class Initialized
INFO - 2025-05-28 14:43:00 --> Security Class Initialized
DEBUG - 2025-05-28 14:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:43:00 --> Input Class Initialized
INFO - 2025-05-28 14:43:00 --> Language Class Initialized
INFO - 2025-05-28 14:43:00 --> Loader Class Initialized
INFO - 2025-05-28 14:43:00 --> Helper loaded: url_helper
INFO - 2025-05-28 14:43:00 --> Helper loaded: form_helper
INFO - 2025-05-28 14:43:00 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:43:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:43:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:43:00 --> Controller Class Initialized
INFO - 2025-05-28 14:43:00 --> Model "User_model" initialized
INFO - 2025-05-28 14:43:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-28 14:43:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-28 14:43:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-28 14:43:00 --> Final output sent to browser
DEBUG - 2025-05-28 14:43:00 --> Total execution time: 0.0533
INFO - 2025-05-28 14:43:10 --> Config Class Initialized
INFO - 2025-05-28 14:43:10 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:43:10 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:43:10 --> Utf8 Class Initialized
INFO - 2025-05-28 14:43:10 --> URI Class Initialized
INFO - 2025-05-28 14:43:10 --> Router Class Initialized
INFO - 2025-05-28 14:43:10 --> Output Class Initialized
INFO - 2025-05-28 14:43:10 --> Security Class Initialized
DEBUG - 2025-05-28 14:43:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:43:10 --> Input Class Initialized
INFO - 2025-05-28 14:43:10 --> Language Class Initialized
INFO - 2025-05-28 14:43:10 --> Loader Class Initialized
INFO - 2025-05-28 14:43:10 --> Helper loaded: url_helper
INFO - 2025-05-28 14:43:10 --> Helper loaded: form_helper
INFO - 2025-05-28 14:43:10 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:43:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:43:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:43:10 --> Controller Class Initialized
INFO - 2025-05-28 14:43:10 --> Model "User_model" initialized
INFO - 2025-05-28 14:43:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-28 14:43:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-28 14:43:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-28 14:43:10 --> Final output sent to browser
DEBUG - 2025-05-28 14:43:10 --> Total execution time: 0.0808
INFO - 2025-05-28 14:43:23 --> Config Class Initialized
INFO - 2025-05-28 14:43:23 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:43:23 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:43:23 --> Utf8 Class Initialized
INFO - 2025-05-28 14:43:23 --> URI Class Initialized
INFO - 2025-05-28 14:43:23 --> Router Class Initialized
INFO - 2025-05-28 14:43:23 --> Output Class Initialized
INFO - 2025-05-28 14:43:23 --> Security Class Initialized
DEBUG - 2025-05-28 14:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:43:23 --> Input Class Initialized
INFO - 2025-05-28 14:43:23 --> Language Class Initialized
INFO - 2025-05-28 14:43:23 --> Loader Class Initialized
INFO - 2025-05-28 14:43:23 --> Helper loaded: url_helper
INFO - 2025-05-28 14:43:23 --> Helper loaded: form_helper
INFO - 2025-05-28 14:43:23 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:43:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:43:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:43:23 --> Controller Class Initialized
INFO - 2025-05-28 14:43:23 --> Model "User_model" initialized
INFO - 2025-05-28 14:43:23 --> Model "Progress_model" initialized
INFO - 2025-05-28 14:43:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-28 14:43:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-28 14:43:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-28 14:43:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-28 14:43:23 --> Final output sent to browser
DEBUG - 2025-05-28 14:43:23 --> Total execution time: 0.0681
INFO - 2025-05-28 14:43:36 --> Config Class Initialized
INFO - 2025-05-28 14:43:36 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:43:36 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:43:36 --> Utf8 Class Initialized
INFO - 2025-05-28 14:43:36 --> URI Class Initialized
INFO - 2025-05-28 14:43:36 --> Router Class Initialized
INFO - 2025-05-28 14:43:36 --> Output Class Initialized
INFO - 2025-05-28 14:43:36 --> Security Class Initialized
DEBUG - 2025-05-28 14:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:43:36 --> Input Class Initialized
INFO - 2025-05-28 14:43:36 --> Language Class Initialized
INFO - 2025-05-28 14:43:36 --> Loader Class Initialized
INFO - 2025-05-28 14:43:36 --> Helper loaded: url_helper
INFO - 2025-05-28 14:43:36 --> Helper loaded: form_helper
INFO - 2025-05-28 14:43:36 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:43:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:43:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:43:36 --> Controller Class Initialized
INFO - 2025-05-28 14:43:36 --> Model "User_model" initialized
INFO - 2025-05-28 14:43:36 --> Form Validation Class Initialized
INFO - 2025-05-28 14:43:36 --> Config Class Initialized
INFO - 2025-05-28 14:43:36 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:43:36 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:43:36 --> Utf8 Class Initialized
INFO - 2025-05-28 14:43:36 --> URI Class Initialized
INFO - 2025-05-28 14:43:36 --> Router Class Initialized
INFO - 2025-05-28 14:43:36 --> Output Class Initialized
INFO - 2025-05-28 14:43:36 --> Security Class Initialized
DEBUG - 2025-05-28 14:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:43:36 --> Input Class Initialized
INFO - 2025-05-28 14:43:36 --> Language Class Initialized
INFO - 2025-05-28 14:43:36 --> Loader Class Initialized
INFO - 2025-05-28 14:43:36 --> Helper loaded: url_helper
INFO - 2025-05-28 14:43:36 --> Helper loaded: form_helper
INFO - 2025-05-28 14:43:36 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:43:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:43:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:43:36 --> Controller Class Initialized
INFO - 2025-05-28 14:43:36 --> Model "User_model" initialized
INFO - 2025-05-28 14:43:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-28 14:43:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-28 14:43:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-28 14:43:36 --> Final output sent to browser
DEBUG - 2025-05-28 14:43:36 --> Total execution time: 0.0592
INFO - 2025-05-28 14:43:43 --> Config Class Initialized
INFO - 2025-05-28 14:43:43 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:43:43 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:43:43 --> Utf8 Class Initialized
INFO - 2025-05-28 14:43:43 --> URI Class Initialized
INFO - 2025-05-28 14:43:43 --> Router Class Initialized
INFO - 2025-05-28 14:43:43 --> Output Class Initialized
INFO - 2025-05-28 14:43:43 --> Security Class Initialized
DEBUG - 2025-05-28 14:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:43:43 --> Input Class Initialized
INFO - 2025-05-28 14:43:43 --> Language Class Initialized
INFO - 2025-05-28 14:43:43 --> Loader Class Initialized
INFO - 2025-05-28 14:43:43 --> Helper loaded: url_helper
INFO - 2025-05-28 14:43:43 --> Helper loaded: form_helper
INFO - 2025-05-28 14:43:43 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:43:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:43:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:43:43 --> Controller Class Initialized
INFO - 2025-05-28 14:43:43 --> Model "User_model" initialized
INFO - 2025-05-28 14:43:43 --> Form Validation Class Initialized
INFO - 2025-05-28 14:43:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-28 14:43:43 --> Final output sent to browser
DEBUG - 2025-05-28 14:43:43 --> Total execution time: 0.0776
INFO - 2025-05-28 14:43:46 --> Config Class Initialized
INFO - 2025-05-28 14:43:46 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:43:46 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:43:46 --> Utf8 Class Initialized
INFO - 2025-05-28 14:43:46 --> URI Class Initialized
INFO - 2025-05-28 14:43:46 --> Router Class Initialized
INFO - 2025-05-28 14:43:46 --> Output Class Initialized
INFO - 2025-05-28 14:43:46 --> Security Class Initialized
DEBUG - 2025-05-28 14:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:43:46 --> Input Class Initialized
INFO - 2025-05-28 14:43:46 --> Language Class Initialized
INFO - 2025-05-28 14:43:46 --> Loader Class Initialized
INFO - 2025-05-28 14:43:46 --> Helper loaded: url_helper
INFO - 2025-05-28 14:43:46 --> Helper loaded: form_helper
INFO - 2025-05-28 14:43:46 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:43:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:43:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:43:46 --> Controller Class Initialized
INFO - 2025-05-28 14:43:46 --> Model "User_model" initialized
INFO - 2025-05-28 14:43:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-28 14:43:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-28 14:43:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-28 14:43:46 --> Final output sent to browser
DEBUG - 2025-05-28 14:43:46 --> Total execution time: 0.0621
INFO - 2025-05-28 14:43:48 --> Config Class Initialized
INFO - 2025-05-28 14:43:48 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:43:48 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:43:48 --> Utf8 Class Initialized
INFO - 2025-05-28 14:43:48 --> URI Class Initialized
INFO - 2025-05-28 14:43:48 --> Router Class Initialized
INFO - 2025-05-28 14:43:48 --> Output Class Initialized
INFO - 2025-05-28 14:43:48 --> Security Class Initialized
DEBUG - 2025-05-28 14:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:43:48 --> Input Class Initialized
INFO - 2025-05-28 14:43:48 --> Language Class Initialized
INFO - 2025-05-28 14:43:48 --> Loader Class Initialized
INFO - 2025-05-28 14:43:48 --> Helper loaded: url_helper
INFO - 2025-05-28 14:43:48 --> Helper loaded: form_helper
INFO - 2025-05-28 14:43:48 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:43:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:43:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:43:48 --> Controller Class Initialized
INFO - 2025-05-28 14:43:48 --> Model "User_model" initialized
INFO - 2025-05-28 14:43:49 --> Form Validation Class Initialized
INFO - 2025-05-28 14:43:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-28 14:43:49 --> Final output sent to browser
DEBUG - 2025-05-28 14:43:49 --> Total execution time: 0.0543
INFO - 2025-05-28 14:43:56 --> Config Class Initialized
INFO - 2025-05-28 14:43:56 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:43:56 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:43:56 --> Utf8 Class Initialized
INFO - 2025-05-28 14:43:56 --> URI Class Initialized
INFO - 2025-05-28 14:43:56 --> Router Class Initialized
INFO - 2025-05-28 14:43:56 --> Output Class Initialized
INFO - 2025-05-28 14:43:56 --> Security Class Initialized
DEBUG - 2025-05-28 14:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:43:56 --> Input Class Initialized
INFO - 2025-05-28 14:43:56 --> Language Class Initialized
INFO - 2025-05-28 14:43:56 --> Loader Class Initialized
INFO - 2025-05-28 14:43:56 --> Helper loaded: url_helper
INFO - 2025-05-28 14:43:56 --> Helper loaded: form_helper
INFO - 2025-05-28 14:43:56 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:43:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:43:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:43:56 --> Controller Class Initialized
INFO - 2025-05-28 14:43:56 --> Model "User_model" initialized
INFO - 2025-05-28 14:43:56 --> Form Validation Class Initialized
INFO - 2025-05-28 14:43:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-05-28 14:43:56 --> Config Class Initialized
INFO - 2025-05-28 14:43:56 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:43:56 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:43:56 --> Utf8 Class Initialized
INFO - 2025-05-28 14:43:56 --> URI Class Initialized
INFO - 2025-05-28 14:43:56 --> Router Class Initialized
INFO - 2025-05-28 14:43:56 --> Output Class Initialized
INFO - 2025-05-28 14:43:56 --> Security Class Initialized
DEBUG - 2025-05-28 14:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:43:56 --> Input Class Initialized
INFO - 2025-05-28 14:43:56 --> Language Class Initialized
INFO - 2025-05-28 14:43:56 --> Loader Class Initialized
INFO - 2025-05-28 14:43:56 --> Helper loaded: url_helper
INFO - 2025-05-28 14:43:56 --> Helper loaded: form_helper
INFO - 2025-05-28 14:43:56 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:43:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:43:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:43:56 --> Controller Class Initialized
INFO - 2025-05-28 14:43:56 --> Model "User_model" initialized
INFO - 2025-05-28 14:43:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-28 14:43:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-28 14:43:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-28 14:43:56 --> Final output sent to browser
DEBUG - 2025-05-28 14:43:56 --> Total execution time: 0.0660
INFO - 2025-05-28 14:44:01 --> Config Class Initialized
INFO - 2025-05-28 14:44:01 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:44:01 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:44:01 --> Utf8 Class Initialized
INFO - 2025-05-28 14:44:01 --> URI Class Initialized
INFO - 2025-05-28 14:44:01 --> Router Class Initialized
INFO - 2025-05-28 14:44:01 --> Output Class Initialized
INFO - 2025-05-28 14:44:01 --> Security Class Initialized
DEBUG - 2025-05-28 14:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:44:01 --> Input Class Initialized
INFO - 2025-05-28 14:44:01 --> Language Class Initialized
INFO - 2025-05-28 14:44:01 --> Loader Class Initialized
INFO - 2025-05-28 14:44:01 --> Helper loaded: url_helper
INFO - 2025-05-28 14:44:01 --> Helper loaded: form_helper
INFO - 2025-05-28 14:44:01 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:44:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:44:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:44:01 --> Controller Class Initialized
INFO - 2025-05-28 14:44:01 --> Model "User_model" initialized
INFO - 2025-05-28 14:44:01 --> Form Validation Class Initialized
INFO - 2025-05-28 14:44:01 --> Config Class Initialized
INFO - 2025-05-28 14:44:01 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:44:01 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:44:01 --> Utf8 Class Initialized
INFO - 2025-05-28 14:44:01 --> URI Class Initialized
INFO - 2025-05-28 14:44:01 --> Router Class Initialized
INFO - 2025-05-28 14:44:01 --> Output Class Initialized
INFO - 2025-05-28 14:44:01 --> Security Class Initialized
DEBUG - 2025-05-28 14:44:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:44:01 --> Input Class Initialized
INFO - 2025-05-28 14:44:01 --> Language Class Initialized
INFO - 2025-05-28 14:44:01 --> Loader Class Initialized
INFO - 2025-05-28 14:44:01 --> Helper loaded: url_helper
INFO - 2025-05-28 14:44:01 --> Helper loaded: form_helper
INFO - 2025-05-28 14:44:01 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:44:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:44:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:44:01 --> Controller Class Initialized
INFO - 2025-05-28 14:44:01 --> Model "User_model" initialized
INFO - 2025-05-28 14:44:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-28 14:44:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-28 14:44:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-28 14:44:01 --> Final output sent to browser
DEBUG - 2025-05-28 14:44:01 --> Total execution time: 0.0544
INFO - 2025-05-28 14:46:11 --> Config Class Initialized
INFO - 2025-05-28 14:46:11 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:46:11 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:46:11 --> Utf8 Class Initialized
INFO - 2025-05-28 14:46:11 --> URI Class Initialized
INFO - 2025-05-28 14:46:11 --> Router Class Initialized
INFO - 2025-05-28 14:46:11 --> Output Class Initialized
INFO - 2025-05-28 14:46:11 --> Security Class Initialized
DEBUG - 2025-05-28 14:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:46:11 --> Input Class Initialized
INFO - 2025-05-28 14:46:11 --> Language Class Initialized
INFO - 2025-05-28 14:46:11 --> Loader Class Initialized
INFO - 2025-05-28 14:46:11 --> Helper loaded: url_helper
INFO - 2025-05-28 14:46:11 --> Helper loaded: form_helper
INFO - 2025-05-28 14:46:11 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:46:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:46:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:46:11 --> Controller Class Initialized
INFO - 2025-05-28 14:46:11 --> Model "User_model" initialized
INFO - 2025-05-28 14:46:11 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-28 14:46:11 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-28 14:46:11 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-28 14:46:11 --> Final output sent to browser
DEBUG - 2025-05-28 14:46:11 --> Total execution time: 0.0611
INFO - 2025-05-28 14:46:13 --> Config Class Initialized
INFO - 2025-05-28 14:46:13 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:46:13 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:46:13 --> Utf8 Class Initialized
INFO - 2025-05-28 14:46:13 --> URI Class Initialized
INFO - 2025-05-28 14:46:13 --> Router Class Initialized
INFO - 2025-05-28 14:46:13 --> Output Class Initialized
INFO - 2025-05-28 14:46:13 --> Security Class Initialized
DEBUG - 2025-05-28 14:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:46:13 --> Input Class Initialized
INFO - 2025-05-28 14:46:13 --> Language Class Initialized
INFO - 2025-05-28 14:46:13 --> Loader Class Initialized
INFO - 2025-05-28 14:46:13 --> Helper loaded: url_helper
INFO - 2025-05-28 14:46:13 --> Helper loaded: form_helper
INFO - 2025-05-28 14:46:13 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:46:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:46:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:46:13 --> Controller Class Initialized
INFO - 2025-05-28 14:46:13 --> Model "User_model" initialized
INFO - 2025-05-28 14:46:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-28 14:46:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-28 14:46:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-28 14:46:13 --> Final output sent to browser
DEBUG - 2025-05-28 14:46:13 --> Total execution time: 0.0836
INFO - 2025-05-28 14:46:14 --> Config Class Initialized
INFO - 2025-05-28 14:46:14 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:46:14 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:46:14 --> Utf8 Class Initialized
INFO - 2025-05-28 14:46:14 --> URI Class Initialized
INFO - 2025-05-28 14:46:14 --> Router Class Initialized
INFO - 2025-05-28 14:46:14 --> Output Class Initialized
INFO - 2025-05-28 14:46:14 --> Security Class Initialized
DEBUG - 2025-05-28 14:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:46:14 --> Input Class Initialized
INFO - 2025-05-28 14:46:14 --> Language Class Initialized
INFO - 2025-05-28 14:46:14 --> Loader Class Initialized
INFO - 2025-05-28 14:46:15 --> Helper loaded: url_helper
INFO - 2025-05-28 14:46:15 --> Helper loaded: form_helper
INFO - 2025-05-28 14:46:15 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:46:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:46:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:46:15 --> Controller Class Initialized
INFO - 2025-05-28 14:46:15 --> Model "User_model" initialized
INFO - 2025-05-28 14:46:15 --> Form Validation Class Initialized
INFO - 2025-05-28 14:46:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-28 14:46:15 --> Final output sent to browser
DEBUG - 2025-05-28 14:46:15 --> Total execution time: 0.0614
INFO - 2025-05-28 14:46:20 --> Config Class Initialized
INFO - 2025-05-28 14:46:20 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:46:20 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:46:20 --> Utf8 Class Initialized
INFO - 2025-05-28 14:46:20 --> URI Class Initialized
INFO - 2025-05-28 14:46:20 --> Router Class Initialized
INFO - 2025-05-28 14:46:20 --> Output Class Initialized
INFO - 2025-05-28 14:46:20 --> Security Class Initialized
DEBUG - 2025-05-28 14:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:46:20 --> Input Class Initialized
INFO - 2025-05-28 14:46:20 --> Language Class Initialized
INFO - 2025-05-28 14:46:20 --> Loader Class Initialized
INFO - 2025-05-28 14:46:20 --> Helper loaded: url_helper
INFO - 2025-05-28 14:46:20 --> Helper loaded: form_helper
INFO - 2025-05-28 14:46:20 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:46:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:46:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:46:20 --> Controller Class Initialized
INFO - 2025-05-28 14:46:20 --> Model "User_model" initialized
INFO - 2025-05-28 14:46:20 --> Form Validation Class Initialized
INFO - 2025-05-28 14:46:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-05-28 14:46:20 --> Config Class Initialized
INFO - 2025-05-28 14:46:20 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:46:20 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:46:20 --> Utf8 Class Initialized
INFO - 2025-05-28 14:46:20 --> URI Class Initialized
INFO - 2025-05-28 14:46:20 --> Router Class Initialized
INFO - 2025-05-28 14:46:20 --> Output Class Initialized
INFO - 2025-05-28 14:46:20 --> Security Class Initialized
DEBUG - 2025-05-28 14:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:46:20 --> Input Class Initialized
INFO - 2025-05-28 14:46:20 --> Language Class Initialized
INFO - 2025-05-28 14:46:20 --> Loader Class Initialized
INFO - 2025-05-28 14:46:20 --> Helper loaded: url_helper
INFO - 2025-05-28 14:46:20 --> Helper loaded: form_helper
INFO - 2025-05-28 14:46:20 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:46:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:46:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:46:20 --> Controller Class Initialized
INFO - 2025-05-28 14:46:20 --> Model "User_model" initialized
INFO - 2025-05-28 14:46:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-28 14:46:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-28 14:46:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-28 14:46:20 --> Final output sent to browser
DEBUG - 2025-05-28 14:46:20 --> Total execution time: 0.0552
INFO - 2025-05-28 14:46:27 --> Config Class Initialized
INFO - 2025-05-28 14:46:27 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:46:27 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:46:27 --> Utf8 Class Initialized
INFO - 2025-05-28 14:46:27 --> URI Class Initialized
INFO - 2025-05-28 14:46:27 --> Router Class Initialized
INFO - 2025-05-28 14:46:27 --> Output Class Initialized
INFO - 2025-05-28 14:46:27 --> Security Class Initialized
DEBUG - 2025-05-28 14:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:46:27 --> Input Class Initialized
INFO - 2025-05-28 14:46:27 --> Language Class Initialized
INFO - 2025-05-28 14:46:27 --> Loader Class Initialized
INFO - 2025-05-28 14:46:27 --> Helper loaded: url_helper
INFO - 2025-05-28 14:46:27 --> Helper loaded: form_helper
INFO - 2025-05-28 14:46:27 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:46:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:46:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:46:27 --> Controller Class Initialized
INFO - 2025-05-28 14:46:27 --> Model "User_model" initialized
INFO - 2025-05-28 14:46:27 --> Model "Progress_model" initialized
INFO - 2025-05-28 14:46:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-28 14:46:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-28 14:46:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-28 14:46:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-28 14:46:27 --> Final output sent to browser
DEBUG - 2025-05-28 14:46:27 --> Total execution time: 0.0915
INFO - 2025-05-28 14:46:39 --> Config Class Initialized
INFO - 2025-05-28 14:46:39 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:46:39 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:46:39 --> Utf8 Class Initialized
INFO - 2025-05-28 14:46:39 --> URI Class Initialized
INFO - 2025-05-28 14:46:39 --> Router Class Initialized
INFO - 2025-05-28 14:46:39 --> Output Class Initialized
INFO - 2025-05-28 14:46:39 --> Security Class Initialized
DEBUG - 2025-05-28 14:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:46:39 --> Input Class Initialized
INFO - 2025-05-28 14:46:39 --> Language Class Initialized
INFO - 2025-05-28 14:46:39 --> Loader Class Initialized
INFO - 2025-05-28 14:46:39 --> Helper loaded: url_helper
INFO - 2025-05-28 14:46:39 --> Helper loaded: form_helper
INFO - 2025-05-28 14:46:39 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:46:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:46:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:46:39 --> Controller Class Initialized
INFO - 2025-05-28 14:46:39 --> Model "User_model" initialized
INFO - 2025-05-28 14:46:39 --> Model "Progress_model" initialized
INFO - 2025-05-28 14:46:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-28 14:46:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-28 14:46:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-28 14:46:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-28 14:46:39 --> Final output sent to browser
DEBUG - 2025-05-28 14:46:39 --> Total execution time: 0.0918
INFO - 2025-05-28 14:47:25 --> Config Class Initialized
INFO - 2025-05-28 14:47:25 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:47:25 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:47:25 --> Utf8 Class Initialized
INFO - 2025-05-28 14:47:25 --> URI Class Initialized
INFO - 2025-05-28 14:47:25 --> Router Class Initialized
INFO - 2025-05-28 14:47:25 --> Output Class Initialized
INFO - 2025-05-28 14:47:25 --> Security Class Initialized
DEBUG - 2025-05-28 14:47:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:47:25 --> Input Class Initialized
INFO - 2025-05-28 14:47:25 --> Language Class Initialized
INFO - 2025-05-28 14:47:25 --> Loader Class Initialized
INFO - 2025-05-28 14:47:25 --> Helper loaded: url_helper
INFO - 2025-05-28 14:47:25 --> Helper loaded: form_helper
INFO - 2025-05-28 14:47:25 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:47:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:47:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:47:25 --> Controller Class Initialized
INFO - 2025-05-28 14:47:25 --> Model "User_model" initialized
INFO - 2025-05-28 14:47:25 --> Model "Progress_model" initialized
INFO - 2025-05-28 14:47:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-28 14:47:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-28 14:47:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-28 14:47:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-28 14:47:25 --> Final output sent to browser
DEBUG - 2025-05-28 14:47:25 --> Total execution time: 0.0801
INFO - 2025-05-28 14:50:46 --> Config Class Initialized
INFO - 2025-05-28 14:50:46 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:50:46 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:50:46 --> Utf8 Class Initialized
INFO - 2025-05-28 14:50:46 --> URI Class Initialized
INFO - 2025-05-28 14:50:46 --> Router Class Initialized
INFO - 2025-05-28 14:50:46 --> Output Class Initialized
INFO - 2025-05-28 14:50:46 --> Security Class Initialized
DEBUG - 2025-05-28 14:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:50:46 --> Input Class Initialized
INFO - 2025-05-28 14:50:46 --> Language Class Initialized
INFO - 2025-05-28 14:50:46 --> Loader Class Initialized
INFO - 2025-05-28 14:50:46 --> Helper loaded: url_helper
INFO - 2025-05-28 14:50:46 --> Helper loaded: form_helper
INFO - 2025-05-28 14:50:46 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:50:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:50:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:50:46 --> Controller Class Initialized
INFO - 2025-05-28 14:50:46 --> Model "User_model" initialized
INFO - 2025-05-28 14:50:46 --> Form Validation Class Initialized
INFO - 2025-05-28 14:50:46 --> Config Class Initialized
INFO - 2025-05-28 14:50:46 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:50:46 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:50:46 --> Utf8 Class Initialized
INFO - 2025-05-28 14:50:46 --> URI Class Initialized
INFO - 2025-05-28 14:50:46 --> Router Class Initialized
INFO - 2025-05-28 14:50:46 --> Output Class Initialized
INFO - 2025-05-28 14:50:46 --> Security Class Initialized
DEBUG - 2025-05-28 14:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:50:46 --> Input Class Initialized
INFO - 2025-05-28 14:50:46 --> Language Class Initialized
INFO - 2025-05-28 14:50:46 --> Loader Class Initialized
INFO - 2025-05-28 14:50:46 --> Helper loaded: url_helper
INFO - 2025-05-28 14:50:46 --> Helper loaded: form_helper
INFO - 2025-05-28 14:50:46 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:50:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:50:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:50:46 --> Controller Class Initialized
INFO - 2025-05-28 14:50:46 --> Model "User_model" initialized
INFO - 2025-05-28 14:50:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-28 14:50:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-28 14:50:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-28 14:50:46 --> Final output sent to browser
DEBUG - 2025-05-28 14:50:46 --> Total execution time: 0.0655
INFO - 2025-05-28 14:50:51 --> Config Class Initialized
INFO - 2025-05-28 14:50:51 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:50:51 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:50:51 --> Utf8 Class Initialized
INFO - 2025-05-28 14:50:51 --> URI Class Initialized
INFO - 2025-05-28 14:50:51 --> Router Class Initialized
INFO - 2025-05-28 14:50:51 --> Output Class Initialized
INFO - 2025-05-28 14:50:51 --> Security Class Initialized
DEBUG - 2025-05-28 14:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:50:51 --> Input Class Initialized
INFO - 2025-05-28 14:50:51 --> Language Class Initialized
INFO - 2025-05-28 14:50:51 --> Loader Class Initialized
INFO - 2025-05-28 14:50:51 --> Helper loaded: url_helper
INFO - 2025-05-28 14:50:51 --> Helper loaded: form_helper
INFO - 2025-05-28 14:50:51 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:50:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:50:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:50:51 --> Controller Class Initialized
INFO - 2025-05-28 14:50:51 --> Model "User_model" initialized
INFO - 2025-05-28 14:50:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-28 14:50:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-28 14:50:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-28 14:50:51 --> Final output sent to browser
DEBUG - 2025-05-28 14:50:51 --> Total execution time: 0.0686
INFO - 2025-05-28 14:50:55 --> Config Class Initialized
INFO - 2025-05-28 14:50:55 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:50:55 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:50:55 --> Utf8 Class Initialized
INFO - 2025-05-28 14:50:55 --> URI Class Initialized
INFO - 2025-05-28 14:50:55 --> Router Class Initialized
INFO - 2025-05-28 14:50:55 --> Output Class Initialized
INFO - 2025-05-28 14:50:55 --> Security Class Initialized
DEBUG - 2025-05-28 14:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:50:55 --> Input Class Initialized
INFO - 2025-05-28 14:50:55 --> Language Class Initialized
INFO - 2025-05-28 14:50:55 --> Loader Class Initialized
INFO - 2025-05-28 14:50:55 --> Helper loaded: url_helper
INFO - 2025-05-28 14:50:55 --> Helper loaded: form_helper
INFO - 2025-05-28 14:50:55 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:50:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:50:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:50:55 --> Controller Class Initialized
INFO - 2025-05-28 14:50:55 --> Model "User_model" initialized
INFO - 2025-05-28 14:50:55 --> Form Validation Class Initialized
INFO - 2025-05-28 14:50:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-28 14:50:55 --> Final output sent to browser
DEBUG - 2025-05-28 14:50:55 --> Total execution time: 0.0642
INFO - 2025-05-28 14:51:00 --> Config Class Initialized
INFO - 2025-05-28 14:51:00 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:51:00 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:51:00 --> Utf8 Class Initialized
INFO - 2025-05-28 14:51:00 --> URI Class Initialized
INFO - 2025-05-28 14:51:00 --> Router Class Initialized
INFO - 2025-05-28 14:51:00 --> Output Class Initialized
INFO - 2025-05-28 14:51:00 --> Security Class Initialized
DEBUG - 2025-05-28 14:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:51:00 --> Input Class Initialized
INFO - 2025-05-28 14:51:00 --> Language Class Initialized
INFO - 2025-05-28 14:51:00 --> Loader Class Initialized
INFO - 2025-05-28 14:51:00 --> Helper loaded: url_helper
INFO - 2025-05-28 14:51:00 --> Helper loaded: form_helper
INFO - 2025-05-28 14:51:00 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:51:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:51:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:51:00 --> Controller Class Initialized
INFO - 2025-05-28 14:51:00 --> Model "User_model" initialized
INFO - 2025-05-28 14:51:00 --> Form Validation Class Initialized
INFO - 2025-05-28 14:51:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-05-28 14:51:00 --> Config Class Initialized
INFO - 2025-05-28 14:51:00 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:51:00 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:51:00 --> Utf8 Class Initialized
INFO - 2025-05-28 14:51:00 --> URI Class Initialized
INFO - 2025-05-28 14:51:00 --> Router Class Initialized
INFO - 2025-05-28 14:51:00 --> Output Class Initialized
INFO - 2025-05-28 14:51:00 --> Security Class Initialized
DEBUG - 2025-05-28 14:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:51:00 --> Input Class Initialized
INFO - 2025-05-28 14:51:00 --> Language Class Initialized
INFO - 2025-05-28 14:51:00 --> Loader Class Initialized
INFO - 2025-05-28 14:51:00 --> Helper loaded: url_helper
INFO - 2025-05-28 14:51:00 --> Helper loaded: form_helper
INFO - 2025-05-28 14:51:00 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:51:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:51:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:51:01 --> Controller Class Initialized
INFO - 2025-05-28 14:51:01 --> Model "User_model" initialized
INFO - 2025-05-28 14:51:01 --> Form Validation Class Initialized
INFO - 2025-05-28 14:51:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-28 14:51:01 --> Final output sent to browser
DEBUG - 2025-05-28 14:51:01 --> Total execution time: 0.0666
INFO - 2025-05-28 14:51:09 --> Config Class Initialized
INFO - 2025-05-28 14:51:09 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:51:09 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:51:09 --> Utf8 Class Initialized
INFO - 2025-05-28 14:51:09 --> URI Class Initialized
INFO - 2025-05-28 14:51:09 --> Router Class Initialized
INFO - 2025-05-28 14:51:09 --> Output Class Initialized
INFO - 2025-05-28 14:51:09 --> Security Class Initialized
DEBUG - 2025-05-28 14:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:51:09 --> Input Class Initialized
INFO - 2025-05-28 14:51:09 --> Language Class Initialized
INFO - 2025-05-28 14:51:09 --> Loader Class Initialized
INFO - 2025-05-28 14:51:09 --> Helper loaded: url_helper
INFO - 2025-05-28 14:51:09 --> Helper loaded: form_helper
INFO - 2025-05-28 14:51:09 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:51:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:51:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:51:09 --> Controller Class Initialized
INFO - 2025-05-28 14:51:09 --> Model "User_model" initialized
INFO - 2025-05-28 14:51:09 --> Form Validation Class Initialized
INFO - 2025-05-28 14:51:09 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-05-28 14:51:09 --> Config Class Initialized
INFO - 2025-05-28 14:51:09 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:51:09 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:51:09 --> Utf8 Class Initialized
INFO - 2025-05-28 14:51:09 --> URI Class Initialized
INFO - 2025-05-28 14:51:09 --> Router Class Initialized
INFO - 2025-05-28 14:51:09 --> Output Class Initialized
INFO - 2025-05-28 14:51:09 --> Security Class Initialized
DEBUG - 2025-05-28 14:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:51:09 --> Input Class Initialized
INFO - 2025-05-28 14:51:09 --> Language Class Initialized
INFO - 2025-05-28 14:51:09 --> Loader Class Initialized
INFO - 2025-05-28 14:51:09 --> Helper loaded: url_helper
INFO - 2025-05-28 14:51:09 --> Helper loaded: form_helper
INFO - 2025-05-28 14:51:09 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:51:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:51:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:51:09 --> Controller Class Initialized
INFO - 2025-05-28 14:51:09 --> Model "User_model" initialized
INFO - 2025-05-28 14:51:09 --> Form Validation Class Initialized
INFO - 2025-05-28 14:51:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-28 14:51:09 --> Final output sent to browser
DEBUG - 2025-05-28 14:51:09 --> Total execution time: 0.0765
INFO - 2025-05-28 14:51:11 --> Config Class Initialized
INFO - 2025-05-28 14:51:11 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:51:11 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:51:11 --> Utf8 Class Initialized
INFO - 2025-05-28 14:51:11 --> URI Class Initialized
INFO - 2025-05-28 14:51:11 --> Router Class Initialized
INFO - 2025-05-28 14:51:11 --> Output Class Initialized
INFO - 2025-05-28 14:51:11 --> Security Class Initialized
DEBUG - 2025-05-28 14:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:51:11 --> Input Class Initialized
INFO - 2025-05-28 14:51:11 --> Language Class Initialized
INFO - 2025-05-28 14:51:11 --> Loader Class Initialized
INFO - 2025-05-28 14:51:11 --> Helper loaded: url_helper
INFO - 2025-05-28 14:51:11 --> Helper loaded: form_helper
INFO - 2025-05-28 14:51:11 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:51:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:51:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:51:11 --> Controller Class Initialized
INFO - 2025-05-28 14:51:11 --> Model "User_model" initialized
INFO - 2025-05-28 14:51:11 --> Form Validation Class Initialized
DEBUG - 2025-05-28 14:51:11 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-05-28 14:51:11 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/register.php
INFO - 2025-05-28 14:51:11 --> Final output sent to browser
DEBUG - 2025-05-28 14:51:11 --> Total execution time: 0.0583
INFO - 2025-05-28 14:51:14 --> Config Class Initialized
INFO - 2025-05-28 14:51:14 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:51:14 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:51:14 --> Utf8 Class Initialized
INFO - 2025-05-28 14:51:14 --> URI Class Initialized
INFO - 2025-05-28 14:51:14 --> Router Class Initialized
INFO - 2025-05-28 14:51:14 --> Output Class Initialized
INFO - 2025-05-28 14:51:14 --> Security Class Initialized
DEBUG - 2025-05-28 14:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:51:14 --> Input Class Initialized
INFO - 2025-05-28 14:51:14 --> Language Class Initialized
INFO - 2025-05-28 14:51:14 --> Loader Class Initialized
INFO - 2025-05-28 14:51:14 --> Helper loaded: url_helper
INFO - 2025-05-28 14:51:14 --> Helper loaded: form_helper
INFO - 2025-05-28 14:51:14 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:51:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:51:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:51:14 --> Controller Class Initialized
INFO - 2025-05-28 14:51:14 --> Model "User_model" initialized
INFO - 2025-05-28 14:51:14 --> Form Validation Class Initialized
DEBUG - 2025-05-28 14:51:14 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-05-28 14:51:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-05-28 14:51:14 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/register.php
INFO - 2025-05-28 14:51:14 --> Final output sent to browser
DEBUG - 2025-05-28 14:51:14 --> Total execution time: 0.0573
INFO - 2025-05-28 14:51:27 --> Config Class Initialized
INFO - 2025-05-28 14:51:27 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:51:27 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:51:27 --> Utf8 Class Initialized
INFO - 2025-05-28 14:51:27 --> URI Class Initialized
INFO - 2025-05-28 14:51:27 --> Router Class Initialized
INFO - 2025-05-28 14:51:27 --> Output Class Initialized
INFO - 2025-05-28 14:51:27 --> Security Class Initialized
DEBUG - 2025-05-28 14:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:51:27 --> Input Class Initialized
INFO - 2025-05-28 14:51:27 --> Language Class Initialized
INFO - 2025-05-28 14:51:27 --> Loader Class Initialized
INFO - 2025-05-28 14:51:27 --> Helper loaded: url_helper
INFO - 2025-05-28 14:51:27 --> Helper loaded: form_helper
INFO - 2025-05-28 14:51:27 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:51:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:51:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:51:27 --> Controller Class Initialized
INFO - 2025-05-28 14:51:27 --> Model "User_model" initialized
INFO - 2025-05-28 14:51:27 --> Form Validation Class Initialized
INFO - 2025-05-28 14:51:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-28 14:51:27 --> Final output sent to browser
DEBUG - 2025-05-28 14:51:27 --> Total execution time: 0.0713
INFO - 2025-05-28 14:51:30 --> Config Class Initialized
INFO - 2025-05-28 14:51:30 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:51:30 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:51:30 --> Utf8 Class Initialized
INFO - 2025-05-28 14:51:30 --> URI Class Initialized
INFO - 2025-05-28 14:51:30 --> Router Class Initialized
INFO - 2025-05-28 14:51:30 --> Output Class Initialized
INFO - 2025-05-28 14:51:30 --> Security Class Initialized
DEBUG - 2025-05-28 14:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:51:30 --> Input Class Initialized
INFO - 2025-05-28 14:51:30 --> Language Class Initialized
INFO - 2025-05-28 14:51:30 --> Loader Class Initialized
INFO - 2025-05-28 14:51:30 --> Helper loaded: url_helper
INFO - 2025-05-28 14:51:30 --> Helper loaded: form_helper
INFO - 2025-05-28 14:51:30 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:51:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:51:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:51:30 --> Controller Class Initialized
INFO - 2025-05-28 14:51:30 --> Model "User_model" initialized
INFO - 2025-05-28 14:51:30 --> Form Validation Class Initialized
INFO - 2025-05-28 14:51:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-28 14:51:30 --> Final output sent to browser
DEBUG - 2025-05-28 14:51:30 --> Total execution time: 0.0545
INFO - 2025-05-28 14:51:58 --> Config Class Initialized
INFO - 2025-05-28 14:51:58 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:51:58 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:51:58 --> Utf8 Class Initialized
INFO - 2025-05-28 14:51:58 --> URI Class Initialized
INFO - 2025-05-28 14:51:58 --> Router Class Initialized
INFO - 2025-05-28 14:51:58 --> Output Class Initialized
INFO - 2025-05-28 14:51:58 --> Security Class Initialized
DEBUG - 2025-05-28 14:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:51:58 --> Input Class Initialized
INFO - 2025-05-28 14:51:58 --> Language Class Initialized
INFO - 2025-05-28 14:51:58 --> Loader Class Initialized
INFO - 2025-05-28 14:51:58 --> Helper loaded: url_helper
INFO - 2025-05-28 14:51:58 --> Helper loaded: form_helper
INFO - 2025-05-28 14:51:58 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:51:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:51:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:51:58 --> Controller Class Initialized
INFO - 2025-05-28 14:51:58 --> Model "User_model" initialized
INFO - 2025-05-28 14:51:58 --> Form Validation Class Initialized
INFO - 2025-05-28 14:51:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-28 14:51:58 --> Final output sent to browser
DEBUG - 2025-05-28 14:51:58 --> Total execution time: 0.0791
INFO - 2025-05-28 14:52:00 --> Config Class Initialized
INFO - 2025-05-28 14:52:00 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:52:00 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:52:00 --> Utf8 Class Initialized
INFO - 2025-05-28 14:52:00 --> URI Class Initialized
INFO - 2025-05-28 14:52:00 --> Router Class Initialized
INFO - 2025-05-28 14:52:00 --> Output Class Initialized
INFO - 2025-05-28 14:52:00 --> Security Class Initialized
DEBUG - 2025-05-28 14:52:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:52:00 --> Input Class Initialized
INFO - 2025-05-28 14:52:00 --> Language Class Initialized
INFO - 2025-05-28 14:52:00 --> Loader Class Initialized
INFO - 2025-05-28 14:52:00 --> Helper loaded: url_helper
INFO - 2025-05-28 14:52:00 --> Helper loaded: form_helper
INFO - 2025-05-28 14:52:00 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:52:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:52:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:52:00 --> Controller Class Initialized
INFO - 2025-05-28 14:52:00 --> Model "User_model" initialized
INFO - 2025-05-28 14:52:00 --> Form Validation Class Initialized
DEBUG - 2025-05-28 14:52:00 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-05-28 14:52:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/register.php
INFO - 2025-05-28 14:52:00 --> Final output sent to browser
DEBUG - 2025-05-28 14:52:00 --> Total execution time: 0.0736
INFO - 2025-05-28 14:52:50 --> Config Class Initialized
INFO - 2025-05-28 14:52:50 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:52:50 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:52:50 --> Utf8 Class Initialized
INFO - 2025-05-28 14:52:50 --> URI Class Initialized
INFO - 2025-05-28 14:52:50 --> Router Class Initialized
INFO - 2025-05-28 14:52:50 --> Output Class Initialized
INFO - 2025-05-28 14:52:50 --> Security Class Initialized
DEBUG - 2025-05-28 14:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:52:50 --> Input Class Initialized
INFO - 2025-05-28 14:52:50 --> Language Class Initialized
INFO - 2025-05-28 14:52:50 --> Loader Class Initialized
INFO - 2025-05-28 14:52:50 --> Helper loaded: url_helper
INFO - 2025-05-28 14:52:50 --> Helper loaded: form_helper
INFO - 2025-05-28 14:52:50 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:52:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:52:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:52:50 --> Controller Class Initialized
INFO - 2025-05-28 14:52:50 --> Model "User_model" initialized
INFO - 2025-05-28 14:52:50 --> Form Validation Class Initialized
INFO - 2025-05-28 14:52:50 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-28 14:52:50 --> Final output sent to browser
DEBUG - 2025-05-28 14:52:50 --> Total execution time: 0.0666
INFO - 2025-05-28 14:52:56 --> Config Class Initialized
INFO - 2025-05-28 14:52:56 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:52:56 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:52:56 --> Utf8 Class Initialized
INFO - 2025-05-28 14:52:56 --> URI Class Initialized
INFO - 2025-05-28 14:52:56 --> Router Class Initialized
INFO - 2025-05-28 14:52:56 --> Output Class Initialized
INFO - 2025-05-28 14:52:56 --> Security Class Initialized
DEBUG - 2025-05-28 14:52:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:52:56 --> Input Class Initialized
INFO - 2025-05-28 14:52:56 --> Language Class Initialized
INFO - 2025-05-28 14:52:56 --> Loader Class Initialized
INFO - 2025-05-28 14:52:56 --> Helper loaded: url_helper
INFO - 2025-05-28 14:52:56 --> Helper loaded: form_helper
INFO - 2025-05-28 14:52:56 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:52:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:52:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:52:56 --> Controller Class Initialized
INFO - 2025-05-28 14:52:56 --> Model "User_model" initialized
INFO - 2025-05-28 14:52:56 --> Form Validation Class Initialized
INFO - 2025-05-28 14:52:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-05-28 14:52:57 --> Config Class Initialized
INFO - 2025-05-28 14:52:57 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:52:57 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:52:57 --> Utf8 Class Initialized
INFO - 2025-05-28 14:52:57 --> URI Class Initialized
INFO - 2025-05-28 14:52:57 --> Router Class Initialized
INFO - 2025-05-28 14:52:57 --> Output Class Initialized
INFO - 2025-05-28 14:52:57 --> Security Class Initialized
DEBUG - 2025-05-28 14:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:52:57 --> Input Class Initialized
INFO - 2025-05-28 14:52:57 --> Language Class Initialized
INFO - 2025-05-28 14:52:57 --> Loader Class Initialized
INFO - 2025-05-28 14:52:57 --> Helper loaded: url_helper
INFO - 2025-05-28 14:52:57 --> Helper loaded: form_helper
INFO - 2025-05-28 14:52:57 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:52:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:52:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:52:57 --> Controller Class Initialized
INFO - 2025-05-28 14:52:57 --> Model "User_model" initialized
INFO - 2025-05-28 14:52:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-28 14:52:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-28 14:52:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-28 14:52:57 --> Final output sent to browser
DEBUG - 2025-05-28 14:52:57 --> Total execution time: 0.0539
INFO - 2025-05-28 14:52:58 --> Config Class Initialized
INFO - 2025-05-28 14:52:58 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:52:58 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:52:58 --> Utf8 Class Initialized
INFO - 2025-05-28 14:52:58 --> URI Class Initialized
INFO - 2025-05-28 14:52:58 --> Router Class Initialized
INFO - 2025-05-28 14:52:58 --> Output Class Initialized
INFO - 2025-05-28 14:52:58 --> Security Class Initialized
DEBUG - 2025-05-28 14:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:52:58 --> Input Class Initialized
INFO - 2025-05-28 14:52:58 --> Language Class Initialized
INFO - 2025-05-28 14:52:58 --> Loader Class Initialized
INFO - 2025-05-28 14:52:58 --> Helper loaded: url_helper
INFO - 2025-05-28 14:52:58 --> Helper loaded: form_helper
INFO - 2025-05-28 14:52:59 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:52:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:52:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:52:59 --> Controller Class Initialized
INFO - 2025-05-28 14:52:59 --> Model "User_model" initialized
INFO - 2025-05-28 14:52:59 --> Model "Progress_model" initialized
INFO - 2025-05-28 14:52:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-28 14:52:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-28 14:52:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-28 14:52:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-28 14:52:59 --> Final output sent to browser
DEBUG - 2025-05-28 14:52:59 --> Total execution time: 0.0683
INFO - 2025-05-28 14:53:01 --> Config Class Initialized
INFO - 2025-05-28 14:53:01 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:53:01 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:53:01 --> Utf8 Class Initialized
INFO - 2025-05-28 14:53:01 --> URI Class Initialized
INFO - 2025-05-28 14:53:01 --> Router Class Initialized
INFO - 2025-05-28 14:53:01 --> Output Class Initialized
INFO - 2025-05-28 14:53:01 --> Security Class Initialized
DEBUG - 2025-05-28 14:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:53:01 --> Input Class Initialized
INFO - 2025-05-28 14:53:01 --> Language Class Initialized
INFO - 2025-05-28 14:53:01 --> Loader Class Initialized
INFO - 2025-05-28 14:53:01 --> Helper loaded: url_helper
INFO - 2025-05-28 14:53:01 --> Helper loaded: form_helper
INFO - 2025-05-28 14:53:01 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:53:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:53:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:53:01 --> Controller Class Initialized
INFO - 2025-05-28 14:53:01 --> Model "Progress_model" initialized
INFO - 2025-05-28 14:53:01 --> Model "Olahraga_model" initialized
INFO - 2025-05-28 14:53:01 --> Model "User_model" initialized
INFO - 2025-05-28 14:53:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-28 14:53:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-28 14:53:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-28 14:53:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-28 14:53:01 --> Final output sent to browser
DEBUG - 2025-05-28 14:53:01 --> Total execution time: 0.2155
INFO - 2025-05-28 14:53:02 --> Config Class Initialized
INFO - 2025-05-28 14:53:02 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:53:02 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:53:02 --> Utf8 Class Initialized
INFO - 2025-05-28 14:53:02 --> URI Class Initialized
INFO - 2025-05-28 14:53:02 --> Router Class Initialized
INFO - 2025-05-28 14:53:02 --> Output Class Initialized
INFO - 2025-05-28 14:53:02 --> Security Class Initialized
DEBUG - 2025-05-28 14:53:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:53:02 --> Input Class Initialized
INFO - 2025-05-28 14:53:02 --> Language Class Initialized
INFO - 2025-05-28 14:53:02 --> Loader Class Initialized
INFO - 2025-05-28 14:53:02 --> Helper loaded: url_helper
INFO - 2025-05-28 14:53:02 --> Helper loaded: form_helper
INFO - 2025-05-28 14:53:02 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:53:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:53:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:53:02 --> Controller Class Initialized
INFO - 2025-05-28 14:53:02 --> Model "Progress_model" initialized
INFO - 2025-05-28 14:53:02 --> Model "Olahraga_model" initialized
INFO - 2025-05-28 14:53:02 --> Model "User_model" initialized
INFO - 2025-05-28 14:53:02 --> Final output sent to browser
DEBUG - 2025-05-28 14:53:02 --> Total execution time: 0.0652
INFO - 2025-05-28 14:54:18 --> Config Class Initialized
INFO - 2025-05-28 14:54:18 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:54:18 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:54:18 --> Utf8 Class Initialized
INFO - 2025-05-28 14:54:18 --> URI Class Initialized
INFO - 2025-05-28 14:54:18 --> Router Class Initialized
INFO - 2025-05-28 14:54:18 --> Output Class Initialized
INFO - 2025-05-28 14:54:18 --> Security Class Initialized
DEBUG - 2025-05-28 14:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:54:18 --> Input Class Initialized
INFO - 2025-05-28 14:54:18 --> Language Class Initialized
INFO - 2025-05-28 14:54:18 --> Loader Class Initialized
INFO - 2025-05-28 14:54:18 --> Helper loaded: url_helper
INFO - 2025-05-28 14:54:18 --> Helper loaded: form_helper
INFO - 2025-05-28 14:54:18 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:54:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:54:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:54:18 --> Controller Class Initialized
INFO - 2025-05-28 14:54:18 --> Model "Progress_model" initialized
INFO - 2025-05-28 14:54:18 --> Model "Olahraga_model" initialized
INFO - 2025-05-28 14:54:18 --> Model "User_model" initialized
INFO - 2025-05-28 14:54:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-28 14:54:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-28 14:54:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-28 14:54:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-28 14:54:18 --> Final output sent to browser
DEBUG - 2025-05-28 14:54:18 --> Total execution time: 0.0660
INFO - 2025-05-28 14:54:18 --> Config Class Initialized
INFO - 2025-05-28 14:54:19 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:54:19 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:54:19 --> Utf8 Class Initialized
INFO - 2025-05-28 14:54:19 --> URI Class Initialized
INFO - 2025-05-28 14:54:19 --> Router Class Initialized
INFO - 2025-05-28 14:54:19 --> Output Class Initialized
INFO - 2025-05-28 14:54:19 --> Security Class Initialized
DEBUG - 2025-05-28 14:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:54:19 --> Input Class Initialized
INFO - 2025-05-28 14:54:19 --> Language Class Initialized
INFO - 2025-05-28 14:54:19 --> Loader Class Initialized
INFO - 2025-05-28 14:54:19 --> Helper loaded: url_helper
INFO - 2025-05-28 14:54:19 --> Helper loaded: form_helper
INFO - 2025-05-28 14:54:19 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:54:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:54:19 --> Controller Class Initialized
INFO - 2025-05-28 14:54:19 --> Model "Progress_model" initialized
INFO - 2025-05-28 14:54:19 --> Model "Olahraga_model" initialized
INFO - 2025-05-28 14:54:19 --> Model "User_model" initialized
INFO - 2025-05-28 14:54:19 --> Final output sent to browser
DEBUG - 2025-05-28 14:54:19 --> Total execution time: 0.0898
INFO - 2025-05-28 14:54:39 --> Config Class Initialized
INFO - 2025-05-28 14:54:39 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:54:39 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:54:39 --> Utf8 Class Initialized
INFO - 2025-05-28 14:54:39 --> URI Class Initialized
INFO - 2025-05-28 14:54:39 --> Router Class Initialized
INFO - 2025-05-28 14:54:39 --> Output Class Initialized
INFO - 2025-05-28 14:54:39 --> Security Class Initialized
DEBUG - 2025-05-28 14:54:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:54:39 --> Input Class Initialized
INFO - 2025-05-28 14:54:39 --> Language Class Initialized
INFO - 2025-05-28 14:54:39 --> Loader Class Initialized
INFO - 2025-05-28 14:54:39 --> Helper loaded: url_helper
INFO - 2025-05-28 14:54:39 --> Helper loaded: form_helper
INFO - 2025-05-28 14:54:39 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:54:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:54:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:54:39 --> Controller Class Initialized
INFO - 2025-05-28 14:54:39 --> Model "Progress_model" initialized
INFO - 2025-05-28 14:54:39 --> Model "Olahraga_model" initialized
INFO - 2025-05-28 14:54:39 --> Model "User_model" initialized
INFO - 2025-05-28 14:54:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-28 14:54:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-28 14:54:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-28 14:54:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-28 14:54:39 --> Final output sent to browser
DEBUG - 2025-05-28 14:54:39 --> Total execution time: 0.0778
INFO - 2025-05-28 14:54:39 --> Config Class Initialized
INFO - 2025-05-28 14:54:39 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:54:39 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:54:39 --> Utf8 Class Initialized
INFO - 2025-05-28 14:54:39 --> URI Class Initialized
INFO - 2025-05-28 14:54:39 --> Router Class Initialized
INFO - 2025-05-28 14:54:39 --> Output Class Initialized
INFO - 2025-05-28 14:54:39 --> Security Class Initialized
DEBUG - 2025-05-28 14:54:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:54:39 --> Input Class Initialized
INFO - 2025-05-28 14:54:39 --> Language Class Initialized
INFO - 2025-05-28 14:54:39 --> Loader Class Initialized
INFO - 2025-05-28 14:54:39 --> Helper loaded: url_helper
INFO - 2025-05-28 14:54:39 --> Helper loaded: form_helper
INFO - 2025-05-28 14:54:39 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:54:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:54:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:54:39 --> Controller Class Initialized
INFO - 2025-05-28 14:54:39 --> Model "Progress_model" initialized
INFO - 2025-05-28 14:54:39 --> Model "Olahraga_model" initialized
INFO - 2025-05-28 14:54:39 --> Model "User_model" initialized
INFO - 2025-05-28 14:54:39 --> Final output sent to browser
DEBUG - 2025-05-28 14:54:39 --> Total execution time: 0.0908
INFO - 2025-05-28 14:54:56 --> Config Class Initialized
INFO - 2025-05-28 14:54:56 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:54:56 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:54:56 --> Utf8 Class Initialized
INFO - 2025-05-28 14:54:56 --> URI Class Initialized
INFO - 2025-05-28 14:54:56 --> Router Class Initialized
INFO - 2025-05-28 14:54:56 --> Output Class Initialized
INFO - 2025-05-28 14:54:56 --> Security Class Initialized
DEBUG - 2025-05-28 14:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:54:56 --> Input Class Initialized
INFO - 2025-05-28 14:54:56 --> Language Class Initialized
INFO - 2025-05-28 14:54:56 --> Loader Class Initialized
INFO - 2025-05-28 14:54:56 --> Helper loaded: url_helper
INFO - 2025-05-28 14:54:56 --> Helper loaded: form_helper
INFO - 2025-05-28 14:54:56 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:54:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:54:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:54:56 --> Controller Class Initialized
INFO - 2025-05-28 14:54:56 --> Model "Progress_model" initialized
INFO - 2025-05-28 14:54:56 --> Model "Olahraga_model" initialized
INFO - 2025-05-28 14:54:56 --> Model "User_model" initialized
INFO - 2025-05-28 14:54:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-28 14:54:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-28 14:54:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-28 14:54:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-28 14:54:56 --> Final output sent to browser
DEBUG - 2025-05-28 14:54:56 --> Total execution time: 0.0744
INFO - 2025-05-28 14:54:57 --> Config Class Initialized
INFO - 2025-05-28 14:54:57 --> Hooks Class Initialized
DEBUG - 2025-05-28 14:54:57 --> UTF-8 Support Enabled
INFO - 2025-05-28 14:54:57 --> Utf8 Class Initialized
INFO - 2025-05-28 14:54:57 --> URI Class Initialized
INFO - 2025-05-28 14:54:57 --> Router Class Initialized
INFO - 2025-05-28 14:54:57 --> Output Class Initialized
INFO - 2025-05-28 14:54:57 --> Security Class Initialized
DEBUG - 2025-05-28 14:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 14:54:57 --> Input Class Initialized
INFO - 2025-05-28 14:54:57 --> Language Class Initialized
INFO - 2025-05-28 14:54:57 --> Loader Class Initialized
INFO - 2025-05-28 14:54:57 --> Helper loaded: url_helper
INFO - 2025-05-28 14:54:57 --> Helper loaded: form_helper
INFO - 2025-05-28 14:54:57 --> Database Driver Class Initialized
DEBUG - 2025-05-28 14:54:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 14:54:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 14:54:57 --> Controller Class Initialized
INFO - 2025-05-28 14:54:57 --> Model "Progress_model" initialized
INFO - 2025-05-28 14:54:57 --> Model "Olahraga_model" initialized
INFO - 2025-05-28 14:54:57 --> Model "User_model" initialized
INFO - 2025-05-28 14:54:57 --> Final output sent to browser
DEBUG - 2025-05-28 14:54:57 --> Total execution time: 0.0671
INFO - 2025-05-28 15:05:04 --> Config Class Initialized
INFO - 2025-05-28 15:05:04 --> Hooks Class Initialized
DEBUG - 2025-05-28 15:05:04 --> UTF-8 Support Enabled
INFO - 2025-05-28 15:05:04 --> Utf8 Class Initialized
INFO - 2025-05-28 15:05:04 --> URI Class Initialized
INFO - 2025-05-28 15:05:04 --> Router Class Initialized
INFO - 2025-05-28 15:05:04 --> Output Class Initialized
INFO - 2025-05-28 15:05:04 --> Security Class Initialized
DEBUG - 2025-05-28 15:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 15:05:04 --> Input Class Initialized
INFO - 2025-05-28 15:05:04 --> Language Class Initialized
INFO - 2025-05-28 15:05:04 --> Loader Class Initialized
INFO - 2025-05-28 15:05:04 --> Helper loaded: url_helper
INFO - 2025-05-28 15:05:04 --> Helper loaded: form_helper
INFO - 2025-05-28 15:05:04 --> Database Driver Class Initialized
DEBUG - 2025-05-28 15:05:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 15:05:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 15:05:04 --> Controller Class Initialized
INFO - 2025-05-28 15:05:04 --> Model "Progress_model" initialized
INFO - 2025-05-28 15:05:04 --> Model "Olahraga_model" initialized
INFO - 2025-05-28 15:05:04 --> Model "User_model" initialized
INFO - 2025-05-28 15:05:04 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-28 15:05:04 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-28 15:05:04 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-28 15:05:04 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-28 15:05:04 --> Final output sent to browser
DEBUG - 2025-05-28 15:05:04 --> Total execution time: 0.0861
INFO - 2025-05-28 15:05:04 --> Config Class Initialized
INFO - 2025-05-28 15:05:04 --> Hooks Class Initialized
DEBUG - 2025-05-28 15:05:04 --> UTF-8 Support Enabled
INFO - 2025-05-28 15:05:04 --> Utf8 Class Initialized
INFO - 2025-05-28 15:05:04 --> URI Class Initialized
INFO - 2025-05-28 15:05:04 --> Router Class Initialized
INFO - 2025-05-28 15:05:04 --> Output Class Initialized
INFO - 2025-05-28 15:05:04 --> Security Class Initialized
DEBUG - 2025-05-28 15:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 15:05:04 --> Input Class Initialized
INFO - 2025-05-28 15:05:04 --> Language Class Initialized
INFO - 2025-05-28 15:05:04 --> Loader Class Initialized
INFO - 2025-05-28 15:05:04 --> Helper loaded: url_helper
INFO - 2025-05-28 15:05:04 --> Helper loaded: form_helper
INFO - 2025-05-28 15:05:04 --> Database Driver Class Initialized
DEBUG - 2025-05-28 15:05:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 15:05:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 15:05:04 --> Controller Class Initialized
INFO - 2025-05-28 15:05:04 --> Model "Progress_model" initialized
INFO - 2025-05-28 15:05:04 --> Model "Olahraga_model" initialized
INFO - 2025-05-28 15:05:04 --> Model "User_model" initialized
INFO - 2025-05-28 15:05:04 --> Final output sent to browser
DEBUG - 2025-05-28 15:05:04 --> Total execution time: 0.0813
INFO - 2025-05-28 15:05:17 --> Config Class Initialized
INFO - 2025-05-28 15:05:17 --> Hooks Class Initialized
DEBUG - 2025-05-28 15:05:17 --> UTF-8 Support Enabled
INFO - 2025-05-28 15:05:17 --> Utf8 Class Initialized
INFO - 2025-05-28 15:05:17 --> URI Class Initialized
INFO - 2025-05-28 15:05:17 --> Router Class Initialized
INFO - 2025-05-28 15:05:17 --> Output Class Initialized
INFO - 2025-05-28 15:05:17 --> Security Class Initialized
DEBUG - 2025-05-28 15:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 15:05:17 --> Input Class Initialized
INFO - 2025-05-28 15:05:17 --> Language Class Initialized
INFO - 2025-05-28 15:05:17 --> Loader Class Initialized
INFO - 2025-05-28 15:05:17 --> Helper loaded: url_helper
INFO - 2025-05-28 15:05:17 --> Helper loaded: form_helper
INFO - 2025-05-28 15:05:17 --> Database Driver Class Initialized
DEBUG - 2025-05-28 15:05:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 15:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 15:05:17 --> Controller Class Initialized
INFO - 2025-05-28 15:05:17 --> Model "Progress_model" initialized
INFO - 2025-05-28 15:05:17 --> Model "Olahraga_model" initialized
INFO - 2025-05-28 15:05:17 --> Model "User_model" initialized
INFO - 2025-05-28 15:05:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-28 15:05:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-28 15:05:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-28 15:05:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-28 15:05:17 --> Final output sent to browser
DEBUG - 2025-05-28 15:05:17 --> Total execution time: 0.0758
INFO - 2025-05-28 15:05:17 --> Config Class Initialized
INFO - 2025-05-28 15:05:17 --> Hooks Class Initialized
DEBUG - 2025-05-28 15:05:17 --> UTF-8 Support Enabled
INFO - 2025-05-28 15:05:17 --> Utf8 Class Initialized
INFO - 2025-05-28 15:05:17 --> URI Class Initialized
INFO - 2025-05-28 15:05:17 --> Router Class Initialized
INFO - 2025-05-28 15:05:17 --> Output Class Initialized
INFO - 2025-05-28 15:05:17 --> Security Class Initialized
DEBUG - 2025-05-28 15:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 15:05:17 --> Input Class Initialized
INFO - 2025-05-28 15:05:17 --> Language Class Initialized
INFO - 2025-05-28 15:05:17 --> Loader Class Initialized
INFO - 2025-05-28 15:05:17 --> Helper loaded: url_helper
INFO - 2025-05-28 15:05:17 --> Helper loaded: form_helper
INFO - 2025-05-28 15:05:17 --> Database Driver Class Initialized
DEBUG - 2025-05-28 15:05:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 15:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 15:05:17 --> Controller Class Initialized
INFO - 2025-05-28 15:05:17 --> Model "Progress_model" initialized
INFO - 2025-05-28 15:05:17 --> Model "Olahraga_model" initialized
INFO - 2025-05-28 15:05:17 --> Model "User_model" initialized
INFO - 2025-05-28 15:05:17 --> Final output sent to browser
DEBUG - 2025-05-28 15:05:17 --> Total execution time: 0.0542
INFO - 2025-05-28 15:05:32 --> Config Class Initialized
INFO - 2025-05-28 15:05:32 --> Hooks Class Initialized
DEBUG - 2025-05-28 15:05:32 --> UTF-8 Support Enabled
INFO - 2025-05-28 15:05:32 --> Utf8 Class Initialized
INFO - 2025-05-28 15:05:32 --> URI Class Initialized
INFO - 2025-05-28 15:05:32 --> Router Class Initialized
INFO - 2025-05-28 15:05:32 --> Output Class Initialized
INFO - 2025-05-28 15:05:32 --> Security Class Initialized
DEBUG - 2025-05-28 15:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 15:05:32 --> Input Class Initialized
INFO - 2025-05-28 15:05:32 --> Language Class Initialized
INFO - 2025-05-28 15:05:32 --> Loader Class Initialized
INFO - 2025-05-28 15:05:32 --> Helper loaded: url_helper
INFO - 2025-05-28 15:05:32 --> Helper loaded: form_helper
INFO - 2025-05-28 15:05:32 --> Database Driver Class Initialized
DEBUG - 2025-05-28 15:05:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 15:05:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 15:05:32 --> Controller Class Initialized
INFO - 2025-05-28 15:05:32 --> Model "Progress_model" initialized
INFO - 2025-05-28 15:05:32 --> Model "Olahraga_model" initialized
INFO - 2025-05-28 15:05:32 --> Model "User_model" initialized
INFO - 2025-05-28 15:05:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-28 15:05:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-28 15:05:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-28 15:05:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-28 15:05:32 --> Final output sent to browser
DEBUG - 2025-05-28 15:05:32 --> Total execution time: 0.0904
INFO - 2025-05-28 15:05:32 --> Config Class Initialized
INFO - 2025-05-28 15:05:32 --> Hooks Class Initialized
DEBUG - 2025-05-28 15:05:32 --> UTF-8 Support Enabled
INFO - 2025-05-28 15:05:32 --> Utf8 Class Initialized
INFO - 2025-05-28 15:05:32 --> URI Class Initialized
INFO - 2025-05-28 15:05:32 --> Router Class Initialized
INFO - 2025-05-28 15:05:32 --> Output Class Initialized
INFO - 2025-05-28 15:05:32 --> Security Class Initialized
DEBUG - 2025-05-28 15:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 15:05:32 --> Input Class Initialized
INFO - 2025-05-28 15:05:32 --> Language Class Initialized
INFO - 2025-05-28 15:05:32 --> Loader Class Initialized
INFO - 2025-05-28 15:05:32 --> Helper loaded: url_helper
INFO - 2025-05-28 15:05:32 --> Helper loaded: form_helper
INFO - 2025-05-28 15:05:32 --> Database Driver Class Initialized
DEBUG - 2025-05-28 15:05:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 15:05:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 15:05:32 --> Controller Class Initialized
INFO - 2025-05-28 15:05:32 --> Model "Progress_model" initialized
INFO - 2025-05-28 15:05:32 --> Model "Olahraga_model" initialized
INFO - 2025-05-28 15:05:32 --> Model "User_model" initialized
INFO - 2025-05-28 15:05:32 --> Final output sent to browser
DEBUG - 2025-05-28 15:05:32 --> Total execution time: 0.0646
INFO - 2025-05-28 15:05:37 --> Config Class Initialized
INFO - 2025-05-28 15:05:37 --> Hooks Class Initialized
DEBUG - 2025-05-28 15:05:37 --> UTF-8 Support Enabled
INFO - 2025-05-28 15:05:37 --> Utf8 Class Initialized
INFO - 2025-05-28 15:05:37 --> URI Class Initialized
INFO - 2025-05-28 15:05:37 --> Router Class Initialized
INFO - 2025-05-28 15:05:37 --> Output Class Initialized
INFO - 2025-05-28 15:05:37 --> Security Class Initialized
DEBUG - 2025-05-28 15:05:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 15:05:37 --> Input Class Initialized
INFO - 2025-05-28 15:05:37 --> Language Class Initialized
INFO - 2025-05-28 15:05:37 --> Loader Class Initialized
INFO - 2025-05-28 15:05:37 --> Helper loaded: url_helper
INFO - 2025-05-28 15:05:37 --> Helper loaded: form_helper
INFO - 2025-05-28 15:05:37 --> Database Driver Class Initialized
DEBUG - 2025-05-28 15:05:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 15:05:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 15:05:37 --> Controller Class Initialized
INFO - 2025-05-28 15:05:37 --> Model "Progress_model" initialized
INFO - 2025-05-28 15:05:37 --> Model "Olahraga_model" initialized
INFO - 2025-05-28 15:05:37 --> Model "User_model" initialized
INFO - 2025-05-28 15:05:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-28 15:05:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-28 15:05:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-28 15:05:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-28 15:05:37 --> Final output sent to browser
DEBUG - 2025-05-28 15:05:37 --> Total execution time: 0.0653
INFO - 2025-05-28 15:05:37 --> Config Class Initialized
INFO - 2025-05-28 15:05:37 --> Hooks Class Initialized
DEBUG - 2025-05-28 15:05:37 --> UTF-8 Support Enabled
INFO - 2025-05-28 15:05:37 --> Utf8 Class Initialized
INFO - 2025-05-28 15:05:37 --> URI Class Initialized
INFO - 2025-05-28 15:05:37 --> Router Class Initialized
INFO - 2025-05-28 15:05:37 --> Output Class Initialized
INFO - 2025-05-28 15:05:37 --> Security Class Initialized
DEBUG - 2025-05-28 15:05:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 15:05:37 --> Input Class Initialized
INFO - 2025-05-28 15:05:37 --> Language Class Initialized
INFO - 2025-05-28 15:05:37 --> Loader Class Initialized
INFO - 2025-05-28 15:05:37 --> Helper loaded: url_helper
INFO - 2025-05-28 15:05:37 --> Helper loaded: form_helper
INFO - 2025-05-28 15:05:37 --> Database Driver Class Initialized
DEBUG - 2025-05-28 15:05:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 15:05:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 15:05:37 --> Controller Class Initialized
INFO - 2025-05-28 15:05:37 --> Model "Progress_model" initialized
INFO - 2025-05-28 15:05:37 --> Model "Olahraga_model" initialized
INFO - 2025-05-28 15:05:37 --> Model "User_model" initialized
INFO - 2025-05-28 15:05:37 --> Final output sent to browser
DEBUG - 2025-05-28 15:05:37 --> Total execution time: 0.0722
INFO - 2025-05-28 15:05:45 --> Config Class Initialized
INFO - 2025-05-28 15:05:45 --> Hooks Class Initialized
DEBUG - 2025-05-28 15:05:45 --> UTF-8 Support Enabled
INFO - 2025-05-28 15:05:45 --> Utf8 Class Initialized
INFO - 2025-05-28 15:05:45 --> URI Class Initialized
INFO - 2025-05-28 15:05:45 --> Router Class Initialized
INFO - 2025-05-28 15:05:45 --> Output Class Initialized
INFO - 2025-05-28 15:05:45 --> Security Class Initialized
DEBUG - 2025-05-28 15:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 15:05:45 --> Input Class Initialized
INFO - 2025-05-28 15:05:45 --> Language Class Initialized
INFO - 2025-05-28 15:05:45 --> Loader Class Initialized
INFO - 2025-05-28 15:05:45 --> Helper loaded: url_helper
INFO - 2025-05-28 15:05:45 --> Helper loaded: form_helper
INFO - 2025-05-28 15:05:45 --> Database Driver Class Initialized
DEBUG - 2025-05-28 15:05:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 15:05:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 15:05:45 --> Controller Class Initialized
INFO - 2025-05-28 15:05:45 --> Model "Progress_model" initialized
INFO - 2025-05-28 15:05:45 --> Model "Olahraga_model" initialized
INFO - 2025-05-28 15:05:45 --> Model "User_model" initialized
INFO - 2025-05-28 15:05:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-28 15:05:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-28 15:05:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-28 15:05:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-28 15:05:45 --> Final output sent to browser
DEBUG - 2025-05-28 15:05:45 --> Total execution time: 0.0817
INFO - 2025-05-28 15:05:46 --> Config Class Initialized
INFO - 2025-05-28 15:05:46 --> Hooks Class Initialized
DEBUG - 2025-05-28 15:05:46 --> UTF-8 Support Enabled
INFO - 2025-05-28 15:05:46 --> Utf8 Class Initialized
INFO - 2025-05-28 15:05:46 --> URI Class Initialized
INFO - 2025-05-28 15:05:46 --> Router Class Initialized
INFO - 2025-05-28 15:05:46 --> Output Class Initialized
INFO - 2025-05-28 15:05:46 --> Security Class Initialized
DEBUG - 2025-05-28 15:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 15:05:46 --> Input Class Initialized
INFO - 2025-05-28 15:05:46 --> Language Class Initialized
INFO - 2025-05-28 15:05:46 --> Loader Class Initialized
INFO - 2025-05-28 15:05:46 --> Helper loaded: url_helper
INFO - 2025-05-28 15:05:46 --> Helper loaded: form_helper
INFO - 2025-05-28 15:05:46 --> Database Driver Class Initialized
DEBUG - 2025-05-28 15:05:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 15:05:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 15:05:46 --> Controller Class Initialized
INFO - 2025-05-28 15:05:46 --> Model "Progress_model" initialized
INFO - 2025-05-28 15:05:46 --> Model "Olahraga_model" initialized
INFO - 2025-05-28 15:05:46 --> Model "User_model" initialized
INFO - 2025-05-28 15:05:46 --> Final output sent to browser
DEBUG - 2025-05-28 15:05:46 --> Total execution time: 0.0558
INFO - 2025-05-28 15:05:49 --> Config Class Initialized
INFO - 2025-05-28 15:05:49 --> Hooks Class Initialized
DEBUG - 2025-05-28 15:05:49 --> UTF-8 Support Enabled
INFO - 2025-05-28 15:05:49 --> Utf8 Class Initialized
INFO - 2025-05-28 15:05:49 --> URI Class Initialized
INFO - 2025-05-28 15:05:49 --> Router Class Initialized
INFO - 2025-05-28 15:05:49 --> Output Class Initialized
INFO - 2025-05-28 15:05:49 --> Security Class Initialized
DEBUG - 2025-05-28 15:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 15:05:49 --> Input Class Initialized
INFO - 2025-05-28 15:05:49 --> Language Class Initialized
INFO - 2025-05-28 15:05:49 --> Loader Class Initialized
INFO - 2025-05-28 15:05:49 --> Helper loaded: url_helper
INFO - 2025-05-28 15:05:49 --> Helper loaded: form_helper
INFO - 2025-05-28 15:05:49 --> Database Driver Class Initialized
DEBUG - 2025-05-28 15:05:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 15:05:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 15:05:49 --> Controller Class Initialized
INFO - 2025-05-28 15:05:49 --> Model "Progress_model" initialized
INFO - 2025-05-28 15:05:49 --> Model "Olahraga_model" initialized
INFO - 2025-05-28 15:05:49 --> Model "User_model" initialized
INFO - 2025-05-28 15:05:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-28 15:05:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-28 15:05:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-28 15:05:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-28 15:05:49 --> Final output sent to browser
DEBUG - 2025-05-28 15:05:49 --> Total execution time: 0.0704
INFO - 2025-05-28 15:05:50 --> Config Class Initialized
INFO - 2025-05-28 15:05:50 --> Hooks Class Initialized
DEBUG - 2025-05-28 15:05:50 --> UTF-8 Support Enabled
INFO - 2025-05-28 15:05:50 --> Utf8 Class Initialized
INFO - 2025-05-28 15:05:50 --> URI Class Initialized
INFO - 2025-05-28 15:05:50 --> Router Class Initialized
INFO - 2025-05-28 15:05:50 --> Output Class Initialized
INFO - 2025-05-28 15:05:50 --> Security Class Initialized
DEBUG - 2025-05-28 15:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 15:05:50 --> Input Class Initialized
INFO - 2025-05-28 15:05:50 --> Language Class Initialized
INFO - 2025-05-28 15:05:50 --> Loader Class Initialized
INFO - 2025-05-28 15:05:50 --> Helper loaded: url_helper
INFO - 2025-05-28 15:05:50 --> Helper loaded: form_helper
INFO - 2025-05-28 15:05:50 --> Database Driver Class Initialized
DEBUG - 2025-05-28 15:05:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 15:05:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 15:05:50 --> Controller Class Initialized
INFO - 2025-05-28 15:05:50 --> Model "Progress_model" initialized
INFO - 2025-05-28 15:05:50 --> Model "Olahraga_model" initialized
INFO - 2025-05-28 15:05:50 --> Model "User_model" initialized
INFO - 2025-05-28 15:05:50 --> Final output sent to browser
DEBUG - 2025-05-28 15:05:50 --> Total execution time: 0.0546
INFO - 2025-05-28 15:05:59 --> Config Class Initialized
INFO - 2025-05-28 15:05:59 --> Hooks Class Initialized
DEBUG - 2025-05-28 15:06:00 --> UTF-8 Support Enabled
INFO - 2025-05-28 15:06:00 --> Utf8 Class Initialized
INFO - 2025-05-28 15:06:00 --> URI Class Initialized
INFO - 2025-05-28 15:06:00 --> Router Class Initialized
INFO - 2025-05-28 15:06:00 --> Output Class Initialized
INFO - 2025-05-28 15:06:00 --> Security Class Initialized
DEBUG - 2025-05-28 15:06:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 15:06:00 --> Input Class Initialized
INFO - 2025-05-28 15:06:00 --> Language Class Initialized
INFO - 2025-05-28 15:06:00 --> Loader Class Initialized
INFO - 2025-05-28 15:06:00 --> Helper loaded: url_helper
INFO - 2025-05-28 15:06:00 --> Helper loaded: form_helper
INFO - 2025-05-28 15:06:00 --> Database Driver Class Initialized
DEBUG - 2025-05-28 15:06:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 15:06:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 15:06:00 --> Controller Class Initialized
INFO - 2025-05-28 15:06:00 --> Model "Progress_model" initialized
INFO - 2025-05-28 15:06:00 --> Model "Olahraga_model" initialized
INFO - 2025-05-28 15:06:00 --> Model "User_model" initialized
INFO - 2025-05-28 15:06:00 --> Final output sent to browser
DEBUG - 2025-05-28 15:06:00 --> Total execution time: 0.0718
INFO - 2025-05-28 15:06:01 --> Config Class Initialized
INFO - 2025-05-28 15:06:01 --> Hooks Class Initialized
DEBUG - 2025-05-28 15:06:01 --> UTF-8 Support Enabled
INFO - 2025-05-28 15:06:01 --> Utf8 Class Initialized
INFO - 2025-05-28 15:06:01 --> URI Class Initialized
INFO - 2025-05-28 15:06:01 --> Router Class Initialized
INFO - 2025-05-28 15:06:01 --> Output Class Initialized
INFO - 2025-05-28 15:06:01 --> Security Class Initialized
DEBUG - 2025-05-28 15:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 15:06:01 --> Input Class Initialized
INFO - 2025-05-28 15:06:01 --> Language Class Initialized
INFO - 2025-05-28 15:06:01 --> Loader Class Initialized
INFO - 2025-05-28 15:06:01 --> Helper loaded: url_helper
INFO - 2025-05-28 15:06:01 --> Helper loaded: form_helper
INFO - 2025-05-28 15:06:01 --> Database Driver Class Initialized
DEBUG - 2025-05-28 15:06:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 15:06:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 15:06:01 --> Controller Class Initialized
INFO - 2025-05-28 15:06:01 --> Model "Progress_model" initialized
INFO - 2025-05-28 15:06:01 --> Model "Olahraga_model" initialized
INFO - 2025-05-28 15:06:01 --> Model "User_model" initialized
INFO - 2025-05-28 15:06:01 --> Final output sent to browser
DEBUG - 2025-05-28 15:06:01 --> Total execution time: 0.0740
INFO - 2025-05-28 15:06:07 --> Config Class Initialized
INFO - 2025-05-28 15:06:07 --> Hooks Class Initialized
DEBUG - 2025-05-28 15:06:07 --> UTF-8 Support Enabled
INFO - 2025-05-28 15:06:07 --> Utf8 Class Initialized
INFO - 2025-05-28 15:06:07 --> URI Class Initialized
INFO - 2025-05-28 15:06:07 --> Router Class Initialized
INFO - 2025-05-28 15:06:07 --> Output Class Initialized
INFO - 2025-05-28 15:06:07 --> Security Class Initialized
DEBUG - 2025-05-28 15:06:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 15:06:07 --> Input Class Initialized
INFO - 2025-05-28 15:06:07 --> Language Class Initialized
INFO - 2025-05-28 15:06:07 --> Loader Class Initialized
INFO - 2025-05-28 15:06:07 --> Helper loaded: url_helper
INFO - 2025-05-28 15:06:07 --> Helper loaded: form_helper
INFO - 2025-05-28 15:06:07 --> Database Driver Class Initialized
DEBUG - 2025-05-28 15:06:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 15:06:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 15:06:07 --> Controller Class Initialized
INFO - 2025-05-28 15:06:07 --> Model "Progress_model" initialized
INFO - 2025-05-28 15:06:07 --> Model "Olahraga_model" initialized
INFO - 2025-05-28 15:06:07 --> Model "User_model" initialized
INFO - 2025-05-28 15:06:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-28 15:06:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-28 15:06:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-28 15:06:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-28 15:06:07 --> Final output sent to browser
DEBUG - 2025-05-28 15:06:07 --> Total execution time: 0.0634
INFO - 2025-05-28 15:06:08 --> Config Class Initialized
INFO - 2025-05-28 15:06:08 --> Hooks Class Initialized
DEBUG - 2025-05-28 15:06:08 --> UTF-8 Support Enabled
INFO - 2025-05-28 15:06:08 --> Utf8 Class Initialized
INFO - 2025-05-28 15:06:08 --> URI Class Initialized
INFO - 2025-05-28 15:06:08 --> Router Class Initialized
INFO - 2025-05-28 15:06:08 --> Output Class Initialized
INFO - 2025-05-28 15:06:08 --> Security Class Initialized
DEBUG - 2025-05-28 15:06:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 15:06:08 --> Input Class Initialized
INFO - 2025-05-28 15:06:08 --> Language Class Initialized
INFO - 2025-05-28 15:06:08 --> Loader Class Initialized
INFO - 2025-05-28 15:06:08 --> Helper loaded: url_helper
INFO - 2025-05-28 15:06:08 --> Helper loaded: form_helper
INFO - 2025-05-28 15:06:08 --> Database Driver Class Initialized
DEBUG - 2025-05-28 15:06:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 15:06:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 15:06:08 --> Controller Class Initialized
INFO - 2025-05-28 15:06:08 --> Model "Progress_model" initialized
INFO - 2025-05-28 15:06:08 --> Model "Olahraga_model" initialized
INFO - 2025-05-28 15:06:08 --> Model "User_model" initialized
INFO - 2025-05-28 15:06:08 --> Final output sent to browser
DEBUG - 2025-05-28 15:06:08 --> Total execution time: 0.0587
INFO - 2025-05-28 15:06:20 --> Config Class Initialized
INFO - 2025-05-28 15:06:20 --> Hooks Class Initialized
DEBUG - 2025-05-28 15:06:20 --> UTF-8 Support Enabled
INFO - 2025-05-28 15:06:20 --> Utf8 Class Initialized
INFO - 2025-05-28 15:06:20 --> URI Class Initialized
INFO - 2025-05-28 15:06:20 --> Router Class Initialized
INFO - 2025-05-28 15:06:20 --> Output Class Initialized
INFO - 2025-05-28 15:06:20 --> Security Class Initialized
DEBUG - 2025-05-28 15:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 15:06:20 --> Input Class Initialized
INFO - 2025-05-28 15:06:20 --> Language Class Initialized
INFO - 2025-05-28 15:06:20 --> Loader Class Initialized
INFO - 2025-05-28 15:06:20 --> Helper loaded: url_helper
INFO - 2025-05-28 15:06:20 --> Helper loaded: form_helper
INFO - 2025-05-28 15:06:20 --> Database Driver Class Initialized
DEBUG - 2025-05-28 15:06:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 15:06:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 15:06:20 --> Controller Class Initialized
INFO - 2025-05-28 15:06:20 --> Model "Olahraga_model" initialized
INFO - 2025-05-28 15:06:20 --> Model "User_model" initialized
INFO - 2025-05-28 15:06:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-28 15:06:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-28 15:06:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-05-28 15:06:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-28 15:06:20 --> Final output sent to browser
DEBUG - 2025-05-28 15:06:20 --> Total execution time: 0.1635
INFO - 2025-05-28 15:06:23 --> Config Class Initialized
INFO - 2025-05-28 15:06:23 --> Hooks Class Initialized
DEBUG - 2025-05-28 15:06:23 --> UTF-8 Support Enabled
INFO - 2025-05-28 15:06:23 --> Utf8 Class Initialized
INFO - 2025-05-28 15:06:23 --> URI Class Initialized
INFO - 2025-05-28 15:06:23 --> Router Class Initialized
INFO - 2025-05-28 15:06:23 --> Output Class Initialized
INFO - 2025-05-28 15:06:23 --> Security Class Initialized
DEBUG - 2025-05-28 15:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 15:06:23 --> Input Class Initialized
INFO - 2025-05-28 15:06:23 --> Language Class Initialized
INFO - 2025-05-28 15:06:23 --> Loader Class Initialized
INFO - 2025-05-28 15:06:23 --> Helper loaded: url_helper
INFO - 2025-05-28 15:06:23 --> Helper loaded: form_helper
INFO - 2025-05-28 15:06:23 --> Database Driver Class Initialized
DEBUG - 2025-05-28 15:06:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 15:06:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 15:06:23 --> Controller Class Initialized
INFO - 2025-05-28 15:06:23 --> Model "Olahraga_model" initialized
INFO - 2025-05-28 15:06:23 --> Model "User_model" initialized
INFO - 2025-05-28 15:06:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-28 15:06:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-28 15:06:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-05-28 15:06:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-28 15:06:23 --> Final output sent to browser
DEBUG - 2025-05-28 15:06:23 --> Total execution time: 0.0959
INFO - 2025-05-28 15:07:45 --> Config Class Initialized
INFO - 2025-05-28 15:07:45 --> Hooks Class Initialized
DEBUG - 2025-05-28 15:07:45 --> UTF-8 Support Enabled
INFO - 2025-05-28 15:07:45 --> Utf8 Class Initialized
INFO - 2025-05-28 15:07:45 --> URI Class Initialized
INFO - 2025-05-28 15:07:45 --> Router Class Initialized
INFO - 2025-05-28 15:07:45 --> Output Class Initialized
INFO - 2025-05-28 15:07:45 --> Security Class Initialized
DEBUG - 2025-05-28 15:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 15:07:45 --> Input Class Initialized
INFO - 2025-05-28 15:07:45 --> Language Class Initialized
INFO - 2025-05-28 15:07:45 --> Loader Class Initialized
INFO - 2025-05-28 15:07:45 --> Helper loaded: url_helper
INFO - 2025-05-28 15:07:45 --> Helper loaded: form_helper
INFO - 2025-05-28 15:07:45 --> Database Driver Class Initialized
DEBUG - 2025-05-28 15:07:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 15:07:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 15:07:45 --> Controller Class Initialized
INFO - 2025-05-28 15:07:45 --> Model "Olahraga_model" initialized
INFO - 2025-05-28 15:07:45 --> Model "User_model" initialized
INFO - 2025-05-28 15:07:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-28 15:07:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-28 15:07:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-05-28 15:07:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-28 15:07:45 --> Final output sent to browser
DEBUG - 2025-05-28 15:07:45 --> Total execution time: 0.0685
INFO - 2025-05-28 15:08:40 --> Config Class Initialized
INFO - 2025-05-28 15:08:40 --> Hooks Class Initialized
DEBUG - 2025-05-28 15:08:40 --> UTF-8 Support Enabled
INFO - 2025-05-28 15:08:40 --> Utf8 Class Initialized
INFO - 2025-05-28 15:08:40 --> URI Class Initialized
INFO - 2025-05-28 15:08:40 --> Router Class Initialized
INFO - 2025-05-28 15:08:40 --> Output Class Initialized
INFO - 2025-05-28 15:08:40 --> Security Class Initialized
DEBUG - 2025-05-28 15:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 15:08:40 --> Input Class Initialized
INFO - 2025-05-28 15:08:40 --> Language Class Initialized
INFO - 2025-05-28 15:08:40 --> Loader Class Initialized
INFO - 2025-05-28 15:08:40 --> Helper loaded: url_helper
INFO - 2025-05-28 15:08:40 --> Helper loaded: form_helper
INFO - 2025-05-28 15:08:40 --> Database Driver Class Initialized
DEBUG - 2025-05-28 15:08:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 15:08:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 15:08:40 --> Controller Class Initialized
INFO - 2025-05-28 15:08:40 --> Model "Olahraga_model" initialized
INFO - 2025-05-28 15:08:40 --> Model "User_model" initialized
INFO - 2025-05-28 15:08:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-28 15:08:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-28 15:08:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-05-28 15:08:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-28 15:08:40 --> Final output sent to browser
DEBUG - 2025-05-28 15:08:40 --> Total execution time: 0.0754
INFO - 2025-05-28 15:08:55 --> Config Class Initialized
INFO - 2025-05-28 15:08:55 --> Hooks Class Initialized
DEBUG - 2025-05-28 15:08:55 --> UTF-8 Support Enabled
INFO - 2025-05-28 15:08:55 --> Utf8 Class Initialized
INFO - 2025-05-28 15:08:55 --> URI Class Initialized
INFO - 2025-05-28 15:08:55 --> Router Class Initialized
INFO - 2025-05-28 15:08:55 --> Output Class Initialized
INFO - 2025-05-28 15:08:55 --> Security Class Initialized
DEBUG - 2025-05-28 15:08:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 15:08:55 --> Input Class Initialized
INFO - 2025-05-28 15:08:55 --> Language Class Initialized
INFO - 2025-05-28 15:08:55 --> Loader Class Initialized
INFO - 2025-05-28 15:08:55 --> Helper loaded: url_helper
INFO - 2025-05-28 15:08:55 --> Helper loaded: form_helper
INFO - 2025-05-28 15:08:55 --> Database Driver Class Initialized
DEBUG - 2025-05-28 15:08:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 15:08:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 15:08:55 --> Controller Class Initialized
INFO - 2025-05-28 15:08:55 --> Model "Olahraga_model" initialized
INFO - 2025-05-28 15:08:55 --> Model "User_model" initialized
INFO - 2025-05-28 15:08:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-28 15:08:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-28 15:08:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-05-28 15:08:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-28 15:08:55 --> Final output sent to browser
DEBUG - 2025-05-28 15:08:55 --> Total execution time: 0.0774
INFO - 2025-05-28 15:10:56 --> Config Class Initialized
INFO - 2025-05-28 15:10:56 --> Hooks Class Initialized
DEBUG - 2025-05-28 15:10:56 --> UTF-8 Support Enabled
INFO - 2025-05-28 15:10:56 --> Utf8 Class Initialized
INFO - 2025-05-28 15:10:56 --> URI Class Initialized
INFO - 2025-05-28 15:10:56 --> Router Class Initialized
INFO - 2025-05-28 15:10:56 --> Output Class Initialized
INFO - 2025-05-28 15:10:56 --> Security Class Initialized
DEBUG - 2025-05-28 15:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 15:10:56 --> Input Class Initialized
INFO - 2025-05-28 15:10:56 --> Language Class Initialized
INFO - 2025-05-28 15:10:56 --> Loader Class Initialized
INFO - 2025-05-28 15:10:56 --> Helper loaded: url_helper
INFO - 2025-05-28 15:10:56 --> Helper loaded: form_helper
INFO - 2025-05-28 15:10:56 --> Database Driver Class Initialized
DEBUG - 2025-05-28 15:10:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 15:10:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 15:10:56 --> Controller Class Initialized
INFO - 2025-05-28 15:10:56 --> Model "Olahraga_model" initialized
INFO - 2025-05-28 15:10:56 --> Model "User_model" initialized
INFO - 2025-05-28 15:10:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-28 15:10:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-28 15:10:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-05-28 15:10:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-28 15:10:56 --> Final output sent to browser
DEBUG - 2025-05-28 15:10:56 --> Total execution time: 0.0842
INFO - 2025-05-28 15:16:25 --> Config Class Initialized
INFO - 2025-05-28 15:16:25 --> Hooks Class Initialized
DEBUG - 2025-05-28 15:16:25 --> UTF-8 Support Enabled
INFO - 2025-05-28 15:16:25 --> Utf8 Class Initialized
INFO - 2025-05-28 15:16:25 --> URI Class Initialized
INFO - 2025-05-28 15:16:25 --> Router Class Initialized
INFO - 2025-05-28 15:16:25 --> Output Class Initialized
INFO - 2025-05-28 15:16:25 --> Security Class Initialized
DEBUG - 2025-05-28 15:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 15:16:25 --> Input Class Initialized
INFO - 2025-05-28 15:16:25 --> Language Class Initialized
INFO - 2025-05-28 15:16:25 --> Loader Class Initialized
INFO - 2025-05-28 15:16:25 --> Helper loaded: url_helper
INFO - 2025-05-28 15:16:25 --> Helper loaded: form_helper
INFO - 2025-05-28 15:16:25 --> Database Driver Class Initialized
DEBUG - 2025-05-28 15:16:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 15:16:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 15:16:25 --> Controller Class Initialized
INFO - 2025-05-28 15:16:25 --> Model "Olahraga_model" initialized
INFO - 2025-05-28 15:16:25 --> Model "User_model" initialized
INFO - 2025-05-28 15:16:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-28 15:16:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-28 15:16:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-05-28 15:16:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-28 15:16:25 --> Final output sent to browser
DEBUG - 2025-05-28 15:16:25 --> Total execution time: 0.0716
INFO - 2025-05-28 15:18:42 --> Config Class Initialized
INFO - 2025-05-28 15:18:42 --> Hooks Class Initialized
DEBUG - 2025-05-28 15:18:42 --> UTF-8 Support Enabled
INFO - 2025-05-28 15:18:42 --> Utf8 Class Initialized
INFO - 2025-05-28 15:18:42 --> URI Class Initialized
INFO - 2025-05-28 15:18:42 --> Router Class Initialized
INFO - 2025-05-28 15:18:42 --> Output Class Initialized
INFO - 2025-05-28 15:18:42 --> Security Class Initialized
DEBUG - 2025-05-28 15:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 15:18:42 --> Input Class Initialized
INFO - 2025-05-28 15:18:42 --> Language Class Initialized
INFO - 2025-05-28 15:18:42 --> Loader Class Initialized
INFO - 2025-05-28 15:18:42 --> Helper loaded: url_helper
INFO - 2025-05-28 15:18:42 --> Helper loaded: form_helper
INFO - 2025-05-28 15:18:42 --> Database Driver Class Initialized
DEBUG - 2025-05-28 15:18:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 15:18:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 15:18:42 --> Controller Class Initialized
INFO - 2025-05-28 15:18:42 --> Model "Olahraga_model" initialized
INFO - 2025-05-28 15:18:42 --> Model "User_model" initialized
INFO - 2025-05-28 15:18:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-28 15:18:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-28 15:18:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-05-28 15:18:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-28 15:18:42 --> Final output sent to browser
DEBUG - 2025-05-28 15:18:42 --> Total execution time: 0.1083
INFO - 2025-05-28 15:19:48 --> Config Class Initialized
INFO - 2025-05-28 15:19:48 --> Hooks Class Initialized
DEBUG - 2025-05-28 15:19:48 --> UTF-8 Support Enabled
INFO - 2025-05-28 15:19:48 --> Utf8 Class Initialized
INFO - 2025-05-28 15:19:48 --> URI Class Initialized
INFO - 2025-05-28 15:19:48 --> Router Class Initialized
INFO - 2025-05-28 15:19:48 --> Output Class Initialized
INFO - 2025-05-28 15:19:48 --> Security Class Initialized
DEBUG - 2025-05-28 15:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 15:19:48 --> Input Class Initialized
INFO - 2025-05-28 15:19:48 --> Language Class Initialized
INFO - 2025-05-28 15:19:48 --> Loader Class Initialized
INFO - 2025-05-28 15:19:48 --> Helper loaded: url_helper
INFO - 2025-05-28 15:19:48 --> Helper loaded: form_helper
INFO - 2025-05-28 15:19:48 --> Database Driver Class Initialized
DEBUG - 2025-05-28 15:19:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 15:19:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 15:19:48 --> Controller Class Initialized
INFO - 2025-05-28 15:19:48 --> Model "Olahraga_model" initialized
INFO - 2025-05-28 15:19:48 --> Model "User_model" initialized
INFO - 2025-05-28 15:19:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-28 15:19:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-28 15:19:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-05-28 15:19:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-28 15:19:48 --> Final output sent to browser
DEBUG - 2025-05-28 15:19:48 --> Total execution time: 0.0682
INFO - 2025-05-28 15:20:57 --> Config Class Initialized
INFO - 2025-05-28 15:20:57 --> Hooks Class Initialized
DEBUG - 2025-05-28 15:20:57 --> UTF-8 Support Enabled
INFO - 2025-05-28 15:20:57 --> Utf8 Class Initialized
INFO - 2025-05-28 15:20:57 --> URI Class Initialized
INFO - 2025-05-28 15:20:57 --> Router Class Initialized
INFO - 2025-05-28 15:20:57 --> Output Class Initialized
INFO - 2025-05-28 15:20:57 --> Security Class Initialized
DEBUG - 2025-05-28 15:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 15:20:57 --> Input Class Initialized
INFO - 2025-05-28 15:20:57 --> Language Class Initialized
INFO - 2025-05-28 15:20:57 --> Loader Class Initialized
INFO - 2025-05-28 15:20:57 --> Helper loaded: url_helper
INFO - 2025-05-28 15:20:57 --> Helper loaded: form_helper
INFO - 2025-05-28 15:20:57 --> Database Driver Class Initialized
DEBUG - 2025-05-28 15:20:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 15:20:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 15:20:57 --> Controller Class Initialized
INFO - 2025-05-28 15:20:57 --> Model "Olahraga_model" initialized
INFO - 2025-05-28 15:20:57 --> Model "User_model" initialized
INFO - 2025-05-28 15:20:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-28 15:20:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-28 15:20:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-05-28 15:20:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-28 15:20:57 --> Final output sent to browser
DEBUG - 2025-05-28 15:20:57 --> Total execution time: 0.0618
INFO - 2025-05-28 15:21:28 --> Config Class Initialized
INFO - 2025-05-28 15:21:28 --> Hooks Class Initialized
DEBUG - 2025-05-28 15:21:28 --> UTF-8 Support Enabled
INFO - 2025-05-28 15:21:28 --> Utf8 Class Initialized
INFO - 2025-05-28 15:21:28 --> URI Class Initialized
INFO - 2025-05-28 15:21:28 --> Router Class Initialized
INFO - 2025-05-28 15:21:28 --> Output Class Initialized
INFO - 2025-05-28 15:21:28 --> Security Class Initialized
DEBUG - 2025-05-28 15:21:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 15:21:28 --> Input Class Initialized
INFO - 2025-05-28 15:21:28 --> Language Class Initialized
INFO - 2025-05-28 15:21:28 --> Loader Class Initialized
INFO - 2025-05-28 15:21:28 --> Helper loaded: url_helper
INFO - 2025-05-28 15:21:28 --> Helper loaded: form_helper
INFO - 2025-05-28 15:21:28 --> Database Driver Class Initialized
DEBUG - 2025-05-28 15:21:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 15:21:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 15:21:28 --> Controller Class Initialized
INFO - 2025-05-28 15:21:28 --> Model "Olahraga_model" initialized
INFO - 2025-05-28 15:21:28 --> Model "User_model" initialized
INFO - 2025-05-28 15:21:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-28 15:21:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-28 15:21:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-05-28 15:21:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-28 15:21:28 --> Final output sent to browser
DEBUG - 2025-05-28 15:21:28 --> Total execution time: 0.0819
INFO - 2025-05-28 15:22:56 --> Config Class Initialized
INFO - 2025-05-28 15:22:56 --> Hooks Class Initialized
DEBUG - 2025-05-28 15:22:56 --> UTF-8 Support Enabled
INFO - 2025-05-28 15:22:56 --> Utf8 Class Initialized
INFO - 2025-05-28 15:22:56 --> URI Class Initialized
INFO - 2025-05-28 15:22:57 --> Router Class Initialized
INFO - 2025-05-28 15:22:57 --> Output Class Initialized
INFO - 2025-05-28 15:22:57 --> Security Class Initialized
DEBUG - 2025-05-28 15:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 15:22:57 --> Input Class Initialized
INFO - 2025-05-28 15:22:57 --> Language Class Initialized
INFO - 2025-05-28 15:22:57 --> Loader Class Initialized
INFO - 2025-05-28 15:22:57 --> Helper loaded: url_helper
INFO - 2025-05-28 15:22:57 --> Helper loaded: form_helper
INFO - 2025-05-28 15:22:57 --> Database Driver Class Initialized
DEBUG - 2025-05-28 15:22:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 15:22:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 15:22:57 --> Controller Class Initialized
INFO - 2025-05-28 15:22:57 --> Model "Olahraga_model" initialized
INFO - 2025-05-28 15:22:57 --> Model "User_model" initialized
INFO - 2025-05-28 15:22:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-28 15:22:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-28 15:22:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-05-28 15:22:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-28 15:22:57 --> Final output sent to browser
DEBUG - 2025-05-28 15:22:57 --> Total execution time: 0.0872
INFO - 2025-05-28 15:24:28 --> Config Class Initialized
INFO - 2025-05-28 15:24:28 --> Hooks Class Initialized
DEBUG - 2025-05-28 15:24:28 --> UTF-8 Support Enabled
INFO - 2025-05-28 15:24:28 --> Utf8 Class Initialized
INFO - 2025-05-28 15:24:28 --> URI Class Initialized
INFO - 2025-05-28 15:24:28 --> Router Class Initialized
INFO - 2025-05-28 15:24:28 --> Output Class Initialized
INFO - 2025-05-28 15:24:28 --> Security Class Initialized
DEBUG - 2025-05-28 15:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 15:24:28 --> Input Class Initialized
INFO - 2025-05-28 15:24:28 --> Language Class Initialized
INFO - 2025-05-28 15:24:28 --> Loader Class Initialized
INFO - 2025-05-28 15:24:28 --> Helper loaded: url_helper
INFO - 2025-05-28 15:24:28 --> Helper loaded: form_helper
INFO - 2025-05-28 15:24:28 --> Database Driver Class Initialized
DEBUG - 2025-05-28 15:24:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 15:24:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 15:24:28 --> Controller Class Initialized
INFO - 2025-05-28 15:24:28 --> Model "Olahraga_model" initialized
INFO - 2025-05-28 15:24:28 --> Model "User_model" initialized
INFO - 2025-05-28 15:24:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-28 15:24:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-28 15:24:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-05-28 15:24:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-28 15:24:28 --> Final output sent to browser
DEBUG - 2025-05-28 15:24:28 --> Total execution time: 0.0821
INFO - 2025-05-28 15:27:32 --> Config Class Initialized
INFO - 2025-05-28 15:27:32 --> Hooks Class Initialized
DEBUG - 2025-05-28 15:27:32 --> UTF-8 Support Enabled
INFO - 2025-05-28 15:27:32 --> Utf8 Class Initialized
INFO - 2025-05-28 15:27:32 --> URI Class Initialized
INFO - 2025-05-28 15:27:32 --> Router Class Initialized
INFO - 2025-05-28 15:27:32 --> Output Class Initialized
INFO - 2025-05-28 15:27:32 --> Security Class Initialized
DEBUG - 2025-05-28 15:27:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 15:27:32 --> Input Class Initialized
INFO - 2025-05-28 15:27:32 --> Language Class Initialized
INFO - 2025-05-28 15:27:32 --> Loader Class Initialized
INFO - 2025-05-28 15:27:32 --> Helper loaded: url_helper
INFO - 2025-05-28 15:27:32 --> Helper loaded: form_helper
INFO - 2025-05-28 15:27:32 --> Database Driver Class Initialized
DEBUG - 2025-05-28 15:27:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 15:27:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 15:27:32 --> Controller Class Initialized
INFO - 2025-05-28 15:27:32 --> Model "Olahraga_model" initialized
INFO - 2025-05-28 15:27:32 --> Model "User_model" initialized
INFO - 2025-05-28 15:27:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-28 15:27:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-28 15:27:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-05-28 15:27:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-28 15:27:32 --> Final output sent to browser
DEBUG - 2025-05-28 15:27:32 --> Total execution time: 0.0671
INFO - 2025-05-28 15:30:44 --> Config Class Initialized
INFO - 2025-05-28 15:30:44 --> Hooks Class Initialized
DEBUG - 2025-05-28 15:30:44 --> UTF-8 Support Enabled
INFO - 2025-05-28 15:30:44 --> Utf8 Class Initialized
INFO - 2025-05-28 15:30:44 --> URI Class Initialized
INFO - 2025-05-28 15:30:44 --> Router Class Initialized
INFO - 2025-05-28 15:30:44 --> Output Class Initialized
INFO - 2025-05-28 15:30:44 --> Security Class Initialized
DEBUG - 2025-05-28 15:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 15:30:44 --> Input Class Initialized
INFO - 2025-05-28 15:30:44 --> Language Class Initialized
INFO - 2025-05-28 15:30:44 --> Loader Class Initialized
INFO - 2025-05-28 15:30:44 --> Helper loaded: url_helper
INFO - 2025-05-28 15:30:44 --> Helper loaded: form_helper
INFO - 2025-05-28 15:30:44 --> Database Driver Class Initialized
DEBUG - 2025-05-28 15:30:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 15:30:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 15:30:44 --> Controller Class Initialized
INFO - 2025-05-28 15:30:44 --> Model "Olahraga_model" initialized
INFO - 2025-05-28 15:30:44 --> Model "User_model" initialized
INFO - 2025-05-28 15:30:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-28 15:30:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-28 15:30:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-05-28 15:30:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-28 15:30:44 --> Final output sent to browser
DEBUG - 2025-05-28 15:30:44 --> Total execution time: 0.0888
INFO - 2025-05-28 15:32:16 --> Config Class Initialized
INFO - 2025-05-28 15:32:16 --> Hooks Class Initialized
DEBUG - 2025-05-28 15:32:16 --> UTF-8 Support Enabled
INFO - 2025-05-28 15:32:16 --> Utf8 Class Initialized
INFO - 2025-05-28 15:32:16 --> URI Class Initialized
INFO - 2025-05-28 15:32:16 --> Router Class Initialized
INFO - 2025-05-28 15:32:16 --> Output Class Initialized
INFO - 2025-05-28 15:32:16 --> Security Class Initialized
DEBUG - 2025-05-28 15:32:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 15:32:16 --> Input Class Initialized
INFO - 2025-05-28 15:32:16 --> Language Class Initialized
INFO - 2025-05-28 15:32:16 --> Loader Class Initialized
INFO - 2025-05-28 15:32:16 --> Helper loaded: url_helper
INFO - 2025-05-28 15:32:16 --> Helper loaded: form_helper
INFO - 2025-05-28 15:32:16 --> Database Driver Class Initialized
DEBUG - 2025-05-28 15:32:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 15:32:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 15:32:16 --> Controller Class Initialized
INFO - 2025-05-28 15:32:16 --> Model "Olahraga_model" initialized
INFO - 2025-05-28 15:32:16 --> Model "User_model" initialized
INFO - 2025-05-28 15:32:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-28 15:32:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-28 15:32:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-05-28 15:32:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-28 15:32:16 --> Final output sent to browser
DEBUG - 2025-05-28 15:32:16 --> Total execution time: 0.0698
INFO - 2025-05-28 15:32:34 --> Config Class Initialized
INFO - 2025-05-28 15:32:34 --> Hooks Class Initialized
DEBUG - 2025-05-28 15:32:34 --> UTF-8 Support Enabled
INFO - 2025-05-28 15:32:34 --> Utf8 Class Initialized
INFO - 2025-05-28 15:32:34 --> URI Class Initialized
INFO - 2025-05-28 15:32:34 --> Router Class Initialized
INFO - 2025-05-28 15:32:34 --> Output Class Initialized
INFO - 2025-05-28 15:32:34 --> Security Class Initialized
DEBUG - 2025-05-28 15:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 15:32:34 --> Input Class Initialized
INFO - 2025-05-28 15:32:34 --> Language Class Initialized
INFO - 2025-05-28 15:32:34 --> Loader Class Initialized
INFO - 2025-05-28 15:32:34 --> Helper loaded: url_helper
INFO - 2025-05-28 15:32:34 --> Helper loaded: form_helper
INFO - 2025-05-28 15:32:34 --> Database Driver Class Initialized
DEBUG - 2025-05-28 15:32:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 15:32:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 15:32:34 --> Controller Class Initialized
INFO - 2025-05-28 15:32:34 --> Model "Olahraga_model" initialized
INFO - 2025-05-28 15:32:34 --> Model "User_model" initialized
INFO - 2025-05-28 15:32:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-28 15:32:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-28 15:32:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-05-28 15:32:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-28 15:32:34 --> Final output sent to browser
DEBUG - 2025-05-28 15:32:34 --> Total execution time: 0.0732
INFO - 2025-05-28 15:32:54 --> Config Class Initialized
INFO - 2025-05-28 15:32:54 --> Hooks Class Initialized
DEBUG - 2025-05-28 15:32:54 --> UTF-8 Support Enabled
INFO - 2025-05-28 15:32:54 --> Utf8 Class Initialized
INFO - 2025-05-28 15:32:54 --> URI Class Initialized
INFO - 2025-05-28 15:32:54 --> Router Class Initialized
INFO - 2025-05-28 15:32:54 --> Output Class Initialized
INFO - 2025-05-28 15:32:54 --> Security Class Initialized
DEBUG - 2025-05-28 15:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 15:32:54 --> Input Class Initialized
INFO - 2025-05-28 15:32:54 --> Language Class Initialized
INFO - 2025-05-28 15:32:54 --> Loader Class Initialized
INFO - 2025-05-28 15:32:54 --> Helper loaded: url_helper
INFO - 2025-05-28 15:32:54 --> Helper loaded: form_helper
INFO - 2025-05-28 15:32:54 --> Database Driver Class Initialized
DEBUG - 2025-05-28 15:32:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 15:32:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 15:32:54 --> Controller Class Initialized
INFO - 2025-05-28 15:32:54 --> Model "Olahraga_model" initialized
INFO - 2025-05-28 15:32:54 --> Model "User_model" initialized
INFO - 2025-05-28 15:32:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-28 15:32:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-28 15:32:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-05-28 15:32:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-28 15:32:54 --> Final output sent to browser
DEBUG - 2025-05-28 15:32:54 --> Total execution time: 0.0799
INFO - 2025-05-28 15:33:06 --> Config Class Initialized
INFO - 2025-05-28 15:33:06 --> Hooks Class Initialized
DEBUG - 2025-05-28 15:33:06 --> UTF-8 Support Enabled
INFO - 2025-05-28 15:33:06 --> Utf8 Class Initialized
INFO - 2025-05-28 15:33:06 --> URI Class Initialized
INFO - 2025-05-28 15:33:06 --> Router Class Initialized
INFO - 2025-05-28 15:33:06 --> Output Class Initialized
INFO - 2025-05-28 15:33:06 --> Security Class Initialized
DEBUG - 2025-05-28 15:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 15:33:06 --> Input Class Initialized
INFO - 2025-05-28 15:33:06 --> Language Class Initialized
INFO - 2025-05-28 15:33:06 --> Loader Class Initialized
INFO - 2025-05-28 15:33:06 --> Helper loaded: url_helper
INFO - 2025-05-28 15:33:06 --> Helper loaded: form_helper
INFO - 2025-05-28 15:33:06 --> Database Driver Class Initialized
DEBUG - 2025-05-28 15:33:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 15:33:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 15:33:06 --> Controller Class Initialized
INFO - 2025-05-28 15:33:06 --> Model "Olahraga_model" initialized
INFO - 2025-05-28 15:33:06 --> Model "User_model" initialized
INFO - 2025-05-28 15:33:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-28 15:33:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-28 15:33:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-05-28 15:33:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-28 15:33:06 --> Final output sent to browser
DEBUG - 2025-05-28 15:33:06 --> Total execution time: 0.0666
INFO - 2025-05-28 15:34:11 --> Config Class Initialized
INFO - 2025-05-28 15:34:11 --> Hooks Class Initialized
DEBUG - 2025-05-28 15:34:11 --> UTF-8 Support Enabled
INFO - 2025-05-28 15:34:11 --> Utf8 Class Initialized
INFO - 2025-05-28 15:34:11 --> URI Class Initialized
INFO - 2025-05-28 15:34:11 --> Router Class Initialized
INFO - 2025-05-28 15:34:11 --> Output Class Initialized
INFO - 2025-05-28 15:34:11 --> Security Class Initialized
DEBUG - 2025-05-28 15:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 15:34:11 --> Input Class Initialized
INFO - 2025-05-28 15:34:11 --> Language Class Initialized
INFO - 2025-05-28 15:34:11 --> Loader Class Initialized
INFO - 2025-05-28 15:34:11 --> Helper loaded: url_helper
INFO - 2025-05-28 15:34:11 --> Helper loaded: form_helper
INFO - 2025-05-28 15:34:11 --> Database Driver Class Initialized
DEBUG - 2025-05-28 15:34:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 15:34:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 15:34:11 --> Controller Class Initialized
INFO - 2025-05-28 15:34:11 --> Model "Olahraga_model" initialized
INFO - 2025-05-28 15:34:11 --> Model "User_model" initialized
INFO - 2025-05-28 15:34:11 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-28 15:34:11 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-28 15:34:11 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-05-28 15:34:11 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-28 15:34:11 --> Final output sent to browser
DEBUG - 2025-05-28 15:34:11 --> Total execution time: 0.0859
INFO - 2025-05-28 17:41:03 --> Config Class Initialized
INFO - 2025-05-28 17:41:03 --> Hooks Class Initialized
DEBUG - 2025-05-28 17:41:03 --> UTF-8 Support Enabled
INFO - 2025-05-28 17:41:03 --> Utf8 Class Initialized
INFO - 2025-05-28 17:41:03 --> URI Class Initialized
INFO - 2025-05-28 17:41:03 --> Router Class Initialized
INFO - 2025-05-28 17:41:03 --> Output Class Initialized
INFO - 2025-05-28 17:41:03 --> Security Class Initialized
DEBUG - 2025-05-28 17:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 17:41:03 --> Input Class Initialized
INFO - 2025-05-28 17:41:03 --> Language Class Initialized
INFO - 2025-05-28 17:41:03 --> Loader Class Initialized
INFO - 2025-05-28 17:41:03 --> Helper loaded: url_helper
INFO - 2025-05-28 17:41:03 --> Helper loaded: form_helper
INFO - 2025-05-28 17:41:03 --> Database Driver Class Initialized
DEBUG - 2025-05-28 17:41:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 17:41:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 17:41:03 --> Controller Class Initialized
INFO - 2025-05-28 17:41:03 --> Model "Olahraga_model" initialized
INFO - 2025-05-28 17:41:03 --> Model "User_model" initialized
INFO - 2025-05-28 17:41:03 --> Config Class Initialized
INFO - 2025-05-28 17:41:03 --> Hooks Class Initialized
DEBUG - 2025-05-28 17:41:03 --> UTF-8 Support Enabled
INFO - 2025-05-28 17:41:03 --> Utf8 Class Initialized
INFO - 2025-05-28 17:41:03 --> URI Class Initialized
INFO - 2025-05-28 17:41:03 --> Router Class Initialized
INFO - 2025-05-28 17:41:03 --> Output Class Initialized
INFO - 2025-05-28 17:41:03 --> Security Class Initialized
DEBUG - 2025-05-28 17:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 17:41:03 --> Input Class Initialized
INFO - 2025-05-28 17:41:03 --> Language Class Initialized
INFO - 2025-05-28 17:41:03 --> Loader Class Initialized
INFO - 2025-05-28 17:41:03 --> Helper loaded: url_helper
INFO - 2025-05-28 17:41:03 --> Helper loaded: form_helper
INFO - 2025-05-28 17:41:03 --> Database Driver Class Initialized
DEBUG - 2025-05-28 17:41:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 17:41:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 17:41:03 --> Controller Class Initialized
INFO - 2025-05-28 17:41:03 --> Model "User_model" initialized
INFO - 2025-05-28 17:41:03 --> Form Validation Class Initialized
INFO - 2025-05-28 17:41:03 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-28 17:41:03 --> Final output sent to browser
DEBUG - 2025-05-28 17:41:03 --> Total execution time: 0.1444
INFO - 2025-05-28 17:41:16 --> Config Class Initialized
INFO - 2025-05-28 17:41:16 --> Hooks Class Initialized
DEBUG - 2025-05-28 17:41:16 --> UTF-8 Support Enabled
INFO - 2025-05-28 17:41:16 --> Utf8 Class Initialized
INFO - 2025-05-28 17:41:16 --> URI Class Initialized
INFO - 2025-05-28 17:41:16 --> Router Class Initialized
INFO - 2025-05-28 17:41:16 --> Output Class Initialized
INFO - 2025-05-28 17:41:16 --> Security Class Initialized
DEBUG - 2025-05-28 17:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 17:41:16 --> Input Class Initialized
INFO - 2025-05-28 17:41:16 --> Language Class Initialized
INFO - 2025-05-28 17:41:17 --> Loader Class Initialized
INFO - 2025-05-28 17:41:17 --> Helper loaded: url_helper
INFO - 2025-05-28 17:41:17 --> Helper loaded: form_helper
INFO - 2025-05-28 17:41:17 --> Database Driver Class Initialized
DEBUG - 2025-05-28 17:41:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 17:41:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 17:41:17 --> Controller Class Initialized
INFO - 2025-05-28 17:41:17 --> Model "User_model" initialized
INFO - 2025-05-28 17:41:17 --> Form Validation Class Initialized
INFO - 2025-05-28 17:41:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-05-28 17:41:17 --> Config Class Initialized
INFO - 2025-05-28 17:41:17 --> Hooks Class Initialized
DEBUG - 2025-05-28 17:41:17 --> UTF-8 Support Enabled
INFO - 2025-05-28 17:41:17 --> Utf8 Class Initialized
INFO - 2025-05-28 17:41:17 --> URI Class Initialized
INFO - 2025-05-28 17:41:17 --> Router Class Initialized
INFO - 2025-05-28 17:41:17 --> Output Class Initialized
INFO - 2025-05-28 17:41:17 --> Security Class Initialized
DEBUG - 2025-05-28 17:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 17:41:17 --> Input Class Initialized
INFO - 2025-05-28 17:41:17 --> Language Class Initialized
INFO - 2025-05-28 17:41:17 --> Loader Class Initialized
INFO - 2025-05-28 17:41:17 --> Helper loaded: url_helper
INFO - 2025-05-28 17:41:17 --> Helper loaded: form_helper
INFO - 2025-05-28 17:41:17 --> Database Driver Class Initialized
DEBUG - 2025-05-28 17:41:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 17:41:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 17:41:17 --> Controller Class Initialized
INFO - 2025-05-28 17:41:17 --> Model "User_model" initialized
INFO - 2025-05-28 17:41:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-28 17:41:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-28 17:41:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-28 17:41:17 --> Final output sent to browser
DEBUG - 2025-05-28 17:41:17 --> Total execution time: 0.0921
INFO - 2025-05-28 17:41:19 --> Config Class Initialized
INFO - 2025-05-28 17:41:19 --> Hooks Class Initialized
DEBUG - 2025-05-28 17:41:19 --> UTF-8 Support Enabled
INFO - 2025-05-28 17:41:19 --> Utf8 Class Initialized
INFO - 2025-05-28 17:41:19 --> URI Class Initialized
INFO - 2025-05-28 17:41:19 --> Router Class Initialized
INFO - 2025-05-28 17:41:19 --> Output Class Initialized
INFO - 2025-05-28 17:41:19 --> Security Class Initialized
DEBUG - 2025-05-28 17:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 17:41:19 --> Input Class Initialized
INFO - 2025-05-28 17:41:19 --> Language Class Initialized
INFO - 2025-05-28 17:41:19 --> Loader Class Initialized
INFO - 2025-05-28 17:41:19 --> Helper loaded: url_helper
INFO - 2025-05-28 17:41:19 --> Helper loaded: form_helper
INFO - 2025-05-28 17:41:19 --> Database Driver Class Initialized
DEBUG - 2025-05-28 17:41:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 17:41:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 17:41:19 --> Controller Class Initialized
INFO - 2025-05-28 17:41:19 --> Model "User_model" initialized
INFO - 2025-05-28 17:41:19 --> Model "Progress_model" initialized
INFO - 2025-05-28 17:41:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-28 17:41:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-28 17:41:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-28 17:41:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-28 17:41:19 --> Final output sent to browser
DEBUG - 2025-05-28 17:41:19 --> Total execution time: 0.1148
INFO - 2025-05-28 17:41:30 --> Config Class Initialized
INFO - 2025-05-28 17:41:30 --> Hooks Class Initialized
DEBUG - 2025-05-28 17:41:30 --> UTF-8 Support Enabled
INFO - 2025-05-28 17:41:30 --> Utf8 Class Initialized
INFO - 2025-05-28 17:41:30 --> URI Class Initialized
INFO - 2025-05-28 17:41:30 --> Router Class Initialized
INFO - 2025-05-28 17:41:30 --> Output Class Initialized
INFO - 2025-05-28 17:41:30 --> Security Class Initialized
DEBUG - 2025-05-28 17:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 17:41:30 --> Input Class Initialized
INFO - 2025-05-28 17:41:30 --> Language Class Initialized
INFO - 2025-05-28 17:41:30 --> Loader Class Initialized
INFO - 2025-05-28 17:41:30 --> Helper loaded: url_helper
INFO - 2025-05-28 17:41:30 --> Helper loaded: form_helper
INFO - 2025-05-28 17:41:30 --> Database Driver Class Initialized
DEBUG - 2025-05-28 17:41:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 17:41:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 17:41:30 --> Controller Class Initialized
INFO - 2025-05-28 17:41:30 --> Model "Olahraga_model" initialized
INFO - 2025-05-28 17:41:30 --> Model "User_model" initialized
INFO - 2025-05-28 17:41:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-28 17:41:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-28 17:41:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-05-28 17:41:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-28 17:41:30 --> Final output sent to browser
DEBUG - 2025-05-28 17:41:30 --> Total execution time: 0.1142
INFO - 2025-05-28 17:41:34 --> Config Class Initialized
INFO - 2025-05-28 17:41:34 --> Hooks Class Initialized
DEBUG - 2025-05-28 17:41:34 --> UTF-8 Support Enabled
INFO - 2025-05-28 17:41:34 --> Utf8 Class Initialized
INFO - 2025-05-28 17:41:34 --> URI Class Initialized
INFO - 2025-05-28 17:41:34 --> Router Class Initialized
INFO - 2025-05-28 17:41:34 --> Output Class Initialized
INFO - 2025-05-28 17:41:34 --> Security Class Initialized
DEBUG - 2025-05-28 17:41:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 17:41:34 --> Input Class Initialized
INFO - 2025-05-28 17:41:34 --> Language Class Initialized
INFO - 2025-05-28 17:41:34 --> Loader Class Initialized
INFO - 2025-05-28 17:41:34 --> Helper loaded: url_helper
INFO - 2025-05-28 17:41:34 --> Helper loaded: form_helper
INFO - 2025-05-28 17:41:34 --> Database Driver Class Initialized
DEBUG - 2025-05-28 17:41:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 17:41:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 17:41:34 --> Controller Class Initialized
INFO - 2025-05-28 17:41:34 --> Model "Olahraga_model" initialized
INFO - 2025-05-28 17:41:34 --> Model "User_model" initialized
INFO - 2025-05-28 17:41:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-28 17:41:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-28 17:41:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-05-28 17:41:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-28 17:41:34 --> Final output sent to browser
DEBUG - 2025-05-28 17:41:34 --> Total execution time: 0.0823
INFO - 2025-05-28 17:42:38 --> Config Class Initialized
INFO - 2025-05-28 17:42:38 --> Hooks Class Initialized
DEBUG - 2025-05-28 17:42:38 --> UTF-8 Support Enabled
INFO - 2025-05-28 17:42:38 --> Utf8 Class Initialized
INFO - 2025-05-28 17:42:38 --> URI Class Initialized
INFO - 2025-05-28 17:42:38 --> Router Class Initialized
INFO - 2025-05-28 17:42:38 --> Output Class Initialized
INFO - 2025-05-28 17:42:38 --> Security Class Initialized
DEBUG - 2025-05-28 17:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 17:42:38 --> Input Class Initialized
INFO - 2025-05-28 17:42:38 --> Language Class Initialized
INFO - 2025-05-28 17:42:38 --> Loader Class Initialized
INFO - 2025-05-28 17:42:38 --> Helper loaded: url_helper
INFO - 2025-05-28 17:42:38 --> Helper loaded: form_helper
INFO - 2025-05-28 17:42:38 --> Database Driver Class Initialized
DEBUG - 2025-05-28 17:42:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 17:42:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 17:42:38 --> Controller Class Initialized
INFO - 2025-05-28 17:42:38 --> Model "Olahraga_model" initialized
INFO - 2025-05-28 17:42:38 --> Model "User_model" initialized
INFO - 2025-05-28 17:42:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-28 17:42:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-28 17:42:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-05-28 17:42:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-28 17:42:38 --> Final output sent to browser
DEBUG - 2025-05-28 17:42:38 --> Total execution time: 0.0773
INFO - 2025-05-28 17:43:39 --> Config Class Initialized
INFO - 2025-05-28 17:43:39 --> Hooks Class Initialized
DEBUG - 2025-05-28 17:43:39 --> UTF-8 Support Enabled
INFO - 2025-05-28 17:43:39 --> Utf8 Class Initialized
INFO - 2025-05-28 17:43:39 --> URI Class Initialized
INFO - 2025-05-28 17:43:39 --> Router Class Initialized
INFO - 2025-05-28 17:43:39 --> Output Class Initialized
INFO - 2025-05-28 17:43:39 --> Security Class Initialized
DEBUG - 2025-05-28 17:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 17:43:39 --> Input Class Initialized
INFO - 2025-05-28 17:43:39 --> Language Class Initialized
INFO - 2025-05-28 17:43:39 --> Loader Class Initialized
INFO - 2025-05-28 17:43:39 --> Helper loaded: url_helper
INFO - 2025-05-28 17:43:39 --> Helper loaded: form_helper
INFO - 2025-05-28 17:43:39 --> Database Driver Class Initialized
DEBUG - 2025-05-28 17:43:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 17:43:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 17:43:39 --> Controller Class Initialized
INFO - 2025-05-28 17:43:39 --> Model "Olahraga_model" initialized
INFO - 2025-05-28 17:43:39 --> Model "User_model" initialized
INFO - 2025-05-28 17:43:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-28 17:43:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-28 17:43:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-05-28 17:43:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-28 17:43:39 --> Final output sent to browser
DEBUG - 2025-05-28 17:43:39 --> Total execution time: 0.0680
INFO - 2025-05-28 18:21:16 --> Config Class Initialized
INFO - 2025-05-28 18:21:16 --> Hooks Class Initialized
DEBUG - 2025-05-28 18:21:16 --> UTF-8 Support Enabled
INFO - 2025-05-28 18:21:16 --> Utf8 Class Initialized
INFO - 2025-05-28 18:21:16 --> URI Class Initialized
INFO - 2025-05-28 18:21:16 --> Router Class Initialized
INFO - 2025-05-28 18:21:16 --> Output Class Initialized
INFO - 2025-05-28 18:21:16 --> Security Class Initialized
DEBUG - 2025-05-28 18:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-28 18:21:16 --> Input Class Initialized
INFO - 2025-05-28 18:21:16 --> Language Class Initialized
INFO - 2025-05-28 18:21:16 --> Loader Class Initialized
INFO - 2025-05-28 18:21:16 --> Helper loaded: url_helper
INFO - 2025-05-28 18:21:16 --> Helper loaded: form_helper
INFO - 2025-05-28 18:21:16 --> Database Driver Class Initialized
DEBUG - 2025-05-28 18:21:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-28 18:21:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-28 18:21:16 --> Controller Class Initialized
INFO - 2025-05-28 18:21:16 --> Model "Olahraga_model" initialized
INFO - 2025-05-28 18:21:16 --> Model "User_model" initialized
INFO - 2025-05-28 18:21:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-28 18:21:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-28 18:21:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-05-28 18:21:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-28 18:21:16 --> Final output sent to browser
DEBUG - 2025-05-28 18:21:16 --> Total execution time: 0.0832
