<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-07-13 11:04:06 --> Config Class Initialized
INFO - 2025-07-13 11:04:06 --> Hooks Class Initialized
DEBUG - 2025-07-13 11:04:06 --> UTF-8 Support Enabled
INFO - 2025-07-13 11:04:06 --> Utf8 Class Initialized
INFO - 2025-07-13 11:04:06 --> URI Class Initialized
DEBUG - 2025-07-13 11:04:06 --> No URI present. Default controller set.
INFO - 2025-07-13 11:04:06 --> Router Class Initialized
INFO - 2025-07-13 11:04:06 --> Output Class Initialized
INFO - 2025-07-13 11:04:06 --> Security Class Initialized
DEBUG - 2025-07-13 11:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 11:04:06 --> Input Class Initialized
INFO - 2025-07-13 11:04:06 --> Language Class Initialized
INFO - 2025-07-13 11:04:06 --> Loader Class Initialized
INFO - 2025-07-13 11:04:06 --> Helper loaded: url_helper
INFO - 2025-07-13 11:04:06 --> Helper loaded: form_helper
INFO - 2025-07-13 11:04:06 --> Database Driver Class Initialized
DEBUG - 2025-07-13 11:04:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 11:04:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 11:04:06 --> Controller Class Initialized
INFO - 2025-07-13 11:04:06 --> Model "User_model" initialized
INFO - 2025-07-13 11:04:06 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-07-13 11:04:06 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/home.php
INFO - 2025-07-13 11:04:06 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-07-13 11:04:06 --> Final output sent to browser
DEBUG - 2025-07-13 11:04:06 --> Total execution time: 0.1439
INFO - 2025-07-13 11:04:09 --> Config Class Initialized
INFO - 2025-07-13 11:04:09 --> Hooks Class Initialized
DEBUG - 2025-07-13 11:04:09 --> UTF-8 Support Enabled
INFO - 2025-07-13 11:04:09 --> Utf8 Class Initialized
INFO - 2025-07-13 11:04:09 --> URI Class Initialized
INFO - 2025-07-13 11:04:09 --> Router Class Initialized
INFO - 2025-07-13 11:04:09 --> Output Class Initialized
INFO - 2025-07-13 11:04:09 --> Security Class Initialized
DEBUG - 2025-07-13 11:04:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 11:04:09 --> Input Class Initialized
INFO - 2025-07-13 11:04:09 --> Language Class Initialized
INFO - 2025-07-13 11:04:09 --> Loader Class Initialized
INFO - 2025-07-13 11:04:09 --> Helper loaded: url_helper
INFO - 2025-07-13 11:04:09 --> Helper loaded: form_helper
INFO - 2025-07-13 11:04:09 --> Database Driver Class Initialized
DEBUG - 2025-07-13 11:04:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 11:04:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 11:04:09 --> Controller Class Initialized
INFO - 2025-07-13 11:04:09 --> Model "User_model" initialized
INFO - 2025-07-13 11:04:09 --> Form Validation Class Initialized
INFO - 2025-07-13 11:04:09 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\auth/login.php
INFO - 2025-07-13 11:04:09 --> Final output sent to browser
DEBUG - 2025-07-13 11:04:09 --> Total execution time: 0.1122
INFO - 2025-07-13 11:04:14 --> Config Class Initialized
INFO - 2025-07-13 11:04:14 --> Hooks Class Initialized
DEBUG - 2025-07-13 11:04:14 --> UTF-8 Support Enabled
INFO - 2025-07-13 11:04:14 --> Utf8 Class Initialized
INFO - 2025-07-13 11:04:14 --> URI Class Initialized
INFO - 2025-07-13 11:04:14 --> Router Class Initialized
INFO - 2025-07-13 11:04:14 --> Output Class Initialized
INFO - 2025-07-13 11:04:14 --> Security Class Initialized
DEBUG - 2025-07-13 11:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 11:04:14 --> Input Class Initialized
INFO - 2025-07-13 11:04:14 --> Language Class Initialized
INFO - 2025-07-13 11:04:14 --> Loader Class Initialized
INFO - 2025-07-13 11:04:14 --> Helper loaded: url_helper
INFO - 2025-07-13 11:04:14 --> Helper loaded: form_helper
INFO - 2025-07-13 11:04:14 --> Database Driver Class Initialized
DEBUG - 2025-07-13 11:04:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 11:04:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 11:04:14 --> Controller Class Initialized
INFO - 2025-07-13 11:04:14 --> Model "User_model" initialized
INFO - 2025-07-13 11:04:14 --> Form Validation Class Initialized
INFO - 2025-07-13 11:04:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-07-13 11:04:14 --> Config Class Initialized
INFO - 2025-07-13 11:04:14 --> Hooks Class Initialized
DEBUG - 2025-07-13 11:04:14 --> UTF-8 Support Enabled
INFO - 2025-07-13 11:04:14 --> Utf8 Class Initialized
INFO - 2025-07-13 11:04:14 --> URI Class Initialized
INFO - 2025-07-13 11:04:14 --> Router Class Initialized
INFO - 2025-07-13 11:04:14 --> Output Class Initialized
INFO - 2025-07-13 11:04:14 --> Security Class Initialized
DEBUG - 2025-07-13 11:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 11:04:14 --> Input Class Initialized
INFO - 2025-07-13 11:04:14 --> Language Class Initialized
INFO - 2025-07-13 11:04:14 --> Loader Class Initialized
INFO - 2025-07-13 11:04:14 --> Helper loaded: url_helper
INFO - 2025-07-13 11:04:14 --> Helper loaded: form_helper
INFO - 2025-07-13 11:04:14 --> Database Driver Class Initialized
DEBUG - 2025-07-13 11:04:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 11:04:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 11:04:14 --> Controller Class Initialized
INFO - 2025-07-13 11:04:14 --> Model "User_model" initialized
INFO - 2025-07-13 11:04:14 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-07-13 11:04:14 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/home.php
INFO - 2025-07-13 11:04:14 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-07-13 11:04:14 --> Final output sent to browser
DEBUG - 2025-07-13 11:04:14 --> Total execution time: 0.0912
INFO - 2025-07-13 11:04:18 --> Config Class Initialized
INFO - 2025-07-13 11:04:18 --> Hooks Class Initialized
DEBUG - 2025-07-13 11:04:18 --> UTF-8 Support Enabled
INFO - 2025-07-13 11:04:18 --> Utf8 Class Initialized
INFO - 2025-07-13 11:04:18 --> URI Class Initialized
INFO - 2025-07-13 11:04:18 --> Router Class Initialized
INFO - 2025-07-13 11:04:18 --> Output Class Initialized
INFO - 2025-07-13 11:04:18 --> Security Class Initialized
DEBUG - 2025-07-13 11:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 11:04:18 --> Input Class Initialized
INFO - 2025-07-13 11:04:18 --> Language Class Initialized
INFO - 2025-07-13 11:04:18 --> Loader Class Initialized
INFO - 2025-07-13 11:04:18 --> Helper loaded: url_helper
INFO - 2025-07-13 11:04:18 --> Helper loaded: form_helper
INFO - 2025-07-13 11:04:18 --> Database Driver Class Initialized
DEBUG - 2025-07-13 11:04:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 11:04:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 11:04:18 --> Controller Class Initialized
INFO - 2025-07-13 11:04:18 --> Model "User_model" initialized
INFO - 2025-07-13 11:04:18 --> Model "Progress_model" initialized
INFO - 2025-07-13 11:04:18 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-13 11:04:18 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-13 11:04:18 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/dashboard.php
INFO - 2025-07-13 11:04:18 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-13 11:04:18 --> Final output sent to browser
DEBUG - 2025-07-13 11:04:18 --> Total execution time: 0.1205
INFO - 2025-07-13 11:04:21 --> Config Class Initialized
INFO - 2025-07-13 11:04:21 --> Hooks Class Initialized
DEBUG - 2025-07-13 11:04:21 --> UTF-8 Support Enabled
INFO - 2025-07-13 11:04:21 --> Utf8 Class Initialized
INFO - 2025-07-13 11:04:21 --> URI Class Initialized
INFO - 2025-07-13 11:04:21 --> Router Class Initialized
INFO - 2025-07-13 11:04:21 --> Output Class Initialized
INFO - 2025-07-13 11:04:21 --> Security Class Initialized
DEBUG - 2025-07-13 11:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 11:04:21 --> Input Class Initialized
INFO - 2025-07-13 11:04:21 --> Language Class Initialized
INFO - 2025-07-13 11:04:21 --> Loader Class Initialized
INFO - 2025-07-13 11:04:21 --> Helper loaded: url_helper
INFO - 2025-07-13 11:04:21 --> Helper loaded: form_helper
INFO - 2025-07-13 11:04:21 --> Database Driver Class Initialized
DEBUG - 2025-07-13 11:04:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 11:04:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 11:04:21 --> Controller Class Initialized
INFO - 2025-07-13 11:04:21 --> Model "Olahraga_model" initialized
INFO - 2025-07-13 11:04:21 --> Model "User_model" initialized
INFO - 2025-07-13 11:04:21 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-13 11:04:21 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-13 11:04:21 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-07-13 11:04:21 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-13 11:04:21 --> Final output sent to browser
DEBUG - 2025-07-13 11:04:21 --> Total execution time: 0.0950
INFO - 2025-07-13 11:04:23 --> Config Class Initialized
INFO - 2025-07-13 11:04:23 --> Hooks Class Initialized
DEBUG - 2025-07-13 11:04:23 --> UTF-8 Support Enabled
INFO - 2025-07-13 11:04:23 --> Utf8 Class Initialized
INFO - 2025-07-13 11:04:23 --> URI Class Initialized
INFO - 2025-07-13 11:04:23 --> Router Class Initialized
INFO - 2025-07-13 11:04:23 --> Output Class Initialized
INFO - 2025-07-13 11:04:23 --> Security Class Initialized
DEBUG - 2025-07-13 11:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 11:04:23 --> Input Class Initialized
INFO - 2025-07-13 11:04:23 --> Language Class Initialized
INFO - 2025-07-13 11:04:23 --> Loader Class Initialized
INFO - 2025-07-13 11:04:23 --> Helper loaded: url_helper
INFO - 2025-07-13 11:04:23 --> Helper loaded: form_helper
INFO - 2025-07-13 11:04:23 --> Database Driver Class Initialized
DEBUG - 2025-07-13 11:04:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 11:04:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 11:04:23 --> Controller Class Initialized
INFO - 2025-07-13 11:04:23 --> Model "Olahraga_model" initialized
INFO - 2025-07-13 11:04:23 --> Model "User_model" initialized
INFO - 2025-07-13 11:04:23 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-13 11:04:23 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-13 11:04:23 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/level.php
INFO - 2025-07-13 11:04:23 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-13 11:04:23 --> Final output sent to browser
DEBUG - 2025-07-13 11:04:23 --> Total execution time: 0.0848
INFO - 2025-07-13 11:04:25 --> Config Class Initialized
INFO - 2025-07-13 11:04:25 --> Hooks Class Initialized
DEBUG - 2025-07-13 11:04:25 --> UTF-8 Support Enabled
INFO - 2025-07-13 11:04:25 --> Utf8 Class Initialized
INFO - 2025-07-13 11:04:25 --> URI Class Initialized
INFO - 2025-07-13 11:04:25 --> Router Class Initialized
INFO - 2025-07-13 11:04:25 --> Output Class Initialized
INFO - 2025-07-13 11:04:25 --> Security Class Initialized
DEBUG - 2025-07-13 11:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 11:04:25 --> Input Class Initialized
INFO - 2025-07-13 11:04:25 --> Language Class Initialized
INFO - 2025-07-13 11:04:25 --> Loader Class Initialized
INFO - 2025-07-13 11:04:25 --> Helper loaded: url_helper
INFO - 2025-07-13 11:04:25 --> Helper loaded: form_helper
INFO - 2025-07-13 11:04:25 --> Database Driver Class Initialized
DEBUG - 2025-07-13 11:04:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 11:04:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 11:04:25 --> Controller Class Initialized
INFO - 2025-07-13 11:04:25 --> Model "Olahraga_model" initialized
INFO - 2025-07-13 11:04:25 --> Model "User_model" initialized
INFO - 2025-07-13 11:04:25 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-13 11:04:25 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-13 11:04:25 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-07-13 11:04:25 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-13 11:04:25 --> Final output sent to browser
DEBUG - 2025-07-13 11:04:25 --> Total execution time: 0.0907
INFO - 2025-07-13 11:04:30 --> Config Class Initialized
INFO - 2025-07-13 11:04:30 --> Hooks Class Initialized
DEBUG - 2025-07-13 11:04:30 --> UTF-8 Support Enabled
INFO - 2025-07-13 11:04:30 --> Utf8 Class Initialized
INFO - 2025-07-13 11:04:30 --> URI Class Initialized
INFO - 2025-07-13 11:04:30 --> Router Class Initialized
INFO - 2025-07-13 11:04:30 --> Output Class Initialized
INFO - 2025-07-13 11:04:30 --> Security Class Initialized
DEBUG - 2025-07-13 11:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 11:04:30 --> Input Class Initialized
INFO - 2025-07-13 11:04:30 --> Language Class Initialized
INFO - 2025-07-13 11:04:30 --> Loader Class Initialized
INFO - 2025-07-13 11:04:30 --> Helper loaded: url_helper
INFO - 2025-07-13 11:04:30 --> Helper loaded: form_helper
INFO - 2025-07-13 11:04:30 --> Database Driver Class Initialized
DEBUG - 2025-07-13 11:04:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 11:04:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 11:04:30 --> Controller Class Initialized
INFO - 2025-07-13 11:04:30 --> Model "User_model" initialized
INFO - 2025-07-13 11:04:30 --> Model "Progress_model" initialized
INFO - 2025-07-13 11:04:30 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-13 11:04:30 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-13 11:04:30 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/dashboard.php
INFO - 2025-07-13 11:04:30 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-13 11:04:30 --> Final output sent to browser
DEBUG - 2025-07-13 11:04:30 --> Total execution time: 0.0920
INFO - 2025-07-13 11:08:35 --> Config Class Initialized
INFO - 2025-07-13 11:08:35 --> Hooks Class Initialized
DEBUG - 2025-07-13 11:08:35 --> UTF-8 Support Enabled
INFO - 2025-07-13 11:08:35 --> Utf8 Class Initialized
INFO - 2025-07-13 11:08:35 --> URI Class Initialized
INFO - 2025-07-13 11:08:35 --> Router Class Initialized
INFO - 2025-07-13 11:08:35 --> Output Class Initialized
INFO - 2025-07-13 11:08:35 --> Security Class Initialized
DEBUG - 2025-07-13 11:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 11:08:35 --> Input Class Initialized
INFO - 2025-07-13 11:08:35 --> Language Class Initialized
INFO - 2025-07-13 11:08:35 --> Loader Class Initialized
INFO - 2025-07-13 11:08:35 --> Helper loaded: url_helper
INFO - 2025-07-13 11:08:35 --> Helper loaded: form_helper
INFO - 2025-07-13 11:08:35 --> Database Driver Class Initialized
DEBUG - 2025-07-13 11:08:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 11:08:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 11:08:35 --> Controller Class Initialized
INFO - 2025-07-13 11:08:35 --> Model "User_model" initialized
INFO - 2025-07-13 11:08:35 --> Form Validation Class Initialized
INFO - 2025-07-13 11:08:35 --> Config Class Initialized
INFO - 2025-07-13 11:08:35 --> Hooks Class Initialized
DEBUG - 2025-07-13 11:08:35 --> UTF-8 Support Enabled
INFO - 2025-07-13 11:08:35 --> Utf8 Class Initialized
INFO - 2025-07-13 11:08:35 --> URI Class Initialized
INFO - 2025-07-13 11:08:35 --> Router Class Initialized
INFO - 2025-07-13 11:08:35 --> Output Class Initialized
INFO - 2025-07-13 11:08:35 --> Security Class Initialized
DEBUG - 2025-07-13 11:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 11:08:35 --> Input Class Initialized
INFO - 2025-07-13 11:08:35 --> Language Class Initialized
INFO - 2025-07-13 11:08:35 --> Loader Class Initialized
INFO - 2025-07-13 11:08:35 --> Helper loaded: url_helper
INFO - 2025-07-13 11:08:35 --> Helper loaded: form_helper
INFO - 2025-07-13 11:08:35 --> Database Driver Class Initialized
DEBUG - 2025-07-13 11:08:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 11:08:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 11:08:35 --> Controller Class Initialized
INFO - 2025-07-13 11:08:35 --> Model "User_model" initialized
INFO - 2025-07-13 11:08:35 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-07-13 11:08:35 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/home.php
INFO - 2025-07-13 11:08:35 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-07-13 11:08:35 --> Final output sent to browser
DEBUG - 2025-07-13 11:08:35 --> Total execution time: 0.0752
INFO - 2025-07-13 11:08:37 --> Config Class Initialized
INFO - 2025-07-13 11:08:37 --> Hooks Class Initialized
DEBUG - 2025-07-13 11:08:37 --> UTF-8 Support Enabled
INFO - 2025-07-13 11:08:37 --> Utf8 Class Initialized
INFO - 2025-07-13 11:08:37 --> URI Class Initialized
INFO - 2025-07-13 11:08:37 --> Router Class Initialized
INFO - 2025-07-13 11:08:37 --> Output Class Initialized
INFO - 2025-07-13 11:08:37 --> Security Class Initialized
DEBUG - 2025-07-13 11:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 11:08:37 --> Input Class Initialized
INFO - 2025-07-13 11:08:37 --> Language Class Initialized
INFO - 2025-07-13 11:08:37 --> Loader Class Initialized
INFO - 2025-07-13 11:08:37 --> Helper loaded: url_helper
INFO - 2025-07-13 11:08:37 --> Helper loaded: form_helper
INFO - 2025-07-13 11:08:37 --> Database Driver Class Initialized
DEBUG - 2025-07-13 11:08:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 11:08:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 11:08:37 --> Controller Class Initialized
INFO - 2025-07-13 11:08:37 --> Model "User_model" initialized
INFO - 2025-07-13 11:08:37 --> Form Validation Class Initialized
INFO - 2025-07-13 11:08:37 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\auth/login.php
INFO - 2025-07-13 11:08:37 --> Final output sent to browser
DEBUG - 2025-07-13 11:08:37 --> Total execution time: 0.0885
INFO - 2025-07-13 11:09:36 --> Config Class Initialized
INFO - 2025-07-13 11:09:36 --> Hooks Class Initialized
DEBUG - 2025-07-13 11:09:36 --> UTF-8 Support Enabled
INFO - 2025-07-13 11:09:36 --> Utf8 Class Initialized
INFO - 2025-07-13 11:09:36 --> URI Class Initialized
INFO - 2025-07-13 11:09:36 --> Router Class Initialized
INFO - 2025-07-13 11:09:36 --> Output Class Initialized
INFO - 2025-07-13 11:09:36 --> Security Class Initialized
DEBUG - 2025-07-13 11:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 11:09:36 --> Input Class Initialized
INFO - 2025-07-13 11:09:36 --> Language Class Initialized
INFO - 2025-07-13 11:09:36 --> Loader Class Initialized
INFO - 2025-07-13 11:09:36 --> Helper loaded: url_helper
INFO - 2025-07-13 11:09:36 --> Helper loaded: form_helper
INFO - 2025-07-13 11:09:36 --> Database Driver Class Initialized
DEBUG - 2025-07-13 11:09:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 11:09:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 11:09:36 --> Controller Class Initialized
INFO - 2025-07-13 11:09:36 --> Model "User_model" initialized
INFO - 2025-07-13 11:09:36 --> Form Validation Class Initialized
DEBUG - 2025-07-13 11:09:36 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-07-13 11:09:36 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\auth/register.php
INFO - 2025-07-13 11:09:36 --> Final output sent to browser
DEBUG - 2025-07-13 11:09:36 --> Total execution time: 0.0872
INFO - 2025-07-13 11:10:28 --> Config Class Initialized
INFO - 2025-07-13 11:10:28 --> Hooks Class Initialized
DEBUG - 2025-07-13 11:10:28 --> UTF-8 Support Enabled
INFO - 2025-07-13 11:10:28 --> Utf8 Class Initialized
INFO - 2025-07-13 11:10:28 --> URI Class Initialized
INFO - 2025-07-13 11:10:28 --> Router Class Initialized
INFO - 2025-07-13 11:10:28 --> Output Class Initialized
INFO - 2025-07-13 11:10:28 --> Security Class Initialized
DEBUG - 2025-07-13 11:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 11:10:28 --> Input Class Initialized
INFO - 2025-07-13 11:10:28 --> Language Class Initialized
INFO - 2025-07-13 11:10:28 --> Loader Class Initialized
INFO - 2025-07-13 11:10:28 --> Helper loaded: url_helper
INFO - 2025-07-13 11:10:28 --> Helper loaded: form_helper
INFO - 2025-07-13 11:10:28 --> Database Driver Class Initialized
DEBUG - 2025-07-13 11:10:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 11:10:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 11:10:28 --> Controller Class Initialized
INFO - 2025-07-13 11:10:28 --> Model "User_model" initialized
INFO - 2025-07-13 11:10:28 --> Form Validation Class Initialized
INFO - 2025-07-13 11:10:28 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\auth/login.php
INFO - 2025-07-13 11:10:28 --> Final output sent to browser
DEBUG - 2025-07-13 11:10:28 --> Total execution time: 0.0811
INFO - 2025-07-13 11:10:33 --> Config Class Initialized
INFO - 2025-07-13 11:10:33 --> Hooks Class Initialized
DEBUG - 2025-07-13 11:10:33 --> UTF-8 Support Enabled
INFO - 2025-07-13 11:10:33 --> Utf8 Class Initialized
INFO - 2025-07-13 11:10:33 --> URI Class Initialized
INFO - 2025-07-13 11:10:33 --> Router Class Initialized
INFO - 2025-07-13 11:10:33 --> Output Class Initialized
INFO - 2025-07-13 11:10:33 --> Security Class Initialized
DEBUG - 2025-07-13 11:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 11:10:33 --> Input Class Initialized
INFO - 2025-07-13 11:10:33 --> Language Class Initialized
INFO - 2025-07-13 11:10:33 --> Loader Class Initialized
INFO - 2025-07-13 11:10:33 --> Helper loaded: url_helper
INFO - 2025-07-13 11:10:33 --> Helper loaded: form_helper
INFO - 2025-07-13 11:10:33 --> Database Driver Class Initialized
DEBUG - 2025-07-13 11:10:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 11:10:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 11:10:33 --> Controller Class Initialized
INFO - 2025-07-13 11:10:33 --> Model "User_model" initialized
INFO - 2025-07-13 11:10:33 --> Form Validation Class Initialized
INFO - 2025-07-13 11:10:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-07-13 11:10:33 --> Config Class Initialized
INFO - 2025-07-13 11:10:33 --> Hooks Class Initialized
DEBUG - 2025-07-13 11:10:33 --> UTF-8 Support Enabled
INFO - 2025-07-13 11:10:33 --> Utf8 Class Initialized
INFO - 2025-07-13 11:10:33 --> URI Class Initialized
INFO - 2025-07-13 11:10:33 --> Router Class Initialized
INFO - 2025-07-13 11:10:33 --> Output Class Initialized
INFO - 2025-07-13 11:10:33 --> Security Class Initialized
DEBUG - 2025-07-13 11:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 11:10:33 --> Input Class Initialized
INFO - 2025-07-13 11:10:33 --> Language Class Initialized
INFO - 2025-07-13 11:10:33 --> Loader Class Initialized
INFO - 2025-07-13 11:10:33 --> Helper loaded: url_helper
INFO - 2025-07-13 11:10:33 --> Helper loaded: form_helper
INFO - 2025-07-13 11:10:33 --> Database Driver Class Initialized
DEBUG - 2025-07-13 11:10:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 11:10:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 11:10:33 --> Controller Class Initialized
INFO - 2025-07-13 11:10:33 --> Model "User_model" initialized
INFO - 2025-07-13 11:10:33 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-07-13 11:10:33 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/home.php
INFO - 2025-07-13 11:10:33 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-07-13 11:10:33 --> Final output sent to browser
DEBUG - 2025-07-13 11:10:33 --> Total execution time: 0.0834
INFO - 2025-07-13 11:10:36 --> Config Class Initialized
INFO - 2025-07-13 11:10:36 --> Hooks Class Initialized
DEBUG - 2025-07-13 11:10:36 --> UTF-8 Support Enabled
INFO - 2025-07-13 11:10:36 --> Utf8 Class Initialized
INFO - 2025-07-13 11:10:36 --> URI Class Initialized
INFO - 2025-07-13 11:10:36 --> Router Class Initialized
INFO - 2025-07-13 11:10:36 --> Output Class Initialized
INFO - 2025-07-13 11:10:36 --> Security Class Initialized
DEBUG - 2025-07-13 11:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 11:10:36 --> Input Class Initialized
INFO - 2025-07-13 11:10:36 --> Language Class Initialized
INFO - 2025-07-13 11:10:36 --> Loader Class Initialized
INFO - 2025-07-13 11:10:36 --> Helper loaded: url_helper
INFO - 2025-07-13 11:10:36 --> Helper loaded: form_helper
INFO - 2025-07-13 11:10:36 --> Database Driver Class Initialized
DEBUG - 2025-07-13 11:10:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 11:10:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 11:10:36 --> Controller Class Initialized
INFO - 2025-07-13 11:10:36 --> Model "User_model" initialized
INFO - 2025-07-13 11:10:36 --> Model "Progress_model" initialized
INFO - 2025-07-13 11:10:36 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-13 11:10:36 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-13 11:10:36 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/dashboard.php
INFO - 2025-07-13 11:10:36 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-13 11:10:36 --> Final output sent to browser
DEBUG - 2025-07-13 11:10:36 --> Total execution time: 0.1582
INFO - 2025-07-13 11:10:39 --> Config Class Initialized
INFO - 2025-07-13 11:10:39 --> Hooks Class Initialized
DEBUG - 2025-07-13 11:10:39 --> UTF-8 Support Enabled
INFO - 2025-07-13 11:10:39 --> Utf8 Class Initialized
INFO - 2025-07-13 11:10:39 --> URI Class Initialized
INFO - 2025-07-13 11:10:39 --> Router Class Initialized
INFO - 2025-07-13 11:10:39 --> Output Class Initialized
INFO - 2025-07-13 11:10:39 --> Security Class Initialized
DEBUG - 2025-07-13 11:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 11:10:39 --> Input Class Initialized
INFO - 2025-07-13 11:10:39 --> Language Class Initialized
INFO - 2025-07-13 11:10:39 --> Loader Class Initialized
INFO - 2025-07-13 11:10:39 --> Helper loaded: url_helper
INFO - 2025-07-13 11:10:39 --> Helper loaded: form_helper
INFO - 2025-07-13 11:10:39 --> Database Driver Class Initialized
DEBUG - 2025-07-13 11:10:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 11:10:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 11:10:39 --> Controller Class Initialized
INFO - 2025-07-13 11:10:39 --> Model "User_model" initialized
INFO - 2025-07-13 11:10:39 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-13 11:10:39 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-13 11:10:39 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/profile.php
INFO - 2025-07-13 11:10:39 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-13 11:10:39 --> Final output sent to browser
DEBUG - 2025-07-13 11:10:39 --> Total execution time: 0.0833
INFO - 2025-07-13 11:10:42 --> Config Class Initialized
INFO - 2025-07-13 11:10:42 --> Hooks Class Initialized
DEBUG - 2025-07-13 11:10:42 --> UTF-8 Support Enabled
INFO - 2025-07-13 11:10:42 --> Utf8 Class Initialized
INFO - 2025-07-13 11:10:42 --> URI Class Initialized
INFO - 2025-07-13 11:10:42 --> Router Class Initialized
INFO - 2025-07-13 11:10:42 --> Output Class Initialized
INFO - 2025-07-13 11:10:42 --> Security Class Initialized
DEBUG - 2025-07-13 11:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 11:10:42 --> Input Class Initialized
INFO - 2025-07-13 11:10:42 --> Language Class Initialized
INFO - 2025-07-13 11:10:42 --> Loader Class Initialized
INFO - 2025-07-13 11:10:42 --> Helper loaded: url_helper
INFO - 2025-07-13 11:10:42 --> Helper loaded: form_helper
INFO - 2025-07-13 11:10:42 --> Database Driver Class Initialized
DEBUG - 2025-07-13 11:10:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 11:10:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 11:10:42 --> Controller Class Initialized
INFO - 2025-07-13 11:10:42 --> Model "User_model" initialized
INFO - 2025-07-13 11:10:42 --> Form Validation Class Initialized
INFO - 2025-07-13 11:10:42 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-13 11:10:42 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-13 11:10:42 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/edit_profile.php
INFO - 2025-07-13 11:10:42 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-13 11:10:42 --> Final output sent to browser
DEBUG - 2025-07-13 11:10:42 --> Total execution time: 0.0937
INFO - 2025-07-13 11:12:10 --> Config Class Initialized
INFO - 2025-07-13 11:12:10 --> Hooks Class Initialized
DEBUG - 2025-07-13 11:12:10 --> UTF-8 Support Enabled
INFO - 2025-07-13 11:12:10 --> Utf8 Class Initialized
INFO - 2025-07-13 11:12:10 --> URI Class Initialized
INFO - 2025-07-13 11:12:10 --> Router Class Initialized
INFO - 2025-07-13 11:12:10 --> Output Class Initialized
INFO - 2025-07-13 11:12:10 --> Security Class Initialized
DEBUG - 2025-07-13 11:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 11:12:10 --> Input Class Initialized
INFO - 2025-07-13 11:12:10 --> Language Class Initialized
INFO - 2025-07-13 11:12:10 --> Loader Class Initialized
INFO - 2025-07-13 11:12:10 --> Helper loaded: url_helper
INFO - 2025-07-13 11:12:10 --> Helper loaded: form_helper
INFO - 2025-07-13 11:12:10 --> Database Driver Class Initialized
DEBUG - 2025-07-13 11:12:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 11:12:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 11:12:10 --> Controller Class Initialized
INFO - 2025-07-13 11:12:10 --> Model "User_model" initialized
INFO - 2025-07-13 11:12:10 --> Model "Progress_model" initialized
INFO - 2025-07-13 11:12:10 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-13 11:12:10 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-13 11:12:10 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/dashboard.php
INFO - 2025-07-13 11:12:10 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-13 11:12:10 --> Final output sent to browser
DEBUG - 2025-07-13 11:12:10 --> Total execution time: 0.0788
INFO - 2025-07-13 11:14:20 --> Config Class Initialized
INFO - 2025-07-13 11:14:20 --> Hooks Class Initialized
DEBUG - 2025-07-13 11:14:20 --> UTF-8 Support Enabled
INFO - 2025-07-13 11:14:20 --> Utf8 Class Initialized
INFO - 2025-07-13 11:14:20 --> URI Class Initialized
INFO - 2025-07-13 11:14:20 --> Router Class Initialized
INFO - 2025-07-13 11:14:20 --> Output Class Initialized
INFO - 2025-07-13 11:14:20 --> Security Class Initialized
DEBUG - 2025-07-13 11:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 11:14:20 --> Input Class Initialized
INFO - 2025-07-13 11:14:20 --> Language Class Initialized
INFO - 2025-07-13 11:14:20 --> Loader Class Initialized
INFO - 2025-07-13 11:14:20 --> Helper loaded: url_helper
INFO - 2025-07-13 11:14:20 --> Helper loaded: form_helper
INFO - 2025-07-13 11:14:20 --> Database Driver Class Initialized
DEBUG - 2025-07-13 11:14:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 11:14:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 11:14:20 --> Controller Class Initialized
INFO - 2025-07-13 11:14:20 --> Model "User_model" initialized
INFO - 2025-07-13 11:14:20 --> Model "Progress_model" initialized
INFO - 2025-07-13 11:14:20 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-13 11:14:20 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-13 11:14:20 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/guide.php
INFO - 2025-07-13 11:14:20 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-13 11:14:20 --> Final output sent to browser
DEBUG - 2025-07-13 11:14:20 --> Total execution time: 0.0839
INFO - 2025-07-13 11:19:02 --> Config Class Initialized
INFO - 2025-07-13 11:19:02 --> Hooks Class Initialized
DEBUG - 2025-07-13 11:19:02 --> UTF-8 Support Enabled
INFO - 2025-07-13 11:19:02 --> Utf8 Class Initialized
INFO - 2025-07-13 11:19:02 --> URI Class Initialized
INFO - 2025-07-13 11:19:02 --> Router Class Initialized
INFO - 2025-07-13 11:19:02 --> Output Class Initialized
INFO - 2025-07-13 11:19:02 --> Security Class Initialized
DEBUG - 2025-07-13 11:19:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 11:19:02 --> Input Class Initialized
INFO - 2025-07-13 11:19:02 --> Language Class Initialized
INFO - 2025-07-13 11:19:02 --> Loader Class Initialized
INFO - 2025-07-13 11:19:02 --> Helper loaded: url_helper
INFO - 2025-07-13 11:19:02 --> Helper loaded: form_helper
INFO - 2025-07-13 11:19:02 --> Database Driver Class Initialized
DEBUG - 2025-07-13 11:19:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 11:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 11:19:02 --> Controller Class Initialized
INFO - 2025-07-13 11:19:02 --> Model "Progress_model" initialized
INFO - 2025-07-13 11:19:02 --> Model "Olahraga_model" initialized
INFO - 2025-07-13 11:19:02 --> Model "User_model" initialized
INFO - 2025-07-13 11:19:02 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-13 11:19:02 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-13 11:19:02 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/progress_view.php
INFO - 2025-07-13 11:19:02 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-13 11:19:02 --> Final output sent to browser
DEBUG - 2025-07-13 11:19:02 --> Total execution time: 0.1042
INFO - 2025-07-13 11:19:02 --> Config Class Initialized
INFO - 2025-07-13 11:19:02 --> Hooks Class Initialized
DEBUG - 2025-07-13 11:19:02 --> UTF-8 Support Enabled
INFO - 2025-07-13 11:19:02 --> Utf8 Class Initialized
INFO - 2025-07-13 11:19:02 --> URI Class Initialized
INFO - 2025-07-13 11:19:02 --> Router Class Initialized
INFO - 2025-07-13 11:19:02 --> Output Class Initialized
INFO - 2025-07-13 11:19:02 --> Security Class Initialized
DEBUG - 2025-07-13 11:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 11:19:03 --> Input Class Initialized
INFO - 2025-07-13 11:19:03 --> Language Class Initialized
INFO - 2025-07-13 11:19:03 --> Loader Class Initialized
INFO - 2025-07-13 11:19:03 --> Helper loaded: url_helper
INFO - 2025-07-13 11:19:03 --> Helper loaded: form_helper
INFO - 2025-07-13 11:19:03 --> Database Driver Class Initialized
DEBUG - 2025-07-13 11:19:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 11:19:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 11:19:03 --> Controller Class Initialized
INFO - 2025-07-13 11:19:03 --> Model "Progress_model" initialized
INFO - 2025-07-13 11:19:03 --> Model "Olahraga_model" initialized
INFO - 2025-07-13 11:19:03 --> Model "User_model" initialized
INFO - 2025-07-13 11:19:03 --> Final output sent to browser
DEBUG - 2025-07-13 11:19:03 --> Total execution time: 0.0890
INFO - 2025-07-13 11:19:09 --> Config Class Initialized
INFO - 2025-07-13 11:19:09 --> Hooks Class Initialized
DEBUG - 2025-07-13 11:19:09 --> UTF-8 Support Enabled
INFO - 2025-07-13 11:19:09 --> Utf8 Class Initialized
INFO - 2025-07-13 11:19:09 --> URI Class Initialized
INFO - 2025-07-13 11:19:09 --> Router Class Initialized
INFO - 2025-07-13 11:19:09 --> Output Class Initialized
INFO - 2025-07-13 11:19:09 --> Security Class Initialized
DEBUG - 2025-07-13 11:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 11:19:09 --> Input Class Initialized
INFO - 2025-07-13 11:19:09 --> Language Class Initialized
INFO - 2025-07-13 11:19:09 --> Loader Class Initialized
INFO - 2025-07-13 11:19:09 --> Helper loaded: url_helper
INFO - 2025-07-13 11:19:09 --> Helper loaded: form_helper
INFO - 2025-07-13 11:19:09 --> Database Driver Class Initialized
DEBUG - 2025-07-13 11:19:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 11:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 11:19:09 --> Controller Class Initialized
INFO - 2025-07-13 11:19:09 --> Model "Progress_model" initialized
INFO - 2025-07-13 11:19:09 --> Model "Olahraga_model" initialized
INFO - 2025-07-13 11:19:09 --> Model "User_model" initialized
INFO - 2025-07-13 11:19:09 --> Final output sent to browser
DEBUG - 2025-07-13 11:19:09 --> Total execution time: 0.0710
INFO - 2025-07-13 11:19:11 --> Config Class Initialized
INFO - 2025-07-13 11:19:11 --> Hooks Class Initialized
DEBUG - 2025-07-13 11:19:11 --> UTF-8 Support Enabled
INFO - 2025-07-13 11:19:11 --> Utf8 Class Initialized
INFO - 2025-07-13 11:19:11 --> URI Class Initialized
INFO - 2025-07-13 11:19:11 --> Router Class Initialized
INFO - 2025-07-13 11:19:11 --> Output Class Initialized
INFO - 2025-07-13 11:19:11 --> Security Class Initialized
DEBUG - 2025-07-13 11:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 11:19:11 --> Input Class Initialized
INFO - 2025-07-13 11:19:11 --> Language Class Initialized
INFO - 2025-07-13 11:19:11 --> Loader Class Initialized
INFO - 2025-07-13 11:19:11 --> Helper loaded: url_helper
INFO - 2025-07-13 11:19:11 --> Helper loaded: form_helper
INFO - 2025-07-13 11:19:11 --> Database Driver Class Initialized
DEBUG - 2025-07-13 11:19:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 11:19:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 11:19:11 --> Controller Class Initialized
INFO - 2025-07-13 11:19:11 --> Model "Progress_model" initialized
INFO - 2025-07-13 11:19:11 --> Model "Olahraga_model" initialized
INFO - 2025-07-13 11:19:11 --> Model "User_model" initialized
INFO - 2025-07-13 11:19:11 --> Final output sent to browser
DEBUG - 2025-07-13 11:19:11 --> Total execution time: 0.1642
INFO - 2025-07-13 11:19:47 --> Config Class Initialized
INFO - 2025-07-13 11:19:47 --> Hooks Class Initialized
DEBUG - 2025-07-13 11:19:47 --> UTF-8 Support Enabled
INFO - 2025-07-13 11:19:47 --> Utf8 Class Initialized
INFO - 2025-07-13 11:19:47 --> URI Class Initialized
INFO - 2025-07-13 11:19:47 --> Router Class Initialized
INFO - 2025-07-13 11:19:47 --> Output Class Initialized
INFO - 2025-07-13 11:19:47 --> Security Class Initialized
DEBUG - 2025-07-13 11:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 11:19:47 --> Input Class Initialized
INFO - 2025-07-13 11:19:47 --> Language Class Initialized
INFO - 2025-07-13 11:19:47 --> Loader Class Initialized
INFO - 2025-07-13 11:19:47 --> Helper loaded: url_helper
INFO - 2025-07-13 11:19:47 --> Helper loaded: form_helper
INFO - 2025-07-13 11:19:47 --> Database Driver Class Initialized
DEBUG - 2025-07-13 11:19:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 11:19:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 11:19:47 --> Controller Class Initialized
INFO - 2025-07-13 11:19:47 --> Model "Olahraga_model" initialized
INFO - 2025-07-13 11:19:47 --> Model "User_model" initialized
INFO - 2025-07-13 11:19:47 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-13 11:19:47 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-13 11:19:47 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-07-13 11:19:47 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-13 11:19:47 --> Final output sent to browser
DEBUG - 2025-07-13 11:19:47 --> Total execution time: 0.0881
INFO - 2025-07-13 11:20:37 --> Config Class Initialized
INFO - 2025-07-13 11:20:37 --> Hooks Class Initialized
DEBUG - 2025-07-13 11:20:37 --> UTF-8 Support Enabled
INFO - 2025-07-13 11:20:37 --> Utf8 Class Initialized
INFO - 2025-07-13 11:20:37 --> URI Class Initialized
INFO - 2025-07-13 11:20:37 --> Router Class Initialized
INFO - 2025-07-13 11:20:37 --> Output Class Initialized
INFO - 2025-07-13 11:20:38 --> Security Class Initialized
DEBUG - 2025-07-13 11:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 11:20:38 --> Input Class Initialized
INFO - 2025-07-13 11:20:38 --> Language Class Initialized
INFO - 2025-07-13 11:20:38 --> Loader Class Initialized
INFO - 2025-07-13 11:20:38 --> Helper loaded: url_helper
INFO - 2025-07-13 11:20:38 --> Helper loaded: form_helper
INFO - 2025-07-13 11:20:38 --> Database Driver Class Initialized
DEBUG - 2025-07-13 11:20:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 11:20:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 11:20:38 --> Controller Class Initialized
INFO - 2025-07-13 11:20:38 --> Model "Olahraga_model" initialized
INFO - 2025-07-13 11:20:38 --> Model "User_model" initialized
INFO - 2025-07-13 11:20:38 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-13 11:20:38 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-13 11:20:38 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/level.php
INFO - 2025-07-13 11:20:38 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-13 11:20:38 --> Final output sent to browser
DEBUG - 2025-07-13 11:20:38 --> Total execution time: 0.0929
INFO - 2025-07-13 11:20:58 --> Config Class Initialized
INFO - 2025-07-13 11:20:58 --> Hooks Class Initialized
DEBUG - 2025-07-13 11:20:58 --> UTF-8 Support Enabled
INFO - 2025-07-13 11:20:58 --> Utf8 Class Initialized
INFO - 2025-07-13 11:20:58 --> URI Class Initialized
INFO - 2025-07-13 11:20:58 --> Router Class Initialized
INFO - 2025-07-13 11:20:58 --> Output Class Initialized
INFO - 2025-07-13 11:20:58 --> Security Class Initialized
DEBUG - 2025-07-13 11:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 11:20:58 --> Input Class Initialized
INFO - 2025-07-13 11:20:58 --> Language Class Initialized
INFO - 2025-07-13 11:20:58 --> Loader Class Initialized
INFO - 2025-07-13 11:20:58 --> Helper loaded: url_helper
INFO - 2025-07-13 11:20:58 --> Helper loaded: form_helper
INFO - 2025-07-13 11:20:58 --> Database Driver Class Initialized
DEBUG - 2025-07-13 11:20:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 11:20:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 11:20:58 --> Controller Class Initialized
INFO - 2025-07-13 11:20:58 --> Model "Olahraga_model" initialized
INFO - 2025-07-13 11:20:58 --> Model "User_model" initialized
INFO - 2025-07-13 11:20:58 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-13 11:20:58 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-13 11:20:58 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-07-13 11:20:58 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-13 11:20:58 --> Final output sent to browser
DEBUG - 2025-07-13 11:20:58 --> Total execution time: 0.0883
INFO - 2025-07-13 11:21:28 --> Config Class Initialized
INFO - 2025-07-13 11:21:28 --> Hooks Class Initialized
DEBUG - 2025-07-13 11:21:28 --> UTF-8 Support Enabled
INFO - 2025-07-13 11:21:28 --> Utf8 Class Initialized
INFO - 2025-07-13 11:21:28 --> URI Class Initialized
INFO - 2025-07-13 11:21:28 --> Router Class Initialized
INFO - 2025-07-13 11:21:28 --> Output Class Initialized
INFO - 2025-07-13 11:21:28 --> Security Class Initialized
DEBUG - 2025-07-13 11:21:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 11:21:29 --> Input Class Initialized
INFO - 2025-07-13 11:21:29 --> Language Class Initialized
INFO - 2025-07-13 11:21:29 --> Loader Class Initialized
INFO - 2025-07-13 11:21:29 --> Helper loaded: url_helper
INFO - 2025-07-13 11:21:29 --> Helper loaded: form_helper
INFO - 2025-07-13 11:21:29 --> Database Driver Class Initialized
DEBUG - 2025-07-13 11:21:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 11:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 11:21:29 --> Controller Class Initialized
INFO - 2025-07-13 11:21:29 --> Model "Olahraga_model" initialized
INFO - 2025-07-13 11:21:29 --> Model "User_model" initialized
INFO - 2025-07-13 11:21:29 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-13 11:21:29 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-13 11:21:29 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-07-13 11:21:29 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-13 11:21:29 --> Final output sent to browser
DEBUG - 2025-07-13 11:21:29 --> Total execution time: 0.1110
INFO - 2025-07-13 11:21:52 --> Config Class Initialized
INFO - 2025-07-13 11:21:52 --> Hooks Class Initialized
DEBUG - 2025-07-13 11:21:52 --> UTF-8 Support Enabled
INFO - 2025-07-13 11:21:52 --> Utf8 Class Initialized
INFO - 2025-07-13 11:21:52 --> URI Class Initialized
INFO - 2025-07-13 11:21:52 --> Router Class Initialized
INFO - 2025-07-13 11:21:52 --> Output Class Initialized
INFO - 2025-07-13 11:21:52 --> Security Class Initialized
DEBUG - 2025-07-13 11:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 11:21:52 --> Input Class Initialized
INFO - 2025-07-13 11:21:52 --> Language Class Initialized
INFO - 2025-07-13 11:21:52 --> Loader Class Initialized
INFO - 2025-07-13 11:21:52 --> Helper loaded: url_helper
INFO - 2025-07-13 11:21:52 --> Helper loaded: form_helper
INFO - 2025-07-13 11:21:52 --> Database Driver Class Initialized
DEBUG - 2025-07-13 11:21:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 11:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 11:21:52 --> Controller Class Initialized
INFO - 2025-07-13 11:21:52 --> Model "Olahraga_model" initialized
INFO - 2025-07-13 11:21:52 --> Model "User_model" initialized
INFO - 2025-07-13 11:21:52 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-13 11:21:52 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-13 11:21:52 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/start.php
INFO - 2025-07-13 11:21:52 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-13 11:21:52 --> Final output sent to browser
DEBUG - 2025-07-13 11:21:52 --> Total execution time: 0.0807
INFO - 2025-07-13 11:22:25 --> Config Class Initialized
INFO - 2025-07-13 11:22:25 --> Hooks Class Initialized
DEBUG - 2025-07-13 11:22:25 --> UTF-8 Support Enabled
INFO - 2025-07-13 11:22:25 --> Utf8 Class Initialized
INFO - 2025-07-13 11:22:25 --> URI Class Initialized
INFO - 2025-07-13 11:22:25 --> Router Class Initialized
INFO - 2025-07-13 11:22:25 --> Output Class Initialized
INFO - 2025-07-13 11:22:25 --> Security Class Initialized
DEBUG - 2025-07-13 11:22:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 11:22:25 --> Input Class Initialized
INFO - 2025-07-13 11:22:25 --> Language Class Initialized
INFO - 2025-07-13 11:22:25 --> Loader Class Initialized
INFO - 2025-07-13 11:22:25 --> Helper loaded: url_helper
INFO - 2025-07-13 11:22:25 --> Helper loaded: form_helper
INFO - 2025-07-13 11:22:25 --> Database Driver Class Initialized
DEBUG - 2025-07-13 11:22:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 11:22:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 11:22:25 --> Controller Class Initialized
INFO - 2025-07-13 11:22:25 --> Model "Olahraga_model" initialized
INFO - 2025-07-13 11:22:25 --> Model "User_model" initialized
INFO - 2025-07-13 11:22:25 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-13 11:22:25 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-13 11:22:26 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/start.php
INFO - 2025-07-13 11:22:26 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-13 11:22:26 --> Final output sent to browser
DEBUG - 2025-07-13 11:22:26 --> Total execution time: 0.1091
INFO - 2025-07-13 11:22:54 --> Config Class Initialized
INFO - 2025-07-13 11:22:54 --> Hooks Class Initialized
DEBUG - 2025-07-13 11:22:54 --> UTF-8 Support Enabled
INFO - 2025-07-13 11:22:54 --> Utf8 Class Initialized
INFO - 2025-07-13 11:22:54 --> URI Class Initialized
INFO - 2025-07-13 11:22:54 --> Router Class Initialized
INFO - 2025-07-13 11:22:54 --> Output Class Initialized
INFO - 2025-07-13 11:22:54 --> Security Class Initialized
DEBUG - 2025-07-13 11:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 11:22:55 --> Input Class Initialized
INFO - 2025-07-13 11:22:55 --> Language Class Initialized
INFO - 2025-07-13 11:22:55 --> Loader Class Initialized
INFO - 2025-07-13 11:22:55 --> Helper loaded: url_helper
INFO - 2025-07-13 11:22:55 --> Helper loaded: form_helper
INFO - 2025-07-13 11:22:55 --> Database Driver Class Initialized
DEBUG - 2025-07-13 11:22:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 11:22:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 11:22:55 --> Controller Class Initialized
INFO - 2025-07-13 11:22:55 --> Model "Olahraga_model" initialized
INFO - 2025-07-13 11:22:55 --> Model "User_model" initialized
INFO - 2025-07-13 11:22:55 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-13 11:22:55 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-13 11:22:55 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/start.php
INFO - 2025-07-13 11:22:55 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-13 11:22:55 --> Final output sent to browser
DEBUG - 2025-07-13 11:22:55 --> Total execution time: 0.0982
INFO - 2025-07-13 11:23:50 --> Config Class Initialized
INFO - 2025-07-13 11:23:50 --> Hooks Class Initialized
DEBUG - 2025-07-13 11:23:50 --> UTF-8 Support Enabled
INFO - 2025-07-13 11:23:50 --> Utf8 Class Initialized
INFO - 2025-07-13 11:23:50 --> URI Class Initialized
INFO - 2025-07-13 11:23:50 --> Router Class Initialized
INFO - 2025-07-13 11:23:50 --> Output Class Initialized
INFO - 2025-07-13 11:23:50 --> Security Class Initialized
DEBUG - 2025-07-13 11:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 11:23:50 --> Input Class Initialized
INFO - 2025-07-13 11:23:50 --> Language Class Initialized
INFO - 2025-07-13 11:23:50 --> Loader Class Initialized
INFO - 2025-07-13 11:23:50 --> Helper loaded: url_helper
INFO - 2025-07-13 11:23:50 --> Helper loaded: form_helper
INFO - 2025-07-13 11:23:50 --> Database Driver Class Initialized
DEBUG - 2025-07-13 11:23:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 11:23:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 11:23:50 --> Controller Class Initialized
INFO - 2025-07-13 11:23:50 --> Model "User_model" initialized
INFO - 2025-07-13 11:23:50 --> Model "Community_model" initialized
INFO - 2025-07-13 11:23:50 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-13 11:23:50 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-13 11:23:50 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/community.php
INFO - 2025-07-13 11:23:50 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-13 11:23:50 --> Final output sent to browser
DEBUG - 2025-07-13 11:23:50 --> Total execution time: 0.1100
INFO - 2025-07-13 12:21:08 --> Config Class Initialized
INFO - 2025-07-13 12:21:08 --> Hooks Class Initialized
DEBUG - 2025-07-13 12:21:08 --> UTF-8 Support Enabled
INFO - 2025-07-13 12:21:08 --> Utf8 Class Initialized
INFO - 2025-07-13 12:21:08 --> URI Class Initialized
INFO - 2025-07-13 12:21:08 --> Router Class Initialized
INFO - 2025-07-13 12:21:08 --> Output Class Initialized
INFO - 2025-07-13 12:21:08 --> Security Class Initialized
DEBUG - 2025-07-13 12:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 12:21:08 --> Input Class Initialized
INFO - 2025-07-13 12:21:08 --> Language Class Initialized
INFO - 2025-07-13 12:21:08 --> Loader Class Initialized
INFO - 2025-07-13 12:21:08 --> Helper loaded: url_helper
INFO - 2025-07-13 12:21:08 --> Helper loaded: form_helper
INFO - 2025-07-13 12:21:08 --> Database Driver Class Initialized
DEBUG - 2025-07-13 12:21:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 12:21:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 12:21:08 --> Controller Class Initialized
INFO - 2025-07-13 12:21:08 --> Model "User_model" initialized
INFO - 2025-07-13 12:21:08 --> Form Validation Class Initialized
INFO - 2025-07-13 12:21:08 --> Config Class Initialized
INFO - 2025-07-13 12:21:08 --> Hooks Class Initialized
DEBUG - 2025-07-13 12:21:08 --> UTF-8 Support Enabled
INFO - 2025-07-13 12:21:08 --> Utf8 Class Initialized
INFO - 2025-07-13 12:21:08 --> URI Class Initialized
INFO - 2025-07-13 12:21:08 --> Router Class Initialized
INFO - 2025-07-13 12:21:08 --> Output Class Initialized
INFO - 2025-07-13 12:21:08 --> Security Class Initialized
DEBUG - 2025-07-13 12:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 12:21:08 --> Input Class Initialized
INFO - 2025-07-13 12:21:08 --> Language Class Initialized
INFO - 2025-07-13 12:21:08 --> Loader Class Initialized
INFO - 2025-07-13 12:21:08 --> Helper loaded: url_helper
INFO - 2025-07-13 12:21:08 --> Helper loaded: form_helper
INFO - 2025-07-13 12:21:08 --> Database Driver Class Initialized
DEBUG - 2025-07-13 12:21:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 12:21:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 12:21:08 --> Controller Class Initialized
INFO - 2025-07-13 12:21:08 --> Model "User_model" initialized
INFO - 2025-07-13 12:21:08 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-07-13 12:21:08 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/home.php
INFO - 2025-07-13 12:21:08 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-07-13 12:21:08 --> Final output sent to browser
DEBUG - 2025-07-13 12:21:08 --> Total execution time: 0.0912
INFO - 2025-07-13 12:21:22 --> Config Class Initialized
INFO - 2025-07-13 12:21:22 --> Hooks Class Initialized
DEBUG - 2025-07-13 12:21:22 --> UTF-8 Support Enabled
INFO - 2025-07-13 12:21:22 --> Utf8 Class Initialized
INFO - 2025-07-13 12:21:22 --> URI Class Initialized
INFO - 2025-07-13 12:21:22 --> Router Class Initialized
INFO - 2025-07-13 12:21:22 --> Output Class Initialized
INFO - 2025-07-13 12:21:22 --> Security Class Initialized
DEBUG - 2025-07-13 12:21:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 12:21:22 --> Input Class Initialized
INFO - 2025-07-13 12:21:22 --> Language Class Initialized
INFO - 2025-07-13 12:21:22 --> Loader Class Initialized
INFO - 2025-07-13 12:21:22 --> Helper loaded: url_helper
INFO - 2025-07-13 12:21:22 --> Helper loaded: form_helper
INFO - 2025-07-13 12:21:22 --> Database Driver Class Initialized
DEBUG - 2025-07-13 12:21:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 12:21:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 12:21:22 --> Controller Class Initialized
INFO - 2025-07-13 12:21:22 --> Model "User_model" initialized
INFO - 2025-07-13 12:21:22 --> Form Validation Class Initialized
INFO - 2025-07-13 12:21:22 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\auth/login.php
INFO - 2025-07-13 12:21:22 --> Final output sent to browser
DEBUG - 2025-07-13 12:21:22 --> Total execution time: 0.0887
INFO - 2025-07-13 12:21:37 --> Config Class Initialized
INFO - 2025-07-13 12:21:37 --> Hooks Class Initialized
DEBUG - 2025-07-13 12:21:37 --> UTF-8 Support Enabled
INFO - 2025-07-13 12:21:37 --> Utf8 Class Initialized
INFO - 2025-07-13 12:21:37 --> URI Class Initialized
INFO - 2025-07-13 12:21:37 --> Router Class Initialized
INFO - 2025-07-13 12:21:37 --> Output Class Initialized
INFO - 2025-07-13 12:21:37 --> Security Class Initialized
DEBUG - 2025-07-13 12:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 12:21:37 --> Input Class Initialized
INFO - 2025-07-13 12:21:37 --> Language Class Initialized
INFO - 2025-07-13 12:21:37 --> Loader Class Initialized
INFO - 2025-07-13 12:21:37 --> Helper loaded: url_helper
INFO - 2025-07-13 12:21:37 --> Helper loaded: form_helper
INFO - 2025-07-13 12:21:37 --> Database Driver Class Initialized
DEBUG - 2025-07-13 12:21:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 12:21:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 12:21:37 --> Controller Class Initialized
INFO - 2025-07-13 12:21:37 --> Model "User_model" initialized
INFO - 2025-07-13 12:21:37 --> Form Validation Class Initialized
INFO - 2025-07-13 12:21:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-07-13 12:21:37 --> Config Class Initialized
INFO - 2025-07-13 12:21:37 --> Hooks Class Initialized
DEBUG - 2025-07-13 12:21:37 --> UTF-8 Support Enabled
INFO - 2025-07-13 12:21:37 --> Utf8 Class Initialized
INFO - 2025-07-13 12:21:37 --> URI Class Initialized
INFO - 2025-07-13 12:21:37 --> Router Class Initialized
INFO - 2025-07-13 12:21:37 --> Output Class Initialized
INFO - 2025-07-13 12:21:37 --> Security Class Initialized
DEBUG - 2025-07-13 12:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 12:21:37 --> Input Class Initialized
INFO - 2025-07-13 12:21:37 --> Language Class Initialized
INFO - 2025-07-13 12:21:37 --> Loader Class Initialized
INFO - 2025-07-13 12:21:37 --> Helper loaded: url_helper
INFO - 2025-07-13 12:21:37 --> Helper loaded: form_helper
INFO - 2025-07-13 12:21:37 --> Database Driver Class Initialized
DEBUG - 2025-07-13 12:21:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 12:21:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 12:21:37 --> Controller Class Initialized
INFO - 2025-07-13 12:21:37 --> Model "User_model" initialized
INFO - 2025-07-13 12:21:37 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-07-13 12:21:37 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/home.php
INFO - 2025-07-13 12:21:37 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-07-13 12:21:37 --> Final output sent to browser
DEBUG - 2025-07-13 12:21:37 --> Total execution time: 0.0928
INFO - 2025-07-13 12:22:10 --> Config Class Initialized
INFO - 2025-07-13 12:22:10 --> Hooks Class Initialized
DEBUG - 2025-07-13 12:22:10 --> UTF-8 Support Enabled
INFO - 2025-07-13 12:22:10 --> Utf8 Class Initialized
INFO - 2025-07-13 12:22:10 --> URI Class Initialized
INFO - 2025-07-13 12:22:10 --> Router Class Initialized
INFO - 2025-07-13 12:22:10 --> Output Class Initialized
INFO - 2025-07-13 12:22:10 --> Security Class Initialized
DEBUG - 2025-07-13 12:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 12:22:10 --> Input Class Initialized
INFO - 2025-07-13 12:22:10 --> Language Class Initialized
INFO - 2025-07-13 12:22:10 --> Loader Class Initialized
INFO - 2025-07-13 12:22:10 --> Helper loaded: url_helper
INFO - 2025-07-13 12:22:10 --> Helper loaded: form_helper
INFO - 2025-07-13 12:22:10 --> Database Driver Class Initialized
DEBUG - 2025-07-13 12:22:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 12:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 12:22:10 --> Controller Class Initialized
INFO - 2025-07-13 12:22:10 --> Model "User_model" initialized
INFO - 2025-07-13 12:22:10 --> Form Validation Class Initialized
INFO - 2025-07-13 12:22:10 --> Config Class Initialized
INFO - 2025-07-13 12:22:10 --> Hooks Class Initialized
DEBUG - 2025-07-13 12:22:10 --> UTF-8 Support Enabled
INFO - 2025-07-13 12:22:10 --> Utf8 Class Initialized
INFO - 2025-07-13 12:22:10 --> URI Class Initialized
INFO - 2025-07-13 12:22:10 --> Router Class Initialized
INFO - 2025-07-13 12:22:10 --> Output Class Initialized
INFO - 2025-07-13 12:22:10 --> Security Class Initialized
DEBUG - 2025-07-13 12:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 12:22:10 --> Input Class Initialized
INFO - 2025-07-13 12:22:10 --> Language Class Initialized
INFO - 2025-07-13 12:22:10 --> Loader Class Initialized
INFO - 2025-07-13 12:22:10 --> Helper loaded: url_helper
INFO - 2025-07-13 12:22:10 --> Helper loaded: form_helper
INFO - 2025-07-13 12:22:10 --> Database Driver Class Initialized
DEBUG - 2025-07-13 12:22:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 12:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 12:22:10 --> Controller Class Initialized
INFO - 2025-07-13 12:22:10 --> Model "User_model" initialized
INFO - 2025-07-13 12:22:10 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-07-13 12:22:10 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/home.php
INFO - 2025-07-13 12:22:10 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-07-13 12:22:10 --> Final output sent to browser
DEBUG - 2025-07-13 12:22:10 --> Total execution time: 0.0855
INFO - 2025-07-13 12:22:12 --> Config Class Initialized
INFO - 2025-07-13 12:22:12 --> Hooks Class Initialized
DEBUG - 2025-07-13 12:22:12 --> UTF-8 Support Enabled
INFO - 2025-07-13 12:22:12 --> Utf8 Class Initialized
INFO - 2025-07-13 12:22:12 --> URI Class Initialized
INFO - 2025-07-13 12:22:12 --> Router Class Initialized
INFO - 2025-07-13 12:22:12 --> Output Class Initialized
INFO - 2025-07-13 12:22:12 --> Security Class Initialized
DEBUG - 2025-07-13 12:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 12:22:12 --> Input Class Initialized
INFO - 2025-07-13 12:22:12 --> Language Class Initialized
INFO - 2025-07-13 12:22:12 --> Loader Class Initialized
INFO - 2025-07-13 12:22:12 --> Helper loaded: url_helper
INFO - 2025-07-13 12:22:12 --> Helper loaded: form_helper
INFO - 2025-07-13 12:22:12 --> Database Driver Class Initialized
DEBUG - 2025-07-13 12:22:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 12:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 12:22:12 --> Controller Class Initialized
INFO - 2025-07-13 12:22:12 --> Model "User_model" initialized
INFO - 2025-07-13 12:22:12 --> Form Validation Class Initialized
INFO - 2025-07-13 12:22:12 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\auth/login.php
INFO - 2025-07-13 12:22:12 --> Final output sent to browser
DEBUG - 2025-07-13 12:22:12 --> Total execution time: 0.0921
INFO - 2025-07-13 12:22:19 --> Config Class Initialized
INFO - 2025-07-13 12:22:19 --> Hooks Class Initialized
DEBUG - 2025-07-13 12:22:19 --> UTF-8 Support Enabled
INFO - 2025-07-13 12:22:19 --> Utf8 Class Initialized
INFO - 2025-07-13 12:22:19 --> URI Class Initialized
INFO - 2025-07-13 12:22:19 --> Router Class Initialized
INFO - 2025-07-13 12:22:19 --> Output Class Initialized
INFO - 2025-07-13 12:22:19 --> Security Class Initialized
DEBUG - 2025-07-13 12:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 12:22:19 --> Input Class Initialized
INFO - 2025-07-13 12:22:19 --> Language Class Initialized
INFO - 2025-07-13 12:22:19 --> Loader Class Initialized
INFO - 2025-07-13 12:22:19 --> Helper loaded: url_helper
INFO - 2025-07-13 12:22:19 --> Helper loaded: form_helper
INFO - 2025-07-13 12:22:19 --> Database Driver Class Initialized
DEBUG - 2025-07-13 12:22:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 12:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 12:22:19 --> Controller Class Initialized
INFO - 2025-07-13 12:22:19 --> Model "User_model" initialized
INFO - 2025-07-13 12:22:19 --> Form Validation Class Initialized
INFO - 2025-07-13 12:22:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-07-13 12:22:19 --> Config Class Initialized
INFO - 2025-07-13 12:22:19 --> Hooks Class Initialized
DEBUG - 2025-07-13 12:22:19 --> UTF-8 Support Enabled
INFO - 2025-07-13 12:22:19 --> Utf8 Class Initialized
INFO - 2025-07-13 12:22:19 --> URI Class Initialized
INFO - 2025-07-13 12:22:19 --> Router Class Initialized
INFO - 2025-07-13 12:22:19 --> Output Class Initialized
INFO - 2025-07-13 12:22:19 --> Security Class Initialized
DEBUG - 2025-07-13 12:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 12:22:19 --> Input Class Initialized
INFO - 2025-07-13 12:22:19 --> Language Class Initialized
INFO - 2025-07-13 12:22:19 --> Loader Class Initialized
INFO - 2025-07-13 12:22:19 --> Helper loaded: url_helper
INFO - 2025-07-13 12:22:19 --> Helper loaded: form_helper
INFO - 2025-07-13 12:22:19 --> Database Driver Class Initialized
DEBUG - 2025-07-13 12:22:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 12:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 12:22:19 --> Controller Class Initialized
INFO - 2025-07-13 12:22:19 --> Model "User_model" initialized
INFO - 2025-07-13 12:22:19 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-07-13 12:22:19 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/home.php
INFO - 2025-07-13 12:22:20 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-07-13 12:22:20 --> Final output sent to browser
DEBUG - 2025-07-13 12:22:20 --> Total execution time: 0.0947
INFO - 2025-07-13 12:22:33 --> Config Class Initialized
INFO - 2025-07-13 12:22:33 --> Hooks Class Initialized
DEBUG - 2025-07-13 12:22:33 --> UTF-8 Support Enabled
INFO - 2025-07-13 12:22:33 --> Utf8 Class Initialized
INFO - 2025-07-13 12:22:33 --> URI Class Initialized
INFO - 2025-07-13 12:22:33 --> Router Class Initialized
INFO - 2025-07-13 12:22:33 --> Output Class Initialized
INFO - 2025-07-13 12:22:33 --> Security Class Initialized
DEBUG - 2025-07-13 12:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 12:22:33 --> Input Class Initialized
INFO - 2025-07-13 12:22:33 --> Language Class Initialized
INFO - 2025-07-13 12:22:33 --> Loader Class Initialized
INFO - 2025-07-13 12:22:33 --> Helper loaded: url_helper
INFO - 2025-07-13 12:22:33 --> Helper loaded: form_helper
INFO - 2025-07-13 12:22:33 --> Database Driver Class Initialized
DEBUG - 2025-07-13 12:22:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 12:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 12:22:33 --> Controller Class Initialized
INFO - 2025-07-13 12:22:33 --> Model "User_model" initialized
INFO - 2025-07-13 12:22:33 --> Form Validation Class Initialized
INFO - 2025-07-13 12:22:33 --> Config Class Initialized
INFO - 2025-07-13 12:22:33 --> Hooks Class Initialized
DEBUG - 2025-07-13 12:22:33 --> UTF-8 Support Enabled
INFO - 2025-07-13 12:22:33 --> Utf8 Class Initialized
INFO - 2025-07-13 12:22:33 --> URI Class Initialized
INFO - 2025-07-13 12:22:33 --> Router Class Initialized
INFO - 2025-07-13 12:22:33 --> Output Class Initialized
INFO - 2025-07-13 12:22:33 --> Security Class Initialized
DEBUG - 2025-07-13 12:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 12:22:33 --> Input Class Initialized
INFO - 2025-07-13 12:22:33 --> Language Class Initialized
INFO - 2025-07-13 12:22:33 --> Loader Class Initialized
INFO - 2025-07-13 12:22:33 --> Helper loaded: url_helper
INFO - 2025-07-13 12:22:33 --> Helper loaded: form_helper
INFO - 2025-07-13 12:22:33 --> Database Driver Class Initialized
DEBUG - 2025-07-13 12:22:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 12:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 12:22:33 --> Controller Class Initialized
INFO - 2025-07-13 12:22:33 --> Model "User_model" initialized
INFO - 2025-07-13 12:22:33 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-07-13 12:22:33 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/home.php
INFO - 2025-07-13 12:22:33 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-07-13 12:22:33 --> Final output sent to browser
DEBUG - 2025-07-13 12:22:33 --> Total execution time: 0.0971
INFO - 2025-07-13 12:22:35 --> Config Class Initialized
INFO - 2025-07-13 12:22:35 --> Hooks Class Initialized
DEBUG - 2025-07-13 12:22:35 --> UTF-8 Support Enabled
INFO - 2025-07-13 12:22:35 --> Utf8 Class Initialized
INFO - 2025-07-13 12:22:35 --> URI Class Initialized
INFO - 2025-07-13 12:22:35 --> Router Class Initialized
INFO - 2025-07-13 12:22:35 --> Output Class Initialized
INFO - 2025-07-13 12:22:35 --> Security Class Initialized
DEBUG - 2025-07-13 12:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 12:22:35 --> Input Class Initialized
INFO - 2025-07-13 12:22:35 --> Language Class Initialized
INFO - 2025-07-13 12:22:35 --> Loader Class Initialized
INFO - 2025-07-13 12:22:35 --> Helper loaded: url_helper
INFO - 2025-07-13 12:22:35 --> Helper loaded: form_helper
INFO - 2025-07-13 12:22:36 --> Database Driver Class Initialized
DEBUG - 2025-07-13 12:22:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 12:22:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 12:22:36 --> Controller Class Initialized
INFO - 2025-07-13 12:22:36 --> Model "User_model" initialized
INFO - 2025-07-13 12:22:36 --> Form Validation Class Initialized
INFO - 2025-07-13 12:22:36 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\auth/login.php
INFO - 2025-07-13 12:22:36 --> Final output sent to browser
DEBUG - 2025-07-13 12:22:36 --> Total execution time: 0.1038
INFO - 2025-07-13 12:22:40 --> Config Class Initialized
INFO - 2025-07-13 12:22:40 --> Hooks Class Initialized
DEBUG - 2025-07-13 12:22:40 --> UTF-8 Support Enabled
INFO - 2025-07-13 12:22:40 --> Utf8 Class Initialized
INFO - 2025-07-13 12:22:40 --> URI Class Initialized
INFO - 2025-07-13 12:22:40 --> Router Class Initialized
INFO - 2025-07-13 12:22:40 --> Output Class Initialized
INFO - 2025-07-13 12:22:40 --> Security Class Initialized
DEBUG - 2025-07-13 12:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 12:22:40 --> Input Class Initialized
INFO - 2025-07-13 12:22:40 --> Language Class Initialized
INFO - 2025-07-13 12:22:40 --> Loader Class Initialized
INFO - 2025-07-13 12:22:40 --> Helper loaded: url_helper
INFO - 2025-07-13 12:22:40 --> Helper loaded: form_helper
INFO - 2025-07-13 12:22:40 --> Database Driver Class Initialized
DEBUG - 2025-07-13 12:22:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 12:22:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 12:22:40 --> Controller Class Initialized
INFO - 2025-07-13 12:22:40 --> Model "User_model" initialized
INFO - 2025-07-13 12:22:40 --> Form Validation Class Initialized
INFO - 2025-07-13 12:22:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-07-13 12:22:41 --> Config Class Initialized
INFO - 2025-07-13 12:22:41 --> Hooks Class Initialized
DEBUG - 2025-07-13 12:22:41 --> UTF-8 Support Enabled
INFO - 2025-07-13 12:22:41 --> Utf8 Class Initialized
INFO - 2025-07-13 12:22:41 --> URI Class Initialized
INFO - 2025-07-13 12:22:41 --> Router Class Initialized
INFO - 2025-07-13 12:22:41 --> Output Class Initialized
INFO - 2025-07-13 12:22:41 --> Security Class Initialized
DEBUG - 2025-07-13 12:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 12:22:41 --> Input Class Initialized
INFO - 2025-07-13 12:22:41 --> Language Class Initialized
INFO - 2025-07-13 12:22:41 --> Loader Class Initialized
INFO - 2025-07-13 12:22:41 --> Helper loaded: url_helper
INFO - 2025-07-13 12:22:41 --> Helper loaded: form_helper
INFO - 2025-07-13 12:22:41 --> Database Driver Class Initialized
DEBUG - 2025-07-13 12:22:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 12:22:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 12:22:41 --> Controller Class Initialized
INFO - 2025-07-13 12:22:41 --> Model "User_model" initialized
INFO - 2025-07-13 12:22:41 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-07-13 12:22:41 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/home.php
INFO - 2025-07-13 12:22:41 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-07-13 12:22:41 --> Final output sent to browser
DEBUG - 2025-07-13 12:22:41 --> Total execution time: 0.0916
INFO - 2025-07-13 12:23:51 --> Config Class Initialized
INFO - 2025-07-13 12:23:51 --> Hooks Class Initialized
DEBUG - 2025-07-13 12:23:51 --> UTF-8 Support Enabled
INFO - 2025-07-13 12:23:51 --> Utf8 Class Initialized
INFO - 2025-07-13 12:23:51 --> URI Class Initialized
INFO - 2025-07-13 12:23:51 --> Router Class Initialized
INFO - 2025-07-13 12:23:51 --> Output Class Initialized
INFO - 2025-07-13 12:23:51 --> Security Class Initialized
DEBUG - 2025-07-13 12:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 12:23:51 --> Input Class Initialized
INFO - 2025-07-13 12:23:51 --> Language Class Initialized
INFO - 2025-07-13 12:23:51 --> Loader Class Initialized
INFO - 2025-07-13 12:23:51 --> Helper loaded: url_helper
INFO - 2025-07-13 12:23:51 --> Helper loaded: form_helper
INFO - 2025-07-13 12:23:51 --> Database Driver Class Initialized
DEBUG - 2025-07-13 12:23:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 12:23:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 12:23:51 --> Controller Class Initialized
INFO - 2025-07-13 12:23:51 --> Model "User_model" initialized
INFO - 2025-07-13 12:23:51 --> Form Validation Class Initialized
INFO - 2025-07-13 12:23:51 --> Config Class Initialized
INFO - 2025-07-13 12:23:51 --> Hooks Class Initialized
DEBUG - 2025-07-13 12:23:51 --> UTF-8 Support Enabled
INFO - 2025-07-13 12:23:51 --> Utf8 Class Initialized
INFO - 2025-07-13 12:23:51 --> URI Class Initialized
INFO - 2025-07-13 12:23:51 --> Router Class Initialized
INFO - 2025-07-13 12:23:51 --> Output Class Initialized
INFO - 2025-07-13 12:23:51 --> Security Class Initialized
DEBUG - 2025-07-13 12:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 12:23:51 --> Input Class Initialized
INFO - 2025-07-13 12:23:51 --> Language Class Initialized
INFO - 2025-07-13 12:23:51 --> Loader Class Initialized
INFO - 2025-07-13 12:23:51 --> Helper loaded: url_helper
INFO - 2025-07-13 12:23:51 --> Helper loaded: form_helper
INFO - 2025-07-13 12:23:51 --> Database Driver Class Initialized
DEBUG - 2025-07-13 12:23:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 12:23:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 12:23:51 --> Controller Class Initialized
INFO - 2025-07-13 12:23:51 --> Model "User_model" initialized
INFO - 2025-07-13 12:23:51 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-07-13 12:23:51 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/home.php
INFO - 2025-07-13 12:23:51 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-07-13 12:23:51 --> Final output sent to browser
DEBUG - 2025-07-13 12:23:51 --> Total execution time: 0.0949
INFO - 2025-07-13 12:23:54 --> Config Class Initialized
INFO - 2025-07-13 12:23:54 --> Hooks Class Initialized
DEBUG - 2025-07-13 12:23:54 --> UTF-8 Support Enabled
INFO - 2025-07-13 12:23:54 --> Utf8 Class Initialized
INFO - 2025-07-13 12:23:54 --> URI Class Initialized
INFO - 2025-07-13 12:23:54 --> Router Class Initialized
INFO - 2025-07-13 12:23:54 --> Output Class Initialized
INFO - 2025-07-13 12:23:54 --> Security Class Initialized
DEBUG - 2025-07-13 12:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 12:23:54 --> Input Class Initialized
INFO - 2025-07-13 12:23:54 --> Language Class Initialized
INFO - 2025-07-13 12:23:54 --> Loader Class Initialized
INFO - 2025-07-13 12:23:54 --> Helper loaded: url_helper
INFO - 2025-07-13 12:23:54 --> Helper loaded: form_helper
INFO - 2025-07-13 12:23:54 --> Database Driver Class Initialized
DEBUG - 2025-07-13 12:23:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 12:23:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 12:23:54 --> Controller Class Initialized
INFO - 2025-07-13 12:23:54 --> Model "User_model" initialized
INFO - 2025-07-13 12:23:54 --> Form Validation Class Initialized
INFO - 2025-07-13 12:23:54 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\auth/login.php
INFO - 2025-07-13 12:23:54 --> Final output sent to browser
DEBUG - 2025-07-13 12:23:54 --> Total execution time: 0.1017
INFO - 2025-07-13 12:23:56 --> Config Class Initialized
INFO - 2025-07-13 12:23:56 --> Hooks Class Initialized
DEBUG - 2025-07-13 12:23:56 --> UTF-8 Support Enabled
INFO - 2025-07-13 12:23:56 --> Utf8 Class Initialized
INFO - 2025-07-13 12:23:56 --> URI Class Initialized
INFO - 2025-07-13 12:23:56 --> Router Class Initialized
INFO - 2025-07-13 12:23:56 --> Output Class Initialized
INFO - 2025-07-13 12:23:56 --> Security Class Initialized
DEBUG - 2025-07-13 12:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 12:23:56 --> Input Class Initialized
INFO - 2025-07-13 12:23:56 --> Language Class Initialized
INFO - 2025-07-13 12:23:56 --> Loader Class Initialized
INFO - 2025-07-13 12:23:56 --> Helper loaded: url_helper
INFO - 2025-07-13 12:23:56 --> Helper loaded: form_helper
INFO - 2025-07-13 12:23:56 --> Database Driver Class Initialized
DEBUG - 2025-07-13 12:23:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 12:23:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 12:23:56 --> Controller Class Initialized
INFO - 2025-07-13 12:23:56 --> Model "User_model" initialized
INFO - 2025-07-13 12:23:56 --> Form Validation Class Initialized
DEBUG - 2025-07-13 12:23:56 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-07-13 12:23:56 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\auth/register.php
INFO - 2025-07-13 12:23:56 --> Final output sent to browser
DEBUG - 2025-07-13 12:23:56 --> Total execution time: 0.0864
INFO - 2025-07-13 12:24:25 --> Config Class Initialized
INFO - 2025-07-13 12:24:25 --> Hooks Class Initialized
DEBUG - 2025-07-13 12:24:25 --> UTF-8 Support Enabled
INFO - 2025-07-13 12:24:25 --> Utf8 Class Initialized
INFO - 2025-07-13 12:24:25 --> URI Class Initialized
INFO - 2025-07-13 12:24:25 --> Router Class Initialized
INFO - 2025-07-13 12:24:25 --> Output Class Initialized
INFO - 2025-07-13 12:24:25 --> Security Class Initialized
DEBUG - 2025-07-13 12:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 12:24:25 --> Input Class Initialized
INFO - 2025-07-13 12:24:25 --> Language Class Initialized
INFO - 2025-07-13 12:24:25 --> Loader Class Initialized
INFO - 2025-07-13 12:24:25 --> Helper loaded: url_helper
INFO - 2025-07-13 12:24:25 --> Helper loaded: form_helper
INFO - 2025-07-13 12:24:25 --> Database Driver Class Initialized
DEBUG - 2025-07-13 12:24:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 12:24:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 12:24:25 --> Controller Class Initialized
INFO - 2025-07-13 12:24:25 --> Model "User_model" initialized
INFO - 2025-07-13 12:24:25 --> Form Validation Class Initialized
DEBUG - 2025-07-13 12:24:25 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-07-13 12:24:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-07-13 12:24:25 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\auth/register.php
INFO - 2025-07-13 12:24:25 --> Final output sent to browser
DEBUG - 2025-07-13 12:24:25 --> Total execution time: 0.0852
INFO - 2025-07-13 12:24:32 --> Config Class Initialized
INFO - 2025-07-13 12:24:32 --> Hooks Class Initialized
DEBUG - 2025-07-13 12:24:32 --> UTF-8 Support Enabled
INFO - 2025-07-13 12:24:32 --> Utf8 Class Initialized
INFO - 2025-07-13 12:24:32 --> URI Class Initialized
INFO - 2025-07-13 12:24:32 --> Router Class Initialized
INFO - 2025-07-13 12:24:32 --> Output Class Initialized
INFO - 2025-07-13 12:24:32 --> Security Class Initialized
DEBUG - 2025-07-13 12:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 12:24:32 --> Input Class Initialized
INFO - 2025-07-13 12:24:32 --> Language Class Initialized
INFO - 2025-07-13 12:24:32 --> Loader Class Initialized
INFO - 2025-07-13 12:24:32 --> Helper loaded: url_helper
INFO - 2025-07-13 12:24:32 --> Helper loaded: form_helper
INFO - 2025-07-13 12:24:32 --> Database Driver Class Initialized
DEBUG - 2025-07-13 12:24:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 12:24:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 12:24:32 --> Controller Class Initialized
INFO - 2025-07-13 12:24:32 --> Model "User_model" initialized
INFO - 2025-07-13 12:24:32 --> Form Validation Class Initialized
DEBUG - 2025-07-13 12:24:32 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-07-13 12:24:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-07-13 12:24:32 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\auth/register.php
INFO - 2025-07-13 12:24:32 --> Final output sent to browser
DEBUG - 2025-07-13 12:24:32 --> Total execution time: 0.1373
INFO - 2025-07-13 12:24:44 --> Config Class Initialized
INFO - 2025-07-13 12:24:44 --> Hooks Class Initialized
DEBUG - 2025-07-13 12:24:44 --> UTF-8 Support Enabled
INFO - 2025-07-13 12:24:44 --> Utf8 Class Initialized
INFO - 2025-07-13 12:24:44 --> URI Class Initialized
INFO - 2025-07-13 12:24:44 --> Router Class Initialized
INFO - 2025-07-13 12:24:44 --> Output Class Initialized
INFO - 2025-07-13 12:24:44 --> Security Class Initialized
DEBUG - 2025-07-13 12:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 12:24:44 --> Input Class Initialized
INFO - 2025-07-13 12:24:44 --> Language Class Initialized
INFO - 2025-07-13 12:24:44 --> Loader Class Initialized
INFO - 2025-07-13 12:24:44 --> Helper loaded: url_helper
INFO - 2025-07-13 12:24:44 --> Helper loaded: form_helper
INFO - 2025-07-13 12:24:44 --> Database Driver Class Initialized
DEBUG - 2025-07-13 12:24:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 12:24:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 12:24:44 --> Controller Class Initialized
INFO - 2025-07-13 12:24:44 --> Model "User_model" initialized
INFO - 2025-07-13 12:24:44 --> Form Validation Class Initialized
DEBUG - 2025-07-13 12:24:44 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-07-13 12:24:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-07-13 12:24:44 --> Config Class Initialized
INFO - 2025-07-13 12:24:44 --> Hooks Class Initialized
DEBUG - 2025-07-13 12:24:44 --> UTF-8 Support Enabled
INFO - 2025-07-13 12:24:44 --> Utf8 Class Initialized
INFO - 2025-07-13 12:24:44 --> URI Class Initialized
INFO - 2025-07-13 12:24:44 --> Router Class Initialized
INFO - 2025-07-13 12:24:44 --> Output Class Initialized
INFO - 2025-07-13 12:24:44 --> Security Class Initialized
DEBUG - 2025-07-13 12:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 12:24:44 --> Input Class Initialized
INFO - 2025-07-13 12:24:44 --> Language Class Initialized
INFO - 2025-07-13 12:24:44 --> Loader Class Initialized
INFO - 2025-07-13 12:24:44 --> Helper loaded: url_helper
INFO - 2025-07-13 12:24:44 --> Helper loaded: form_helper
INFO - 2025-07-13 12:24:44 --> Database Driver Class Initialized
DEBUG - 2025-07-13 12:24:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 12:24:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 12:24:44 --> Controller Class Initialized
INFO - 2025-07-13 12:24:44 --> Model "User_model" initialized
INFO - 2025-07-13 12:24:44 --> Form Validation Class Initialized
INFO - 2025-07-13 12:24:44 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\auth/login.php
INFO - 2025-07-13 12:24:44 --> Final output sent to browser
DEBUG - 2025-07-13 12:24:44 --> Total execution time: 0.1022
INFO - 2025-07-13 12:26:14 --> Config Class Initialized
INFO - 2025-07-13 12:26:14 --> Hooks Class Initialized
DEBUG - 2025-07-13 12:26:14 --> UTF-8 Support Enabled
INFO - 2025-07-13 12:26:14 --> Utf8 Class Initialized
INFO - 2025-07-13 12:26:14 --> URI Class Initialized
INFO - 2025-07-13 12:26:14 --> Router Class Initialized
INFO - 2025-07-13 12:26:14 --> Output Class Initialized
INFO - 2025-07-13 12:26:14 --> Security Class Initialized
DEBUG - 2025-07-13 12:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 12:26:14 --> Input Class Initialized
INFO - 2025-07-13 12:26:14 --> Language Class Initialized
INFO - 2025-07-13 12:26:14 --> Loader Class Initialized
INFO - 2025-07-13 12:26:14 --> Helper loaded: url_helper
INFO - 2025-07-13 12:26:14 --> Helper loaded: form_helper
INFO - 2025-07-13 12:26:14 --> Database Driver Class Initialized
DEBUG - 2025-07-13 12:26:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 12:26:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 12:26:14 --> Controller Class Initialized
INFO - 2025-07-13 12:26:14 --> Model "User_model" initialized
INFO - 2025-07-13 12:26:14 --> Form Validation Class Initialized
INFO - 2025-07-13 12:26:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-07-13 12:26:14 --> Config Class Initialized
INFO - 2025-07-13 12:26:14 --> Hooks Class Initialized
DEBUG - 2025-07-13 12:26:14 --> UTF-8 Support Enabled
INFO - 2025-07-13 12:26:14 --> Utf8 Class Initialized
INFO - 2025-07-13 12:26:14 --> URI Class Initialized
INFO - 2025-07-13 12:26:14 --> Router Class Initialized
INFO - 2025-07-13 12:26:14 --> Output Class Initialized
INFO - 2025-07-13 12:26:14 --> Security Class Initialized
DEBUG - 2025-07-13 12:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 12:26:14 --> Input Class Initialized
INFO - 2025-07-13 12:26:14 --> Language Class Initialized
INFO - 2025-07-13 12:26:14 --> Loader Class Initialized
INFO - 2025-07-13 12:26:14 --> Helper loaded: url_helper
INFO - 2025-07-13 12:26:14 --> Helper loaded: form_helper
INFO - 2025-07-13 12:26:14 --> Database Driver Class Initialized
DEBUG - 2025-07-13 12:26:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 12:26:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 12:26:14 --> Controller Class Initialized
INFO - 2025-07-13 12:26:14 --> Model "User_model" initialized
INFO - 2025-07-13 12:26:14 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-07-13 12:26:14 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/home.php
INFO - 2025-07-13 12:26:14 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-07-13 12:26:14 --> Final output sent to browser
DEBUG - 2025-07-13 12:26:14 --> Total execution time: 0.1059
INFO - 2025-07-13 12:26:20 --> Config Class Initialized
INFO - 2025-07-13 12:26:20 --> Hooks Class Initialized
DEBUG - 2025-07-13 12:26:20 --> UTF-8 Support Enabled
INFO - 2025-07-13 12:26:20 --> Utf8 Class Initialized
INFO - 2025-07-13 12:26:20 --> URI Class Initialized
INFO - 2025-07-13 12:26:20 --> Router Class Initialized
INFO - 2025-07-13 12:26:20 --> Output Class Initialized
INFO - 2025-07-13 12:26:20 --> Security Class Initialized
DEBUG - 2025-07-13 12:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 12:26:20 --> Input Class Initialized
INFO - 2025-07-13 12:26:20 --> Language Class Initialized
INFO - 2025-07-13 12:26:20 --> Loader Class Initialized
INFO - 2025-07-13 12:26:20 --> Helper loaded: url_helper
INFO - 2025-07-13 12:26:20 --> Helper loaded: form_helper
INFO - 2025-07-13 12:26:20 --> Database Driver Class Initialized
DEBUG - 2025-07-13 12:26:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 12:26:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 12:26:20 --> Controller Class Initialized
INFO - 2025-07-13 12:26:20 --> Model "User_model" initialized
INFO - 2025-07-13 12:26:20 --> Model "Progress_model" initialized
INFO - 2025-07-13 12:26:20 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-13 12:26:20 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-13 12:26:20 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/dashboard.php
INFO - 2025-07-13 12:26:20 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-13 12:26:20 --> Final output sent to browser
DEBUG - 2025-07-13 12:26:20 --> Total execution time: 0.0944
INFO - 2025-07-13 12:26:23 --> Config Class Initialized
INFO - 2025-07-13 12:26:23 --> Hooks Class Initialized
DEBUG - 2025-07-13 12:26:23 --> UTF-8 Support Enabled
INFO - 2025-07-13 12:26:23 --> Utf8 Class Initialized
INFO - 2025-07-13 12:26:23 --> URI Class Initialized
INFO - 2025-07-13 12:26:23 --> Router Class Initialized
INFO - 2025-07-13 12:26:23 --> Output Class Initialized
INFO - 2025-07-13 12:26:23 --> Security Class Initialized
DEBUG - 2025-07-13 12:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 12:26:23 --> Input Class Initialized
INFO - 2025-07-13 12:26:23 --> Language Class Initialized
INFO - 2025-07-13 12:26:23 --> Loader Class Initialized
INFO - 2025-07-13 12:26:23 --> Helper loaded: url_helper
INFO - 2025-07-13 12:26:23 --> Helper loaded: form_helper
INFO - 2025-07-13 12:26:23 --> Database Driver Class Initialized
DEBUG - 2025-07-13 12:26:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 12:26:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 12:26:23 --> Controller Class Initialized
INFO - 2025-07-13 12:26:23 --> Model "User_model" initialized
INFO - 2025-07-13 12:26:23 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-13 12:26:23 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-13 12:26:23 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/profile.php
INFO - 2025-07-13 12:26:23 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-13 12:26:23 --> Final output sent to browser
DEBUG - 2025-07-13 12:26:23 --> Total execution time: 0.0838
INFO - 2025-07-13 12:26:25 --> Config Class Initialized
INFO - 2025-07-13 12:26:25 --> Hooks Class Initialized
DEBUG - 2025-07-13 12:26:25 --> UTF-8 Support Enabled
INFO - 2025-07-13 12:26:25 --> Utf8 Class Initialized
INFO - 2025-07-13 12:26:25 --> URI Class Initialized
INFO - 2025-07-13 12:26:25 --> Router Class Initialized
INFO - 2025-07-13 12:26:25 --> Output Class Initialized
INFO - 2025-07-13 12:26:25 --> Security Class Initialized
DEBUG - 2025-07-13 12:26:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 12:26:25 --> Input Class Initialized
INFO - 2025-07-13 12:26:25 --> Language Class Initialized
INFO - 2025-07-13 12:26:25 --> Loader Class Initialized
INFO - 2025-07-13 12:26:25 --> Helper loaded: url_helper
INFO - 2025-07-13 12:26:25 --> Helper loaded: form_helper
INFO - 2025-07-13 12:26:25 --> Database Driver Class Initialized
DEBUG - 2025-07-13 12:26:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 12:26:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 12:26:25 --> Controller Class Initialized
INFO - 2025-07-13 12:26:25 --> Model "User_model" initialized
INFO - 2025-07-13 12:26:25 --> Form Validation Class Initialized
INFO - 2025-07-13 12:26:25 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-13 12:26:25 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-13 12:26:25 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/edit_profile.php
INFO - 2025-07-13 12:26:25 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-13 12:26:25 --> Final output sent to browser
DEBUG - 2025-07-13 12:26:25 --> Total execution time: 0.0862
INFO - 2025-07-13 12:26:32 --> Config Class Initialized
INFO - 2025-07-13 12:26:32 --> Hooks Class Initialized
DEBUG - 2025-07-13 12:26:32 --> UTF-8 Support Enabled
INFO - 2025-07-13 12:26:32 --> Utf8 Class Initialized
INFO - 2025-07-13 12:26:32 --> URI Class Initialized
INFO - 2025-07-13 12:26:32 --> Router Class Initialized
INFO - 2025-07-13 12:26:32 --> Output Class Initialized
INFO - 2025-07-13 12:26:32 --> Security Class Initialized
DEBUG - 2025-07-13 12:26:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 12:26:32 --> Input Class Initialized
INFO - 2025-07-13 12:26:32 --> Language Class Initialized
INFO - 2025-07-13 12:26:32 --> Loader Class Initialized
INFO - 2025-07-13 12:26:32 --> Helper loaded: url_helper
INFO - 2025-07-13 12:26:32 --> Helper loaded: form_helper
INFO - 2025-07-13 12:26:32 --> Database Driver Class Initialized
DEBUG - 2025-07-13 12:26:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 12:26:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 12:26:32 --> Controller Class Initialized
INFO - 2025-07-13 12:26:32 --> Model "User_model" initialized
INFO - 2025-07-13 12:26:32 --> Form Validation Class Initialized
INFO - 2025-07-13 12:26:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-07-13 12:26:32 --> Config Class Initialized
INFO - 2025-07-13 12:26:32 --> Hooks Class Initialized
DEBUG - 2025-07-13 12:26:32 --> UTF-8 Support Enabled
INFO - 2025-07-13 12:26:32 --> Utf8 Class Initialized
INFO - 2025-07-13 12:26:32 --> URI Class Initialized
INFO - 2025-07-13 12:26:32 --> Router Class Initialized
INFO - 2025-07-13 12:26:32 --> Output Class Initialized
INFO - 2025-07-13 12:26:32 --> Security Class Initialized
DEBUG - 2025-07-13 12:26:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 12:26:32 --> Input Class Initialized
INFO - 2025-07-13 12:26:32 --> Language Class Initialized
INFO - 2025-07-13 12:26:32 --> Loader Class Initialized
INFO - 2025-07-13 12:26:32 --> Helper loaded: url_helper
INFO - 2025-07-13 12:26:32 --> Helper loaded: form_helper
INFO - 2025-07-13 12:26:33 --> Database Driver Class Initialized
DEBUG - 2025-07-13 12:26:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 12:26:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 12:26:33 --> Controller Class Initialized
INFO - 2025-07-13 12:26:33 --> Model "User_model" initialized
INFO - 2025-07-13 12:26:33 --> Model "Progress_model" initialized
INFO - 2025-07-13 12:26:33 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-13 12:26:33 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-13 12:26:33 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/dashboard.php
INFO - 2025-07-13 12:26:33 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-13 12:26:33 --> Final output sent to browser
DEBUG - 2025-07-13 12:26:33 --> Total execution time: 0.1021
INFO - 2025-07-13 12:28:26 --> Config Class Initialized
INFO - 2025-07-13 12:28:26 --> Hooks Class Initialized
DEBUG - 2025-07-13 12:28:26 --> UTF-8 Support Enabled
INFO - 2025-07-13 12:28:26 --> Utf8 Class Initialized
INFO - 2025-07-13 12:28:26 --> URI Class Initialized
INFO - 2025-07-13 12:28:26 --> Router Class Initialized
INFO - 2025-07-13 12:28:26 --> Output Class Initialized
INFO - 2025-07-13 12:28:26 --> Security Class Initialized
DEBUG - 2025-07-13 12:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 12:28:26 --> Input Class Initialized
INFO - 2025-07-13 12:28:26 --> Language Class Initialized
INFO - 2025-07-13 12:28:26 --> Loader Class Initialized
INFO - 2025-07-13 12:28:26 --> Helper loaded: url_helper
INFO - 2025-07-13 12:28:26 --> Helper loaded: form_helper
INFO - 2025-07-13 12:28:26 --> Database Driver Class Initialized
DEBUG - 2025-07-13 12:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 12:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 12:28:26 --> Controller Class Initialized
INFO - 2025-07-13 12:28:26 --> Model "User_model" initialized
INFO - 2025-07-13 12:28:26 --> Model "Progress_model" initialized
INFO - 2025-07-13 12:28:26 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-13 12:28:26 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-13 12:28:26 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/dashboard.php
INFO - 2025-07-13 12:28:26 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-13 12:28:26 --> Final output sent to browser
DEBUG - 2025-07-13 12:28:26 --> Total execution time: 0.1121
INFO - 2025-07-13 12:28:29 --> Config Class Initialized
INFO - 2025-07-13 12:28:29 --> Hooks Class Initialized
DEBUG - 2025-07-13 12:28:29 --> UTF-8 Support Enabled
INFO - 2025-07-13 12:28:29 --> Utf8 Class Initialized
INFO - 2025-07-13 12:28:29 --> URI Class Initialized
INFO - 2025-07-13 12:28:29 --> Router Class Initialized
INFO - 2025-07-13 12:28:29 --> Output Class Initialized
INFO - 2025-07-13 12:28:29 --> Security Class Initialized
DEBUG - 2025-07-13 12:28:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 12:28:29 --> Input Class Initialized
INFO - 2025-07-13 12:28:29 --> Language Class Initialized
INFO - 2025-07-13 12:28:29 --> Loader Class Initialized
INFO - 2025-07-13 12:28:29 --> Helper loaded: url_helper
INFO - 2025-07-13 12:28:29 --> Helper loaded: form_helper
INFO - 2025-07-13 12:28:29 --> Database Driver Class Initialized
DEBUG - 2025-07-13 12:28:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 12:28:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 12:28:29 --> Controller Class Initialized
INFO - 2025-07-13 12:28:29 --> Model "User_model" initialized
INFO - 2025-07-13 12:28:29 --> Model "Progress_model" initialized
INFO - 2025-07-13 12:28:29 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-13 12:28:29 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-13 12:28:29 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/dashboard.php
INFO - 2025-07-13 12:28:29 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-13 12:28:29 --> Final output sent to browser
DEBUG - 2025-07-13 12:28:29 --> Total execution time: 0.1262
INFO - 2025-07-13 12:29:18 --> Config Class Initialized
INFO - 2025-07-13 12:29:18 --> Hooks Class Initialized
DEBUG - 2025-07-13 12:29:18 --> UTF-8 Support Enabled
INFO - 2025-07-13 12:29:18 --> Utf8 Class Initialized
INFO - 2025-07-13 12:29:18 --> URI Class Initialized
INFO - 2025-07-13 12:29:18 --> Router Class Initialized
INFO - 2025-07-13 12:29:18 --> Output Class Initialized
INFO - 2025-07-13 12:29:18 --> Security Class Initialized
DEBUG - 2025-07-13 12:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 12:29:18 --> Input Class Initialized
INFO - 2025-07-13 12:29:18 --> Language Class Initialized
INFO - 2025-07-13 12:29:18 --> Loader Class Initialized
INFO - 2025-07-13 12:29:18 --> Helper loaded: url_helper
INFO - 2025-07-13 12:29:18 --> Helper loaded: form_helper
INFO - 2025-07-13 12:29:18 --> Database Driver Class Initialized
DEBUG - 2025-07-13 12:29:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 12:29:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 12:29:18 --> Controller Class Initialized
INFO - 2025-07-13 12:29:18 --> Model "User_model" initialized
INFO - 2025-07-13 12:29:18 --> Model "Progress_model" initialized
INFO - 2025-07-13 12:29:18 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-13 12:29:18 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-13 12:29:18 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/guide.php
INFO - 2025-07-13 12:29:18 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-13 12:29:18 --> Final output sent to browser
DEBUG - 2025-07-13 12:29:18 --> Total execution time: 0.1056
INFO - 2025-07-13 12:29:53 --> Config Class Initialized
INFO - 2025-07-13 12:29:53 --> Hooks Class Initialized
DEBUG - 2025-07-13 12:29:53 --> UTF-8 Support Enabled
INFO - 2025-07-13 12:29:53 --> Utf8 Class Initialized
INFO - 2025-07-13 12:29:53 --> URI Class Initialized
INFO - 2025-07-13 12:29:53 --> Router Class Initialized
INFO - 2025-07-13 12:29:53 --> Output Class Initialized
INFO - 2025-07-13 12:29:53 --> Security Class Initialized
DEBUG - 2025-07-13 12:29:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 12:29:53 --> Input Class Initialized
INFO - 2025-07-13 12:29:53 --> Language Class Initialized
INFO - 2025-07-13 12:29:54 --> Loader Class Initialized
INFO - 2025-07-13 12:29:54 --> Helper loaded: url_helper
INFO - 2025-07-13 12:29:54 --> Helper loaded: form_helper
INFO - 2025-07-13 12:29:54 --> Database Driver Class Initialized
DEBUG - 2025-07-13 12:29:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 12:29:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 12:29:54 --> Controller Class Initialized
INFO - 2025-07-13 12:29:54 --> Model "Progress_model" initialized
INFO - 2025-07-13 12:29:54 --> Model "Olahraga_model" initialized
INFO - 2025-07-13 12:29:54 --> Model "User_model" initialized
INFO - 2025-07-13 12:29:54 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-13 12:29:54 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-13 12:29:54 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/progress_view.php
INFO - 2025-07-13 12:29:54 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-13 12:29:54 --> Final output sent to browser
DEBUG - 2025-07-13 12:29:54 --> Total execution time: 0.0879
INFO - 2025-07-13 12:29:54 --> Config Class Initialized
INFO - 2025-07-13 12:29:54 --> Hooks Class Initialized
DEBUG - 2025-07-13 12:29:54 --> UTF-8 Support Enabled
INFO - 2025-07-13 12:29:54 --> Utf8 Class Initialized
INFO - 2025-07-13 12:29:54 --> URI Class Initialized
INFO - 2025-07-13 12:29:54 --> Router Class Initialized
INFO - 2025-07-13 12:29:54 --> Output Class Initialized
INFO - 2025-07-13 12:29:54 --> Security Class Initialized
DEBUG - 2025-07-13 12:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 12:29:54 --> Input Class Initialized
INFO - 2025-07-13 12:29:54 --> Language Class Initialized
INFO - 2025-07-13 12:29:54 --> Loader Class Initialized
INFO - 2025-07-13 12:29:54 --> Helper loaded: url_helper
INFO - 2025-07-13 12:29:54 --> Helper loaded: form_helper
INFO - 2025-07-13 12:29:54 --> Database Driver Class Initialized
DEBUG - 2025-07-13 12:29:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 12:29:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 12:29:55 --> Controller Class Initialized
INFO - 2025-07-13 12:29:55 --> Model "Progress_model" initialized
INFO - 2025-07-13 12:29:55 --> Model "Olahraga_model" initialized
INFO - 2025-07-13 12:29:55 --> Model "User_model" initialized
INFO - 2025-07-13 12:29:55 --> Final output sent to browser
DEBUG - 2025-07-13 12:29:55 --> Total execution time: 0.2271
INFO - 2025-07-13 12:29:56 --> Config Class Initialized
INFO - 2025-07-13 12:29:56 --> Hooks Class Initialized
DEBUG - 2025-07-13 12:29:56 --> UTF-8 Support Enabled
INFO - 2025-07-13 12:29:56 --> Utf8 Class Initialized
INFO - 2025-07-13 12:29:56 --> URI Class Initialized
INFO - 2025-07-13 12:29:56 --> Router Class Initialized
INFO - 2025-07-13 12:29:56 --> Output Class Initialized
INFO - 2025-07-13 12:29:56 --> Security Class Initialized
DEBUG - 2025-07-13 12:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 12:29:56 --> Input Class Initialized
INFO - 2025-07-13 12:29:56 --> Language Class Initialized
INFO - 2025-07-13 12:29:56 --> Loader Class Initialized
INFO - 2025-07-13 12:29:56 --> Helper loaded: url_helper
INFO - 2025-07-13 12:29:56 --> Helper loaded: form_helper
INFO - 2025-07-13 12:29:56 --> Database Driver Class Initialized
DEBUG - 2025-07-13 12:29:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 12:29:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 12:29:56 --> Controller Class Initialized
INFO - 2025-07-13 12:29:56 --> Model "Progress_model" initialized
INFO - 2025-07-13 12:29:56 --> Model "Olahraga_model" initialized
INFO - 2025-07-13 12:29:56 --> Model "User_model" initialized
INFO - 2025-07-13 12:29:56 --> Final output sent to browser
DEBUG - 2025-07-13 12:29:56 --> Total execution time: 0.0681
INFO - 2025-07-13 12:30:28 --> Config Class Initialized
INFO - 2025-07-13 12:30:28 --> Hooks Class Initialized
DEBUG - 2025-07-13 12:30:28 --> UTF-8 Support Enabled
INFO - 2025-07-13 12:30:28 --> Utf8 Class Initialized
INFO - 2025-07-13 12:30:28 --> URI Class Initialized
INFO - 2025-07-13 12:30:28 --> Router Class Initialized
INFO - 2025-07-13 12:30:28 --> Output Class Initialized
INFO - 2025-07-13 12:30:28 --> Security Class Initialized
DEBUG - 2025-07-13 12:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 12:30:28 --> Input Class Initialized
INFO - 2025-07-13 12:30:28 --> Language Class Initialized
INFO - 2025-07-13 12:30:28 --> Loader Class Initialized
INFO - 2025-07-13 12:30:28 --> Helper loaded: url_helper
INFO - 2025-07-13 12:30:28 --> Helper loaded: form_helper
INFO - 2025-07-13 12:30:28 --> Database Driver Class Initialized
DEBUG - 2025-07-13 12:30:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 12:30:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 12:30:28 --> Controller Class Initialized
INFO - 2025-07-13 12:30:28 --> Model "Olahraga_model" initialized
INFO - 2025-07-13 12:30:28 --> Model "User_model" initialized
INFO - 2025-07-13 12:30:28 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-13 12:30:28 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-13 12:30:28 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-07-13 12:30:28 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-13 12:30:28 --> Final output sent to browser
DEBUG - 2025-07-13 12:30:28 --> Total execution time: 0.0831
INFO - 2025-07-13 12:30:31 --> Config Class Initialized
INFO - 2025-07-13 12:30:31 --> Hooks Class Initialized
DEBUG - 2025-07-13 12:30:31 --> UTF-8 Support Enabled
INFO - 2025-07-13 12:30:31 --> Utf8 Class Initialized
INFO - 2025-07-13 12:30:31 --> URI Class Initialized
INFO - 2025-07-13 12:30:31 --> Router Class Initialized
INFO - 2025-07-13 12:30:31 --> Output Class Initialized
INFO - 2025-07-13 12:30:31 --> Security Class Initialized
DEBUG - 2025-07-13 12:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 12:30:31 --> Input Class Initialized
INFO - 2025-07-13 12:30:31 --> Language Class Initialized
INFO - 2025-07-13 12:30:31 --> Loader Class Initialized
INFO - 2025-07-13 12:30:31 --> Helper loaded: url_helper
INFO - 2025-07-13 12:30:31 --> Helper loaded: form_helper
INFO - 2025-07-13 12:30:31 --> Database Driver Class Initialized
DEBUG - 2025-07-13 12:30:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 12:30:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 12:30:31 --> Controller Class Initialized
INFO - 2025-07-13 12:30:31 --> Model "Olahraga_model" initialized
INFO - 2025-07-13 12:30:31 --> Model "User_model" initialized
INFO - 2025-07-13 12:30:31 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-13 12:30:31 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-13 12:30:31 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/level.php
INFO - 2025-07-13 12:30:31 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-13 12:30:31 --> Final output sent to browser
DEBUG - 2025-07-13 12:30:31 --> Total execution time: 0.0892
INFO - 2025-07-13 12:30:33 --> Config Class Initialized
INFO - 2025-07-13 12:30:33 --> Hooks Class Initialized
DEBUG - 2025-07-13 12:30:33 --> UTF-8 Support Enabled
INFO - 2025-07-13 12:30:33 --> Utf8 Class Initialized
INFO - 2025-07-13 12:30:33 --> URI Class Initialized
INFO - 2025-07-13 12:30:33 --> Router Class Initialized
INFO - 2025-07-13 12:30:33 --> Output Class Initialized
INFO - 2025-07-13 12:30:33 --> Security Class Initialized
DEBUG - 2025-07-13 12:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 12:30:33 --> Input Class Initialized
INFO - 2025-07-13 12:30:33 --> Language Class Initialized
INFO - 2025-07-13 12:30:33 --> Loader Class Initialized
INFO - 2025-07-13 12:30:33 --> Helper loaded: url_helper
INFO - 2025-07-13 12:30:33 --> Helper loaded: form_helper
INFO - 2025-07-13 12:30:33 --> Database Driver Class Initialized
DEBUG - 2025-07-13 12:30:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 12:30:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 12:30:33 --> Controller Class Initialized
INFO - 2025-07-13 12:30:33 --> Model "Olahraga_model" initialized
INFO - 2025-07-13 12:30:33 --> Model "User_model" initialized
INFO - 2025-07-13 12:30:33 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-13 12:30:33 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-13 12:30:33 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-07-13 12:30:33 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-13 12:30:33 --> Final output sent to browser
DEBUG - 2025-07-13 12:30:33 --> Total execution time: 0.0794
INFO - 2025-07-13 12:30:37 --> Config Class Initialized
INFO - 2025-07-13 12:30:37 --> Hooks Class Initialized
DEBUG - 2025-07-13 12:30:37 --> UTF-8 Support Enabled
INFO - 2025-07-13 12:30:37 --> Utf8 Class Initialized
INFO - 2025-07-13 12:30:37 --> URI Class Initialized
INFO - 2025-07-13 12:30:37 --> Router Class Initialized
INFO - 2025-07-13 12:30:37 --> Output Class Initialized
INFO - 2025-07-13 12:30:37 --> Security Class Initialized
DEBUG - 2025-07-13 12:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 12:30:37 --> Input Class Initialized
INFO - 2025-07-13 12:30:37 --> Language Class Initialized
INFO - 2025-07-13 12:30:37 --> Loader Class Initialized
INFO - 2025-07-13 12:30:37 --> Helper loaded: url_helper
INFO - 2025-07-13 12:30:37 --> Helper loaded: form_helper
INFO - 2025-07-13 12:30:37 --> Database Driver Class Initialized
DEBUG - 2025-07-13 12:30:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 12:30:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 12:30:37 --> Controller Class Initialized
INFO - 2025-07-13 12:30:37 --> Model "Olahraga_model" initialized
INFO - 2025-07-13 12:30:37 --> Model "User_model" initialized
INFO - 2025-07-13 12:30:37 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-13 12:30:37 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-13 12:30:37 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/start.php
INFO - 2025-07-13 12:30:37 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-13 12:30:37 --> Final output sent to browser
DEBUG - 2025-07-13 12:30:37 --> Total execution time: 0.1023
INFO - 2025-07-13 12:31:19 --> Config Class Initialized
INFO - 2025-07-13 12:31:19 --> Hooks Class Initialized
DEBUG - 2025-07-13 12:31:19 --> UTF-8 Support Enabled
INFO - 2025-07-13 12:31:19 --> Utf8 Class Initialized
INFO - 2025-07-13 12:31:19 --> URI Class Initialized
INFO - 2025-07-13 12:31:19 --> Router Class Initialized
INFO - 2025-07-13 12:31:19 --> Output Class Initialized
INFO - 2025-07-13 12:31:19 --> Security Class Initialized
DEBUG - 2025-07-13 12:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 12:31:19 --> Input Class Initialized
INFO - 2025-07-13 12:31:19 --> Language Class Initialized
INFO - 2025-07-13 12:31:19 --> Loader Class Initialized
INFO - 2025-07-13 12:31:19 --> Helper loaded: url_helper
INFO - 2025-07-13 12:31:19 --> Helper loaded: form_helper
INFO - 2025-07-13 12:31:19 --> Database Driver Class Initialized
DEBUG - 2025-07-13 12:31:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 12:31:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 12:31:19 --> Controller Class Initialized
INFO - 2025-07-13 12:31:19 --> Model "User_model" initialized
INFO - 2025-07-13 12:31:19 --> Model "Community_model" initialized
INFO - 2025-07-13 12:31:19 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-13 12:31:19 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-13 12:31:19 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/community.php
INFO - 2025-07-13 12:31:19 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-13 12:31:19 --> Final output sent to browser
DEBUG - 2025-07-13 12:31:19 --> Total execution time: 0.0988
INFO - 2025-07-13 12:31:33 --> Config Class Initialized
INFO - 2025-07-13 12:31:33 --> Hooks Class Initialized
DEBUG - 2025-07-13 12:31:33 --> UTF-8 Support Enabled
INFO - 2025-07-13 12:31:33 --> Utf8 Class Initialized
INFO - 2025-07-13 12:31:33 --> URI Class Initialized
INFO - 2025-07-13 12:31:33 --> Router Class Initialized
INFO - 2025-07-13 12:31:33 --> Output Class Initialized
INFO - 2025-07-13 12:31:33 --> Security Class Initialized
DEBUG - 2025-07-13 12:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 12:31:33 --> Input Class Initialized
INFO - 2025-07-13 12:31:33 --> Language Class Initialized
INFO - 2025-07-13 12:31:33 --> Loader Class Initialized
INFO - 2025-07-13 12:31:33 --> Helper loaded: url_helper
INFO - 2025-07-13 12:31:33 --> Helper loaded: form_helper
INFO - 2025-07-13 12:31:33 --> Database Driver Class Initialized
DEBUG - 2025-07-13 12:31:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 12:31:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 12:31:33 --> Controller Class Initialized
INFO - 2025-07-13 12:31:33 --> Model "User_model" initialized
INFO - 2025-07-13 12:31:33 --> Model "Community_model" initialized
INFO - 2025-07-13 12:31:33 --> Config Class Initialized
INFO - 2025-07-13 12:31:33 --> Hooks Class Initialized
DEBUG - 2025-07-13 12:31:33 --> UTF-8 Support Enabled
INFO - 2025-07-13 12:31:33 --> Utf8 Class Initialized
INFO - 2025-07-13 12:31:33 --> URI Class Initialized
INFO - 2025-07-13 12:31:33 --> Router Class Initialized
INFO - 2025-07-13 12:31:33 --> Output Class Initialized
INFO - 2025-07-13 12:31:33 --> Security Class Initialized
DEBUG - 2025-07-13 12:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 12:31:33 --> Input Class Initialized
INFO - 2025-07-13 12:31:33 --> Language Class Initialized
INFO - 2025-07-13 12:31:33 --> Loader Class Initialized
INFO - 2025-07-13 12:31:33 --> Helper loaded: url_helper
INFO - 2025-07-13 12:31:33 --> Helper loaded: form_helper
INFO - 2025-07-13 12:31:33 --> Database Driver Class Initialized
DEBUG - 2025-07-13 12:31:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 12:31:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 12:31:33 --> Controller Class Initialized
INFO - 2025-07-13 12:31:33 --> Model "User_model" initialized
INFO - 2025-07-13 12:31:33 --> Model "Community_model" initialized
INFO - 2025-07-13 12:31:33 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-13 12:31:33 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-13 12:31:33 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/community.php
INFO - 2025-07-13 12:31:33 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-13 12:31:33 --> Final output sent to browser
DEBUG - 2025-07-13 12:31:33 --> Total execution time: 0.0999
INFO - 2025-07-13 12:46:32 --> Config Class Initialized
INFO - 2025-07-13 12:46:32 --> Hooks Class Initialized
DEBUG - 2025-07-13 12:46:32 --> UTF-8 Support Enabled
INFO - 2025-07-13 12:46:32 --> Utf8 Class Initialized
INFO - 2025-07-13 12:46:32 --> URI Class Initialized
INFO - 2025-07-13 12:46:32 --> Router Class Initialized
INFO - 2025-07-13 12:46:32 --> Output Class Initialized
INFO - 2025-07-13 12:46:32 --> Security Class Initialized
DEBUG - 2025-07-13 12:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 12:46:32 --> Input Class Initialized
INFO - 2025-07-13 12:46:32 --> Language Class Initialized
INFO - 2025-07-13 12:46:32 --> Loader Class Initialized
INFO - 2025-07-13 12:46:32 --> Helper loaded: url_helper
INFO - 2025-07-13 12:46:32 --> Helper loaded: form_helper
INFO - 2025-07-13 12:46:32 --> Database Driver Class Initialized
DEBUG - 2025-07-13 12:46:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 12:46:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 12:46:32 --> Controller Class Initialized
INFO - 2025-07-13 12:46:32 --> Model "User_model" initialized
INFO - 2025-07-13 12:46:32 --> Form Validation Class Initialized
INFO - 2025-07-13 12:46:32 --> Config Class Initialized
INFO - 2025-07-13 12:46:32 --> Hooks Class Initialized
DEBUG - 2025-07-13 12:46:32 --> UTF-8 Support Enabled
INFO - 2025-07-13 12:46:32 --> Utf8 Class Initialized
INFO - 2025-07-13 12:46:32 --> URI Class Initialized
INFO - 2025-07-13 12:46:32 --> Router Class Initialized
INFO - 2025-07-13 12:46:32 --> Output Class Initialized
INFO - 2025-07-13 12:46:32 --> Security Class Initialized
DEBUG - 2025-07-13 12:46:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 12:46:32 --> Input Class Initialized
INFO - 2025-07-13 12:46:32 --> Language Class Initialized
INFO - 2025-07-13 12:46:32 --> Loader Class Initialized
INFO - 2025-07-13 12:46:32 --> Helper loaded: url_helper
INFO - 2025-07-13 12:46:32 --> Helper loaded: form_helper
INFO - 2025-07-13 12:46:32 --> Database Driver Class Initialized
DEBUG - 2025-07-13 12:46:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 12:46:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 12:46:32 --> Controller Class Initialized
INFO - 2025-07-13 12:46:32 --> Model "User_model" initialized
INFO - 2025-07-13 12:46:32 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-07-13 12:46:32 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/home.php
INFO - 2025-07-13 12:46:32 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-07-13 12:46:32 --> Final output sent to browser
DEBUG - 2025-07-13 12:46:32 --> Total execution time: 0.0901
INFO - 2025-07-13 13:33:53 --> Config Class Initialized
INFO - 2025-07-13 13:33:53 --> Hooks Class Initialized
DEBUG - 2025-07-13 13:33:53 --> UTF-8 Support Enabled
INFO - 2025-07-13 13:33:53 --> Utf8 Class Initialized
INFO - 2025-07-13 13:33:53 --> URI Class Initialized
DEBUG - 2025-07-13 13:33:53 --> No URI present. Default controller set.
INFO - 2025-07-13 13:33:53 --> Router Class Initialized
INFO - 2025-07-13 13:33:53 --> Output Class Initialized
INFO - 2025-07-13 13:33:53 --> Security Class Initialized
DEBUG - 2025-07-13 13:33:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 13:33:53 --> Input Class Initialized
INFO - 2025-07-13 13:33:53 --> Language Class Initialized
INFO - 2025-07-13 13:33:53 --> Loader Class Initialized
INFO - 2025-07-13 13:33:53 --> Helper loaded: url_helper
INFO - 2025-07-13 13:33:53 --> Helper loaded: form_helper
INFO - 2025-07-13 13:33:53 --> Database Driver Class Initialized
DEBUG - 2025-07-13 13:33:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 13:33:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 13:33:53 --> Controller Class Initialized
INFO - 2025-07-13 13:33:53 --> Model "User_model" initialized
INFO - 2025-07-13 13:33:53 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-07-13 13:33:53 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/home.php
INFO - 2025-07-13 13:33:53 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-07-13 13:33:53 --> Final output sent to browser
DEBUG - 2025-07-13 13:33:53 --> Total execution time: 0.1456
INFO - 2025-07-13 13:33:57 --> Config Class Initialized
INFO - 2025-07-13 13:33:57 --> Hooks Class Initialized
DEBUG - 2025-07-13 13:33:57 --> UTF-8 Support Enabled
INFO - 2025-07-13 13:33:57 --> Utf8 Class Initialized
INFO - 2025-07-13 13:33:57 --> URI Class Initialized
INFO - 2025-07-13 13:33:57 --> Router Class Initialized
INFO - 2025-07-13 13:33:57 --> Output Class Initialized
INFO - 2025-07-13 13:33:57 --> Security Class Initialized
DEBUG - 2025-07-13 13:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 13:33:57 --> Input Class Initialized
INFO - 2025-07-13 13:33:57 --> Language Class Initialized
INFO - 2025-07-13 13:33:57 --> Loader Class Initialized
INFO - 2025-07-13 13:33:57 --> Helper loaded: url_helper
INFO - 2025-07-13 13:33:57 --> Helper loaded: form_helper
INFO - 2025-07-13 13:33:57 --> Database Driver Class Initialized
DEBUG - 2025-07-13 13:33:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 13:33:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 13:33:57 --> Controller Class Initialized
INFO - 2025-07-13 13:33:57 --> Model "User_model" initialized
INFO - 2025-07-13 13:33:57 --> Form Validation Class Initialized
INFO - 2025-07-13 13:33:57 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\auth/login.php
INFO - 2025-07-13 13:33:57 --> Final output sent to browser
DEBUG - 2025-07-13 13:33:57 --> Total execution time: 0.0961
INFO - 2025-07-13 13:34:02 --> Config Class Initialized
INFO - 2025-07-13 13:34:02 --> Hooks Class Initialized
DEBUG - 2025-07-13 13:34:02 --> UTF-8 Support Enabled
INFO - 2025-07-13 13:34:02 --> Utf8 Class Initialized
INFO - 2025-07-13 13:34:02 --> URI Class Initialized
INFO - 2025-07-13 13:34:02 --> Router Class Initialized
INFO - 2025-07-13 13:34:02 --> Output Class Initialized
INFO - 2025-07-13 13:34:02 --> Security Class Initialized
DEBUG - 2025-07-13 13:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 13:34:02 --> Input Class Initialized
INFO - 2025-07-13 13:34:02 --> Language Class Initialized
INFO - 2025-07-13 13:34:02 --> Loader Class Initialized
INFO - 2025-07-13 13:34:02 --> Helper loaded: url_helper
INFO - 2025-07-13 13:34:02 --> Helper loaded: form_helper
INFO - 2025-07-13 13:34:02 --> Database Driver Class Initialized
DEBUG - 2025-07-13 13:34:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 13:34:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 13:34:02 --> Controller Class Initialized
INFO - 2025-07-13 13:34:02 --> Model "User_model" initialized
INFO - 2025-07-13 13:34:02 --> Form Validation Class Initialized
DEBUG - 2025-07-13 13:34:02 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-07-13 13:34:02 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\auth/register.php
INFO - 2025-07-13 13:34:02 --> Final output sent to browser
DEBUG - 2025-07-13 13:34:02 --> Total execution time: 0.0855
INFO - 2025-07-13 13:34:29 --> Config Class Initialized
INFO - 2025-07-13 13:34:29 --> Hooks Class Initialized
DEBUG - 2025-07-13 13:34:29 --> UTF-8 Support Enabled
INFO - 2025-07-13 13:34:29 --> Utf8 Class Initialized
INFO - 2025-07-13 13:34:29 --> URI Class Initialized
INFO - 2025-07-13 13:34:29 --> Router Class Initialized
INFO - 2025-07-13 13:34:29 --> Output Class Initialized
INFO - 2025-07-13 13:34:29 --> Security Class Initialized
DEBUG - 2025-07-13 13:34:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 13:34:29 --> Input Class Initialized
INFO - 2025-07-13 13:34:29 --> Language Class Initialized
INFO - 2025-07-13 13:34:29 --> Loader Class Initialized
INFO - 2025-07-13 13:34:29 --> Helper loaded: url_helper
INFO - 2025-07-13 13:34:29 --> Helper loaded: form_helper
INFO - 2025-07-13 13:34:29 --> Database Driver Class Initialized
DEBUG - 2025-07-13 13:34:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 13:34:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 13:34:29 --> Controller Class Initialized
INFO - 2025-07-13 13:34:29 --> Model "User_model" initialized
INFO - 2025-07-13 13:34:29 --> Form Validation Class Initialized
DEBUG - 2025-07-13 13:34:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-07-13 13:34:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-07-13 13:34:29 --> Config Class Initialized
INFO - 2025-07-13 13:34:29 --> Hooks Class Initialized
DEBUG - 2025-07-13 13:34:29 --> UTF-8 Support Enabled
INFO - 2025-07-13 13:34:29 --> Utf8 Class Initialized
INFO - 2025-07-13 13:34:29 --> URI Class Initialized
INFO - 2025-07-13 13:34:29 --> Router Class Initialized
INFO - 2025-07-13 13:34:29 --> Output Class Initialized
INFO - 2025-07-13 13:34:29 --> Security Class Initialized
DEBUG - 2025-07-13 13:34:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 13:34:29 --> Input Class Initialized
INFO - 2025-07-13 13:34:29 --> Language Class Initialized
INFO - 2025-07-13 13:34:29 --> Loader Class Initialized
INFO - 2025-07-13 13:34:29 --> Helper loaded: url_helper
INFO - 2025-07-13 13:34:29 --> Helper loaded: form_helper
INFO - 2025-07-13 13:34:29 --> Database Driver Class Initialized
DEBUG - 2025-07-13 13:34:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 13:34:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 13:34:29 --> Controller Class Initialized
INFO - 2025-07-13 13:34:29 --> Model "User_model" initialized
INFO - 2025-07-13 13:34:29 --> Form Validation Class Initialized
INFO - 2025-07-13 13:34:29 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\auth/login.php
INFO - 2025-07-13 13:34:29 --> Final output sent to browser
DEBUG - 2025-07-13 13:34:29 --> Total execution time: 0.0812
INFO - 2025-07-13 13:35:32 --> Config Class Initialized
INFO - 2025-07-13 13:35:32 --> Hooks Class Initialized
DEBUG - 2025-07-13 13:35:32 --> UTF-8 Support Enabled
INFO - 2025-07-13 13:35:32 --> Utf8 Class Initialized
INFO - 2025-07-13 13:35:32 --> URI Class Initialized
DEBUG - 2025-07-13 13:35:32 --> No URI present. Default controller set.
INFO - 2025-07-13 13:35:32 --> Router Class Initialized
INFO - 2025-07-13 13:35:32 --> Output Class Initialized
INFO - 2025-07-13 13:35:32 --> Security Class Initialized
DEBUG - 2025-07-13 13:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 13:35:32 --> Input Class Initialized
INFO - 2025-07-13 13:35:32 --> Language Class Initialized
INFO - 2025-07-13 13:35:32 --> Loader Class Initialized
INFO - 2025-07-13 13:35:32 --> Helper loaded: url_helper
INFO - 2025-07-13 13:35:32 --> Helper loaded: form_helper
INFO - 2025-07-13 13:35:32 --> Database Driver Class Initialized
DEBUG - 2025-07-13 13:35:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 13:35:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 13:35:32 --> Controller Class Initialized
INFO - 2025-07-13 13:35:32 --> Model "User_model" initialized
INFO - 2025-07-13 13:35:32 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-07-13 13:35:32 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/home.php
INFO - 2025-07-13 13:35:32 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-07-13 13:35:32 --> Final output sent to browser
DEBUG - 2025-07-13 13:35:32 --> Total execution time: 0.0870
INFO - 2025-07-13 13:35:34 --> Config Class Initialized
INFO - 2025-07-13 13:35:34 --> Hooks Class Initialized
DEBUG - 2025-07-13 13:35:34 --> UTF-8 Support Enabled
INFO - 2025-07-13 13:35:34 --> Utf8 Class Initialized
INFO - 2025-07-13 13:35:34 --> URI Class Initialized
INFO - 2025-07-13 13:35:34 --> Router Class Initialized
INFO - 2025-07-13 13:35:34 --> Output Class Initialized
INFO - 2025-07-13 13:35:34 --> Security Class Initialized
DEBUG - 2025-07-13 13:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 13:35:34 --> Input Class Initialized
INFO - 2025-07-13 13:35:34 --> Language Class Initialized
INFO - 2025-07-13 13:35:34 --> Loader Class Initialized
INFO - 2025-07-13 13:35:34 --> Helper loaded: url_helper
INFO - 2025-07-13 13:35:34 --> Helper loaded: form_helper
INFO - 2025-07-13 13:35:34 --> Database Driver Class Initialized
DEBUG - 2025-07-13 13:35:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 13:35:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 13:35:34 --> Controller Class Initialized
INFO - 2025-07-13 13:35:34 --> Model "User_model" initialized
INFO - 2025-07-13 13:35:34 --> Form Validation Class Initialized
INFO - 2025-07-13 13:35:34 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\auth/login.php
INFO - 2025-07-13 13:35:34 --> Final output sent to browser
DEBUG - 2025-07-13 13:35:34 --> Total execution time: 0.0830
INFO - 2025-07-13 13:35:37 --> Config Class Initialized
INFO - 2025-07-13 13:35:37 --> Hooks Class Initialized
DEBUG - 2025-07-13 13:35:37 --> UTF-8 Support Enabled
INFO - 2025-07-13 13:35:37 --> Utf8 Class Initialized
INFO - 2025-07-13 13:35:37 --> URI Class Initialized
INFO - 2025-07-13 13:35:37 --> Router Class Initialized
INFO - 2025-07-13 13:35:37 --> Output Class Initialized
INFO - 2025-07-13 13:35:37 --> Security Class Initialized
DEBUG - 2025-07-13 13:35:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 13:35:37 --> Input Class Initialized
INFO - 2025-07-13 13:35:37 --> Language Class Initialized
INFO - 2025-07-13 13:35:37 --> Loader Class Initialized
INFO - 2025-07-13 13:35:37 --> Helper loaded: url_helper
INFO - 2025-07-13 13:35:37 --> Helper loaded: form_helper
INFO - 2025-07-13 13:35:37 --> Database Driver Class Initialized
DEBUG - 2025-07-13 13:35:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 13:35:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 13:35:37 --> Controller Class Initialized
INFO - 2025-07-13 13:35:37 --> Model "User_model" initialized
INFO - 2025-07-13 13:35:37 --> Form Validation Class Initialized
DEBUG - 2025-07-13 13:35:37 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-07-13 13:35:37 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\auth/register.php
INFO - 2025-07-13 13:35:37 --> Final output sent to browser
DEBUG - 2025-07-13 13:35:37 --> Total execution time: 0.0902
INFO - 2025-07-13 13:39:07 --> Config Class Initialized
INFO - 2025-07-13 13:39:07 --> Hooks Class Initialized
DEBUG - 2025-07-13 13:39:07 --> UTF-8 Support Enabled
INFO - 2025-07-13 13:39:07 --> Utf8 Class Initialized
INFO - 2025-07-13 13:39:07 --> URI Class Initialized
INFO - 2025-07-13 13:39:07 --> Router Class Initialized
INFO - 2025-07-13 13:39:07 --> Output Class Initialized
INFO - 2025-07-13 13:39:07 --> Security Class Initialized
DEBUG - 2025-07-13 13:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 13:39:07 --> Input Class Initialized
INFO - 2025-07-13 13:39:07 --> Language Class Initialized
INFO - 2025-07-13 13:39:07 --> Loader Class Initialized
INFO - 2025-07-13 13:39:07 --> Helper loaded: url_helper
INFO - 2025-07-13 13:39:07 --> Helper loaded: form_helper
INFO - 2025-07-13 13:39:07 --> Database Driver Class Initialized
DEBUG - 2025-07-13 13:39:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 13:39:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 13:39:07 --> Controller Class Initialized
INFO - 2025-07-13 13:39:07 --> Model "User_model" initialized
INFO - 2025-07-13 13:39:07 --> Form Validation Class Initialized
DEBUG - 2025-07-13 13:39:07 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-07-13 13:39:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-07-13 13:39:07 --> Config Class Initialized
INFO - 2025-07-13 13:39:07 --> Hooks Class Initialized
DEBUG - 2025-07-13 13:39:07 --> UTF-8 Support Enabled
INFO - 2025-07-13 13:39:07 --> Utf8 Class Initialized
INFO - 2025-07-13 13:39:07 --> URI Class Initialized
INFO - 2025-07-13 13:39:07 --> Router Class Initialized
INFO - 2025-07-13 13:39:07 --> Output Class Initialized
INFO - 2025-07-13 13:39:07 --> Security Class Initialized
DEBUG - 2025-07-13 13:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 13:39:07 --> Input Class Initialized
INFO - 2025-07-13 13:39:07 --> Language Class Initialized
INFO - 2025-07-13 13:39:07 --> Loader Class Initialized
INFO - 2025-07-13 13:39:07 --> Helper loaded: url_helper
INFO - 2025-07-13 13:39:07 --> Helper loaded: form_helper
INFO - 2025-07-13 13:39:07 --> Database Driver Class Initialized
DEBUG - 2025-07-13 13:39:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 13:39:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 13:39:07 --> Controller Class Initialized
INFO - 2025-07-13 13:39:07 --> Model "User_model" initialized
INFO - 2025-07-13 13:39:07 --> Form Validation Class Initialized
INFO - 2025-07-13 13:39:07 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\auth/login.php
INFO - 2025-07-13 13:39:07 --> Final output sent to browser
DEBUG - 2025-07-13 13:39:07 --> Total execution time: 0.0754
INFO - 2025-07-13 13:39:14 --> Config Class Initialized
INFO - 2025-07-13 13:39:14 --> Hooks Class Initialized
DEBUG - 2025-07-13 13:39:14 --> UTF-8 Support Enabled
INFO - 2025-07-13 13:39:14 --> Utf8 Class Initialized
INFO - 2025-07-13 13:39:14 --> URI Class Initialized
INFO - 2025-07-13 13:39:14 --> Router Class Initialized
INFO - 2025-07-13 13:39:14 --> Output Class Initialized
INFO - 2025-07-13 13:39:14 --> Security Class Initialized
DEBUG - 2025-07-13 13:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 13:39:14 --> Input Class Initialized
INFO - 2025-07-13 13:39:14 --> Language Class Initialized
INFO - 2025-07-13 13:39:14 --> Loader Class Initialized
INFO - 2025-07-13 13:39:14 --> Helper loaded: url_helper
INFO - 2025-07-13 13:39:14 --> Helper loaded: form_helper
INFO - 2025-07-13 13:39:14 --> Database Driver Class Initialized
DEBUG - 2025-07-13 13:39:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 13:39:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 13:39:14 --> Controller Class Initialized
INFO - 2025-07-13 13:39:14 --> Model "User_model" initialized
INFO - 2025-07-13 13:39:14 --> Form Validation Class Initialized
INFO - 2025-07-13 13:39:14 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-07-13 13:39:14 --> Config Class Initialized
INFO - 2025-07-13 13:39:14 --> Hooks Class Initialized
DEBUG - 2025-07-13 13:39:14 --> UTF-8 Support Enabled
INFO - 2025-07-13 13:39:14 --> Utf8 Class Initialized
INFO - 2025-07-13 13:39:14 --> URI Class Initialized
INFO - 2025-07-13 13:39:14 --> Router Class Initialized
INFO - 2025-07-13 13:39:14 --> Output Class Initialized
INFO - 2025-07-13 13:39:14 --> Security Class Initialized
DEBUG - 2025-07-13 13:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 13:39:14 --> Input Class Initialized
INFO - 2025-07-13 13:39:14 --> Language Class Initialized
INFO - 2025-07-13 13:39:14 --> Loader Class Initialized
INFO - 2025-07-13 13:39:14 --> Helper loaded: url_helper
INFO - 2025-07-13 13:39:14 --> Helper loaded: form_helper
INFO - 2025-07-13 13:39:14 --> Database Driver Class Initialized
DEBUG - 2025-07-13 13:39:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 13:39:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 13:39:14 --> Controller Class Initialized
INFO - 2025-07-13 13:39:14 --> Model "User_model" initialized
INFO - 2025-07-13 13:39:14 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-07-13 13:39:14 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/home.php
INFO - 2025-07-13 13:39:14 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-07-13 13:39:14 --> Final output sent to browser
DEBUG - 2025-07-13 13:39:14 --> Total execution time: 0.0790
INFO - 2025-07-13 13:39:25 --> Config Class Initialized
INFO - 2025-07-13 13:39:25 --> Hooks Class Initialized
DEBUG - 2025-07-13 13:39:25 --> UTF-8 Support Enabled
INFO - 2025-07-13 13:39:25 --> Utf8 Class Initialized
INFO - 2025-07-13 13:39:25 --> URI Class Initialized
INFO - 2025-07-13 13:39:25 --> Router Class Initialized
INFO - 2025-07-13 13:39:25 --> Output Class Initialized
INFO - 2025-07-13 13:39:25 --> Security Class Initialized
DEBUG - 2025-07-13 13:39:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 13:39:25 --> Input Class Initialized
INFO - 2025-07-13 13:39:25 --> Language Class Initialized
INFO - 2025-07-13 13:39:25 --> Loader Class Initialized
INFO - 2025-07-13 13:39:25 --> Helper loaded: url_helper
INFO - 2025-07-13 13:39:25 --> Helper loaded: form_helper
INFO - 2025-07-13 13:39:25 --> Database Driver Class Initialized
DEBUG - 2025-07-13 13:39:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 13:39:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 13:39:25 --> Controller Class Initialized
INFO - 2025-07-13 13:39:25 --> Model "User_model" initialized
INFO - 2025-07-13 13:39:25 --> Form Validation Class Initialized
INFO - 2025-07-13 13:39:25 --> Config Class Initialized
INFO - 2025-07-13 13:39:25 --> Hooks Class Initialized
DEBUG - 2025-07-13 13:39:25 --> UTF-8 Support Enabled
INFO - 2025-07-13 13:39:25 --> Utf8 Class Initialized
INFO - 2025-07-13 13:39:25 --> URI Class Initialized
INFO - 2025-07-13 13:39:25 --> Router Class Initialized
INFO - 2025-07-13 13:39:25 --> Output Class Initialized
INFO - 2025-07-13 13:39:25 --> Security Class Initialized
DEBUG - 2025-07-13 13:39:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 13:39:25 --> Input Class Initialized
INFO - 2025-07-13 13:39:25 --> Language Class Initialized
INFO - 2025-07-13 13:39:25 --> Loader Class Initialized
INFO - 2025-07-13 13:39:25 --> Helper loaded: url_helper
INFO - 2025-07-13 13:39:25 --> Helper loaded: form_helper
INFO - 2025-07-13 13:39:25 --> Database Driver Class Initialized
DEBUG - 2025-07-13 13:39:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 13:39:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 13:39:25 --> Controller Class Initialized
INFO - 2025-07-13 13:39:25 --> Model "User_model" initialized
INFO - 2025-07-13 13:39:25 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-07-13 13:39:25 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/home.php
INFO - 2025-07-13 13:39:25 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-07-13 13:39:25 --> Final output sent to browser
DEBUG - 2025-07-13 13:39:25 --> Total execution time: 0.0980
INFO - 2025-07-13 13:39:27 --> Config Class Initialized
INFO - 2025-07-13 13:39:27 --> Hooks Class Initialized
DEBUG - 2025-07-13 13:39:27 --> UTF-8 Support Enabled
INFO - 2025-07-13 13:39:27 --> Utf8 Class Initialized
INFO - 2025-07-13 13:39:27 --> URI Class Initialized
INFO - 2025-07-13 13:39:27 --> Router Class Initialized
INFO - 2025-07-13 13:39:27 --> Output Class Initialized
INFO - 2025-07-13 13:39:27 --> Security Class Initialized
DEBUG - 2025-07-13 13:39:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 13:39:27 --> Input Class Initialized
INFO - 2025-07-13 13:39:27 --> Language Class Initialized
INFO - 2025-07-13 13:39:27 --> Loader Class Initialized
INFO - 2025-07-13 13:39:27 --> Helper loaded: url_helper
INFO - 2025-07-13 13:39:27 --> Helper loaded: form_helper
INFO - 2025-07-13 13:39:27 --> Database Driver Class Initialized
DEBUG - 2025-07-13 13:39:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 13:39:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 13:39:27 --> Controller Class Initialized
INFO - 2025-07-13 13:39:27 --> Model "User_model" initialized
INFO - 2025-07-13 13:39:27 --> Form Validation Class Initialized
INFO - 2025-07-13 13:39:27 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\auth/login.php
INFO - 2025-07-13 13:39:27 --> Final output sent to browser
DEBUG - 2025-07-13 13:39:27 --> Total execution time: 0.0814
INFO - 2025-07-13 13:39:36 --> Config Class Initialized
INFO - 2025-07-13 13:39:36 --> Hooks Class Initialized
DEBUG - 2025-07-13 13:39:36 --> UTF-8 Support Enabled
INFO - 2025-07-13 13:39:36 --> Utf8 Class Initialized
INFO - 2025-07-13 13:39:36 --> URI Class Initialized
INFO - 2025-07-13 13:39:36 --> Router Class Initialized
INFO - 2025-07-13 13:39:36 --> Output Class Initialized
INFO - 2025-07-13 13:39:36 --> Security Class Initialized
DEBUG - 2025-07-13 13:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 13:39:36 --> Input Class Initialized
INFO - 2025-07-13 13:39:36 --> Language Class Initialized
INFO - 2025-07-13 13:39:36 --> Loader Class Initialized
INFO - 2025-07-13 13:39:36 --> Helper loaded: url_helper
INFO - 2025-07-13 13:39:36 --> Helper loaded: form_helper
INFO - 2025-07-13 13:39:36 --> Database Driver Class Initialized
DEBUG - 2025-07-13 13:39:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 13:39:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 13:39:36 --> Controller Class Initialized
INFO - 2025-07-13 13:39:36 --> Model "User_model" initialized
INFO - 2025-07-13 13:39:36 --> Form Validation Class Initialized
INFO - 2025-07-13 13:39:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-07-13 13:39:37 --> Config Class Initialized
INFO - 2025-07-13 13:39:37 --> Hooks Class Initialized
DEBUG - 2025-07-13 13:39:37 --> UTF-8 Support Enabled
INFO - 2025-07-13 13:39:37 --> Utf8 Class Initialized
INFO - 2025-07-13 13:39:37 --> URI Class Initialized
INFO - 2025-07-13 13:39:37 --> Router Class Initialized
INFO - 2025-07-13 13:39:37 --> Output Class Initialized
INFO - 2025-07-13 13:39:37 --> Security Class Initialized
DEBUG - 2025-07-13 13:39:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 13:39:37 --> Input Class Initialized
INFO - 2025-07-13 13:39:37 --> Language Class Initialized
INFO - 2025-07-13 13:39:37 --> Loader Class Initialized
INFO - 2025-07-13 13:39:37 --> Helper loaded: url_helper
INFO - 2025-07-13 13:39:37 --> Helper loaded: form_helper
INFO - 2025-07-13 13:39:37 --> Database Driver Class Initialized
DEBUG - 2025-07-13 13:39:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 13:39:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 13:39:37 --> Controller Class Initialized
INFO - 2025-07-13 13:39:37 --> Model "User_model" initialized
INFO - 2025-07-13 13:39:37 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-07-13 13:39:37 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/home.php
INFO - 2025-07-13 13:39:37 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-07-13 13:39:37 --> Final output sent to browser
DEBUG - 2025-07-13 13:39:37 --> Total execution time: 0.0897
INFO - 2025-07-13 13:39:39 --> Config Class Initialized
INFO - 2025-07-13 13:39:39 --> Hooks Class Initialized
DEBUG - 2025-07-13 13:39:39 --> UTF-8 Support Enabled
INFO - 2025-07-13 13:39:39 --> Utf8 Class Initialized
INFO - 2025-07-13 13:39:39 --> URI Class Initialized
INFO - 2025-07-13 13:39:39 --> Router Class Initialized
INFO - 2025-07-13 13:39:39 --> Output Class Initialized
INFO - 2025-07-13 13:39:39 --> Security Class Initialized
DEBUG - 2025-07-13 13:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 13:39:39 --> Input Class Initialized
INFO - 2025-07-13 13:39:39 --> Language Class Initialized
INFO - 2025-07-13 13:39:39 --> Loader Class Initialized
INFO - 2025-07-13 13:39:39 --> Helper loaded: url_helper
INFO - 2025-07-13 13:39:39 --> Helper loaded: form_helper
INFO - 2025-07-13 13:39:39 --> Database Driver Class Initialized
DEBUG - 2025-07-13 13:39:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 13:39:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 13:39:39 --> Controller Class Initialized
INFO - 2025-07-13 13:39:39 --> Model "User_model" initialized
INFO - 2025-07-13 13:39:39 --> Model "Progress_model" initialized
INFO - 2025-07-13 13:39:39 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-13 13:39:39 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-13 13:39:39 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/dashboard.php
INFO - 2025-07-13 13:39:39 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-13 13:39:39 --> Final output sent to browser
DEBUG - 2025-07-13 13:39:39 --> Total execution time: 0.1089
INFO - 2025-07-13 13:40:30 --> Config Class Initialized
INFO - 2025-07-13 13:40:30 --> Hooks Class Initialized
DEBUG - 2025-07-13 13:40:30 --> UTF-8 Support Enabled
INFO - 2025-07-13 13:40:30 --> Utf8 Class Initialized
INFO - 2025-07-13 13:40:30 --> URI Class Initialized
INFO - 2025-07-13 13:40:30 --> Router Class Initialized
INFO - 2025-07-13 13:40:30 --> Output Class Initialized
INFO - 2025-07-13 13:40:30 --> Security Class Initialized
DEBUG - 2025-07-13 13:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 13:40:30 --> Input Class Initialized
INFO - 2025-07-13 13:40:30 --> Language Class Initialized
INFO - 2025-07-13 13:40:30 --> Loader Class Initialized
INFO - 2025-07-13 13:40:30 --> Helper loaded: url_helper
INFO - 2025-07-13 13:40:30 --> Helper loaded: form_helper
INFO - 2025-07-13 13:40:30 --> Database Driver Class Initialized
DEBUG - 2025-07-13 13:40:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 13:40:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 13:40:30 --> Controller Class Initialized
INFO - 2025-07-13 13:40:30 --> Model "User_model" initialized
INFO - 2025-07-13 13:40:30 --> Form Validation Class Initialized
INFO - 2025-07-13 13:40:30 --> Config Class Initialized
INFO - 2025-07-13 13:40:30 --> Hooks Class Initialized
DEBUG - 2025-07-13 13:40:30 --> UTF-8 Support Enabled
INFO - 2025-07-13 13:40:30 --> Utf8 Class Initialized
INFO - 2025-07-13 13:40:30 --> URI Class Initialized
INFO - 2025-07-13 13:40:30 --> Router Class Initialized
INFO - 2025-07-13 13:40:30 --> Output Class Initialized
INFO - 2025-07-13 13:40:30 --> Security Class Initialized
DEBUG - 2025-07-13 13:40:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 13:40:30 --> Input Class Initialized
INFO - 2025-07-13 13:40:30 --> Language Class Initialized
INFO - 2025-07-13 13:40:30 --> Loader Class Initialized
INFO - 2025-07-13 13:40:30 --> Helper loaded: url_helper
INFO - 2025-07-13 13:40:30 --> Helper loaded: form_helper
INFO - 2025-07-13 13:40:30 --> Database Driver Class Initialized
DEBUG - 2025-07-13 13:40:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 13:40:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 13:40:30 --> Controller Class Initialized
INFO - 2025-07-13 13:40:30 --> Model "User_model" initialized
INFO - 2025-07-13 13:40:30 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-07-13 13:40:30 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/home.php
INFO - 2025-07-13 13:40:30 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-07-13 13:40:30 --> Final output sent to browser
DEBUG - 2025-07-13 13:40:30 --> Total execution time: 0.1031
INFO - 2025-07-13 13:41:01 --> Config Class Initialized
INFO - 2025-07-13 13:41:01 --> Hooks Class Initialized
DEBUG - 2025-07-13 13:41:01 --> UTF-8 Support Enabled
INFO - 2025-07-13 13:41:01 --> Utf8 Class Initialized
INFO - 2025-07-13 13:41:01 --> URI Class Initialized
INFO - 2025-07-13 13:41:01 --> Router Class Initialized
INFO - 2025-07-13 13:41:01 --> Output Class Initialized
INFO - 2025-07-13 13:41:01 --> Security Class Initialized
DEBUG - 2025-07-13 13:41:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 13:41:01 --> Input Class Initialized
INFO - 2025-07-13 13:41:01 --> Language Class Initialized
INFO - 2025-07-13 13:41:01 --> Loader Class Initialized
INFO - 2025-07-13 13:41:01 --> Helper loaded: url_helper
INFO - 2025-07-13 13:41:01 --> Helper loaded: form_helper
INFO - 2025-07-13 13:41:01 --> Database Driver Class Initialized
DEBUG - 2025-07-13 13:41:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 13:41:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 13:41:01 --> Controller Class Initialized
INFO - 2025-07-13 13:41:01 --> Model "User_model" initialized
INFO - 2025-07-13 13:41:01 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-07-13 13:41:01 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/artikel.php
INFO - 2025-07-13 13:41:01 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-07-13 13:41:01 --> Final output sent to browser
DEBUG - 2025-07-13 13:41:01 --> Total execution time: 0.1331
INFO - 2025-07-13 13:41:09 --> Config Class Initialized
INFO - 2025-07-13 13:41:09 --> Hooks Class Initialized
DEBUG - 2025-07-13 13:41:09 --> UTF-8 Support Enabled
INFO - 2025-07-13 13:41:09 --> Utf8 Class Initialized
INFO - 2025-07-13 13:41:09 --> URI Class Initialized
INFO - 2025-07-13 13:41:09 --> Router Class Initialized
INFO - 2025-07-13 13:41:09 --> Output Class Initialized
INFO - 2025-07-13 13:41:09 --> Security Class Initialized
DEBUG - 2025-07-13 13:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 13:41:09 --> Input Class Initialized
INFO - 2025-07-13 13:41:09 --> Language Class Initialized
INFO - 2025-07-13 13:41:09 --> Loader Class Initialized
INFO - 2025-07-13 13:41:09 --> Helper loaded: url_helper
INFO - 2025-07-13 13:41:09 --> Helper loaded: form_helper
INFO - 2025-07-13 13:41:09 --> Database Driver Class Initialized
DEBUG - 2025-07-13 13:41:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 13:41:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 13:41:09 --> Controller Class Initialized
INFO - 2025-07-13 13:41:09 --> Model "User_model" initialized
INFO - 2025-07-13 13:41:09 --> Form Validation Class Initialized
INFO - 2025-07-13 13:41:09 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\auth/login.php
INFO - 2025-07-13 13:41:09 --> Final output sent to browser
DEBUG - 2025-07-13 13:41:09 --> Total execution time: 0.0834
INFO - 2025-07-13 13:41:48 --> Config Class Initialized
INFO - 2025-07-13 13:41:48 --> Hooks Class Initialized
DEBUG - 2025-07-13 13:41:48 --> UTF-8 Support Enabled
INFO - 2025-07-13 13:41:48 --> Utf8 Class Initialized
INFO - 2025-07-13 13:41:48 --> URI Class Initialized
INFO - 2025-07-13 13:41:48 --> Router Class Initialized
INFO - 2025-07-13 13:41:48 --> Output Class Initialized
INFO - 2025-07-13 13:41:48 --> Security Class Initialized
DEBUG - 2025-07-13 13:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-13 13:41:48 --> Input Class Initialized
INFO - 2025-07-13 13:41:48 --> Language Class Initialized
INFO - 2025-07-13 13:41:48 --> Loader Class Initialized
INFO - 2025-07-13 13:41:48 --> Helper loaded: url_helper
INFO - 2025-07-13 13:41:48 --> Helper loaded: form_helper
INFO - 2025-07-13 13:41:48 --> Database Driver Class Initialized
DEBUG - 2025-07-13 13:41:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-13 13:41:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-13 13:41:48 --> Controller Class Initialized
INFO - 2025-07-13 13:41:48 --> Model "User_model" initialized
INFO - 2025-07-13 13:41:48 --> Form Validation Class Initialized
INFO - 2025-07-13 13:41:48 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\auth/login.php
INFO - 2025-07-13 13:41:48 --> Final output sent to browser
DEBUG - 2025-07-13 13:41:48 --> Total execution time: 0.0798
