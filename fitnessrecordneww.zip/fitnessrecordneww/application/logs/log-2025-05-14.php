<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-05-14 04:09:03 --> Config Class Initialized
INFO - 2025-05-14 04:09:03 --> Hooks Class Initialized
DEBUG - 2025-05-14 04:09:03 --> UTF-8 Support Enabled
INFO - 2025-05-14 04:09:03 --> Utf8 Class Initialized
INFO - 2025-05-14 04:09:03 --> URI Class Initialized
DEBUG - 2025-05-14 04:09:03 --> No URI present. Default controller set.
INFO - 2025-05-14 04:09:03 --> Router Class Initialized
INFO - 2025-05-14 04:09:03 --> Output Class Initialized
INFO - 2025-05-14 04:09:03 --> Security Class Initialized
DEBUG - 2025-05-14 04:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 04:09:04 --> Input Class Initialized
INFO - 2025-05-14 04:09:04 --> Language Class Initialized
INFO - 2025-05-14 04:09:04 --> Loader Class Initialized
INFO - 2025-05-14 04:09:04 --> Helper loaded: url_helper
INFO - 2025-05-14 04:09:04 --> Helper loaded: form_helper
INFO - 2025-05-14 04:09:04 --> Database Driver Class Initialized
DEBUG - 2025-05-14 04:09:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 04:09:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 04:09:04 --> Controller Class Initialized
INFO - 2025-05-14 04:09:04 --> Model "User_model" initialized
INFO - 2025-05-14 04:09:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-14 04:09:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-14 04:09:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-14 04:09:05 --> Final output sent to browser
DEBUG - 2025-05-14 04:09:05 --> Total execution time: 1.8799
INFO - 2025-05-14 04:12:00 --> Config Class Initialized
INFO - 2025-05-14 04:12:00 --> Hooks Class Initialized
DEBUG - 2025-05-14 04:12:00 --> UTF-8 Support Enabled
INFO - 2025-05-14 04:12:00 --> Utf8 Class Initialized
INFO - 2025-05-14 04:12:00 --> URI Class Initialized
DEBUG - 2025-05-14 04:12:00 --> No URI present. Default controller set.
INFO - 2025-05-14 04:12:00 --> Router Class Initialized
INFO - 2025-05-14 04:12:00 --> Output Class Initialized
INFO - 2025-05-14 04:12:00 --> Security Class Initialized
DEBUG - 2025-05-14 04:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 04:12:00 --> Input Class Initialized
INFO - 2025-05-14 04:12:00 --> Language Class Initialized
INFO - 2025-05-14 04:12:00 --> Loader Class Initialized
INFO - 2025-05-14 04:12:00 --> Helper loaded: url_helper
INFO - 2025-05-14 04:12:00 --> Helper loaded: form_helper
INFO - 2025-05-14 04:12:00 --> Database Driver Class Initialized
DEBUG - 2025-05-14 04:12:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 04:12:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 04:12:00 --> Controller Class Initialized
INFO - 2025-05-14 04:12:00 --> Model "User_model" initialized
INFO - 2025-05-14 04:12:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-14 04:12:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-14 04:12:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-14 04:12:00 --> Final output sent to browser
DEBUG - 2025-05-14 04:12:00 --> Total execution time: 0.0899
INFO - 2025-05-14 04:12:08 --> Config Class Initialized
INFO - 2025-05-14 04:12:08 --> Hooks Class Initialized
DEBUG - 2025-05-14 04:12:08 --> UTF-8 Support Enabled
INFO - 2025-05-14 04:12:08 --> Utf8 Class Initialized
INFO - 2025-05-14 04:12:08 --> URI Class Initialized
INFO - 2025-05-14 04:12:08 --> Router Class Initialized
INFO - 2025-05-14 04:12:08 --> Output Class Initialized
INFO - 2025-05-14 04:12:08 --> Security Class Initialized
DEBUG - 2025-05-14 04:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 04:12:08 --> Input Class Initialized
INFO - 2025-05-14 04:12:08 --> Language Class Initialized
INFO - 2025-05-14 04:12:08 --> Loader Class Initialized
INFO - 2025-05-14 04:12:08 --> Helper loaded: url_helper
INFO - 2025-05-14 04:12:08 --> Helper loaded: form_helper
INFO - 2025-05-14 04:12:08 --> Database Driver Class Initialized
DEBUG - 2025-05-14 04:12:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 04:12:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 04:12:08 --> Controller Class Initialized
INFO - 2025-05-14 04:12:08 --> Model "User_model" initialized
INFO - 2025-05-14 04:12:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-14 04:12:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/artikel.php
INFO - 2025-05-14 04:12:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-14 04:12:08 --> Final output sent to browser
DEBUG - 2025-05-14 04:12:08 --> Total execution time: 0.1106
INFO - 2025-05-14 04:12:19 --> Config Class Initialized
INFO - 2025-05-14 04:12:19 --> Hooks Class Initialized
DEBUG - 2025-05-14 04:12:19 --> UTF-8 Support Enabled
INFO - 2025-05-14 04:12:19 --> Utf8 Class Initialized
INFO - 2025-05-14 04:12:19 --> URI Class Initialized
INFO - 2025-05-14 04:12:19 --> Router Class Initialized
INFO - 2025-05-14 04:12:19 --> Output Class Initialized
INFO - 2025-05-14 04:12:19 --> Security Class Initialized
DEBUG - 2025-05-14 04:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 04:12:19 --> Input Class Initialized
INFO - 2025-05-14 04:12:19 --> Language Class Initialized
INFO - 2025-05-14 04:12:19 --> Loader Class Initialized
INFO - 2025-05-14 04:12:19 --> Helper loaded: url_helper
INFO - 2025-05-14 04:12:19 --> Helper loaded: form_helper
INFO - 2025-05-14 04:12:19 --> Database Driver Class Initialized
DEBUG - 2025-05-14 04:12:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 04:12:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 04:12:19 --> Controller Class Initialized
INFO - 2025-05-14 04:12:19 --> Model "User_model" initialized
INFO - 2025-05-14 04:12:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-14 04:12:19 --> Final output sent to browser
DEBUG - 2025-05-14 04:12:19 --> Total execution time: 0.1973
INFO - 2025-05-14 04:12:30 --> Config Class Initialized
INFO - 2025-05-14 04:12:30 --> Hooks Class Initialized
DEBUG - 2025-05-14 04:12:30 --> UTF-8 Support Enabled
INFO - 2025-05-14 04:12:30 --> Utf8 Class Initialized
INFO - 2025-05-14 04:12:30 --> URI Class Initialized
INFO - 2025-05-14 04:12:30 --> Router Class Initialized
INFO - 2025-05-14 04:12:30 --> Output Class Initialized
INFO - 2025-05-14 04:12:30 --> Security Class Initialized
DEBUG - 2025-05-14 04:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 04:12:30 --> Input Class Initialized
INFO - 2025-05-14 04:12:30 --> Language Class Initialized
INFO - 2025-05-14 04:12:30 --> Loader Class Initialized
INFO - 2025-05-14 04:12:30 --> Helper loaded: url_helper
INFO - 2025-05-14 04:12:30 --> Helper loaded: form_helper
INFO - 2025-05-14 04:12:30 --> Database Driver Class Initialized
DEBUG - 2025-05-14 04:12:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 04:12:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 04:12:30 --> Controller Class Initialized
INFO - 2025-05-14 04:12:30 --> Model "User_model" initialized
INFO - 2025-05-14 04:12:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/register.php
INFO - 2025-05-14 04:12:30 --> Final output sent to browser
DEBUG - 2025-05-14 04:12:30 --> Total execution time: 0.1158
INFO - 2025-05-14 04:12:33 --> Config Class Initialized
INFO - 2025-05-14 04:12:33 --> Hooks Class Initialized
DEBUG - 2025-05-14 04:12:33 --> UTF-8 Support Enabled
INFO - 2025-05-14 04:12:33 --> Utf8 Class Initialized
INFO - 2025-05-14 04:12:33 --> URI Class Initialized
INFO - 2025-05-14 04:12:33 --> Router Class Initialized
INFO - 2025-05-14 04:12:33 --> Output Class Initialized
INFO - 2025-05-14 04:12:33 --> Security Class Initialized
DEBUG - 2025-05-14 04:12:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 04:12:33 --> Input Class Initialized
INFO - 2025-05-14 04:12:33 --> Language Class Initialized
INFO - 2025-05-14 04:12:33 --> Loader Class Initialized
INFO - 2025-05-14 04:12:33 --> Helper loaded: url_helper
INFO - 2025-05-14 04:12:33 --> Helper loaded: form_helper
INFO - 2025-05-14 04:12:33 --> Database Driver Class Initialized
DEBUG - 2025-05-14 04:12:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 04:12:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 04:12:33 --> Controller Class Initialized
INFO - 2025-05-14 04:12:33 --> Model "User_model" initialized
INFO - 2025-05-14 04:12:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-14 04:12:33 --> Final output sent to browser
DEBUG - 2025-05-14 04:12:33 --> Total execution time: 0.0862
INFO - 2025-05-14 04:12:37 --> Config Class Initialized
INFO - 2025-05-14 04:12:37 --> Hooks Class Initialized
DEBUG - 2025-05-14 04:12:37 --> UTF-8 Support Enabled
INFO - 2025-05-14 04:12:37 --> Utf8 Class Initialized
INFO - 2025-05-14 04:12:37 --> URI Class Initialized
INFO - 2025-05-14 04:12:37 --> Router Class Initialized
INFO - 2025-05-14 04:12:37 --> Output Class Initialized
INFO - 2025-05-14 04:12:37 --> Security Class Initialized
DEBUG - 2025-05-14 04:12:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 04:12:37 --> Input Class Initialized
INFO - 2025-05-14 04:12:37 --> Language Class Initialized
INFO - 2025-05-14 04:12:37 --> Loader Class Initialized
INFO - 2025-05-14 04:12:37 --> Helper loaded: url_helper
INFO - 2025-05-14 04:12:37 --> Helper loaded: form_helper
INFO - 2025-05-14 04:12:37 --> Database Driver Class Initialized
DEBUG - 2025-05-14 04:12:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 04:12:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 04:12:37 --> Controller Class Initialized
INFO - 2025-05-14 04:12:37 --> Model "User_model" initialized
INFO - 2025-05-14 04:12:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/register.php
INFO - 2025-05-14 04:12:37 --> Final output sent to browser
DEBUG - 2025-05-14 04:12:37 --> Total execution time: 0.0679
INFO - 2025-05-14 04:13:06 --> Config Class Initialized
INFO - 2025-05-14 04:13:06 --> Hooks Class Initialized
DEBUG - 2025-05-14 04:13:06 --> UTF-8 Support Enabled
INFO - 2025-05-14 04:13:06 --> Utf8 Class Initialized
INFO - 2025-05-14 04:13:06 --> URI Class Initialized
INFO - 2025-05-14 04:13:06 --> Router Class Initialized
INFO - 2025-05-14 04:13:06 --> Output Class Initialized
INFO - 2025-05-14 04:13:06 --> Security Class Initialized
DEBUG - 2025-05-14 04:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 04:13:06 --> Input Class Initialized
INFO - 2025-05-14 04:13:06 --> Language Class Initialized
INFO - 2025-05-14 04:13:06 --> Loader Class Initialized
INFO - 2025-05-14 04:13:06 --> Helper loaded: url_helper
INFO - 2025-05-14 04:13:06 --> Helper loaded: form_helper
INFO - 2025-05-14 04:13:06 --> Database Driver Class Initialized
DEBUG - 2025-05-14 04:13:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 04:13:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 04:13:06 --> Controller Class Initialized
INFO - 2025-05-14 04:13:06 --> Model "User_model" initialized
INFO - 2025-05-14 04:13:06 --> Config Class Initialized
INFO - 2025-05-14 04:13:06 --> Hooks Class Initialized
DEBUG - 2025-05-14 04:13:06 --> UTF-8 Support Enabled
INFO - 2025-05-14 04:13:06 --> Utf8 Class Initialized
INFO - 2025-05-14 04:13:06 --> URI Class Initialized
INFO - 2025-05-14 04:13:06 --> Router Class Initialized
INFO - 2025-05-14 04:13:06 --> Output Class Initialized
INFO - 2025-05-14 04:13:06 --> Security Class Initialized
DEBUG - 2025-05-14 04:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 04:13:06 --> Input Class Initialized
INFO - 2025-05-14 04:13:06 --> Language Class Initialized
INFO - 2025-05-14 04:13:06 --> Loader Class Initialized
INFO - 2025-05-14 04:13:06 --> Helper loaded: url_helper
INFO - 2025-05-14 04:13:06 --> Helper loaded: form_helper
INFO - 2025-05-14 04:13:06 --> Database Driver Class Initialized
DEBUG - 2025-05-14 04:13:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 04:13:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 04:13:06 --> Controller Class Initialized
INFO - 2025-05-14 04:13:06 --> Model "User_model" initialized
INFO - 2025-05-14 04:13:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-14 04:13:06 --> Final output sent to browser
DEBUG - 2025-05-14 04:13:06 --> Total execution time: 0.0840
INFO - 2025-05-14 04:13:17 --> Config Class Initialized
INFO - 2025-05-14 04:13:17 --> Hooks Class Initialized
DEBUG - 2025-05-14 04:13:17 --> UTF-8 Support Enabled
INFO - 2025-05-14 04:13:17 --> Utf8 Class Initialized
INFO - 2025-05-14 04:13:17 --> URI Class Initialized
INFO - 2025-05-14 04:13:17 --> Router Class Initialized
INFO - 2025-05-14 04:13:17 --> Output Class Initialized
INFO - 2025-05-14 04:13:17 --> Security Class Initialized
DEBUG - 2025-05-14 04:13:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 04:13:17 --> Input Class Initialized
INFO - 2025-05-14 04:13:17 --> Language Class Initialized
INFO - 2025-05-14 04:13:17 --> Loader Class Initialized
INFO - 2025-05-14 04:13:17 --> Helper loaded: url_helper
INFO - 2025-05-14 04:13:17 --> Helper loaded: form_helper
INFO - 2025-05-14 04:13:17 --> Database Driver Class Initialized
DEBUG - 2025-05-14 04:13:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 04:13:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 04:13:17 --> Controller Class Initialized
INFO - 2025-05-14 04:13:17 --> Model "User_model" initialized
INFO - 2025-05-14 04:13:17 --> Config Class Initialized
INFO - 2025-05-14 04:13:17 --> Hooks Class Initialized
DEBUG - 2025-05-14 04:13:17 --> UTF-8 Support Enabled
INFO - 2025-05-14 04:13:17 --> Utf8 Class Initialized
INFO - 2025-05-14 04:13:17 --> URI Class Initialized
INFO - 2025-05-14 04:13:17 --> Router Class Initialized
INFO - 2025-05-14 04:13:17 --> Output Class Initialized
INFO - 2025-05-14 04:13:17 --> Security Class Initialized
DEBUG - 2025-05-14 04:13:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 04:13:17 --> Input Class Initialized
INFO - 2025-05-14 04:13:17 --> Language Class Initialized
INFO - 2025-05-14 04:13:17 --> Loader Class Initialized
INFO - 2025-05-14 04:13:17 --> Helper loaded: url_helper
INFO - 2025-05-14 04:13:17 --> Helper loaded: form_helper
INFO - 2025-05-14 04:13:17 --> Database Driver Class Initialized
DEBUG - 2025-05-14 04:13:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 04:13:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 04:13:17 --> Controller Class Initialized
INFO - 2025-05-14 04:13:17 --> Model "User_model" initialized
INFO - 2025-05-14 04:13:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-14 04:13:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-14 04:13:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-14 04:13:17 --> Final output sent to browser
DEBUG - 2025-05-14 04:13:17 --> Total execution time: 0.0763
INFO - 2025-05-14 04:13:22 --> Config Class Initialized
INFO - 2025-05-14 04:13:22 --> Hooks Class Initialized
DEBUG - 2025-05-14 04:13:22 --> UTF-8 Support Enabled
INFO - 2025-05-14 04:13:22 --> Utf8 Class Initialized
INFO - 2025-05-14 04:13:22 --> URI Class Initialized
INFO - 2025-05-14 04:13:22 --> Router Class Initialized
INFO - 2025-05-14 04:13:22 --> Output Class Initialized
INFO - 2025-05-14 04:13:22 --> Security Class Initialized
DEBUG - 2025-05-14 04:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 04:13:22 --> Input Class Initialized
INFO - 2025-05-14 04:13:22 --> Language Class Initialized
INFO - 2025-05-14 04:13:22 --> Loader Class Initialized
INFO - 2025-05-14 04:13:22 --> Helper loaded: url_helper
INFO - 2025-05-14 04:13:22 --> Helper loaded: form_helper
INFO - 2025-05-14 04:13:22 --> Database Driver Class Initialized
DEBUG - 2025-05-14 04:13:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 04:13:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 04:13:22 --> Controller Class Initialized
INFO - 2025-05-14 04:13:22 --> Model "User_model" initialized
INFO - 2025-05-14 04:13:22 --> Model "Workout_model" initialized
INFO - 2025-05-14 04:13:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-14 04:13:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-14 04:13:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-14 04:13:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-14 04:13:22 --> Final output sent to browser
DEBUG - 2025-05-14 04:13:22 --> Total execution time: 0.3150
INFO - 2025-05-14 04:13:26 --> Config Class Initialized
INFO - 2025-05-14 04:13:26 --> Hooks Class Initialized
DEBUG - 2025-05-14 04:13:26 --> UTF-8 Support Enabled
INFO - 2025-05-14 04:13:26 --> Utf8 Class Initialized
INFO - 2025-05-14 04:13:26 --> URI Class Initialized
INFO - 2025-05-14 04:13:26 --> Router Class Initialized
INFO - 2025-05-14 04:13:26 --> Output Class Initialized
INFO - 2025-05-14 04:13:26 --> Security Class Initialized
DEBUG - 2025-05-14 04:13:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 04:13:26 --> Input Class Initialized
INFO - 2025-05-14 04:13:26 --> Language Class Initialized
INFO - 2025-05-14 04:13:26 --> Loader Class Initialized
INFO - 2025-05-14 04:13:26 --> Helper loaded: url_helper
INFO - 2025-05-14 04:13:26 --> Helper loaded: form_helper
INFO - 2025-05-14 04:13:26 --> Database Driver Class Initialized
DEBUG - 2025-05-14 04:13:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 04:13:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 04:13:26 --> Controller Class Initialized
INFO - 2025-05-14 04:13:26 --> Model "User_model" initialized
INFO - 2025-05-14 04:13:26 --> Model "Workout_model" initialized
INFO - 2025-05-14 04:13:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-14 04:13:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-14 04:13:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-14 04:13:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-14 04:13:26 --> Final output sent to browser
DEBUG - 2025-05-14 04:13:26 --> Total execution time: 0.0850
INFO - 2025-05-14 04:13:27 --> Config Class Initialized
INFO - 2025-05-14 04:13:27 --> Hooks Class Initialized
DEBUG - 2025-05-14 04:13:27 --> UTF-8 Support Enabled
INFO - 2025-05-14 04:13:27 --> Utf8 Class Initialized
INFO - 2025-05-14 04:13:27 --> URI Class Initialized
INFO - 2025-05-14 04:13:27 --> Router Class Initialized
INFO - 2025-05-14 04:13:27 --> Output Class Initialized
INFO - 2025-05-14 04:13:27 --> Security Class Initialized
DEBUG - 2025-05-14 04:13:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 04:13:27 --> Input Class Initialized
INFO - 2025-05-14 04:13:27 --> Language Class Initialized
INFO - 2025-05-14 04:13:27 --> Loader Class Initialized
INFO - 2025-05-14 04:13:27 --> Helper loaded: url_helper
INFO - 2025-05-14 04:13:27 --> Helper loaded: form_helper
INFO - 2025-05-14 04:13:28 --> Database Driver Class Initialized
DEBUG - 2025-05-14 04:13:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 04:13:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 04:13:28 --> Controller Class Initialized
INFO - 2025-05-14 04:13:28 --> Model "User_model" initialized
INFO - 2025-05-14 04:13:28 --> Model "Workout_model" initialized
INFO - 2025-05-14 04:13:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-14 04:13:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-14 04:13:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-14 04:13:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-14 04:13:28 --> Final output sent to browser
DEBUG - 2025-05-14 04:13:28 --> Total execution time: 0.1104
INFO - 2025-05-14 04:13:36 --> Config Class Initialized
INFO - 2025-05-14 04:13:36 --> Hooks Class Initialized
DEBUG - 2025-05-14 04:13:36 --> UTF-8 Support Enabled
INFO - 2025-05-14 04:13:36 --> Utf8 Class Initialized
INFO - 2025-05-14 04:13:36 --> URI Class Initialized
INFO - 2025-05-14 04:13:36 --> Router Class Initialized
INFO - 2025-05-14 04:13:36 --> Output Class Initialized
INFO - 2025-05-14 04:13:36 --> Security Class Initialized
DEBUG - 2025-05-14 04:13:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 04:13:36 --> Input Class Initialized
INFO - 2025-05-14 04:13:36 --> Language Class Initialized
INFO - 2025-05-14 04:13:36 --> Loader Class Initialized
INFO - 2025-05-14 04:13:36 --> Helper loaded: url_helper
INFO - 2025-05-14 04:13:36 --> Helper loaded: form_helper
INFO - 2025-05-14 04:13:36 --> Database Driver Class Initialized
DEBUG - 2025-05-14 04:13:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 04:13:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 04:13:36 --> Controller Class Initialized
INFO - 2025-05-14 04:13:36 --> Model "Workout_model" initialized
INFO - 2025-05-14 04:13:36 --> Model "User_model" initialized
INFO - 2025-05-14 04:13:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-14 04:13:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-14 04:13:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-14 04:13:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-14 04:13:36 --> Final output sent to browser
DEBUG - 2025-05-14 04:13:36 --> Total execution time: 0.1788
INFO - 2025-05-14 04:13:39 --> Config Class Initialized
INFO - 2025-05-14 04:13:39 --> Hooks Class Initialized
DEBUG - 2025-05-14 04:13:39 --> UTF-8 Support Enabled
INFO - 2025-05-14 04:13:39 --> Utf8 Class Initialized
INFO - 2025-05-14 04:13:39 --> URI Class Initialized
INFO - 2025-05-14 04:13:39 --> Router Class Initialized
INFO - 2025-05-14 04:13:39 --> Output Class Initialized
INFO - 2025-05-14 04:13:39 --> Security Class Initialized
DEBUG - 2025-05-14 04:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 04:13:39 --> Input Class Initialized
INFO - 2025-05-14 04:13:39 --> Language Class Initialized
INFO - 2025-05-14 04:13:39 --> Loader Class Initialized
INFO - 2025-05-14 04:13:39 --> Helper loaded: url_helper
INFO - 2025-05-14 04:13:39 --> Helper loaded: form_helper
INFO - 2025-05-14 04:13:39 --> Database Driver Class Initialized
DEBUG - 2025-05-14 04:13:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 04:13:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 04:13:39 --> Controller Class Initialized
INFO - 2025-05-14 04:13:39 --> Model "User_model" initialized
INFO - 2025-05-14 04:13:39 --> Model "Community_model" initialized
INFO - 2025-05-14 04:13:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-14 04:13:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-14 04:13:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/community.php
INFO - 2025-05-14 04:13:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-14 04:13:39 --> Final output sent to browser
DEBUG - 2025-05-14 04:13:39 --> Total execution time: 0.2136
INFO - 2025-05-14 04:13:43 --> Config Class Initialized
INFO - 2025-05-14 04:13:43 --> Hooks Class Initialized
DEBUG - 2025-05-14 04:13:43 --> UTF-8 Support Enabled
INFO - 2025-05-14 04:13:43 --> Utf8 Class Initialized
INFO - 2025-05-14 04:13:43 --> URI Class Initialized
INFO - 2025-05-14 04:13:43 --> Router Class Initialized
INFO - 2025-05-14 04:13:43 --> Output Class Initialized
INFO - 2025-05-14 04:13:43 --> Security Class Initialized
DEBUG - 2025-05-14 04:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 04:13:43 --> Input Class Initialized
INFO - 2025-05-14 04:13:43 --> Language Class Initialized
INFO - 2025-05-14 04:13:43 --> Loader Class Initialized
INFO - 2025-05-14 04:13:43 --> Helper loaded: url_helper
INFO - 2025-05-14 04:13:43 --> Helper loaded: form_helper
INFO - 2025-05-14 04:13:43 --> Database Driver Class Initialized
DEBUG - 2025-05-14 04:13:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 04:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 04:13:43 --> Controller Class Initialized
INFO - 2025-05-14 04:13:43 --> Model "Workout_model" initialized
INFO - 2025-05-14 04:13:43 --> Model "User_model" initialized
INFO - 2025-05-14 04:13:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-14 04:13:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-14 04:13:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-14 04:13:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-14 04:13:43 --> Final output sent to browser
DEBUG - 2025-05-14 04:13:43 --> Total execution time: 0.0769
INFO - 2025-05-14 04:13:44 --> Config Class Initialized
INFO - 2025-05-14 04:13:44 --> Hooks Class Initialized
DEBUG - 2025-05-14 04:13:44 --> UTF-8 Support Enabled
INFO - 2025-05-14 04:13:44 --> Utf8 Class Initialized
INFO - 2025-05-14 04:13:44 --> URI Class Initialized
INFO - 2025-05-14 04:13:44 --> Router Class Initialized
INFO - 2025-05-14 04:13:44 --> Output Class Initialized
INFO - 2025-05-14 04:13:44 --> Security Class Initialized
DEBUG - 2025-05-14 04:13:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 04:13:44 --> Input Class Initialized
INFO - 2025-05-14 04:13:44 --> Language Class Initialized
INFO - 2025-05-14 04:13:44 --> Loader Class Initialized
INFO - 2025-05-14 04:13:44 --> Helper loaded: url_helper
INFO - 2025-05-14 04:13:44 --> Helper loaded: form_helper
INFO - 2025-05-14 04:13:44 --> Database Driver Class Initialized
DEBUG - 2025-05-14 04:13:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 04:13:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 04:13:44 --> Controller Class Initialized
INFO - 2025-05-14 04:13:44 --> Model "Workout_model" initialized
INFO - 2025-05-14 04:13:44 --> Model "User_model" initialized
INFO - 2025-05-14 04:13:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-14 04:13:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-14 04:13:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/add_jadwal.php
INFO - 2025-05-14 04:13:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-14 04:13:45 --> Final output sent to browser
DEBUG - 2025-05-14 04:13:45 --> Total execution time: 0.1130
INFO - 2025-05-14 04:13:55 --> Config Class Initialized
INFO - 2025-05-14 04:13:55 --> Hooks Class Initialized
DEBUG - 2025-05-14 04:13:55 --> UTF-8 Support Enabled
INFO - 2025-05-14 04:13:55 --> Utf8 Class Initialized
INFO - 2025-05-14 04:13:55 --> URI Class Initialized
INFO - 2025-05-14 04:13:55 --> Router Class Initialized
INFO - 2025-05-14 04:13:55 --> Output Class Initialized
INFO - 2025-05-14 04:13:55 --> Security Class Initialized
DEBUG - 2025-05-14 04:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 04:13:55 --> Input Class Initialized
INFO - 2025-05-14 04:13:55 --> Language Class Initialized
INFO - 2025-05-14 04:13:55 --> Loader Class Initialized
INFO - 2025-05-14 04:13:55 --> Helper loaded: url_helper
INFO - 2025-05-14 04:13:55 --> Helper loaded: form_helper
INFO - 2025-05-14 04:13:55 --> Database Driver Class Initialized
DEBUG - 2025-05-14 04:13:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 04:13:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 04:13:55 --> Controller Class Initialized
INFO - 2025-05-14 04:13:55 --> Model "Workout_model" initialized
INFO - 2025-05-14 04:13:55 --> Model "User_model" initialized
INFO - 2025-05-14 04:13:55 --> Config Class Initialized
INFO - 2025-05-14 04:13:55 --> Hooks Class Initialized
DEBUG - 2025-05-14 04:13:55 --> UTF-8 Support Enabled
INFO - 2025-05-14 04:13:55 --> Utf8 Class Initialized
INFO - 2025-05-14 04:13:55 --> URI Class Initialized
INFO - 2025-05-14 04:13:55 --> Router Class Initialized
INFO - 2025-05-14 04:13:55 --> Output Class Initialized
INFO - 2025-05-14 04:13:55 --> Security Class Initialized
DEBUG - 2025-05-14 04:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 04:13:55 --> Input Class Initialized
INFO - 2025-05-14 04:13:55 --> Language Class Initialized
INFO - 2025-05-14 04:13:55 --> Loader Class Initialized
INFO - 2025-05-14 04:13:55 --> Helper loaded: url_helper
INFO - 2025-05-14 04:13:55 --> Helper loaded: form_helper
INFO - 2025-05-14 04:13:55 --> Database Driver Class Initialized
DEBUG - 2025-05-14 04:13:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 04:13:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 04:13:55 --> Controller Class Initialized
INFO - 2025-05-14 04:13:55 --> Model "Workout_model" initialized
INFO - 2025-05-14 04:13:55 --> Model "User_model" initialized
INFO - 2025-05-14 04:13:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-14 04:13:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-14 04:13:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-14 04:13:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-14 04:13:55 --> Final output sent to browser
DEBUG - 2025-05-14 04:13:55 --> Total execution time: 0.1003
INFO - 2025-05-14 04:13:57 --> Config Class Initialized
INFO - 2025-05-14 04:13:57 --> Hooks Class Initialized
DEBUG - 2025-05-14 04:13:57 --> UTF-8 Support Enabled
INFO - 2025-05-14 04:13:57 --> Utf8 Class Initialized
INFO - 2025-05-14 04:13:57 --> URI Class Initialized
INFO - 2025-05-14 04:13:57 --> Router Class Initialized
INFO - 2025-05-14 04:13:57 --> Output Class Initialized
INFO - 2025-05-14 04:13:58 --> Security Class Initialized
DEBUG - 2025-05-14 04:13:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 04:13:58 --> Input Class Initialized
INFO - 2025-05-14 04:13:58 --> Language Class Initialized
INFO - 2025-05-14 04:13:58 --> Loader Class Initialized
INFO - 2025-05-14 04:13:58 --> Helper loaded: url_helper
INFO - 2025-05-14 04:13:58 --> Helper loaded: form_helper
INFO - 2025-05-14 04:13:58 --> Database Driver Class Initialized
DEBUG - 2025-05-14 04:13:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 04:13:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 04:13:58 --> Controller Class Initialized
INFO - 2025-05-14 04:13:58 --> Model "Workout_model" initialized
INFO - 2025-05-14 04:13:58 --> Model "User_model" initialized
INFO - 2025-05-14 04:13:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-14 04:13:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-14 04:13:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/add_jadwal.php
INFO - 2025-05-14 04:13:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-14 04:13:58 --> Final output sent to browser
DEBUG - 2025-05-14 04:13:58 --> Total execution time: 0.0766
INFO - 2025-05-14 04:14:09 --> Config Class Initialized
INFO - 2025-05-14 04:14:09 --> Hooks Class Initialized
DEBUG - 2025-05-14 04:14:09 --> UTF-8 Support Enabled
INFO - 2025-05-14 04:14:09 --> Utf8 Class Initialized
INFO - 2025-05-14 04:14:09 --> URI Class Initialized
INFO - 2025-05-14 04:14:09 --> Router Class Initialized
INFO - 2025-05-14 04:14:09 --> Output Class Initialized
INFO - 2025-05-14 04:14:09 --> Security Class Initialized
DEBUG - 2025-05-14 04:14:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 04:14:09 --> Input Class Initialized
INFO - 2025-05-14 04:14:09 --> Language Class Initialized
INFO - 2025-05-14 04:14:09 --> Loader Class Initialized
INFO - 2025-05-14 04:14:09 --> Helper loaded: url_helper
INFO - 2025-05-14 04:14:09 --> Helper loaded: form_helper
INFO - 2025-05-14 04:14:09 --> Database Driver Class Initialized
DEBUG - 2025-05-14 04:14:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 04:14:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 04:14:09 --> Controller Class Initialized
INFO - 2025-05-14 04:14:09 --> Model "Workout_model" initialized
INFO - 2025-05-14 04:14:09 --> Model "User_model" initialized
INFO - 2025-05-14 04:14:09 --> Config Class Initialized
INFO - 2025-05-14 04:14:09 --> Hooks Class Initialized
DEBUG - 2025-05-14 04:14:09 --> UTF-8 Support Enabled
INFO - 2025-05-14 04:14:09 --> Utf8 Class Initialized
INFO - 2025-05-14 04:14:09 --> URI Class Initialized
INFO - 2025-05-14 04:14:09 --> Router Class Initialized
INFO - 2025-05-14 04:14:09 --> Output Class Initialized
INFO - 2025-05-14 04:14:09 --> Security Class Initialized
DEBUG - 2025-05-14 04:14:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 04:14:09 --> Input Class Initialized
INFO - 2025-05-14 04:14:09 --> Language Class Initialized
INFO - 2025-05-14 04:14:09 --> Loader Class Initialized
INFO - 2025-05-14 04:14:09 --> Helper loaded: url_helper
INFO - 2025-05-14 04:14:09 --> Helper loaded: form_helper
INFO - 2025-05-14 04:14:09 --> Database Driver Class Initialized
DEBUG - 2025-05-14 04:14:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 04:14:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 04:14:09 --> Controller Class Initialized
INFO - 2025-05-14 04:14:09 --> Model "Workout_model" initialized
INFO - 2025-05-14 04:14:09 --> Model "User_model" initialized
INFO - 2025-05-14 04:14:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-14 04:14:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-14 04:14:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-14 04:14:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-14 04:14:09 --> Final output sent to browser
DEBUG - 2025-05-14 04:14:09 --> Total execution time: 0.0957
INFO - 2025-05-14 04:14:13 --> Config Class Initialized
INFO - 2025-05-14 04:14:13 --> Hooks Class Initialized
DEBUG - 2025-05-14 04:14:13 --> UTF-8 Support Enabled
INFO - 2025-05-14 04:14:13 --> Utf8 Class Initialized
INFO - 2025-05-14 04:14:13 --> URI Class Initialized
INFO - 2025-05-14 04:14:13 --> Router Class Initialized
INFO - 2025-05-14 04:14:13 --> Output Class Initialized
INFO - 2025-05-14 04:14:13 --> Security Class Initialized
DEBUG - 2025-05-14 04:14:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 04:14:13 --> Input Class Initialized
INFO - 2025-05-14 04:14:13 --> Language Class Initialized
INFO - 2025-05-14 04:14:13 --> Loader Class Initialized
INFO - 2025-05-14 04:14:13 --> Helper loaded: url_helper
INFO - 2025-05-14 04:14:13 --> Helper loaded: form_helper
INFO - 2025-05-14 04:14:13 --> Database Driver Class Initialized
DEBUG - 2025-05-14 04:14:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 04:14:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 04:14:13 --> Controller Class Initialized
INFO - 2025-05-14 04:14:13 --> Model "Workout_model" initialized
INFO - 2025-05-14 04:14:13 --> Model "User_model" initialized
INFO - 2025-05-14 04:14:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/start.php
INFO - 2025-05-14 04:14:13 --> Final output sent to browser
DEBUG - 2025-05-14 04:14:13 --> Total execution time: 0.1596
INFO - 2025-05-14 04:14:21 --> Config Class Initialized
INFO - 2025-05-14 04:14:21 --> Hooks Class Initialized
DEBUG - 2025-05-14 04:14:21 --> UTF-8 Support Enabled
INFO - 2025-05-14 04:14:21 --> Utf8 Class Initialized
INFO - 2025-05-14 04:14:21 --> URI Class Initialized
INFO - 2025-05-14 04:14:21 --> Router Class Initialized
INFO - 2025-05-14 04:14:21 --> Output Class Initialized
INFO - 2025-05-14 04:14:21 --> Security Class Initialized
DEBUG - 2025-05-14 04:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 04:14:21 --> Input Class Initialized
INFO - 2025-05-14 04:14:21 --> Language Class Initialized
INFO - 2025-05-14 04:14:21 --> Loader Class Initialized
INFO - 2025-05-14 04:14:21 --> Helper loaded: url_helper
INFO - 2025-05-14 04:14:21 --> Helper loaded: form_helper
INFO - 2025-05-14 04:14:21 --> Database Driver Class Initialized
DEBUG - 2025-05-14 04:14:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 04:14:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 04:14:21 --> Controller Class Initialized
INFO - 2025-05-14 04:14:21 --> Model "Workout_model" initialized
INFO - 2025-05-14 04:14:21 --> Model "User_model" initialized
INFO - 2025-05-14 04:14:21 --> Final output sent to browser
DEBUG - 2025-05-14 04:14:21 --> Total execution time: 0.0879
INFO - 2025-05-14 04:14:21 --> Config Class Initialized
INFO - 2025-05-14 04:14:21 --> Hooks Class Initialized
DEBUG - 2025-05-14 04:14:21 --> UTF-8 Support Enabled
INFO - 2025-05-14 04:14:21 --> Utf8 Class Initialized
INFO - 2025-05-14 04:14:21 --> URI Class Initialized
INFO - 2025-05-14 04:14:21 --> Router Class Initialized
INFO - 2025-05-14 04:14:21 --> Output Class Initialized
INFO - 2025-05-14 04:14:21 --> Security Class Initialized
DEBUG - 2025-05-14 04:14:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 04:14:21 --> Input Class Initialized
INFO - 2025-05-14 04:14:21 --> Language Class Initialized
INFO - 2025-05-14 04:14:21 --> Loader Class Initialized
INFO - 2025-05-14 04:14:21 --> Helper loaded: url_helper
INFO - 2025-05-14 04:14:21 --> Helper loaded: form_helper
INFO - 2025-05-14 04:14:21 --> Database Driver Class Initialized
DEBUG - 2025-05-14 04:14:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 04:14:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 04:14:21 --> Controller Class Initialized
INFO - 2025-05-14 04:14:21 --> Model "Workout_model" initialized
INFO - 2025-05-14 04:14:21 --> Model "User_model" initialized
INFO - 2025-05-14 04:14:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-14 04:14:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-14 04:14:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-14 04:14:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-14 04:14:21 --> Final output sent to browser
DEBUG - 2025-05-14 04:14:21 --> Total execution time: 0.0753
INFO - 2025-05-14 04:14:28 --> Config Class Initialized
INFO - 2025-05-14 04:14:28 --> Hooks Class Initialized
DEBUG - 2025-05-14 04:14:28 --> UTF-8 Support Enabled
INFO - 2025-05-14 04:14:28 --> Utf8 Class Initialized
INFO - 2025-05-14 04:14:28 --> URI Class Initialized
INFO - 2025-05-14 04:14:28 --> Router Class Initialized
INFO - 2025-05-14 04:14:28 --> Output Class Initialized
INFO - 2025-05-14 04:14:28 --> Security Class Initialized
DEBUG - 2025-05-14 04:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 04:14:28 --> Input Class Initialized
INFO - 2025-05-14 04:14:28 --> Language Class Initialized
INFO - 2025-05-14 04:14:28 --> Loader Class Initialized
INFO - 2025-05-14 04:14:28 --> Helper loaded: url_helper
INFO - 2025-05-14 04:14:28 --> Helper loaded: form_helper
INFO - 2025-05-14 04:14:28 --> Database Driver Class Initialized
DEBUG - 2025-05-14 04:14:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 04:14:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 04:14:28 --> Controller Class Initialized
INFO - 2025-05-14 04:14:28 --> Model "User_model" initialized
INFO - 2025-05-14 04:14:28 --> Model "Workout_model" initialized
INFO - 2025-05-14 04:14:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-14 04:14:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-14 04:14:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-14 04:14:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-14 04:14:28 --> Final output sent to browser
DEBUG - 2025-05-14 04:14:28 --> Total execution time: 0.1045
INFO - 2025-05-14 04:14:33 --> Config Class Initialized
INFO - 2025-05-14 04:14:33 --> Hooks Class Initialized
DEBUG - 2025-05-14 04:14:33 --> UTF-8 Support Enabled
INFO - 2025-05-14 04:14:33 --> Utf8 Class Initialized
INFO - 2025-05-14 04:14:33 --> URI Class Initialized
INFO - 2025-05-14 04:14:33 --> Router Class Initialized
INFO - 2025-05-14 04:14:33 --> Output Class Initialized
INFO - 2025-05-14 04:14:33 --> Security Class Initialized
DEBUG - 2025-05-14 04:14:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 04:14:33 --> Input Class Initialized
INFO - 2025-05-14 04:14:33 --> Language Class Initialized
INFO - 2025-05-14 04:14:33 --> Loader Class Initialized
INFO - 2025-05-14 04:14:33 --> Helper loaded: url_helper
INFO - 2025-05-14 04:14:33 --> Helper loaded: form_helper
INFO - 2025-05-14 04:14:33 --> Database Driver Class Initialized
DEBUG - 2025-05-14 04:14:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 04:14:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 04:14:33 --> Controller Class Initialized
INFO - 2025-05-14 04:14:33 --> Model "User_model" initialized
INFO - 2025-05-14 04:14:33 --> Model "Community_model" initialized
INFO - 2025-05-14 04:14:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-14 04:14:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-14 04:14:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/community.php
INFO - 2025-05-14 04:14:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-14 04:14:33 --> Final output sent to browser
DEBUG - 2025-05-14 04:14:33 --> Total execution time: 0.0777
INFO - 2025-05-14 04:14:39 --> Config Class Initialized
INFO - 2025-05-14 04:14:39 --> Hooks Class Initialized
DEBUG - 2025-05-14 04:14:39 --> UTF-8 Support Enabled
INFO - 2025-05-14 04:14:39 --> Utf8 Class Initialized
INFO - 2025-05-14 04:14:39 --> URI Class Initialized
INFO - 2025-05-14 04:14:39 --> Router Class Initialized
INFO - 2025-05-14 04:14:39 --> Output Class Initialized
INFO - 2025-05-14 04:14:39 --> Security Class Initialized
DEBUG - 2025-05-14 04:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 04:14:39 --> Input Class Initialized
INFO - 2025-05-14 04:14:39 --> Language Class Initialized
INFO - 2025-05-14 04:14:39 --> Loader Class Initialized
INFO - 2025-05-14 04:14:39 --> Helper loaded: url_helper
INFO - 2025-05-14 04:14:39 --> Helper loaded: form_helper
INFO - 2025-05-14 04:14:39 --> Database Driver Class Initialized
DEBUG - 2025-05-14 04:14:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 04:14:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 04:14:39 --> Controller Class Initialized
INFO - 2025-05-14 04:14:39 --> Model "User_model" initialized
INFO - 2025-05-14 04:14:39 --> Model "Community_model" initialized
INFO - 2025-05-14 04:14:39 --> Config Class Initialized
INFO - 2025-05-14 04:14:39 --> Hooks Class Initialized
DEBUG - 2025-05-14 04:14:39 --> UTF-8 Support Enabled
INFO - 2025-05-14 04:14:39 --> Utf8 Class Initialized
INFO - 2025-05-14 04:14:39 --> URI Class Initialized
INFO - 2025-05-14 04:14:39 --> Router Class Initialized
INFO - 2025-05-14 04:14:39 --> Output Class Initialized
INFO - 2025-05-14 04:14:39 --> Security Class Initialized
DEBUG - 2025-05-14 04:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 04:14:39 --> Input Class Initialized
INFO - 2025-05-14 04:14:40 --> Language Class Initialized
INFO - 2025-05-14 04:14:40 --> Loader Class Initialized
INFO - 2025-05-14 04:14:40 --> Helper loaded: url_helper
INFO - 2025-05-14 04:14:40 --> Helper loaded: form_helper
INFO - 2025-05-14 04:14:40 --> Database Driver Class Initialized
DEBUG - 2025-05-14 04:14:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 04:14:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 04:14:40 --> Controller Class Initialized
INFO - 2025-05-14 04:14:40 --> Model "User_model" initialized
INFO - 2025-05-14 04:14:40 --> Model "Community_model" initialized
INFO - 2025-05-14 04:14:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-14 04:14:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-14 04:14:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/community.php
INFO - 2025-05-14 04:14:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-14 04:14:40 --> Final output sent to browser
DEBUG - 2025-05-14 04:14:40 --> Total execution time: 0.0976
INFO - 2025-05-14 04:14:49 --> Config Class Initialized
INFO - 2025-05-14 04:14:49 --> Hooks Class Initialized
DEBUG - 2025-05-14 04:14:49 --> UTF-8 Support Enabled
INFO - 2025-05-14 04:14:49 --> Utf8 Class Initialized
INFO - 2025-05-14 04:14:49 --> URI Class Initialized
INFO - 2025-05-14 04:14:49 --> Router Class Initialized
INFO - 2025-05-14 04:14:49 --> Output Class Initialized
INFO - 2025-05-14 04:14:49 --> Security Class Initialized
DEBUG - 2025-05-14 04:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 04:14:49 --> Input Class Initialized
INFO - 2025-05-14 04:14:49 --> Language Class Initialized
INFO - 2025-05-14 04:14:49 --> Loader Class Initialized
INFO - 2025-05-14 04:14:49 --> Helper loaded: url_helper
INFO - 2025-05-14 04:14:49 --> Helper loaded: form_helper
INFO - 2025-05-14 04:14:49 --> Database Driver Class Initialized
DEBUG - 2025-05-14 04:14:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 04:14:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 04:14:49 --> Controller Class Initialized
INFO - 2025-05-14 04:14:49 --> Model "User_model" initialized
INFO - 2025-05-14 04:14:49 --> Model "Workout_model" initialized
INFO - 2025-05-14 04:14:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-14 04:14:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-14 04:14:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-14 04:14:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-14 04:14:49 --> Final output sent to browser
DEBUG - 2025-05-14 04:14:49 --> Total execution time: 0.1069
INFO - 2025-05-14 04:14:52 --> Config Class Initialized
INFO - 2025-05-14 04:14:52 --> Hooks Class Initialized
DEBUG - 2025-05-14 04:14:52 --> UTF-8 Support Enabled
INFO - 2025-05-14 04:14:52 --> Utf8 Class Initialized
INFO - 2025-05-14 04:14:52 --> URI Class Initialized
INFO - 2025-05-14 04:14:52 --> Router Class Initialized
INFO - 2025-05-14 04:14:52 --> Output Class Initialized
INFO - 2025-05-14 04:14:52 --> Security Class Initialized
DEBUG - 2025-05-14 04:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 04:14:52 --> Input Class Initialized
INFO - 2025-05-14 04:14:52 --> Language Class Initialized
INFO - 2025-05-14 04:14:52 --> Loader Class Initialized
INFO - 2025-05-14 04:14:52 --> Helper loaded: url_helper
INFO - 2025-05-14 04:14:52 --> Helper loaded: form_helper
INFO - 2025-05-14 04:14:52 --> Database Driver Class Initialized
DEBUG - 2025-05-14 04:14:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 04:14:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 04:14:52 --> Controller Class Initialized
INFO - 2025-05-14 04:14:52 --> Model "User_model" initialized
INFO - 2025-05-14 04:14:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-14 04:14:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-14 04:14:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/profile.php
INFO - 2025-05-14 04:14:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-14 04:14:52 --> Final output sent to browser
DEBUG - 2025-05-14 04:14:52 --> Total execution time: 0.1687
INFO - 2025-05-14 04:14:57 --> Config Class Initialized
INFO - 2025-05-14 04:14:57 --> Hooks Class Initialized
DEBUG - 2025-05-14 04:14:57 --> UTF-8 Support Enabled
INFO - 2025-05-14 04:14:57 --> Utf8 Class Initialized
INFO - 2025-05-14 04:14:57 --> URI Class Initialized
INFO - 2025-05-14 04:14:57 --> Router Class Initialized
INFO - 2025-05-14 04:14:57 --> Output Class Initialized
INFO - 2025-05-14 04:14:57 --> Security Class Initialized
DEBUG - 2025-05-14 04:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 04:14:57 --> Input Class Initialized
INFO - 2025-05-14 04:14:57 --> Language Class Initialized
INFO - 2025-05-14 04:14:57 --> Loader Class Initialized
INFO - 2025-05-14 04:14:57 --> Helper loaded: url_helper
INFO - 2025-05-14 04:14:57 --> Helper loaded: form_helper
INFO - 2025-05-14 04:14:57 --> Database Driver Class Initialized
DEBUG - 2025-05-14 04:14:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 04:14:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 04:14:57 --> Controller Class Initialized
INFO - 2025-05-14 04:14:57 --> Model "User_model" initialized
INFO - 2025-05-14 04:14:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-14 04:14:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-14 04:14:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/edit_profile.php
INFO - 2025-05-14 04:14:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-14 04:14:57 --> Final output sent to browser
DEBUG - 2025-05-14 04:14:57 --> Total execution time: 0.1222
INFO - 2025-05-14 04:15:29 --> Config Class Initialized
INFO - 2025-05-14 04:15:29 --> Hooks Class Initialized
DEBUG - 2025-05-14 04:15:29 --> UTF-8 Support Enabled
INFO - 2025-05-14 04:15:29 --> Utf8 Class Initialized
INFO - 2025-05-14 04:15:29 --> URI Class Initialized
INFO - 2025-05-14 04:15:29 --> Router Class Initialized
INFO - 2025-05-14 04:15:29 --> Output Class Initialized
INFO - 2025-05-14 04:15:29 --> Security Class Initialized
DEBUG - 2025-05-14 04:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 04:15:29 --> Input Class Initialized
INFO - 2025-05-14 04:15:29 --> Language Class Initialized
INFO - 2025-05-14 04:15:29 --> Loader Class Initialized
INFO - 2025-05-14 04:15:29 --> Helper loaded: url_helper
INFO - 2025-05-14 04:15:29 --> Helper loaded: form_helper
INFO - 2025-05-14 04:15:29 --> Database Driver Class Initialized
DEBUG - 2025-05-14 04:15:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 04:15:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 04:15:29 --> Controller Class Initialized
INFO - 2025-05-14 04:15:29 --> Model "User_model" initialized
INFO - 2025-05-14 04:15:29 --> Config Class Initialized
INFO - 2025-05-14 04:15:29 --> Hooks Class Initialized
DEBUG - 2025-05-14 04:15:29 --> UTF-8 Support Enabled
INFO - 2025-05-14 04:15:29 --> Utf8 Class Initialized
INFO - 2025-05-14 04:15:29 --> URI Class Initialized
INFO - 2025-05-14 04:15:29 --> Router Class Initialized
INFO - 2025-05-14 04:15:29 --> Output Class Initialized
INFO - 2025-05-14 04:15:29 --> Security Class Initialized
DEBUG - 2025-05-14 04:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 04:15:29 --> Input Class Initialized
INFO - 2025-05-14 04:15:29 --> Language Class Initialized
INFO - 2025-05-14 04:15:29 --> Loader Class Initialized
INFO - 2025-05-14 04:15:29 --> Helper loaded: url_helper
INFO - 2025-05-14 04:15:29 --> Helper loaded: form_helper
INFO - 2025-05-14 04:15:29 --> Database Driver Class Initialized
DEBUG - 2025-05-14 04:15:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 04:15:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 04:15:29 --> Controller Class Initialized
INFO - 2025-05-14 04:15:29 --> Model "User_model" initialized
INFO - 2025-05-14 04:15:29 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-14 04:15:29 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-14 04:15:29 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/profile.php
INFO - 2025-05-14 04:15:29 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-14 04:15:29 --> Final output sent to browser
DEBUG - 2025-05-14 04:15:29 --> Total execution time: 0.0833
INFO - 2025-05-14 04:15:33 --> Config Class Initialized
INFO - 2025-05-14 04:15:33 --> Hooks Class Initialized
DEBUG - 2025-05-14 04:15:33 --> UTF-8 Support Enabled
INFO - 2025-05-14 04:15:33 --> Utf8 Class Initialized
INFO - 2025-05-14 04:15:33 --> URI Class Initialized
INFO - 2025-05-14 04:15:33 --> Router Class Initialized
INFO - 2025-05-14 04:15:33 --> Output Class Initialized
INFO - 2025-05-14 04:15:33 --> Security Class Initialized
DEBUG - 2025-05-14 04:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 04:15:33 --> Input Class Initialized
INFO - 2025-05-14 04:15:33 --> Language Class Initialized
INFO - 2025-05-14 04:15:33 --> Loader Class Initialized
INFO - 2025-05-14 04:15:33 --> Helper loaded: url_helper
INFO - 2025-05-14 04:15:33 --> Helper loaded: form_helper
INFO - 2025-05-14 04:15:33 --> Database Driver Class Initialized
DEBUG - 2025-05-14 04:15:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 04:15:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 04:15:33 --> Controller Class Initialized
INFO - 2025-05-14 04:15:33 --> Model "User_model" initialized
INFO - 2025-05-14 04:15:33 --> Model "Workout_model" initialized
INFO - 2025-05-14 04:15:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-14 04:15:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-14 04:15:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-14 04:15:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-14 04:15:33 --> Final output sent to browser
DEBUG - 2025-05-14 04:15:33 --> Total execution time: 0.0785
INFO - 2025-05-14 04:15:42 --> Config Class Initialized
INFO - 2025-05-14 04:15:42 --> Hooks Class Initialized
DEBUG - 2025-05-14 04:15:42 --> UTF-8 Support Enabled
INFO - 2025-05-14 04:15:42 --> Utf8 Class Initialized
INFO - 2025-05-14 04:15:42 --> URI Class Initialized
INFO - 2025-05-14 04:15:42 --> Router Class Initialized
INFO - 2025-05-14 04:15:42 --> Output Class Initialized
INFO - 2025-05-14 04:15:42 --> Security Class Initialized
DEBUG - 2025-05-14 04:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 04:15:42 --> Input Class Initialized
INFO - 2025-05-14 04:15:42 --> Language Class Initialized
INFO - 2025-05-14 04:15:42 --> Loader Class Initialized
INFO - 2025-05-14 04:15:42 --> Helper loaded: url_helper
INFO - 2025-05-14 04:15:42 --> Helper loaded: form_helper
INFO - 2025-05-14 04:15:42 --> Database Driver Class Initialized
DEBUG - 2025-05-14 04:15:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 04:15:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 04:15:42 --> Controller Class Initialized
INFO - 2025-05-14 04:15:42 --> Model "User_model" initialized
INFO - 2025-05-14 04:15:42 --> Config Class Initialized
INFO - 2025-05-14 04:15:42 --> Hooks Class Initialized
DEBUG - 2025-05-14 04:15:42 --> UTF-8 Support Enabled
INFO - 2025-05-14 04:15:42 --> Utf8 Class Initialized
INFO - 2025-05-14 04:15:42 --> URI Class Initialized
INFO - 2025-05-14 04:15:42 --> Router Class Initialized
INFO - 2025-05-14 04:15:42 --> Output Class Initialized
INFO - 2025-05-14 04:15:42 --> Security Class Initialized
DEBUG - 2025-05-14 04:15:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 04:15:42 --> Input Class Initialized
INFO - 2025-05-14 04:15:42 --> Language Class Initialized
INFO - 2025-05-14 04:15:42 --> Loader Class Initialized
INFO - 2025-05-14 04:15:42 --> Helper loaded: url_helper
INFO - 2025-05-14 04:15:42 --> Helper loaded: form_helper
INFO - 2025-05-14 04:15:42 --> Database Driver Class Initialized
DEBUG - 2025-05-14 04:15:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 04:15:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 04:15:42 --> Controller Class Initialized
INFO - 2025-05-14 04:15:42 --> Model "User_model" initialized
INFO - 2025-05-14 04:15:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-14 04:15:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-14 04:15:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-14 04:15:42 --> Final output sent to browser
DEBUG - 2025-05-14 04:15:42 --> Total execution time: 0.0731
INFO - 2025-05-14 06:58:47 --> Config Class Initialized
INFO - 2025-05-14 06:58:47 --> Hooks Class Initialized
DEBUG - 2025-05-14 06:58:47 --> UTF-8 Support Enabled
INFO - 2025-05-14 06:58:47 --> Utf8 Class Initialized
INFO - 2025-05-14 06:58:47 --> URI Class Initialized
DEBUG - 2025-05-14 06:58:47 --> No URI present. Default controller set.
INFO - 2025-05-14 06:58:47 --> Router Class Initialized
INFO - 2025-05-14 06:58:48 --> Output Class Initialized
INFO - 2025-05-14 06:58:48 --> Security Class Initialized
DEBUG - 2025-05-14 06:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 06:58:48 --> Input Class Initialized
INFO - 2025-05-14 06:58:48 --> Language Class Initialized
INFO - 2025-05-14 06:58:48 --> Loader Class Initialized
INFO - 2025-05-14 06:58:48 --> Helper loaded: url_helper
INFO - 2025-05-14 06:58:48 --> Helper loaded: form_helper
INFO - 2025-05-14 06:58:48 --> Database Driver Class Initialized
DEBUG - 2025-05-14 06:58:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 06:58:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 06:58:48 --> Controller Class Initialized
INFO - 2025-05-14 06:58:48 --> Model "User_model" initialized
INFO - 2025-05-14 06:58:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-14 06:58:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-14 06:58:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-14 06:58:49 --> Final output sent to browser
DEBUG - 2025-05-14 06:58:49 --> Total execution time: 1.6138
INFO - 2025-05-14 06:59:10 --> Config Class Initialized
INFO - 2025-05-14 06:59:10 --> Hooks Class Initialized
DEBUG - 2025-05-14 06:59:10 --> UTF-8 Support Enabled
INFO - 2025-05-14 06:59:10 --> Utf8 Class Initialized
INFO - 2025-05-14 06:59:10 --> URI Class Initialized
DEBUG - 2025-05-14 06:59:10 --> No URI present. Default controller set.
INFO - 2025-05-14 06:59:10 --> Router Class Initialized
INFO - 2025-05-14 06:59:10 --> Output Class Initialized
INFO - 2025-05-14 06:59:10 --> Security Class Initialized
DEBUG - 2025-05-14 06:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 06:59:10 --> Input Class Initialized
INFO - 2025-05-14 06:59:10 --> Language Class Initialized
INFO - 2025-05-14 06:59:10 --> Loader Class Initialized
INFO - 2025-05-14 06:59:10 --> Helper loaded: url_helper
INFO - 2025-05-14 06:59:10 --> Helper loaded: form_helper
INFO - 2025-05-14 06:59:10 --> Database Driver Class Initialized
DEBUG - 2025-05-14 06:59:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 06:59:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 06:59:10 --> Controller Class Initialized
INFO - 2025-05-14 06:59:10 --> Model "User_model" initialized
INFO - 2025-05-14 06:59:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-14 06:59:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-14 06:59:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-14 06:59:10 --> Final output sent to browser
DEBUG - 2025-05-14 06:59:10 --> Total execution time: 0.0771
INFO - 2025-05-14 06:59:17 --> Config Class Initialized
INFO - 2025-05-14 06:59:17 --> Hooks Class Initialized
DEBUG - 2025-05-14 06:59:17 --> UTF-8 Support Enabled
INFO - 2025-05-14 06:59:17 --> Utf8 Class Initialized
INFO - 2025-05-14 06:59:17 --> URI Class Initialized
INFO - 2025-05-14 06:59:17 --> Router Class Initialized
INFO - 2025-05-14 06:59:17 --> Output Class Initialized
INFO - 2025-05-14 06:59:17 --> Security Class Initialized
DEBUG - 2025-05-14 06:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 06:59:17 --> Input Class Initialized
INFO - 2025-05-14 06:59:17 --> Language Class Initialized
INFO - 2025-05-14 06:59:17 --> Loader Class Initialized
INFO - 2025-05-14 06:59:17 --> Helper loaded: url_helper
INFO - 2025-05-14 06:59:17 --> Helper loaded: form_helper
INFO - 2025-05-14 06:59:17 --> Database Driver Class Initialized
DEBUG - 2025-05-14 06:59:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 06:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 06:59:17 --> Controller Class Initialized
INFO - 2025-05-14 06:59:17 --> Model "User_model" initialized
INFO - 2025-05-14 06:59:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-14 06:59:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/artikel.php
INFO - 2025-05-14 06:59:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-14 06:59:17 --> Final output sent to browser
DEBUG - 2025-05-14 06:59:17 --> Total execution time: 0.1382
INFO - 2025-05-14 06:59:19 --> Config Class Initialized
INFO - 2025-05-14 06:59:19 --> Hooks Class Initialized
DEBUG - 2025-05-14 06:59:19 --> UTF-8 Support Enabled
INFO - 2025-05-14 06:59:19 --> Utf8 Class Initialized
INFO - 2025-05-14 06:59:19 --> URI Class Initialized
INFO - 2025-05-14 06:59:19 --> Router Class Initialized
INFO - 2025-05-14 06:59:19 --> Output Class Initialized
INFO - 2025-05-14 06:59:19 --> Security Class Initialized
DEBUG - 2025-05-14 06:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 06:59:19 --> Input Class Initialized
INFO - 2025-05-14 06:59:19 --> Language Class Initialized
INFO - 2025-05-14 06:59:19 --> Loader Class Initialized
INFO - 2025-05-14 06:59:19 --> Helper loaded: url_helper
INFO - 2025-05-14 06:59:19 --> Helper loaded: form_helper
INFO - 2025-05-14 06:59:19 --> Database Driver Class Initialized
DEBUG - 2025-05-14 06:59:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 06:59:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 06:59:19 --> Controller Class Initialized
INFO - 2025-05-14 06:59:19 --> Model "User_model" initialized
INFO - 2025-05-14 06:59:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-14 06:59:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-14 06:59:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-14 06:59:19 --> Final output sent to browser
DEBUG - 2025-05-14 06:59:19 --> Total execution time: 0.0731
INFO - 2025-05-14 06:59:23 --> Config Class Initialized
INFO - 2025-05-14 06:59:23 --> Hooks Class Initialized
DEBUG - 2025-05-14 06:59:23 --> UTF-8 Support Enabled
INFO - 2025-05-14 06:59:23 --> Utf8 Class Initialized
INFO - 2025-05-14 06:59:23 --> URI Class Initialized
INFO - 2025-05-14 06:59:23 --> Router Class Initialized
INFO - 2025-05-14 06:59:23 --> Output Class Initialized
INFO - 2025-05-14 06:59:23 --> Security Class Initialized
DEBUG - 2025-05-14 06:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 06:59:23 --> Input Class Initialized
INFO - 2025-05-14 06:59:23 --> Language Class Initialized
INFO - 2025-05-14 06:59:23 --> Loader Class Initialized
INFO - 2025-05-14 06:59:23 --> Helper loaded: url_helper
INFO - 2025-05-14 06:59:23 --> Helper loaded: form_helper
INFO - 2025-05-14 06:59:23 --> Database Driver Class Initialized
DEBUG - 2025-05-14 06:59:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 06:59:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 06:59:23 --> Controller Class Initialized
INFO - 2025-05-14 06:59:23 --> Model "User_model" initialized
INFO - 2025-05-14 06:59:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-14 06:59:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/artikel.php
INFO - 2025-05-14 06:59:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-14 06:59:23 --> Final output sent to browser
DEBUG - 2025-05-14 06:59:23 --> Total execution time: 0.1144
INFO - 2025-05-14 12:42:01 --> Config Class Initialized
INFO - 2025-05-14 12:42:01 --> Hooks Class Initialized
DEBUG - 2025-05-14 12:42:01 --> UTF-8 Support Enabled
INFO - 2025-05-14 12:42:01 --> Utf8 Class Initialized
INFO - 2025-05-14 12:42:01 --> URI Class Initialized
DEBUG - 2025-05-14 12:42:01 --> No URI present. Default controller set.
INFO - 2025-05-14 12:42:01 --> Router Class Initialized
INFO - 2025-05-14 12:42:01 --> Output Class Initialized
INFO - 2025-05-14 12:42:01 --> Security Class Initialized
DEBUG - 2025-05-14 12:42:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 12:42:01 --> Input Class Initialized
INFO - 2025-05-14 12:42:01 --> Language Class Initialized
INFO - 2025-05-14 12:42:01 --> Loader Class Initialized
INFO - 2025-05-14 12:42:01 --> Helper loaded: url_helper
INFO - 2025-05-14 12:42:01 --> Helper loaded: form_helper
INFO - 2025-05-14 12:42:01 --> Database Driver Class Initialized
DEBUG - 2025-05-14 12:42:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 12:42:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 12:42:01 --> Controller Class Initialized
INFO - 2025-05-14 12:42:01 --> Model "User_model" initialized
INFO - 2025-05-14 12:42:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-14 12:42:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-14 12:42:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-14 12:42:01 --> Final output sent to browser
DEBUG - 2025-05-14 12:42:01 --> Total execution time: 0.1607
INFO - 2025-05-14 14:11:43 --> Config Class Initialized
INFO - 2025-05-14 14:11:43 --> Hooks Class Initialized
DEBUG - 2025-05-14 14:11:43 --> UTF-8 Support Enabled
INFO - 2025-05-14 14:11:43 --> Utf8 Class Initialized
INFO - 2025-05-14 14:11:43 --> URI Class Initialized
DEBUG - 2025-05-14 14:11:43 --> No URI present. Default controller set.
INFO - 2025-05-14 14:11:43 --> Router Class Initialized
INFO - 2025-05-14 14:11:43 --> Output Class Initialized
INFO - 2025-05-14 14:11:43 --> Security Class Initialized
DEBUG - 2025-05-14 14:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 14:11:43 --> Input Class Initialized
INFO - 2025-05-14 14:11:43 --> Language Class Initialized
INFO - 2025-05-14 14:11:43 --> Loader Class Initialized
INFO - 2025-05-14 14:11:43 --> Helper loaded: url_helper
INFO - 2025-05-14 14:11:43 --> Helper loaded: form_helper
INFO - 2025-05-14 14:11:43 --> Database Driver Class Initialized
DEBUG - 2025-05-14 14:11:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 14:11:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 14:11:43 --> Controller Class Initialized
INFO - 2025-05-14 14:11:43 --> Model "User_model" initialized
INFO - 2025-05-14 14:11:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-14 14:11:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-14 14:11:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-14 14:11:43 --> Final output sent to browser
DEBUG - 2025-05-14 14:11:43 --> Total execution time: 0.1956
INFO - 2025-05-14 14:12:55 --> Config Class Initialized
INFO - 2025-05-14 14:12:55 --> Hooks Class Initialized
DEBUG - 2025-05-14 14:12:55 --> UTF-8 Support Enabled
INFO - 2025-05-14 14:12:55 --> Utf8 Class Initialized
INFO - 2025-05-14 14:12:55 --> URI Class Initialized
DEBUG - 2025-05-14 14:12:55 --> No URI present. Default controller set.
INFO - 2025-05-14 14:12:55 --> Router Class Initialized
INFO - 2025-05-14 14:12:55 --> Output Class Initialized
INFO - 2025-05-14 14:12:55 --> Security Class Initialized
DEBUG - 2025-05-14 14:12:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 14:12:55 --> Input Class Initialized
INFO - 2025-05-14 14:12:55 --> Language Class Initialized
INFO - 2025-05-14 14:12:55 --> Loader Class Initialized
INFO - 2025-05-14 14:12:55 --> Helper loaded: url_helper
INFO - 2025-05-14 14:12:55 --> Helper loaded: form_helper
INFO - 2025-05-14 14:12:55 --> Database Driver Class Initialized
DEBUG - 2025-05-14 14:12:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 14:12:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 14:12:55 --> Controller Class Initialized
INFO - 2025-05-14 14:12:55 --> Model "User_model" initialized
INFO - 2025-05-14 14:12:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-14 14:12:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-14 14:12:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-14 14:12:55 --> Final output sent to browser
DEBUG - 2025-05-14 14:12:55 --> Total execution time: 0.1111
INFO - 2025-05-14 14:30:55 --> Config Class Initialized
INFO - 2025-05-14 14:30:55 --> Hooks Class Initialized
DEBUG - 2025-05-14 14:30:55 --> UTF-8 Support Enabled
INFO - 2025-05-14 14:30:55 --> Utf8 Class Initialized
INFO - 2025-05-14 14:30:55 --> URI Class Initialized
DEBUG - 2025-05-14 14:30:55 --> No URI present. Default controller set.
INFO - 2025-05-14 14:30:55 --> Router Class Initialized
INFO - 2025-05-14 14:30:55 --> Output Class Initialized
INFO - 2025-05-14 14:30:55 --> Security Class Initialized
DEBUG - 2025-05-14 14:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 14:30:55 --> Input Class Initialized
INFO - 2025-05-14 14:30:55 --> Language Class Initialized
INFO - 2025-05-14 14:30:55 --> Loader Class Initialized
INFO - 2025-05-14 14:30:55 --> Helper loaded: url_helper
INFO - 2025-05-14 14:30:55 --> Helper loaded: form_helper
INFO - 2025-05-14 14:30:55 --> Database Driver Class Initialized
DEBUG - 2025-05-14 14:30:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 14:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 14:30:55 --> Controller Class Initialized
INFO - 2025-05-14 14:30:55 --> Model "User_model" initialized
INFO - 2025-05-14 14:30:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-14 14:30:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-14 14:30:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-14 14:30:55 --> Final output sent to browser
DEBUG - 2025-05-14 14:30:55 --> Total execution time: 0.0984
INFO - 2025-05-14 14:32:35 --> Config Class Initialized
INFO - 2025-05-14 14:32:35 --> Hooks Class Initialized
DEBUG - 2025-05-14 14:32:35 --> UTF-8 Support Enabled
INFO - 2025-05-14 14:32:35 --> Utf8 Class Initialized
INFO - 2025-05-14 14:32:35 --> URI Class Initialized
DEBUG - 2025-05-14 14:32:35 --> No URI present. Default controller set.
INFO - 2025-05-14 14:32:35 --> Router Class Initialized
INFO - 2025-05-14 14:32:35 --> Output Class Initialized
INFO - 2025-05-14 14:32:35 --> Security Class Initialized
DEBUG - 2025-05-14 14:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 14:32:35 --> Input Class Initialized
INFO - 2025-05-14 14:32:35 --> Language Class Initialized
INFO - 2025-05-14 14:32:35 --> Loader Class Initialized
INFO - 2025-05-14 14:32:35 --> Helper loaded: url_helper
INFO - 2025-05-14 14:32:35 --> Helper loaded: form_helper
INFO - 2025-05-14 14:32:35 --> Database Driver Class Initialized
DEBUG - 2025-05-14 14:32:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 14:32:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 14:32:35 --> Controller Class Initialized
INFO - 2025-05-14 14:32:35 --> Model "User_model" initialized
INFO - 2025-05-14 14:32:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-14 14:32:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-14 14:32:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-14 14:32:35 --> Final output sent to browser
DEBUG - 2025-05-14 14:32:35 --> Total execution time: 0.0821
INFO - 2025-05-14 14:33:17 --> Config Class Initialized
INFO - 2025-05-14 14:33:17 --> Hooks Class Initialized
DEBUG - 2025-05-14 14:33:17 --> UTF-8 Support Enabled
INFO - 2025-05-14 14:33:17 --> Utf8 Class Initialized
INFO - 2025-05-14 14:33:17 --> URI Class Initialized
DEBUG - 2025-05-14 14:33:17 --> No URI present. Default controller set.
INFO - 2025-05-14 14:33:17 --> Router Class Initialized
INFO - 2025-05-14 14:33:17 --> Output Class Initialized
INFO - 2025-05-14 14:33:17 --> Security Class Initialized
DEBUG - 2025-05-14 14:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 14:33:17 --> Input Class Initialized
INFO - 2025-05-14 14:33:17 --> Language Class Initialized
INFO - 2025-05-14 14:33:17 --> Loader Class Initialized
INFO - 2025-05-14 14:33:17 --> Helper loaded: url_helper
INFO - 2025-05-14 14:33:17 --> Helper loaded: form_helper
INFO - 2025-05-14 14:33:17 --> Database Driver Class Initialized
DEBUG - 2025-05-14 14:33:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 14:33:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 14:33:17 --> Controller Class Initialized
INFO - 2025-05-14 14:33:17 --> Model "User_model" initialized
INFO - 2025-05-14 14:33:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-14 14:33:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-14 14:33:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-14 14:33:17 --> Final output sent to browser
DEBUG - 2025-05-14 14:33:17 --> Total execution time: 0.0984
INFO - 2025-05-14 14:34:51 --> Config Class Initialized
INFO - 2025-05-14 14:34:51 --> Hooks Class Initialized
DEBUG - 2025-05-14 14:34:51 --> UTF-8 Support Enabled
INFO - 2025-05-14 14:34:51 --> Utf8 Class Initialized
INFO - 2025-05-14 14:34:51 --> URI Class Initialized
DEBUG - 2025-05-14 14:34:51 --> No URI present. Default controller set.
INFO - 2025-05-14 14:34:51 --> Router Class Initialized
INFO - 2025-05-14 14:34:51 --> Output Class Initialized
INFO - 2025-05-14 14:34:51 --> Security Class Initialized
DEBUG - 2025-05-14 14:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 14:34:51 --> Input Class Initialized
INFO - 2025-05-14 14:34:51 --> Language Class Initialized
INFO - 2025-05-14 14:34:51 --> Loader Class Initialized
INFO - 2025-05-14 14:34:51 --> Helper loaded: url_helper
INFO - 2025-05-14 14:34:51 --> Helper loaded: form_helper
INFO - 2025-05-14 14:34:51 --> Database Driver Class Initialized
DEBUG - 2025-05-14 14:34:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 14:34:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 14:34:51 --> Controller Class Initialized
INFO - 2025-05-14 14:34:51 --> Model "User_model" initialized
INFO - 2025-05-14 14:34:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-14 14:34:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-14 14:34:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-14 14:34:51 --> Final output sent to browser
DEBUG - 2025-05-14 14:34:51 --> Total execution time: 0.0833
INFO - 2025-05-14 14:36:24 --> Config Class Initialized
INFO - 2025-05-14 14:36:24 --> Hooks Class Initialized
DEBUG - 2025-05-14 14:36:24 --> UTF-8 Support Enabled
INFO - 2025-05-14 14:36:24 --> Utf8 Class Initialized
INFO - 2025-05-14 14:36:24 --> URI Class Initialized
DEBUG - 2025-05-14 14:36:24 --> No URI present. Default controller set.
INFO - 2025-05-14 14:36:24 --> Router Class Initialized
INFO - 2025-05-14 14:36:24 --> Output Class Initialized
INFO - 2025-05-14 14:36:24 --> Security Class Initialized
DEBUG - 2025-05-14 14:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 14:36:24 --> Input Class Initialized
INFO - 2025-05-14 14:36:24 --> Language Class Initialized
INFO - 2025-05-14 14:36:24 --> Loader Class Initialized
INFO - 2025-05-14 14:36:24 --> Helper loaded: url_helper
INFO - 2025-05-14 14:36:24 --> Helper loaded: form_helper
INFO - 2025-05-14 14:36:24 --> Database Driver Class Initialized
DEBUG - 2025-05-14 14:36:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 14:36:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 14:36:24 --> Controller Class Initialized
INFO - 2025-05-14 14:36:24 --> Model "User_model" initialized
INFO - 2025-05-14 14:36:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-14 14:36:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-14 14:36:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-14 14:36:25 --> Final output sent to browser
DEBUG - 2025-05-14 14:36:25 --> Total execution time: 0.0996
INFO - 2025-05-14 14:39:39 --> Config Class Initialized
INFO - 2025-05-14 14:39:39 --> Hooks Class Initialized
DEBUG - 2025-05-14 14:39:39 --> UTF-8 Support Enabled
INFO - 2025-05-14 14:39:39 --> Utf8 Class Initialized
INFO - 2025-05-14 14:39:39 --> URI Class Initialized
DEBUG - 2025-05-14 14:39:39 --> No URI present. Default controller set.
INFO - 2025-05-14 14:39:39 --> Router Class Initialized
INFO - 2025-05-14 14:39:39 --> Output Class Initialized
INFO - 2025-05-14 14:39:39 --> Security Class Initialized
DEBUG - 2025-05-14 14:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 14:39:39 --> Input Class Initialized
INFO - 2025-05-14 14:39:39 --> Language Class Initialized
INFO - 2025-05-14 14:39:39 --> Loader Class Initialized
INFO - 2025-05-14 14:39:39 --> Helper loaded: url_helper
INFO - 2025-05-14 14:39:39 --> Helper loaded: form_helper
INFO - 2025-05-14 14:39:39 --> Database Driver Class Initialized
DEBUG - 2025-05-14 14:39:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 14:39:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 14:39:39 --> Controller Class Initialized
INFO - 2025-05-14 14:39:39 --> Model "User_model" initialized
INFO - 2025-05-14 14:39:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-14 14:39:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-14 14:39:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-14 14:39:39 --> Final output sent to browser
DEBUG - 2025-05-14 14:39:39 --> Total execution time: 0.0976
INFO - 2025-05-14 14:43:55 --> Config Class Initialized
INFO - 2025-05-14 14:43:55 --> Hooks Class Initialized
DEBUG - 2025-05-14 14:43:55 --> UTF-8 Support Enabled
INFO - 2025-05-14 14:43:55 --> Utf8 Class Initialized
INFO - 2025-05-14 14:43:55 --> URI Class Initialized
DEBUG - 2025-05-14 14:43:55 --> No URI present. Default controller set.
INFO - 2025-05-14 14:43:55 --> Router Class Initialized
INFO - 2025-05-14 14:43:55 --> Output Class Initialized
INFO - 2025-05-14 14:43:55 --> Security Class Initialized
DEBUG - 2025-05-14 14:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 14:43:55 --> Input Class Initialized
INFO - 2025-05-14 14:43:55 --> Language Class Initialized
INFO - 2025-05-14 14:43:55 --> Loader Class Initialized
INFO - 2025-05-14 14:43:55 --> Helper loaded: url_helper
INFO - 2025-05-14 14:43:55 --> Helper loaded: form_helper
INFO - 2025-05-14 14:43:55 --> Database Driver Class Initialized
DEBUG - 2025-05-14 14:43:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 14:43:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 14:43:55 --> Controller Class Initialized
INFO - 2025-05-14 14:43:55 --> Model "User_model" initialized
INFO - 2025-05-14 14:43:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-14 14:43:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-14 14:43:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-14 14:43:55 --> Final output sent to browser
DEBUG - 2025-05-14 14:43:55 --> Total execution time: 0.1011
INFO - 2025-05-14 14:45:42 --> Config Class Initialized
INFO - 2025-05-14 14:45:42 --> Hooks Class Initialized
DEBUG - 2025-05-14 14:45:42 --> UTF-8 Support Enabled
INFO - 2025-05-14 14:45:42 --> Utf8 Class Initialized
INFO - 2025-05-14 14:45:42 --> URI Class Initialized
DEBUG - 2025-05-14 14:45:42 --> No URI present. Default controller set.
INFO - 2025-05-14 14:45:42 --> Router Class Initialized
INFO - 2025-05-14 14:45:42 --> Output Class Initialized
INFO - 2025-05-14 14:45:42 --> Security Class Initialized
DEBUG - 2025-05-14 14:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 14:45:42 --> Input Class Initialized
INFO - 2025-05-14 14:45:42 --> Language Class Initialized
INFO - 2025-05-14 14:45:42 --> Loader Class Initialized
INFO - 2025-05-14 14:45:42 --> Helper loaded: url_helper
INFO - 2025-05-14 14:45:42 --> Helper loaded: form_helper
INFO - 2025-05-14 14:45:42 --> Database Driver Class Initialized
DEBUG - 2025-05-14 14:45:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 14:45:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 14:45:42 --> Controller Class Initialized
INFO - 2025-05-14 14:45:42 --> Model "User_model" initialized
INFO - 2025-05-14 14:45:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-14 14:45:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-14 14:45:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-14 14:45:42 --> Final output sent to browser
DEBUG - 2025-05-14 14:45:42 --> Total execution time: 0.0803
INFO - 2025-05-14 14:51:02 --> Config Class Initialized
INFO - 2025-05-14 14:51:02 --> Hooks Class Initialized
DEBUG - 2025-05-14 14:51:02 --> UTF-8 Support Enabled
INFO - 2025-05-14 14:51:02 --> Utf8 Class Initialized
INFO - 2025-05-14 14:51:02 --> URI Class Initialized
INFO - 2025-05-14 14:51:02 --> Router Class Initialized
INFO - 2025-05-14 14:51:02 --> Output Class Initialized
INFO - 2025-05-14 14:51:02 --> Security Class Initialized
DEBUG - 2025-05-14 14:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 14:51:02 --> Input Class Initialized
INFO - 2025-05-14 14:51:02 --> Language Class Initialized
INFO - 2025-05-14 14:51:02 --> Loader Class Initialized
INFO - 2025-05-14 14:51:02 --> Helper loaded: url_helper
INFO - 2025-05-14 14:51:02 --> Helper loaded: form_helper
INFO - 2025-05-14 14:51:02 --> Database Driver Class Initialized
DEBUG - 2025-05-14 14:51:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 14:51:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 14:51:02 --> Controller Class Initialized
INFO - 2025-05-14 14:51:02 --> Model "User_model" initialized
INFO - 2025-05-14 14:51:02 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-14 14:51:02 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/artikel.php
INFO - 2025-05-14 14:51:02 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-14 14:51:02 --> Final output sent to browser
DEBUG - 2025-05-14 14:51:02 --> Total execution time: 0.1197
INFO - 2025-05-14 14:51:07 --> Config Class Initialized
INFO - 2025-05-14 14:51:07 --> Hooks Class Initialized
DEBUG - 2025-05-14 14:51:07 --> UTF-8 Support Enabled
INFO - 2025-05-14 14:51:07 --> Utf8 Class Initialized
INFO - 2025-05-14 14:51:07 --> URI Class Initialized
INFO - 2025-05-14 14:51:07 --> Router Class Initialized
INFO - 2025-05-14 14:51:07 --> Output Class Initialized
INFO - 2025-05-14 14:51:07 --> Security Class Initialized
DEBUG - 2025-05-14 14:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 14:51:07 --> Input Class Initialized
INFO - 2025-05-14 14:51:07 --> Language Class Initialized
INFO - 2025-05-14 14:51:07 --> Loader Class Initialized
INFO - 2025-05-14 14:51:07 --> Helper loaded: url_helper
INFO - 2025-05-14 14:51:07 --> Helper loaded: form_helper
INFO - 2025-05-14 14:51:07 --> Database Driver Class Initialized
DEBUG - 2025-05-14 14:51:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 14:51:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 14:51:07 --> Controller Class Initialized
INFO - 2025-05-14 14:51:07 --> Model "User_model" initialized
INFO - 2025-05-14 14:51:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-14 14:51:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-14 14:51:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-14 14:51:07 --> Final output sent to browser
DEBUG - 2025-05-14 14:51:07 --> Total execution time: 0.0983
INFO - 2025-05-14 14:52:16 --> Config Class Initialized
INFO - 2025-05-14 14:52:16 --> Hooks Class Initialized
DEBUG - 2025-05-14 14:52:16 --> UTF-8 Support Enabled
INFO - 2025-05-14 14:52:16 --> Utf8 Class Initialized
INFO - 2025-05-14 14:52:16 --> URI Class Initialized
INFO - 2025-05-14 14:52:16 --> Router Class Initialized
INFO - 2025-05-14 14:52:16 --> Output Class Initialized
INFO - 2025-05-14 14:52:16 --> Security Class Initialized
DEBUG - 2025-05-14 14:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 14:52:16 --> Input Class Initialized
INFO - 2025-05-14 14:52:16 --> Language Class Initialized
INFO - 2025-05-14 14:52:16 --> Loader Class Initialized
INFO - 2025-05-14 14:52:16 --> Helper loaded: url_helper
INFO - 2025-05-14 14:52:16 --> Helper loaded: form_helper
INFO - 2025-05-14 14:52:16 --> Database Driver Class Initialized
DEBUG - 2025-05-14 14:52:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 14:52:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 14:52:16 --> Controller Class Initialized
INFO - 2025-05-14 14:52:16 --> Model "User_model" initialized
INFO - 2025-05-14 14:52:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-14 14:52:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-14 14:52:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-14 14:52:16 --> Final output sent to browser
DEBUG - 2025-05-14 14:52:16 --> Total execution time: 0.1098
INFO - 2025-05-14 14:53:02 --> Config Class Initialized
INFO - 2025-05-14 14:53:02 --> Hooks Class Initialized
DEBUG - 2025-05-14 14:53:02 --> UTF-8 Support Enabled
INFO - 2025-05-14 14:53:02 --> Utf8 Class Initialized
INFO - 2025-05-14 14:53:02 --> URI Class Initialized
INFO - 2025-05-14 14:53:02 --> Router Class Initialized
INFO - 2025-05-14 14:53:02 --> Output Class Initialized
INFO - 2025-05-14 14:53:02 --> Security Class Initialized
DEBUG - 2025-05-14 14:53:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 14:53:02 --> Input Class Initialized
INFO - 2025-05-14 14:53:02 --> Language Class Initialized
INFO - 2025-05-14 14:53:02 --> Loader Class Initialized
INFO - 2025-05-14 14:53:02 --> Helper loaded: url_helper
INFO - 2025-05-14 14:53:02 --> Helper loaded: form_helper
INFO - 2025-05-14 14:53:02 --> Database Driver Class Initialized
DEBUG - 2025-05-14 14:53:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 14:53:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 14:53:02 --> Controller Class Initialized
INFO - 2025-05-14 14:53:02 --> Model "User_model" initialized
INFO - 2025-05-14 14:53:02 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-14 14:53:02 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-14 14:53:02 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-14 14:53:02 --> Final output sent to browser
DEBUG - 2025-05-14 14:53:02 --> Total execution time: 0.0883
INFO - 2025-05-14 14:53:04 --> Config Class Initialized
INFO - 2025-05-14 14:53:04 --> Hooks Class Initialized
DEBUG - 2025-05-14 14:53:04 --> UTF-8 Support Enabled
INFO - 2025-05-14 14:53:04 --> Utf8 Class Initialized
INFO - 2025-05-14 14:53:04 --> URI Class Initialized
INFO - 2025-05-14 14:53:04 --> Router Class Initialized
INFO - 2025-05-14 14:53:04 --> Output Class Initialized
INFO - 2025-05-14 14:53:04 --> Security Class Initialized
DEBUG - 2025-05-14 14:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 14:53:04 --> Input Class Initialized
INFO - 2025-05-14 14:53:04 --> Language Class Initialized
INFO - 2025-05-14 14:53:04 --> Loader Class Initialized
INFO - 2025-05-14 14:53:04 --> Helper loaded: url_helper
INFO - 2025-05-14 14:53:04 --> Helper loaded: form_helper
INFO - 2025-05-14 14:53:04 --> Database Driver Class Initialized
DEBUG - 2025-05-14 14:53:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 14:53:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 14:53:04 --> Controller Class Initialized
INFO - 2025-05-14 14:53:04 --> Model "User_model" initialized
INFO - 2025-05-14 14:53:04 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-14 14:53:04 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-14 14:53:04 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-14 14:53:04 --> Final output sent to browser
DEBUG - 2025-05-14 14:53:04 --> Total execution time: 0.0776
INFO - 2025-05-14 14:53:05 --> Config Class Initialized
INFO - 2025-05-14 14:53:05 --> Hooks Class Initialized
DEBUG - 2025-05-14 14:53:05 --> UTF-8 Support Enabled
INFO - 2025-05-14 14:53:05 --> Utf8 Class Initialized
INFO - 2025-05-14 14:53:05 --> URI Class Initialized
INFO - 2025-05-14 14:53:05 --> Router Class Initialized
INFO - 2025-05-14 14:53:05 --> Output Class Initialized
INFO - 2025-05-14 14:53:05 --> Security Class Initialized
DEBUG - 2025-05-14 14:53:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 14:53:05 --> Input Class Initialized
INFO - 2025-05-14 14:53:05 --> Language Class Initialized
INFO - 2025-05-14 14:53:05 --> Loader Class Initialized
INFO - 2025-05-14 14:53:05 --> Helper loaded: url_helper
INFO - 2025-05-14 14:53:05 --> Helper loaded: form_helper
INFO - 2025-05-14 14:53:05 --> Database Driver Class Initialized
DEBUG - 2025-05-14 14:53:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 14:53:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 14:53:05 --> Controller Class Initialized
INFO - 2025-05-14 14:53:05 --> Model "User_model" initialized
INFO - 2025-05-14 14:53:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-14 14:53:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-14 14:53:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-14 14:53:05 --> Final output sent to browser
DEBUG - 2025-05-14 14:53:05 --> Total execution time: 0.0863
INFO - 2025-05-14 14:53:06 --> Config Class Initialized
INFO - 2025-05-14 14:53:06 --> Hooks Class Initialized
DEBUG - 2025-05-14 14:53:06 --> UTF-8 Support Enabled
INFO - 2025-05-14 14:53:06 --> Utf8 Class Initialized
INFO - 2025-05-14 14:53:06 --> URI Class Initialized
INFO - 2025-05-14 14:53:06 --> Router Class Initialized
INFO - 2025-05-14 14:53:06 --> Output Class Initialized
INFO - 2025-05-14 14:53:06 --> Security Class Initialized
DEBUG - 2025-05-14 14:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 14:53:06 --> Input Class Initialized
INFO - 2025-05-14 14:53:06 --> Language Class Initialized
INFO - 2025-05-14 14:53:06 --> Loader Class Initialized
INFO - 2025-05-14 14:53:06 --> Helper loaded: url_helper
INFO - 2025-05-14 14:53:06 --> Helper loaded: form_helper
INFO - 2025-05-14 14:53:06 --> Database Driver Class Initialized
DEBUG - 2025-05-14 14:53:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 14:53:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 14:53:06 --> Controller Class Initialized
INFO - 2025-05-14 14:53:06 --> Model "User_model" initialized
INFO - 2025-05-14 14:53:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-14 14:53:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-14 14:53:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-14 14:53:06 --> Final output sent to browser
DEBUG - 2025-05-14 14:53:06 --> Total execution time: 0.0893
INFO - 2025-05-14 14:53:07 --> Config Class Initialized
INFO - 2025-05-14 14:53:07 --> Hooks Class Initialized
DEBUG - 2025-05-14 14:53:07 --> UTF-8 Support Enabled
INFO - 2025-05-14 14:53:07 --> Utf8 Class Initialized
INFO - 2025-05-14 14:53:07 --> URI Class Initialized
INFO - 2025-05-14 14:53:07 --> Router Class Initialized
INFO - 2025-05-14 14:53:07 --> Output Class Initialized
INFO - 2025-05-14 14:53:07 --> Security Class Initialized
DEBUG - 2025-05-14 14:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 14:53:07 --> Input Class Initialized
INFO - 2025-05-14 14:53:07 --> Language Class Initialized
INFO - 2025-05-14 14:53:07 --> Loader Class Initialized
INFO - 2025-05-14 14:53:07 --> Helper loaded: url_helper
INFO - 2025-05-14 14:53:07 --> Helper loaded: form_helper
INFO - 2025-05-14 14:53:07 --> Database Driver Class Initialized
DEBUG - 2025-05-14 14:53:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 14:53:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 14:53:07 --> Controller Class Initialized
INFO - 2025-05-14 14:53:07 --> Model "User_model" initialized
INFO - 2025-05-14 14:53:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-14 14:53:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-14 14:53:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-14 14:53:07 --> Final output sent to browser
DEBUG - 2025-05-14 14:53:07 --> Total execution time: 0.0991
INFO - 2025-05-14 14:55:35 --> Config Class Initialized
INFO - 2025-05-14 14:55:35 --> Hooks Class Initialized
DEBUG - 2025-05-14 14:55:35 --> UTF-8 Support Enabled
INFO - 2025-05-14 14:55:35 --> Utf8 Class Initialized
INFO - 2025-05-14 14:55:35 --> URI Class Initialized
INFO - 2025-05-14 14:55:35 --> Router Class Initialized
INFO - 2025-05-14 14:55:35 --> Output Class Initialized
INFO - 2025-05-14 14:55:35 --> Security Class Initialized
DEBUG - 2025-05-14 14:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 14:55:35 --> Input Class Initialized
INFO - 2025-05-14 14:55:35 --> Language Class Initialized
INFO - 2025-05-14 14:55:35 --> Loader Class Initialized
INFO - 2025-05-14 14:55:35 --> Helper loaded: url_helper
INFO - 2025-05-14 14:55:35 --> Helper loaded: form_helper
INFO - 2025-05-14 14:55:35 --> Database Driver Class Initialized
DEBUG - 2025-05-14 14:55:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 14:55:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 14:55:35 --> Controller Class Initialized
INFO - 2025-05-14 14:55:35 --> Model "User_model" initialized
INFO - 2025-05-14 14:55:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-14 14:55:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-14 14:55:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-14 14:55:35 --> Final output sent to browser
DEBUG - 2025-05-14 14:55:35 --> Total execution time: 0.0961
INFO - 2025-05-14 14:55:36 --> Config Class Initialized
INFO - 2025-05-14 14:55:36 --> Hooks Class Initialized
DEBUG - 2025-05-14 14:55:36 --> UTF-8 Support Enabled
INFO - 2025-05-14 14:55:36 --> Utf8 Class Initialized
INFO - 2025-05-14 14:55:36 --> URI Class Initialized
INFO - 2025-05-14 14:55:36 --> Router Class Initialized
INFO - 2025-05-14 14:55:36 --> Output Class Initialized
INFO - 2025-05-14 14:55:36 --> Security Class Initialized
DEBUG - 2025-05-14 14:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 14:55:36 --> Input Class Initialized
INFO - 2025-05-14 14:55:36 --> Language Class Initialized
INFO - 2025-05-14 14:55:36 --> Loader Class Initialized
INFO - 2025-05-14 14:55:36 --> Helper loaded: url_helper
INFO - 2025-05-14 14:55:36 --> Helper loaded: form_helper
INFO - 2025-05-14 14:55:36 --> Database Driver Class Initialized
DEBUG - 2025-05-14 14:55:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 14:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 14:55:36 --> Controller Class Initialized
INFO - 2025-05-14 14:55:36 --> Model "User_model" initialized
INFO - 2025-05-14 14:55:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-14 14:55:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-14 14:55:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-14 14:55:36 --> Final output sent to browser
DEBUG - 2025-05-14 14:55:36 --> Total execution time: 0.0929
INFO - 2025-05-14 14:55:37 --> Config Class Initialized
INFO - 2025-05-14 14:55:37 --> Hooks Class Initialized
DEBUG - 2025-05-14 14:55:37 --> UTF-8 Support Enabled
INFO - 2025-05-14 14:55:37 --> Utf8 Class Initialized
INFO - 2025-05-14 14:55:37 --> URI Class Initialized
INFO - 2025-05-14 14:55:37 --> Router Class Initialized
INFO - 2025-05-14 14:55:37 --> Output Class Initialized
INFO - 2025-05-14 14:55:37 --> Security Class Initialized
DEBUG - 2025-05-14 14:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 14:55:37 --> Input Class Initialized
INFO - 2025-05-14 14:55:37 --> Language Class Initialized
INFO - 2025-05-14 14:55:37 --> Loader Class Initialized
INFO - 2025-05-14 14:55:37 --> Helper loaded: url_helper
INFO - 2025-05-14 14:55:37 --> Helper loaded: form_helper
INFO - 2025-05-14 14:55:37 --> Database Driver Class Initialized
DEBUG - 2025-05-14 14:55:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 14:55:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 14:55:37 --> Controller Class Initialized
INFO - 2025-05-14 14:55:37 --> Model "User_model" initialized
INFO - 2025-05-14 14:55:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-14 14:55:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-14 14:55:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-14 14:55:37 --> Final output sent to browser
DEBUG - 2025-05-14 14:55:37 --> Total execution time: 0.0696
INFO - 2025-05-14 14:55:38 --> Config Class Initialized
INFO - 2025-05-14 14:55:38 --> Hooks Class Initialized
DEBUG - 2025-05-14 14:55:38 --> UTF-8 Support Enabled
INFO - 2025-05-14 14:55:38 --> Utf8 Class Initialized
INFO - 2025-05-14 14:55:38 --> URI Class Initialized
INFO - 2025-05-14 14:55:38 --> Router Class Initialized
INFO - 2025-05-14 14:55:38 --> Output Class Initialized
INFO - 2025-05-14 14:55:38 --> Security Class Initialized
DEBUG - 2025-05-14 14:55:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 14:55:38 --> Input Class Initialized
INFO - 2025-05-14 14:55:38 --> Language Class Initialized
INFO - 2025-05-14 14:55:38 --> Loader Class Initialized
INFO - 2025-05-14 14:55:38 --> Helper loaded: url_helper
INFO - 2025-05-14 14:55:38 --> Helper loaded: form_helper
INFO - 2025-05-14 14:55:38 --> Database Driver Class Initialized
DEBUG - 2025-05-14 14:55:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 14:55:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 14:55:38 --> Controller Class Initialized
INFO - 2025-05-14 14:55:38 --> Model "User_model" initialized
INFO - 2025-05-14 14:55:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-14 14:55:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-14 14:55:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-14 14:55:38 --> Final output sent to browser
DEBUG - 2025-05-14 14:55:38 --> Total execution time: 0.0763
INFO - 2025-05-14 14:56:02 --> Config Class Initialized
INFO - 2025-05-14 14:56:02 --> Hooks Class Initialized
DEBUG - 2025-05-14 14:56:02 --> UTF-8 Support Enabled
INFO - 2025-05-14 14:56:02 --> Utf8 Class Initialized
INFO - 2025-05-14 14:56:02 --> URI Class Initialized
INFO - 2025-05-14 14:56:02 --> Router Class Initialized
INFO - 2025-05-14 14:56:02 --> Output Class Initialized
INFO - 2025-05-14 14:56:02 --> Security Class Initialized
DEBUG - 2025-05-14 14:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 14:56:02 --> Input Class Initialized
INFO - 2025-05-14 14:56:02 --> Language Class Initialized
INFO - 2025-05-14 14:56:02 --> Loader Class Initialized
INFO - 2025-05-14 14:56:02 --> Helper loaded: url_helper
INFO - 2025-05-14 14:56:02 --> Helper loaded: form_helper
INFO - 2025-05-14 14:56:02 --> Database Driver Class Initialized
DEBUG - 2025-05-14 14:56:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 14:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 14:56:02 --> Controller Class Initialized
INFO - 2025-05-14 14:56:02 --> Model "User_model" initialized
INFO - 2025-05-14 14:56:02 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-14 14:56:02 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-14 14:56:02 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-14 14:56:02 --> Final output sent to browser
DEBUG - 2025-05-14 14:56:02 --> Total execution time: 0.0981
INFO - 2025-05-14 14:56:19 --> Config Class Initialized
INFO - 2025-05-14 14:56:19 --> Hooks Class Initialized
DEBUG - 2025-05-14 14:56:19 --> UTF-8 Support Enabled
INFO - 2025-05-14 14:56:19 --> Utf8 Class Initialized
INFO - 2025-05-14 14:56:19 --> URI Class Initialized
INFO - 2025-05-14 14:56:19 --> Router Class Initialized
INFO - 2025-05-14 14:56:19 --> Output Class Initialized
INFO - 2025-05-14 14:56:19 --> Security Class Initialized
DEBUG - 2025-05-14 14:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 14:56:19 --> Input Class Initialized
INFO - 2025-05-14 14:56:19 --> Language Class Initialized
INFO - 2025-05-14 14:56:19 --> Loader Class Initialized
INFO - 2025-05-14 14:56:19 --> Helper loaded: url_helper
INFO - 2025-05-14 14:56:19 --> Helper loaded: form_helper
INFO - 2025-05-14 14:56:19 --> Database Driver Class Initialized
DEBUG - 2025-05-14 14:56:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 14:56:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 14:56:19 --> Controller Class Initialized
INFO - 2025-05-14 14:56:19 --> Model "User_model" initialized
INFO - 2025-05-14 14:56:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-14 14:56:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-14 14:56:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-14 14:56:19 --> Final output sent to browser
DEBUG - 2025-05-14 14:56:19 --> Total execution time: 0.1026
INFO - 2025-05-14 15:00:16 --> Config Class Initialized
INFO - 2025-05-14 15:00:16 --> Hooks Class Initialized
DEBUG - 2025-05-14 15:00:16 --> UTF-8 Support Enabled
INFO - 2025-05-14 15:00:16 --> Utf8 Class Initialized
INFO - 2025-05-14 15:00:16 --> URI Class Initialized
INFO - 2025-05-14 15:00:16 --> Router Class Initialized
INFO - 2025-05-14 15:00:16 --> Output Class Initialized
INFO - 2025-05-14 15:00:16 --> Security Class Initialized
DEBUG - 2025-05-14 15:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 15:00:16 --> Input Class Initialized
INFO - 2025-05-14 15:00:16 --> Language Class Initialized
INFO - 2025-05-14 15:00:16 --> Loader Class Initialized
INFO - 2025-05-14 15:00:16 --> Helper loaded: url_helper
INFO - 2025-05-14 15:00:16 --> Helper loaded: form_helper
INFO - 2025-05-14 15:00:16 --> Database Driver Class Initialized
DEBUG - 2025-05-14 15:00:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 15:00:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 15:00:16 --> Controller Class Initialized
INFO - 2025-05-14 15:00:16 --> Model "User_model" initialized
INFO - 2025-05-14 15:00:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-14 15:00:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-14 15:00:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-14 15:00:16 --> Final output sent to browser
DEBUG - 2025-05-14 15:00:16 --> Total execution time: 0.0992
INFO - 2025-05-14 15:00:49 --> Config Class Initialized
INFO - 2025-05-14 15:00:49 --> Hooks Class Initialized
DEBUG - 2025-05-14 15:00:49 --> UTF-8 Support Enabled
INFO - 2025-05-14 15:00:49 --> Utf8 Class Initialized
INFO - 2025-05-14 15:00:49 --> URI Class Initialized
INFO - 2025-05-14 15:00:49 --> Router Class Initialized
INFO - 2025-05-14 15:00:49 --> Output Class Initialized
INFO - 2025-05-14 15:00:49 --> Security Class Initialized
DEBUG - 2025-05-14 15:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 15:00:49 --> Input Class Initialized
INFO - 2025-05-14 15:00:49 --> Language Class Initialized
INFO - 2025-05-14 15:00:49 --> Loader Class Initialized
INFO - 2025-05-14 15:00:49 --> Helper loaded: url_helper
INFO - 2025-05-14 15:00:49 --> Helper loaded: form_helper
INFO - 2025-05-14 15:00:49 --> Database Driver Class Initialized
DEBUG - 2025-05-14 15:00:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 15:00:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 15:00:49 --> Controller Class Initialized
INFO - 2025-05-14 15:00:49 --> Model "User_model" initialized
INFO - 2025-05-14 15:00:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-14 15:00:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-14 15:00:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-14 15:00:49 --> Final output sent to browser
DEBUG - 2025-05-14 15:00:49 --> Total execution time: 0.0843
INFO - 2025-05-14 15:02:08 --> Config Class Initialized
INFO - 2025-05-14 15:02:08 --> Hooks Class Initialized
DEBUG - 2025-05-14 15:02:08 --> UTF-8 Support Enabled
INFO - 2025-05-14 15:02:08 --> Utf8 Class Initialized
INFO - 2025-05-14 15:02:08 --> URI Class Initialized
INFO - 2025-05-14 15:02:08 --> Router Class Initialized
INFO - 2025-05-14 15:02:08 --> Output Class Initialized
INFO - 2025-05-14 15:02:08 --> Security Class Initialized
DEBUG - 2025-05-14 15:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 15:02:08 --> Input Class Initialized
INFO - 2025-05-14 15:02:08 --> Language Class Initialized
INFO - 2025-05-14 15:02:08 --> Loader Class Initialized
INFO - 2025-05-14 15:02:08 --> Helper loaded: url_helper
INFO - 2025-05-14 15:02:08 --> Helper loaded: form_helper
INFO - 2025-05-14 15:02:08 --> Database Driver Class Initialized
DEBUG - 2025-05-14 15:02:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 15:02:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 15:02:08 --> Controller Class Initialized
INFO - 2025-05-14 15:02:08 --> Model "User_model" initialized
INFO - 2025-05-14 15:02:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-14 15:02:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-14 15:02:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-14 15:02:08 --> Final output sent to browser
DEBUG - 2025-05-14 15:02:08 --> Total execution time: 0.1190
INFO - 2025-05-14 15:05:16 --> Config Class Initialized
INFO - 2025-05-14 15:05:16 --> Hooks Class Initialized
DEBUG - 2025-05-14 15:05:16 --> UTF-8 Support Enabled
INFO - 2025-05-14 15:05:16 --> Utf8 Class Initialized
INFO - 2025-05-14 15:05:16 --> URI Class Initialized
INFO - 2025-05-14 15:05:16 --> Router Class Initialized
INFO - 2025-05-14 15:05:16 --> Output Class Initialized
INFO - 2025-05-14 15:05:16 --> Security Class Initialized
DEBUG - 2025-05-14 15:05:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 15:05:16 --> Input Class Initialized
INFO - 2025-05-14 15:05:16 --> Language Class Initialized
INFO - 2025-05-14 15:05:16 --> Loader Class Initialized
INFO - 2025-05-14 15:05:16 --> Helper loaded: url_helper
INFO - 2025-05-14 15:05:16 --> Helper loaded: form_helper
INFO - 2025-05-14 15:05:16 --> Database Driver Class Initialized
DEBUG - 2025-05-14 15:05:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 15:05:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 15:05:16 --> Controller Class Initialized
INFO - 2025-05-14 15:05:16 --> Model "User_model" initialized
INFO - 2025-05-14 15:05:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-14 15:05:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-14 15:05:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-14 15:05:16 --> Final output sent to browser
DEBUG - 2025-05-14 15:05:16 --> Total execution time: 0.0805
INFO - 2025-05-14 15:05:35 --> Config Class Initialized
INFO - 2025-05-14 15:05:35 --> Hooks Class Initialized
DEBUG - 2025-05-14 15:05:35 --> UTF-8 Support Enabled
INFO - 2025-05-14 15:05:35 --> Utf8 Class Initialized
INFO - 2025-05-14 15:05:35 --> URI Class Initialized
INFO - 2025-05-14 15:05:35 --> Router Class Initialized
INFO - 2025-05-14 15:05:35 --> Output Class Initialized
INFO - 2025-05-14 15:05:35 --> Security Class Initialized
DEBUG - 2025-05-14 15:05:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 15:05:35 --> Input Class Initialized
INFO - 2025-05-14 15:05:35 --> Language Class Initialized
INFO - 2025-05-14 15:05:35 --> Loader Class Initialized
INFO - 2025-05-14 15:05:35 --> Helper loaded: url_helper
INFO - 2025-05-14 15:05:35 --> Helper loaded: form_helper
INFO - 2025-05-14 15:05:35 --> Database Driver Class Initialized
DEBUG - 2025-05-14 15:05:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 15:05:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 15:05:35 --> Controller Class Initialized
INFO - 2025-05-14 15:05:35 --> Model "User_model" initialized
INFO - 2025-05-14 15:05:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-14 15:05:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-14 15:05:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-14 15:05:35 --> Final output sent to browser
DEBUG - 2025-05-14 15:05:35 --> Total execution time: 0.1147
INFO - 2025-05-14 15:36:24 --> Config Class Initialized
INFO - 2025-05-14 15:36:24 --> Hooks Class Initialized
DEBUG - 2025-05-14 15:36:24 --> UTF-8 Support Enabled
INFO - 2025-05-14 15:36:24 --> Utf8 Class Initialized
INFO - 2025-05-14 15:36:24 --> URI Class Initialized
INFO - 2025-05-14 15:36:24 --> Router Class Initialized
INFO - 2025-05-14 15:36:24 --> Output Class Initialized
INFO - 2025-05-14 15:36:24 --> Security Class Initialized
DEBUG - 2025-05-14 15:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 15:36:24 --> Input Class Initialized
INFO - 2025-05-14 15:36:24 --> Language Class Initialized
INFO - 2025-05-14 15:36:24 --> Loader Class Initialized
INFO - 2025-05-14 15:36:24 --> Helper loaded: url_helper
INFO - 2025-05-14 15:36:24 --> Helper loaded: form_helper
INFO - 2025-05-14 15:36:24 --> Database Driver Class Initialized
DEBUG - 2025-05-14 15:36:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 15:36:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 15:36:24 --> Controller Class Initialized
INFO - 2025-05-14 15:36:24 --> Model "User_model" initialized
INFO - 2025-05-14 15:36:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-14 15:36:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-14 15:36:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-14 15:36:24 --> Final output sent to browser
DEBUG - 2025-05-14 15:36:24 --> Total execution time: 0.1312
INFO - 2025-05-14 15:38:13 --> Config Class Initialized
INFO - 2025-05-14 15:38:13 --> Hooks Class Initialized
DEBUG - 2025-05-14 15:38:13 --> UTF-8 Support Enabled
INFO - 2025-05-14 15:38:13 --> Utf8 Class Initialized
INFO - 2025-05-14 15:38:13 --> URI Class Initialized
INFO - 2025-05-14 15:38:13 --> Router Class Initialized
INFO - 2025-05-14 15:38:13 --> Output Class Initialized
INFO - 2025-05-14 15:38:13 --> Security Class Initialized
DEBUG - 2025-05-14 15:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 15:38:13 --> Input Class Initialized
INFO - 2025-05-14 15:38:13 --> Language Class Initialized
INFO - 2025-05-14 15:38:13 --> Loader Class Initialized
INFO - 2025-05-14 15:38:13 --> Helper loaded: url_helper
INFO - 2025-05-14 15:38:13 --> Helper loaded: form_helper
INFO - 2025-05-14 15:38:13 --> Database Driver Class Initialized
DEBUG - 2025-05-14 15:38:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 15:38:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 15:38:13 --> Controller Class Initialized
INFO - 2025-05-14 15:38:13 --> Model "User_model" initialized
INFO - 2025-05-14 15:38:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-14 15:38:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-14 15:38:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-14 15:38:13 --> Final output sent to browser
DEBUG - 2025-05-14 15:38:13 --> Total execution time: 0.1097
INFO - 2025-05-14 15:40:36 --> Config Class Initialized
INFO - 2025-05-14 15:40:36 --> Hooks Class Initialized
DEBUG - 2025-05-14 15:40:36 --> UTF-8 Support Enabled
INFO - 2025-05-14 15:40:36 --> Utf8 Class Initialized
INFO - 2025-05-14 15:40:36 --> URI Class Initialized
INFO - 2025-05-14 15:40:36 --> Router Class Initialized
INFO - 2025-05-14 15:40:36 --> Output Class Initialized
INFO - 2025-05-14 15:40:36 --> Security Class Initialized
DEBUG - 2025-05-14 15:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 15:40:36 --> Input Class Initialized
INFO - 2025-05-14 15:40:36 --> Language Class Initialized
INFO - 2025-05-14 15:40:36 --> Loader Class Initialized
INFO - 2025-05-14 15:40:36 --> Helper loaded: url_helper
INFO - 2025-05-14 15:40:36 --> Helper loaded: form_helper
INFO - 2025-05-14 15:40:36 --> Database Driver Class Initialized
DEBUG - 2025-05-14 15:40:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 15:40:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 15:40:36 --> Controller Class Initialized
INFO - 2025-05-14 15:40:36 --> Model "User_model" initialized
INFO - 2025-05-14 15:40:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-14 15:40:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-14 15:40:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-14 15:40:36 --> Final output sent to browser
DEBUG - 2025-05-14 15:40:36 --> Total execution time: 0.0872
INFO - 2025-05-14 15:41:32 --> Config Class Initialized
INFO - 2025-05-14 15:41:32 --> Hooks Class Initialized
DEBUG - 2025-05-14 15:41:32 --> UTF-8 Support Enabled
INFO - 2025-05-14 15:41:32 --> Utf8 Class Initialized
INFO - 2025-05-14 15:41:32 --> URI Class Initialized
INFO - 2025-05-14 15:41:32 --> Router Class Initialized
INFO - 2025-05-14 15:41:32 --> Output Class Initialized
INFO - 2025-05-14 15:41:32 --> Security Class Initialized
DEBUG - 2025-05-14 15:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 15:41:32 --> Input Class Initialized
INFO - 2025-05-14 15:41:32 --> Language Class Initialized
INFO - 2025-05-14 15:41:32 --> Loader Class Initialized
INFO - 2025-05-14 15:41:32 --> Helper loaded: url_helper
INFO - 2025-05-14 15:41:32 --> Helper loaded: form_helper
INFO - 2025-05-14 15:41:32 --> Database Driver Class Initialized
DEBUG - 2025-05-14 15:41:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 15:41:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 15:41:32 --> Controller Class Initialized
INFO - 2025-05-14 15:41:32 --> Model "User_model" initialized
INFO - 2025-05-14 15:41:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-14 15:41:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-14 15:41:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-14 15:41:32 --> Final output sent to browser
DEBUG - 2025-05-14 15:41:32 --> Total execution time: 0.1091
INFO - 2025-05-14 15:42:21 --> Config Class Initialized
INFO - 2025-05-14 15:42:21 --> Hooks Class Initialized
DEBUG - 2025-05-14 15:42:21 --> UTF-8 Support Enabled
INFO - 2025-05-14 15:42:21 --> Utf8 Class Initialized
INFO - 2025-05-14 15:42:21 --> URI Class Initialized
INFO - 2025-05-14 15:42:21 --> Router Class Initialized
INFO - 2025-05-14 15:42:21 --> Output Class Initialized
INFO - 2025-05-14 15:42:21 --> Security Class Initialized
DEBUG - 2025-05-14 15:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 15:42:21 --> Input Class Initialized
INFO - 2025-05-14 15:42:21 --> Language Class Initialized
INFO - 2025-05-14 15:42:21 --> Loader Class Initialized
INFO - 2025-05-14 15:42:21 --> Helper loaded: url_helper
INFO - 2025-05-14 15:42:21 --> Helper loaded: form_helper
INFO - 2025-05-14 15:42:21 --> Database Driver Class Initialized
DEBUG - 2025-05-14 15:42:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 15:42:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 15:42:21 --> Controller Class Initialized
INFO - 2025-05-14 15:42:21 --> Model "User_model" initialized
INFO - 2025-05-14 15:42:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-14 15:42:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-14 15:42:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-14 15:42:21 --> Final output sent to browser
DEBUG - 2025-05-14 15:42:21 --> Total execution time: 0.0942
INFO - 2025-05-14 15:44:36 --> Config Class Initialized
INFO - 2025-05-14 15:44:36 --> Hooks Class Initialized
DEBUG - 2025-05-14 15:44:36 --> UTF-8 Support Enabled
INFO - 2025-05-14 15:44:36 --> Utf8 Class Initialized
INFO - 2025-05-14 15:44:36 --> URI Class Initialized
INFO - 2025-05-14 15:44:36 --> Router Class Initialized
INFO - 2025-05-14 15:44:36 --> Output Class Initialized
INFO - 2025-05-14 15:44:36 --> Security Class Initialized
DEBUG - 2025-05-14 15:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 15:44:36 --> Input Class Initialized
INFO - 2025-05-14 15:44:36 --> Language Class Initialized
INFO - 2025-05-14 15:44:36 --> Loader Class Initialized
INFO - 2025-05-14 15:44:36 --> Helper loaded: url_helper
INFO - 2025-05-14 15:44:36 --> Helper loaded: form_helper
INFO - 2025-05-14 15:44:36 --> Database Driver Class Initialized
DEBUG - 2025-05-14 15:44:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 15:44:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 15:44:36 --> Controller Class Initialized
INFO - 2025-05-14 15:44:36 --> Model "User_model" initialized
INFO - 2025-05-14 15:44:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-14 15:44:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-14 15:44:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-14 15:44:36 --> Final output sent to browser
DEBUG - 2025-05-14 15:44:36 --> Total execution time: 0.1077
INFO - 2025-05-14 15:45:27 --> Config Class Initialized
INFO - 2025-05-14 15:45:27 --> Hooks Class Initialized
DEBUG - 2025-05-14 15:45:27 --> UTF-8 Support Enabled
INFO - 2025-05-14 15:45:27 --> Utf8 Class Initialized
INFO - 2025-05-14 15:45:27 --> URI Class Initialized
INFO - 2025-05-14 15:45:27 --> Router Class Initialized
INFO - 2025-05-14 15:45:27 --> Output Class Initialized
INFO - 2025-05-14 15:45:27 --> Security Class Initialized
DEBUG - 2025-05-14 15:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 15:45:27 --> Input Class Initialized
INFO - 2025-05-14 15:45:27 --> Language Class Initialized
INFO - 2025-05-14 15:45:27 --> Loader Class Initialized
INFO - 2025-05-14 15:45:27 --> Helper loaded: url_helper
INFO - 2025-05-14 15:45:27 --> Helper loaded: form_helper
INFO - 2025-05-14 15:45:27 --> Database Driver Class Initialized
DEBUG - 2025-05-14 15:45:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 15:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 15:45:27 --> Controller Class Initialized
INFO - 2025-05-14 15:45:27 --> Model "User_model" initialized
INFO - 2025-05-14 15:45:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-14 15:45:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-14 15:45:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-14 15:45:27 --> Final output sent to browser
DEBUG - 2025-05-14 15:45:27 --> Total execution time: 0.0830
INFO - 2025-05-14 15:46:35 --> Config Class Initialized
INFO - 2025-05-14 15:46:35 --> Hooks Class Initialized
DEBUG - 2025-05-14 15:46:35 --> UTF-8 Support Enabled
INFO - 2025-05-14 15:46:35 --> Utf8 Class Initialized
INFO - 2025-05-14 15:46:35 --> URI Class Initialized
INFO - 2025-05-14 15:46:35 --> Router Class Initialized
INFO - 2025-05-14 15:46:35 --> Output Class Initialized
INFO - 2025-05-14 15:46:35 --> Security Class Initialized
DEBUG - 2025-05-14 15:46:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 15:46:35 --> Input Class Initialized
INFO - 2025-05-14 15:46:35 --> Language Class Initialized
INFO - 2025-05-14 15:46:35 --> Loader Class Initialized
INFO - 2025-05-14 15:46:35 --> Helper loaded: url_helper
INFO - 2025-05-14 15:46:35 --> Helper loaded: form_helper
INFO - 2025-05-14 15:46:35 --> Database Driver Class Initialized
DEBUG - 2025-05-14 15:46:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 15:46:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 15:46:35 --> Controller Class Initialized
INFO - 2025-05-14 15:46:35 --> Model "User_model" initialized
INFO - 2025-05-14 15:46:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-14 15:46:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-14 15:46:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-14 15:46:35 --> Final output sent to browser
DEBUG - 2025-05-14 15:46:35 --> Total execution time: 0.1014
INFO - 2025-05-14 15:48:56 --> Config Class Initialized
INFO - 2025-05-14 15:48:56 --> Hooks Class Initialized
DEBUG - 2025-05-14 15:48:56 --> UTF-8 Support Enabled
INFO - 2025-05-14 15:48:56 --> Utf8 Class Initialized
INFO - 2025-05-14 15:48:56 --> URI Class Initialized
INFO - 2025-05-14 15:48:56 --> Router Class Initialized
INFO - 2025-05-14 15:48:56 --> Output Class Initialized
INFO - 2025-05-14 15:48:56 --> Security Class Initialized
DEBUG - 2025-05-14 15:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 15:48:56 --> Input Class Initialized
INFO - 2025-05-14 15:48:56 --> Language Class Initialized
INFO - 2025-05-14 15:48:56 --> Loader Class Initialized
INFO - 2025-05-14 15:48:56 --> Helper loaded: url_helper
INFO - 2025-05-14 15:48:56 --> Helper loaded: form_helper
INFO - 2025-05-14 15:48:56 --> Database Driver Class Initialized
DEBUG - 2025-05-14 15:48:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 15:48:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 15:48:56 --> Controller Class Initialized
INFO - 2025-05-14 15:48:56 --> Model "User_model" initialized
INFO - 2025-05-14 15:48:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-14 15:48:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-14 15:48:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-14 15:48:56 --> Final output sent to browser
DEBUG - 2025-05-14 15:48:56 --> Total execution time: 0.0992
INFO - 2025-05-14 15:50:14 --> Config Class Initialized
INFO - 2025-05-14 15:50:14 --> Hooks Class Initialized
DEBUG - 2025-05-14 15:50:14 --> UTF-8 Support Enabled
INFO - 2025-05-14 15:50:14 --> Utf8 Class Initialized
INFO - 2025-05-14 15:50:14 --> URI Class Initialized
INFO - 2025-05-14 15:50:14 --> Router Class Initialized
INFO - 2025-05-14 15:50:14 --> Output Class Initialized
INFO - 2025-05-14 15:50:14 --> Security Class Initialized
DEBUG - 2025-05-14 15:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 15:50:14 --> Input Class Initialized
INFO - 2025-05-14 15:50:14 --> Language Class Initialized
INFO - 2025-05-14 15:50:14 --> Loader Class Initialized
INFO - 2025-05-14 15:50:14 --> Helper loaded: url_helper
INFO - 2025-05-14 15:50:14 --> Helper loaded: form_helper
INFO - 2025-05-14 15:50:14 --> Database Driver Class Initialized
DEBUG - 2025-05-14 15:50:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 15:50:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 15:50:14 --> Controller Class Initialized
INFO - 2025-05-14 15:50:14 --> Model "User_model" initialized
INFO - 2025-05-14 15:50:14 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-14 15:50:14 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-14 15:50:14 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-14 15:50:14 --> Final output sent to browser
DEBUG - 2025-05-14 15:50:14 --> Total execution time: 0.0832
INFO - 2025-05-14 15:51:37 --> Config Class Initialized
INFO - 2025-05-14 15:51:37 --> Hooks Class Initialized
DEBUG - 2025-05-14 15:51:37 --> UTF-8 Support Enabled
INFO - 2025-05-14 15:51:37 --> Utf8 Class Initialized
INFO - 2025-05-14 15:51:37 --> URI Class Initialized
INFO - 2025-05-14 15:51:37 --> Router Class Initialized
INFO - 2025-05-14 15:51:37 --> Output Class Initialized
INFO - 2025-05-14 15:51:37 --> Security Class Initialized
DEBUG - 2025-05-14 15:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 15:51:37 --> Input Class Initialized
INFO - 2025-05-14 15:51:37 --> Language Class Initialized
INFO - 2025-05-14 15:51:37 --> Loader Class Initialized
INFO - 2025-05-14 15:51:37 --> Helper loaded: url_helper
INFO - 2025-05-14 15:51:37 --> Helper loaded: form_helper
INFO - 2025-05-14 15:51:37 --> Database Driver Class Initialized
DEBUG - 2025-05-14 15:51:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 15:51:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 15:51:37 --> Controller Class Initialized
INFO - 2025-05-14 15:51:37 --> Model "User_model" initialized
INFO - 2025-05-14 15:51:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-14 15:51:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/artikel.php
INFO - 2025-05-14 15:51:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-14 15:51:37 --> Final output sent to browser
DEBUG - 2025-05-14 15:51:37 --> Total execution time: 0.1106
INFO - 2025-05-14 15:51:40 --> Config Class Initialized
INFO - 2025-05-14 15:51:40 --> Hooks Class Initialized
DEBUG - 2025-05-14 15:51:40 --> UTF-8 Support Enabled
INFO - 2025-05-14 15:51:40 --> Utf8 Class Initialized
INFO - 2025-05-14 15:51:40 --> URI Class Initialized
INFO - 2025-05-14 15:51:40 --> Router Class Initialized
INFO - 2025-05-14 15:51:40 --> Output Class Initialized
INFO - 2025-05-14 15:51:40 --> Security Class Initialized
DEBUG - 2025-05-14 15:51:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 15:51:40 --> Input Class Initialized
INFO - 2025-05-14 15:51:40 --> Language Class Initialized
INFO - 2025-05-14 15:51:40 --> Loader Class Initialized
INFO - 2025-05-14 15:51:40 --> Helper loaded: url_helper
INFO - 2025-05-14 15:51:41 --> Helper loaded: form_helper
INFO - 2025-05-14 15:51:41 --> Database Driver Class Initialized
DEBUG - 2025-05-14 15:51:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 15:51:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 15:51:41 --> Controller Class Initialized
INFO - 2025-05-14 15:51:41 --> Model "User_model" initialized
INFO - 2025-05-14 15:51:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-14 15:51:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/artikel.php
INFO - 2025-05-14 15:51:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-14 15:51:41 --> Final output sent to browser
DEBUG - 2025-05-14 15:51:41 --> Total execution time: 0.0959
INFO - 2025-05-14 15:51:42 --> Config Class Initialized
INFO - 2025-05-14 15:51:42 --> Hooks Class Initialized
DEBUG - 2025-05-14 15:51:42 --> UTF-8 Support Enabled
INFO - 2025-05-14 15:51:42 --> Utf8 Class Initialized
INFO - 2025-05-14 15:51:42 --> URI Class Initialized
INFO - 2025-05-14 15:51:42 --> Router Class Initialized
INFO - 2025-05-14 15:51:42 --> Output Class Initialized
INFO - 2025-05-14 15:51:42 --> Security Class Initialized
DEBUG - 2025-05-14 15:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 15:51:42 --> Input Class Initialized
INFO - 2025-05-14 15:51:42 --> Language Class Initialized
INFO - 2025-05-14 15:51:42 --> Loader Class Initialized
INFO - 2025-05-14 15:51:42 --> Helper loaded: url_helper
INFO - 2025-05-14 15:51:42 --> Helper loaded: form_helper
INFO - 2025-05-14 15:51:42 --> Database Driver Class Initialized
DEBUG - 2025-05-14 15:51:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 15:51:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 15:51:42 --> Controller Class Initialized
INFO - 2025-05-14 15:51:42 --> Model "User_model" initialized
INFO - 2025-05-14 15:51:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-14 15:51:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-14 15:51:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-14 15:51:42 --> Final output sent to browser
DEBUG - 2025-05-14 15:51:42 --> Total execution time: 0.0934
INFO - 2025-05-14 15:51:47 --> Config Class Initialized
INFO - 2025-05-14 15:51:47 --> Hooks Class Initialized
DEBUG - 2025-05-14 15:51:47 --> UTF-8 Support Enabled
INFO - 2025-05-14 15:51:47 --> Utf8 Class Initialized
INFO - 2025-05-14 15:51:47 --> URI Class Initialized
INFO - 2025-05-14 15:51:47 --> Router Class Initialized
INFO - 2025-05-14 15:51:47 --> Output Class Initialized
INFO - 2025-05-14 15:51:47 --> Security Class Initialized
DEBUG - 2025-05-14 15:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 15:51:47 --> Input Class Initialized
INFO - 2025-05-14 15:51:47 --> Language Class Initialized
INFO - 2025-05-14 15:51:47 --> Loader Class Initialized
INFO - 2025-05-14 15:51:47 --> Helper loaded: url_helper
INFO - 2025-05-14 15:51:47 --> Helper loaded: form_helper
INFO - 2025-05-14 15:51:47 --> Database Driver Class Initialized
DEBUG - 2025-05-14 15:51:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 15:51:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 15:51:47 --> Controller Class Initialized
INFO - 2025-05-14 15:51:47 --> Model "User_model" initialized
INFO - 2025-05-14 15:51:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-14 15:51:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/artikel.php
INFO - 2025-05-14 15:51:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-14 15:51:47 --> Final output sent to browser
DEBUG - 2025-05-14 15:51:47 --> Total execution time: 0.1107
INFO - 2025-05-14 15:52:50 --> Config Class Initialized
INFO - 2025-05-14 15:52:50 --> Hooks Class Initialized
DEBUG - 2025-05-14 15:52:50 --> UTF-8 Support Enabled
INFO - 2025-05-14 15:52:50 --> Utf8 Class Initialized
INFO - 2025-05-14 15:52:50 --> URI Class Initialized
INFO - 2025-05-14 15:52:50 --> Router Class Initialized
INFO - 2025-05-14 15:52:50 --> Output Class Initialized
INFO - 2025-05-14 15:52:50 --> Security Class Initialized
DEBUG - 2025-05-14 15:52:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 15:52:50 --> Input Class Initialized
INFO - 2025-05-14 15:52:50 --> Language Class Initialized
INFO - 2025-05-14 15:52:50 --> Loader Class Initialized
INFO - 2025-05-14 15:52:50 --> Helper loaded: url_helper
INFO - 2025-05-14 15:52:50 --> Helper loaded: form_helper
INFO - 2025-05-14 15:52:50 --> Database Driver Class Initialized
DEBUG - 2025-05-14 15:52:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 15:52:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 15:52:50 --> Controller Class Initialized
INFO - 2025-05-14 15:52:50 --> Model "User_model" initialized
INFO - 2025-05-14 15:52:50 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-14 15:52:50 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/artikel.php
INFO - 2025-05-14 15:52:50 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-14 15:52:50 --> Final output sent to browser
DEBUG - 2025-05-14 15:52:50 --> Total execution time: 0.1220
INFO - 2025-05-14 15:55:06 --> Config Class Initialized
INFO - 2025-05-14 15:55:06 --> Hooks Class Initialized
DEBUG - 2025-05-14 15:55:06 --> UTF-8 Support Enabled
INFO - 2025-05-14 15:55:06 --> Utf8 Class Initialized
INFO - 2025-05-14 15:55:06 --> URI Class Initialized
INFO - 2025-05-14 15:55:06 --> Router Class Initialized
INFO - 2025-05-14 15:55:06 --> Output Class Initialized
INFO - 2025-05-14 15:55:06 --> Security Class Initialized
DEBUG - 2025-05-14 15:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 15:55:06 --> Input Class Initialized
INFO - 2025-05-14 15:55:06 --> Language Class Initialized
INFO - 2025-05-14 15:55:06 --> Loader Class Initialized
INFO - 2025-05-14 15:55:06 --> Helper loaded: url_helper
INFO - 2025-05-14 15:55:06 --> Helper loaded: form_helper
INFO - 2025-05-14 15:55:06 --> Database Driver Class Initialized
DEBUG - 2025-05-14 15:55:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 15:55:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 15:55:06 --> Controller Class Initialized
INFO - 2025-05-14 15:55:06 --> Model "User_model" initialized
INFO - 2025-05-14 15:55:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-14 15:55:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/artikel.php
INFO - 2025-05-14 15:55:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-14 15:55:06 --> Final output sent to browser
DEBUG - 2025-05-14 15:55:06 --> Total execution time: 0.0930
INFO - 2025-05-14 15:55:19 --> Config Class Initialized
INFO - 2025-05-14 15:55:19 --> Hooks Class Initialized
DEBUG - 2025-05-14 15:55:19 --> UTF-8 Support Enabled
INFO - 2025-05-14 15:55:19 --> Utf8 Class Initialized
INFO - 2025-05-14 15:55:19 --> URI Class Initialized
INFO - 2025-05-14 15:55:19 --> Router Class Initialized
INFO - 2025-05-14 15:55:19 --> Output Class Initialized
INFO - 2025-05-14 15:55:19 --> Security Class Initialized
DEBUG - 2025-05-14 15:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 15:55:19 --> Input Class Initialized
INFO - 2025-05-14 15:55:19 --> Language Class Initialized
INFO - 2025-05-14 15:55:19 --> Loader Class Initialized
INFO - 2025-05-14 15:55:19 --> Helper loaded: url_helper
INFO - 2025-05-14 15:55:19 --> Helper loaded: form_helper
INFO - 2025-05-14 15:55:19 --> Database Driver Class Initialized
DEBUG - 2025-05-14 15:55:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 15:55:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 15:55:19 --> Controller Class Initialized
INFO - 2025-05-14 15:55:19 --> Model "User_model" initialized
INFO - 2025-05-14 15:55:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-14 15:55:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-14 15:55:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-14 15:55:19 --> Final output sent to browser
DEBUG - 2025-05-14 15:55:19 --> Total execution time: 0.0930
INFO - 2025-05-14 15:55:22 --> Config Class Initialized
INFO - 2025-05-14 15:55:22 --> Hooks Class Initialized
DEBUG - 2025-05-14 15:55:22 --> UTF-8 Support Enabled
INFO - 2025-05-14 15:55:22 --> Utf8 Class Initialized
INFO - 2025-05-14 15:55:22 --> URI Class Initialized
INFO - 2025-05-14 15:55:22 --> Router Class Initialized
INFO - 2025-05-14 15:55:22 --> Output Class Initialized
INFO - 2025-05-14 15:55:22 --> Security Class Initialized
DEBUG - 2025-05-14 15:55:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 15:55:22 --> Input Class Initialized
INFO - 2025-05-14 15:55:22 --> Language Class Initialized
INFO - 2025-05-14 15:55:22 --> Loader Class Initialized
INFO - 2025-05-14 15:55:22 --> Helper loaded: url_helper
INFO - 2025-05-14 15:55:22 --> Helper loaded: form_helper
INFO - 2025-05-14 15:55:22 --> Database Driver Class Initialized
DEBUG - 2025-05-14 15:55:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 15:55:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 15:55:22 --> Controller Class Initialized
INFO - 2025-05-14 15:55:22 --> Model "User_model" initialized
INFO - 2025-05-14 15:55:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-14 15:55:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/artikel.php
INFO - 2025-05-14 15:55:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-14 15:55:22 --> Final output sent to browser
DEBUG - 2025-05-14 15:55:22 --> Total execution time: 0.0891
INFO - 2025-05-14 15:55:25 --> Config Class Initialized
INFO - 2025-05-14 15:55:25 --> Hooks Class Initialized
DEBUG - 2025-05-14 15:55:25 --> UTF-8 Support Enabled
INFO - 2025-05-14 15:55:25 --> Utf8 Class Initialized
INFO - 2025-05-14 15:55:25 --> URI Class Initialized
INFO - 2025-05-14 15:55:25 --> Router Class Initialized
INFO - 2025-05-14 15:55:25 --> Output Class Initialized
INFO - 2025-05-14 15:55:25 --> Security Class Initialized
DEBUG - 2025-05-14 15:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 15:55:25 --> Input Class Initialized
INFO - 2025-05-14 15:55:25 --> Language Class Initialized
INFO - 2025-05-14 15:55:25 --> Loader Class Initialized
INFO - 2025-05-14 15:55:25 --> Helper loaded: url_helper
INFO - 2025-05-14 15:55:25 --> Helper loaded: form_helper
INFO - 2025-05-14 15:55:25 --> Database Driver Class Initialized
DEBUG - 2025-05-14 15:55:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 15:55:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 15:55:25 --> Controller Class Initialized
INFO - 2025-05-14 15:55:25 --> Model "User_model" initialized
INFO - 2025-05-14 15:55:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-14 15:55:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-14 15:55:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-14 15:55:25 --> Final output sent to browser
DEBUG - 2025-05-14 15:55:25 --> Total execution time: 0.0827
INFO - 2025-05-14 15:56:37 --> Config Class Initialized
INFO - 2025-05-14 15:56:37 --> Hooks Class Initialized
DEBUG - 2025-05-14 15:56:37 --> UTF-8 Support Enabled
INFO - 2025-05-14 15:56:37 --> Utf8 Class Initialized
INFO - 2025-05-14 15:56:37 --> URI Class Initialized
INFO - 2025-05-14 15:56:37 --> Router Class Initialized
INFO - 2025-05-14 15:56:37 --> Output Class Initialized
INFO - 2025-05-14 15:56:37 --> Security Class Initialized
DEBUG - 2025-05-14 15:56:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 15:56:37 --> Input Class Initialized
INFO - 2025-05-14 15:56:37 --> Language Class Initialized
INFO - 2025-05-14 15:56:37 --> Loader Class Initialized
INFO - 2025-05-14 15:56:37 --> Helper loaded: url_helper
INFO - 2025-05-14 15:56:37 --> Helper loaded: form_helper
INFO - 2025-05-14 15:56:37 --> Database Driver Class Initialized
DEBUG - 2025-05-14 15:56:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 15:56:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 15:56:37 --> Controller Class Initialized
INFO - 2025-05-14 15:56:37 --> Model "User_model" initialized
INFO - 2025-05-14 15:56:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-14 15:56:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/artikel.php
INFO - 2025-05-14 15:56:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-14 15:56:37 --> Final output sent to browser
DEBUG - 2025-05-14 15:56:37 --> Total execution time: 0.0921
INFO - 2025-05-14 15:56:38 --> Config Class Initialized
INFO - 2025-05-14 15:56:38 --> Hooks Class Initialized
DEBUG - 2025-05-14 15:56:38 --> UTF-8 Support Enabled
INFO - 2025-05-14 15:56:38 --> Utf8 Class Initialized
INFO - 2025-05-14 15:56:38 --> URI Class Initialized
INFO - 2025-05-14 15:56:38 --> Router Class Initialized
INFO - 2025-05-14 15:56:38 --> Output Class Initialized
INFO - 2025-05-14 15:56:38 --> Security Class Initialized
DEBUG - 2025-05-14 15:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 15:56:38 --> Input Class Initialized
INFO - 2025-05-14 15:56:38 --> Language Class Initialized
INFO - 2025-05-14 15:56:38 --> Loader Class Initialized
INFO - 2025-05-14 15:56:38 --> Helper loaded: url_helper
INFO - 2025-05-14 15:56:38 --> Helper loaded: form_helper
INFO - 2025-05-14 15:56:38 --> Database Driver Class Initialized
DEBUG - 2025-05-14 15:56:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 15:56:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 15:56:38 --> Controller Class Initialized
INFO - 2025-05-14 15:56:38 --> Model "User_model" initialized
INFO - 2025-05-14 15:56:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-14 15:56:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-14 15:56:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-14 15:56:39 --> Final output sent to browser
DEBUG - 2025-05-14 15:56:39 --> Total execution time: 0.0786
INFO - 2025-05-14 15:57:47 --> Config Class Initialized
INFO - 2025-05-14 15:57:47 --> Hooks Class Initialized
DEBUG - 2025-05-14 15:57:47 --> UTF-8 Support Enabled
INFO - 2025-05-14 15:57:47 --> Utf8 Class Initialized
INFO - 2025-05-14 15:57:47 --> URI Class Initialized
INFO - 2025-05-14 15:57:47 --> Router Class Initialized
INFO - 2025-05-14 15:57:47 --> Output Class Initialized
INFO - 2025-05-14 15:57:47 --> Security Class Initialized
DEBUG - 2025-05-14 15:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 15:57:47 --> Input Class Initialized
INFO - 2025-05-14 15:57:47 --> Language Class Initialized
INFO - 2025-05-14 15:57:47 --> Loader Class Initialized
INFO - 2025-05-14 15:57:47 --> Helper loaded: url_helper
INFO - 2025-05-14 15:57:47 --> Helper loaded: form_helper
INFO - 2025-05-14 15:57:47 --> Database Driver Class Initialized
DEBUG - 2025-05-14 15:57:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 15:57:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 15:57:47 --> Controller Class Initialized
INFO - 2025-05-14 15:57:47 --> Model "User_model" initialized
INFO - 2025-05-14 15:57:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-14 15:57:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-14 15:57:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-14 15:57:47 --> Final output sent to browser
DEBUG - 2025-05-14 15:57:47 --> Total execution time: 0.0966
INFO - 2025-05-14 15:57:53 --> Config Class Initialized
INFO - 2025-05-14 15:57:53 --> Hooks Class Initialized
DEBUG - 2025-05-14 15:57:53 --> UTF-8 Support Enabled
INFO - 2025-05-14 15:57:53 --> Utf8 Class Initialized
INFO - 2025-05-14 15:57:53 --> URI Class Initialized
INFO - 2025-05-14 15:57:53 --> Router Class Initialized
INFO - 2025-05-14 15:57:53 --> Output Class Initialized
INFO - 2025-05-14 15:57:53 --> Security Class Initialized
DEBUG - 2025-05-14 15:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 15:57:53 --> Input Class Initialized
INFO - 2025-05-14 15:57:53 --> Language Class Initialized
INFO - 2025-05-14 15:57:53 --> Loader Class Initialized
INFO - 2025-05-14 15:57:53 --> Helper loaded: url_helper
INFO - 2025-05-14 15:57:53 --> Helper loaded: form_helper
INFO - 2025-05-14 15:57:53 --> Database Driver Class Initialized
DEBUG - 2025-05-14 15:57:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 15:57:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 15:57:53 --> Controller Class Initialized
INFO - 2025-05-14 15:57:53 --> Model "User_model" initialized
INFO - 2025-05-14 15:57:53 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-14 15:57:53 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-14 15:57:53 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-14 15:57:53 --> Final output sent to browser
DEBUG - 2025-05-14 15:57:53 --> Total execution time: 0.1271
INFO - 2025-05-14 15:57:55 --> Config Class Initialized
INFO - 2025-05-14 15:57:55 --> Hooks Class Initialized
DEBUG - 2025-05-14 15:57:55 --> UTF-8 Support Enabled
INFO - 2025-05-14 15:57:55 --> Utf8 Class Initialized
INFO - 2025-05-14 15:57:55 --> URI Class Initialized
INFO - 2025-05-14 15:57:55 --> Router Class Initialized
INFO - 2025-05-14 15:57:55 --> Output Class Initialized
INFO - 2025-05-14 15:57:55 --> Security Class Initialized
DEBUG - 2025-05-14 15:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 15:57:55 --> Input Class Initialized
INFO - 2025-05-14 15:57:55 --> Language Class Initialized
INFO - 2025-05-14 15:57:55 --> Loader Class Initialized
INFO - 2025-05-14 15:57:55 --> Helper loaded: url_helper
INFO - 2025-05-14 15:57:55 --> Helper loaded: form_helper
INFO - 2025-05-14 15:57:55 --> Database Driver Class Initialized
DEBUG - 2025-05-14 15:57:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 15:57:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 15:57:55 --> Controller Class Initialized
INFO - 2025-05-14 15:57:55 --> Model "User_model" initialized
INFO - 2025-05-14 15:57:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-14 15:57:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/artikel.php
INFO - 2025-05-14 15:57:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-14 15:57:55 --> Final output sent to browser
DEBUG - 2025-05-14 15:57:55 --> Total execution time: 0.1012
INFO - 2025-05-14 15:57:56 --> Config Class Initialized
INFO - 2025-05-14 15:57:56 --> Hooks Class Initialized
DEBUG - 2025-05-14 15:57:57 --> UTF-8 Support Enabled
INFO - 2025-05-14 15:57:57 --> Utf8 Class Initialized
INFO - 2025-05-14 15:57:57 --> URI Class Initialized
INFO - 2025-05-14 15:57:57 --> Router Class Initialized
INFO - 2025-05-14 15:57:57 --> Output Class Initialized
INFO - 2025-05-14 15:57:57 --> Security Class Initialized
DEBUG - 2025-05-14 15:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 15:57:57 --> Input Class Initialized
INFO - 2025-05-14 15:57:57 --> Language Class Initialized
INFO - 2025-05-14 15:57:57 --> Loader Class Initialized
INFO - 2025-05-14 15:57:57 --> Helper loaded: url_helper
INFO - 2025-05-14 15:57:57 --> Helper loaded: form_helper
INFO - 2025-05-14 15:57:57 --> Database Driver Class Initialized
DEBUG - 2025-05-14 15:57:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 15:57:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 15:57:57 --> Controller Class Initialized
INFO - 2025-05-14 15:57:57 --> Model "User_model" initialized
INFO - 2025-05-14 15:57:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-14 15:57:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-14 15:57:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-14 15:57:57 --> Final output sent to browser
DEBUG - 2025-05-14 15:57:57 --> Total execution time: 0.0692
INFO - 2025-05-14 15:57:59 --> Config Class Initialized
INFO - 2025-05-14 15:57:59 --> Hooks Class Initialized
DEBUG - 2025-05-14 15:57:59 --> UTF-8 Support Enabled
INFO - 2025-05-14 15:57:59 --> Utf8 Class Initialized
INFO - 2025-05-14 15:57:59 --> URI Class Initialized
INFO - 2025-05-14 15:57:59 --> Router Class Initialized
INFO - 2025-05-14 15:57:59 --> Output Class Initialized
INFO - 2025-05-14 15:57:59 --> Security Class Initialized
DEBUG - 2025-05-14 15:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 15:57:59 --> Input Class Initialized
INFO - 2025-05-14 15:57:59 --> Language Class Initialized
INFO - 2025-05-14 15:57:59 --> Loader Class Initialized
INFO - 2025-05-14 15:57:59 --> Helper loaded: url_helper
INFO - 2025-05-14 15:57:59 --> Helper loaded: form_helper
INFO - 2025-05-14 15:57:59 --> Database Driver Class Initialized
DEBUG - 2025-05-14 15:57:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 15:57:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 15:57:59 --> Controller Class Initialized
INFO - 2025-05-14 15:57:59 --> Model "User_model" initialized
INFO - 2025-05-14 15:57:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-14 15:57:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/artikel.php
INFO - 2025-05-14 15:57:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-14 15:57:59 --> Final output sent to browser
DEBUG - 2025-05-14 15:57:59 --> Total execution time: 0.0909
INFO - 2025-05-14 15:58:15 --> Config Class Initialized
INFO - 2025-05-14 15:58:15 --> Hooks Class Initialized
DEBUG - 2025-05-14 15:58:15 --> UTF-8 Support Enabled
INFO - 2025-05-14 15:58:15 --> Utf8 Class Initialized
INFO - 2025-05-14 15:58:15 --> URI Class Initialized
INFO - 2025-05-14 15:58:15 --> Router Class Initialized
INFO - 2025-05-14 15:58:15 --> Output Class Initialized
INFO - 2025-05-14 15:58:15 --> Security Class Initialized
DEBUG - 2025-05-14 15:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 15:58:15 --> Input Class Initialized
INFO - 2025-05-14 15:58:15 --> Language Class Initialized
INFO - 2025-05-14 15:58:15 --> Loader Class Initialized
INFO - 2025-05-14 15:58:15 --> Helper loaded: url_helper
INFO - 2025-05-14 15:58:15 --> Helper loaded: form_helper
INFO - 2025-05-14 15:58:15 --> Database Driver Class Initialized
DEBUG - 2025-05-14 15:58:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 15:58:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 15:58:15 --> Controller Class Initialized
INFO - 2025-05-14 15:58:15 --> Model "User_model" initialized
INFO - 2025-05-14 15:58:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-14 15:58:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/artikel.php
INFO - 2025-05-14 15:58:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-14 15:58:15 --> Final output sent to browser
DEBUG - 2025-05-14 15:58:15 --> Total execution time: 0.0870
INFO - 2025-05-14 15:58:18 --> Config Class Initialized
INFO - 2025-05-14 15:58:18 --> Hooks Class Initialized
DEBUG - 2025-05-14 15:58:18 --> UTF-8 Support Enabled
INFO - 2025-05-14 15:58:18 --> Utf8 Class Initialized
INFO - 2025-05-14 15:58:18 --> URI Class Initialized
INFO - 2025-05-14 15:58:18 --> Router Class Initialized
INFO - 2025-05-14 15:58:18 --> Output Class Initialized
INFO - 2025-05-14 15:58:18 --> Security Class Initialized
DEBUG - 2025-05-14 15:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 15:58:18 --> Input Class Initialized
INFO - 2025-05-14 15:58:18 --> Language Class Initialized
INFO - 2025-05-14 15:58:18 --> Loader Class Initialized
INFO - 2025-05-14 15:58:18 --> Helper loaded: url_helper
INFO - 2025-05-14 15:58:18 --> Helper loaded: form_helper
INFO - 2025-05-14 15:58:18 --> Database Driver Class Initialized
DEBUG - 2025-05-14 15:58:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 15:58:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 15:58:18 --> Controller Class Initialized
INFO - 2025-05-14 15:58:18 --> Model "User_model" initialized
INFO - 2025-05-14 15:58:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-14 15:58:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-14 15:58:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-14 15:58:18 --> Final output sent to browser
DEBUG - 2025-05-14 15:58:18 --> Total execution time: 0.0796
INFO - 2025-05-14 15:58:19 --> Config Class Initialized
INFO - 2025-05-14 15:58:19 --> Hooks Class Initialized
DEBUG - 2025-05-14 15:58:19 --> UTF-8 Support Enabled
INFO - 2025-05-14 15:58:19 --> Utf8 Class Initialized
INFO - 2025-05-14 15:58:19 --> URI Class Initialized
INFO - 2025-05-14 15:58:19 --> Router Class Initialized
INFO - 2025-05-14 15:58:19 --> Output Class Initialized
INFO - 2025-05-14 15:58:19 --> Security Class Initialized
DEBUG - 2025-05-14 15:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 15:58:19 --> Input Class Initialized
INFO - 2025-05-14 15:58:19 --> Language Class Initialized
INFO - 2025-05-14 15:58:19 --> Loader Class Initialized
INFO - 2025-05-14 15:58:20 --> Helper loaded: url_helper
INFO - 2025-05-14 15:58:20 --> Helper loaded: form_helper
INFO - 2025-05-14 15:58:20 --> Database Driver Class Initialized
DEBUG - 2025-05-14 15:58:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 15:58:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 15:58:20 --> Controller Class Initialized
INFO - 2025-05-14 15:58:20 --> Model "User_model" initialized
INFO - 2025-05-14 15:58:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-14 15:58:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/artikel.php
INFO - 2025-05-14 15:58:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-14 15:58:20 --> Final output sent to browser
DEBUG - 2025-05-14 15:58:20 --> Total execution time: 0.1070
INFO - 2025-05-14 15:58:21 --> Config Class Initialized
INFO - 2025-05-14 15:58:21 --> Hooks Class Initialized
DEBUG - 2025-05-14 15:58:21 --> UTF-8 Support Enabled
INFO - 2025-05-14 15:58:21 --> Utf8 Class Initialized
INFO - 2025-05-14 15:58:21 --> URI Class Initialized
INFO - 2025-05-14 15:58:21 --> Router Class Initialized
INFO - 2025-05-14 15:58:21 --> Output Class Initialized
INFO - 2025-05-14 15:58:21 --> Security Class Initialized
DEBUG - 2025-05-14 15:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 15:58:21 --> Input Class Initialized
INFO - 2025-05-14 15:58:21 --> Language Class Initialized
INFO - 2025-05-14 15:58:21 --> Loader Class Initialized
INFO - 2025-05-14 15:58:21 --> Helper loaded: url_helper
INFO - 2025-05-14 15:58:21 --> Helper loaded: form_helper
INFO - 2025-05-14 15:58:21 --> Database Driver Class Initialized
DEBUG - 2025-05-14 15:58:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 15:58:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 15:58:21 --> Controller Class Initialized
INFO - 2025-05-14 15:58:21 --> Model "User_model" initialized
INFO - 2025-05-14 15:58:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-14 15:58:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-14 15:58:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-14 15:58:21 --> Final output sent to browser
DEBUG - 2025-05-14 15:58:21 --> Total execution time: 0.0926
INFO - 2025-05-14 15:59:40 --> Config Class Initialized
INFO - 2025-05-14 15:59:40 --> Hooks Class Initialized
DEBUG - 2025-05-14 15:59:40 --> UTF-8 Support Enabled
INFO - 2025-05-14 15:59:40 --> Utf8 Class Initialized
INFO - 2025-05-14 15:59:40 --> URI Class Initialized
INFO - 2025-05-14 15:59:40 --> Router Class Initialized
INFO - 2025-05-14 15:59:40 --> Output Class Initialized
INFO - 2025-05-14 15:59:40 --> Security Class Initialized
DEBUG - 2025-05-14 15:59:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 15:59:40 --> Input Class Initialized
INFO - 2025-05-14 15:59:40 --> Language Class Initialized
INFO - 2025-05-14 15:59:40 --> Loader Class Initialized
INFO - 2025-05-14 15:59:40 --> Helper loaded: url_helper
INFO - 2025-05-14 15:59:40 --> Helper loaded: form_helper
INFO - 2025-05-14 15:59:40 --> Database Driver Class Initialized
DEBUG - 2025-05-14 15:59:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 15:59:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 15:59:40 --> Controller Class Initialized
INFO - 2025-05-14 15:59:40 --> Model "User_model" initialized
INFO - 2025-05-14 15:59:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-14 15:59:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-14 15:59:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-14 15:59:40 --> Final output sent to browser
DEBUG - 2025-05-14 15:59:40 --> Total execution time: 0.1091
INFO - 2025-05-14 15:59:43 --> Config Class Initialized
INFO - 2025-05-14 15:59:43 --> Hooks Class Initialized
DEBUG - 2025-05-14 15:59:43 --> UTF-8 Support Enabled
INFO - 2025-05-14 15:59:43 --> Utf8 Class Initialized
INFO - 2025-05-14 15:59:43 --> URI Class Initialized
INFO - 2025-05-14 15:59:43 --> Router Class Initialized
INFO - 2025-05-14 15:59:43 --> Output Class Initialized
INFO - 2025-05-14 15:59:43 --> Security Class Initialized
DEBUG - 2025-05-14 15:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 15:59:43 --> Input Class Initialized
INFO - 2025-05-14 15:59:43 --> Language Class Initialized
INFO - 2025-05-14 15:59:43 --> Loader Class Initialized
INFO - 2025-05-14 15:59:43 --> Helper loaded: url_helper
INFO - 2025-05-14 15:59:43 --> Helper loaded: form_helper
INFO - 2025-05-14 15:59:43 --> Database Driver Class Initialized
DEBUG - 2025-05-14 15:59:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 15:59:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 15:59:43 --> Controller Class Initialized
INFO - 2025-05-14 15:59:43 --> Model "User_model" initialized
INFO - 2025-05-14 15:59:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-14 15:59:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-14 15:59:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-14 15:59:43 --> Final output sent to browser
DEBUG - 2025-05-14 15:59:43 --> Total execution time: 0.1066
INFO - 2025-05-14 15:59:44 --> Config Class Initialized
INFO - 2025-05-14 15:59:44 --> Hooks Class Initialized
DEBUG - 2025-05-14 15:59:44 --> UTF-8 Support Enabled
INFO - 2025-05-14 15:59:44 --> Utf8 Class Initialized
INFO - 2025-05-14 15:59:44 --> URI Class Initialized
INFO - 2025-05-14 15:59:44 --> Router Class Initialized
INFO - 2025-05-14 15:59:44 --> Output Class Initialized
INFO - 2025-05-14 15:59:44 --> Security Class Initialized
DEBUG - 2025-05-14 15:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 15:59:44 --> Input Class Initialized
INFO - 2025-05-14 15:59:44 --> Language Class Initialized
INFO - 2025-05-14 15:59:44 --> Loader Class Initialized
INFO - 2025-05-14 15:59:44 --> Helper loaded: url_helper
INFO - 2025-05-14 15:59:44 --> Helper loaded: form_helper
INFO - 2025-05-14 15:59:44 --> Database Driver Class Initialized
DEBUG - 2025-05-14 15:59:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 15:59:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 15:59:44 --> Controller Class Initialized
INFO - 2025-05-14 15:59:44 --> Model "User_model" initialized
INFO - 2025-05-14 15:59:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-14 15:59:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/artikel.php
INFO - 2025-05-14 15:59:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-14 15:59:44 --> Final output sent to browser
DEBUG - 2025-05-14 15:59:44 --> Total execution time: 0.0847
INFO - 2025-05-14 15:59:46 --> Config Class Initialized
INFO - 2025-05-14 15:59:46 --> Hooks Class Initialized
DEBUG - 2025-05-14 15:59:46 --> UTF-8 Support Enabled
INFO - 2025-05-14 15:59:46 --> Utf8 Class Initialized
INFO - 2025-05-14 15:59:46 --> URI Class Initialized
INFO - 2025-05-14 15:59:46 --> Router Class Initialized
INFO - 2025-05-14 15:59:46 --> Output Class Initialized
INFO - 2025-05-14 15:59:46 --> Security Class Initialized
DEBUG - 2025-05-14 15:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 15:59:46 --> Input Class Initialized
INFO - 2025-05-14 15:59:46 --> Language Class Initialized
INFO - 2025-05-14 15:59:46 --> Loader Class Initialized
INFO - 2025-05-14 15:59:46 --> Helper loaded: url_helper
INFO - 2025-05-14 15:59:46 --> Helper loaded: form_helper
INFO - 2025-05-14 15:59:46 --> Database Driver Class Initialized
DEBUG - 2025-05-14 15:59:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 15:59:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 15:59:46 --> Controller Class Initialized
INFO - 2025-05-14 15:59:46 --> Model "User_model" initialized
INFO - 2025-05-14 15:59:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-14 15:59:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-14 15:59:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-14 15:59:46 --> Final output sent to browser
DEBUG - 2025-05-14 15:59:46 --> Total execution time: 0.0798
INFO - 2025-05-14 16:00:14 --> Config Class Initialized
INFO - 2025-05-14 16:00:14 --> Hooks Class Initialized
DEBUG - 2025-05-14 16:00:14 --> UTF-8 Support Enabled
INFO - 2025-05-14 16:00:14 --> Utf8 Class Initialized
INFO - 2025-05-14 16:00:14 --> URI Class Initialized
INFO - 2025-05-14 16:00:14 --> Router Class Initialized
INFO - 2025-05-14 16:00:14 --> Output Class Initialized
INFO - 2025-05-14 16:00:14 --> Security Class Initialized
DEBUG - 2025-05-14 16:00:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 16:00:14 --> Input Class Initialized
INFO - 2025-05-14 16:00:14 --> Language Class Initialized
INFO - 2025-05-14 16:00:14 --> Loader Class Initialized
INFO - 2025-05-14 16:00:14 --> Helper loaded: url_helper
INFO - 2025-05-14 16:00:14 --> Helper loaded: form_helper
INFO - 2025-05-14 16:00:14 --> Database Driver Class Initialized
DEBUG - 2025-05-14 16:00:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 16:00:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 16:00:14 --> Controller Class Initialized
INFO - 2025-05-14 16:00:14 --> Model "User_model" initialized
INFO - 2025-05-14 16:00:14 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-14 16:00:14 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-14 16:00:14 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-14 16:00:14 --> Final output sent to browser
DEBUG - 2025-05-14 16:00:14 --> Total execution time: 0.0982
INFO - 2025-05-14 16:00:18 --> Config Class Initialized
INFO - 2025-05-14 16:00:18 --> Hooks Class Initialized
DEBUG - 2025-05-14 16:00:18 --> UTF-8 Support Enabled
INFO - 2025-05-14 16:00:18 --> Utf8 Class Initialized
INFO - 2025-05-14 16:00:18 --> URI Class Initialized
INFO - 2025-05-14 16:00:18 --> Router Class Initialized
INFO - 2025-05-14 16:00:18 --> Output Class Initialized
INFO - 2025-05-14 16:00:18 --> Security Class Initialized
DEBUG - 2025-05-14 16:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 16:00:18 --> Input Class Initialized
INFO - 2025-05-14 16:00:18 --> Language Class Initialized
INFO - 2025-05-14 16:00:18 --> Loader Class Initialized
INFO - 2025-05-14 16:00:18 --> Helper loaded: url_helper
INFO - 2025-05-14 16:00:18 --> Helper loaded: form_helper
INFO - 2025-05-14 16:00:18 --> Database Driver Class Initialized
DEBUG - 2025-05-14 16:00:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 16:00:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 16:00:18 --> Controller Class Initialized
INFO - 2025-05-14 16:00:18 --> Model "User_model" initialized
INFO - 2025-05-14 16:00:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-14 16:00:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/artikel.php
INFO - 2025-05-14 16:00:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-14 16:00:18 --> Final output sent to browser
DEBUG - 2025-05-14 16:00:18 --> Total execution time: 0.0904
INFO - 2025-05-14 16:00:22 --> Config Class Initialized
INFO - 2025-05-14 16:00:22 --> Hooks Class Initialized
DEBUG - 2025-05-14 16:00:22 --> UTF-8 Support Enabled
INFO - 2025-05-14 16:00:22 --> Utf8 Class Initialized
INFO - 2025-05-14 16:00:22 --> URI Class Initialized
INFO - 2025-05-14 16:00:22 --> Router Class Initialized
INFO - 2025-05-14 16:00:22 --> Output Class Initialized
INFO - 2025-05-14 16:00:22 --> Security Class Initialized
DEBUG - 2025-05-14 16:00:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 16:00:22 --> Input Class Initialized
INFO - 2025-05-14 16:00:22 --> Language Class Initialized
INFO - 2025-05-14 16:00:22 --> Loader Class Initialized
INFO - 2025-05-14 16:00:22 --> Helper loaded: url_helper
INFO - 2025-05-14 16:00:22 --> Helper loaded: form_helper
INFO - 2025-05-14 16:00:22 --> Database Driver Class Initialized
DEBUG - 2025-05-14 16:00:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 16:00:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 16:00:22 --> Controller Class Initialized
INFO - 2025-05-14 16:00:22 --> Model "User_model" initialized
INFO - 2025-05-14 16:00:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-14 16:00:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-14 16:00:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-14 16:00:22 --> Final output sent to browser
DEBUG - 2025-05-14 16:00:22 --> Total execution time: 0.1149
INFO - 2025-05-14 16:00:36 --> Config Class Initialized
INFO - 2025-05-14 16:00:36 --> Hooks Class Initialized
DEBUG - 2025-05-14 16:00:36 --> UTF-8 Support Enabled
INFO - 2025-05-14 16:00:36 --> Utf8 Class Initialized
INFO - 2025-05-14 16:00:36 --> URI Class Initialized
INFO - 2025-05-14 16:00:36 --> Router Class Initialized
INFO - 2025-05-14 16:00:36 --> Output Class Initialized
INFO - 2025-05-14 16:00:36 --> Security Class Initialized
DEBUG - 2025-05-14 16:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 16:00:36 --> Input Class Initialized
INFO - 2025-05-14 16:00:36 --> Language Class Initialized
INFO - 2025-05-14 16:00:36 --> Loader Class Initialized
INFO - 2025-05-14 16:00:36 --> Helper loaded: url_helper
INFO - 2025-05-14 16:00:36 --> Helper loaded: form_helper
INFO - 2025-05-14 16:00:36 --> Database Driver Class Initialized
DEBUG - 2025-05-14 16:00:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 16:00:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 16:00:36 --> Controller Class Initialized
INFO - 2025-05-14 16:00:36 --> Model "User_model" initialized
INFO - 2025-05-14 16:00:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-14 16:00:36 --> Final output sent to browser
DEBUG - 2025-05-14 16:00:36 --> Total execution time: 0.1136
INFO - 2025-05-14 16:00:44 --> Config Class Initialized
INFO - 2025-05-14 16:00:44 --> Hooks Class Initialized
DEBUG - 2025-05-14 16:00:44 --> UTF-8 Support Enabled
INFO - 2025-05-14 16:00:44 --> Utf8 Class Initialized
INFO - 2025-05-14 16:00:44 --> URI Class Initialized
INFO - 2025-05-14 16:00:44 --> Router Class Initialized
INFO - 2025-05-14 16:00:44 --> Output Class Initialized
INFO - 2025-05-14 16:00:44 --> Security Class Initialized
DEBUG - 2025-05-14 16:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 16:00:44 --> Input Class Initialized
INFO - 2025-05-14 16:00:44 --> Language Class Initialized
INFO - 2025-05-14 16:00:44 --> Loader Class Initialized
INFO - 2025-05-14 16:00:44 --> Helper loaded: url_helper
INFO - 2025-05-14 16:00:44 --> Helper loaded: form_helper
INFO - 2025-05-14 16:00:44 --> Database Driver Class Initialized
DEBUG - 2025-05-14 16:00:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 16:00:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 16:00:44 --> Controller Class Initialized
INFO - 2025-05-14 16:00:44 --> Model "User_model" initialized
INFO - 2025-05-14 16:00:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-14 16:00:45 --> Final output sent to browser
DEBUG - 2025-05-14 16:00:45 --> Total execution time: 0.2030
INFO - 2025-05-14 16:00:54 --> Config Class Initialized
INFO - 2025-05-14 16:00:54 --> Hooks Class Initialized
DEBUG - 2025-05-14 16:00:54 --> UTF-8 Support Enabled
INFO - 2025-05-14 16:00:54 --> Utf8 Class Initialized
INFO - 2025-05-14 16:00:54 --> URI Class Initialized
INFO - 2025-05-14 16:00:54 --> Router Class Initialized
INFO - 2025-05-14 16:00:54 --> Output Class Initialized
INFO - 2025-05-14 16:00:54 --> Security Class Initialized
DEBUG - 2025-05-14 16:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 16:00:54 --> Input Class Initialized
INFO - 2025-05-14 16:00:54 --> Language Class Initialized
INFO - 2025-05-14 16:00:54 --> Loader Class Initialized
INFO - 2025-05-14 16:00:54 --> Helper loaded: url_helper
INFO - 2025-05-14 16:00:54 --> Helper loaded: form_helper
INFO - 2025-05-14 16:00:54 --> Database Driver Class Initialized
DEBUG - 2025-05-14 16:00:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 16:00:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 16:00:54 --> Controller Class Initialized
INFO - 2025-05-14 16:00:54 --> Model "User_model" initialized
INFO - 2025-05-14 16:00:54 --> Config Class Initialized
INFO - 2025-05-14 16:00:54 --> Hooks Class Initialized
DEBUG - 2025-05-14 16:00:54 --> UTF-8 Support Enabled
INFO - 2025-05-14 16:00:54 --> Utf8 Class Initialized
INFO - 2025-05-14 16:00:54 --> URI Class Initialized
INFO - 2025-05-14 16:00:54 --> Router Class Initialized
INFO - 2025-05-14 16:00:54 --> Output Class Initialized
INFO - 2025-05-14 16:00:54 --> Security Class Initialized
DEBUG - 2025-05-14 16:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 16:00:54 --> Input Class Initialized
INFO - 2025-05-14 16:00:54 --> Language Class Initialized
INFO - 2025-05-14 16:00:54 --> Loader Class Initialized
INFO - 2025-05-14 16:00:54 --> Helper loaded: url_helper
INFO - 2025-05-14 16:00:54 --> Helper loaded: form_helper
INFO - 2025-05-14 16:00:54 --> Database Driver Class Initialized
DEBUG - 2025-05-14 16:00:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 16:00:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 16:00:54 --> Controller Class Initialized
INFO - 2025-05-14 16:00:54 --> Model "User_model" initialized
INFO - 2025-05-14 16:00:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-14 16:00:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-14 16:00:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-14 16:00:54 --> Final output sent to browser
DEBUG - 2025-05-14 16:00:54 --> Total execution time: 0.0838
INFO - 2025-05-14 16:00:58 --> Config Class Initialized
INFO - 2025-05-14 16:00:58 --> Hooks Class Initialized
DEBUG - 2025-05-14 16:00:58 --> UTF-8 Support Enabled
INFO - 2025-05-14 16:00:58 --> Utf8 Class Initialized
INFO - 2025-05-14 16:00:58 --> URI Class Initialized
INFO - 2025-05-14 16:00:58 --> Router Class Initialized
INFO - 2025-05-14 16:00:58 --> Output Class Initialized
INFO - 2025-05-14 16:00:58 --> Security Class Initialized
DEBUG - 2025-05-14 16:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 16:00:58 --> Input Class Initialized
INFO - 2025-05-14 16:00:58 --> Language Class Initialized
INFO - 2025-05-14 16:00:58 --> Loader Class Initialized
INFO - 2025-05-14 16:00:58 --> Helper loaded: url_helper
INFO - 2025-05-14 16:00:58 --> Helper loaded: form_helper
INFO - 2025-05-14 16:00:58 --> Database Driver Class Initialized
DEBUG - 2025-05-14 16:00:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 16:00:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 16:00:58 --> Controller Class Initialized
INFO - 2025-05-14 16:00:58 --> Model "User_model" initialized
INFO - 2025-05-14 16:00:58 --> Model "Workout_model" initialized
INFO - 2025-05-14 16:00:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-14 16:00:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-14 16:00:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-14 16:00:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-14 16:00:58 --> Final output sent to browser
DEBUG - 2025-05-14 16:00:58 --> Total execution time: 0.2153
INFO - 2025-05-14 16:02:23 --> Config Class Initialized
INFO - 2025-05-14 16:02:23 --> Hooks Class Initialized
DEBUG - 2025-05-14 16:02:23 --> UTF-8 Support Enabled
INFO - 2025-05-14 16:02:23 --> Utf8 Class Initialized
INFO - 2025-05-14 16:02:23 --> URI Class Initialized
INFO - 2025-05-14 16:02:23 --> Router Class Initialized
INFO - 2025-05-14 16:02:23 --> Output Class Initialized
INFO - 2025-05-14 16:02:23 --> Security Class Initialized
DEBUG - 2025-05-14 16:02:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 16:02:23 --> Input Class Initialized
INFO - 2025-05-14 16:02:23 --> Language Class Initialized
INFO - 2025-05-14 16:02:23 --> Loader Class Initialized
INFO - 2025-05-14 16:02:23 --> Helper loaded: url_helper
INFO - 2025-05-14 16:02:23 --> Helper loaded: form_helper
INFO - 2025-05-14 16:02:23 --> Database Driver Class Initialized
DEBUG - 2025-05-14 16:02:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 16:02:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 16:02:23 --> Controller Class Initialized
INFO - 2025-05-14 16:02:23 --> Model "User_model" initialized
INFO - 2025-05-14 16:02:23 --> Model "Workout_model" initialized
INFO - 2025-05-14 16:02:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-14 16:02:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-14 16:02:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-14 16:02:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-14 16:02:23 --> Final output sent to browser
DEBUG - 2025-05-14 16:02:23 --> Total execution time: 0.0917
INFO - 2025-05-14 16:03:24 --> Config Class Initialized
INFO - 2025-05-14 16:03:24 --> Hooks Class Initialized
DEBUG - 2025-05-14 16:03:24 --> UTF-8 Support Enabled
INFO - 2025-05-14 16:03:24 --> Utf8 Class Initialized
INFO - 2025-05-14 16:03:24 --> URI Class Initialized
INFO - 2025-05-14 16:03:24 --> Router Class Initialized
INFO - 2025-05-14 16:03:24 --> Output Class Initialized
INFO - 2025-05-14 16:03:24 --> Security Class Initialized
DEBUG - 2025-05-14 16:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 16:03:24 --> Input Class Initialized
INFO - 2025-05-14 16:03:24 --> Language Class Initialized
INFO - 2025-05-14 16:03:24 --> Loader Class Initialized
INFO - 2025-05-14 16:03:24 --> Helper loaded: url_helper
INFO - 2025-05-14 16:03:24 --> Helper loaded: form_helper
INFO - 2025-05-14 16:03:24 --> Database Driver Class Initialized
DEBUG - 2025-05-14 16:03:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 16:03:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 16:03:24 --> Controller Class Initialized
INFO - 2025-05-14 16:03:24 --> Model "User_model" initialized
INFO - 2025-05-14 16:03:24 --> Model "Workout_model" initialized
INFO - 2025-05-14 16:03:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-14 16:03:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-14 16:03:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-14 16:03:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-14 16:03:24 --> Final output sent to browser
DEBUG - 2025-05-14 16:03:24 --> Total execution time: 0.1053
INFO - 2025-05-14 16:04:54 --> Config Class Initialized
INFO - 2025-05-14 16:04:54 --> Hooks Class Initialized
DEBUG - 2025-05-14 16:04:54 --> UTF-8 Support Enabled
INFO - 2025-05-14 16:04:54 --> Utf8 Class Initialized
INFO - 2025-05-14 16:04:54 --> URI Class Initialized
INFO - 2025-05-14 16:04:54 --> Router Class Initialized
INFO - 2025-05-14 16:04:54 --> Output Class Initialized
INFO - 2025-05-14 16:04:54 --> Security Class Initialized
DEBUG - 2025-05-14 16:04:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 16:04:54 --> Input Class Initialized
INFO - 2025-05-14 16:04:54 --> Language Class Initialized
INFO - 2025-05-14 16:04:54 --> Loader Class Initialized
INFO - 2025-05-14 16:04:54 --> Helper loaded: url_helper
INFO - 2025-05-14 16:04:54 --> Helper loaded: form_helper
INFO - 2025-05-14 16:04:54 --> Database Driver Class Initialized
DEBUG - 2025-05-14 16:04:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 16:04:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 16:04:54 --> Controller Class Initialized
INFO - 2025-05-14 16:04:54 --> Model "User_model" initialized
INFO - 2025-05-14 16:04:54 --> Model "Workout_model" initialized
INFO - 2025-05-14 16:04:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-14 16:04:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-14 16:04:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-14 16:04:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-14 16:04:54 --> Final output sent to browser
DEBUG - 2025-05-14 16:04:54 --> Total execution time: 0.0838
INFO - 2025-05-14 16:06:21 --> Config Class Initialized
INFO - 2025-05-14 16:06:21 --> Hooks Class Initialized
DEBUG - 2025-05-14 16:06:21 --> UTF-8 Support Enabled
INFO - 2025-05-14 16:06:21 --> Utf8 Class Initialized
INFO - 2025-05-14 16:06:21 --> URI Class Initialized
INFO - 2025-05-14 16:06:21 --> Router Class Initialized
INFO - 2025-05-14 16:06:21 --> Output Class Initialized
INFO - 2025-05-14 16:06:21 --> Security Class Initialized
DEBUG - 2025-05-14 16:06:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 16:06:21 --> Input Class Initialized
INFO - 2025-05-14 16:06:21 --> Language Class Initialized
INFO - 2025-05-14 16:06:21 --> Loader Class Initialized
INFO - 2025-05-14 16:06:21 --> Helper loaded: url_helper
INFO - 2025-05-14 16:06:21 --> Helper loaded: form_helper
INFO - 2025-05-14 16:06:21 --> Database Driver Class Initialized
DEBUG - 2025-05-14 16:06:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 16:06:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 16:06:21 --> Controller Class Initialized
INFO - 2025-05-14 16:06:21 --> Model "User_model" initialized
INFO - 2025-05-14 16:06:21 --> Model "Workout_model" initialized
INFO - 2025-05-14 16:06:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-14 16:06:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-14 16:06:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-14 16:06:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-14 16:06:21 --> Final output sent to browser
DEBUG - 2025-05-14 16:06:21 --> Total execution time: 0.1045
INFO - 2025-05-14 16:07:49 --> Config Class Initialized
INFO - 2025-05-14 16:07:49 --> Hooks Class Initialized
DEBUG - 2025-05-14 16:07:49 --> UTF-8 Support Enabled
INFO - 2025-05-14 16:07:49 --> Utf8 Class Initialized
INFO - 2025-05-14 16:07:49 --> URI Class Initialized
INFO - 2025-05-14 16:07:49 --> Router Class Initialized
INFO - 2025-05-14 16:07:49 --> Output Class Initialized
INFO - 2025-05-14 16:07:49 --> Security Class Initialized
DEBUG - 2025-05-14 16:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 16:07:49 --> Input Class Initialized
INFO - 2025-05-14 16:07:49 --> Language Class Initialized
INFO - 2025-05-14 16:07:49 --> Loader Class Initialized
INFO - 2025-05-14 16:07:49 --> Helper loaded: url_helper
INFO - 2025-05-14 16:07:49 --> Helper loaded: form_helper
INFO - 2025-05-14 16:07:49 --> Database Driver Class Initialized
DEBUG - 2025-05-14 16:07:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 16:07:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 16:07:49 --> Controller Class Initialized
INFO - 2025-05-14 16:07:49 --> Model "User_model" initialized
INFO - 2025-05-14 16:07:49 --> Model "Workout_model" initialized
INFO - 2025-05-14 16:07:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-14 16:07:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-14 16:07:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-14 16:07:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-14 16:07:49 --> Final output sent to browser
DEBUG - 2025-05-14 16:07:49 --> Total execution time: 0.1111
INFO - 2025-05-14 16:08:22 --> Config Class Initialized
INFO - 2025-05-14 16:08:22 --> Hooks Class Initialized
DEBUG - 2025-05-14 16:08:22 --> UTF-8 Support Enabled
INFO - 2025-05-14 16:08:22 --> Utf8 Class Initialized
INFO - 2025-05-14 16:08:22 --> URI Class Initialized
INFO - 2025-05-14 16:08:22 --> Router Class Initialized
INFO - 2025-05-14 16:08:22 --> Output Class Initialized
INFO - 2025-05-14 16:08:22 --> Security Class Initialized
DEBUG - 2025-05-14 16:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 16:08:22 --> Input Class Initialized
INFO - 2025-05-14 16:08:22 --> Language Class Initialized
INFO - 2025-05-14 16:08:22 --> Loader Class Initialized
INFO - 2025-05-14 16:08:22 --> Helper loaded: url_helper
INFO - 2025-05-14 16:08:22 --> Helper loaded: form_helper
INFO - 2025-05-14 16:08:22 --> Database Driver Class Initialized
DEBUG - 2025-05-14 16:08:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 16:08:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 16:08:22 --> Controller Class Initialized
INFO - 2025-05-14 16:08:22 --> Model "User_model" initialized
INFO - 2025-05-14 16:08:22 --> Model "Workout_model" initialized
INFO - 2025-05-14 16:08:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-14 16:08:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-14 16:08:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-14 16:08:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-14 16:08:22 --> Final output sent to browser
DEBUG - 2025-05-14 16:08:22 --> Total execution time: 0.0804
INFO - 2025-05-14 16:09:16 --> Config Class Initialized
INFO - 2025-05-14 16:09:16 --> Hooks Class Initialized
DEBUG - 2025-05-14 16:09:16 --> UTF-8 Support Enabled
INFO - 2025-05-14 16:09:16 --> Utf8 Class Initialized
INFO - 2025-05-14 16:09:16 --> URI Class Initialized
INFO - 2025-05-14 16:09:16 --> Router Class Initialized
INFO - 2025-05-14 16:09:16 --> Output Class Initialized
INFO - 2025-05-14 16:09:16 --> Security Class Initialized
DEBUG - 2025-05-14 16:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 16:09:16 --> Input Class Initialized
INFO - 2025-05-14 16:09:16 --> Language Class Initialized
INFO - 2025-05-14 16:09:16 --> Loader Class Initialized
INFO - 2025-05-14 16:09:16 --> Helper loaded: url_helper
INFO - 2025-05-14 16:09:16 --> Helper loaded: form_helper
INFO - 2025-05-14 16:09:16 --> Database Driver Class Initialized
DEBUG - 2025-05-14 16:09:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 16:09:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 16:09:16 --> Controller Class Initialized
INFO - 2025-05-14 16:09:16 --> Model "User_model" initialized
INFO - 2025-05-14 16:09:16 --> Model "Workout_model" initialized
INFO - 2025-05-14 16:09:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-14 16:09:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-14 16:09:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-14 16:09:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-14 16:09:16 --> Final output sent to browser
DEBUG - 2025-05-14 16:09:16 --> Total execution time: 0.0862
INFO - 2025-05-14 16:09:48 --> Config Class Initialized
INFO - 2025-05-14 16:09:48 --> Hooks Class Initialized
DEBUG - 2025-05-14 16:09:48 --> UTF-8 Support Enabled
INFO - 2025-05-14 16:09:48 --> Utf8 Class Initialized
INFO - 2025-05-14 16:09:48 --> URI Class Initialized
INFO - 2025-05-14 16:09:48 --> Router Class Initialized
INFO - 2025-05-14 16:09:48 --> Output Class Initialized
INFO - 2025-05-14 16:09:48 --> Security Class Initialized
DEBUG - 2025-05-14 16:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 16:09:48 --> Input Class Initialized
INFO - 2025-05-14 16:09:48 --> Language Class Initialized
INFO - 2025-05-14 16:09:48 --> Loader Class Initialized
INFO - 2025-05-14 16:09:48 --> Helper loaded: url_helper
INFO - 2025-05-14 16:09:48 --> Helper loaded: form_helper
INFO - 2025-05-14 16:09:48 --> Database Driver Class Initialized
DEBUG - 2025-05-14 16:09:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 16:09:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 16:09:48 --> Controller Class Initialized
INFO - 2025-05-14 16:09:48 --> Model "User_model" initialized
INFO - 2025-05-14 16:09:48 --> Model "Workout_model" initialized
INFO - 2025-05-14 16:09:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-14 16:09:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-14 16:09:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-14 16:09:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-14 16:09:48 --> Final output sent to browser
DEBUG - 2025-05-14 16:09:48 --> Total execution time: 0.0814
INFO - 2025-05-14 16:10:15 --> Config Class Initialized
INFO - 2025-05-14 16:10:15 --> Hooks Class Initialized
DEBUG - 2025-05-14 16:10:15 --> UTF-8 Support Enabled
INFO - 2025-05-14 16:10:15 --> Utf8 Class Initialized
INFO - 2025-05-14 16:10:15 --> URI Class Initialized
INFO - 2025-05-14 16:10:15 --> Router Class Initialized
INFO - 2025-05-14 16:10:15 --> Output Class Initialized
INFO - 2025-05-14 16:10:15 --> Security Class Initialized
DEBUG - 2025-05-14 16:10:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 16:10:15 --> Input Class Initialized
INFO - 2025-05-14 16:10:15 --> Language Class Initialized
INFO - 2025-05-14 16:10:15 --> Loader Class Initialized
INFO - 2025-05-14 16:10:15 --> Helper loaded: url_helper
INFO - 2025-05-14 16:10:15 --> Helper loaded: form_helper
INFO - 2025-05-14 16:10:15 --> Database Driver Class Initialized
DEBUG - 2025-05-14 16:10:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 16:10:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 16:10:15 --> Controller Class Initialized
INFO - 2025-05-14 16:10:15 --> Model "User_model" initialized
INFO - 2025-05-14 16:10:15 --> Model "Workout_model" initialized
INFO - 2025-05-14 16:10:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-14 16:10:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-14 16:10:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-14 16:10:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-14 16:10:15 --> Final output sent to browser
DEBUG - 2025-05-14 16:10:15 --> Total execution time: 0.1048
INFO - 2025-05-14 16:10:27 --> Config Class Initialized
INFO - 2025-05-14 16:10:27 --> Hooks Class Initialized
DEBUG - 2025-05-14 16:10:27 --> UTF-8 Support Enabled
INFO - 2025-05-14 16:10:27 --> Utf8 Class Initialized
INFO - 2025-05-14 16:10:27 --> URI Class Initialized
INFO - 2025-05-14 16:10:27 --> Router Class Initialized
INFO - 2025-05-14 16:10:27 --> Output Class Initialized
INFO - 2025-05-14 16:10:27 --> Security Class Initialized
DEBUG - 2025-05-14 16:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-14 16:10:27 --> Input Class Initialized
INFO - 2025-05-14 16:10:27 --> Language Class Initialized
INFO - 2025-05-14 16:10:27 --> Loader Class Initialized
INFO - 2025-05-14 16:10:27 --> Helper loaded: url_helper
INFO - 2025-05-14 16:10:27 --> Helper loaded: form_helper
INFO - 2025-05-14 16:10:27 --> Database Driver Class Initialized
DEBUG - 2025-05-14 16:10:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-14 16:10:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-14 16:10:27 --> Controller Class Initialized
INFO - 2025-05-14 16:10:27 --> Model "User_model" initialized
INFO - 2025-05-14 16:10:27 --> Model "Workout_model" initialized
INFO - 2025-05-14 16:10:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-14 16:10:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-14 16:10:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-14 16:10:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-14 16:10:27 --> Final output sent to browser
DEBUG - 2025-05-14 16:10:27 --> Total execution time: 0.0825
