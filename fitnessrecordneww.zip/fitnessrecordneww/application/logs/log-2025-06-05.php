<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-06-05 07:40:26 --> Config Class Initialized
INFO - 2025-06-05 07:40:26 --> Hooks Class Initialized
DEBUG - 2025-06-05 07:40:26 --> UTF-8 Support Enabled
INFO - 2025-06-05 07:40:26 --> Utf8 Class Initialized
INFO - 2025-06-05 07:40:26 --> URI Class Initialized
DEBUG - 2025-06-05 07:40:27 --> No URI present. Default controller set.
INFO - 2025-06-05 07:40:27 --> Router Class Initialized
INFO - 2025-06-05 07:40:27 --> Output Class Initialized
INFO - 2025-06-05 07:40:27 --> Security Class Initialized
DEBUG - 2025-06-05 07:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-05 07:40:27 --> Input Class Initialized
INFO - 2025-06-05 07:40:27 --> Language Class Initialized
INFO - 2025-06-05 07:40:27 --> Loader Class Initialized
INFO - 2025-06-05 07:40:27 --> Helper loaded: url_helper
INFO - 2025-06-05 07:40:27 --> Helper loaded: form_helper
INFO - 2025-06-05 07:40:28 --> Database Driver Class Initialized
DEBUG - 2025-06-05 07:40:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-05 07:40:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-05 07:40:28 --> Controller Class Initialized
INFO - 2025-06-05 07:40:28 --> Model "User_model" initialized
INFO - 2025-06-05 07:40:28 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-06-05 07:40:28 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/home.php
INFO - 2025-06-05 07:40:28 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-06-05 07:40:28 --> Final output sent to browser
DEBUG - 2025-06-05 07:40:28 --> Total execution time: 2.0201
