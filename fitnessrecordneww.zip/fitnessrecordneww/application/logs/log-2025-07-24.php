<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-07-24 09:07:50 --> Config Class Initialized
INFO - 2025-07-24 09:07:50 --> Hooks Class Initialized
DEBUG - 2025-07-24 09:07:50 --> UTF-8 Support Enabled
INFO - 2025-07-24 09:07:50 --> Utf8 Class Initialized
INFO - 2025-07-24 09:07:50 --> URI Class Initialized
INFO - 2025-07-24 09:07:50 --> Router Class Initialized
INFO - 2025-07-24 09:07:50 --> Output Class Initialized
INFO - 2025-07-24 09:07:50 --> Security Class Initialized
DEBUG - 2025-07-24 09:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-24 09:07:51 --> Input Class Initialized
INFO - 2025-07-24 09:07:51 --> Language Class Initialized
INFO - 2025-07-24 09:07:51 --> Loader Class Initialized
INFO - 2025-07-24 09:07:51 --> Helper loaded: url_helper
INFO - 2025-07-24 09:07:51 --> Helper loaded: form_helper
INFO - 2025-07-24 09:07:51 --> Database Driver Class Initialized
DEBUG - 2025-07-24 09:07:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-24 09:07:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-24 09:07:51 --> Controller Class Initialized
INFO - 2025-07-24 09:07:51 --> Model "Olahraga_model" initialized
INFO - 2025-07-24 09:07:51 --> Model "User_model" initialized
INFO - 2025-07-24 09:07:51 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-24 09:07:51 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-24 09:07:51 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-07-24 09:07:51 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-24 09:07:51 --> Final output sent to browser
DEBUG - 2025-07-24 09:07:51 --> Total execution time: 1.5239
INFO - 2025-07-24 09:07:56 --> Config Class Initialized
INFO - 2025-07-24 09:07:56 --> Hooks Class Initialized
DEBUG - 2025-07-24 09:07:56 --> UTF-8 Support Enabled
INFO - 2025-07-24 09:07:56 --> Utf8 Class Initialized
INFO - 2025-07-24 09:07:56 --> URI Class Initialized
INFO - 2025-07-24 09:07:56 --> Router Class Initialized
INFO - 2025-07-24 09:07:56 --> Output Class Initialized
INFO - 2025-07-24 09:07:56 --> Security Class Initialized
DEBUG - 2025-07-24 09:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-24 09:07:56 --> Input Class Initialized
INFO - 2025-07-24 09:07:56 --> Language Class Initialized
INFO - 2025-07-24 09:07:56 --> Loader Class Initialized
INFO - 2025-07-24 09:07:56 --> Helper loaded: url_helper
INFO - 2025-07-24 09:07:56 --> Helper loaded: form_helper
INFO - 2025-07-24 09:07:56 --> Database Driver Class Initialized
DEBUG - 2025-07-24 09:07:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-24 09:07:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-24 09:07:56 --> Controller Class Initialized
INFO - 2025-07-24 09:07:56 --> Model "Olahraga_model" initialized
INFO - 2025-07-24 09:07:56 --> Model "User_model" initialized
INFO - 2025-07-24 09:07:56 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-24 09:07:56 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-24 09:07:56 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/level.php
INFO - 2025-07-24 09:07:56 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-24 09:07:56 --> Final output sent to browser
DEBUG - 2025-07-24 09:07:56 --> Total execution time: 0.1080
INFO - 2025-07-24 09:07:58 --> Config Class Initialized
INFO - 2025-07-24 09:07:58 --> Hooks Class Initialized
DEBUG - 2025-07-24 09:07:58 --> UTF-8 Support Enabled
INFO - 2025-07-24 09:07:58 --> Utf8 Class Initialized
INFO - 2025-07-24 09:07:58 --> URI Class Initialized
INFO - 2025-07-24 09:07:58 --> Router Class Initialized
INFO - 2025-07-24 09:07:58 --> Output Class Initialized
INFO - 2025-07-24 09:07:58 --> Security Class Initialized
DEBUG - 2025-07-24 09:07:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-24 09:07:58 --> Input Class Initialized
INFO - 2025-07-24 09:07:58 --> Language Class Initialized
INFO - 2025-07-24 09:07:58 --> Loader Class Initialized
INFO - 2025-07-24 09:07:58 --> Helper loaded: url_helper
INFO - 2025-07-24 09:07:58 --> Helper loaded: form_helper
INFO - 2025-07-24 09:07:58 --> Database Driver Class Initialized
DEBUG - 2025-07-24 09:07:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-24 09:07:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-24 09:07:58 --> Controller Class Initialized
INFO - 2025-07-24 09:07:58 --> Model "User_model" initialized
INFO - 2025-07-24 09:07:58 --> Model "Progress_model" initialized
INFO - 2025-07-24 09:07:58 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-24 09:07:58 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-24 09:07:58 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/guide.php
INFO - 2025-07-24 09:07:58 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-24 09:07:58 --> Final output sent to browser
DEBUG - 2025-07-24 09:07:58 --> Total execution time: 0.1458
INFO - 2025-07-24 09:07:59 --> Config Class Initialized
INFO - 2025-07-24 09:07:59 --> Hooks Class Initialized
DEBUG - 2025-07-24 09:07:59 --> UTF-8 Support Enabled
INFO - 2025-07-24 09:07:59 --> Utf8 Class Initialized
INFO - 2025-07-24 09:07:59 --> URI Class Initialized
INFO - 2025-07-24 09:07:59 --> Router Class Initialized
INFO - 2025-07-24 09:07:59 --> Output Class Initialized
INFO - 2025-07-24 09:07:59 --> Security Class Initialized
DEBUG - 2025-07-24 09:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-07-24 09:07:59 --> Input Class Initialized
INFO - 2025-07-24 09:07:59 --> Language Class Initialized
INFO - 2025-07-24 09:07:59 --> Loader Class Initialized
INFO - 2025-07-24 09:07:59 --> Helper loaded: url_helper
INFO - 2025-07-24 09:07:59 --> Helper loaded: form_helper
INFO - 2025-07-24 09:07:59 --> Database Driver Class Initialized
DEBUG - 2025-07-24 09:07:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-07-24 09:07:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-07-24 09:07:59 --> Controller Class Initialized
INFO - 2025-07-24 09:07:59 --> Model "User_model" initialized
INFO - 2025-07-24 09:07:59 --> Model "Progress_model" initialized
INFO - 2025-07-24 09:07:59 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-07-24 09:07:59 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-07-24 09:07:59 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/dashboard.php
INFO - 2025-07-24 09:07:59 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-07-24 09:07:59 --> Final output sent to browser
DEBUG - 2025-07-24 09:07:59 --> Total execution time: 0.2199
