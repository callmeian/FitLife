<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-05-13 10:14:42 --> Config Class Initialized
INFO - 2025-05-13 10:14:42 --> Hooks Class Initialized
DEBUG - 2025-05-13 10:14:42 --> UTF-8 Support Enabled
INFO - 2025-05-13 10:14:42 --> Utf8 Class Initialized
INFO - 2025-05-13 10:14:42 --> URI Class Initialized
DEBUG - 2025-05-13 10:14:42 --> No URI present. Default controller set.
INFO - 2025-05-13 10:14:42 --> Router Class Initialized
INFO - 2025-05-13 10:14:42 --> Output Class Initialized
INFO - 2025-05-13 10:14:42 --> Security Class Initialized
DEBUG - 2025-05-13 10:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 10:14:42 --> Input Class Initialized
INFO - 2025-05-13 10:14:42 --> Language Class Initialized
INFO - 2025-05-13 10:14:42 --> Loader Class Initialized
INFO - 2025-05-13 10:14:42 --> Helper loaded: url_helper
INFO - 2025-05-13 10:14:42 --> Helper loaded: form_helper
INFO - 2025-05-13 10:14:42 --> Database Driver Class Initialized
DEBUG - 2025-05-13 10:14:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 10:14:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 10:14:42 --> Controller Class Initialized
INFO - 2025-05-13 10:14:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-13 10:14:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-13 10:14:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-13 10:14:42 --> Final output sent to browser
DEBUG - 2025-05-13 10:14:42 --> Total execution time: 0.0934
INFO - 2025-05-13 10:15:51 --> Config Class Initialized
INFO - 2025-05-13 10:15:51 --> Hooks Class Initialized
DEBUG - 2025-05-13 10:15:51 --> UTF-8 Support Enabled
INFO - 2025-05-13 10:15:51 --> Utf8 Class Initialized
INFO - 2025-05-13 10:15:51 --> URI Class Initialized
DEBUG - 2025-05-13 10:15:51 --> No URI present. Default controller set.
INFO - 2025-05-13 10:15:51 --> Router Class Initialized
INFO - 2025-05-13 10:15:51 --> Output Class Initialized
INFO - 2025-05-13 10:15:51 --> Security Class Initialized
DEBUG - 2025-05-13 10:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 10:15:51 --> Input Class Initialized
INFO - 2025-05-13 10:15:51 --> Language Class Initialized
INFO - 2025-05-13 10:15:51 --> Loader Class Initialized
INFO - 2025-05-13 10:15:51 --> Helper loaded: url_helper
INFO - 2025-05-13 10:15:51 --> Helper loaded: form_helper
INFO - 2025-05-13 10:15:51 --> Database Driver Class Initialized
DEBUG - 2025-05-13 10:15:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 10:15:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 10:15:51 --> Controller Class Initialized
INFO - 2025-05-13 10:15:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-13 10:15:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-13 10:15:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-13 10:15:51 --> Final output sent to browser
DEBUG - 2025-05-13 10:15:51 --> Total execution time: 0.1563
INFO - 2025-05-13 10:16:02 --> Config Class Initialized
INFO - 2025-05-13 10:16:02 --> Hooks Class Initialized
DEBUG - 2025-05-13 10:16:02 --> UTF-8 Support Enabled
INFO - 2025-05-13 10:16:02 --> Utf8 Class Initialized
INFO - 2025-05-13 10:16:02 --> URI Class Initialized
INFO - 2025-05-13 10:16:02 --> Router Class Initialized
INFO - 2025-05-13 10:16:02 --> Output Class Initialized
INFO - 2025-05-13 10:16:02 --> Security Class Initialized
DEBUG - 2025-05-13 10:16:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 10:16:02 --> Input Class Initialized
INFO - 2025-05-13 10:16:02 --> Language Class Initialized
INFO - 2025-05-13 10:16:02 --> Loader Class Initialized
INFO - 2025-05-13 10:16:02 --> Helper loaded: url_helper
INFO - 2025-05-13 10:16:02 --> Helper loaded: form_helper
INFO - 2025-05-13 10:16:02 --> Database Driver Class Initialized
DEBUG - 2025-05-13 10:16:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 10:16:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 10:16:02 --> Controller Class Initialized
INFO - 2025-05-13 10:16:02 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-13 10:16:02 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/artikel.php
INFO - 2025-05-13 10:16:02 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-13 10:16:02 --> Final output sent to browser
DEBUG - 2025-05-13 10:16:02 --> Total execution time: 0.0788
INFO - 2025-05-13 10:16:19 --> Config Class Initialized
INFO - 2025-05-13 10:16:19 --> Hooks Class Initialized
DEBUG - 2025-05-13 10:16:19 --> UTF-8 Support Enabled
INFO - 2025-05-13 10:16:19 --> Utf8 Class Initialized
INFO - 2025-05-13 10:16:19 --> URI Class Initialized
INFO - 2025-05-13 10:16:19 --> Router Class Initialized
INFO - 2025-05-13 10:16:19 --> Output Class Initialized
INFO - 2025-05-13 10:16:19 --> Security Class Initialized
DEBUG - 2025-05-13 10:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 10:16:19 --> Input Class Initialized
INFO - 2025-05-13 10:16:19 --> Language Class Initialized
INFO - 2025-05-13 10:16:19 --> Loader Class Initialized
INFO - 2025-05-13 10:16:19 --> Helper loaded: url_helper
INFO - 2025-05-13 10:16:19 --> Helper loaded: form_helper
INFO - 2025-05-13 10:16:19 --> Database Driver Class Initialized
DEBUG - 2025-05-13 10:16:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 10:16:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 10:16:19 --> Controller Class Initialized
INFO - 2025-05-13 10:16:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-13 10:16:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-13 10:16:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-13 10:16:19 --> Final output sent to browser
DEBUG - 2025-05-13 10:16:19 --> Total execution time: 0.0649
INFO - 2025-05-13 10:16:21 --> Config Class Initialized
INFO - 2025-05-13 10:16:21 --> Hooks Class Initialized
DEBUG - 2025-05-13 10:16:21 --> UTF-8 Support Enabled
INFO - 2025-05-13 10:16:21 --> Utf8 Class Initialized
INFO - 2025-05-13 10:16:21 --> URI Class Initialized
INFO - 2025-05-13 10:16:21 --> Router Class Initialized
INFO - 2025-05-13 10:16:21 --> Output Class Initialized
INFO - 2025-05-13 10:16:21 --> Security Class Initialized
DEBUG - 2025-05-13 10:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 10:16:21 --> Input Class Initialized
INFO - 2025-05-13 10:16:21 --> Language Class Initialized
INFO - 2025-05-13 10:16:21 --> Loader Class Initialized
INFO - 2025-05-13 10:16:21 --> Helper loaded: url_helper
INFO - 2025-05-13 10:16:21 --> Helper loaded: form_helper
INFO - 2025-05-13 10:16:21 --> Database Driver Class Initialized
DEBUG - 2025-05-13 10:16:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 10:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 10:16:22 --> Controller Class Initialized
INFO - 2025-05-13 10:16:22 --> Model "User_model" initialized
INFO - 2025-05-13 10:16:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-13 10:16:22 --> Final output sent to browser
DEBUG - 2025-05-13 10:16:22 --> Total execution time: 0.0867
INFO - 2025-05-13 10:16:25 --> Config Class Initialized
INFO - 2025-05-13 10:16:25 --> Hooks Class Initialized
DEBUG - 2025-05-13 10:16:25 --> UTF-8 Support Enabled
INFO - 2025-05-13 10:16:25 --> Utf8 Class Initialized
INFO - 2025-05-13 10:16:25 --> URI Class Initialized
INFO - 2025-05-13 10:16:25 --> Router Class Initialized
INFO - 2025-05-13 10:16:25 --> Output Class Initialized
INFO - 2025-05-13 10:16:25 --> Security Class Initialized
DEBUG - 2025-05-13 10:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 10:16:25 --> Input Class Initialized
INFO - 2025-05-13 10:16:25 --> Language Class Initialized
INFO - 2025-05-13 10:16:25 --> Loader Class Initialized
INFO - 2025-05-13 10:16:25 --> Helper loaded: url_helper
INFO - 2025-05-13 10:16:25 --> Helper loaded: form_helper
INFO - 2025-05-13 10:16:25 --> Database Driver Class Initialized
DEBUG - 2025-05-13 10:16:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 10:16:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 10:16:25 --> Controller Class Initialized
INFO - 2025-05-13 10:16:25 --> Model "User_model" initialized
INFO - 2025-05-13 10:16:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/register.php
INFO - 2025-05-13 10:16:25 --> Final output sent to browser
DEBUG - 2025-05-13 10:16:25 --> Total execution time: 0.0636
INFO - 2025-05-13 10:16:33 --> Config Class Initialized
INFO - 2025-05-13 10:16:33 --> Hooks Class Initialized
DEBUG - 2025-05-13 10:16:33 --> UTF-8 Support Enabled
INFO - 2025-05-13 10:16:33 --> Utf8 Class Initialized
INFO - 2025-05-13 10:16:33 --> URI Class Initialized
INFO - 2025-05-13 10:16:33 --> Router Class Initialized
INFO - 2025-05-13 10:16:33 --> Output Class Initialized
INFO - 2025-05-13 10:16:33 --> Security Class Initialized
DEBUG - 2025-05-13 10:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 10:16:33 --> Input Class Initialized
INFO - 2025-05-13 10:16:33 --> Language Class Initialized
INFO - 2025-05-13 10:16:33 --> Loader Class Initialized
INFO - 2025-05-13 10:16:33 --> Helper loaded: url_helper
INFO - 2025-05-13 10:16:33 --> Helper loaded: form_helper
INFO - 2025-05-13 10:16:33 --> Database Driver Class Initialized
DEBUG - 2025-05-13 10:16:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 10:16:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 10:16:33 --> Controller Class Initialized
INFO - 2025-05-13 10:16:33 --> Model "User_model" initialized
INFO - 2025-05-13 10:16:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-13 10:16:33 --> Final output sent to browser
DEBUG - 2025-05-13 10:16:33 --> Total execution time: 0.0887
INFO - 2025-05-13 10:17:44 --> Config Class Initialized
INFO - 2025-05-13 10:17:44 --> Hooks Class Initialized
DEBUG - 2025-05-13 10:17:44 --> UTF-8 Support Enabled
INFO - 2025-05-13 10:17:44 --> Utf8 Class Initialized
INFO - 2025-05-13 10:17:44 --> URI Class Initialized
INFO - 2025-05-13 10:17:44 --> Router Class Initialized
INFO - 2025-05-13 10:17:44 --> Output Class Initialized
INFO - 2025-05-13 10:17:44 --> Security Class Initialized
DEBUG - 2025-05-13 10:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 10:17:44 --> Input Class Initialized
INFO - 2025-05-13 10:17:44 --> Language Class Initialized
INFO - 2025-05-13 10:17:44 --> Loader Class Initialized
INFO - 2025-05-13 10:17:44 --> Helper loaded: url_helper
INFO - 2025-05-13 10:17:44 --> Helper loaded: form_helper
INFO - 2025-05-13 10:17:44 --> Database Driver Class Initialized
DEBUG - 2025-05-13 10:17:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 10:17:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 10:17:44 --> Controller Class Initialized
INFO - 2025-05-13 10:17:44 --> Model "User_model" initialized
INFO - 2025-05-13 10:17:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-13 10:17:44 --> Final output sent to browser
DEBUG - 2025-05-13 10:17:44 --> Total execution time: 0.0647
INFO - 2025-05-13 10:18:04 --> Config Class Initialized
INFO - 2025-05-13 10:18:04 --> Hooks Class Initialized
DEBUG - 2025-05-13 10:18:04 --> UTF-8 Support Enabled
INFO - 2025-05-13 10:18:04 --> Utf8 Class Initialized
INFO - 2025-05-13 10:18:04 --> URI Class Initialized
INFO - 2025-05-13 10:18:04 --> Router Class Initialized
INFO - 2025-05-13 10:18:04 --> Output Class Initialized
INFO - 2025-05-13 10:18:04 --> Security Class Initialized
DEBUG - 2025-05-13 10:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 10:18:04 --> Input Class Initialized
INFO - 2025-05-13 10:18:04 --> Language Class Initialized
INFO - 2025-05-13 10:18:04 --> Loader Class Initialized
INFO - 2025-05-13 10:18:04 --> Helper loaded: url_helper
INFO - 2025-05-13 10:18:04 --> Helper loaded: form_helper
INFO - 2025-05-13 10:18:04 --> Database Driver Class Initialized
DEBUG - 2025-05-13 10:18:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 10:18:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 10:18:04 --> Controller Class Initialized
INFO - 2025-05-13 10:18:04 --> Model "User_model" initialized
INFO - 2025-05-13 10:18:04 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-13 10:18:04 --> Final output sent to browser
DEBUG - 2025-05-13 10:18:04 --> Total execution time: 0.0722
INFO - 2025-05-13 10:18:38 --> Config Class Initialized
INFO - 2025-05-13 10:18:38 --> Hooks Class Initialized
DEBUG - 2025-05-13 10:18:38 --> UTF-8 Support Enabled
INFO - 2025-05-13 10:18:38 --> Utf8 Class Initialized
INFO - 2025-05-13 10:18:38 --> URI Class Initialized
INFO - 2025-05-13 10:18:38 --> Router Class Initialized
INFO - 2025-05-13 10:18:38 --> Output Class Initialized
INFO - 2025-05-13 10:18:38 --> Security Class Initialized
DEBUG - 2025-05-13 10:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 10:18:38 --> Input Class Initialized
INFO - 2025-05-13 10:18:38 --> Language Class Initialized
INFO - 2025-05-13 10:18:38 --> Loader Class Initialized
INFO - 2025-05-13 10:18:38 --> Helper loaded: url_helper
INFO - 2025-05-13 10:18:38 --> Helper loaded: form_helper
INFO - 2025-05-13 10:18:38 --> Database Driver Class Initialized
DEBUG - 2025-05-13 10:18:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 10:18:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 10:18:38 --> Controller Class Initialized
INFO - 2025-05-13 10:18:38 --> Model "User_model" initialized
INFO - 2025-05-13 10:18:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-13 10:18:38 --> Final output sent to browser
DEBUG - 2025-05-13 10:18:38 --> Total execution time: 0.0754
INFO - 2025-05-13 10:18:41 --> Config Class Initialized
INFO - 2025-05-13 10:18:41 --> Hooks Class Initialized
DEBUG - 2025-05-13 10:18:41 --> UTF-8 Support Enabled
INFO - 2025-05-13 10:18:41 --> Utf8 Class Initialized
INFO - 2025-05-13 10:18:41 --> URI Class Initialized
INFO - 2025-05-13 10:18:41 --> Router Class Initialized
INFO - 2025-05-13 10:18:41 --> Output Class Initialized
INFO - 2025-05-13 10:18:41 --> Security Class Initialized
DEBUG - 2025-05-13 10:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 10:18:41 --> Input Class Initialized
INFO - 2025-05-13 10:18:41 --> Language Class Initialized
INFO - 2025-05-13 10:18:41 --> Loader Class Initialized
INFO - 2025-05-13 10:18:41 --> Helper loaded: url_helper
INFO - 2025-05-13 10:18:41 --> Helper loaded: form_helper
INFO - 2025-05-13 10:18:41 --> Database Driver Class Initialized
DEBUG - 2025-05-13 10:18:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 10:18:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 10:18:41 --> Controller Class Initialized
INFO - 2025-05-13 10:18:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-13 10:18:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-13 10:18:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-13 10:18:41 --> Final output sent to browser
DEBUG - 2025-05-13 10:18:41 --> Total execution time: 0.0818
INFO - 2025-05-13 10:18:44 --> Config Class Initialized
INFO - 2025-05-13 10:18:44 --> Hooks Class Initialized
DEBUG - 2025-05-13 10:18:44 --> UTF-8 Support Enabled
INFO - 2025-05-13 10:18:44 --> Utf8 Class Initialized
INFO - 2025-05-13 10:18:44 --> URI Class Initialized
INFO - 2025-05-13 10:18:44 --> Router Class Initialized
INFO - 2025-05-13 10:18:44 --> Output Class Initialized
INFO - 2025-05-13 10:18:44 --> Security Class Initialized
DEBUG - 2025-05-13 10:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 10:18:44 --> Input Class Initialized
INFO - 2025-05-13 10:18:44 --> Language Class Initialized
INFO - 2025-05-13 10:18:44 --> Loader Class Initialized
INFO - 2025-05-13 10:18:44 --> Helper loaded: url_helper
INFO - 2025-05-13 10:18:44 --> Helper loaded: form_helper
INFO - 2025-05-13 10:18:44 --> Database Driver Class Initialized
DEBUG - 2025-05-13 10:18:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 10:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 10:18:44 --> Controller Class Initialized
INFO - 2025-05-13 10:18:44 --> Model "User_model" initialized
INFO - 2025-05-13 10:18:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-13 10:18:44 --> Final output sent to browser
DEBUG - 2025-05-13 10:18:44 --> Total execution time: 0.0699
INFO - 2025-05-13 10:19:07 --> Config Class Initialized
INFO - 2025-05-13 10:19:07 --> Hooks Class Initialized
DEBUG - 2025-05-13 10:19:07 --> UTF-8 Support Enabled
INFO - 2025-05-13 10:19:07 --> Utf8 Class Initialized
INFO - 2025-05-13 10:19:07 --> URI Class Initialized
INFO - 2025-05-13 10:19:07 --> Router Class Initialized
INFO - 2025-05-13 10:19:07 --> Output Class Initialized
INFO - 2025-05-13 10:19:07 --> Security Class Initialized
DEBUG - 2025-05-13 10:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 10:19:07 --> Input Class Initialized
INFO - 2025-05-13 10:19:07 --> Language Class Initialized
INFO - 2025-05-13 10:19:07 --> Loader Class Initialized
INFO - 2025-05-13 10:19:07 --> Helper loaded: url_helper
INFO - 2025-05-13 10:19:07 --> Helper loaded: form_helper
INFO - 2025-05-13 10:19:07 --> Database Driver Class Initialized
DEBUG - 2025-05-13 10:19:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 10:19:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 10:19:07 --> Controller Class Initialized
INFO - 2025-05-13 10:19:07 --> Model "User_model" initialized
INFO - 2025-05-13 10:19:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-13 10:19:07 --> Final output sent to browser
DEBUG - 2025-05-13 10:19:07 --> Total execution time: 0.0591
INFO - 2025-05-13 10:19:35 --> Config Class Initialized
INFO - 2025-05-13 10:19:35 --> Hooks Class Initialized
DEBUG - 2025-05-13 10:19:35 --> UTF-8 Support Enabled
INFO - 2025-05-13 10:19:35 --> Utf8 Class Initialized
INFO - 2025-05-13 10:19:35 --> URI Class Initialized
INFO - 2025-05-13 10:19:35 --> Router Class Initialized
INFO - 2025-05-13 10:19:35 --> Output Class Initialized
INFO - 2025-05-13 10:19:35 --> Security Class Initialized
DEBUG - 2025-05-13 10:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 10:19:35 --> Input Class Initialized
INFO - 2025-05-13 10:19:35 --> Language Class Initialized
INFO - 2025-05-13 10:19:35 --> Loader Class Initialized
INFO - 2025-05-13 10:19:35 --> Helper loaded: url_helper
INFO - 2025-05-13 10:19:35 --> Helper loaded: form_helper
INFO - 2025-05-13 10:19:35 --> Database Driver Class Initialized
DEBUG - 2025-05-13 10:19:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 10:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 10:19:35 --> Controller Class Initialized
INFO - 2025-05-13 10:19:35 --> Model "User_model" initialized
INFO - 2025-05-13 10:19:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-13 10:19:35 --> Final output sent to browser
DEBUG - 2025-05-13 10:19:35 --> Total execution time: 0.0637
INFO - 2025-05-13 10:19:57 --> Config Class Initialized
INFO - 2025-05-13 10:19:57 --> Hooks Class Initialized
DEBUG - 2025-05-13 10:19:57 --> UTF-8 Support Enabled
INFO - 2025-05-13 10:19:57 --> Utf8 Class Initialized
INFO - 2025-05-13 10:19:57 --> URI Class Initialized
INFO - 2025-05-13 10:19:57 --> Router Class Initialized
INFO - 2025-05-13 10:19:57 --> Output Class Initialized
INFO - 2025-05-13 10:19:57 --> Security Class Initialized
DEBUG - 2025-05-13 10:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 10:19:57 --> Input Class Initialized
INFO - 2025-05-13 10:19:57 --> Language Class Initialized
INFO - 2025-05-13 10:19:57 --> Loader Class Initialized
INFO - 2025-05-13 10:19:57 --> Helper loaded: url_helper
INFO - 2025-05-13 10:19:57 --> Helper loaded: form_helper
INFO - 2025-05-13 10:19:57 --> Database Driver Class Initialized
DEBUG - 2025-05-13 10:19:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 10:19:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 10:19:57 --> Controller Class Initialized
INFO - 2025-05-13 10:19:57 --> Model "User_model" initialized
INFO - 2025-05-13 10:19:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-13 10:19:57 --> Final output sent to browser
DEBUG - 2025-05-13 10:19:57 --> Total execution time: 0.0628
INFO - 2025-05-13 10:20:14 --> Config Class Initialized
INFO - 2025-05-13 10:20:14 --> Hooks Class Initialized
DEBUG - 2025-05-13 10:20:14 --> UTF-8 Support Enabled
INFO - 2025-05-13 10:20:14 --> Utf8 Class Initialized
INFO - 2025-05-13 10:20:14 --> URI Class Initialized
INFO - 2025-05-13 10:20:14 --> Router Class Initialized
INFO - 2025-05-13 10:20:14 --> Output Class Initialized
INFO - 2025-05-13 10:20:14 --> Security Class Initialized
DEBUG - 2025-05-13 10:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 10:20:14 --> Input Class Initialized
INFO - 2025-05-13 10:20:14 --> Language Class Initialized
INFO - 2025-05-13 10:20:14 --> Loader Class Initialized
INFO - 2025-05-13 10:20:14 --> Helper loaded: url_helper
INFO - 2025-05-13 10:20:14 --> Helper loaded: form_helper
INFO - 2025-05-13 10:20:14 --> Database Driver Class Initialized
DEBUG - 2025-05-13 10:20:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 10:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 10:20:14 --> Controller Class Initialized
INFO - 2025-05-13 10:20:14 --> Model "User_model" initialized
INFO - 2025-05-13 10:20:14 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-13 10:20:14 --> Final output sent to browser
DEBUG - 2025-05-13 10:20:14 --> Total execution time: 0.0631
INFO - 2025-05-13 10:20:42 --> Config Class Initialized
INFO - 2025-05-13 10:20:42 --> Hooks Class Initialized
DEBUG - 2025-05-13 10:20:42 --> UTF-8 Support Enabled
INFO - 2025-05-13 10:20:42 --> Utf8 Class Initialized
INFO - 2025-05-13 10:20:42 --> URI Class Initialized
INFO - 2025-05-13 10:20:42 --> Router Class Initialized
INFO - 2025-05-13 10:20:42 --> Output Class Initialized
INFO - 2025-05-13 10:20:42 --> Security Class Initialized
DEBUG - 2025-05-13 10:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 10:20:42 --> Input Class Initialized
INFO - 2025-05-13 10:20:42 --> Language Class Initialized
INFO - 2025-05-13 10:20:42 --> Loader Class Initialized
INFO - 2025-05-13 10:20:42 --> Helper loaded: url_helper
INFO - 2025-05-13 10:20:42 --> Helper loaded: form_helper
INFO - 2025-05-13 10:20:42 --> Database Driver Class Initialized
DEBUG - 2025-05-13 10:20:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 10:20:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 10:20:42 --> Controller Class Initialized
INFO - 2025-05-13 10:20:42 --> Model "User_model" initialized
INFO - 2025-05-13 10:20:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-13 10:20:42 --> Final output sent to browser
DEBUG - 2025-05-13 10:20:42 --> Total execution time: 0.0561
INFO - 2025-05-13 10:20:51 --> Config Class Initialized
INFO - 2025-05-13 10:20:51 --> Hooks Class Initialized
DEBUG - 2025-05-13 10:20:51 --> UTF-8 Support Enabled
INFO - 2025-05-13 10:20:51 --> Utf8 Class Initialized
INFO - 2025-05-13 10:20:51 --> URI Class Initialized
INFO - 2025-05-13 10:20:51 --> Router Class Initialized
INFO - 2025-05-13 10:20:51 --> Output Class Initialized
INFO - 2025-05-13 10:20:51 --> Security Class Initialized
DEBUG - 2025-05-13 10:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 10:20:51 --> Input Class Initialized
INFO - 2025-05-13 10:20:51 --> Language Class Initialized
INFO - 2025-05-13 10:20:51 --> Loader Class Initialized
INFO - 2025-05-13 10:20:51 --> Helper loaded: url_helper
INFO - 2025-05-13 10:20:51 --> Helper loaded: form_helper
INFO - 2025-05-13 10:20:51 --> Database Driver Class Initialized
DEBUG - 2025-05-13 10:20:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 10:20:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 10:20:51 --> Controller Class Initialized
INFO - 2025-05-13 10:20:51 --> Model "User_model" initialized
INFO - 2025-05-13 10:20:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-13 10:20:51 --> Final output sent to browser
DEBUG - 2025-05-13 10:20:51 --> Total execution time: 0.0580
INFO - 2025-05-13 10:21:10 --> Config Class Initialized
INFO - 2025-05-13 10:21:10 --> Hooks Class Initialized
DEBUG - 2025-05-13 10:21:10 --> UTF-8 Support Enabled
INFO - 2025-05-13 10:21:10 --> Utf8 Class Initialized
INFO - 2025-05-13 10:21:10 --> URI Class Initialized
INFO - 2025-05-13 10:21:10 --> Router Class Initialized
INFO - 2025-05-13 10:21:10 --> Output Class Initialized
INFO - 2025-05-13 10:21:10 --> Security Class Initialized
DEBUG - 2025-05-13 10:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 10:21:10 --> Input Class Initialized
INFO - 2025-05-13 10:21:10 --> Language Class Initialized
INFO - 2025-05-13 10:21:10 --> Loader Class Initialized
INFO - 2025-05-13 10:21:10 --> Helper loaded: url_helper
INFO - 2025-05-13 10:21:10 --> Helper loaded: form_helper
INFO - 2025-05-13 10:21:10 --> Database Driver Class Initialized
DEBUG - 2025-05-13 10:21:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 10:21:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 10:21:10 --> Controller Class Initialized
INFO - 2025-05-13 10:21:10 --> Model "User_model" initialized
INFO - 2025-05-13 10:21:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-13 10:21:10 --> Final output sent to browser
DEBUG - 2025-05-13 10:21:10 --> Total execution time: 0.0755
INFO - 2025-05-13 10:21:16 --> Config Class Initialized
INFO - 2025-05-13 10:21:16 --> Hooks Class Initialized
DEBUG - 2025-05-13 10:21:16 --> UTF-8 Support Enabled
INFO - 2025-05-13 10:21:16 --> Utf8 Class Initialized
INFO - 2025-05-13 10:21:16 --> URI Class Initialized
INFO - 2025-05-13 10:21:16 --> Router Class Initialized
INFO - 2025-05-13 10:21:16 --> Output Class Initialized
INFO - 2025-05-13 10:21:16 --> Security Class Initialized
DEBUG - 2025-05-13 10:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 10:21:16 --> Input Class Initialized
INFO - 2025-05-13 10:21:16 --> Language Class Initialized
INFO - 2025-05-13 10:21:16 --> Loader Class Initialized
INFO - 2025-05-13 10:21:16 --> Helper loaded: url_helper
INFO - 2025-05-13 10:21:16 --> Helper loaded: form_helper
INFO - 2025-05-13 10:21:16 --> Database Driver Class Initialized
DEBUG - 2025-05-13 10:21:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 10:21:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 10:21:16 --> Controller Class Initialized
INFO - 2025-05-13 10:21:16 --> Model "User_model" initialized
INFO - 2025-05-13 10:21:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/register.php
INFO - 2025-05-13 10:21:16 --> Final output sent to browser
DEBUG - 2025-05-13 10:21:16 --> Total execution time: 0.0596
INFO - 2025-05-13 10:21:18 --> Config Class Initialized
INFO - 2025-05-13 10:21:18 --> Hooks Class Initialized
DEBUG - 2025-05-13 10:21:18 --> UTF-8 Support Enabled
INFO - 2025-05-13 10:21:18 --> Utf8 Class Initialized
INFO - 2025-05-13 10:21:18 --> URI Class Initialized
INFO - 2025-05-13 10:21:18 --> Router Class Initialized
INFO - 2025-05-13 10:21:18 --> Output Class Initialized
INFO - 2025-05-13 10:21:18 --> Security Class Initialized
DEBUG - 2025-05-13 10:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 10:21:18 --> Input Class Initialized
INFO - 2025-05-13 10:21:18 --> Language Class Initialized
INFO - 2025-05-13 10:21:18 --> Loader Class Initialized
INFO - 2025-05-13 10:21:18 --> Helper loaded: url_helper
INFO - 2025-05-13 10:21:18 --> Helper loaded: form_helper
INFO - 2025-05-13 10:21:18 --> Database Driver Class Initialized
DEBUG - 2025-05-13 10:21:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 10:21:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 10:21:18 --> Controller Class Initialized
INFO - 2025-05-13 10:21:18 --> Model "User_model" initialized
INFO - 2025-05-13 10:21:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-13 10:21:18 --> Final output sent to browser
DEBUG - 2025-05-13 10:21:18 --> Total execution time: 0.0729
INFO - 2025-05-13 10:34:26 --> Config Class Initialized
INFO - 2025-05-13 10:34:26 --> Hooks Class Initialized
DEBUG - 2025-05-13 10:34:26 --> UTF-8 Support Enabled
INFO - 2025-05-13 10:34:26 --> Utf8 Class Initialized
INFO - 2025-05-13 10:34:26 --> URI Class Initialized
INFO - 2025-05-13 10:34:26 --> Router Class Initialized
INFO - 2025-05-13 10:34:26 --> Output Class Initialized
INFO - 2025-05-13 10:34:26 --> Security Class Initialized
DEBUG - 2025-05-13 10:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 10:34:26 --> Input Class Initialized
INFO - 2025-05-13 10:34:26 --> Language Class Initialized
INFO - 2025-05-13 10:34:26 --> Loader Class Initialized
INFO - 2025-05-13 10:34:26 --> Helper loaded: url_helper
INFO - 2025-05-13 10:34:26 --> Helper loaded: form_helper
INFO - 2025-05-13 10:34:26 --> Database Driver Class Initialized
DEBUG - 2025-05-13 10:34:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 10:34:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 10:34:26 --> Controller Class Initialized
INFO - 2025-05-13 10:34:26 --> Model "User_model" initialized
INFO - 2025-05-13 10:34:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-13 10:34:26 --> Final output sent to browser
DEBUG - 2025-05-13 10:34:26 --> Total execution time: 0.0631
INFO - 2025-05-13 10:34:39 --> Config Class Initialized
INFO - 2025-05-13 10:34:39 --> Hooks Class Initialized
DEBUG - 2025-05-13 10:34:39 --> UTF-8 Support Enabled
INFO - 2025-05-13 10:34:39 --> Utf8 Class Initialized
INFO - 2025-05-13 10:34:39 --> URI Class Initialized
INFO - 2025-05-13 10:34:39 --> Router Class Initialized
INFO - 2025-05-13 10:34:39 --> Output Class Initialized
INFO - 2025-05-13 10:34:39 --> Security Class Initialized
DEBUG - 2025-05-13 10:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 10:34:39 --> Input Class Initialized
INFO - 2025-05-13 10:34:39 --> Language Class Initialized
INFO - 2025-05-13 10:34:39 --> Loader Class Initialized
INFO - 2025-05-13 10:34:39 --> Helper loaded: url_helper
INFO - 2025-05-13 10:34:39 --> Helper loaded: form_helper
INFO - 2025-05-13 10:34:39 --> Database Driver Class Initialized
DEBUG - 2025-05-13 10:34:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 10:34:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 10:34:39 --> Controller Class Initialized
INFO - 2025-05-13 10:34:39 --> Model "User_model" initialized
INFO - 2025-05-13 10:34:39 --> Config Class Initialized
INFO - 2025-05-13 10:34:39 --> Hooks Class Initialized
DEBUG - 2025-05-13 10:34:39 --> UTF-8 Support Enabled
INFO - 2025-05-13 10:34:39 --> Utf8 Class Initialized
INFO - 2025-05-13 10:34:39 --> URI Class Initialized
INFO - 2025-05-13 10:34:39 --> Router Class Initialized
INFO - 2025-05-13 10:34:39 --> Output Class Initialized
INFO - 2025-05-13 10:34:39 --> Security Class Initialized
DEBUG - 2025-05-13 10:34:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 10:34:39 --> Input Class Initialized
INFO - 2025-05-13 10:34:39 --> Language Class Initialized
INFO - 2025-05-13 10:34:39 --> Loader Class Initialized
INFO - 2025-05-13 10:34:39 --> Helper loaded: url_helper
INFO - 2025-05-13 10:34:39 --> Helper loaded: form_helper
INFO - 2025-05-13 10:34:39 --> Database Driver Class Initialized
DEBUG - 2025-05-13 10:34:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 10:34:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 10:34:39 --> Controller Class Initialized
INFO - 2025-05-13 10:34:39 --> Model "User_model" initialized
INFO - 2025-05-13 10:34:39 --> Model "Workout_model" initialized
INFO - 2025-05-13 10:34:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 10:34:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 10:34:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 10:34:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 10:34:39 --> Final output sent to browser
DEBUG - 2025-05-13 10:34:39 --> Total execution time: 0.0966
INFO - 2025-05-13 10:34:44 --> Config Class Initialized
INFO - 2025-05-13 10:34:44 --> Hooks Class Initialized
DEBUG - 2025-05-13 10:34:44 --> UTF-8 Support Enabled
INFO - 2025-05-13 10:34:44 --> Utf8 Class Initialized
INFO - 2025-05-13 10:34:44 --> URI Class Initialized
DEBUG - 2025-05-13 10:34:44 --> No URI present. Default controller set.
INFO - 2025-05-13 10:34:44 --> Router Class Initialized
INFO - 2025-05-13 10:34:44 --> Output Class Initialized
INFO - 2025-05-13 10:34:44 --> Security Class Initialized
DEBUG - 2025-05-13 10:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 10:34:44 --> Input Class Initialized
INFO - 2025-05-13 10:34:44 --> Language Class Initialized
INFO - 2025-05-13 10:34:44 --> Loader Class Initialized
INFO - 2025-05-13 10:34:44 --> Helper loaded: url_helper
INFO - 2025-05-13 10:34:44 --> Helper loaded: form_helper
INFO - 2025-05-13 10:34:44 --> Database Driver Class Initialized
DEBUG - 2025-05-13 10:34:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 10:34:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 10:34:44 --> Controller Class Initialized
INFO - 2025-05-13 10:34:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-13 10:34:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-13 10:34:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-13 10:34:44 --> Final output sent to browser
DEBUG - 2025-05-13 10:34:44 --> Total execution time: 0.0613
INFO - 2025-05-13 10:34:53 --> Config Class Initialized
INFO - 2025-05-13 10:34:53 --> Hooks Class Initialized
DEBUG - 2025-05-13 10:34:53 --> UTF-8 Support Enabled
INFO - 2025-05-13 10:34:53 --> Utf8 Class Initialized
INFO - 2025-05-13 10:34:53 --> URI Class Initialized
INFO - 2025-05-13 10:34:53 --> Router Class Initialized
INFO - 2025-05-13 10:34:53 --> Output Class Initialized
INFO - 2025-05-13 10:34:53 --> Security Class Initialized
DEBUG - 2025-05-13 10:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 10:34:53 --> Input Class Initialized
INFO - 2025-05-13 10:34:53 --> Language Class Initialized
INFO - 2025-05-13 10:34:53 --> Loader Class Initialized
INFO - 2025-05-13 10:34:53 --> Helper loaded: url_helper
INFO - 2025-05-13 10:34:53 --> Helper loaded: form_helper
INFO - 2025-05-13 10:34:53 --> Database Driver Class Initialized
DEBUG - 2025-05-13 10:34:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 10:34:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 10:34:53 --> Controller Class Initialized
INFO - 2025-05-13 10:34:53 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-13 10:34:53 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/artikel.php
INFO - 2025-05-13 10:34:53 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-13 10:34:53 --> Final output sent to browser
DEBUG - 2025-05-13 10:34:53 --> Total execution time: 0.0846
INFO - 2025-05-13 10:34:54 --> Config Class Initialized
INFO - 2025-05-13 10:34:54 --> Hooks Class Initialized
DEBUG - 2025-05-13 10:34:54 --> UTF-8 Support Enabled
INFO - 2025-05-13 10:34:54 --> Utf8 Class Initialized
INFO - 2025-05-13 10:34:54 --> URI Class Initialized
INFO - 2025-05-13 10:34:54 --> Router Class Initialized
INFO - 2025-05-13 10:34:54 --> Output Class Initialized
INFO - 2025-05-13 10:34:54 --> Security Class Initialized
DEBUG - 2025-05-13 10:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 10:34:54 --> Input Class Initialized
INFO - 2025-05-13 10:34:54 --> Language Class Initialized
INFO - 2025-05-13 10:34:54 --> Loader Class Initialized
INFO - 2025-05-13 10:34:54 --> Helper loaded: url_helper
INFO - 2025-05-13 10:34:54 --> Helper loaded: form_helper
INFO - 2025-05-13 10:34:54 --> Database Driver Class Initialized
DEBUG - 2025-05-13 10:34:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 10:34:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 10:34:54 --> Controller Class Initialized
INFO - 2025-05-13 10:34:54 --> Model "User_model" initialized
INFO - 2025-05-13 10:34:54 --> Model "Workout_model" initialized
INFO - 2025-05-13 10:34:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 10:34:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 10:34:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 10:34:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 10:34:54 --> Final output sent to browser
DEBUG - 2025-05-13 10:34:54 --> Total execution time: 0.0820
INFO - 2025-05-13 10:35:02 --> Config Class Initialized
INFO - 2025-05-13 10:35:02 --> Hooks Class Initialized
DEBUG - 2025-05-13 10:35:02 --> UTF-8 Support Enabled
INFO - 2025-05-13 10:35:02 --> Utf8 Class Initialized
INFO - 2025-05-13 10:35:02 --> URI Class Initialized
INFO - 2025-05-13 10:35:02 --> Router Class Initialized
INFO - 2025-05-13 10:35:02 --> Output Class Initialized
INFO - 2025-05-13 10:35:02 --> Security Class Initialized
DEBUG - 2025-05-13 10:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 10:35:02 --> Input Class Initialized
INFO - 2025-05-13 10:35:02 --> Language Class Initialized
INFO - 2025-05-13 10:35:02 --> Loader Class Initialized
INFO - 2025-05-13 10:35:02 --> Helper loaded: url_helper
INFO - 2025-05-13 10:35:02 --> Helper loaded: form_helper
INFO - 2025-05-13 10:35:02 --> Database Driver Class Initialized
DEBUG - 2025-05-13 10:35:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 10:35:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 10:35:02 --> Controller Class Initialized
INFO - 2025-05-13 10:35:02 --> Model "User_model" initialized
INFO - 2025-05-13 10:35:02 --> Config Class Initialized
INFO - 2025-05-13 10:35:02 --> Hooks Class Initialized
DEBUG - 2025-05-13 10:35:02 --> UTF-8 Support Enabled
INFO - 2025-05-13 10:35:02 --> Utf8 Class Initialized
INFO - 2025-05-13 10:35:02 --> URI Class Initialized
INFO - 2025-05-13 10:35:02 --> Router Class Initialized
INFO - 2025-05-13 10:35:02 --> Output Class Initialized
INFO - 2025-05-13 10:35:02 --> Security Class Initialized
DEBUG - 2025-05-13 10:35:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 10:35:02 --> Input Class Initialized
INFO - 2025-05-13 10:35:02 --> Language Class Initialized
INFO - 2025-05-13 10:35:02 --> Loader Class Initialized
INFO - 2025-05-13 10:35:02 --> Helper loaded: url_helper
INFO - 2025-05-13 10:35:02 --> Helper loaded: form_helper
INFO - 2025-05-13 10:35:02 --> Database Driver Class Initialized
DEBUG - 2025-05-13 10:35:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 10:35:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 10:35:02 --> Controller Class Initialized
INFO - 2025-05-13 10:35:02 --> Model "User_model" initialized
INFO - 2025-05-13 10:35:02 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-13 10:35:02 --> Final output sent to browser
DEBUG - 2025-05-13 10:35:02 --> Total execution time: 0.0520
INFO - 2025-05-13 10:35:06 --> Config Class Initialized
INFO - 2025-05-13 10:35:06 --> Hooks Class Initialized
DEBUG - 2025-05-13 10:35:06 --> UTF-8 Support Enabled
INFO - 2025-05-13 10:35:06 --> Utf8 Class Initialized
INFO - 2025-05-13 10:35:06 --> URI Class Initialized
DEBUG - 2025-05-13 10:35:06 --> No URI present. Default controller set.
INFO - 2025-05-13 10:35:06 --> Router Class Initialized
INFO - 2025-05-13 10:35:06 --> Output Class Initialized
INFO - 2025-05-13 10:35:06 --> Security Class Initialized
DEBUG - 2025-05-13 10:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 10:35:06 --> Input Class Initialized
INFO - 2025-05-13 10:35:06 --> Language Class Initialized
INFO - 2025-05-13 10:35:06 --> Loader Class Initialized
INFO - 2025-05-13 10:35:06 --> Helper loaded: url_helper
INFO - 2025-05-13 10:35:06 --> Helper loaded: form_helper
INFO - 2025-05-13 10:35:06 --> Database Driver Class Initialized
DEBUG - 2025-05-13 10:35:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 10:35:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 10:35:06 --> Controller Class Initialized
INFO - 2025-05-13 10:35:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-13 10:35:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-13 10:35:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-13 10:35:06 --> Final output sent to browser
DEBUG - 2025-05-13 10:35:06 --> Total execution time: 0.0840
INFO - 2025-05-13 10:35:57 --> Config Class Initialized
INFO - 2025-05-13 10:35:57 --> Hooks Class Initialized
DEBUG - 2025-05-13 10:35:57 --> UTF-8 Support Enabled
INFO - 2025-05-13 10:35:57 --> Utf8 Class Initialized
INFO - 2025-05-13 10:35:57 --> URI Class Initialized
DEBUG - 2025-05-13 10:35:57 --> No URI present. Default controller set.
INFO - 2025-05-13 10:35:57 --> Router Class Initialized
INFO - 2025-05-13 10:35:57 --> Output Class Initialized
INFO - 2025-05-13 10:35:57 --> Security Class Initialized
DEBUG - 2025-05-13 10:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 10:35:57 --> Input Class Initialized
INFO - 2025-05-13 10:35:57 --> Language Class Initialized
INFO - 2025-05-13 10:35:57 --> Loader Class Initialized
INFO - 2025-05-13 10:35:57 --> Helper loaded: url_helper
INFO - 2025-05-13 10:35:57 --> Helper loaded: form_helper
INFO - 2025-05-13 10:35:57 --> Database Driver Class Initialized
DEBUG - 2025-05-13 10:35:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 10:35:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 10:35:57 --> Controller Class Initialized
INFO - 2025-05-13 10:35:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-13 10:35:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-13 10:35:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-13 10:35:57 --> Final output sent to browser
DEBUG - 2025-05-13 10:35:57 --> Total execution time: 0.0648
INFO - 2025-05-13 10:36:00 --> Config Class Initialized
INFO - 2025-05-13 10:36:00 --> Hooks Class Initialized
DEBUG - 2025-05-13 10:36:00 --> UTF-8 Support Enabled
INFO - 2025-05-13 10:36:00 --> Utf8 Class Initialized
INFO - 2025-05-13 10:36:00 --> URI Class Initialized
INFO - 2025-05-13 10:36:00 --> Router Class Initialized
INFO - 2025-05-13 10:36:00 --> Output Class Initialized
INFO - 2025-05-13 10:36:00 --> Security Class Initialized
DEBUG - 2025-05-13 10:36:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 10:36:00 --> Input Class Initialized
INFO - 2025-05-13 10:36:00 --> Language Class Initialized
INFO - 2025-05-13 10:36:00 --> Loader Class Initialized
INFO - 2025-05-13 10:36:00 --> Helper loaded: url_helper
INFO - 2025-05-13 10:36:00 --> Helper loaded: form_helper
INFO - 2025-05-13 10:36:00 --> Database Driver Class Initialized
DEBUG - 2025-05-13 10:36:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 10:36:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 10:36:00 --> Controller Class Initialized
INFO - 2025-05-13 10:36:00 --> Model "User_model" initialized
INFO - 2025-05-13 10:36:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-13 10:36:00 --> Final output sent to browser
DEBUG - 2025-05-13 10:36:00 --> Total execution time: 0.0611
INFO - 2025-05-13 10:36:06 --> Config Class Initialized
INFO - 2025-05-13 10:36:06 --> Hooks Class Initialized
DEBUG - 2025-05-13 10:36:06 --> UTF-8 Support Enabled
INFO - 2025-05-13 10:36:06 --> Utf8 Class Initialized
INFO - 2025-05-13 10:36:06 --> URI Class Initialized
INFO - 2025-05-13 10:36:06 --> Router Class Initialized
INFO - 2025-05-13 10:36:06 --> Output Class Initialized
INFO - 2025-05-13 10:36:07 --> Security Class Initialized
DEBUG - 2025-05-13 10:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 10:36:07 --> Input Class Initialized
INFO - 2025-05-13 10:36:07 --> Language Class Initialized
INFO - 2025-05-13 10:36:07 --> Loader Class Initialized
INFO - 2025-05-13 10:36:07 --> Helper loaded: url_helper
INFO - 2025-05-13 10:36:07 --> Helper loaded: form_helper
INFO - 2025-05-13 10:36:07 --> Database Driver Class Initialized
DEBUG - 2025-05-13 10:36:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 10:36:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 10:36:07 --> Controller Class Initialized
INFO - 2025-05-13 10:36:07 --> Model "User_model" initialized
INFO - 2025-05-13 10:36:07 --> Config Class Initialized
INFO - 2025-05-13 10:36:07 --> Hooks Class Initialized
DEBUG - 2025-05-13 10:36:07 --> UTF-8 Support Enabled
INFO - 2025-05-13 10:36:07 --> Utf8 Class Initialized
INFO - 2025-05-13 10:36:07 --> URI Class Initialized
INFO - 2025-05-13 10:36:07 --> Router Class Initialized
INFO - 2025-05-13 10:36:07 --> Output Class Initialized
INFO - 2025-05-13 10:36:07 --> Security Class Initialized
DEBUG - 2025-05-13 10:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 10:36:07 --> Input Class Initialized
INFO - 2025-05-13 10:36:07 --> Language Class Initialized
INFO - 2025-05-13 10:36:07 --> Loader Class Initialized
INFO - 2025-05-13 10:36:07 --> Helper loaded: url_helper
INFO - 2025-05-13 10:36:07 --> Helper loaded: form_helper
INFO - 2025-05-13 10:36:07 --> Database Driver Class Initialized
DEBUG - 2025-05-13 10:36:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 10:36:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 10:36:07 --> Controller Class Initialized
INFO - 2025-05-13 10:36:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-13 10:36:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-13 10:36:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-13 10:36:07 --> Final output sent to browser
DEBUG - 2025-05-13 10:36:07 --> Total execution time: 0.0683
INFO - 2025-05-13 10:36:09 --> Config Class Initialized
INFO - 2025-05-13 10:36:09 --> Hooks Class Initialized
DEBUG - 2025-05-13 10:36:09 --> UTF-8 Support Enabled
INFO - 2025-05-13 10:36:09 --> Utf8 Class Initialized
INFO - 2025-05-13 10:36:09 --> URI Class Initialized
INFO - 2025-05-13 10:36:09 --> Router Class Initialized
INFO - 2025-05-13 10:36:09 --> Output Class Initialized
INFO - 2025-05-13 10:36:09 --> Security Class Initialized
DEBUG - 2025-05-13 10:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 10:36:09 --> Input Class Initialized
INFO - 2025-05-13 10:36:09 --> Language Class Initialized
INFO - 2025-05-13 10:36:09 --> Loader Class Initialized
INFO - 2025-05-13 10:36:09 --> Helper loaded: url_helper
INFO - 2025-05-13 10:36:09 --> Helper loaded: form_helper
INFO - 2025-05-13 10:36:09 --> Database Driver Class Initialized
DEBUG - 2025-05-13 10:36:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 10:36:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 10:36:09 --> Controller Class Initialized
INFO - 2025-05-13 10:36:09 --> Model "User_model" initialized
INFO - 2025-05-13 10:36:09 --> Model "Workout_model" initialized
INFO - 2025-05-13 10:36:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 10:36:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 10:36:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 10:36:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 10:36:09 --> Final output sent to browser
DEBUG - 2025-05-13 10:36:09 --> Total execution time: 0.0713
INFO - 2025-05-13 11:04:18 --> Config Class Initialized
INFO - 2025-05-13 11:04:18 --> Hooks Class Initialized
DEBUG - 2025-05-13 11:04:18 --> UTF-8 Support Enabled
INFO - 2025-05-13 11:04:18 --> Utf8 Class Initialized
INFO - 2025-05-13 11:04:18 --> URI Class Initialized
DEBUG - 2025-05-13 11:04:18 --> No URI present. Default controller set.
INFO - 2025-05-13 11:04:18 --> Router Class Initialized
INFO - 2025-05-13 11:04:18 --> Output Class Initialized
INFO - 2025-05-13 11:04:18 --> Security Class Initialized
DEBUG - 2025-05-13 11:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 11:04:18 --> Input Class Initialized
INFO - 2025-05-13 11:04:18 --> Language Class Initialized
INFO - 2025-05-13 11:04:18 --> Loader Class Initialized
INFO - 2025-05-13 11:04:18 --> Helper loaded: url_helper
INFO - 2025-05-13 11:04:18 --> Helper loaded: form_helper
INFO - 2025-05-13 11:04:18 --> Database Driver Class Initialized
DEBUG - 2025-05-13 11:04:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 11:04:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 11:04:18 --> Controller Class Initialized
INFO - 2025-05-13 11:04:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-13 11:04:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-13 11:04:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-13 11:04:18 --> Final output sent to browser
DEBUG - 2025-05-13 11:04:18 --> Total execution time: 0.0725
INFO - 2025-05-13 11:05:07 --> Config Class Initialized
INFO - 2025-05-13 11:05:07 --> Hooks Class Initialized
DEBUG - 2025-05-13 11:05:07 --> UTF-8 Support Enabled
INFO - 2025-05-13 11:05:07 --> Utf8 Class Initialized
INFO - 2025-05-13 11:05:08 --> URI Class Initialized
INFO - 2025-05-13 11:05:08 --> Router Class Initialized
INFO - 2025-05-13 11:05:08 --> Output Class Initialized
INFO - 2025-05-13 11:05:08 --> Security Class Initialized
DEBUG - 2025-05-13 11:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 11:05:08 --> Input Class Initialized
INFO - 2025-05-13 11:05:08 --> Language Class Initialized
INFO - 2025-05-13 11:05:08 --> Loader Class Initialized
INFO - 2025-05-13 11:05:08 --> Helper loaded: url_helper
INFO - 2025-05-13 11:05:08 --> Helper loaded: form_helper
INFO - 2025-05-13 11:05:08 --> Database Driver Class Initialized
DEBUG - 2025-05-13 11:05:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 11:05:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 11:05:08 --> Controller Class Initialized
INFO - 2025-05-13 11:05:08 --> Model "User_model" initialized
INFO - 2025-05-13 11:05:08 --> Model "Workout_model" initialized
INFO - 2025-05-13 11:05:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 11:05:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 11:05:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 11:05:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 11:05:08 --> Final output sent to browser
DEBUG - 2025-05-13 11:05:08 --> Total execution time: 0.0698
INFO - 2025-05-13 11:05:40 --> Config Class Initialized
INFO - 2025-05-13 11:05:40 --> Hooks Class Initialized
DEBUG - 2025-05-13 11:05:40 --> UTF-8 Support Enabled
INFO - 2025-05-13 11:05:40 --> Utf8 Class Initialized
INFO - 2025-05-13 11:05:40 --> URI Class Initialized
INFO - 2025-05-13 11:05:40 --> Router Class Initialized
INFO - 2025-05-13 11:05:40 --> Output Class Initialized
INFO - 2025-05-13 11:05:40 --> Security Class Initialized
DEBUG - 2025-05-13 11:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 11:05:40 --> Input Class Initialized
INFO - 2025-05-13 11:05:40 --> Language Class Initialized
INFO - 2025-05-13 11:05:40 --> Loader Class Initialized
INFO - 2025-05-13 11:05:40 --> Helper loaded: url_helper
INFO - 2025-05-13 11:05:40 --> Helper loaded: form_helper
INFO - 2025-05-13 11:05:40 --> Database Driver Class Initialized
DEBUG - 2025-05-13 11:05:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 11:05:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 11:05:40 --> Controller Class Initialized
INFO - 2025-05-13 11:05:40 --> Model "User_model" initialized
INFO - 2025-05-13 11:05:40 --> Model "Workout_model" initialized
INFO - 2025-05-13 11:05:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 11:05:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 11:05:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 11:05:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 11:05:40 --> Final output sent to browser
DEBUG - 2025-05-13 11:05:40 --> Total execution time: 0.0660
INFO - 2025-05-13 11:06:00 --> Config Class Initialized
INFO - 2025-05-13 11:06:00 --> Hooks Class Initialized
DEBUG - 2025-05-13 11:06:00 --> UTF-8 Support Enabled
INFO - 2025-05-13 11:06:00 --> Utf8 Class Initialized
INFO - 2025-05-13 11:06:00 --> URI Class Initialized
INFO - 2025-05-13 11:06:00 --> Router Class Initialized
INFO - 2025-05-13 11:06:00 --> Output Class Initialized
INFO - 2025-05-13 11:06:00 --> Security Class Initialized
DEBUG - 2025-05-13 11:06:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 11:06:00 --> Input Class Initialized
INFO - 2025-05-13 11:06:00 --> Language Class Initialized
INFO - 2025-05-13 11:06:00 --> Loader Class Initialized
INFO - 2025-05-13 11:06:00 --> Helper loaded: url_helper
INFO - 2025-05-13 11:06:00 --> Helper loaded: form_helper
INFO - 2025-05-13 11:06:00 --> Database Driver Class Initialized
DEBUG - 2025-05-13 11:06:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 11:06:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 11:06:00 --> Controller Class Initialized
INFO - 2025-05-13 11:06:00 --> Model "User_model" initialized
INFO - 2025-05-13 11:06:00 --> Model "Workout_model" initialized
INFO - 2025-05-13 11:06:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 11:06:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 11:06:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 11:06:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 11:06:00 --> Final output sent to browser
DEBUG - 2025-05-13 11:06:00 --> Total execution time: 0.0714
INFO - 2025-05-13 11:06:09 --> Config Class Initialized
INFO - 2025-05-13 11:06:09 --> Hooks Class Initialized
DEBUG - 2025-05-13 11:06:09 --> UTF-8 Support Enabled
INFO - 2025-05-13 11:06:09 --> Utf8 Class Initialized
INFO - 2025-05-13 11:06:09 --> URI Class Initialized
INFO - 2025-05-13 11:06:09 --> Router Class Initialized
INFO - 2025-05-13 11:06:09 --> Output Class Initialized
INFO - 2025-05-13 11:06:09 --> Security Class Initialized
DEBUG - 2025-05-13 11:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 11:06:09 --> Input Class Initialized
INFO - 2025-05-13 11:06:09 --> Language Class Initialized
INFO - 2025-05-13 11:06:09 --> Loader Class Initialized
INFO - 2025-05-13 11:06:09 --> Helper loaded: url_helper
INFO - 2025-05-13 11:06:09 --> Helper loaded: form_helper
INFO - 2025-05-13 11:06:09 --> Database Driver Class Initialized
DEBUG - 2025-05-13 11:06:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 11:06:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 11:06:09 --> Controller Class Initialized
INFO - 2025-05-13 11:06:09 --> Model "User_model" initialized
INFO - 2025-05-13 11:06:09 --> Model "Workout_model" initialized
INFO - 2025-05-13 11:06:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 11:06:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 11:06:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 11:06:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 11:06:09 --> Final output sent to browser
DEBUG - 2025-05-13 11:06:09 --> Total execution time: 0.0756
INFO - 2025-05-13 11:07:58 --> Config Class Initialized
INFO - 2025-05-13 11:07:58 --> Hooks Class Initialized
DEBUG - 2025-05-13 11:07:58 --> UTF-8 Support Enabled
INFO - 2025-05-13 11:07:58 --> Utf8 Class Initialized
INFO - 2025-05-13 11:07:58 --> URI Class Initialized
DEBUG - 2025-05-13 11:07:58 --> No URI present. Default controller set.
INFO - 2025-05-13 11:07:58 --> Router Class Initialized
INFO - 2025-05-13 11:07:58 --> Output Class Initialized
INFO - 2025-05-13 11:07:58 --> Security Class Initialized
DEBUG - 2025-05-13 11:07:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 11:07:58 --> Input Class Initialized
INFO - 2025-05-13 11:07:58 --> Language Class Initialized
INFO - 2025-05-13 11:07:58 --> Loader Class Initialized
INFO - 2025-05-13 11:07:58 --> Helper loaded: url_helper
INFO - 2025-05-13 11:07:58 --> Helper loaded: form_helper
INFO - 2025-05-13 11:07:58 --> Database Driver Class Initialized
DEBUG - 2025-05-13 11:07:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 11:07:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 11:07:58 --> Controller Class Initialized
INFO - 2025-05-13 11:07:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-13 11:07:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-13 11:07:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-13 11:07:58 --> Final output sent to browser
DEBUG - 2025-05-13 11:07:58 --> Total execution time: 0.0831
INFO - 2025-05-13 11:08:16 --> Config Class Initialized
INFO - 2025-05-13 11:08:16 --> Hooks Class Initialized
DEBUG - 2025-05-13 11:08:16 --> UTF-8 Support Enabled
INFO - 2025-05-13 11:08:16 --> Utf8 Class Initialized
INFO - 2025-05-13 11:08:16 --> URI Class Initialized
DEBUG - 2025-05-13 11:08:16 --> No URI present. Default controller set.
INFO - 2025-05-13 11:08:16 --> Router Class Initialized
INFO - 2025-05-13 11:08:16 --> Output Class Initialized
INFO - 2025-05-13 11:08:16 --> Security Class Initialized
DEBUG - 2025-05-13 11:08:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 11:08:16 --> Input Class Initialized
INFO - 2025-05-13 11:08:16 --> Language Class Initialized
INFO - 2025-05-13 11:08:16 --> Loader Class Initialized
INFO - 2025-05-13 11:08:16 --> Helper loaded: url_helper
INFO - 2025-05-13 11:08:16 --> Helper loaded: form_helper
INFO - 2025-05-13 11:08:16 --> Database Driver Class Initialized
DEBUG - 2025-05-13 11:08:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 11:08:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 11:08:16 --> Controller Class Initialized
INFO - 2025-05-13 11:08:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-13 11:08:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-13 11:08:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-13 11:08:16 --> Final output sent to browser
DEBUG - 2025-05-13 11:08:16 --> Total execution time: 0.0761
INFO - 2025-05-13 11:08:46 --> Config Class Initialized
INFO - 2025-05-13 11:08:46 --> Hooks Class Initialized
DEBUG - 2025-05-13 11:08:46 --> UTF-8 Support Enabled
INFO - 2025-05-13 11:08:46 --> Utf8 Class Initialized
INFO - 2025-05-13 11:08:46 --> URI Class Initialized
DEBUG - 2025-05-13 11:08:46 --> No URI present. Default controller set.
INFO - 2025-05-13 11:08:46 --> Router Class Initialized
INFO - 2025-05-13 11:08:46 --> Output Class Initialized
INFO - 2025-05-13 11:08:46 --> Security Class Initialized
DEBUG - 2025-05-13 11:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 11:08:46 --> Input Class Initialized
INFO - 2025-05-13 11:08:46 --> Language Class Initialized
INFO - 2025-05-13 11:08:46 --> Loader Class Initialized
INFO - 2025-05-13 11:08:46 --> Helper loaded: url_helper
INFO - 2025-05-13 11:08:46 --> Helper loaded: form_helper
INFO - 2025-05-13 11:08:46 --> Database Driver Class Initialized
DEBUG - 2025-05-13 11:08:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 11:08:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 11:08:46 --> Controller Class Initialized
INFO - 2025-05-13 11:08:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-13 11:08:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-13 11:08:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-13 11:08:46 --> Final output sent to browser
DEBUG - 2025-05-13 11:08:46 --> Total execution time: 0.0593
INFO - 2025-05-13 11:10:30 --> Config Class Initialized
INFO - 2025-05-13 11:10:30 --> Hooks Class Initialized
DEBUG - 2025-05-13 11:10:30 --> UTF-8 Support Enabled
INFO - 2025-05-13 11:10:30 --> Utf8 Class Initialized
INFO - 2025-05-13 11:10:30 --> URI Class Initialized
DEBUG - 2025-05-13 11:10:30 --> No URI present. Default controller set.
INFO - 2025-05-13 11:10:30 --> Router Class Initialized
INFO - 2025-05-13 11:10:30 --> Output Class Initialized
INFO - 2025-05-13 11:10:30 --> Security Class Initialized
DEBUG - 2025-05-13 11:10:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 11:10:30 --> Input Class Initialized
INFO - 2025-05-13 11:10:30 --> Language Class Initialized
INFO - 2025-05-13 11:10:30 --> Loader Class Initialized
INFO - 2025-05-13 11:10:30 --> Helper loaded: url_helper
INFO - 2025-05-13 11:10:30 --> Helper loaded: form_helper
INFO - 2025-05-13 11:10:30 --> Database Driver Class Initialized
DEBUG - 2025-05-13 11:10:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 11:10:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 11:10:30 --> Controller Class Initialized
INFO - 2025-05-13 11:10:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-13 11:10:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-13 11:10:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-13 11:10:30 --> Final output sent to browser
DEBUG - 2025-05-13 11:10:30 --> Total execution time: 0.0794
INFO - 2025-05-13 11:11:15 --> Config Class Initialized
INFO - 2025-05-13 11:11:15 --> Hooks Class Initialized
DEBUG - 2025-05-13 11:11:15 --> UTF-8 Support Enabled
INFO - 2025-05-13 11:11:15 --> Utf8 Class Initialized
INFO - 2025-05-13 11:11:15 --> URI Class Initialized
DEBUG - 2025-05-13 11:11:15 --> No URI present. Default controller set.
INFO - 2025-05-13 11:11:15 --> Router Class Initialized
INFO - 2025-05-13 11:11:15 --> Output Class Initialized
INFO - 2025-05-13 11:11:15 --> Security Class Initialized
DEBUG - 2025-05-13 11:11:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 11:11:15 --> Input Class Initialized
INFO - 2025-05-13 11:11:15 --> Language Class Initialized
INFO - 2025-05-13 11:11:15 --> Loader Class Initialized
INFO - 2025-05-13 11:11:15 --> Helper loaded: url_helper
INFO - 2025-05-13 11:11:15 --> Helper loaded: form_helper
INFO - 2025-05-13 11:11:15 --> Database Driver Class Initialized
DEBUG - 2025-05-13 11:11:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 11:11:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 11:11:15 --> Controller Class Initialized
INFO - 2025-05-13 11:11:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-13 11:11:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-13 11:11:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-13 11:11:15 --> Final output sent to browser
DEBUG - 2025-05-13 11:11:15 --> Total execution time: 0.0777
INFO - 2025-05-13 11:12:15 --> Config Class Initialized
INFO - 2025-05-13 11:12:15 --> Hooks Class Initialized
DEBUG - 2025-05-13 11:12:15 --> UTF-8 Support Enabled
INFO - 2025-05-13 11:12:15 --> Utf8 Class Initialized
INFO - 2025-05-13 11:12:15 --> URI Class Initialized
DEBUG - 2025-05-13 11:12:15 --> No URI present. Default controller set.
INFO - 2025-05-13 11:12:15 --> Router Class Initialized
INFO - 2025-05-13 11:12:15 --> Output Class Initialized
INFO - 2025-05-13 11:12:15 --> Security Class Initialized
DEBUG - 2025-05-13 11:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 11:12:15 --> Input Class Initialized
INFO - 2025-05-13 11:12:15 --> Language Class Initialized
INFO - 2025-05-13 11:12:15 --> Loader Class Initialized
INFO - 2025-05-13 11:12:15 --> Helper loaded: url_helper
INFO - 2025-05-13 11:12:15 --> Helper loaded: form_helper
INFO - 2025-05-13 11:12:15 --> Database Driver Class Initialized
DEBUG - 2025-05-13 11:12:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 11:12:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 11:12:15 --> Controller Class Initialized
ERROR - 2025-05-13 11:12:15 --> Severity: Warning --> Undefined variable $user C:\laragon\www\Project\fitnessrecord\application\views\landing_page\layout\header.php 468
ERROR - 2025-05-13 11:12:15 --> Severity: Warning --> Attempt to read property "name" on null C:\laragon\www\Project\fitnessrecord\application\views\landing_page\layout\header.php 468
INFO - 2025-05-13 11:12:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-13 11:12:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-13 11:12:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-13 11:12:15 --> Final output sent to browser
DEBUG - 2025-05-13 11:12:15 --> Total execution time: 0.0845
INFO - 2025-05-13 11:14:03 --> Config Class Initialized
INFO - 2025-05-13 11:14:03 --> Hooks Class Initialized
DEBUG - 2025-05-13 11:14:03 --> UTF-8 Support Enabled
INFO - 2025-05-13 11:14:03 --> Utf8 Class Initialized
INFO - 2025-05-13 11:14:03 --> URI Class Initialized
DEBUG - 2025-05-13 11:14:03 --> No URI present. Default controller set.
INFO - 2025-05-13 11:14:03 --> Router Class Initialized
INFO - 2025-05-13 11:14:03 --> Output Class Initialized
INFO - 2025-05-13 11:14:03 --> Security Class Initialized
DEBUG - 2025-05-13 11:14:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 11:14:03 --> Input Class Initialized
INFO - 2025-05-13 11:14:03 --> Language Class Initialized
INFO - 2025-05-13 11:14:03 --> Loader Class Initialized
INFO - 2025-05-13 11:14:03 --> Helper loaded: url_helper
INFO - 2025-05-13 11:14:03 --> Helper loaded: form_helper
INFO - 2025-05-13 11:14:03 --> Database Driver Class Initialized
DEBUG - 2025-05-13 11:14:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 11:14:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 11:14:03 --> Controller Class Initialized
ERROR - 2025-05-13 11:14:03 --> Severity: Warning --> Undefined variable $user C:\laragon\www\Project\fitnessrecord\application\views\landing_page\layout\header.php 468
ERROR - 2025-05-13 11:14:03 --> Severity: Warning --> Attempt to read property "name" on null C:\laragon\www\Project\fitnessrecord\application\views\landing_page\layout\header.php 468
INFO - 2025-05-13 11:14:03 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-13 11:14:03 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-13 11:14:03 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-13 11:14:03 --> Final output sent to browser
DEBUG - 2025-05-13 11:14:03 --> Total execution time: 0.0892
INFO - 2025-05-13 11:18:21 --> Config Class Initialized
INFO - 2025-05-13 11:18:21 --> Hooks Class Initialized
DEBUG - 2025-05-13 11:18:21 --> UTF-8 Support Enabled
INFO - 2025-05-13 11:18:21 --> Utf8 Class Initialized
INFO - 2025-05-13 11:18:21 --> URI Class Initialized
DEBUG - 2025-05-13 11:18:21 --> No URI present. Default controller set.
INFO - 2025-05-13 11:18:21 --> Router Class Initialized
INFO - 2025-05-13 11:18:21 --> Output Class Initialized
INFO - 2025-05-13 11:18:21 --> Security Class Initialized
DEBUG - 2025-05-13 11:18:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 11:18:21 --> Input Class Initialized
INFO - 2025-05-13 11:18:21 --> Language Class Initialized
INFO - 2025-05-13 11:18:21 --> Loader Class Initialized
INFO - 2025-05-13 11:18:21 --> Helper loaded: url_helper
INFO - 2025-05-13 11:18:21 --> Helper loaded: form_helper
INFO - 2025-05-13 11:18:21 --> Database Driver Class Initialized
DEBUG - 2025-05-13 11:18:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 11:18:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 11:18:21 --> Controller Class Initialized
ERROR - 2025-05-13 11:18:21 --> Severity: Warning --> Undefined variable $user C:\laragon\www\Project\fitnessrecord\application\views\landing_page\layout\header.php 468
ERROR - 2025-05-13 11:18:21 --> Severity: Warning --> Attempt to read property "name" on null C:\laragon\www\Project\fitnessrecord\application\views\landing_page\layout\header.php 468
INFO - 2025-05-13 11:18:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-13 11:18:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-13 11:18:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-13 11:18:21 --> Final output sent to browser
DEBUG - 2025-05-13 11:18:21 --> Total execution time: 0.1049
INFO - 2025-05-13 11:19:50 --> Config Class Initialized
INFO - 2025-05-13 11:19:50 --> Hooks Class Initialized
DEBUG - 2025-05-13 11:19:50 --> UTF-8 Support Enabled
INFO - 2025-05-13 11:19:50 --> Utf8 Class Initialized
INFO - 2025-05-13 11:19:50 --> URI Class Initialized
DEBUG - 2025-05-13 11:19:50 --> No URI present. Default controller set.
INFO - 2025-05-13 11:19:50 --> Router Class Initialized
INFO - 2025-05-13 11:19:50 --> Output Class Initialized
INFO - 2025-05-13 11:19:50 --> Security Class Initialized
DEBUG - 2025-05-13 11:19:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 11:19:50 --> Input Class Initialized
INFO - 2025-05-13 11:19:50 --> Language Class Initialized
INFO - 2025-05-13 11:19:50 --> Loader Class Initialized
INFO - 2025-05-13 11:19:50 --> Helper loaded: url_helper
INFO - 2025-05-13 11:19:50 --> Helper loaded: form_helper
INFO - 2025-05-13 11:19:50 --> Database Driver Class Initialized
DEBUG - 2025-05-13 11:19:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 11:19:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 11:19:50 --> Controller Class Initialized
INFO - 2025-05-13 11:19:50 --> Model "User_model" initialized
ERROR - 2025-05-13 11:19:50 --> Severity: Warning --> Undefined variable $user C:\laragon\www\Project\fitnessrecord\application\views\landing_page\layout\header.php 468
ERROR - 2025-05-13 11:19:50 --> Severity: Warning --> Attempt to read property "name" on null C:\laragon\www\Project\fitnessrecord\application\views\landing_page\layout\header.php 468
INFO - 2025-05-13 11:19:50 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-13 11:19:50 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-13 11:19:50 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-13 11:19:50 --> Final output sent to browser
DEBUG - 2025-05-13 11:19:50 --> Total execution time: 0.0756
INFO - 2025-05-13 11:20:28 --> Config Class Initialized
INFO - 2025-05-13 11:20:28 --> Hooks Class Initialized
DEBUG - 2025-05-13 11:20:28 --> UTF-8 Support Enabled
INFO - 2025-05-13 11:20:28 --> Utf8 Class Initialized
INFO - 2025-05-13 11:20:28 --> URI Class Initialized
DEBUG - 2025-05-13 11:20:28 --> No URI present. Default controller set.
INFO - 2025-05-13 11:20:28 --> Router Class Initialized
INFO - 2025-05-13 11:20:28 --> Output Class Initialized
INFO - 2025-05-13 11:20:28 --> Security Class Initialized
DEBUG - 2025-05-13 11:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 11:20:28 --> Input Class Initialized
INFO - 2025-05-13 11:20:28 --> Language Class Initialized
INFO - 2025-05-13 11:20:28 --> Loader Class Initialized
INFO - 2025-05-13 11:20:28 --> Helper loaded: url_helper
INFO - 2025-05-13 11:20:28 --> Helper loaded: form_helper
INFO - 2025-05-13 11:20:28 --> Database Driver Class Initialized
DEBUG - 2025-05-13 11:20:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 11:20:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 11:20:28 --> Controller Class Initialized
INFO - 2025-05-13 11:20:28 --> Model "User_model" initialized
ERROR - 2025-05-13 11:20:28 --> Severity: Warning --> Undefined variable $user C:\laragon\www\Project\fitnessrecord\application\views\landing_page\layout\header.php 468
ERROR - 2025-05-13 11:20:28 --> Severity: Warning --> Attempt to read property "name" on null C:\laragon\www\Project\fitnessrecord\application\views\landing_page\layout\header.php 468
INFO - 2025-05-13 11:20:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-13 11:20:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-13 11:20:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-13 11:20:28 --> Final output sent to browser
DEBUG - 2025-05-13 11:20:28 --> Total execution time: 0.0986
INFO - 2025-05-13 11:20:35 --> Config Class Initialized
INFO - 2025-05-13 11:20:35 --> Hooks Class Initialized
DEBUG - 2025-05-13 11:20:35 --> UTF-8 Support Enabled
INFO - 2025-05-13 11:20:35 --> Utf8 Class Initialized
INFO - 2025-05-13 11:20:35 --> URI Class Initialized
INFO - 2025-05-13 11:20:35 --> Router Class Initialized
INFO - 2025-05-13 11:20:35 --> Output Class Initialized
INFO - 2025-05-13 11:20:35 --> Security Class Initialized
DEBUG - 2025-05-13 11:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 11:20:35 --> Input Class Initialized
INFO - 2025-05-13 11:20:35 --> Language Class Initialized
INFO - 2025-05-13 11:20:35 --> Loader Class Initialized
INFO - 2025-05-13 11:20:35 --> Helper loaded: url_helper
INFO - 2025-05-13 11:20:35 --> Helper loaded: form_helper
INFO - 2025-05-13 11:20:35 --> Database Driver Class Initialized
DEBUG - 2025-05-13 11:20:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 11:20:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 11:20:35 --> Controller Class Initialized
INFO - 2025-05-13 11:20:35 --> Model "User_model" initialized
INFO - 2025-05-13 11:20:35 --> Model "Workout_model" initialized
INFO - 2025-05-13 11:20:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 11:20:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 11:20:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 11:20:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 11:20:35 --> Final output sent to browser
DEBUG - 2025-05-13 11:20:35 --> Total execution time: 0.0775
INFO - 2025-05-13 11:20:37 --> Config Class Initialized
INFO - 2025-05-13 11:20:37 --> Hooks Class Initialized
DEBUG - 2025-05-13 11:20:37 --> UTF-8 Support Enabled
INFO - 2025-05-13 11:20:37 --> Utf8 Class Initialized
INFO - 2025-05-13 11:20:37 --> URI Class Initialized
INFO - 2025-05-13 11:20:37 --> Router Class Initialized
INFO - 2025-05-13 11:20:37 --> Output Class Initialized
INFO - 2025-05-13 11:20:37 --> Security Class Initialized
DEBUG - 2025-05-13 11:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 11:20:37 --> Input Class Initialized
INFO - 2025-05-13 11:20:37 --> Language Class Initialized
INFO - 2025-05-13 11:20:37 --> Loader Class Initialized
INFO - 2025-05-13 11:20:37 --> Helper loaded: url_helper
INFO - 2025-05-13 11:20:37 --> Helper loaded: form_helper
INFO - 2025-05-13 11:20:38 --> Database Driver Class Initialized
DEBUG - 2025-05-13 11:20:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 11:20:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 11:20:38 --> Controller Class Initialized
INFO - 2025-05-13 11:20:38 --> Model "User_model" initialized
INFO - 2025-05-13 11:20:38 --> Config Class Initialized
INFO - 2025-05-13 11:20:38 --> Hooks Class Initialized
DEBUG - 2025-05-13 11:20:38 --> UTF-8 Support Enabled
INFO - 2025-05-13 11:20:38 --> Utf8 Class Initialized
INFO - 2025-05-13 11:20:38 --> URI Class Initialized
INFO - 2025-05-13 11:20:38 --> Router Class Initialized
INFO - 2025-05-13 11:20:38 --> Output Class Initialized
INFO - 2025-05-13 11:20:38 --> Security Class Initialized
DEBUG - 2025-05-13 11:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 11:20:38 --> Input Class Initialized
INFO - 2025-05-13 11:20:38 --> Language Class Initialized
INFO - 2025-05-13 11:20:38 --> Loader Class Initialized
INFO - 2025-05-13 11:20:38 --> Helper loaded: url_helper
INFO - 2025-05-13 11:20:38 --> Helper loaded: form_helper
INFO - 2025-05-13 11:20:38 --> Database Driver Class Initialized
DEBUG - 2025-05-13 11:20:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 11:20:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 11:20:38 --> Controller Class Initialized
INFO - 2025-05-13 11:20:38 --> Model "User_model" initialized
INFO - 2025-05-13 11:20:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-13 11:20:38 --> Final output sent to browser
DEBUG - 2025-05-13 11:20:38 --> Total execution time: 0.0578
INFO - 2025-05-13 11:20:48 --> Config Class Initialized
INFO - 2025-05-13 11:20:48 --> Hooks Class Initialized
DEBUG - 2025-05-13 11:20:48 --> UTF-8 Support Enabled
INFO - 2025-05-13 11:20:48 --> Utf8 Class Initialized
INFO - 2025-05-13 11:20:48 --> URI Class Initialized
INFO - 2025-05-13 11:20:48 --> Router Class Initialized
INFO - 2025-05-13 11:20:48 --> Output Class Initialized
INFO - 2025-05-13 11:20:48 --> Security Class Initialized
DEBUG - 2025-05-13 11:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 11:20:48 --> Input Class Initialized
INFO - 2025-05-13 11:20:48 --> Language Class Initialized
INFO - 2025-05-13 11:20:48 --> Loader Class Initialized
INFO - 2025-05-13 11:20:48 --> Helper loaded: url_helper
INFO - 2025-05-13 11:20:48 --> Helper loaded: form_helper
INFO - 2025-05-13 11:20:48 --> Database Driver Class Initialized
DEBUG - 2025-05-13 11:20:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 11:20:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 11:20:48 --> Controller Class Initialized
INFO - 2025-05-13 11:20:48 --> Model "User_model" initialized
INFO - 2025-05-13 11:20:48 --> Config Class Initialized
INFO - 2025-05-13 11:20:48 --> Hooks Class Initialized
DEBUG - 2025-05-13 11:20:48 --> UTF-8 Support Enabled
INFO - 2025-05-13 11:20:48 --> Utf8 Class Initialized
INFO - 2025-05-13 11:20:48 --> URI Class Initialized
INFO - 2025-05-13 11:20:48 --> Router Class Initialized
INFO - 2025-05-13 11:20:48 --> Output Class Initialized
INFO - 2025-05-13 11:20:48 --> Security Class Initialized
DEBUG - 2025-05-13 11:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 11:20:48 --> Input Class Initialized
INFO - 2025-05-13 11:20:48 --> Language Class Initialized
INFO - 2025-05-13 11:20:48 --> Loader Class Initialized
INFO - 2025-05-13 11:20:48 --> Helper loaded: url_helper
INFO - 2025-05-13 11:20:48 --> Helper loaded: form_helper
INFO - 2025-05-13 11:20:48 --> Database Driver Class Initialized
DEBUG - 2025-05-13 11:20:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 11:20:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 11:20:48 --> Controller Class Initialized
INFO - 2025-05-13 11:20:48 --> Model "User_model" initialized
ERROR - 2025-05-13 11:20:48 --> Severity: Warning --> Undefined variable $user C:\laragon\www\Project\fitnessrecord\application\views\landing_page\layout\header.php 468
ERROR - 2025-05-13 11:20:48 --> Severity: Warning --> Attempt to read property "name" on null C:\laragon\www\Project\fitnessrecord\application\views\landing_page\layout\header.php 468
INFO - 2025-05-13 11:20:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-13 11:20:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-13 11:20:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-13 11:20:48 --> Final output sent to browser
DEBUG - 2025-05-13 11:20:48 --> Total execution time: 0.0723
INFO - 2025-05-13 11:21:28 --> Config Class Initialized
INFO - 2025-05-13 11:21:28 --> Hooks Class Initialized
DEBUG - 2025-05-13 11:21:28 --> UTF-8 Support Enabled
INFO - 2025-05-13 11:21:28 --> Utf8 Class Initialized
INFO - 2025-05-13 11:21:28 --> URI Class Initialized
INFO - 2025-05-13 11:21:28 --> Router Class Initialized
INFO - 2025-05-13 11:21:28 --> Output Class Initialized
INFO - 2025-05-13 11:21:28 --> Security Class Initialized
DEBUG - 2025-05-13 11:21:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 11:21:28 --> Input Class Initialized
INFO - 2025-05-13 11:21:28 --> Language Class Initialized
INFO - 2025-05-13 11:21:28 --> Loader Class Initialized
INFO - 2025-05-13 11:21:28 --> Helper loaded: url_helper
INFO - 2025-05-13 11:21:28 --> Helper loaded: form_helper
INFO - 2025-05-13 11:21:28 --> Database Driver Class Initialized
DEBUG - 2025-05-13 11:21:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 11:21:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 11:21:28 --> Controller Class Initialized
INFO - 2025-05-13 11:21:28 --> Model "User_model" initialized
INFO - 2025-05-13 11:21:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-13 11:21:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-13 11:21:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-13 11:21:28 --> Final output sent to browser
DEBUG - 2025-05-13 11:21:28 --> Total execution time: 0.0757
INFO - 2025-05-13 11:22:07 --> Config Class Initialized
INFO - 2025-05-13 11:22:07 --> Hooks Class Initialized
DEBUG - 2025-05-13 11:22:07 --> UTF-8 Support Enabled
INFO - 2025-05-13 11:22:07 --> Utf8 Class Initialized
INFO - 2025-05-13 11:22:07 --> URI Class Initialized
INFO - 2025-05-13 11:22:07 --> Router Class Initialized
INFO - 2025-05-13 11:22:07 --> Output Class Initialized
INFO - 2025-05-13 11:22:07 --> Security Class Initialized
DEBUG - 2025-05-13 11:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 11:22:07 --> Input Class Initialized
INFO - 2025-05-13 11:22:07 --> Language Class Initialized
INFO - 2025-05-13 11:22:07 --> Loader Class Initialized
INFO - 2025-05-13 11:22:07 --> Helper loaded: url_helper
INFO - 2025-05-13 11:22:07 --> Helper loaded: form_helper
INFO - 2025-05-13 11:22:07 --> Database Driver Class Initialized
DEBUG - 2025-05-13 11:22:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 11:22:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 11:22:07 --> Controller Class Initialized
INFO - 2025-05-13 11:22:07 --> Model "User_model" initialized
INFO - 2025-05-13 11:22:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-13 11:22:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-13 11:22:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-13 11:22:07 --> Final output sent to browser
DEBUG - 2025-05-13 11:22:07 --> Total execution time: 0.0637
INFO - 2025-05-13 11:24:21 --> Config Class Initialized
INFO - 2025-05-13 11:24:21 --> Hooks Class Initialized
DEBUG - 2025-05-13 11:24:21 --> UTF-8 Support Enabled
INFO - 2025-05-13 11:24:21 --> Utf8 Class Initialized
INFO - 2025-05-13 11:24:21 --> URI Class Initialized
INFO - 2025-05-13 11:24:21 --> Router Class Initialized
INFO - 2025-05-13 11:24:21 --> Output Class Initialized
INFO - 2025-05-13 11:24:21 --> Security Class Initialized
DEBUG - 2025-05-13 11:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 11:24:21 --> Input Class Initialized
INFO - 2025-05-13 11:24:21 --> Language Class Initialized
INFO - 2025-05-13 11:24:21 --> Loader Class Initialized
INFO - 2025-05-13 11:24:21 --> Helper loaded: url_helper
INFO - 2025-05-13 11:24:21 --> Helper loaded: form_helper
INFO - 2025-05-13 11:24:21 --> Database Driver Class Initialized
DEBUG - 2025-05-13 11:24:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 11:24:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 11:24:21 --> Controller Class Initialized
INFO - 2025-05-13 11:24:21 --> Model "User_model" initialized
INFO - 2025-05-13 11:24:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-13 11:24:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-13 11:24:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-13 11:24:21 --> Final output sent to browser
DEBUG - 2025-05-13 11:24:21 --> Total execution time: 0.0718
INFO - 2025-05-13 11:25:17 --> Config Class Initialized
INFO - 2025-05-13 11:25:17 --> Hooks Class Initialized
DEBUG - 2025-05-13 11:25:17 --> UTF-8 Support Enabled
INFO - 2025-05-13 11:25:17 --> Utf8 Class Initialized
INFO - 2025-05-13 11:25:17 --> URI Class Initialized
INFO - 2025-05-13 11:25:17 --> Router Class Initialized
INFO - 2025-05-13 11:25:17 --> Output Class Initialized
INFO - 2025-05-13 11:25:17 --> Security Class Initialized
DEBUG - 2025-05-13 11:25:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 11:25:17 --> Input Class Initialized
INFO - 2025-05-13 11:25:17 --> Language Class Initialized
INFO - 2025-05-13 11:25:17 --> Loader Class Initialized
INFO - 2025-05-13 11:25:17 --> Helper loaded: url_helper
INFO - 2025-05-13 11:25:17 --> Helper loaded: form_helper
INFO - 2025-05-13 11:25:17 --> Database Driver Class Initialized
DEBUG - 2025-05-13 11:25:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 11:25:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 11:25:17 --> Controller Class Initialized
INFO - 2025-05-13 11:25:17 --> Model "User_model" initialized
INFO - 2025-05-13 11:25:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-13 11:25:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-13 11:25:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-13 11:25:17 --> Final output sent to browser
DEBUG - 2025-05-13 11:25:17 --> Total execution time: 0.0596
INFO - 2025-05-13 11:25:28 --> Config Class Initialized
INFO - 2025-05-13 11:25:28 --> Hooks Class Initialized
DEBUG - 2025-05-13 11:25:28 --> UTF-8 Support Enabled
INFO - 2025-05-13 11:25:28 --> Utf8 Class Initialized
INFO - 2025-05-13 11:25:28 --> URI Class Initialized
INFO - 2025-05-13 11:25:28 --> Router Class Initialized
INFO - 2025-05-13 11:25:28 --> Output Class Initialized
INFO - 2025-05-13 11:25:28 --> Security Class Initialized
DEBUG - 2025-05-13 11:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 11:25:28 --> Input Class Initialized
INFO - 2025-05-13 11:25:28 --> Language Class Initialized
INFO - 2025-05-13 11:25:28 --> Loader Class Initialized
INFO - 2025-05-13 11:25:28 --> Helper loaded: url_helper
INFO - 2025-05-13 11:25:28 --> Helper loaded: form_helper
INFO - 2025-05-13 11:25:28 --> Database Driver Class Initialized
DEBUG - 2025-05-13 11:25:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 11:25:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 11:25:28 --> Controller Class Initialized
INFO - 2025-05-13 11:25:28 --> Model "User_model" initialized
INFO - 2025-05-13 11:25:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-13 11:25:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-13 11:25:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-13 11:25:28 --> Final output sent to browser
DEBUG - 2025-05-13 11:25:28 --> Total execution time: 0.0823
INFO - 2025-05-13 11:27:09 --> Config Class Initialized
INFO - 2025-05-13 11:27:09 --> Hooks Class Initialized
DEBUG - 2025-05-13 11:27:09 --> UTF-8 Support Enabled
INFO - 2025-05-13 11:27:09 --> Utf8 Class Initialized
INFO - 2025-05-13 11:27:09 --> URI Class Initialized
INFO - 2025-05-13 11:27:09 --> Router Class Initialized
INFO - 2025-05-13 11:27:09 --> Output Class Initialized
INFO - 2025-05-13 11:27:09 --> Security Class Initialized
DEBUG - 2025-05-13 11:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 11:27:09 --> Input Class Initialized
INFO - 2025-05-13 11:27:09 --> Language Class Initialized
INFO - 2025-05-13 11:27:09 --> Loader Class Initialized
INFO - 2025-05-13 11:27:09 --> Helper loaded: url_helper
INFO - 2025-05-13 11:27:09 --> Helper loaded: form_helper
INFO - 2025-05-13 11:27:09 --> Database Driver Class Initialized
DEBUG - 2025-05-13 11:27:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 11:27:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 11:27:09 --> Controller Class Initialized
INFO - 2025-05-13 11:27:09 --> Model "User_model" initialized
INFO - 2025-05-13 11:27:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-13 11:27:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-13 11:27:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-13 11:27:09 --> Final output sent to browser
DEBUG - 2025-05-13 11:27:09 --> Total execution time: 0.0641
INFO - 2025-05-13 11:27:47 --> Config Class Initialized
INFO - 2025-05-13 11:27:47 --> Hooks Class Initialized
DEBUG - 2025-05-13 11:27:47 --> UTF-8 Support Enabled
INFO - 2025-05-13 11:27:47 --> Utf8 Class Initialized
INFO - 2025-05-13 11:27:47 --> URI Class Initialized
INFO - 2025-05-13 11:27:47 --> Router Class Initialized
INFO - 2025-05-13 11:27:47 --> Output Class Initialized
INFO - 2025-05-13 11:27:47 --> Security Class Initialized
DEBUG - 2025-05-13 11:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 11:27:47 --> Input Class Initialized
INFO - 2025-05-13 11:27:47 --> Language Class Initialized
INFO - 2025-05-13 11:27:47 --> Loader Class Initialized
INFO - 2025-05-13 11:27:47 --> Helper loaded: url_helper
INFO - 2025-05-13 11:27:47 --> Helper loaded: form_helper
INFO - 2025-05-13 11:27:47 --> Database Driver Class Initialized
DEBUG - 2025-05-13 11:27:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 11:27:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 11:27:47 --> Controller Class Initialized
INFO - 2025-05-13 11:27:47 --> Model "User_model" initialized
INFO - 2025-05-13 11:27:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-13 11:27:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-13 11:27:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-13 11:27:47 --> Final output sent to browser
DEBUG - 2025-05-13 11:27:47 --> Total execution time: 0.0697
INFO - 2025-05-13 11:28:21 --> Config Class Initialized
INFO - 2025-05-13 11:28:21 --> Hooks Class Initialized
DEBUG - 2025-05-13 11:28:21 --> UTF-8 Support Enabled
INFO - 2025-05-13 11:28:21 --> Utf8 Class Initialized
INFO - 2025-05-13 11:28:21 --> URI Class Initialized
INFO - 2025-05-13 11:28:21 --> Router Class Initialized
INFO - 2025-05-13 11:28:21 --> Output Class Initialized
INFO - 2025-05-13 11:28:21 --> Security Class Initialized
DEBUG - 2025-05-13 11:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 11:28:21 --> Input Class Initialized
INFO - 2025-05-13 11:28:21 --> Language Class Initialized
INFO - 2025-05-13 11:28:21 --> Loader Class Initialized
INFO - 2025-05-13 11:28:21 --> Helper loaded: url_helper
INFO - 2025-05-13 11:28:21 --> Helper loaded: form_helper
INFO - 2025-05-13 11:28:21 --> Database Driver Class Initialized
DEBUG - 2025-05-13 11:28:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 11:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 11:28:21 --> Controller Class Initialized
INFO - 2025-05-13 11:28:21 --> Model "User_model" initialized
INFO - 2025-05-13 11:28:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-13 11:28:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-13 11:28:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-13 11:28:21 --> Final output sent to browser
DEBUG - 2025-05-13 11:28:21 --> Total execution time: 0.0676
INFO - 2025-05-13 11:32:41 --> Config Class Initialized
INFO - 2025-05-13 11:32:41 --> Hooks Class Initialized
DEBUG - 2025-05-13 11:32:41 --> UTF-8 Support Enabled
INFO - 2025-05-13 11:32:41 --> Utf8 Class Initialized
INFO - 2025-05-13 11:32:41 --> URI Class Initialized
INFO - 2025-05-13 11:32:41 --> Router Class Initialized
INFO - 2025-05-13 11:32:41 --> Output Class Initialized
INFO - 2025-05-13 11:32:41 --> Security Class Initialized
DEBUG - 2025-05-13 11:32:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 11:32:41 --> Input Class Initialized
INFO - 2025-05-13 11:32:41 --> Language Class Initialized
INFO - 2025-05-13 11:32:41 --> Loader Class Initialized
INFO - 2025-05-13 11:32:41 --> Helper loaded: url_helper
INFO - 2025-05-13 11:32:41 --> Helper loaded: form_helper
INFO - 2025-05-13 11:32:41 --> Database Driver Class Initialized
DEBUG - 2025-05-13 11:32:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 11:32:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 11:32:41 --> Controller Class Initialized
INFO - 2025-05-13 11:32:41 --> Model "User_model" initialized
INFO - 2025-05-13 11:32:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-13 11:32:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-13 11:32:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-13 11:32:41 --> Final output sent to browser
DEBUG - 2025-05-13 11:32:41 --> Total execution time: 0.0947
INFO - 2025-05-13 11:32:45 --> Config Class Initialized
INFO - 2025-05-13 11:32:45 --> Hooks Class Initialized
DEBUG - 2025-05-13 11:32:45 --> UTF-8 Support Enabled
INFO - 2025-05-13 11:32:45 --> Utf8 Class Initialized
INFO - 2025-05-13 11:32:45 --> URI Class Initialized
INFO - 2025-05-13 11:32:45 --> Router Class Initialized
INFO - 2025-05-13 11:32:45 --> Output Class Initialized
INFO - 2025-05-13 11:32:45 --> Security Class Initialized
DEBUG - 2025-05-13 11:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 11:32:45 --> Input Class Initialized
INFO - 2025-05-13 11:32:45 --> Language Class Initialized
INFO - 2025-05-13 11:32:45 --> Loader Class Initialized
INFO - 2025-05-13 11:32:45 --> Helper loaded: url_helper
INFO - 2025-05-13 11:32:45 --> Helper loaded: form_helper
INFO - 2025-05-13 11:32:45 --> Database Driver Class Initialized
DEBUG - 2025-05-13 11:32:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 11:32:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 11:32:45 --> Controller Class Initialized
INFO - 2025-05-13 11:32:45 --> Model "User_model" initialized
INFO - 2025-05-13 11:32:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-13 11:32:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-13 11:32:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-13 11:32:45 --> Final output sent to browser
DEBUG - 2025-05-13 11:32:45 --> Total execution time: 0.0816
INFO - 2025-05-13 11:33:06 --> Config Class Initialized
INFO - 2025-05-13 11:33:06 --> Hooks Class Initialized
DEBUG - 2025-05-13 11:33:06 --> UTF-8 Support Enabled
INFO - 2025-05-13 11:33:06 --> Utf8 Class Initialized
INFO - 2025-05-13 11:33:06 --> URI Class Initialized
INFO - 2025-05-13 11:33:06 --> Router Class Initialized
INFO - 2025-05-13 11:33:06 --> Output Class Initialized
INFO - 2025-05-13 11:33:06 --> Security Class Initialized
DEBUG - 2025-05-13 11:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 11:33:06 --> Input Class Initialized
INFO - 2025-05-13 11:33:06 --> Language Class Initialized
INFO - 2025-05-13 11:33:06 --> Loader Class Initialized
INFO - 2025-05-13 11:33:06 --> Helper loaded: url_helper
INFO - 2025-05-13 11:33:06 --> Helper loaded: form_helper
INFO - 2025-05-13 11:33:06 --> Database Driver Class Initialized
DEBUG - 2025-05-13 11:33:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 11:33:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 11:33:06 --> Controller Class Initialized
INFO - 2025-05-13 11:33:06 --> Model "User_model" initialized
INFO - 2025-05-13 11:33:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-13 11:33:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-13 11:33:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-13 11:33:06 --> Final output sent to browser
DEBUG - 2025-05-13 11:33:06 --> Total execution time: 0.0854
INFO - 2025-05-13 11:33:31 --> Config Class Initialized
INFO - 2025-05-13 11:33:31 --> Hooks Class Initialized
DEBUG - 2025-05-13 11:33:31 --> UTF-8 Support Enabled
INFO - 2025-05-13 11:33:31 --> Utf8 Class Initialized
INFO - 2025-05-13 11:33:31 --> URI Class Initialized
INFO - 2025-05-13 11:33:31 --> Router Class Initialized
INFO - 2025-05-13 11:33:31 --> Output Class Initialized
INFO - 2025-05-13 11:33:31 --> Security Class Initialized
DEBUG - 2025-05-13 11:33:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 11:33:31 --> Input Class Initialized
INFO - 2025-05-13 11:33:31 --> Language Class Initialized
INFO - 2025-05-13 11:33:31 --> Loader Class Initialized
INFO - 2025-05-13 11:33:31 --> Helper loaded: url_helper
INFO - 2025-05-13 11:33:31 --> Helper loaded: form_helper
INFO - 2025-05-13 11:33:31 --> Database Driver Class Initialized
DEBUG - 2025-05-13 11:33:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 11:33:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 11:33:31 --> Controller Class Initialized
INFO - 2025-05-13 11:33:31 --> Model "User_model" initialized
INFO - 2025-05-13 11:33:31 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-13 11:33:31 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-13 11:33:31 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-13 11:33:31 --> Final output sent to browser
DEBUG - 2025-05-13 11:33:31 --> Total execution time: 0.0683
INFO - 2025-05-13 11:33:34 --> Config Class Initialized
INFO - 2025-05-13 11:33:34 --> Hooks Class Initialized
DEBUG - 2025-05-13 11:33:34 --> UTF-8 Support Enabled
INFO - 2025-05-13 11:33:34 --> Utf8 Class Initialized
INFO - 2025-05-13 11:33:34 --> URI Class Initialized
INFO - 2025-05-13 11:33:34 --> Router Class Initialized
INFO - 2025-05-13 11:33:34 --> Output Class Initialized
INFO - 2025-05-13 11:33:34 --> Security Class Initialized
DEBUG - 2025-05-13 11:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 11:33:34 --> Input Class Initialized
INFO - 2025-05-13 11:33:34 --> Language Class Initialized
INFO - 2025-05-13 11:33:34 --> Loader Class Initialized
INFO - 2025-05-13 11:33:34 --> Helper loaded: url_helper
INFO - 2025-05-13 11:33:34 --> Helper loaded: form_helper
INFO - 2025-05-13 11:33:34 --> Database Driver Class Initialized
DEBUG - 2025-05-13 11:33:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 11:33:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 11:33:34 --> Controller Class Initialized
INFO - 2025-05-13 11:33:34 --> Model "User_model" initialized
INFO - 2025-05-13 11:33:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-13 11:33:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-13 11:33:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-13 11:33:34 --> Final output sent to browser
DEBUG - 2025-05-13 11:33:34 --> Total execution time: 0.0774
INFO - 2025-05-13 11:33:54 --> Config Class Initialized
INFO - 2025-05-13 11:33:54 --> Hooks Class Initialized
DEBUG - 2025-05-13 11:33:54 --> UTF-8 Support Enabled
INFO - 2025-05-13 11:33:54 --> Utf8 Class Initialized
INFO - 2025-05-13 11:33:54 --> URI Class Initialized
INFO - 2025-05-13 11:33:54 --> Router Class Initialized
INFO - 2025-05-13 11:33:54 --> Output Class Initialized
INFO - 2025-05-13 11:33:54 --> Security Class Initialized
DEBUG - 2025-05-13 11:33:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 11:33:54 --> Input Class Initialized
INFO - 2025-05-13 11:33:54 --> Language Class Initialized
INFO - 2025-05-13 11:33:54 --> Loader Class Initialized
INFO - 2025-05-13 11:33:54 --> Helper loaded: url_helper
INFO - 2025-05-13 11:33:54 --> Helper loaded: form_helper
INFO - 2025-05-13 11:33:54 --> Database Driver Class Initialized
DEBUG - 2025-05-13 11:33:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 11:33:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 11:33:54 --> Controller Class Initialized
INFO - 2025-05-13 11:33:54 --> Model "User_model" initialized
INFO - 2025-05-13 11:33:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-13 11:33:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-13 11:33:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-13 11:33:54 --> Final output sent to browser
DEBUG - 2025-05-13 11:33:54 --> Total execution time: 0.0881
INFO - 2025-05-13 11:36:31 --> Config Class Initialized
INFO - 2025-05-13 11:36:31 --> Hooks Class Initialized
DEBUG - 2025-05-13 11:36:31 --> UTF-8 Support Enabled
INFO - 2025-05-13 11:36:31 --> Utf8 Class Initialized
INFO - 2025-05-13 11:36:31 --> URI Class Initialized
INFO - 2025-05-13 11:36:31 --> Router Class Initialized
INFO - 2025-05-13 11:36:31 --> Output Class Initialized
INFO - 2025-05-13 11:36:31 --> Security Class Initialized
DEBUG - 2025-05-13 11:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 11:36:31 --> Input Class Initialized
INFO - 2025-05-13 11:36:31 --> Language Class Initialized
INFO - 2025-05-13 11:36:31 --> Loader Class Initialized
INFO - 2025-05-13 11:36:31 --> Helper loaded: url_helper
INFO - 2025-05-13 11:36:31 --> Helper loaded: form_helper
INFO - 2025-05-13 11:36:31 --> Database Driver Class Initialized
DEBUG - 2025-05-13 11:36:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 11:36:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 11:36:31 --> Controller Class Initialized
INFO - 2025-05-13 11:36:31 --> Model "User_model" initialized
INFO - 2025-05-13 11:36:31 --> Model "Workout_model" initialized
INFO - 2025-05-13 11:36:31 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 11:36:31 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 11:36:31 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 11:36:31 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 11:36:31 --> Final output sent to browser
DEBUG - 2025-05-13 11:36:31 --> Total execution time: 0.0917
INFO - 2025-05-13 11:37:05 --> Config Class Initialized
INFO - 2025-05-13 11:37:05 --> Hooks Class Initialized
DEBUG - 2025-05-13 11:37:05 --> UTF-8 Support Enabled
INFO - 2025-05-13 11:37:05 --> Utf8 Class Initialized
INFO - 2025-05-13 11:37:05 --> URI Class Initialized
INFO - 2025-05-13 11:37:05 --> Router Class Initialized
INFO - 2025-05-13 11:37:05 --> Output Class Initialized
INFO - 2025-05-13 11:37:05 --> Security Class Initialized
DEBUG - 2025-05-13 11:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 11:37:05 --> Input Class Initialized
INFO - 2025-05-13 11:37:05 --> Language Class Initialized
INFO - 2025-05-13 11:37:05 --> Loader Class Initialized
INFO - 2025-05-13 11:37:05 --> Helper loaded: url_helper
INFO - 2025-05-13 11:37:05 --> Helper loaded: form_helper
INFO - 2025-05-13 11:37:05 --> Database Driver Class Initialized
DEBUG - 2025-05-13 11:37:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 11:37:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 11:37:05 --> Controller Class Initialized
INFO - 2025-05-13 11:37:05 --> Model "User_model" initialized
INFO - 2025-05-13 11:37:05 --> Model "Workout_model" initialized
INFO - 2025-05-13 11:37:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 11:37:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 11:37:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-13 11:37:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 11:37:05 --> Final output sent to browser
DEBUG - 2025-05-13 11:37:05 --> Total execution time: 0.0998
INFO - 2025-05-13 11:37:10 --> Config Class Initialized
INFO - 2025-05-13 11:37:10 --> Hooks Class Initialized
DEBUG - 2025-05-13 11:37:10 --> UTF-8 Support Enabled
INFO - 2025-05-13 11:37:10 --> Utf8 Class Initialized
INFO - 2025-05-13 11:37:10 --> URI Class Initialized
INFO - 2025-05-13 11:37:10 --> Router Class Initialized
INFO - 2025-05-13 11:37:10 --> Output Class Initialized
INFO - 2025-05-13 11:37:10 --> Security Class Initialized
DEBUG - 2025-05-13 11:37:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 11:37:10 --> Input Class Initialized
INFO - 2025-05-13 11:37:10 --> Language Class Initialized
INFO - 2025-05-13 11:37:10 --> Loader Class Initialized
INFO - 2025-05-13 11:37:10 --> Helper loaded: url_helper
INFO - 2025-05-13 11:37:10 --> Helper loaded: form_helper
INFO - 2025-05-13 11:37:10 --> Database Driver Class Initialized
DEBUG - 2025-05-13 11:37:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 11:37:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 11:37:10 --> Controller Class Initialized
INFO - 2025-05-13 11:37:10 --> Model "Workout_model" initialized
INFO - 2025-05-13 11:37:10 --> Model "User_model" initialized
INFO - 2025-05-13 11:37:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 11:37:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 11:37:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-13 11:37:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 11:37:10 --> Final output sent to browser
DEBUG - 2025-05-13 11:37:10 --> Total execution time: 0.1176
INFO - 2025-05-13 11:37:13 --> Config Class Initialized
INFO - 2025-05-13 11:37:13 --> Hooks Class Initialized
DEBUG - 2025-05-13 11:37:13 --> UTF-8 Support Enabled
INFO - 2025-05-13 11:37:13 --> Utf8 Class Initialized
INFO - 2025-05-13 11:37:13 --> URI Class Initialized
INFO - 2025-05-13 11:37:13 --> Router Class Initialized
INFO - 2025-05-13 11:37:13 --> Output Class Initialized
INFO - 2025-05-13 11:37:13 --> Security Class Initialized
DEBUG - 2025-05-13 11:37:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 11:37:13 --> Input Class Initialized
INFO - 2025-05-13 11:37:13 --> Language Class Initialized
INFO - 2025-05-13 11:37:13 --> Loader Class Initialized
INFO - 2025-05-13 11:37:13 --> Helper loaded: url_helper
INFO - 2025-05-13 11:37:13 --> Helper loaded: form_helper
INFO - 2025-05-13 11:37:13 --> Database Driver Class Initialized
DEBUG - 2025-05-13 11:37:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 11:37:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 11:37:13 --> Controller Class Initialized
INFO - 2025-05-13 11:37:13 --> Model "User_model" initialized
INFO - 2025-05-13 11:37:13 --> Model "Workout_model" initialized
INFO - 2025-05-13 11:37:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 11:37:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 11:37:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 11:37:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 11:37:13 --> Final output sent to browser
DEBUG - 2025-05-13 11:37:13 --> Total execution time: 0.0711
INFO - 2025-05-13 11:37:20 --> Config Class Initialized
INFO - 2025-05-13 11:37:20 --> Hooks Class Initialized
DEBUG - 2025-05-13 11:37:20 --> UTF-8 Support Enabled
INFO - 2025-05-13 11:37:20 --> Utf8 Class Initialized
INFO - 2025-05-13 11:37:20 --> URI Class Initialized
INFO - 2025-05-13 11:37:20 --> Router Class Initialized
INFO - 2025-05-13 11:37:20 --> Output Class Initialized
INFO - 2025-05-13 11:37:20 --> Security Class Initialized
DEBUG - 2025-05-13 11:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 11:37:20 --> Input Class Initialized
INFO - 2025-05-13 11:37:20 --> Language Class Initialized
INFO - 2025-05-13 11:37:20 --> Loader Class Initialized
INFO - 2025-05-13 11:37:20 --> Helper loaded: url_helper
INFO - 2025-05-13 11:37:20 --> Helper loaded: form_helper
INFO - 2025-05-13 11:37:20 --> Database Driver Class Initialized
DEBUG - 2025-05-13 11:37:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 11:37:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 11:37:20 --> Controller Class Initialized
INFO - 2025-05-13 11:37:20 --> Model "User_model" initialized
INFO - 2025-05-13 11:37:20 --> Model "Workout_model" initialized
INFO - 2025-05-13 11:37:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 11:37:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 11:37:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 11:37:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 11:37:20 --> Final output sent to browser
DEBUG - 2025-05-13 11:37:20 --> Total execution time: 0.0873
INFO - 2025-05-13 11:37:41 --> Config Class Initialized
INFO - 2025-05-13 11:37:41 --> Hooks Class Initialized
DEBUG - 2025-05-13 11:37:41 --> UTF-8 Support Enabled
INFO - 2025-05-13 11:37:41 --> Utf8 Class Initialized
INFO - 2025-05-13 11:37:41 --> URI Class Initialized
INFO - 2025-05-13 11:37:41 --> Router Class Initialized
INFO - 2025-05-13 11:37:41 --> Output Class Initialized
INFO - 2025-05-13 11:37:41 --> Security Class Initialized
DEBUG - 2025-05-13 11:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 11:37:41 --> Input Class Initialized
INFO - 2025-05-13 11:37:41 --> Language Class Initialized
INFO - 2025-05-13 11:37:41 --> Loader Class Initialized
INFO - 2025-05-13 11:37:41 --> Helper loaded: url_helper
INFO - 2025-05-13 11:37:41 --> Helper loaded: form_helper
INFO - 2025-05-13 11:37:41 --> Database Driver Class Initialized
DEBUG - 2025-05-13 11:37:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 11:37:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 11:37:41 --> Controller Class Initialized
INFO - 2025-05-13 11:37:41 --> Model "User_model" initialized
INFO - 2025-05-13 11:37:41 --> Model "Workout_model" initialized
INFO - 2025-05-13 11:37:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 11:37:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 11:37:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 11:37:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 11:37:41 --> Final output sent to browser
DEBUG - 2025-05-13 11:37:41 --> Total execution time: 0.0884
INFO - 2025-05-13 11:38:59 --> Config Class Initialized
INFO - 2025-05-13 11:38:59 --> Hooks Class Initialized
DEBUG - 2025-05-13 11:38:59 --> UTF-8 Support Enabled
INFO - 2025-05-13 11:38:59 --> Utf8 Class Initialized
INFO - 2025-05-13 11:38:59 --> URI Class Initialized
INFO - 2025-05-13 11:38:59 --> Router Class Initialized
INFO - 2025-05-13 11:38:59 --> Output Class Initialized
INFO - 2025-05-13 11:38:59 --> Security Class Initialized
DEBUG - 2025-05-13 11:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 11:38:59 --> Input Class Initialized
INFO - 2025-05-13 11:38:59 --> Language Class Initialized
INFO - 2025-05-13 11:38:59 --> Loader Class Initialized
INFO - 2025-05-13 11:38:59 --> Helper loaded: url_helper
INFO - 2025-05-13 11:38:59 --> Helper loaded: form_helper
INFO - 2025-05-13 11:38:59 --> Database Driver Class Initialized
DEBUG - 2025-05-13 11:38:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 11:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 11:38:59 --> Controller Class Initialized
INFO - 2025-05-13 11:38:59 --> Model "User_model" initialized
INFO - 2025-05-13 11:38:59 --> Model "Workout_model" initialized
INFO - 2025-05-13 11:38:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 11:38:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 11:38:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 11:38:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 11:38:59 --> Final output sent to browser
DEBUG - 2025-05-13 11:38:59 --> Total execution time: 0.0706
INFO - 2025-05-13 11:42:57 --> Config Class Initialized
INFO - 2025-05-13 11:42:57 --> Hooks Class Initialized
DEBUG - 2025-05-13 11:42:57 --> UTF-8 Support Enabled
INFO - 2025-05-13 11:42:57 --> Utf8 Class Initialized
INFO - 2025-05-13 11:42:57 --> URI Class Initialized
INFO - 2025-05-13 11:42:57 --> Router Class Initialized
INFO - 2025-05-13 11:42:57 --> Output Class Initialized
INFO - 2025-05-13 11:42:57 --> Security Class Initialized
DEBUG - 2025-05-13 11:42:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 11:42:57 --> Input Class Initialized
INFO - 2025-05-13 11:42:57 --> Language Class Initialized
INFO - 2025-05-13 11:42:57 --> Loader Class Initialized
INFO - 2025-05-13 11:42:57 --> Helper loaded: url_helper
INFO - 2025-05-13 11:42:57 --> Helper loaded: form_helper
INFO - 2025-05-13 11:42:57 --> Database Driver Class Initialized
DEBUG - 2025-05-13 11:42:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 11:42:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 11:42:57 --> Controller Class Initialized
INFO - 2025-05-13 11:42:57 --> Model "User_model" initialized
INFO - 2025-05-13 11:42:57 --> Model "Workout_model" initialized
INFO - 2025-05-13 11:42:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 11:42:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 11:42:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 11:42:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 11:42:57 --> Final output sent to browser
DEBUG - 2025-05-13 11:42:57 --> Total execution time: 0.0744
INFO - 2025-05-13 11:43:18 --> Config Class Initialized
INFO - 2025-05-13 11:43:18 --> Hooks Class Initialized
DEBUG - 2025-05-13 11:43:18 --> UTF-8 Support Enabled
INFO - 2025-05-13 11:43:18 --> Utf8 Class Initialized
INFO - 2025-05-13 11:43:18 --> URI Class Initialized
INFO - 2025-05-13 11:43:18 --> Router Class Initialized
INFO - 2025-05-13 11:43:18 --> Output Class Initialized
INFO - 2025-05-13 11:43:18 --> Security Class Initialized
DEBUG - 2025-05-13 11:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 11:43:18 --> Input Class Initialized
INFO - 2025-05-13 11:43:18 --> Language Class Initialized
INFO - 2025-05-13 11:43:18 --> Loader Class Initialized
INFO - 2025-05-13 11:43:18 --> Helper loaded: url_helper
INFO - 2025-05-13 11:43:18 --> Helper loaded: form_helper
INFO - 2025-05-13 11:43:18 --> Database Driver Class Initialized
DEBUG - 2025-05-13 11:43:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 11:43:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 11:43:18 --> Controller Class Initialized
INFO - 2025-05-13 11:43:18 --> Model "User_model" initialized
INFO - 2025-05-13 11:43:18 --> Model "Workout_model" initialized
INFO - 2025-05-13 11:43:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 11:43:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 11:43:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-13 11:43:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 11:43:18 --> Final output sent to browser
DEBUG - 2025-05-13 11:43:18 --> Total execution time: 0.0702
INFO - 2025-05-13 11:43:19 --> Config Class Initialized
INFO - 2025-05-13 11:43:19 --> Hooks Class Initialized
DEBUG - 2025-05-13 11:43:19 --> UTF-8 Support Enabled
INFO - 2025-05-13 11:43:19 --> Utf8 Class Initialized
INFO - 2025-05-13 11:43:19 --> URI Class Initialized
INFO - 2025-05-13 11:43:19 --> Router Class Initialized
INFO - 2025-05-13 11:43:19 --> Output Class Initialized
INFO - 2025-05-13 11:43:19 --> Security Class Initialized
DEBUG - 2025-05-13 11:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 11:43:19 --> Input Class Initialized
INFO - 2025-05-13 11:43:19 --> Language Class Initialized
INFO - 2025-05-13 11:43:19 --> Loader Class Initialized
INFO - 2025-05-13 11:43:20 --> Helper loaded: url_helper
INFO - 2025-05-13 11:43:20 --> Helper loaded: form_helper
INFO - 2025-05-13 11:43:20 --> Database Driver Class Initialized
DEBUG - 2025-05-13 11:43:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 11:43:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 11:43:20 --> Controller Class Initialized
INFO - 2025-05-13 11:43:20 --> Model "User_model" initialized
INFO - 2025-05-13 11:43:20 --> Model "Workout_model" initialized
INFO - 2025-05-13 11:43:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 11:43:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 11:43:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 11:43:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 11:43:20 --> Final output sent to browser
DEBUG - 2025-05-13 11:43:20 --> Total execution time: 0.0695
INFO - 2025-05-13 11:44:40 --> Config Class Initialized
INFO - 2025-05-13 11:44:40 --> Hooks Class Initialized
DEBUG - 2025-05-13 11:44:40 --> UTF-8 Support Enabled
INFO - 2025-05-13 11:44:40 --> Utf8 Class Initialized
INFO - 2025-05-13 11:44:40 --> URI Class Initialized
INFO - 2025-05-13 11:44:40 --> Router Class Initialized
INFO - 2025-05-13 11:44:40 --> Output Class Initialized
INFO - 2025-05-13 11:44:40 --> Security Class Initialized
DEBUG - 2025-05-13 11:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 11:44:40 --> Input Class Initialized
INFO - 2025-05-13 11:44:40 --> Language Class Initialized
INFO - 2025-05-13 11:44:40 --> Loader Class Initialized
INFO - 2025-05-13 11:44:40 --> Helper loaded: url_helper
INFO - 2025-05-13 11:44:40 --> Helper loaded: form_helper
INFO - 2025-05-13 11:44:40 --> Database Driver Class Initialized
DEBUG - 2025-05-13 11:44:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 11:44:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 11:44:40 --> Controller Class Initialized
INFO - 2025-05-13 11:44:40 --> Model "User_model" initialized
INFO - 2025-05-13 11:44:40 --> Model "Workout_model" initialized
INFO - 2025-05-13 11:44:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 11:44:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 11:44:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 11:44:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 11:44:40 --> Final output sent to browser
DEBUG - 2025-05-13 11:44:40 --> Total execution time: 0.0845
INFO - 2025-05-13 11:44:45 --> Config Class Initialized
INFO - 2025-05-13 11:44:45 --> Hooks Class Initialized
DEBUG - 2025-05-13 11:44:45 --> UTF-8 Support Enabled
INFO - 2025-05-13 11:44:45 --> Utf8 Class Initialized
INFO - 2025-05-13 11:44:45 --> URI Class Initialized
INFO - 2025-05-13 11:44:45 --> Router Class Initialized
INFO - 2025-05-13 11:44:45 --> Output Class Initialized
INFO - 2025-05-13 11:44:45 --> Security Class Initialized
DEBUG - 2025-05-13 11:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 11:44:45 --> Input Class Initialized
INFO - 2025-05-13 11:44:45 --> Language Class Initialized
INFO - 2025-05-13 11:44:45 --> Loader Class Initialized
INFO - 2025-05-13 11:44:45 --> Helper loaded: url_helper
INFO - 2025-05-13 11:44:45 --> Helper loaded: form_helper
INFO - 2025-05-13 11:44:45 --> Database Driver Class Initialized
DEBUG - 2025-05-13 11:44:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 11:44:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 11:44:45 --> Controller Class Initialized
INFO - 2025-05-13 11:44:45 --> Model "User_model" initialized
INFO - 2025-05-13 11:44:45 --> Model "Workout_model" initialized
INFO - 2025-05-13 11:44:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 11:44:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 11:44:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 11:44:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 11:44:45 --> Final output sent to browser
DEBUG - 2025-05-13 11:44:45 --> Total execution time: 0.0875
INFO - 2025-05-13 11:45:16 --> Config Class Initialized
INFO - 2025-05-13 11:45:16 --> Hooks Class Initialized
DEBUG - 2025-05-13 11:45:16 --> UTF-8 Support Enabled
INFO - 2025-05-13 11:45:16 --> Utf8 Class Initialized
INFO - 2025-05-13 11:45:16 --> URI Class Initialized
INFO - 2025-05-13 11:45:16 --> Router Class Initialized
INFO - 2025-05-13 11:45:16 --> Output Class Initialized
INFO - 2025-05-13 11:45:16 --> Security Class Initialized
DEBUG - 2025-05-13 11:45:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 11:45:16 --> Input Class Initialized
INFO - 2025-05-13 11:45:16 --> Language Class Initialized
INFO - 2025-05-13 11:45:16 --> Loader Class Initialized
INFO - 2025-05-13 11:45:16 --> Helper loaded: url_helper
INFO - 2025-05-13 11:45:16 --> Helper loaded: form_helper
INFO - 2025-05-13 11:45:16 --> Database Driver Class Initialized
DEBUG - 2025-05-13 11:45:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 11:45:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 11:45:17 --> Controller Class Initialized
INFO - 2025-05-13 11:45:17 --> Model "User_model" initialized
INFO - 2025-05-13 11:45:17 --> Model "Workout_model" initialized
INFO - 2025-05-13 11:45:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 11:45:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 11:45:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 11:45:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 11:45:17 --> Final output sent to browser
DEBUG - 2025-05-13 11:45:17 --> Total execution time: 0.0674
INFO - 2025-05-13 11:47:42 --> Config Class Initialized
INFO - 2025-05-13 11:47:42 --> Hooks Class Initialized
DEBUG - 2025-05-13 11:47:42 --> UTF-8 Support Enabled
INFO - 2025-05-13 11:47:42 --> Utf8 Class Initialized
INFO - 2025-05-13 11:47:42 --> URI Class Initialized
INFO - 2025-05-13 11:47:42 --> Router Class Initialized
INFO - 2025-05-13 11:47:42 --> Output Class Initialized
INFO - 2025-05-13 11:47:42 --> Security Class Initialized
DEBUG - 2025-05-13 11:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 11:47:42 --> Input Class Initialized
INFO - 2025-05-13 11:47:42 --> Language Class Initialized
INFO - 2025-05-13 11:47:42 --> Loader Class Initialized
INFO - 2025-05-13 11:47:42 --> Helper loaded: url_helper
INFO - 2025-05-13 11:47:42 --> Helper loaded: form_helper
INFO - 2025-05-13 11:47:42 --> Database Driver Class Initialized
DEBUG - 2025-05-13 11:47:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 11:47:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 11:47:42 --> Controller Class Initialized
INFO - 2025-05-13 11:47:42 --> Model "User_model" initialized
INFO - 2025-05-13 11:47:42 --> Model "Workout_model" initialized
INFO - 2025-05-13 11:47:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 11:47:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 11:47:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 11:47:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 11:47:42 --> Final output sent to browser
DEBUG - 2025-05-13 11:47:42 --> Total execution time: 0.0722
INFO - 2025-05-13 11:47:47 --> Config Class Initialized
INFO - 2025-05-13 11:47:47 --> Hooks Class Initialized
DEBUG - 2025-05-13 11:47:47 --> UTF-8 Support Enabled
INFO - 2025-05-13 11:47:47 --> Utf8 Class Initialized
INFO - 2025-05-13 11:47:47 --> URI Class Initialized
INFO - 2025-05-13 11:47:47 --> Router Class Initialized
INFO - 2025-05-13 11:47:47 --> Output Class Initialized
INFO - 2025-05-13 11:47:47 --> Security Class Initialized
DEBUG - 2025-05-13 11:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 11:47:47 --> Input Class Initialized
INFO - 2025-05-13 11:47:47 --> Language Class Initialized
INFO - 2025-05-13 11:47:47 --> Loader Class Initialized
INFO - 2025-05-13 11:47:47 --> Helper loaded: url_helper
INFO - 2025-05-13 11:47:47 --> Helper loaded: form_helper
INFO - 2025-05-13 11:47:47 --> Database Driver Class Initialized
DEBUG - 2025-05-13 11:47:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 11:47:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 11:47:47 --> Controller Class Initialized
INFO - 2025-05-13 11:47:47 --> Model "User_model" initialized
INFO - 2025-05-13 11:47:47 --> Model "Workout_model" initialized
INFO - 2025-05-13 11:47:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 11:47:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 11:47:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 11:47:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 11:47:47 --> Final output sent to browser
DEBUG - 2025-05-13 11:47:47 --> Total execution time: 0.0798
INFO - 2025-05-13 11:47:54 --> Config Class Initialized
INFO - 2025-05-13 11:47:54 --> Hooks Class Initialized
DEBUG - 2025-05-13 11:47:54 --> UTF-8 Support Enabled
INFO - 2025-05-13 11:47:54 --> Utf8 Class Initialized
INFO - 2025-05-13 11:47:54 --> URI Class Initialized
INFO - 2025-05-13 11:47:54 --> Router Class Initialized
INFO - 2025-05-13 11:47:54 --> Output Class Initialized
INFO - 2025-05-13 11:47:54 --> Security Class Initialized
DEBUG - 2025-05-13 11:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 11:47:54 --> Input Class Initialized
INFO - 2025-05-13 11:47:54 --> Language Class Initialized
INFO - 2025-05-13 11:47:54 --> Loader Class Initialized
INFO - 2025-05-13 11:47:54 --> Helper loaded: url_helper
INFO - 2025-05-13 11:47:54 --> Helper loaded: form_helper
INFO - 2025-05-13 11:47:54 --> Database Driver Class Initialized
DEBUG - 2025-05-13 11:47:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 11:47:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 11:47:54 --> Controller Class Initialized
INFO - 2025-05-13 11:47:54 --> Model "User_model" initialized
INFO - 2025-05-13 11:47:54 --> Model "Workout_model" initialized
INFO - 2025-05-13 11:47:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 11:47:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 11:47:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-13 11:47:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 11:47:54 --> Final output sent to browser
DEBUG - 2025-05-13 11:47:54 --> Total execution time: 0.0592
INFO - 2025-05-13 11:48:05 --> Config Class Initialized
INFO - 2025-05-13 11:48:05 --> Hooks Class Initialized
DEBUG - 2025-05-13 11:48:05 --> UTF-8 Support Enabled
INFO - 2025-05-13 11:48:05 --> Utf8 Class Initialized
INFO - 2025-05-13 11:48:05 --> URI Class Initialized
INFO - 2025-05-13 11:48:05 --> Router Class Initialized
INFO - 2025-05-13 11:48:05 --> Output Class Initialized
INFO - 2025-05-13 11:48:05 --> Security Class Initialized
DEBUG - 2025-05-13 11:48:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 11:48:05 --> Input Class Initialized
INFO - 2025-05-13 11:48:05 --> Language Class Initialized
INFO - 2025-05-13 11:48:05 --> Loader Class Initialized
INFO - 2025-05-13 11:48:05 --> Helper loaded: url_helper
INFO - 2025-05-13 11:48:05 --> Helper loaded: form_helper
INFO - 2025-05-13 11:48:05 --> Database Driver Class Initialized
DEBUG - 2025-05-13 11:48:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 11:48:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 11:48:05 --> Controller Class Initialized
INFO - 2025-05-13 11:48:05 --> Model "User_model" initialized
INFO - 2025-05-13 11:48:05 --> Model "Workout_model" initialized
INFO - 2025-05-13 11:48:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 11:48:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 11:48:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-13 11:48:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 11:48:05 --> Final output sent to browser
DEBUG - 2025-05-13 11:48:05 --> Total execution time: 0.0670
INFO - 2025-05-13 11:50:33 --> Config Class Initialized
INFO - 2025-05-13 11:50:33 --> Hooks Class Initialized
DEBUG - 2025-05-13 11:50:33 --> UTF-8 Support Enabled
INFO - 2025-05-13 11:50:33 --> Utf8 Class Initialized
INFO - 2025-05-13 11:50:33 --> URI Class Initialized
INFO - 2025-05-13 11:50:33 --> Router Class Initialized
INFO - 2025-05-13 11:50:33 --> Output Class Initialized
INFO - 2025-05-13 11:50:33 --> Security Class Initialized
DEBUG - 2025-05-13 11:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 11:50:33 --> Input Class Initialized
INFO - 2025-05-13 11:50:33 --> Language Class Initialized
INFO - 2025-05-13 11:50:33 --> Loader Class Initialized
INFO - 2025-05-13 11:50:33 --> Helper loaded: url_helper
INFO - 2025-05-13 11:50:33 --> Helper loaded: form_helper
INFO - 2025-05-13 11:50:33 --> Database Driver Class Initialized
DEBUG - 2025-05-13 11:50:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 11:50:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 11:50:33 --> Controller Class Initialized
INFO - 2025-05-13 11:50:33 --> Model "User_model" initialized
INFO - 2025-05-13 11:50:33 --> Model "Workout_model" initialized
INFO - 2025-05-13 11:50:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 11:50:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 11:50:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-13 11:50:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 11:50:33 --> Final output sent to browser
DEBUG - 2025-05-13 11:50:33 --> Total execution time: 0.0813
INFO - 2025-05-13 11:50:39 --> Config Class Initialized
INFO - 2025-05-13 11:50:39 --> Hooks Class Initialized
DEBUG - 2025-05-13 11:50:39 --> UTF-8 Support Enabled
INFO - 2025-05-13 11:50:39 --> Utf8 Class Initialized
INFO - 2025-05-13 11:50:39 --> URI Class Initialized
INFO - 2025-05-13 11:50:39 --> Router Class Initialized
INFO - 2025-05-13 11:50:39 --> Output Class Initialized
INFO - 2025-05-13 11:50:39 --> Security Class Initialized
DEBUG - 2025-05-13 11:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 11:50:39 --> Input Class Initialized
INFO - 2025-05-13 11:50:39 --> Language Class Initialized
INFO - 2025-05-13 11:50:39 --> Loader Class Initialized
INFO - 2025-05-13 11:50:39 --> Helper loaded: url_helper
INFO - 2025-05-13 11:50:39 --> Helper loaded: form_helper
INFO - 2025-05-13 11:50:39 --> Database Driver Class Initialized
DEBUG - 2025-05-13 11:50:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 11:50:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 11:50:39 --> Controller Class Initialized
INFO - 2025-05-13 11:50:39 --> Model "User_model" initialized
INFO - 2025-05-13 11:50:39 --> Model "Workout_model" initialized
INFO - 2025-05-13 11:50:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 11:50:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 11:50:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-13 11:50:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 11:50:39 --> Final output sent to browser
DEBUG - 2025-05-13 11:50:39 --> Total execution time: 0.0813
INFO - 2025-05-13 11:50:47 --> Config Class Initialized
INFO - 2025-05-13 11:50:47 --> Hooks Class Initialized
DEBUG - 2025-05-13 11:50:47 --> UTF-8 Support Enabled
INFO - 2025-05-13 11:50:47 --> Utf8 Class Initialized
INFO - 2025-05-13 11:50:47 --> URI Class Initialized
INFO - 2025-05-13 11:50:47 --> Router Class Initialized
INFO - 2025-05-13 11:50:47 --> Output Class Initialized
INFO - 2025-05-13 11:50:47 --> Security Class Initialized
DEBUG - 2025-05-13 11:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 11:50:47 --> Input Class Initialized
INFO - 2025-05-13 11:50:47 --> Language Class Initialized
INFO - 2025-05-13 11:50:47 --> Loader Class Initialized
INFO - 2025-05-13 11:50:47 --> Helper loaded: url_helper
INFO - 2025-05-13 11:50:47 --> Helper loaded: form_helper
INFO - 2025-05-13 11:50:47 --> Database Driver Class Initialized
DEBUG - 2025-05-13 11:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 11:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 11:50:47 --> Controller Class Initialized
INFO - 2025-05-13 11:50:47 --> Model "User_model" initialized
INFO - 2025-05-13 11:50:47 --> Model "Workout_model" initialized
INFO - 2025-05-13 11:50:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 11:50:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 11:50:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-13 11:50:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 11:50:47 --> Final output sent to browser
DEBUG - 2025-05-13 11:50:47 --> Total execution time: 0.0661
INFO - 2025-05-13 11:51:02 --> Config Class Initialized
INFO - 2025-05-13 11:51:02 --> Hooks Class Initialized
DEBUG - 2025-05-13 11:51:03 --> UTF-8 Support Enabled
INFO - 2025-05-13 11:51:03 --> Utf8 Class Initialized
INFO - 2025-05-13 11:51:03 --> URI Class Initialized
INFO - 2025-05-13 11:51:03 --> Router Class Initialized
INFO - 2025-05-13 11:51:03 --> Output Class Initialized
INFO - 2025-05-13 11:51:03 --> Security Class Initialized
DEBUG - 2025-05-13 11:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 11:51:03 --> Input Class Initialized
INFO - 2025-05-13 11:51:03 --> Language Class Initialized
INFO - 2025-05-13 11:51:03 --> Loader Class Initialized
INFO - 2025-05-13 11:51:03 --> Helper loaded: url_helper
INFO - 2025-05-13 11:51:03 --> Helper loaded: form_helper
INFO - 2025-05-13 11:51:03 --> Database Driver Class Initialized
DEBUG - 2025-05-13 11:51:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 11:51:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 11:51:03 --> Controller Class Initialized
INFO - 2025-05-13 11:51:03 --> Model "User_model" initialized
INFO - 2025-05-13 11:51:03 --> Model "Workout_model" initialized
INFO - 2025-05-13 11:51:03 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 11:51:03 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 11:51:03 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-13 11:51:03 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 11:51:03 --> Final output sent to browser
DEBUG - 2025-05-13 11:51:03 --> Total execution time: 0.0710
INFO - 2025-05-13 11:51:16 --> Config Class Initialized
INFO - 2025-05-13 11:51:16 --> Hooks Class Initialized
DEBUG - 2025-05-13 11:51:16 --> UTF-8 Support Enabled
INFO - 2025-05-13 11:51:16 --> Utf8 Class Initialized
INFO - 2025-05-13 11:51:16 --> URI Class Initialized
INFO - 2025-05-13 11:51:16 --> Router Class Initialized
INFO - 2025-05-13 11:51:16 --> Output Class Initialized
INFO - 2025-05-13 11:51:16 --> Security Class Initialized
DEBUG - 2025-05-13 11:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 11:51:16 --> Input Class Initialized
INFO - 2025-05-13 11:51:16 --> Language Class Initialized
INFO - 2025-05-13 11:51:16 --> Loader Class Initialized
INFO - 2025-05-13 11:51:16 --> Helper loaded: url_helper
INFO - 2025-05-13 11:51:16 --> Helper loaded: form_helper
INFO - 2025-05-13 11:51:16 --> Database Driver Class Initialized
DEBUG - 2025-05-13 11:51:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 11:51:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 11:51:16 --> Controller Class Initialized
INFO - 2025-05-13 11:51:16 --> Model "User_model" initialized
INFO - 2025-05-13 11:51:16 --> Model "Workout_model" initialized
INFO - 2025-05-13 11:51:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 11:51:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 11:51:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-13 11:51:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 11:51:16 --> Final output sent to browser
DEBUG - 2025-05-13 11:51:16 --> Total execution time: 0.0838
INFO - 2025-05-13 11:51:43 --> Config Class Initialized
INFO - 2025-05-13 11:51:43 --> Hooks Class Initialized
DEBUG - 2025-05-13 11:51:43 --> UTF-8 Support Enabled
INFO - 2025-05-13 11:51:43 --> Utf8 Class Initialized
INFO - 2025-05-13 11:51:43 --> URI Class Initialized
INFO - 2025-05-13 11:51:43 --> Router Class Initialized
INFO - 2025-05-13 11:51:43 --> Output Class Initialized
INFO - 2025-05-13 11:51:43 --> Security Class Initialized
DEBUG - 2025-05-13 11:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 11:51:43 --> Input Class Initialized
INFO - 2025-05-13 11:51:43 --> Language Class Initialized
INFO - 2025-05-13 11:51:43 --> Loader Class Initialized
INFO - 2025-05-13 11:51:43 --> Helper loaded: url_helper
INFO - 2025-05-13 11:51:43 --> Helper loaded: form_helper
INFO - 2025-05-13 11:51:43 --> Database Driver Class Initialized
DEBUG - 2025-05-13 11:51:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 11:51:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 11:51:43 --> Controller Class Initialized
INFO - 2025-05-13 11:51:43 --> Model "User_model" initialized
INFO - 2025-05-13 11:51:43 --> Model "Workout_model" initialized
INFO - 2025-05-13 11:51:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 11:51:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 11:51:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-13 11:51:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 11:51:43 --> Final output sent to browser
DEBUG - 2025-05-13 11:51:43 --> Total execution time: 0.0682
INFO - 2025-05-13 13:46:05 --> Config Class Initialized
INFO - 2025-05-13 13:46:05 --> Hooks Class Initialized
DEBUG - 2025-05-13 13:46:05 --> UTF-8 Support Enabled
INFO - 2025-05-13 13:46:05 --> Utf8 Class Initialized
INFO - 2025-05-13 13:46:05 --> URI Class Initialized
INFO - 2025-05-13 13:46:05 --> Router Class Initialized
INFO - 2025-05-13 13:46:05 --> Output Class Initialized
INFO - 2025-05-13 13:46:05 --> Security Class Initialized
DEBUG - 2025-05-13 13:46:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 13:46:05 --> Input Class Initialized
INFO - 2025-05-13 13:46:05 --> Language Class Initialized
INFO - 2025-05-13 13:46:05 --> Loader Class Initialized
INFO - 2025-05-13 13:46:05 --> Helper loaded: url_helper
INFO - 2025-05-13 13:46:05 --> Helper loaded: form_helper
INFO - 2025-05-13 13:46:05 --> Database Driver Class Initialized
DEBUG - 2025-05-13 13:46:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 13:46:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 13:46:05 --> Controller Class Initialized
INFO - 2025-05-13 13:46:05 --> Model "User_model" initialized
INFO - 2025-05-13 13:46:05 --> Model "Workout_model" initialized
INFO - 2025-05-13 13:46:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 13:46:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 13:46:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-13 13:46:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 13:46:05 --> Final output sent to browser
DEBUG - 2025-05-13 13:46:05 --> Total execution time: 0.1079
INFO - 2025-05-13 13:46:07 --> Config Class Initialized
INFO - 2025-05-13 13:46:07 --> Hooks Class Initialized
DEBUG - 2025-05-13 13:46:07 --> UTF-8 Support Enabled
INFO - 2025-05-13 13:46:07 --> Utf8 Class Initialized
INFO - 2025-05-13 13:46:07 --> URI Class Initialized
INFO - 2025-05-13 13:46:07 --> Router Class Initialized
INFO - 2025-05-13 13:46:07 --> Output Class Initialized
INFO - 2025-05-13 13:46:07 --> Security Class Initialized
DEBUG - 2025-05-13 13:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 13:46:07 --> Input Class Initialized
INFO - 2025-05-13 13:46:07 --> Language Class Initialized
INFO - 2025-05-13 13:46:07 --> Loader Class Initialized
INFO - 2025-05-13 13:46:07 --> Helper loaded: url_helper
INFO - 2025-05-13 13:46:07 --> Helper loaded: form_helper
INFO - 2025-05-13 13:46:07 --> Database Driver Class Initialized
DEBUG - 2025-05-13 13:46:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 13:46:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 13:46:08 --> Controller Class Initialized
INFO - 2025-05-13 13:46:08 --> Model "Workout_model" initialized
INFO - 2025-05-13 13:46:08 --> Model "User_model" initialized
INFO - 2025-05-13 13:46:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 13:46:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 13:46:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-13 13:46:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 13:46:08 --> Final output sent to browser
DEBUG - 2025-05-13 13:46:08 --> Total execution time: 0.0788
INFO - 2025-05-13 13:46:09 --> Config Class Initialized
INFO - 2025-05-13 13:46:09 --> Hooks Class Initialized
DEBUG - 2025-05-13 13:46:09 --> UTF-8 Support Enabled
INFO - 2025-05-13 13:46:09 --> Utf8 Class Initialized
INFO - 2025-05-13 13:46:09 --> URI Class Initialized
INFO - 2025-05-13 13:46:09 --> Router Class Initialized
INFO - 2025-05-13 13:46:09 --> Output Class Initialized
INFO - 2025-05-13 13:46:09 --> Security Class Initialized
DEBUG - 2025-05-13 13:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 13:46:10 --> Input Class Initialized
INFO - 2025-05-13 13:46:10 --> Language Class Initialized
INFO - 2025-05-13 13:46:10 --> Loader Class Initialized
INFO - 2025-05-13 13:46:10 --> Helper loaded: url_helper
INFO - 2025-05-13 13:46:10 --> Helper loaded: form_helper
INFO - 2025-05-13 13:46:10 --> Database Driver Class Initialized
DEBUG - 2025-05-13 13:46:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 13:46:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 13:46:10 --> Controller Class Initialized
INFO - 2025-05-13 13:46:10 --> Model "User_model" initialized
INFO - 2025-05-13 13:46:10 --> Model "Workout_model" initialized
INFO - 2025-05-13 13:46:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 13:46:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 13:46:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 13:46:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 13:46:10 --> Final output sent to browser
DEBUG - 2025-05-13 13:46:10 --> Total execution time: 0.0643
INFO - 2025-05-13 13:46:14 --> Config Class Initialized
INFO - 2025-05-13 13:46:14 --> Hooks Class Initialized
DEBUG - 2025-05-13 13:46:14 --> UTF-8 Support Enabled
INFO - 2025-05-13 13:46:14 --> Utf8 Class Initialized
INFO - 2025-05-13 13:46:14 --> URI Class Initialized
INFO - 2025-05-13 13:46:14 --> Router Class Initialized
INFO - 2025-05-13 13:46:14 --> Output Class Initialized
INFO - 2025-05-13 13:46:14 --> Security Class Initialized
DEBUG - 2025-05-13 13:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 13:46:14 --> Input Class Initialized
INFO - 2025-05-13 13:46:14 --> Language Class Initialized
INFO - 2025-05-13 13:46:14 --> Loader Class Initialized
INFO - 2025-05-13 13:46:14 --> Helper loaded: url_helper
INFO - 2025-05-13 13:46:14 --> Helper loaded: form_helper
INFO - 2025-05-13 13:46:14 --> Database Driver Class Initialized
DEBUG - 2025-05-13 13:46:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 13:46:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 13:46:14 --> Controller Class Initialized
INFO - 2025-05-13 13:46:14 --> Model "User_model" initialized
INFO - 2025-05-13 13:46:14 --> Model "Workout_model" initialized
INFO - 2025-05-13 13:46:14 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 13:46:14 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 13:46:14 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 13:46:14 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 13:46:14 --> Final output sent to browser
DEBUG - 2025-05-13 13:46:14 --> Total execution time: 0.0936
INFO - 2025-05-13 13:46:44 --> Config Class Initialized
INFO - 2025-05-13 13:46:44 --> Hooks Class Initialized
DEBUG - 2025-05-13 13:46:44 --> UTF-8 Support Enabled
INFO - 2025-05-13 13:46:44 --> Utf8 Class Initialized
INFO - 2025-05-13 13:46:44 --> URI Class Initialized
INFO - 2025-05-13 13:46:44 --> Router Class Initialized
INFO - 2025-05-13 13:46:44 --> Output Class Initialized
INFO - 2025-05-13 13:46:44 --> Security Class Initialized
DEBUG - 2025-05-13 13:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 13:46:44 --> Input Class Initialized
INFO - 2025-05-13 13:46:44 --> Language Class Initialized
INFO - 2025-05-13 13:46:44 --> Loader Class Initialized
INFO - 2025-05-13 13:46:44 --> Helper loaded: url_helper
INFO - 2025-05-13 13:46:44 --> Helper loaded: form_helper
INFO - 2025-05-13 13:46:44 --> Database Driver Class Initialized
DEBUG - 2025-05-13 13:46:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 13:46:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 13:46:44 --> Controller Class Initialized
INFO - 2025-05-13 13:46:44 --> Model "User_model" initialized
INFO - 2025-05-13 13:46:44 --> Model "Workout_model" initialized
INFO - 2025-05-13 13:46:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 13:46:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 13:46:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 13:46:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 13:46:44 --> Final output sent to browser
DEBUG - 2025-05-13 13:46:44 --> Total execution time: 0.0674
INFO - 2025-05-13 13:46:46 --> Config Class Initialized
INFO - 2025-05-13 13:46:46 --> Hooks Class Initialized
DEBUG - 2025-05-13 13:46:46 --> UTF-8 Support Enabled
INFO - 2025-05-13 13:46:46 --> Utf8 Class Initialized
INFO - 2025-05-13 13:46:46 --> URI Class Initialized
INFO - 2025-05-13 13:46:46 --> Router Class Initialized
INFO - 2025-05-13 13:46:46 --> Output Class Initialized
INFO - 2025-05-13 13:46:46 --> Security Class Initialized
DEBUG - 2025-05-13 13:46:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 13:46:46 --> Input Class Initialized
INFO - 2025-05-13 13:46:46 --> Language Class Initialized
INFO - 2025-05-13 13:46:46 --> Loader Class Initialized
INFO - 2025-05-13 13:46:46 --> Helper loaded: url_helper
INFO - 2025-05-13 13:46:46 --> Helper loaded: form_helper
INFO - 2025-05-13 13:46:46 --> Database Driver Class Initialized
DEBUG - 2025-05-13 13:46:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 13:46:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 13:46:46 --> Controller Class Initialized
INFO - 2025-05-13 13:46:46 --> Model "User_model" initialized
INFO - 2025-05-13 13:46:46 --> Model "Workout_model" initialized
INFO - 2025-05-13 13:46:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 13:46:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 13:46:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-13 13:46:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 13:46:46 --> Final output sent to browser
DEBUG - 2025-05-13 13:46:46 --> Total execution time: 0.0670
INFO - 2025-05-13 13:46:47 --> Config Class Initialized
INFO - 2025-05-13 13:46:47 --> Hooks Class Initialized
DEBUG - 2025-05-13 13:46:47 --> UTF-8 Support Enabled
INFO - 2025-05-13 13:46:47 --> Utf8 Class Initialized
INFO - 2025-05-13 13:46:47 --> URI Class Initialized
INFO - 2025-05-13 13:46:47 --> Router Class Initialized
INFO - 2025-05-13 13:46:47 --> Output Class Initialized
INFO - 2025-05-13 13:46:47 --> Security Class Initialized
DEBUG - 2025-05-13 13:46:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 13:46:47 --> Input Class Initialized
INFO - 2025-05-13 13:46:47 --> Language Class Initialized
INFO - 2025-05-13 13:46:47 --> Loader Class Initialized
INFO - 2025-05-13 13:46:47 --> Helper loaded: url_helper
INFO - 2025-05-13 13:46:47 --> Helper loaded: form_helper
INFO - 2025-05-13 13:46:47 --> Database Driver Class Initialized
DEBUG - 2025-05-13 13:46:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 13:46:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 13:46:47 --> Controller Class Initialized
INFO - 2025-05-13 13:46:47 --> Model "Workout_model" initialized
INFO - 2025-05-13 13:46:47 --> Model "User_model" initialized
INFO - 2025-05-13 13:46:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 13:46:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 13:46:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-13 13:46:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 13:46:47 --> Final output sent to browser
DEBUG - 2025-05-13 13:46:47 --> Total execution time: 0.0711
INFO - 2025-05-13 13:47:21 --> Config Class Initialized
INFO - 2025-05-13 13:47:21 --> Hooks Class Initialized
DEBUG - 2025-05-13 13:47:21 --> UTF-8 Support Enabled
INFO - 2025-05-13 13:47:21 --> Utf8 Class Initialized
INFO - 2025-05-13 13:47:21 --> URI Class Initialized
INFO - 2025-05-13 13:47:21 --> Router Class Initialized
INFO - 2025-05-13 13:47:21 --> Output Class Initialized
INFO - 2025-05-13 13:47:21 --> Security Class Initialized
DEBUG - 2025-05-13 13:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 13:47:21 --> Input Class Initialized
INFO - 2025-05-13 13:47:21 --> Language Class Initialized
INFO - 2025-05-13 13:47:21 --> Loader Class Initialized
INFO - 2025-05-13 13:47:21 --> Helper loaded: url_helper
INFO - 2025-05-13 13:47:21 --> Helper loaded: form_helper
INFO - 2025-05-13 13:47:21 --> Database Driver Class Initialized
DEBUG - 2025-05-13 13:47:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 13:47:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 13:47:21 --> Controller Class Initialized
INFO - 2025-05-13 13:47:21 --> Model "User_model" initialized
INFO - 2025-05-13 13:47:21 --> Model "Workout_model" initialized
INFO - 2025-05-13 13:47:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 13:47:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 13:47:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 13:47:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 13:47:21 --> Final output sent to browser
DEBUG - 2025-05-13 13:47:21 --> Total execution time: 0.1028
INFO - 2025-05-13 13:47:22 --> Config Class Initialized
INFO - 2025-05-13 13:47:22 --> Hooks Class Initialized
DEBUG - 2025-05-13 13:47:22 --> UTF-8 Support Enabled
INFO - 2025-05-13 13:47:22 --> Utf8 Class Initialized
INFO - 2025-05-13 13:47:22 --> URI Class Initialized
INFO - 2025-05-13 13:47:22 --> Router Class Initialized
INFO - 2025-05-13 13:47:22 --> Output Class Initialized
INFO - 2025-05-13 13:47:22 --> Security Class Initialized
DEBUG - 2025-05-13 13:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 13:47:22 --> Input Class Initialized
INFO - 2025-05-13 13:47:22 --> Language Class Initialized
INFO - 2025-05-13 13:47:22 --> Loader Class Initialized
INFO - 2025-05-13 13:47:22 --> Helper loaded: url_helper
INFO - 2025-05-13 13:47:22 --> Helper loaded: form_helper
INFO - 2025-05-13 13:47:22 --> Database Driver Class Initialized
DEBUG - 2025-05-13 13:47:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 13:47:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 13:47:22 --> Controller Class Initialized
INFO - 2025-05-13 13:47:22 --> Model "User_model" initialized
INFO - 2025-05-13 13:47:22 --> Model "Workout_model" initialized
INFO - 2025-05-13 13:47:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 13:47:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 13:47:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-13 13:47:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 13:47:22 --> Final output sent to browser
DEBUG - 2025-05-13 13:47:22 --> Total execution time: 0.0963
INFO - 2025-05-13 13:47:30 --> Config Class Initialized
INFO - 2025-05-13 13:47:30 --> Hooks Class Initialized
DEBUG - 2025-05-13 13:47:30 --> UTF-8 Support Enabled
INFO - 2025-05-13 13:47:30 --> Utf8 Class Initialized
INFO - 2025-05-13 13:47:30 --> URI Class Initialized
INFO - 2025-05-13 13:47:30 --> Router Class Initialized
INFO - 2025-05-13 13:47:30 --> Output Class Initialized
INFO - 2025-05-13 13:47:30 --> Security Class Initialized
DEBUG - 2025-05-13 13:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 13:47:30 --> Input Class Initialized
INFO - 2025-05-13 13:47:30 --> Language Class Initialized
INFO - 2025-05-13 13:47:30 --> Loader Class Initialized
INFO - 2025-05-13 13:47:30 --> Helper loaded: url_helper
INFO - 2025-05-13 13:47:30 --> Helper loaded: form_helper
INFO - 2025-05-13 13:47:30 --> Database Driver Class Initialized
DEBUG - 2025-05-13 13:47:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 13:47:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 13:47:30 --> Controller Class Initialized
INFO - 2025-05-13 13:47:30 --> Model "User_model" initialized
INFO - 2025-05-13 13:47:30 --> Model "Workout_model" initialized
INFO - 2025-05-13 13:47:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 13:47:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 13:47:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 13:47:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 13:47:30 --> Final output sent to browser
DEBUG - 2025-05-13 13:47:30 --> Total execution time: 0.0820
INFO - 2025-05-13 13:47:39 --> Config Class Initialized
INFO - 2025-05-13 13:47:39 --> Hooks Class Initialized
DEBUG - 2025-05-13 13:47:39 --> UTF-8 Support Enabled
INFO - 2025-05-13 13:47:39 --> Utf8 Class Initialized
INFO - 2025-05-13 13:47:39 --> URI Class Initialized
INFO - 2025-05-13 13:47:39 --> Router Class Initialized
INFO - 2025-05-13 13:47:39 --> Output Class Initialized
INFO - 2025-05-13 13:47:39 --> Security Class Initialized
DEBUG - 2025-05-13 13:47:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 13:47:39 --> Input Class Initialized
INFO - 2025-05-13 13:47:39 --> Language Class Initialized
INFO - 2025-05-13 13:47:39 --> Loader Class Initialized
INFO - 2025-05-13 13:47:39 --> Helper loaded: url_helper
INFO - 2025-05-13 13:47:39 --> Helper loaded: form_helper
INFO - 2025-05-13 13:47:39 --> Database Driver Class Initialized
DEBUG - 2025-05-13 13:47:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 13:47:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 13:47:39 --> Controller Class Initialized
INFO - 2025-05-13 13:47:39 --> Model "Workout_model" initialized
INFO - 2025-05-13 13:47:39 --> Model "User_model" initialized
INFO - 2025-05-13 13:47:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 13:47:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 13:47:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-13 13:47:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 13:47:39 --> Final output sent to browser
DEBUG - 2025-05-13 13:47:39 --> Total execution time: 0.0808
INFO - 2025-05-13 13:47:52 --> Config Class Initialized
INFO - 2025-05-13 13:47:52 --> Hooks Class Initialized
DEBUG - 2025-05-13 13:47:52 --> UTF-8 Support Enabled
INFO - 2025-05-13 13:47:52 --> Utf8 Class Initialized
INFO - 2025-05-13 13:47:52 --> URI Class Initialized
INFO - 2025-05-13 13:47:52 --> Router Class Initialized
INFO - 2025-05-13 13:47:52 --> Output Class Initialized
INFO - 2025-05-13 13:47:52 --> Security Class Initialized
DEBUG - 2025-05-13 13:47:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 13:47:52 --> Input Class Initialized
INFO - 2025-05-13 13:47:52 --> Language Class Initialized
INFO - 2025-05-13 13:47:52 --> Loader Class Initialized
INFO - 2025-05-13 13:47:52 --> Helper loaded: url_helper
INFO - 2025-05-13 13:47:52 --> Helper loaded: form_helper
INFO - 2025-05-13 13:47:52 --> Database Driver Class Initialized
DEBUG - 2025-05-13 13:47:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 13:47:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 13:47:52 --> Controller Class Initialized
INFO - 2025-05-13 13:47:52 --> Model "User_model" initialized
INFO - 2025-05-13 13:47:52 --> Model "Workout_model" initialized
INFO - 2025-05-13 13:47:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 13:47:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 13:47:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 13:47:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 13:47:52 --> Final output sent to browser
DEBUG - 2025-05-13 13:47:52 --> Total execution time: 0.0861
INFO - 2025-05-13 13:50:56 --> Config Class Initialized
INFO - 2025-05-13 13:50:56 --> Hooks Class Initialized
DEBUG - 2025-05-13 13:50:56 --> UTF-8 Support Enabled
INFO - 2025-05-13 13:50:56 --> Utf8 Class Initialized
INFO - 2025-05-13 13:50:56 --> URI Class Initialized
INFO - 2025-05-13 13:50:56 --> Router Class Initialized
INFO - 2025-05-13 13:50:56 --> Output Class Initialized
INFO - 2025-05-13 13:50:56 --> Security Class Initialized
DEBUG - 2025-05-13 13:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 13:50:56 --> Input Class Initialized
INFO - 2025-05-13 13:50:56 --> Language Class Initialized
INFO - 2025-05-13 13:50:56 --> Loader Class Initialized
INFO - 2025-05-13 13:50:56 --> Helper loaded: url_helper
INFO - 2025-05-13 13:50:56 --> Helper loaded: form_helper
INFO - 2025-05-13 13:50:56 --> Database Driver Class Initialized
DEBUG - 2025-05-13 13:50:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 13:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 13:50:56 --> Controller Class Initialized
INFO - 2025-05-13 13:50:56 --> Model "User_model" initialized
INFO - 2025-05-13 13:50:56 --> Model "Workout_model" initialized
INFO - 2025-05-13 13:50:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 13:50:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 13:50:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 13:50:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 13:50:56 --> Final output sent to browser
DEBUG - 2025-05-13 13:50:56 --> Total execution time: 0.0720
INFO - 2025-05-13 13:51:58 --> Config Class Initialized
INFO - 2025-05-13 13:51:58 --> Hooks Class Initialized
DEBUG - 2025-05-13 13:51:58 --> UTF-8 Support Enabled
INFO - 2025-05-13 13:51:58 --> Utf8 Class Initialized
INFO - 2025-05-13 13:51:58 --> URI Class Initialized
INFO - 2025-05-13 13:51:58 --> Router Class Initialized
INFO - 2025-05-13 13:51:58 --> Output Class Initialized
INFO - 2025-05-13 13:51:58 --> Security Class Initialized
DEBUG - 2025-05-13 13:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 13:51:58 --> Input Class Initialized
INFO - 2025-05-13 13:51:58 --> Language Class Initialized
INFO - 2025-05-13 13:51:58 --> Loader Class Initialized
INFO - 2025-05-13 13:51:58 --> Helper loaded: url_helper
INFO - 2025-05-13 13:51:58 --> Helper loaded: form_helper
INFO - 2025-05-13 13:51:58 --> Database Driver Class Initialized
DEBUG - 2025-05-13 13:51:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 13:51:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 13:51:58 --> Controller Class Initialized
INFO - 2025-05-13 13:51:58 --> Model "Workout_model" initialized
INFO - 2025-05-13 13:51:58 --> Model "User_model" initialized
INFO - 2025-05-13 13:51:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 13:51:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 13:51:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-13 13:51:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 13:51:58 --> Final output sent to browser
DEBUG - 2025-05-13 13:51:58 --> Total execution time: 0.0731
INFO - 2025-05-13 13:52:00 --> Config Class Initialized
INFO - 2025-05-13 13:52:00 --> Hooks Class Initialized
DEBUG - 2025-05-13 13:52:00 --> UTF-8 Support Enabled
INFO - 2025-05-13 13:52:00 --> Utf8 Class Initialized
INFO - 2025-05-13 13:52:00 --> URI Class Initialized
INFO - 2025-05-13 13:52:00 --> Router Class Initialized
INFO - 2025-05-13 13:52:00 --> Output Class Initialized
INFO - 2025-05-13 13:52:00 --> Security Class Initialized
DEBUG - 2025-05-13 13:52:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 13:52:00 --> Input Class Initialized
INFO - 2025-05-13 13:52:00 --> Language Class Initialized
INFO - 2025-05-13 13:52:00 --> Loader Class Initialized
INFO - 2025-05-13 13:52:00 --> Helper loaded: url_helper
INFO - 2025-05-13 13:52:00 --> Helper loaded: form_helper
INFO - 2025-05-13 13:52:00 --> Database Driver Class Initialized
DEBUG - 2025-05-13 13:52:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 13:52:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 13:52:00 --> Controller Class Initialized
INFO - 2025-05-13 13:52:00 --> Model "User_model" initialized
INFO - 2025-05-13 13:52:00 --> Model "Workout_model" initialized
INFO - 2025-05-13 13:52:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 13:52:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 13:52:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 13:52:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 13:52:00 --> Final output sent to browser
DEBUG - 2025-05-13 13:52:00 --> Total execution time: 0.0768
INFO - 2025-05-13 13:56:25 --> Config Class Initialized
INFO - 2025-05-13 13:56:25 --> Hooks Class Initialized
DEBUG - 2025-05-13 13:56:25 --> UTF-8 Support Enabled
INFO - 2025-05-13 13:56:25 --> Utf8 Class Initialized
INFO - 2025-05-13 13:56:25 --> URI Class Initialized
INFO - 2025-05-13 13:56:25 --> Router Class Initialized
INFO - 2025-05-13 13:56:25 --> Output Class Initialized
INFO - 2025-05-13 13:56:25 --> Security Class Initialized
DEBUG - 2025-05-13 13:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 13:56:25 --> Input Class Initialized
INFO - 2025-05-13 13:56:25 --> Language Class Initialized
INFO - 2025-05-13 13:56:25 --> Loader Class Initialized
INFO - 2025-05-13 13:56:25 --> Helper loaded: url_helper
INFO - 2025-05-13 13:56:25 --> Helper loaded: form_helper
INFO - 2025-05-13 13:56:25 --> Database Driver Class Initialized
DEBUG - 2025-05-13 13:56:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 13:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 13:56:25 --> Controller Class Initialized
INFO - 2025-05-13 13:56:25 --> Model "User_model" initialized
INFO - 2025-05-13 13:56:25 --> Model "Workout_model" initialized
INFO - 2025-05-13 13:56:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 13:56:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 13:56:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 13:56:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 13:56:25 --> Final output sent to browser
DEBUG - 2025-05-13 13:56:25 --> Total execution time: 0.0942
INFO - 2025-05-13 14:03:02 --> Config Class Initialized
INFO - 2025-05-13 14:03:02 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:03:02 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:03:02 --> Utf8 Class Initialized
INFO - 2025-05-13 14:03:02 --> URI Class Initialized
INFO - 2025-05-13 14:03:02 --> Router Class Initialized
INFO - 2025-05-13 14:03:02 --> Output Class Initialized
INFO - 2025-05-13 14:03:02 --> Security Class Initialized
DEBUG - 2025-05-13 14:03:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:03:02 --> Input Class Initialized
INFO - 2025-05-13 14:03:02 --> Language Class Initialized
INFO - 2025-05-13 14:03:02 --> Loader Class Initialized
INFO - 2025-05-13 14:03:02 --> Helper loaded: url_helper
INFO - 2025-05-13 14:03:02 --> Helper loaded: form_helper
INFO - 2025-05-13 14:03:02 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:03:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:03:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:03:02 --> Controller Class Initialized
INFO - 2025-05-13 14:03:02 --> Model "User_model" initialized
INFO - 2025-05-13 14:03:02 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:03:02 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 14:03:02 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 14:03:02 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 14:03:02 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 14:03:02 --> Final output sent to browser
DEBUG - 2025-05-13 14:03:02 --> Total execution time: 0.1102
INFO - 2025-05-13 14:03:15 --> Config Class Initialized
INFO - 2025-05-13 14:03:15 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:03:15 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:03:15 --> Utf8 Class Initialized
INFO - 2025-05-13 14:03:15 --> URI Class Initialized
INFO - 2025-05-13 14:03:15 --> Router Class Initialized
INFO - 2025-05-13 14:03:15 --> Output Class Initialized
INFO - 2025-05-13 14:03:15 --> Security Class Initialized
DEBUG - 2025-05-13 14:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:03:15 --> Input Class Initialized
INFO - 2025-05-13 14:03:15 --> Language Class Initialized
INFO - 2025-05-13 14:03:15 --> Loader Class Initialized
INFO - 2025-05-13 14:03:15 --> Helper loaded: url_helper
INFO - 2025-05-13 14:03:15 --> Helper loaded: form_helper
INFO - 2025-05-13 14:03:15 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:03:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:03:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:03:15 --> Controller Class Initialized
INFO - 2025-05-13 14:03:15 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:03:15 --> Model "User_model" initialized
INFO - 2025-05-13 14:03:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 14:03:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 14:03:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-13 14:03:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 14:03:15 --> Final output sent to browser
DEBUG - 2025-05-13 14:03:15 --> Total execution time: 0.0897
INFO - 2025-05-13 14:03:17 --> Config Class Initialized
INFO - 2025-05-13 14:03:17 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:03:17 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:03:17 --> Utf8 Class Initialized
INFO - 2025-05-13 14:03:17 --> URI Class Initialized
INFO - 2025-05-13 14:03:17 --> Router Class Initialized
INFO - 2025-05-13 14:03:17 --> Output Class Initialized
INFO - 2025-05-13 14:03:17 --> Security Class Initialized
DEBUG - 2025-05-13 14:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:03:17 --> Input Class Initialized
INFO - 2025-05-13 14:03:17 --> Language Class Initialized
INFO - 2025-05-13 14:03:17 --> Loader Class Initialized
INFO - 2025-05-13 14:03:17 --> Helper loaded: url_helper
INFO - 2025-05-13 14:03:17 --> Helper loaded: form_helper
INFO - 2025-05-13 14:03:17 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:03:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:03:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:03:17 --> Controller Class Initialized
INFO - 2025-05-13 14:03:17 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:03:17 --> Model "User_model" initialized
INFO - 2025-05-13 14:03:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 14:03:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 14:03:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/add_jadwal.php
INFO - 2025-05-13 14:03:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 14:03:17 --> Final output sent to browser
DEBUG - 2025-05-13 14:03:17 --> Total execution time: 0.0943
INFO - 2025-05-13 14:03:33 --> Config Class Initialized
INFO - 2025-05-13 14:03:33 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:03:33 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:03:33 --> Utf8 Class Initialized
INFO - 2025-05-13 14:03:33 --> URI Class Initialized
INFO - 2025-05-13 14:03:33 --> Router Class Initialized
INFO - 2025-05-13 14:03:33 --> Output Class Initialized
INFO - 2025-05-13 14:03:33 --> Security Class Initialized
DEBUG - 2025-05-13 14:03:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:03:33 --> Input Class Initialized
INFO - 2025-05-13 14:03:33 --> Language Class Initialized
INFO - 2025-05-13 14:03:33 --> Loader Class Initialized
INFO - 2025-05-13 14:03:33 --> Helper loaded: url_helper
INFO - 2025-05-13 14:03:33 --> Helper loaded: form_helper
INFO - 2025-05-13 14:03:33 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:03:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:03:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:03:33 --> Controller Class Initialized
INFO - 2025-05-13 14:03:33 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:03:33 --> Model "User_model" initialized
INFO - 2025-05-13 14:03:33 --> Config Class Initialized
INFO - 2025-05-13 14:03:33 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:03:33 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:03:33 --> Utf8 Class Initialized
INFO - 2025-05-13 14:03:33 --> URI Class Initialized
INFO - 2025-05-13 14:03:33 --> Router Class Initialized
INFO - 2025-05-13 14:03:33 --> Output Class Initialized
INFO - 2025-05-13 14:03:33 --> Security Class Initialized
DEBUG - 2025-05-13 14:03:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:03:33 --> Input Class Initialized
INFO - 2025-05-13 14:03:33 --> Language Class Initialized
INFO - 2025-05-13 14:03:33 --> Loader Class Initialized
INFO - 2025-05-13 14:03:33 --> Helper loaded: url_helper
INFO - 2025-05-13 14:03:33 --> Helper loaded: form_helper
INFO - 2025-05-13 14:03:33 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:03:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:03:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:03:33 --> Controller Class Initialized
INFO - 2025-05-13 14:03:33 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:03:33 --> Model "User_model" initialized
INFO - 2025-05-13 14:03:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 14:03:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 14:03:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-13 14:03:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 14:03:33 --> Final output sent to browser
DEBUG - 2025-05-13 14:03:33 --> Total execution time: 0.0845
INFO - 2025-05-13 14:03:35 --> Config Class Initialized
INFO - 2025-05-13 14:03:35 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:03:35 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:03:35 --> Utf8 Class Initialized
INFO - 2025-05-13 14:03:35 --> URI Class Initialized
INFO - 2025-05-13 14:03:35 --> Router Class Initialized
INFO - 2025-05-13 14:03:35 --> Output Class Initialized
INFO - 2025-05-13 14:03:35 --> Security Class Initialized
DEBUG - 2025-05-13 14:03:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:03:35 --> Input Class Initialized
INFO - 2025-05-13 14:03:35 --> Language Class Initialized
INFO - 2025-05-13 14:03:35 --> Loader Class Initialized
INFO - 2025-05-13 14:03:35 --> Helper loaded: url_helper
INFO - 2025-05-13 14:03:35 --> Helper loaded: form_helper
INFO - 2025-05-13 14:03:35 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:03:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:03:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:03:35 --> Controller Class Initialized
INFO - 2025-05-13 14:03:35 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:03:35 --> Model "User_model" initialized
INFO - 2025-05-13 14:03:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 14:03:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 14:03:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/add_jadwal.php
INFO - 2025-05-13 14:03:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 14:03:35 --> Final output sent to browser
DEBUG - 2025-05-13 14:03:35 --> Total execution time: 0.0618
INFO - 2025-05-13 14:03:47 --> Config Class Initialized
INFO - 2025-05-13 14:03:47 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:03:47 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:03:47 --> Utf8 Class Initialized
INFO - 2025-05-13 14:03:47 --> URI Class Initialized
INFO - 2025-05-13 14:03:47 --> Router Class Initialized
INFO - 2025-05-13 14:03:47 --> Output Class Initialized
INFO - 2025-05-13 14:03:47 --> Security Class Initialized
DEBUG - 2025-05-13 14:03:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:03:47 --> Input Class Initialized
INFO - 2025-05-13 14:03:47 --> Language Class Initialized
INFO - 2025-05-13 14:03:47 --> Loader Class Initialized
INFO - 2025-05-13 14:03:47 --> Helper loaded: url_helper
INFO - 2025-05-13 14:03:47 --> Helper loaded: form_helper
INFO - 2025-05-13 14:03:47 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:03:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:03:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:03:47 --> Controller Class Initialized
INFO - 2025-05-13 14:03:47 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:03:47 --> Model "User_model" initialized
INFO - 2025-05-13 14:03:47 --> Config Class Initialized
INFO - 2025-05-13 14:03:47 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:03:47 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:03:47 --> Utf8 Class Initialized
INFO - 2025-05-13 14:03:47 --> URI Class Initialized
INFO - 2025-05-13 14:03:47 --> Router Class Initialized
INFO - 2025-05-13 14:03:47 --> Output Class Initialized
INFO - 2025-05-13 14:03:47 --> Security Class Initialized
DEBUG - 2025-05-13 14:03:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:03:47 --> Input Class Initialized
INFO - 2025-05-13 14:03:47 --> Language Class Initialized
INFO - 2025-05-13 14:03:47 --> Loader Class Initialized
INFO - 2025-05-13 14:03:47 --> Helper loaded: url_helper
INFO - 2025-05-13 14:03:47 --> Helper loaded: form_helper
INFO - 2025-05-13 14:03:47 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:03:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:03:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:03:47 --> Controller Class Initialized
INFO - 2025-05-13 14:03:47 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:03:47 --> Model "User_model" initialized
INFO - 2025-05-13 14:03:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 14:03:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 14:03:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-13 14:03:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 14:03:47 --> Final output sent to browser
DEBUG - 2025-05-13 14:03:47 --> Total execution time: 0.0650
INFO - 2025-05-13 14:03:52 --> Config Class Initialized
INFO - 2025-05-13 14:03:52 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:03:52 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:03:52 --> Utf8 Class Initialized
INFO - 2025-05-13 14:03:52 --> URI Class Initialized
INFO - 2025-05-13 14:03:52 --> Router Class Initialized
INFO - 2025-05-13 14:03:52 --> Output Class Initialized
INFO - 2025-05-13 14:03:52 --> Security Class Initialized
DEBUG - 2025-05-13 14:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:03:52 --> Input Class Initialized
INFO - 2025-05-13 14:03:52 --> Language Class Initialized
INFO - 2025-05-13 14:03:52 --> Loader Class Initialized
INFO - 2025-05-13 14:03:52 --> Helper loaded: url_helper
INFO - 2025-05-13 14:03:52 --> Helper loaded: form_helper
INFO - 2025-05-13 14:03:52 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:03:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:03:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:03:52 --> Controller Class Initialized
INFO - 2025-05-13 14:03:52 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:03:52 --> Model "User_model" initialized
INFO - 2025-05-13 14:03:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/start.php
INFO - 2025-05-13 14:03:52 --> Final output sent to browser
DEBUG - 2025-05-13 14:03:52 --> Total execution time: 0.0743
INFO - 2025-05-13 14:03:58 --> Config Class Initialized
INFO - 2025-05-13 14:03:58 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:03:58 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:03:58 --> Utf8 Class Initialized
INFO - 2025-05-13 14:03:58 --> URI Class Initialized
INFO - 2025-05-13 14:03:58 --> Router Class Initialized
INFO - 2025-05-13 14:03:58 --> Output Class Initialized
INFO - 2025-05-13 14:03:58 --> Security Class Initialized
DEBUG - 2025-05-13 14:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:03:58 --> Input Class Initialized
INFO - 2025-05-13 14:03:58 --> Language Class Initialized
INFO - 2025-05-13 14:03:58 --> Loader Class Initialized
INFO - 2025-05-13 14:03:58 --> Helper loaded: url_helper
INFO - 2025-05-13 14:03:58 --> Helper loaded: form_helper
INFO - 2025-05-13 14:03:58 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:03:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:03:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:03:58 --> Controller Class Initialized
INFO - 2025-05-13 14:03:58 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:03:58 --> Model "User_model" initialized
INFO - 2025-05-13 14:03:58 --> Final output sent to browser
DEBUG - 2025-05-13 14:03:58 --> Total execution time: 0.0750
INFO - 2025-05-13 14:03:58 --> Config Class Initialized
INFO - 2025-05-13 14:03:58 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:03:58 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:03:58 --> Utf8 Class Initialized
INFO - 2025-05-13 14:03:58 --> URI Class Initialized
INFO - 2025-05-13 14:03:58 --> Router Class Initialized
INFO - 2025-05-13 14:03:58 --> Output Class Initialized
INFO - 2025-05-13 14:03:58 --> Security Class Initialized
DEBUG - 2025-05-13 14:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:03:58 --> Input Class Initialized
INFO - 2025-05-13 14:03:58 --> Language Class Initialized
INFO - 2025-05-13 14:03:58 --> Loader Class Initialized
INFO - 2025-05-13 14:03:58 --> Helper loaded: url_helper
INFO - 2025-05-13 14:03:58 --> Helper loaded: form_helper
INFO - 2025-05-13 14:03:58 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:03:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:03:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:03:58 --> Controller Class Initialized
INFO - 2025-05-13 14:03:58 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:03:58 --> Model "User_model" initialized
INFO - 2025-05-13 14:03:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 14:03:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 14:03:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-13 14:03:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 14:03:58 --> Final output sent to browser
DEBUG - 2025-05-13 14:03:58 --> Total execution time: 0.0737
INFO - 2025-05-13 14:04:04 --> Config Class Initialized
INFO - 2025-05-13 14:04:04 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:04:04 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:04:04 --> Utf8 Class Initialized
INFO - 2025-05-13 14:04:04 --> URI Class Initialized
INFO - 2025-05-13 14:04:04 --> Router Class Initialized
INFO - 2025-05-13 14:04:04 --> Output Class Initialized
INFO - 2025-05-13 14:04:04 --> Security Class Initialized
DEBUG - 2025-05-13 14:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:04:04 --> Input Class Initialized
INFO - 2025-05-13 14:04:04 --> Language Class Initialized
INFO - 2025-05-13 14:04:04 --> Loader Class Initialized
INFO - 2025-05-13 14:04:04 --> Helper loaded: url_helper
INFO - 2025-05-13 14:04:04 --> Helper loaded: form_helper
INFO - 2025-05-13 14:04:04 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:04:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:04:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:04:04 --> Controller Class Initialized
INFO - 2025-05-13 14:04:04 --> Model "User_model" initialized
INFO - 2025-05-13 14:04:04 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:04:04 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 14:04:04 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 14:04:04 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 14:04:04 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 14:04:04 --> Final output sent to browser
DEBUG - 2025-05-13 14:04:04 --> Total execution time: 0.0831
INFO - 2025-05-13 14:04:26 --> Config Class Initialized
INFO - 2025-05-13 14:04:26 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:04:26 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:04:26 --> Utf8 Class Initialized
INFO - 2025-05-13 14:04:26 --> URI Class Initialized
INFO - 2025-05-13 14:04:26 --> Router Class Initialized
INFO - 2025-05-13 14:04:26 --> Output Class Initialized
INFO - 2025-05-13 14:04:26 --> Security Class Initialized
DEBUG - 2025-05-13 14:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:04:27 --> Input Class Initialized
INFO - 2025-05-13 14:04:27 --> Language Class Initialized
INFO - 2025-05-13 14:04:27 --> Loader Class Initialized
INFO - 2025-05-13 14:04:27 --> Helper loaded: url_helper
INFO - 2025-05-13 14:04:27 --> Helper loaded: form_helper
INFO - 2025-05-13 14:04:27 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:04:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:04:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:04:27 --> Controller Class Initialized
INFO - 2025-05-13 14:04:27 --> Model "User_model" initialized
INFO - 2025-05-13 14:04:27 --> Config Class Initialized
INFO - 2025-05-13 14:04:27 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:04:27 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:04:27 --> Utf8 Class Initialized
INFO - 2025-05-13 14:04:27 --> URI Class Initialized
INFO - 2025-05-13 14:04:27 --> Router Class Initialized
INFO - 2025-05-13 14:04:27 --> Output Class Initialized
INFO - 2025-05-13 14:04:27 --> Security Class Initialized
DEBUG - 2025-05-13 14:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:04:27 --> Input Class Initialized
INFO - 2025-05-13 14:04:27 --> Language Class Initialized
INFO - 2025-05-13 14:04:27 --> Loader Class Initialized
INFO - 2025-05-13 14:04:27 --> Helper loaded: url_helper
INFO - 2025-05-13 14:04:27 --> Helper loaded: form_helper
INFO - 2025-05-13 14:04:27 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:04:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:04:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:04:27 --> Controller Class Initialized
INFO - 2025-05-13 14:04:27 --> Model "User_model" initialized
INFO - 2025-05-13 14:04:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-13 14:04:27 --> Final output sent to browser
DEBUG - 2025-05-13 14:04:27 --> Total execution time: 0.0590
INFO - 2025-05-13 14:04:35 --> Config Class Initialized
INFO - 2025-05-13 14:04:35 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:04:35 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:04:35 --> Utf8 Class Initialized
INFO - 2025-05-13 14:04:35 --> URI Class Initialized
INFO - 2025-05-13 14:04:35 --> Router Class Initialized
INFO - 2025-05-13 14:04:35 --> Output Class Initialized
INFO - 2025-05-13 14:04:35 --> Security Class Initialized
DEBUG - 2025-05-13 14:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:04:35 --> Input Class Initialized
INFO - 2025-05-13 14:04:35 --> Language Class Initialized
INFO - 2025-05-13 14:04:35 --> Loader Class Initialized
INFO - 2025-05-13 14:04:35 --> Helper loaded: url_helper
INFO - 2025-05-13 14:04:35 --> Helper loaded: form_helper
INFO - 2025-05-13 14:04:35 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:04:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:04:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:04:35 --> Controller Class Initialized
INFO - 2025-05-13 14:04:35 --> Model "User_model" initialized
INFO - 2025-05-13 14:04:35 --> Config Class Initialized
INFO - 2025-05-13 14:04:35 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:04:35 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:04:35 --> Utf8 Class Initialized
INFO - 2025-05-13 14:04:35 --> URI Class Initialized
INFO - 2025-05-13 14:04:35 --> Router Class Initialized
INFO - 2025-05-13 14:04:35 --> Output Class Initialized
INFO - 2025-05-13 14:04:35 --> Security Class Initialized
DEBUG - 2025-05-13 14:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:04:35 --> Input Class Initialized
INFO - 2025-05-13 14:04:35 --> Language Class Initialized
INFO - 2025-05-13 14:04:35 --> Loader Class Initialized
INFO - 2025-05-13 14:04:35 --> Helper loaded: url_helper
INFO - 2025-05-13 14:04:35 --> Helper loaded: form_helper
INFO - 2025-05-13 14:04:35 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:04:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:04:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:04:35 --> Controller Class Initialized
INFO - 2025-05-13 14:04:35 --> Model "User_model" initialized
INFO - 2025-05-13 14:04:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-13 14:04:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-13 14:04:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-13 14:04:35 --> Final output sent to browser
DEBUG - 2025-05-13 14:04:35 --> Total execution time: 0.0858
INFO - 2025-05-13 14:04:47 --> Config Class Initialized
INFO - 2025-05-13 14:04:47 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:04:47 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:04:47 --> Utf8 Class Initialized
INFO - 2025-05-13 14:04:47 --> URI Class Initialized
INFO - 2025-05-13 14:04:47 --> Router Class Initialized
INFO - 2025-05-13 14:04:47 --> Output Class Initialized
INFO - 2025-05-13 14:04:47 --> Security Class Initialized
DEBUG - 2025-05-13 14:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:04:47 --> Input Class Initialized
INFO - 2025-05-13 14:04:47 --> Language Class Initialized
INFO - 2025-05-13 14:04:47 --> Loader Class Initialized
INFO - 2025-05-13 14:04:47 --> Helper loaded: url_helper
INFO - 2025-05-13 14:04:47 --> Helper loaded: form_helper
INFO - 2025-05-13 14:04:47 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:04:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:04:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:04:47 --> Controller Class Initialized
INFO - 2025-05-13 14:04:47 --> Model "User_model" initialized
INFO - 2025-05-13 14:04:47 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:04:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 14:04:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 14:04:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 14:04:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 14:04:47 --> Final output sent to browser
DEBUG - 2025-05-13 14:04:47 --> Total execution time: 0.0763
INFO - 2025-05-13 14:04:51 --> Config Class Initialized
INFO - 2025-05-13 14:04:51 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:04:51 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:04:51 --> Utf8 Class Initialized
INFO - 2025-05-13 14:04:51 --> URI Class Initialized
INFO - 2025-05-13 14:04:51 --> Router Class Initialized
INFO - 2025-05-13 14:04:51 --> Output Class Initialized
INFO - 2025-05-13 14:04:51 --> Security Class Initialized
DEBUG - 2025-05-13 14:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:04:51 --> Input Class Initialized
INFO - 2025-05-13 14:04:51 --> Language Class Initialized
INFO - 2025-05-13 14:04:51 --> Loader Class Initialized
INFO - 2025-05-13 14:04:51 --> Helper loaded: url_helper
INFO - 2025-05-13 14:04:51 --> Helper loaded: form_helper
INFO - 2025-05-13 14:04:51 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:04:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:04:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:04:51 --> Controller Class Initialized
INFO - 2025-05-13 14:04:51 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:04:51 --> Model "User_model" initialized
INFO - 2025-05-13 14:04:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 14:04:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 14:04:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-13 14:04:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 14:04:51 --> Final output sent to browser
DEBUG - 2025-05-13 14:04:51 --> Total execution time: 0.0698
INFO - 2025-05-13 14:04:52 --> Config Class Initialized
INFO - 2025-05-13 14:04:52 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:04:52 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:04:52 --> Utf8 Class Initialized
INFO - 2025-05-13 14:04:52 --> URI Class Initialized
INFO - 2025-05-13 14:04:52 --> Router Class Initialized
INFO - 2025-05-13 14:04:52 --> Output Class Initialized
INFO - 2025-05-13 14:04:52 --> Security Class Initialized
DEBUG - 2025-05-13 14:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:04:52 --> Input Class Initialized
INFO - 2025-05-13 14:04:52 --> Language Class Initialized
INFO - 2025-05-13 14:04:52 --> Loader Class Initialized
INFO - 2025-05-13 14:04:52 --> Helper loaded: url_helper
INFO - 2025-05-13 14:04:52 --> Helper loaded: form_helper
INFO - 2025-05-13 14:04:52 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:04:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:04:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:04:52 --> Controller Class Initialized
INFO - 2025-05-13 14:04:52 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:04:52 --> Model "User_model" initialized
INFO - 2025-05-13 14:04:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 14:04:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 14:04:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/add_jadwal.php
INFO - 2025-05-13 14:04:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 14:04:52 --> Final output sent to browser
DEBUG - 2025-05-13 14:04:52 --> Total execution time: 0.0731
INFO - 2025-05-13 14:05:03 --> Config Class Initialized
INFO - 2025-05-13 14:05:03 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:05:03 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:05:03 --> Utf8 Class Initialized
INFO - 2025-05-13 14:05:03 --> URI Class Initialized
INFO - 2025-05-13 14:05:03 --> Router Class Initialized
INFO - 2025-05-13 14:05:03 --> Output Class Initialized
INFO - 2025-05-13 14:05:03 --> Security Class Initialized
DEBUG - 2025-05-13 14:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:05:03 --> Input Class Initialized
INFO - 2025-05-13 14:05:03 --> Language Class Initialized
INFO - 2025-05-13 14:05:03 --> Loader Class Initialized
INFO - 2025-05-13 14:05:03 --> Helper loaded: url_helper
INFO - 2025-05-13 14:05:03 --> Helper loaded: form_helper
INFO - 2025-05-13 14:05:03 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:05:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:05:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:05:03 --> Controller Class Initialized
INFO - 2025-05-13 14:05:03 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:05:03 --> Model "User_model" initialized
INFO - 2025-05-13 14:05:03 --> Config Class Initialized
INFO - 2025-05-13 14:05:03 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:05:03 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:05:03 --> Utf8 Class Initialized
INFO - 2025-05-13 14:05:03 --> URI Class Initialized
INFO - 2025-05-13 14:05:03 --> Router Class Initialized
INFO - 2025-05-13 14:05:03 --> Output Class Initialized
INFO - 2025-05-13 14:05:03 --> Security Class Initialized
DEBUG - 2025-05-13 14:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:05:03 --> Input Class Initialized
INFO - 2025-05-13 14:05:03 --> Language Class Initialized
INFO - 2025-05-13 14:05:03 --> Loader Class Initialized
INFO - 2025-05-13 14:05:03 --> Helper loaded: url_helper
INFO - 2025-05-13 14:05:03 --> Helper loaded: form_helper
INFO - 2025-05-13 14:05:03 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:05:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:05:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:05:03 --> Controller Class Initialized
INFO - 2025-05-13 14:05:03 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:05:03 --> Model "User_model" initialized
INFO - 2025-05-13 14:05:03 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 14:05:03 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 14:05:03 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-13 14:05:03 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 14:05:03 --> Final output sent to browser
DEBUG - 2025-05-13 14:05:03 --> Total execution time: 0.0651
INFO - 2025-05-13 14:05:07 --> Config Class Initialized
INFO - 2025-05-13 14:05:07 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:05:07 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:05:07 --> Utf8 Class Initialized
INFO - 2025-05-13 14:05:07 --> URI Class Initialized
INFO - 2025-05-13 14:05:07 --> Router Class Initialized
INFO - 2025-05-13 14:05:07 --> Output Class Initialized
INFO - 2025-05-13 14:05:07 --> Security Class Initialized
DEBUG - 2025-05-13 14:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:05:07 --> Input Class Initialized
INFO - 2025-05-13 14:05:07 --> Language Class Initialized
INFO - 2025-05-13 14:05:07 --> Loader Class Initialized
INFO - 2025-05-13 14:05:07 --> Helper loaded: url_helper
INFO - 2025-05-13 14:05:07 --> Helper loaded: form_helper
INFO - 2025-05-13 14:05:07 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:05:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:05:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:05:07 --> Controller Class Initialized
INFO - 2025-05-13 14:05:07 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:05:07 --> Model "User_model" initialized
INFO - 2025-05-13 14:05:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 14:05:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 14:05:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/add_jadwal.php
INFO - 2025-05-13 14:05:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 14:05:07 --> Final output sent to browser
DEBUG - 2025-05-13 14:05:07 --> Total execution time: 0.0774
INFO - 2025-05-13 14:05:37 --> Config Class Initialized
INFO - 2025-05-13 14:05:37 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:05:37 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:05:37 --> Utf8 Class Initialized
INFO - 2025-05-13 14:05:37 --> URI Class Initialized
INFO - 2025-05-13 14:05:37 --> Router Class Initialized
INFO - 2025-05-13 14:05:37 --> Output Class Initialized
INFO - 2025-05-13 14:05:37 --> Security Class Initialized
DEBUG - 2025-05-13 14:05:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:05:37 --> Input Class Initialized
INFO - 2025-05-13 14:05:37 --> Language Class Initialized
INFO - 2025-05-13 14:05:37 --> Loader Class Initialized
INFO - 2025-05-13 14:05:37 --> Helper loaded: url_helper
INFO - 2025-05-13 14:05:37 --> Helper loaded: form_helper
INFO - 2025-05-13 14:05:37 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:05:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:05:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:05:38 --> Controller Class Initialized
INFO - 2025-05-13 14:05:38 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:05:38 --> Model "User_model" initialized
INFO - 2025-05-13 14:05:38 --> Config Class Initialized
INFO - 2025-05-13 14:05:38 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:05:38 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:05:38 --> Utf8 Class Initialized
INFO - 2025-05-13 14:05:38 --> URI Class Initialized
INFO - 2025-05-13 14:05:38 --> Router Class Initialized
INFO - 2025-05-13 14:05:38 --> Output Class Initialized
INFO - 2025-05-13 14:05:38 --> Security Class Initialized
DEBUG - 2025-05-13 14:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:05:38 --> Input Class Initialized
INFO - 2025-05-13 14:05:38 --> Language Class Initialized
INFO - 2025-05-13 14:05:38 --> Loader Class Initialized
INFO - 2025-05-13 14:05:38 --> Helper loaded: url_helper
INFO - 2025-05-13 14:05:38 --> Helper loaded: form_helper
INFO - 2025-05-13 14:05:38 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:05:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:05:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:05:38 --> Controller Class Initialized
INFO - 2025-05-13 14:05:38 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:05:38 --> Model "User_model" initialized
INFO - 2025-05-13 14:05:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 14:05:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 14:05:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-13 14:05:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 14:05:38 --> Final output sent to browser
DEBUG - 2025-05-13 14:05:38 --> Total execution time: 0.1124
INFO - 2025-05-13 14:05:42 --> Config Class Initialized
INFO - 2025-05-13 14:05:42 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:05:42 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:05:42 --> Utf8 Class Initialized
INFO - 2025-05-13 14:05:42 --> URI Class Initialized
INFO - 2025-05-13 14:05:42 --> Router Class Initialized
INFO - 2025-05-13 14:05:42 --> Output Class Initialized
INFO - 2025-05-13 14:05:42 --> Security Class Initialized
DEBUG - 2025-05-13 14:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:05:42 --> Input Class Initialized
INFO - 2025-05-13 14:05:42 --> Language Class Initialized
INFO - 2025-05-13 14:05:42 --> Loader Class Initialized
INFO - 2025-05-13 14:05:42 --> Helper loaded: url_helper
INFO - 2025-05-13 14:05:42 --> Helper loaded: form_helper
INFO - 2025-05-13 14:05:42 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:05:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:05:43 --> Controller Class Initialized
INFO - 2025-05-13 14:05:43 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:05:43 --> Model "User_model" initialized
INFO - 2025-05-13 14:05:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/start.php
INFO - 2025-05-13 14:05:43 --> Final output sent to browser
DEBUG - 2025-05-13 14:05:43 --> Total execution time: 0.0801
INFO - 2025-05-13 14:05:47 --> Config Class Initialized
INFO - 2025-05-13 14:05:47 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:05:47 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:05:47 --> Utf8 Class Initialized
INFO - 2025-05-13 14:05:47 --> URI Class Initialized
INFO - 2025-05-13 14:05:47 --> Router Class Initialized
INFO - 2025-05-13 14:05:47 --> Output Class Initialized
INFO - 2025-05-13 14:05:47 --> Security Class Initialized
DEBUG - 2025-05-13 14:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:05:47 --> Input Class Initialized
INFO - 2025-05-13 14:05:47 --> Language Class Initialized
INFO - 2025-05-13 14:05:47 --> Loader Class Initialized
INFO - 2025-05-13 14:05:47 --> Helper loaded: url_helper
INFO - 2025-05-13 14:05:47 --> Helper loaded: form_helper
INFO - 2025-05-13 14:05:47 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:05:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:05:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:05:47 --> Controller Class Initialized
INFO - 2025-05-13 14:05:47 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:05:47 --> Model "User_model" initialized
INFO - 2025-05-13 14:05:47 --> Final output sent to browser
DEBUG - 2025-05-13 14:05:47 --> Total execution time: 0.0835
INFO - 2025-05-13 14:05:47 --> Config Class Initialized
INFO - 2025-05-13 14:05:47 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:05:47 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:05:47 --> Utf8 Class Initialized
INFO - 2025-05-13 14:05:47 --> URI Class Initialized
INFO - 2025-05-13 14:05:47 --> Router Class Initialized
INFO - 2025-05-13 14:05:47 --> Output Class Initialized
INFO - 2025-05-13 14:05:47 --> Security Class Initialized
DEBUG - 2025-05-13 14:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:05:47 --> Input Class Initialized
INFO - 2025-05-13 14:05:47 --> Language Class Initialized
INFO - 2025-05-13 14:05:47 --> Loader Class Initialized
INFO - 2025-05-13 14:05:47 --> Helper loaded: url_helper
INFO - 2025-05-13 14:05:47 --> Helper loaded: form_helper
INFO - 2025-05-13 14:05:47 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:05:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:05:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:05:47 --> Controller Class Initialized
INFO - 2025-05-13 14:05:47 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:05:47 --> Model "User_model" initialized
INFO - 2025-05-13 14:05:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 14:05:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 14:05:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-13 14:05:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 14:05:47 --> Final output sent to browser
DEBUG - 2025-05-13 14:05:47 --> Total execution time: 0.0855
INFO - 2025-05-13 14:05:50 --> Config Class Initialized
INFO - 2025-05-13 14:05:50 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:05:50 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:05:50 --> Utf8 Class Initialized
INFO - 2025-05-13 14:05:50 --> URI Class Initialized
INFO - 2025-05-13 14:05:50 --> Router Class Initialized
INFO - 2025-05-13 14:05:50 --> Output Class Initialized
INFO - 2025-05-13 14:05:50 --> Security Class Initialized
DEBUG - 2025-05-13 14:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:05:50 --> Input Class Initialized
INFO - 2025-05-13 14:05:50 --> Language Class Initialized
INFO - 2025-05-13 14:05:50 --> Loader Class Initialized
INFO - 2025-05-13 14:05:50 --> Helper loaded: url_helper
INFO - 2025-05-13 14:05:50 --> Helper loaded: form_helper
INFO - 2025-05-13 14:05:50 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:05:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:05:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:05:50 --> Controller Class Initialized
INFO - 2025-05-13 14:05:50 --> Model "User_model" initialized
INFO - 2025-05-13 14:05:50 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:05:50 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 14:05:50 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 14:05:50 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 14:05:50 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 14:05:50 --> Final output sent to browser
DEBUG - 2025-05-13 14:05:50 --> Total execution time: 0.0614
INFO - 2025-05-13 14:05:59 --> Config Class Initialized
INFO - 2025-05-13 14:05:59 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:05:59 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:05:59 --> Utf8 Class Initialized
INFO - 2025-05-13 14:05:59 --> URI Class Initialized
INFO - 2025-05-13 14:05:59 --> Router Class Initialized
INFO - 2025-05-13 14:05:59 --> Output Class Initialized
INFO - 2025-05-13 14:05:59 --> Security Class Initialized
DEBUG - 2025-05-13 14:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:05:59 --> Input Class Initialized
INFO - 2025-05-13 14:05:59 --> Language Class Initialized
INFO - 2025-05-13 14:05:59 --> Loader Class Initialized
INFO - 2025-05-13 14:05:59 --> Helper loaded: url_helper
INFO - 2025-05-13 14:05:59 --> Helper loaded: form_helper
INFO - 2025-05-13 14:05:59 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:05:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:05:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:05:59 --> Controller Class Initialized
INFO - 2025-05-13 14:05:59 --> Model "User_model" initialized
INFO - 2025-05-13 14:05:59 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:05:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 14:05:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 14:05:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-13 14:05:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 14:05:59 --> Final output sent to browser
DEBUG - 2025-05-13 14:05:59 --> Total execution time: 0.0689
INFO - 2025-05-13 14:06:00 --> Config Class Initialized
INFO - 2025-05-13 14:06:00 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:06:00 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:06:00 --> Utf8 Class Initialized
INFO - 2025-05-13 14:06:00 --> URI Class Initialized
INFO - 2025-05-13 14:06:00 --> Router Class Initialized
INFO - 2025-05-13 14:06:00 --> Output Class Initialized
INFO - 2025-05-13 14:06:00 --> Security Class Initialized
DEBUG - 2025-05-13 14:06:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:06:00 --> Input Class Initialized
INFO - 2025-05-13 14:06:00 --> Language Class Initialized
INFO - 2025-05-13 14:06:00 --> Loader Class Initialized
INFO - 2025-05-13 14:06:00 --> Helper loaded: url_helper
INFO - 2025-05-13 14:06:00 --> Helper loaded: form_helper
INFO - 2025-05-13 14:06:00 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:06:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:06:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:06:00 --> Controller Class Initialized
INFO - 2025-05-13 14:06:00 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:06:00 --> Model "User_model" initialized
INFO - 2025-05-13 14:06:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 14:06:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 14:06:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-13 14:06:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 14:06:00 --> Final output sent to browser
DEBUG - 2025-05-13 14:06:00 --> Total execution time: 0.0687
INFO - 2025-05-13 14:06:04 --> Config Class Initialized
INFO - 2025-05-13 14:06:04 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:06:04 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:06:04 --> Utf8 Class Initialized
INFO - 2025-05-13 14:06:04 --> URI Class Initialized
INFO - 2025-05-13 14:06:04 --> Router Class Initialized
INFO - 2025-05-13 14:06:04 --> Output Class Initialized
INFO - 2025-05-13 14:06:04 --> Security Class Initialized
DEBUG - 2025-05-13 14:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:06:04 --> Input Class Initialized
INFO - 2025-05-13 14:06:04 --> Language Class Initialized
INFO - 2025-05-13 14:06:04 --> Loader Class Initialized
INFO - 2025-05-13 14:06:04 --> Helper loaded: url_helper
INFO - 2025-05-13 14:06:04 --> Helper loaded: form_helper
INFO - 2025-05-13 14:06:04 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:06:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:06:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:06:04 --> Controller Class Initialized
INFO - 2025-05-13 14:06:04 --> Model "User_model" initialized
INFO - 2025-05-13 14:06:04 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:06:04 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 14:06:04 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 14:06:04 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 14:06:04 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 14:06:04 --> Final output sent to browser
DEBUG - 2025-05-13 14:06:04 --> Total execution time: 0.0711
INFO - 2025-05-13 14:09:09 --> Config Class Initialized
INFO - 2025-05-13 14:09:09 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:09:09 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:09:09 --> Utf8 Class Initialized
INFO - 2025-05-13 14:09:09 --> URI Class Initialized
INFO - 2025-05-13 14:09:09 --> Router Class Initialized
INFO - 2025-05-13 14:09:09 --> Output Class Initialized
INFO - 2025-05-13 14:09:09 --> Security Class Initialized
DEBUG - 2025-05-13 14:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:09:09 --> Input Class Initialized
INFO - 2025-05-13 14:09:09 --> Language Class Initialized
INFO - 2025-05-13 14:09:09 --> Loader Class Initialized
INFO - 2025-05-13 14:09:09 --> Helper loaded: url_helper
INFO - 2025-05-13 14:09:09 --> Helper loaded: form_helper
INFO - 2025-05-13 14:09:09 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:09:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:09:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:09:09 --> Controller Class Initialized
INFO - 2025-05-13 14:09:09 --> Model "User_model" initialized
INFO - 2025-05-13 14:09:09 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:09:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 14:09:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 14:09:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 14:09:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 14:09:09 --> Final output sent to browser
DEBUG - 2025-05-13 14:09:09 --> Total execution time: 0.0754
INFO - 2025-05-13 14:10:08 --> Config Class Initialized
INFO - 2025-05-13 14:10:08 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:10:08 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:10:08 --> Utf8 Class Initialized
INFO - 2025-05-13 14:10:08 --> URI Class Initialized
INFO - 2025-05-13 14:10:08 --> Router Class Initialized
INFO - 2025-05-13 14:10:08 --> Output Class Initialized
INFO - 2025-05-13 14:10:08 --> Security Class Initialized
DEBUG - 2025-05-13 14:10:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:10:08 --> Input Class Initialized
INFO - 2025-05-13 14:10:08 --> Language Class Initialized
INFO - 2025-05-13 14:10:08 --> Loader Class Initialized
INFO - 2025-05-13 14:10:08 --> Helper loaded: url_helper
INFO - 2025-05-13 14:10:08 --> Helper loaded: form_helper
INFO - 2025-05-13 14:10:08 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:10:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:10:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:10:08 --> Controller Class Initialized
INFO - 2025-05-13 14:10:08 --> Model "User_model" initialized
INFO - 2025-05-13 14:10:08 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:10:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 14:10:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 14:10:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 14:10:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 14:10:08 --> Final output sent to browser
DEBUG - 2025-05-13 14:10:08 --> Total execution time: 0.0844
INFO - 2025-05-13 14:10:10 --> Config Class Initialized
INFO - 2025-05-13 14:10:10 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:10:10 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:10:10 --> Utf8 Class Initialized
INFO - 2025-05-13 14:10:10 --> URI Class Initialized
INFO - 2025-05-13 14:10:10 --> Router Class Initialized
INFO - 2025-05-13 14:10:10 --> Output Class Initialized
INFO - 2025-05-13 14:10:10 --> Security Class Initialized
DEBUG - 2025-05-13 14:10:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:10:10 --> Input Class Initialized
INFO - 2025-05-13 14:10:10 --> Language Class Initialized
INFO - 2025-05-13 14:10:10 --> Loader Class Initialized
INFO - 2025-05-13 14:10:10 --> Helper loaded: url_helper
INFO - 2025-05-13 14:10:10 --> Helper loaded: form_helper
INFO - 2025-05-13 14:10:10 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:10:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:10:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:10:10 --> Controller Class Initialized
INFO - 2025-05-13 14:10:10 --> Model "User_model" initialized
INFO - 2025-05-13 14:10:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-13 14:10:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-13 14:10:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-13 14:10:10 --> Final output sent to browser
DEBUG - 2025-05-13 14:10:10 --> Total execution time: 0.0701
INFO - 2025-05-13 14:10:13 --> Config Class Initialized
INFO - 2025-05-13 14:10:13 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:10:13 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:10:13 --> Utf8 Class Initialized
INFO - 2025-05-13 14:10:13 --> URI Class Initialized
INFO - 2025-05-13 14:10:13 --> Router Class Initialized
INFO - 2025-05-13 14:10:13 --> Output Class Initialized
INFO - 2025-05-13 14:10:13 --> Security Class Initialized
DEBUG - 2025-05-13 14:10:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:10:13 --> Input Class Initialized
INFO - 2025-05-13 14:10:13 --> Language Class Initialized
INFO - 2025-05-13 14:10:13 --> Loader Class Initialized
INFO - 2025-05-13 14:10:13 --> Helper loaded: url_helper
INFO - 2025-05-13 14:10:13 --> Helper loaded: form_helper
INFO - 2025-05-13 14:10:13 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:10:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:10:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:10:13 --> Controller Class Initialized
INFO - 2025-05-13 14:10:13 --> Model "User_model" initialized
INFO - 2025-05-13 14:10:13 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:10:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 14:10:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 14:10:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 14:10:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 14:10:13 --> Final output sent to browser
DEBUG - 2025-05-13 14:10:13 --> Total execution time: 0.0881
INFO - 2025-05-13 14:10:19 --> Config Class Initialized
INFO - 2025-05-13 14:10:19 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:10:19 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:10:19 --> Utf8 Class Initialized
INFO - 2025-05-13 14:10:19 --> URI Class Initialized
INFO - 2025-05-13 14:10:19 --> Router Class Initialized
INFO - 2025-05-13 14:10:19 --> Output Class Initialized
INFO - 2025-05-13 14:10:19 --> Security Class Initialized
DEBUG - 2025-05-13 14:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:10:19 --> Input Class Initialized
INFO - 2025-05-13 14:10:19 --> Language Class Initialized
INFO - 2025-05-13 14:10:19 --> Loader Class Initialized
INFO - 2025-05-13 14:10:19 --> Helper loaded: url_helper
INFO - 2025-05-13 14:10:19 --> Helper loaded: form_helper
INFO - 2025-05-13 14:10:19 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:10:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:10:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:10:19 --> Controller Class Initialized
INFO - 2025-05-13 14:10:19 --> Model "User_model" initialized
INFO - 2025-05-13 14:10:19 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:10:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 14:10:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 14:10:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 14:10:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 14:10:19 --> Final output sent to browser
DEBUG - 2025-05-13 14:10:19 --> Total execution time: 0.0925
INFO - 2025-05-13 14:10:53 --> Config Class Initialized
INFO - 2025-05-13 14:10:53 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:10:53 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:10:53 --> Utf8 Class Initialized
INFO - 2025-05-13 14:10:53 --> URI Class Initialized
INFO - 2025-05-13 14:10:53 --> Router Class Initialized
INFO - 2025-05-13 14:10:53 --> Output Class Initialized
INFO - 2025-05-13 14:10:53 --> Security Class Initialized
DEBUG - 2025-05-13 14:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:10:53 --> Input Class Initialized
INFO - 2025-05-13 14:10:53 --> Language Class Initialized
INFO - 2025-05-13 14:10:53 --> Loader Class Initialized
INFO - 2025-05-13 14:10:53 --> Helper loaded: url_helper
INFO - 2025-05-13 14:10:53 --> Helper loaded: form_helper
INFO - 2025-05-13 14:10:53 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:10:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:10:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:10:53 --> Controller Class Initialized
INFO - 2025-05-13 14:10:53 --> Model "User_model" initialized
INFO - 2025-05-13 14:10:53 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:10:53 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 14:10:53 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 14:10:53 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-13 14:10:53 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 14:10:53 --> Final output sent to browser
DEBUG - 2025-05-13 14:10:53 --> Total execution time: 0.0616
INFO - 2025-05-13 14:10:56 --> Config Class Initialized
INFO - 2025-05-13 14:10:56 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:10:56 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:10:56 --> Utf8 Class Initialized
INFO - 2025-05-13 14:10:56 --> URI Class Initialized
INFO - 2025-05-13 14:10:56 --> Router Class Initialized
INFO - 2025-05-13 14:10:56 --> Output Class Initialized
INFO - 2025-05-13 14:10:56 --> Security Class Initialized
DEBUG - 2025-05-13 14:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:10:56 --> Input Class Initialized
INFO - 2025-05-13 14:10:56 --> Language Class Initialized
INFO - 2025-05-13 14:10:56 --> Loader Class Initialized
INFO - 2025-05-13 14:10:56 --> Helper loaded: url_helper
INFO - 2025-05-13 14:10:56 --> Helper loaded: form_helper
INFO - 2025-05-13 14:10:56 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:10:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:10:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:10:56 --> Controller Class Initialized
INFO - 2025-05-13 14:10:56 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:10:56 --> Model "User_model" initialized
INFO - 2025-05-13 14:10:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 14:10:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 14:10:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-13 14:10:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 14:10:56 --> Final output sent to browser
DEBUG - 2025-05-13 14:10:56 --> Total execution time: 0.0740
INFO - 2025-05-13 14:11:03 --> Config Class Initialized
INFO - 2025-05-13 14:11:03 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:11:03 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:11:03 --> Utf8 Class Initialized
INFO - 2025-05-13 14:11:03 --> URI Class Initialized
INFO - 2025-05-13 14:11:03 --> Router Class Initialized
INFO - 2025-05-13 14:11:03 --> Output Class Initialized
INFO - 2025-05-13 14:11:03 --> Security Class Initialized
DEBUG - 2025-05-13 14:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:11:03 --> Input Class Initialized
INFO - 2025-05-13 14:11:03 --> Language Class Initialized
INFO - 2025-05-13 14:11:03 --> Loader Class Initialized
INFO - 2025-05-13 14:11:03 --> Helper loaded: url_helper
INFO - 2025-05-13 14:11:03 --> Helper loaded: form_helper
INFO - 2025-05-13 14:11:03 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:11:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:11:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:11:03 --> Controller Class Initialized
INFO - 2025-05-13 14:11:03 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:11:03 --> Model "User_model" initialized
INFO - 2025-05-13 14:11:03 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 14:11:03 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 14:11:03 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-13 14:11:03 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 14:11:03 --> Final output sent to browser
DEBUG - 2025-05-13 14:11:03 --> Total execution time: 0.0723
INFO - 2025-05-13 14:14:54 --> Config Class Initialized
INFO - 2025-05-13 14:14:54 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:14:54 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:14:54 --> Utf8 Class Initialized
INFO - 2025-05-13 14:14:54 --> URI Class Initialized
INFO - 2025-05-13 14:14:54 --> Router Class Initialized
INFO - 2025-05-13 14:14:54 --> Output Class Initialized
INFO - 2025-05-13 14:14:54 --> Security Class Initialized
DEBUG - 2025-05-13 14:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:14:54 --> Input Class Initialized
INFO - 2025-05-13 14:14:54 --> Language Class Initialized
INFO - 2025-05-13 14:14:54 --> Loader Class Initialized
INFO - 2025-05-13 14:14:54 --> Helper loaded: url_helper
INFO - 2025-05-13 14:14:54 --> Helper loaded: form_helper
INFO - 2025-05-13 14:14:54 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:14:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:14:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:14:54 --> Controller Class Initialized
INFO - 2025-05-13 14:14:54 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:14:54 --> Model "User_model" initialized
INFO - 2025-05-13 14:14:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 14:14:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 14:14:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-13 14:14:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 14:14:54 --> Final output sent to browser
DEBUG - 2025-05-13 14:14:54 --> Total execution time: 0.0684
INFO - 2025-05-13 14:14:55 --> Config Class Initialized
INFO - 2025-05-13 14:14:55 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:14:55 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:14:55 --> Utf8 Class Initialized
INFO - 2025-05-13 14:14:55 --> URI Class Initialized
INFO - 2025-05-13 14:14:55 --> Router Class Initialized
INFO - 2025-05-13 14:14:55 --> Output Class Initialized
INFO - 2025-05-13 14:14:55 --> Security Class Initialized
DEBUG - 2025-05-13 14:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:14:55 --> Input Class Initialized
INFO - 2025-05-13 14:14:55 --> Language Class Initialized
INFO - 2025-05-13 14:14:55 --> Loader Class Initialized
INFO - 2025-05-13 14:14:55 --> Helper loaded: url_helper
INFO - 2025-05-13 14:14:55 --> Helper loaded: form_helper
INFO - 2025-05-13 14:14:55 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:14:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:14:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:14:55 --> Controller Class Initialized
INFO - 2025-05-13 14:14:55 --> Model "User_model" initialized
INFO - 2025-05-13 14:14:55 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:14:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 14:14:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 14:14:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-13 14:14:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 14:14:55 --> Final output sent to browser
DEBUG - 2025-05-13 14:14:55 --> Total execution time: 0.0819
INFO - 2025-05-13 14:14:57 --> Config Class Initialized
INFO - 2025-05-13 14:14:57 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:14:57 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:14:57 --> Utf8 Class Initialized
INFO - 2025-05-13 14:14:57 --> URI Class Initialized
INFO - 2025-05-13 14:14:57 --> Router Class Initialized
INFO - 2025-05-13 14:14:57 --> Output Class Initialized
INFO - 2025-05-13 14:14:57 --> Security Class Initialized
DEBUG - 2025-05-13 14:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:14:57 --> Input Class Initialized
INFO - 2025-05-13 14:14:57 --> Language Class Initialized
INFO - 2025-05-13 14:14:57 --> Loader Class Initialized
INFO - 2025-05-13 14:14:57 --> Helper loaded: url_helper
INFO - 2025-05-13 14:14:57 --> Helper loaded: form_helper
INFO - 2025-05-13 14:14:57 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:14:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:14:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:14:57 --> Controller Class Initialized
INFO - 2025-05-13 14:14:57 --> Model "User_model" initialized
INFO - 2025-05-13 14:14:57 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:14:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 14:14:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 14:14:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 14:14:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 14:14:57 --> Final output sent to browser
DEBUG - 2025-05-13 14:14:57 --> Total execution time: 0.0779
INFO - 2025-05-13 14:15:01 --> Config Class Initialized
INFO - 2025-05-13 14:15:01 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:15:01 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:15:01 --> Utf8 Class Initialized
INFO - 2025-05-13 14:15:01 --> URI Class Initialized
INFO - 2025-05-13 14:15:01 --> Router Class Initialized
INFO - 2025-05-13 14:15:01 --> Output Class Initialized
INFO - 2025-05-13 14:15:01 --> Security Class Initialized
DEBUG - 2025-05-13 14:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:15:01 --> Input Class Initialized
INFO - 2025-05-13 14:15:01 --> Language Class Initialized
INFO - 2025-05-13 14:15:01 --> Loader Class Initialized
INFO - 2025-05-13 14:15:01 --> Helper loaded: url_helper
INFO - 2025-05-13 14:15:01 --> Helper loaded: form_helper
INFO - 2025-05-13 14:15:01 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:15:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:15:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:15:01 --> Controller Class Initialized
INFO - 2025-05-13 14:15:01 --> Model "User_model" initialized
INFO - 2025-05-13 14:15:01 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:15:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 14:15:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 14:15:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 14:15:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 14:15:01 --> Final output sent to browser
DEBUG - 2025-05-13 14:15:01 --> Total execution time: 0.1281
INFO - 2025-05-13 14:15:05 --> Config Class Initialized
INFO - 2025-05-13 14:15:05 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:15:05 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:15:05 --> Utf8 Class Initialized
INFO - 2025-05-13 14:15:05 --> URI Class Initialized
INFO - 2025-05-13 14:15:05 --> Router Class Initialized
INFO - 2025-05-13 14:15:05 --> Output Class Initialized
INFO - 2025-05-13 14:15:05 --> Security Class Initialized
DEBUG - 2025-05-13 14:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:15:05 --> Input Class Initialized
INFO - 2025-05-13 14:15:05 --> Language Class Initialized
INFO - 2025-05-13 14:15:05 --> Loader Class Initialized
INFO - 2025-05-13 14:15:05 --> Helper loaded: url_helper
INFO - 2025-05-13 14:15:05 --> Helper loaded: form_helper
INFO - 2025-05-13 14:15:05 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:15:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:15:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:15:05 --> Controller Class Initialized
INFO - 2025-05-13 14:15:05 --> Model "User_model" initialized
INFO - 2025-05-13 14:15:05 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:15:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 14:15:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 14:15:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-13 14:15:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 14:15:05 --> Final output sent to browser
DEBUG - 2025-05-13 14:15:05 --> Total execution time: 0.0574
INFO - 2025-05-13 14:15:08 --> Config Class Initialized
INFO - 2025-05-13 14:15:08 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:15:08 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:15:08 --> Utf8 Class Initialized
INFO - 2025-05-13 14:15:08 --> URI Class Initialized
INFO - 2025-05-13 14:15:08 --> Router Class Initialized
INFO - 2025-05-13 14:15:08 --> Output Class Initialized
INFO - 2025-05-13 14:15:08 --> Security Class Initialized
DEBUG - 2025-05-13 14:15:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:15:08 --> Input Class Initialized
INFO - 2025-05-13 14:15:08 --> Language Class Initialized
INFO - 2025-05-13 14:15:08 --> Loader Class Initialized
INFO - 2025-05-13 14:15:08 --> Helper loaded: url_helper
INFO - 2025-05-13 14:15:08 --> Helper loaded: form_helper
INFO - 2025-05-13 14:15:08 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:15:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:15:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:15:08 --> Controller Class Initialized
INFO - 2025-05-13 14:15:08 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:15:08 --> Model "User_model" initialized
INFO - 2025-05-13 14:15:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 14:15:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 14:15:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-13 14:15:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 14:15:08 --> Final output sent to browser
DEBUG - 2025-05-13 14:15:08 --> Total execution time: 0.0902
INFO - 2025-05-13 14:15:20 --> Config Class Initialized
INFO - 2025-05-13 14:15:20 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:15:20 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:15:20 --> Utf8 Class Initialized
INFO - 2025-05-13 14:15:20 --> URI Class Initialized
INFO - 2025-05-13 14:15:20 --> Router Class Initialized
INFO - 2025-05-13 14:15:20 --> Output Class Initialized
INFO - 2025-05-13 14:15:20 --> Security Class Initialized
DEBUG - 2025-05-13 14:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:15:20 --> Input Class Initialized
INFO - 2025-05-13 14:15:20 --> Language Class Initialized
INFO - 2025-05-13 14:15:20 --> Loader Class Initialized
INFO - 2025-05-13 14:15:20 --> Helper loaded: url_helper
INFO - 2025-05-13 14:15:20 --> Helper loaded: form_helper
INFO - 2025-05-13 14:15:20 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:15:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:15:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:15:20 --> Controller Class Initialized
INFO - 2025-05-13 14:15:20 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:15:20 --> Model "User_model" initialized
INFO - 2025-05-13 14:15:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 14:15:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 14:15:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-13 14:15:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 14:15:20 --> Final output sent to browser
DEBUG - 2025-05-13 14:15:20 --> Total execution time: 0.0826
INFO - 2025-05-13 14:16:17 --> Config Class Initialized
INFO - 2025-05-13 14:16:17 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:16:17 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:16:17 --> Utf8 Class Initialized
INFO - 2025-05-13 14:16:17 --> URI Class Initialized
INFO - 2025-05-13 14:16:17 --> Router Class Initialized
INFO - 2025-05-13 14:16:17 --> Output Class Initialized
INFO - 2025-05-13 14:16:17 --> Security Class Initialized
DEBUG - 2025-05-13 14:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:16:17 --> Input Class Initialized
INFO - 2025-05-13 14:16:17 --> Language Class Initialized
INFO - 2025-05-13 14:16:17 --> Loader Class Initialized
INFO - 2025-05-13 14:16:17 --> Helper loaded: url_helper
INFO - 2025-05-13 14:16:17 --> Helper loaded: form_helper
INFO - 2025-05-13 14:16:17 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:16:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:16:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:16:17 --> Controller Class Initialized
INFO - 2025-05-13 14:16:17 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:16:17 --> Model "User_model" initialized
INFO - 2025-05-13 14:16:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 14:16:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 14:16:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-13 14:16:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 14:16:17 --> Final output sent to browser
DEBUG - 2025-05-13 14:16:17 --> Total execution time: 0.0859
INFO - 2025-05-13 14:17:39 --> Config Class Initialized
INFO - 2025-05-13 14:17:39 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:17:39 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:17:39 --> Utf8 Class Initialized
INFO - 2025-05-13 14:17:39 --> URI Class Initialized
INFO - 2025-05-13 14:17:39 --> Router Class Initialized
INFO - 2025-05-13 14:17:39 --> Output Class Initialized
INFO - 2025-05-13 14:17:39 --> Security Class Initialized
DEBUG - 2025-05-13 14:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:17:39 --> Input Class Initialized
INFO - 2025-05-13 14:17:39 --> Language Class Initialized
INFO - 2025-05-13 14:17:39 --> Loader Class Initialized
INFO - 2025-05-13 14:17:39 --> Helper loaded: url_helper
INFO - 2025-05-13 14:17:39 --> Helper loaded: form_helper
INFO - 2025-05-13 14:17:39 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:17:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:17:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:17:39 --> Controller Class Initialized
INFO - 2025-05-13 14:17:39 --> Model "User_model" initialized
INFO - 2025-05-13 14:17:39 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:17:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 14:17:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 14:17:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-13 14:17:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 14:17:39 --> Final output sent to browser
DEBUG - 2025-05-13 14:17:39 --> Total execution time: 0.0863
INFO - 2025-05-13 14:17:41 --> Config Class Initialized
INFO - 2025-05-13 14:17:41 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:17:41 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:17:41 --> Utf8 Class Initialized
INFO - 2025-05-13 14:17:41 --> URI Class Initialized
INFO - 2025-05-13 14:17:41 --> Router Class Initialized
INFO - 2025-05-13 14:17:41 --> Output Class Initialized
INFO - 2025-05-13 14:17:41 --> Security Class Initialized
DEBUG - 2025-05-13 14:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:17:41 --> Input Class Initialized
INFO - 2025-05-13 14:17:41 --> Language Class Initialized
INFO - 2025-05-13 14:17:41 --> Loader Class Initialized
INFO - 2025-05-13 14:17:41 --> Helper loaded: url_helper
INFO - 2025-05-13 14:17:41 --> Helper loaded: form_helper
INFO - 2025-05-13 14:17:41 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:17:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:17:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:17:41 --> Controller Class Initialized
INFO - 2025-05-13 14:17:41 --> Model "User_model" initialized
INFO - 2025-05-13 14:17:41 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:17:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 14:17:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 14:17:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 14:17:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 14:17:41 --> Final output sent to browser
DEBUG - 2025-05-13 14:17:41 --> Total execution time: 0.0637
INFO - 2025-05-13 14:17:43 --> Config Class Initialized
INFO - 2025-05-13 14:17:43 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:17:43 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:17:43 --> Utf8 Class Initialized
INFO - 2025-05-13 14:17:43 --> URI Class Initialized
INFO - 2025-05-13 14:17:43 --> Router Class Initialized
INFO - 2025-05-13 14:17:43 --> Output Class Initialized
INFO - 2025-05-13 14:17:43 --> Security Class Initialized
DEBUG - 2025-05-13 14:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:17:43 --> Input Class Initialized
INFO - 2025-05-13 14:17:43 --> Language Class Initialized
INFO - 2025-05-13 14:17:43 --> Loader Class Initialized
INFO - 2025-05-13 14:17:43 --> Helper loaded: url_helper
INFO - 2025-05-13 14:17:43 --> Helper loaded: form_helper
INFO - 2025-05-13 14:17:43 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:17:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:17:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:17:43 --> Controller Class Initialized
INFO - 2025-05-13 14:17:43 --> Model "User_model" initialized
INFO - 2025-05-13 14:17:43 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:17:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 14:17:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 14:17:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-13 14:17:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 14:17:43 --> Final output sent to browser
DEBUG - 2025-05-13 14:17:43 --> Total execution time: 0.0666
INFO - 2025-05-13 14:19:01 --> Config Class Initialized
INFO - 2025-05-13 14:19:01 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:19:01 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:19:01 --> Utf8 Class Initialized
INFO - 2025-05-13 14:19:01 --> URI Class Initialized
INFO - 2025-05-13 14:19:01 --> Router Class Initialized
INFO - 2025-05-13 14:19:01 --> Output Class Initialized
INFO - 2025-05-13 14:19:01 --> Security Class Initialized
DEBUG - 2025-05-13 14:19:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:19:01 --> Input Class Initialized
INFO - 2025-05-13 14:19:01 --> Language Class Initialized
INFO - 2025-05-13 14:19:01 --> Loader Class Initialized
INFO - 2025-05-13 14:19:01 --> Helper loaded: url_helper
INFO - 2025-05-13 14:19:01 --> Helper loaded: form_helper
INFO - 2025-05-13 14:19:01 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:19:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:19:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:19:01 --> Controller Class Initialized
INFO - 2025-05-13 14:19:01 --> Model "User_model" initialized
INFO - 2025-05-13 14:19:01 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:19:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 14:19:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 14:19:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-13 14:19:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 14:19:01 --> Final output sent to browser
DEBUG - 2025-05-13 14:19:01 --> Total execution time: 0.0652
INFO - 2025-05-13 14:19:24 --> Config Class Initialized
INFO - 2025-05-13 14:19:24 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:19:24 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:19:24 --> Utf8 Class Initialized
INFO - 2025-05-13 14:19:24 --> URI Class Initialized
INFO - 2025-05-13 14:19:24 --> Router Class Initialized
INFO - 2025-05-13 14:19:24 --> Output Class Initialized
INFO - 2025-05-13 14:19:24 --> Security Class Initialized
DEBUG - 2025-05-13 14:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:19:24 --> Input Class Initialized
INFO - 2025-05-13 14:19:24 --> Language Class Initialized
INFO - 2025-05-13 14:19:24 --> Loader Class Initialized
INFO - 2025-05-13 14:19:24 --> Helper loaded: url_helper
INFO - 2025-05-13 14:19:24 --> Helper loaded: form_helper
INFO - 2025-05-13 14:19:24 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:19:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:19:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:19:24 --> Controller Class Initialized
INFO - 2025-05-13 14:19:24 --> Model "User_model" initialized
INFO - 2025-05-13 14:19:24 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:19:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 14:19:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 14:19:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-13 14:19:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 14:19:24 --> Final output sent to browser
DEBUG - 2025-05-13 14:19:24 --> Total execution time: 0.0695
INFO - 2025-05-13 14:21:59 --> Config Class Initialized
INFO - 2025-05-13 14:21:59 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:21:59 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:21:59 --> Utf8 Class Initialized
INFO - 2025-05-13 14:21:59 --> URI Class Initialized
INFO - 2025-05-13 14:21:59 --> Router Class Initialized
INFO - 2025-05-13 14:21:59 --> Output Class Initialized
INFO - 2025-05-13 14:21:59 --> Security Class Initialized
DEBUG - 2025-05-13 14:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:21:59 --> Input Class Initialized
INFO - 2025-05-13 14:21:59 --> Language Class Initialized
INFO - 2025-05-13 14:21:59 --> Loader Class Initialized
INFO - 2025-05-13 14:21:59 --> Helper loaded: url_helper
INFO - 2025-05-13 14:21:59 --> Helper loaded: form_helper
INFO - 2025-05-13 14:21:59 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:21:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:21:59 --> Controller Class Initialized
INFO - 2025-05-13 14:21:59 --> Model "User_model" initialized
INFO - 2025-05-13 14:21:59 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:21:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 14:21:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 14:21:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-13 14:21:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 14:21:59 --> Final output sent to browser
DEBUG - 2025-05-13 14:21:59 --> Total execution time: 0.0752
INFO - 2025-05-13 14:22:06 --> Config Class Initialized
INFO - 2025-05-13 14:22:06 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:22:06 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:22:06 --> Utf8 Class Initialized
INFO - 2025-05-13 14:22:06 --> URI Class Initialized
INFO - 2025-05-13 14:22:06 --> Router Class Initialized
INFO - 2025-05-13 14:22:06 --> Output Class Initialized
INFO - 2025-05-13 14:22:06 --> Security Class Initialized
DEBUG - 2025-05-13 14:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:22:06 --> Input Class Initialized
INFO - 2025-05-13 14:22:06 --> Language Class Initialized
INFO - 2025-05-13 14:22:06 --> Loader Class Initialized
INFO - 2025-05-13 14:22:06 --> Helper loaded: url_helper
INFO - 2025-05-13 14:22:06 --> Helper loaded: form_helper
INFO - 2025-05-13 14:22:06 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:22:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:22:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:22:06 --> Controller Class Initialized
INFO - 2025-05-13 14:22:06 --> Model "User_model" initialized
INFO - 2025-05-13 14:22:06 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:22:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 14:22:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 14:22:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 14:22:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 14:22:06 --> Final output sent to browser
DEBUG - 2025-05-13 14:22:06 --> Total execution time: 0.0696
INFO - 2025-05-13 14:22:42 --> Config Class Initialized
INFO - 2025-05-13 14:22:42 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:22:42 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:22:42 --> Utf8 Class Initialized
INFO - 2025-05-13 14:22:42 --> URI Class Initialized
INFO - 2025-05-13 14:22:42 --> Router Class Initialized
INFO - 2025-05-13 14:22:42 --> Output Class Initialized
INFO - 2025-05-13 14:22:42 --> Security Class Initialized
DEBUG - 2025-05-13 14:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:22:42 --> Input Class Initialized
INFO - 2025-05-13 14:22:42 --> Language Class Initialized
INFO - 2025-05-13 14:22:42 --> Loader Class Initialized
INFO - 2025-05-13 14:22:42 --> Helper loaded: url_helper
INFO - 2025-05-13 14:22:42 --> Helper loaded: form_helper
INFO - 2025-05-13 14:22:42 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:22:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:22:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:22:42 --> Controller Class Initialized
INFO - 2025-05-13 14:22:42 --> Model "User_model" initialized
INFO - 2025-05-13 14:22:42 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:22:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 14:22:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 14:22:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 14:22:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 14:22:42 --> Final output sent to browser
DEBUG - 2025-05-13 14:22:42 --> Total execution time: 0.0879
INFO - 2025-05-13 14:22:44 --> Config Class Initialized
INFO - 2025-05-13 14:22:44 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:22:44 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:22:44 --> Utf8 Class Initialized
INFO - 2025-05-13 14:22:44 --> URI Class Initialized
INFO - 2025-05-13 14:22:44 --> Router Class Initialized
INFO - 2025-05-13 14:22:44 --> Output Class Initialized
INFO - 2025-05-13 14:22:44 --> Security Class Initialized
DEBUG - 2025-05-13 14:22:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:22:44 --> Input Class Initialized
INFO - 2025-05-13 14:22:44 --> Language Class Initialized
INFO - 2025-05-13 14:22:44 --> Loader Class Initialized
INFO - 2025-05-13 14:22:44 --> Helper loaded: url_helper
INFO - 2025-05-13 14:22:44 --> Helper loaded: form_helper
INFO - 2025-05-13 14:22:44 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:22:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:22:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:22:44 --> Controller Class Initialized
INFO - 2025-05-13 14:22:44 --> Model "User_model" initialized
INFO - 2025-05-13 14:22:44 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:22:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 14:22:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 14:22:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 14:22:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 14:22:44 --> Final output sent to browser
DEBUG - 2025-05-13 14:22:44 --> Total execution time: 0.0736
INFO - 2025-05-13 14:22:51 --> Config Class Initialized
INFO - 2025-05-13 14:22:51 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:22:51 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:22:51 --> Utf8 Class Initialized
INFO - 2025-05-13 14:22:51 --> URI Class Initialized
INFO - 2025-05-13 14:22:51 --> Router Class Initialized
INFO - 2025-05-13 14:22:51 --> Output Class Initialized
INFO - 2025-05-13 14:22:51 --> Security Class Initialized
DEBUG - 2025-05-13 14:22:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:22:51 --> Input Class Initialized
INFO - 2025-05-13 14:22:51 --> Language Class Initialized
INFO - 2025-05-13 14:22:51 --> Loader Class Initialized
INFO - 2025-05-13 14:22:51 --> Helper loaded: url_helper
INFO - 2025-05-13 14:22:51 --> Helper loaded: form_helper
INFO - 2025-05-13 14:22:51 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:22:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:22:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:22:51 --> Controller Class Initialized
INFO - 2025-05-13 14:22:51 --> Model "User_model" initialized
INFO - 2025-05-13 14:22:51 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:22:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 14:22:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 14:22:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 14:22:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 14:22:51 --> Final output sent to browser
DEBUG - 2025-05-13 14:22:51 --> Total execution time: 0.0675
INFO - 2025-05-13 14:23:06 --> Config Class Initialized
INFO - 2025-05-13 14:23:06 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:23:06 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:23:06 --> Utf8 Class Initialized
INFO - 2025-05-13 14:23:06 --> URI Class Initialized
INFO - 2025-05-13 14:23:06 --> Router Class Initialized
INFO - 2025-05-13 14:23:06 --> Output Class Initialized
INFO - 2025-05-13 14:23:06 --> Security Class Initialized
DEBUG - 2025-05-13 14:23:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:23:06 --> Input Class Initialized
INFO - 2025-05-13 14:23:06 --> Language Class Initialized
INFO - 2025-05-13 14:23:06 --> Loader Class Initialized
INFO - 2025-05-13 14:23:06 --> Helper loaded: url_helper
INFO - 2025-05-13 14:23:06 --> Helper loaded: form_helper
INFO - 2025-05-13 14:23:06 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:23:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:23:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:23:06 --> Controller Class Initialized
INFO - 2025-05-13 14:23:06 --> Model "User_model" initialized
INFO - 2025-05-13 14:23:06 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:23:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 14:23:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 14:23:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 14:23:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 14:23:06 --> Final output sent to browser
DEBUG - 2025-05-13 14:23:06 --> Total execution time: 0.0771
INFO - 2025-05-13 14:23:07 --> Config Class Initialized
INFO - 2025-05-13 14:23:07 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:23:08 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:23:08 --> Utf8 Class Initialized
INFO - 2025-05-13 14:23:08 --> URI Class Initialized
INFO - 2025-05-13 14:23:08 --> Router Class Initialized
INFO - 2025-05-13 14:23:08 --> Output Class Initialized
INFO - 2025-05-13 14:23:08 --> Security Class Initialized
DEBUG - 2025-05-13 14:23:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:23:08 --> Input Class Initialized
INFO - 2025-05-13 14:23:08 --> Language Class Initialized
INFO - 2025-05-13 14:23:08 --> Loader Class Initialized
INFO - 2025-05-13 14:23:08 --> Helper loaded: url_helper
INFO - 2025-05-13 14:23:08 --> Helper loaded: form_helper
INFO - 2025-05-13 14:23:08 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:23:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:23:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:23:08 --> Controller Class Initialized
INFO - 2025-05-13 14:23:08 --> Model "User_model" initialized
INFO - 2025-05-13 14:23:08 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:23:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 14:23:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 14:23:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 14:23:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 14:23:08 --> Final output sent to browser
DEBUG - 2025-05-13 14:23:08 --> Total execution time: 0.0729
INFO - 2025-05-13 14:23:08 --> Config Class Initialized
INFO - 2025-05-13 14:23:08 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:23:08 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:23:08 --> Utf8 Class Initialized
INFO - 2025-05-13 14:23:08 --> URI Class Initialized
INFO - 2025-05-13 14:23:08 --> Router Class Initialized
INFO - 2025-05-13 14:23:08 --> Output Class Initialized
INFO - 2025-05-13 14:23:08 --> Security Class Initialized
DEBUG - 2025-05-13 14:23:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:23:08 --> Input Class Initialized
INFO - 2025-05-13 14:23:08 --> Language Class Initialized
INFO - 2025-05-13 14:23:08 --> Loader Class Initialized
INFO - 2025-05-13 14:23:08 --> Helper loaded: url_helper
INFO - 2025-05-13 14:23:08 --> Helper loaded: form_helper
INFO - 2025-05-13 14:23:08 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:23:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:23:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:23:08 --> Controller Class Initialized
INFO - 2025-05-13 14:23:08 --> Model "User_model" initialized
INFO - 2025-05-13 14:23:08 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:23:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 14:23:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 14:23:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 14:23:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 14:23:08 --> Final output sent to browser
DEBUG - 2025-05-13 14:23:08 --> Total execution time: 0.0693
INFO - 2025-05-13 14:23:09 --> Config Class Initialized
INFO - 2025-05-13 14:23:09 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:23:09 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:23:09 --> Utf8 Class Initialized
INFO - 2025-05-13 14:23:09 --> URI Class Initialized
INFO - 2025-05-13 14:23:09 --> Router Class Initialized
INFO - 2025-05-13 14:23:09 --> Output Class Initialized
INFO - 2025-05-13 14:23:09 --> Security Class Initialized
DEBUG - 2025-05-13 14:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:23:09 --> Input Class Initialized
INFO - 2025-05-13 14:23:09 --> Language Class Initialized
INFO - 2025-05-13 14:23:09 --> Loader Class Initialized
INFO - 2025-05-13 14:23:09 --> Helper loaded: url_helper
INFO - 2025-05-13 14:23:09 --> Helper loaded: form_helper
INFO - 2025-05-13 14:23:09 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:23:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:23:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:23:09 --> Controller Class Initialized
INFO - 2025-05-13 14:23:09 --> Model "User_model" initialized
INFO - 2025-05-13 14:23:09 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:23:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 14:23:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 14:23:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 14:23:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 14:23:09 --> Final output sent to browser
DEBUG - 2025-05-13 14:23:09 --> Total execution time: 0.0633
INFO - 2025-05-13 14:23:54 --> Config Class Initialized
INFO - 2025-05-13 14:23:54 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:23:54 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:23:54 --> Utf8 Class Initialized
INFO - 2025-05-13 14:23:54 --> URI Class Initialized
INFO - 2025-05-13 14:23:54 --> Router Class Initialized
INFO - 2025-05-13 14:23:54 --> Output Class Initialized
INFO - 2025-05-13 14:23:54 --> Security Class Initialized
DEBUG - 2025-05-13 14:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:23:54 --> Input Class Initialized
INFO - 2025-05-13 14:23:54 --> Language Class Initialized
INFO - 2025-05-13 14:23:54 --> Loader Class Initialized
INFO - 2025-05-13 14:23:54 --> Helper loaded: url_helper
INFO - 2025-05-13 14:23:54 --> Helper loaded: form_helper
INFO - 2025-05-13 14:23:54 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:23:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:23:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:23:54 --> Controller Class Initialized
INFO - 2025-05-13 14:23:54 --> Model "User_model" initialized
INFO - 2025-05-13 14:23:54 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:23:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 14:23:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 14:23:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 14:23:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 14:23:54 --> Final output sent to browser
DEBUG - 2025-05-13 14:23:54 --> Total execution time: 0.0840
INFO - 2025-05-13 14:23:57 --> Config Class Initialized
INFO - 2025-05-13 14:23:57 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:23:57 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:23:57 --> Utf8 Class Initialized
INFO - 2025-05-13 14:23:57 --> URI Class Initialized
INFO - 2025-05-13 14:23:57 --> Router Class Initialized
INFO - 2025-05-13 14:23:57 --> Output Class Initialized
INFO - 2025-05-13 14:23:57 --> Security Class Initialized
DEBUG - 2025-05-13 14:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:23:57 --> Input Class Initialized
INFO - 2025-05-13 14:23:57 --> Language Class Initialized
INFO - 2025-05-13 14:23:57 --> Loader Class Initialized
INFO - 2025-05-13 14:23:57 --> Helper loaded: url_helper
INFO - 2025-05-13 14:23:57 --> Helper loaded: form_helper
INFO - 2025-05-13 14:23:57 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:23:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:23:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:23:57 --> Controller Class Initialized
INFO - 2025-05-13 14:23:57 --> Model "User_model" initialized
INFO - 2025-05-13 14:23:57 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:23:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 14:23:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 14:23:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-13 14:23:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 14:23:57 --> Final output sent to browser
DEBUG - 2025-05-13 14:23:57 --> Total execution time: 0.0774
INFO - 2025-05-13 14:23:59 --> Config Class Initialized
INFO - 2025-05-13 14:23:59 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:23:59 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:23:59 --> Utf8 Class Initialized
INFO - 2025-05-13 14:23:59 --> URI Class Initialized
INFO - 2025-05-13 14:23:59 --> Router Class Initialized
INFO - 2025-05-13 14:23:59 --> Output Class Initialized
INFO - 2025-05-13 14:23:59 --> Security Class Initialized
DEBUG - 2025-05-13 14:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:23:59 --> Input Class Initialized
INFO - 2025-05-13 14:23:59 --> Language Class Initialized
INFO - 2025-05-13 14:23:59 --> Loader Class Initialized
INFO - 2025-05-13 14:23:59 --> Helper loaded: url_helper
INFO - 2025-05-13 14:23:59 --> Helper loaded: form_helper
INFO - 2025-05-13 14:23:59 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:23:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:23:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:23:59 --> Controller Class Initialized
INFO - 2025-05-13 14:23:59 --> Model "User_model" initialized
INFO - 2025-05-13 14:23:59 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:23:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 14:23:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 14:23:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 14:23:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 14:23:59 --> Final output sent to browser
DEBUG - 2025-05-13 14:23:59 --> Total execution time: 0.0812
INFO - 2025-05-13 14:25:02 --> Config Class Initialized
INFO - 2025-05-13 14:25:02 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:25:02 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:25:02 --> Utf8 Class Initialized
INFO - 2025-05-13 14:25:02 --> URI Class Initialized
INFO - 2025-05-13 14:25:02 --> Router Class Initialized
INFO - 2025-05-13 14:25:02 --> Output Class Initialized
INFO - 2025-05-13 14:25:02 --> Security Class Initialized
DEBUG - 2025-05-13 14:25:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:25:02 --> Input Class Initialized
INFO - 2025-05-13 14:25:02 --> Language Class Initialized
INFO - 2025-05-13 14:25:02 --> Loader Class Initialized
INFO - 2025-05-13 14:25:02 --> Helper loaded: url_helper
INFO - 2025-05-13 14:25:02 --> Helper loaded: form_helper
INFO - 2025-05-13 14:25:02 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:25:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:25:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:25:02 --> Controller Class Initialized
INFO - 2025-05-13 14:25:02 --> Model "User_model" initialized
INFO - 2025-05-13 14:25:02 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:25:02 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 14:25:02 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 14:25:02 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 14:25:02 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 14:25:02 --> Final output sent to browser
DEBUG - 2025-05-13 14:25:02 --> Total execution time: 0.0834
INFO - 2025-05-13 14:25:35 --> Config Class Initialized
INFO - 2025-05-13 14:25:35 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:25:35 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:25:35 --> Utf8 Class Initialized
INFO - 2025-05-13 14:25:35 --> URI Class Initialized
INFO - 2025-05-13 14:25:35 --> Router Class Initialized
INFO - 2025-05-13 14:25:35 --> Output Class Initialized
INFO - 2025-05-13 14:25:35 --> Security Class Initialized
DEBUG - 2025-05-13 14:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:25:35 --> Input Class Initialized
INFO - 2025-05-13 14:25:36 --> Language Class Initialized
INFO - 2025-05-13 14:25:36 --> Loader Class Initialized
INFO - 2025-05-13 14:25:36 --> Helper loaded: url_helper
INFO - 2025-05-13 14:25:36 --> Helper loaded: form_helper
INFO - 2025-05-13 14:25:36 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:25:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:25:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:25:36 --> Controller Class Initialized
INFO - 2025-05-13 14:25:36 --> Model "User_model" initialized
INFO - 2025-05-13 14:25:36 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:25:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 14:25:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 14:25:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 14:25:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 14:25:36 --> Final output sent to browser
DEBUG - 2025-05-13 14:25:36 --> Total execution time: 0.0826
INFO - 2025-05-13 14:25:52 --> Config Class Initialized
INFO - 2025-05-13 14:25:52 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:25:52 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:25:52 --> Utf8 Class Initialized
INFO - 2025-05-13 14:25:52 --> URI Class Initialized
INFO - 2025-05-13 14:25:52 --> Router Class Initialized
INFO - 2025-05-13 14:25:52 --> Output Class Initialized
INFO - 2025-05-13 14:25:52 --> Security Class Initialized
DEBUG - 2025-05-13 14:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:25:52 --> Input Class Initialized
INFO - 2025-05-13 14:25:52 --> Language Class Initialized
INFO - 2025-05-13 14:25:52 --> Loader Class Initialized
INFO - 2025-05-13 14:25:52 --> Helper loaded: url_helper
INFO - 2025-05-13 14:25:52 --> Helper loaded: form_helper
INFO - 2025-05-13 14:25:52 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:25:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:25:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:25:52 --> Controller Class Initialized
INFO - 2025-05-13 14:25:52 --> Model "User_model" initialized
INFO - 2025-05-13 14:25:52 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:25:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 14:25:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 14:25:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 14:25:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 14:25:52 --> Final output sent to browser
DEBUG - 2025-05-13 14:25:52 --> Total execution time: 0.0713
INFO - 2025-05-13 14:26:14 --> Config Class Initialized
INFO - 2025-05-13 14:26:14 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:26:14 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:26:14 --> Utf8 Class Initialized
INFO - 2025-05-13 14:26:14 --> URI Class Initialized
INFO - 2025-05-13 14:26:14 --> Router Class Initialized
INFO - 2025-05-13 14:26:14 --> Output Class Initialized
INFO - 2025-05-13 14:26:14 --> Security Class Initialized
DEBUG - 2025-05-13 14:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:26:14 --> Input Class Initialized
INFO - 2025-05-13 14:26:14 --> Language Class Initialized
INFO - 2025-05-13 14:26:14 --> Loader Class Initialized
INFO - 2025-05-13 14:26:14 --> Helper loaded: url_helper
INFO - 2025-05-13 14:26:14 --> Helper loaded: form_helper
INFO - 2025-05-13 14:26:14 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:26:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:26:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:26:14 --> Controller Class Initialized
INFO - 2025-05-13 14:26:14 --> Model "User_model" initialized
INFO - 2025-05-13 14:26:14 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:26:14 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 14:26:14 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 14:26:14 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 14:26:14 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 14:26:14 --> Final output sent to browser
DEBUG - 2025-05-13 14:26:14 --> Total execution time: 0.0884
INFO - 2025-05-13 14:26:28 --> Config Class Initialized
INFO - 2025-05-13 14:26:28 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:26:28 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:26:28 --> Utf8 Class Initialized
INFO - 2025-05-13 14:26:28 --> URI Class Initialized
INFO - 2025-05-13 14:26:28 --> Router Class Initialized
INFO - 2025-05-13 14:26:28 --> Output Class Initialized
INFO - 2025-05-13 14:26:28 --> Security Class Initialized
DEBUG - 2025-05-13 14:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:26:28 --> Input Class Initialized
INFO - 2025-05-13 14:26:28 --> Language Class Initialized
INFO - 2025-05-13 14:26:28 --> Loader Class Initialized
INFO - 2025-05-13 14:26:28 --> Helper loaded: url_helper
INFO - 2025-05-13 14:26:28 --> Helper loaded: form_helper
INFO - 2025-05-13 14:26:28 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:26:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:26:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:26:28 --> Controller Class Initialized
INFO - 2025-05-13 14:26:28 --> Model "User_model" initialized
INFO - 2025-05-13 14:26:28 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:26:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 14:26:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 14:26:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 14:26:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 14:26:28 --> Final output sent to browser
DEBUG - 2025-05-13 14:26:28 --> Total execution time: 0.0753
INFO - 2025-05-13 14:26:57 --> Config Class Initialized
INFO - 2025-05-13 14:26:57 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:26:57 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:26:57 --> Utf8 Class Initialized
INFO - 2025-05-13 14:26:57 --> URI Class Initialized
INFO - 2025-05-13 14:26:57 --> Router Class Initialized
INFO - 2025-05-13 14:26:57 --> Output Class Initialized
INFO - 2025-05-13 14:26:57 --> Security Class Initialized
DEBUG - 2025-05-13 14:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:26:57 --> Input Class Initialized
INFO - 2025-05-13 14:26:57 --> Language Class Initialized
INFO - 2025-05-13 14:26:57 --> Loader Class Initialized
INFO - 2025-05-13 14:26:57 --> Helper loaded: url_helper
INFO - 2025-05-13 14:26:57 --> Helper loaded: form_helper
INFO - 2025-05-13 14:26:57 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:26:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:26:57 --> Controller Class Initialized
INFO - 2025-05-13 14:26:57 --> Model "User_model" initialized
INFO - 2025-05-13 14:26:57 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:26:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 14:26:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 14:26:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 14:26:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 14:26:57 --> Final output sent to browser
DEBUG - 2025-05-13 14:26:57 --> Total execution time: 0.0685
INFO - 2025-05-13 14:26:58 --> Config Class Initialized
INFO - 2025-05-13 14:26:58 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:26:58 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:26:58 --> Utf8 Class Initialized
INFO - 2025-05-13 14:26:58 --> URI Class Initialized
INFO - 2025-05-13 14:26:58 --> Router Class Initialized
INFO - 2025-05-13 14:26:58 --> Output Class Initialized
INFO - 2025-05-13 14:26:58 --> Security Class Initialized
DEBUG - 2025-05-13 14:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:26:58 --> Input Class Initialized
INFO - 2025-05-13 14:26:58 --> Language Class Initialized
INFO - 2025-05-13 14:26:58 --> Loader Class Initialized
INFO - 2025-05-13 14:26:58 --> Helper loaded: url_helper
INFO - 2025-05-13 14:26:58 --> Helper loaded: form_helper
INFO - 2025-05-13 14:26:58 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:26:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:26:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:26:58 --> Controller Class Initialized
INFO - 2025-05-13 14:26:58 --> Model "User_model" initialized
INFO - 2025-05-13 14:26:58 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:26:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 14:26:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 14:26:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 14:26:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 14:26:58 --> Final output sent to browser
DEBUG - 2025-05-13 14:26:58 --> Total execution time: 0.0873
INFO - 2025-05-13 14:26:59 --> Config Class Initialized
INFO - 2025-05-13 14:26:59 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:26:59 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:26:59 --> Utf8 Class Initialized
INFO - 2025-05-13 14:26:59 --> URI Class Initialized
INFO - 2025-05-13 14:26:59 --> Router Class Initialized
INFO - 2025-05-13 14:26:59 --> Output Class Initialized
INFO - 2025-05-13 14:26:59 --> Security Class Initialized
DEBUG - 2025-05-13 14:26:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:26:59 --> Input Class Initialized
INFO - 2025-05-13 14:26:59 --> Language Class Initialized
INFO - 2025-05-13 14:26:59 --> Loader Class Initialized
INFO - 2025-05-13 14:26:59 --> Helper loaded: url_helper
INFO - 2025-05-13 14:26:59 --> Helper loaded: form_helper
INFO - 2025-05-13 14:26:59 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:26:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:26:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:26:59 --> Controller Class Initialized
INFO - 2025-05-13 14:26:59 --> Model "User_model" initialized
INFO - 2025-05-13 14:26:59 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:26:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 14:26:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 14:26:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 14:26:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 14:26:59 --> Final output sent to browser
DEBUG - 2025-05-13 14:26:59 --> Total execution time: 0.0905
INFO - 2025-05-13 14:27:17 --> Config Class Initialized
INFO - 2025-05-13 14:27:17 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:27:17 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:27:17 --> Utf8 Class Initialized
INFO - 2025-05-13 14:27:17 --> URI Class Initialized
INFO - 2025-05-13 14:27:17 --> Router Class Initialized
INFO - 2025-05-13 14:27:17 --> Output Class Initialized
INFO - 2025-05-13 14:27:17 --> Security Class Initialized
DEBUG - 2025-05-13 14:27:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:27:17 --> Input Class Initialized
INFO - 2025-05-13 14:27:17 --> Language Class Initialized
INFO - 2025-05-13 14:27:17 --> Loader Class Initialized
INFO - 2025-05-13 14:27:17 --> Helper loaded: url_helper
INFO - 2025-05-13 14:27:17 --> Helper loaded: form_helper
INFO - 2025-05-13 14:27:17 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:27:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:27:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:27:17 --> Controller Class Initialized
INFO - 2025-05-13 14:27:17 --> Model "User_model" initialized
INFO - 2025-05-13 14:27:17 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:27:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 14:27:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 14:27:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 14:27:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 14:27:17 --> Final output sent to browser
DEBUG - 2025-05-13 14:27:17 --> Total execution time: 0.0729
INFO - 2025-05-13 14:27:19 --> Config Class Initialized
INFO - 2025-05-13 14:27:19 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:27:19 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:27:19 --> Utf8 Class Initialized
INFO - 2025-05-13 14:27:19 --> URI Class Initialized
INFO - 2025-05-13 14:27:19 --> Router Class Initialized
INFO - 2025-05-13 14:27:19 --> Output Class Initialized
INFO - 2025-05-13 14:27:19 --> Security Class Initialized
DEBUG - 2025-05-13 14:27:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:27:19 --> Input Class Initialized
INFO - 2025-05-13 14:27:19 --> Language Class Initialized
INFO - 2025-05-13 14:27:19 --> Loader Class Initialized
INFO - 2025-05-13 14:27:19 --> Helper loaded: url_helper
INFO - 2025-05-13 14:27:19 --> Helper loaded: form_helper
INFO - 2025-05-13 14:27:19 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:27:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:27:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:27:19 --> Controller Class Initialized
INFO - 2025-05-13 14:27:19 --> Model "User_model" initialized
INFO - 2025-05-13 14:27:19 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:27:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 14:27:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 14:27:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 14:27:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 14:27:19 --> Final output sent to browser
DEBUG - 2025-05-13 14:27:19 --> Total execution time: 0.0840
INFO - 2025-05-13 14:27:20 --> Config Class Initialized
INFO - 2025-05-13 14:27:20 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:27:20 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:27:20 --> Utf8 Class Initialized
INFO - 2025-05-13 14:27:20 --> URI Class Initialized
INFO - 2025-05-13 14:27:20 --> Router Class Initialized
INFO - 2025-05-13 14:27:20 --> Output Class Initialized
INFO - 2025-05-13 14:27:20 --> Security Class Initialized
DEBUG - 2025-05-13 14:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:27:20 --> Input Class Initialized
INFO - 2025-05-13 14:27:20 --> Language Class Initialized
INFO - 2025-05-13 14:27:20 --> Loader Class Initialized
INFO - 2025-05-13 14:27:20 --> Helper loaded: url_helper
INFO - 2025-05-13 14:27:20 --> Helper loaded: form_helper
INFO - 2025-05-13 14:27:20 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:27:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:27:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:27:20 --> Controller Class Initialized
INFO - 2025-05-13 14:27:20 --> Model "User_model" initialized
INFO - 2025-05-13 14:27:20 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:27:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 14:27:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 14:27:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 14:27:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 14:27:20 --> Final output sent to browser
DEBUG - 2025-05-13 14:27:20 --> Total execution time: 0.0722
INFO - 2025-05-13 14:27:28 --> Config Class Initialized
INFO - 2025-05-13 14:27:28 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:27:28 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:27:28 --> Utf8 Class Initialized
INFO - 2025-05-13 14:27:28 --> URI Class Initialized
INFO - 2025-05-13 14:27:28 --> Router Class Initialized
INFO - 2025-05-13 14:27:28 --> Output Class Initialized
INFO - 2025-05-13 14:27:28 --> Security Class Initialized
DEBUG - 2025-05-13 14:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:27:28 --> Input Class Initialized
INFO - 2025-05-13 14:27:28 --> Language Class Initialized
INFO - 2025-05-13 14:27:28 --> Loader Class Initialized
INFO - 2025-05-13 14:27:28 --> Helper loaded: url_helper
INFO - 2025-05-13 14:27:28 --> Helper loaded: form_helper
INFO - 2025-05-13 14:27:28 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:27:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:27:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:27:28 --> Controller Class Initialized
INFO - 2025-05-13 14:27:28 --> Model "User_model" initialized
INFO - 2025-05-13 14:27:28 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:27:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 14:27:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 14:27:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 14:27:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 14:27:28 --> Final output sent to browser
DEBUG - 2025-05-13 14:27:28 --> Total execution time: 0.0710
INFO - 2025-05-13 14:27:29 --> Config Class Initialized
INFO - 2025-05-13 14:27:29 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:27:29 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:27:29 --> Utf8 Class Initialized
INFO - 2025-05-13 14:27:29 --> URI Class Initialized
INFO - 2025-05-13 14:27:29 --> Router Class Initialized
INFO - 2025-05-13 14:27:29 --> Output Class Initialized
INFO - 2025-05-13 14:27:29 --> Security Class Initialized
DEBUG - 2025-05-13 14:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:27:29 --> Input Class Initialized
INFO - 2025-05-13 14:27:29 --> Language Class Initialized
INFO - 2025-05-13 14:27:29 --> Loader Class Initialized
INFO - 2025-05-13 14:27:29 --> Helper loaded: url_helper
INFO - 2025-05-13 14:27:29 --> Helper loaded: form_helper
INFO - 2025-05-13 14:27:29 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:27:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:27:29 --> Controller Class Initialized
INFO - 2025-05-13 14:27:29 --> Model "User_model" initialized
INFO - 2025-05-13 14:27:29 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:27:29 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 14:27:29 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 14:27:29 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 14:27:29 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 14:27:29 --> Final output sent to browser
DEBUG - 2025-05-13 14:27:29 --> Total execution time: 0.0738
INFO - 2025-05-13 14:27:42 --> Config Class Initialized
INFO - 2025-05-13 14:27:42 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:27:42 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:27:42 --> Utf8 Class Initialized
INFO - 2025-05-13 14:27:42 --> URI Class Initialized
INFO - 2025-05-13 14:27:42 --> Router Class Initialized
INFO - 2025-05-13 14:27:42 --> Output Class Initialized
INFO - 2025-05-13 14:27:42 --> Security Class Initialized
DEBUG - 2025-05-13 14:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:27:42 --> Input Class Initialized
INFO - 2025-05-13 14:27:42 --> Language Class Initialized
INFO - 2025-05-13 14:27:42 --> Loader Class Initialized
INFO - 2025-05-13 14:27:42 --> Helper loaded: url_helper
INFO - 2025-05-13 14:27:42 --> Helper loaded: form_helper
INFO - 2025-05-13 14:27:42 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:27:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:27:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:27:42 --> Controller Class Initialized
INFO - 2025-05-13 14:27:42 --> Model "User_model" initialized
INFO - 2025-05-13 14:27:42 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:27:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 14:27:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 14:27:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 14:27:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 14:27:42 --> Final output sent to browser
DEBUG - 2025-05-13 14:27:42 --> Total execution time: 0.0843
INFO - 2025-05-13 14:28:12 --> Config Class Initialized
INFO - 2025-05-13 14:28:12 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:28:12 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:28:12 --> Utf8 Class Initialized
INFO - 2025-05-13 14:28:12 --> URI Class Initialized
INFO - 2025-05-13 14:28:12 --> Router Class Initialized
INFO - 2025-05-13 14:28:12 --> Output Class Initialized
INFO - 2025-05-13 14:28:12 --> Security Class Initialized
DEBUG - 2025-05-13 14:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:28:12 --> Input Class Initialized
INFO - 2025-05-13 14:28:12 --> Language Class Initialized
INFO - 2025-05-13 14:28:12 --> Loader Class Initialized
INFO - 2025-05-13 14:28:12 --> Helper loaded: url_helper
INFO - 2025-05-13 14:28:12 --> Helper loaded: form_helper
INFO - 2025-05-13 14:28:12 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:28:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:28:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:28:12 --> Controller Class Initialized
INFO - 2025-05-13 14:28:12 --> Model "User_model" initialized
INFO - 2025-05-13 14:28:12 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:28:12 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 14:28:12 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 14:28:12 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 14:28:12 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 14:28:12 --> Final output sent to browser
DEBUG - 2025-05-13 14:28:12 --> Total execution time: 0.0834
INFO - 2025-05-13 14:28:21 --> Config Class Initialized
INFO - 2025-05-13 14:28:21 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:28:22 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:28:22 --> Utf8 Class Initialized
INFO - 2025-05-13 14:28:22 --> URI Class Initialized
INFO - 2025-05-13 14:28:22 --> Router Class Initialized
INFO - 2025-05-13 14:28:22 --> Output Class Initialized
INFO - 2025-05-13 14:28:22 --> Security Class Initialized
DEBUG - 2025-05-13 14:28:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:28:22 --> Input Class Initialized
INFO - 2025-05-13 14:28:22 --> Language Class Initialized
INFO - 2025-05-13 14:28:22 --> Loader Class Initialized
INFO - 2025-05-13 14:28:22 --> Helper loaded: url_helper
INFO - 2025-05-13 14:28:22 --> Helper loaded: form_helper
INFO - 2025-05-13 14:28:22 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:28:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:28:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:28:22 --> Controller Class Initialized
INFO - 2025-05-13 14:28:22 --> Model "User_model" initialized
INFO - 2025-05-13 14:28:22 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:28:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 14:28:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 14:28:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 14:28:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 14:28:22 --> Final output sent to browser
DEBUG - 2025-05-13 14:28:22 --> Total execution time: 0.0894
INFO - 2025-05-13 14:28:44 --> Config Class Initialized
INFO - 2025-05-13 14:28:44 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:28:44 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:28:44 --> Utf8 Class Initialized
INFO - 2025-05-13 14:28:44 --> URI Class Initialized
INFO - 2025-05-13 14:28:44 --> Router Class Initialized
INFO - 2025-05-13 14:28:44 --> Output Class Initialized
INFO - 2025-05-13 14:28:44 --> Security Class Initialized
DEBUG - 2025-05-13 14:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:28:44 --> Input Class Initialized
INFO - 2025-05-13 14:28:44 --> Language Class Initialized
INFO - 2025-05-13 14:28:44 --> Loader Class Initialized
INFO - 2025-05-13 14:28:44 --> Helper loaded: url_helper
INFO - 2025-05-13 14:28:44 --> Helper loaded: form_helper
INFO - 2025-05-13 14:28:44 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:28:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:28:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:28:44 --> Controller Class Initialized
INFO - 2025-05-13 14:28:44 --> Model "User_model" initialized
INFO - 2025-05-13 14:28:44 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:28:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 14:28:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 14:28:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 14:28:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 14:28:44 --> Final output sent to browser
DEBUG - 2025-05-13 14:28:44 --> Total execution time: 0.0875
INFO - 2025-05-13 14:29:26 --> Config Class Initialized
INFO - 2025-05-13 14:29:26 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:29:26 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:29:26 --> Utf8 Class Initialized
INFO - 2025-05-13 14:29:26 --> URI Class Initialized
INFO - 2025-05-13 14:29:26 --> Router Class Initialized
INFO - 2025-05-13 14:29:26 --> Output Class Initialized
INFO - 2025-05-13 14:29:26 --> Security Class Initialized
DEBUG - 2025-05-13 14:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:29:26 --> Input Class Initialized
INFO - 2025-05-13 14:29:26 --> Language Class Initialized
INFO - 2025-05-13 14:29:26 --> Loader Class Initialized
INFO - 2025-05-13 14:29:26 --> Helper loaded: url_helper
INFO - 2025-05-13 14:29:26 --> Helper loaded: form_helper
INFO - 2025-05-13 14:29:26 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:29:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:29:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:29:26 --> Controller Class Initialized
INFO - 2025-05-13 14:29:26 --> Model "User_model" initialized
INFO - 2025-05-13 14:29:26 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:29:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 14:29:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 14:29:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 14:29:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 14:29:26 --> Final output sent to browser
DEBUG - 2025-05-13 14:29:26 --> Total execution time: 0.0728
INFO - 2025-05-13 14:29:29 --> Config Class Initialized
INFO - 2025-05-13 14:29:29 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:29:29 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:29:29 --> Utf8 Class Initialized
INFO - 2025-05-13 14:29:29 --> URI Class Initialized
INFO - 2025-05-13 14:29:29 --> Router Class Initialized
INFO - 2025-05-13 14:29:29 --> Output Class Initialized
INFO - 2025-05-13 14:29:29 --> Security Class Initialized
DEBUG - 2025-05-13 14:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:29:29 --> Input Class Initialized
INFO - 2025-05-13 14:29:29 --> Language Class Initialized
INFO - 2025-05-13 14:29:29 --> Loader Class Initialized
INFO - 2025-05-13 14:29:29 --> Helper loaded: url_helper
INFO - 2025-05-13 14:29:29 --> Helper loaded: form_helper
INFO - 2025-05-13 14:29:29 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:29:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:29:29 --> Controller Class Initialized
INFO - 2025-05-13 14:29:29 --> Model "User_model" initialized
INFO - 2025-05-13 14:29:29 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:29:29 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 14:29:29 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 14:29:29 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 14:29:29 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 14:29:29 --> Final output sent to browser
DEBUG - 2025-05-13 14:29:29 --> Total execution time: 0.0758
INFO - 2025-05-13 14:29:55 --> Config Class Initialized
INFO - 2025-05-13 14:29:55 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:29:55 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:29:55 --> Utf8 Class Initialized
INFO - 2025-05-13 14:29:55 --> URI Class Initialized
INFO - 2025-05-13 14:29:55 --> Router Class Initialized
INFO - 2025-05-13 14:29:55 --> Output Class Initialized
INFO - 2025-05-13 14:29:55 --> Security Class Initialized
DEBUG - 2025-05-13 14:29:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:29:55 --> Input Class Initialized
INFO - 2025-05-13 14:29:55 --> Language Class Initialized
INFO - 2025-05-13 14:29:55 --> Loader Class Initialized
INFO - 2025-05-13 14:29:55 --> Helper loaded: url_helper
INFO - 2025-05-13 14:29:55 --> Helper loaded: form_helper
INFO - 2025-05-13 14:29:55 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:29:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:29:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:29:55 --> Controller Class Initialized
INFO - 2025-05-13 14:29:55 --> Model "User_model" initialized
INFO - 2025-05-13 14:29:55 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:29:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 14:29:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 14:29:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 14:29:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 14:29:55 --> Final output sent to browser
DEBUG - 2025-05-13 14:29:55 --> Total execution time: 0.0680
INFO - 2025-05-13 14:29:56 --> Config Class Initialized
INFO - 2025-05-13 14:29:56 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:29:56 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:29:56 --> Utf8 Class Initialized
INFO - 2025-05-13 14:29:56 --> URI Class Initialized
INFO - 2025-05-13 14:29:56 --> Router Class Initialized
INFO - 2025-05-13 14:29:56 --> Output Class Initialized
INFO - 2025-05-13 14:29:56 --> Security Class Initialized
DEBUG - 2025-05-13 14:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:29:56 --> Input Class Initialized
INFO - 2025-05-13 14:29:56 --> Language Class Initialized
INFO - 2025-05-13 14:29:56 --> Loader Class Initialized
INFO - 2025-05-13 14:29:56 --> Helper loaded: url_helper
INFO - 2025-05-13 14:29:56 --> Helper loaded: form_helper
INFO - 2025-05-13 14:29:56 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:29:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:29:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:29:56 --> Controller Class Initialized
INFO - 2025-05-13 14:29:56 --> Model "User_model" initialized
INFO - 2025-05-13 14:29:56 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:29:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 14:29:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 14:29:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 14:29:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 14:29:56 --> Final output sent to browser
DEBUG - 2025-05-13 14:29:56 --> Total execution time: 0.0728
INFO - 2025-05-13 14:30:09 --> Config Class Initialized
INFO - 2025-05-13 14:30:09 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:30:09 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:30:09 --> Utf8 Class Initialized
INFO - 2025-05-13 14:30:09 --> URI Class Initialized
INFO - 2025-05-13 14:30:09 --> Router Class Initialized
INFO - 2025-05-13 14:30:09 --> Output Class Initialized
INFO - 2025-05-13 14:30:09 --> Security Class Initialized
DEBUG - 2025-05-13 14:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:30:09 --> Input Class Initialized
INFO - 2025-05-13 14:30:09 --> Language Class Initialized
INFO - 2025-05-13 14:30:09 --> Loader Class Initialized
INFO - 2025-05-13 14:30:09 --> Helper loaded: url_helper
INFO - 2025-05-13 14:30:09 --> Helper loaded: form_helper
INFO - 2025-05-13 14:30:09 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:30:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:30:09 --> Controller Class Initialized
INFO - 2025-05-13 14:30:09 --> Model "User_model" initialized
INFO - 2025-05-13 14:30:09 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:30:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 14:30:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 14:30:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 14:30:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 14:30:09 --> Final output sent to browser
DEBUG - 2025-05-13 14:30:09 --> Total execution time: 0.0693
INFO - 2025-05-13 14:30:17 --> Config Class Initialized
INFO - 2025-05-13 14:30:17 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:30:17 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:30:17 --> Utf8 Class Initialized
INFO - 2025-05-13 14:30:17 --> URI Class Initialized
INFO - 2025-05-13 14:30:17 --> Router Class Initialized
INFO - 2025-05-13 14:30:17 --> Output Class Initialized
INFO - 2025-05-13 14:30:17 --> Security Class Initialized
DEBUG - 2025-05-13 14:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:30:17 --> Input Class Initialized
INFO - 2025-05-13 14:30:17 --> Language Class Initialized
INFO - 2025-05-13 14:30:17 --> Loader Class Initialized
INFO - 2025-05-13 14:30:17 --> Helper loaded: url_helper
INFO - 2025-05-13 14:30:17 --> Helper loaded: form_helper
INFO - 2025-05-13 14:30:17 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:30:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:30:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:30:17 --> Controller Class Initialized
INFO - 2025-05-13 14:30:17 --> Model "User_model" initialized
INFO - 2025-05-13 14:30:17 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:30:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 14:30:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 14:30:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 14:30:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 14:30:17 --> Final output sent to browser
DEBUG - 2025-05-13 14:30:17 --> Total execution time: 0.0688
INFO - 2025-05-13 14:30:30 --> Config Class Initialized
INFO - 2025-05-13 14:30:30 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:30:30 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:30:30 --> Utf8 Class Initialized
INFO - 2025-05-13 14:30:30 --> URI Class Initialized
INFO - 2025-05-13 14:30:30 --> Router Class Initialized
INFO - 2025-05-13 14:30:30 --> Output Class Initialized
INFO - 2025-05-13 14:30:30 --> Security Class Initialized
DEBUG - 2025-05-13 14:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:30:30 --> Input Class Initialized
INFO - 2025-05-13 14:30:30 --> Language Class Initialized
INFO - 2025-05-13 14:30:30 --> Loader Class Initialized
INFO - 2025-05-13 14:30:30 --> Helper loaded: url_helper
INFO - 2025-05-13 14:30:30 --> Helper loaded: form_helper
INFO - 2025-05-13 14:30:30 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:30:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:30:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:30:30 --> Controller Class Initialized
INFO - 2025-05-13 14:30:30 --> Model "User_model" initialized
INFO - 2025-05-13 14:30:30 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:30:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 14:30:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 14:30:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 14:30:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 14:30:30 --> Final output sent to browser
DEBUG - 2025-05-13 14:30:30 --> Total execution time: 0.0686
INFO - 2025-05-13 14:30:40 --> Config Class Initialized
INFO - 2025-05-13 14:30:40 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:30:40 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:30:40 --> Utf8 Class Initialized
INFO - 2025-05-13 14:30:40 --> URI Class Initialized
INFO - 2025-05-13 14:30:40 --> Router Class Initialized
INFO - 2025-05-13 14:30:40 --> Output Class Initialized
INFO - 2025-05-13 14:30:40 --> Security Class Initialized
DEBUG - 2025-05-13 14:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:30:40 --> Input Class Initialized
INFO - 2025-05-13 14:30:40 --> Language Class Initialized
INFO - 2025-05-13 14:30:40 --> Loader Class Initialized
INFO - 2025-05-13 14:30:40 --> Helper loaded: url_helper
INFO - 2025-05-13 14:30:40 --> Helper loaded: form_helper
INFO - 2025-05-13 14:30:40 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:30:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:30:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:30:40 --> Controller Class Initialized
INFO - 2025-05-13 14:30:40 --> Model "User_model" initialized
INFO - 2025-05-13 14:30:40 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:30:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 14:30:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 14:30:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 14:30:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 14:30:40 --> Final output sent to browser
DEBUG - 2025-05-13 14:30:40 --> Total execution time: 0.0886
INFO - 2025-05-13 14:30:50 --> Config Class Initialized
INFO - 2025-05-13 14:30:50 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:30:50 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:30:50 --> Utf8 Class Initialized
INFO - 2025-05-13 14:30:50 --> URI Class Initialized
INFO - 2025-05-13 14:30:50 --> Router Class Initialized
INFO - 2025-05-13 14:30:50 --> Output Class Initialized
INFO - 2025-05-13 14:30:50 --> Security Class Initialized
DEBUG - 2025-05-13 14:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:30:50 --> Input Class Initialized
INFO - 2025-05-13 14:30:50 --> Language Class Initialized
INFO - 2025-05-13 14:30:50 --> Loader Class Initialized
INFO - 2025-05-13 14:30:50 --> Helper loaded: url_helper
INFO - 2025-05-13 14:30:50 --> Helper loaded: form_helper
INFO - 2025-05-13 14:30:50 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:30:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:30:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:30:50 --> Controller Class Initialized
INFO - 2025-05-13 14:30:50 --> Model "User_model" initialized
INFO - 2025-05-13 14:30:50 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:30:50 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 14:30:50 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 14:30:50 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-13 14:30:50 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 14:30:50 --> Final output sent to browser
DEBUG - 2025-05-13 14:30:50 --> Total execution time: 0.0797
INFO - 2025-05-13 14:30:51 --> Config Class Initialized
INFO - 2025-05-13 14:30:51 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:30:51 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:30:51 --> Utf8 Class Initialized
INFO - 2025-05-13 14:30:51 --> URI Class Initialized
INFO - 2025-05-13 14:30:51 --> Router Class Initialized
INFO - 2025-05-13 14:30:51 --> Output Class Initialized
INFO - 2025-05-13 14:30:51 --> Security Class Initialized
DEBUG - 2025-05-13 14:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:30:51 --> Input Class Initialized
INFO - 2025-05-13 14:30:51 --> Language Class Initialized
INFO - 2025-05-13 14:30:51 --> Loader Class Initialized
INFO - 2025-05-13 14:30:51 --> Helper loaded: url_helper
INFO - 2025-05-13 14:30:51 --> Helper loaded: form_helper
INFO - 2025-05-13 14:30:51 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:30:51 --> Controller Class Initialized
INFO - 2025-05-13 14:30:51 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:30:51 --> Model "User_model" initialized
INFO - 2025-05-13 14:30:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 14:30:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 14:30:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-13 14:30:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 14:30:51 --> Final output sent to browser
DEBUG - 2025-05-13 14:30:51 --> Total execution time: 0.0721
INFO - 2025-05-13 14:30:53 --> Config Class Initialized
INFO - 2025-05-13 14:30:53 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:30:53 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:30:53 --> Utf8 Class Initialized
INFO - 2025-05-13 14:30:53 --> URI Class Initialized
INFO - 2025-05-13 14:30:53 --> Router Class Initialized
INFO - 2025-05-13 14:30:53 --> Output Class Initialized
INFO - 2025-05-13 14:30:53 --> Security Class Initialized
DEBUG - 2025-05-13 14:30:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:30:53 --> Input Class Initialized
INFO - 2025-05-13 14:30:53 --> Language Class Initialized
INFO - 2025-05-13 14:30:53 --> Loader Class Initialized
INFO - 2025-05-13 14:30:53 --> Helper loaded: url_helper
INFO - 2025-05-13 14:30:53 --> Helper loaded: form_helper
INFO - 2025-05-13 14:30:53 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:30:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:30:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:30:53 --> Controller Class Initialized
INFO - 2025-05-13 14:30:53 --> Model "User_model" initialized
INFO - 2025-05-13 14:30:53 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-13 14:30:53 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-13 14:30:53 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-13 14:30:53 --> Final output sent to browser
DEBUG - 2025-05-13 14:30:53 --> Total execution time: 0.0608
INFO - 2025-05-13 14:30:57 --> Config Class Initialized
INFO - 2025-05-13 14:30:57 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:30:57 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:30:57 --> Utf8 Class Initialized
INFO - 2025-05-13 14:30:57 --> URI Class Initialized
INFO - 2025-05-13 14:30:57 --> Router Class Initialized
INFO - 2025-05-13 14:30:57 --> Output Class Initialized
INFO - 2025-05-13 14:30:57 --> Security Class Initialized
DEBUG - 2025-05-13 14:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:30:57 --> Input Class Initialized
INFO - 2025-05-13 14:30:57 --> Language Class Initialized
INFO - 2025-05-13 14:30:57 --> Loader Class Initialized
INFO - 2025-05-13 14:30:57 --> Helper loaded: url_helper
INFO - 2025-05-13 14:30:57 --> Helper loaded: form_helper
INFO - 2025-05-13 14:30:57 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:30:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:30:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:30:57 --> Controller Class Initialized
INFO - 2025-05-13 14:30:57 --> Model "User_model" initialized
INFO - 2025-05-13 14:30:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-13 14:30:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/artikel.php
INFO - 2025-05-13 14:30:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-13 14:30:57 --> Final output sent to browser
DEBUG - 2025-05-13 14:30:57 --> Total execution time: 0.0705
INFO - 2025-05-13 14:31:00 --> Config Class Initialized
INFO - 2025-05-13 14:31:00 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:31:00 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:31:00 --> Utf8 Class Initialized
INFO - 2025-05-13 14:31:00 --> URI Class Initialized
INFO - 2025-05-13 14:31:00 --> Router Class Initialized
INFO - 2025-05-13 14:31:00 --> Output Class Initialized
INFO - 2025-05-13 14:31:00 --> Security Class Initialized
DEBUG - 2025-05-13 14:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:31:00 --> Input Class Initialized
INFO - 2025-05-13 14:31:00 --> Language Class Initialized
INFO - 2025-05-13 14:31:00 --> Loader Class Initialized
INFO - 2025-05-13 14:31:00 --> Helper loaded: url_helper
INFO - 2025-05-13 14:31:00 --> Helper loaded: form_helper
INFO - 2025-05-13 14:31:00 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:31:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:31:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:31:00 --> Controller Class Initialized
INFO - 2025-05-13 14:31:00 --> Model "User_model" initialized
INFO - 2025-05-13 14:31:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-13 14:31:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-13 14:31:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-13 14:31:00 --> Final output sent to browser
DEBUG - 2025-05-13 14:31:00 --> Total execution time: 0.0919
INFO - 2025-05-13 14:31:01 --> Config Class Initialized
INFO - 2025-05-13 14:31:01 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:31:01 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:31:01 --> Utf8 Class Initialized
INFO - 2025-05-13 14:31:01 --> URI Class Initialized
INFO - 2025-05-13 14:31:01 --> Router Class Initialized
INFO - 2025-05-13 14:31:01 --> Output Class Initialized
INFO - 2025-05-13 14:31:01 --> Security Class Initialized
DEBUG - 2025-05-13 14:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:31:01 --> Input Class Initialized
INFO - 2025-05-13 14:31:01 --> Language Class Initialized
INFO - 2025-05-13 14:31:01 --> Loader Class Initialized
INFO - 2025-05-13 14:31:01 --> Helper loaded: url_helper
INFO - 2025-05-13 14:31:01 --> Helper loaded: form_helper
INFO - 2025-05-13 14:31:01 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:31:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:31:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:31:01 --> Controller Class Initialized
INFO - 2025-05-13 14:31:01 --> Model "User_model" initialized
INFO - 2025-05-13 14:31:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-13 14:31:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/artikel.php
INFO - 2025-05-13 14:31:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-13 14:31:01 --> Final output sent to browser
DEBUG - 2025-05-13 14:31:01 --> Total execution time: 0.0693
INFO - 2025-05-13 14:42:25 --> Config Class Initialized
INFO - 2025-05-13 14:42:25 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:42:25 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:42:25 --> Utf8 Class Initialized
INFO - 2025-05-13 14:42:25 --> URI Class Initialized
INFO - 2025-05-13 14:42:25 --> Router Class Initialized
INFO - 2025-05-13 14:42:25 --> Output Class Initialized
INFO - 2025-05-13 14:42:26 --> Security Class Initialized
DEBUG - 2025-05-13 14:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:42:26 --> Input Class Initialized
INFO - 2025-05-13 14:42:26 --> Language Class Initialized
INFO - 2025-05-13 14:42:26 --> Loader Class Initialized
INFO - 2025-05-13 14:42:26 --> Helper loaded: url_helper
INFO - 2025-05-13 14:42:26 --> Helper loaded: form_helper
INFO - 2025-05-13 14:42:26 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:42:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:42:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:42:26 --> Controller Class Initialized
INFO - 2025-05-13 14:42:26 --> Model "User_model" initialized
INFO - 2025-05-13 14:42:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-13 14:42:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/artikel.php
INFO - 2025-05-13 14:42:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-13 14:42:27 --> Final output sent to browser
DEBUG - 2025-05-13 14:42:27 --> Total execution time: 1.8374
INFO - 2025-05-13 14:42:53 --> Config Class Initialized
INFO - 2025-05-13 14:42:53 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:42:53 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:42:53 --> Utf8 Class Initialized
INFO - 2025-05-13 14:42:53 --> URI Class Initialized
INFO - 2025-05-13 14:42:53 --> Router Class Initialized
INFO - 2025-05-13 14:42:53 --> Output Class Initialized
INFO - 2025-05-13 14:42:53 --> Security Class Initialized
DEBUG - 2025-05-13 14:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:42:53 --> Input Class Initialized
INFO - 2025-05-13 14:42:53 --> Language Class Initialized
INFO - 2025-05-13 14:42:53 --> Loader Class Initialized
INFO - 2025-05-13 14:42:53 --> Helper loaded: url_helper
INFO - 2025-05-13 14:42:53 --> Helper loaded: form_helper
INFO - 2025-05-13 14:42:53 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:42:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:42:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:42:53 --> Controller Class Initialized
INFO - 2025-05-13 14:42:53 --> Model "User_model" initialized
INFO - 2025-05-13 14:42:53 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-13 14:42:53 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/artikel.php
INFO - 2025-05-13 14:42:53 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-13 14:42:53 --> Final output sent to browser
DEBUG - 2025-05-13 14:42:53 --> Total execution time: 0.0845
INFO - 2025-05-13 14:43:21 --> Config Class Initialized
INFO - 2025-05-13 14:43:21 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:43:21 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:43:21 --> Utf8 Class Initialized
INFO - 2025-05-13 14:43:21 --> URI Class Initialized
INFO - 2025-05-13 14:43:21 --> Router Class Initialized
INFO - 2025-05-13 14:43:21 --> Output Class Initialized
INFO - 2025-05-13 14:43:21 --> Security Class Initialized
DEBUG - 2025-05-13 14:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:43:21 --> Input Class Initialized
INFO - 2025-05-13 14:43:21 --> Language Class Initialized
INFO - 2025-05-13 14:43:21 --> Loader Class Initialized
INFO - 2025-05-13 14:43:21 --> Helper loaded: url_helper
INFO - 2025-05-13 14:43:21 --> Helper loaded: form_helper
INFO - 2025-05-13 14:43:21 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:43:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:43:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:43:21 --> Controller Class Initialized
INFO - 2025-05-13 14:43:21 --> Model "User_model" initialized
INFO - 2025-05-13 14:43:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-13 14:43:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/artikel.php
INFO - 2025-05-13 14:43:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-13 14:43:21 --> Final output sent to browser
DEBUG - 2025-05-13 14:43:21 --> Total execution time: 0.0937
INFO - 2025-05-13 14:43:23 --> Config Class Initialized
INFO - 2025-05-13 14:43:23 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:43:23 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:43:23 --> Utf8 Class Initialized
INFO - 2025-05-13 14:43:23 --> URI Class Initialized
INFO - 2025-05-13 14:43:23 --> Router Class Initialized
INFO - 2025-05-13 14:43:23 --> Output Class Initialized
INFO - 2025-05-13 14:43:23 --> Security Class Initialized
DEBUG - 2025-05-13 14:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:43:23 --> Input Class Initialized
INFO - 2025-05-13 14:43:23 --> Language Class Initialized
INFO - 2025-05-13 14:43:23 --> Loader Class Initialized
INFO - 2025-05-13 14:43:23 --> Helper loaded: url_helper
INFO - 2025-05-13 14:43:23 --> Helper loaded: form_helper
INFO - 2025-05-13 14:43:23 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:43:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:43:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:43:23 --> Controller Class Initialized
INFO - 2025-05-13 14:43:23 --> Model "User_model" initialized
INFO - 2025-05-13 14:43:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-13 14:43:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-13 14:43:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-13 14:43:23 --> Final output sent to browser
DEBUG - 2025-05-13 14:43:23 --> Total execution time: 0.1310
INFO - 2025-05-13 14:43:39 --> Config Class Initialized
INFO - 2025-05-13 14:43:39 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:43:39 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:43:39 --> Utf8 Class Initialized
INFO - 2025-05-13 14:43:39 --> URI Class Initialized
INFO - 2025-05-13 14:43:39 --> Router Class Initialized
INFO - 2025-05-13 14:43:39 --> Output Class Initialized
INFO - 2025-05-13 14:43:39 --> Security Class Initialized
DEBUG - 2025-05-13 14:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:43:39 --> Input Class Initialized
INFO - 2025-05-13 14:43:39 --> Language Class Initialized
INFO - 2025-05-13 14:43:39 --> Loader Class Initialized
INFO - 2025-05-13 14:43:39 --> Helper loaded: url_helper
INFO - 2025-05-13 14:43:39 --> Helper loaded: form_helper
INFO - 2025-05-13 14:43:39 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:43:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:43:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:43:39 --> Controller Class Initialized
INFO - 2025-05-13 14:43:39 --> Model "User_model" initialized
INFO - 2025-05-13 14:43:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-13 14:43:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-13 14:43:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-13 14:43:39 --> Final output sent to browser
DEBUG - 2025-05-13 14:43:39 --> Total execution time: 0.0996
INFO - 2025-05-13 14:44:19 --> Config Class Initialized
INFO - 2025-05-13 14:44:19 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:44:19 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:44:19 --> Utf8 Class Initialized
INFO - 2025-05-13 14:44:19 --> URI Class Initialized
INFO - 2025-05-13 14:44:19 --> Router Class Initialized
INFO - 2025-05-13 14:44:19 --> Output Class Initialized
INFO - 2025-05-13 14:44:19 --> Security Class Initialized
DEBUG - 2025-05-13 14:44:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:44:19 --> Input Class Initialized
INFO - 2025-05-13 14:44:19 --> Language Class Initialized
INFO - 2025-05-13 14:44:19 --> Loader Class Initialized
INFO - 2025-05-13 14:44:19 --> Helper loaded: url_helper
INFO - 2025-05-13 14:44:19 --> Helper loaded: form_helper
INFO - 2025-05-13 14:44:19 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:44:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:44:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:44:19 --> Controller Class Initialized
INFO - 2025-05-13 14:44:19 --> Model "User_model" initialized
INFO - 2025-05-13 14:44:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-13 14:44:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-13 14:44:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-13 14:44:19 --> Final output sent to browser
DEBUG - 2025-05-13 14:44:19 --> Total execution time: 0.0682
INFO - 2025-05-13 14:45:15 --> Config Class Initialized
INFO - 2025-05-13 14:45:15 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:45:15 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:45:15 --> Utf8 Class Initialized
INFO - 2025-05-13 14:45:15 --> URI Class Initialized
INFO - 2025-05-13 14:45:15 --> Router Class Initialized
INFO - 2025-05-13 14:45:15 --> Output Class Initialized
INFO - 2025-05-13 14:45:15 --> Security Class Initialized
DEBUG - 2025-05-13 14:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:45:15 --> Input Class Initialized
INFO - 2025-05-13 14:45:15 --> Language Class Initialized
INFO - 2025-05-13 14:45:15 --> Loader Class Initialized
INFO - 2025-05-13 14:45:15 --> Helper loaded: url_helper
INFO - 2025-05-13 14:45:15 --> Helper loaded: form_helper
INFO - 2025-05-13 14:45:15 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:45:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:45:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:45:15 --> Controller Class Initialized
INFO - 2025-05-13 14:45:15 --> Model "User_model" initialized
INFO - 2025-05-13 14:45:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-13 14:45:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-13 14:45:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-13 14:45:15 --> Final output sent to browser
DEBUG - 2025-05-13 14:45:15 --> Total execution time: 0.0916
INFO - 2025-05-13 14:45:55 --> Config Class Initialized
INFO - 2025-05-13 14:45:55 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:45:55 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:45:55 --> Utf8 Class Initialized
INFO - 2025-05-13 14:45:55 --> URI Class Initialized
INFO - 2025-05-13 14:45:55 --> Router Class Initialized
INFO - 2025-05-13 14:45:55 --> Output Class Initialized
INFO - 2025-05-13 14:45:55 --> Security Class Initialized
DEBUG - 2025-05-13 14:45:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:45:55 --> Input Class Initialized
INFO - 2025-05-13 14:45:55 --> Language Class Initialized
INFO - 2025-05-13 14:45:55 --> Loader Class Initialized
INFO - 2025-05-13 14:45:55 --> Helper loaded: url_helper
INFO - 2025-05-13 14:45:55 --> Helper loaded: form_helper
INFO - 2025-05-13 14:45:55 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:45:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:45:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:45:55 --> Controller Class Initialized
INFO - 2025-05-13 14:45:55 --> Model "User_model" initialized
INFO - 2025-05-13 14:45:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-13 14:45:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-13 14:45:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-13 14:45:55 --> Final output sent to browser
DEBUG - 2025-05-13 14:45:55 --> Total execution time: 0.0767
INFO - 2025-05-13 14:46:18 --> Config Class Initialized
INFO - 2025-05-13 14:46:18 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:46:18 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:46:18 --> Utf8 Class Initialized
INFO - 2025-05-13 14:46:18 --> URI Class Initialized
INFO - 2025-05-13 14:46:18 --> Router Class Initialized
INFO - 2025-05-13 14:46:18 --> Output Class Initialized
INFO - 2025-05-13 14:46:18 --> Security Class Initialized
DEBUG - 2025-05-13 14:46:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:46:18 --> Input Class Initialized
INFO - 2025-05-13 14:46:18 --> Language Class Initialized
INFO - 2025-05-13 14:46:18 --> Loader Class Initialized
INFO - 2025-05-13 14:46:18 --> Helper loaded: url_helper
INFO - 2025-05-13 14:46:18 --> Helper loaded: form_helper
INFO - 2025-05-13 14:46:18 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:46:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:46:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:46:18 --> Controller Class Initialized
INFO - 2025-05-13 14:46:18 --> Model "User_model" initialized
INFO - 2025-05-13 14:46:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-13 14:46:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-13 14:46:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-13 14:46:18 --> Final output sent to browser
DEBUG - 2025-05-13 14:46:18 --> Total execution time: 0.0859
INFO - 2025-05-13 14:46:29 --> Config Class Initialized
INFO - 2025-05-13 14:46:29 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:46:29 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:46:29 --> Utf8 Class Initialized
INFO - 2025-05-13 14:46:29 --> URI Class Initialized
INFO - 2025-05-13 14:46:29 --> Router Class Initialized
INFO - 2025-05-13 14:46:29 --> Output Class Initialized
INFO - 2025-05-13 14:46:29 --> Security Class Initialized
DEBUG - 2025-05-13 14:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:46:29 --> Input Class Initialized
INFO - 2025-05-13 14:46:29 --> Language Class Initialized
INFO - 2025-05-13 14:46:29 --> Loader Class Initialized
INFO - 2025-05-13 14:46:29 --> Helper loaded: url_helper
INFO - 2025-05-13 14:46:29 --> Helper loaded: form_helper
INFO - 2025-05-13 14:46:29 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:46:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:46:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:46:29 --> Controller Class Initialized
INFO - 2025-05-13 14:46:29 --> Model "User_model" initialized
INFO - 2025-05-13 14:46:29 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-13 14:46:29 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-13 14:46:29 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-13 14:46:29 --> Final output sent to browser
DEBUG - 2025-05-13 14:46:29 --> Total execution time: 0.0788
INFO - 2025-05-13 14:46:52 --> Config Class Initialized
INFO - 2025-05-13 14:46:52 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:46:52 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:46:52 --> Utf8 Class Initialized
INFO - 2025-05-13 14:46:52 --> URI Class Initialized
INFO - 2025-05-13 14:46:52 --> Router Class Initialized
INFO - 2025-05-13 14:46:52 --> Output Class Initialized
INFO - 2025-05-13 14:46:52 --> Security Class Initialized
DEBUG - 2025-05-13 14:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:46:52 --> Input Class Initialized
INFO - 2025-05-13 14:46:52 --> Language Class Initialized
INFO - 2025-05-13 14:46:52 --> Loader Class Initialized
INFO - 2025-05-13 14:46:52 --> Helper loaded: url_helper
INFO - 2025-05-13 14:46:52 --> Helper loaded: form_helper
INFO - 2025-05-13 14:46:52 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:46:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:46:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:46:52 --> Controller Class Initialized
INFO - 2025-05-13 14:46:52 --> Model "User_model" initialized
INFO - 2025-05-13 14:46:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-13 14:46:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-13 14:46:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-13 14:46:52 --> Final output sent to browser
DEBUG - 2025-05-13 14:46:52 --> Total execution time: 0.0820
INFO - 2025-05-13 14:47:32 --> Config Class Initialized
INFO - 2025-05-13 14:47:32 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:47:32 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:47:32 --> Utf8 Class Initialized
INFO - 2025-05-13 14:47:32 --> URI Class Initialized
INFO - 2025-05-13 14:47:32 --> Router Class Initialized
INFO - 2025-05-13 14:47:32 --> Output Class Initialized
INFO - 2025-05-13 14:47:32 --> Security Class Initialized
DEBUG - 2025-05-13 14:47:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:47:32 --> Input Class Initialized
INFO - 2025-05-13 14:47:32 --> Language Class Initialized
INFO - 2025-05-13 14:47:32 --> Loader Class Initialized
INFO - 2025-05-13 14:47:32 --> Helper loaded: url_helper
INFO - 2025-05-13 14:47:32 --> Helper loaded: form_helper
INFO - 2025-05-13 14:47:32 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:47:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:47:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:47:32 --> Controller Class Initialized
INFO - 2025-05-13 14:47:32 --> Model "User_model" initialized
INFO - 2025-05-13 14:47:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-13 14:47:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-13 14:47:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-13 14:47:32 --> Final output sent to browser
DEBUG - 2025-05-13 14:47:32 --> Total execution time: 0.0765
INFO - 2025-05-13 14:47:35 --> Config Class Initialized
INFO - 2025-05-13 14:47:35 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:47:35 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:47:35 --> Utf8 Class Initialized
INFO - 2025-05-13 14:47:35 --> URI Class Initialized
INFO - 2025-05-13 14:47:35 --> Router Class Initialized
INFO - 2025-05-13 14:47:35 --> Output Class Initialized
INFO - 2025-05-13 14:47:35 --> Security Class Initialized
DEBUG - 2025-05-13 14:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:47:35 --> Input Class Initialized
INFO - 2025-05-13 14:47:35 --> Language Class Initialized
INFO - 2025-05-13 14:47:35 --> Loader Class Initialized
INFO - 2025-05-13 14:47:35 --> Helper loaded: url_helper
INFO - 2025-05-13 14:47:35 --> Helper loaded: form_helper
INFO - 2025-05-13 14:47:35 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:47:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:47:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:47:35 --> Controller Class Initialized
INFO - 2025-05-13 14:47:35 --> Model "User_model" initialized
INFO - 2025-05-13 14:47:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-13 14:47:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-13 14:47:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-13 14:47:35 --> Final output sent to browser
DEBUG - 2025-05-13 14:47:35 --> Total execution time: 0.0908
INFO - 2025-05-13 14:47:48 --> Config Class Initialized
INFO - 2025-05-13 14:47:48 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:47:48 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:47:48 --> Utf8 Class Initialized
INFO - 2025-05-13 14:47:48 --> URI Class Initialized
INFO - 2025-05-13 14:47:48 --> Router Class Initialized
INFO - 2025-05-13 14:47:48 --> Output Class Initialized
INFO - 2025-05-13 14:47:48 --> Security Class Initialized
DEBUG - 2025-05-13 14:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:47:48 --> Input Class Initialized
INFO - 2025-05-13 14:47:48 --> Language Class Initialized
INFO - 2025-05-13 14:47:48 --> Loader Class Initialized
INFO - 2025-05-13 14:47:48 --> Helper loaded: url_helper
INFO - 2025-05-13 14:47:48 --> Helper loaded: form_helper
INFO - 2025-05-13 14:47:48 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:47:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:47:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:47:48 --> Controller Class Initialized
INFO - 2025-05-13 14:47:48 --> Model "User_model" initialized
INFO - 2025-05-13 14:47:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-13 14:47:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-13 14:47:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-13 14:47:48 --> Final output sent to browser
DEBUG - 2025-05-13 14:47:48 --> Total execution time: 0.0842
INFO - 2025-05-13 14:48:42 --> Config Class Initialized
INFO - 2025-05-13 14:48:42 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:48:42 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:48:42 --> Utf8 Class Initialized
INFO - 2025-05-13 14:48:42 --> URI Class Initialized
INFO - 2025-05-13 14:48:42 --> Router Class Initialized
INFO - 2025-05-13 14:48:42 --> Output Class Initialized
INFO - 2025-05-13 14:48:42 --> Security Class Initialized
DEBUG - 2025-05-13 14:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:48:42 --> Input Class Initialized
INFO - 2025-05-13 14:48:42 --> Language Class Initialized
INFO - 2025-05-13 14:48:42 --> Loader Class Initialized
INFO - 2025-05-13 14:48:42 --> Helper loaded: url_helper
INFO - 2025-05-13 14:48:42 --> Helper loaded: form_helper
INFO - 2025-05-13 14:48:42 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:48:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:48:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:48:42 --> Controller Class Initialized
INFO - 2025-05-13 14:48:42 --> Model "User_model" initialized
INFO - 2025-05-13 14:48:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-13 14:48:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-13 14:48:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-13 14:48:42 --> Final output sent to browser
DEBUG - 2025-05-13 14:48:42 --> Total execution time: 0.0843
INFO - 2025-05-13 14:48:46 --> Config Class Initialized
INFO - 2025-05-13 14:48:46 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:48:46 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:48:46 --> Utf8 Class Initialized
INFO - 2025-05-13 14:48:46 --> URI Class Initialized
INFO - 2025-05-13 14:48:46 --> Router Class Initialized
INFO - 2025-05-13 14:48:46 --> Output Class Initialized
INFO - 2025-05-13 14:48:46 --> Security Class Initialized
DEBUG - 2025-05-13 14:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:48:46 --> Input Class Initialized
INFO - 2025-05-13 14:48:46 --> Language Class Initialized
INFO - 2025-05-13 14:48:46 --> Loader Class Initialized
INFO - 2025-05-13 14:48:46 --> Helper loaded: url_helper
INFO - 2025-05-13 14:48:46 --> Helper loaded: form_helper
INFO - 2025-05-13 14:48:46 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:48:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:48:46 --> Controller Class Initialized
INFO - 2025-05-13 14:48:46 --> Model "User_model" initialized
INFO - 2025-05-13 14:48:46 --> Config Class Initialized
INFO - 2025-05-13 14:48:46 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:48:46 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:48:46 --> Utf8 Class Initialized
INFO - 2025-05-13 14:48:46 --> URI Class Initialized
INFO - 2025-05-13 14:48:46 --> Router Class Initialized
INFO - 2025-05-13 14:48:46 --> Output Class Initialized
INFO - 2025-05-13 14:48:46 --> Security Class Initialized
DEBUG - 2025-05-13 14:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:48:46 --> Input Class Initialized
INFO - 2025-05-13 14:48:46 --> Language Class Initialized
INFO - 2025-05-13 14:48:46 --> Loader Class Initialized
INFO - 2025-05-13 14:48:46 --> Helper loaded: url_helper
INFO - 2025-05-13 14:48:46 --> Helper loaded: form_helper
INFO - 2025-05-13 14:48:46 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:48:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:48:46 --> Controller Class Initialized
INFO - 2025-05-13 14:48:46 --> Model "User_model" initialized
INFO - 2025-05-13 14:48:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-13 14:48:46 --> Final output sent to browser
DEBUG - 2025-05-13 14:48:46 --> Total execution time: 0.1037
INFO - 2025-05-13 14:48:49 --> Config Class Initialized
INFO - 2025-05-13 14:48:49 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:48:49 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:48:49 --> Utf8 Class Initialized
INFO - 2025-05-13 14:48:49 --> URI Class Initialized
INFO - 2025-05-13 14:48:49 --> Router Class Initialized
INFO - 2025-05-13 14:48:49 --> Output Class Initialized
INFO - 2025-05-13 14:48:49 --> Security Class Initialized
DEBUG - 2025-05-13 14:48:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:48:49 --> Input Class Initialized
INFO - 2025-05-13 14:48:49 --> Language Class Initialized
INFO - 2025-05-13 14:48:49 --> Loader Class Initialized
INFO - 2025-05-13 14:48:49 --> Helper loaded: url_helper
INFO - 2025-05-13 14:48:49 --> Helper loaded: form_helper
INFO - 2025-05-13 14:48:49 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:48:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:48:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:48:49 --> Controller Class Initialized
INFO - 2025-05-13 14:48:49 --> Model "User_model" initialized
INFO - 2025-05-13 14:48:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-13 14:48:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-13 14:48:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-13 14:48:49 --> Final output sent to browser
DEBUG - 2025-05-13 14:48:49 --> Total execution time: 0.0758
INFO - 2025-05-13 14:49:32 --> Config Class Initialized
INFO - 2025-05-13 14:49:32 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:49:32 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:49:32 --> Utf8 Class Initialized
INFO - 2025-05-13 14:49:32 --> URI Class Initialized
INFO - 2025-05-13 14:49:32 --> Router Class Initialized
INFO - 2025-05-13 14:49:32 --> Output Class Initialized
INFO - 2025-05-13 14:49:32 --> Security Class Initialized
DEBUG - 2025-05-13 14:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:49:32 --> Input Class Initialized
INFO - 2025-05-13 14:49:32 --> Language Class Initialized
INFO - 2025-05-13 14:49:32 --> Loader Class Initialized
INFO - 2025-05-13 14:49:32 --> Helper loaded: url_helper
INFO - 2025-05-13 14:49:32 --> Helper loaded: form_helper
INFO - 2025-05-13 14:49:32 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:49:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:49:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:49:32 --> Controller Class Initialized
INFO - 2025-05-13 14:49:32 --> Model "User_model" initialized
INFO - 2025-05-13 14:49:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-13 14:49:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-13 14:49:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-13 14:49:32 --> Final output sent to browser
DEBUG - 2025-05-13 14:49:32 --> Total execution time: 0.1008
INFO - 2025-05-13 14:49:33 --> Config Class Initialized
INFO - 2025-05-13 14:49:33 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:49:33 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:49:33 --> Utf8 Class Initialized
INFO - 2025-05-13 14:49:33 --> URI Class Initialized
INFO - 2025-05-13 14:49:33 --> Router Class Initialized
INFO - 2025-05-13 14:49:33 --> Output Class Initialized
INFO - 2025-05-13 14:49:33 --> Security Class Initialized
DEBUG - 2025-05-13 14:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:49:33 --> Input Class Initialized
INFO - 2025-05-13 14:49:33 --> Language Class Initialized
INFO - 2025-05-13 14:49:33 --> Loader Class Initialized
INFO - 2025-05-13 14:49:33 --> Helper loaded: url_helper
INFO - 2025-05-13 14:49:33 --> Helper loaded: form_helper
INFO - 2025-05-13 14:49:33 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:49:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:49:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:49:33 --> Controller Class Initialized
INFO - 2025-05-13 14:49:33 --> Model "User_model" initialized
INFO - 2025-05-13 14:49:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-13 14:49:33 --> Final output sent to browser
DEBUG - 2025-05-13 14:49:33 --> Total execution time: 0.0610
INFO - 2025-05-13 14:49:41 --> Config Class Initialized
INFO - 2025-05-13 14:49:41 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:49:41 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:49:41 --> Utf8 Class Initialized
INFO - 2025-05-13 14:49:41 --> URI Class Initialized
INFO - 2025-05-13 14:49:41 --> Router Class Initialized
INFO - 2025-05-13 14:49:41 --> Output Class Initialized
INFO - 2025-05-13 14:49:41 --> Security Class Initialized
DEBUG - 2025-05-13 14:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:49:41 --> Input Class Initialized
INFO - 2025-05-13 14:49:41 --> Language Class Initialized
INFO - 2025-05-13 14:49:41 --> Loader Class Initialized
INFO - 2025-05-13 14:49:41 --> Helper loaded: url_helper
INFO - 2025-05-13 14:49:41 --> Helper loaded: form_helper
INFO - 2025-05-13 14:49:41 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:49:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:49:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:49:41 --> Controller Class Initialized
INFO - 2025-05-13 14:49:41 --> Model "User_model" initialized
INFO - 2025-05-13 14:49:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-13 14:49:41 --> Final output sent to browser
DEBUG - 2025-05-13 14:49:41 --> Total execution time: 0.1693
INFO - 2025-05-13 14:49:49 --> Config Class Initialized
INFO - 2025-05-13 14:49:49 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:49:49 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:49:49 --> Utf8 Class Initialized
INFO - 2025-05-13 14:49:49 --> URI Class Initialized
INFO - 2025-05-13 14:49:49 --> Router Class Initialized
INFO - 2025-05-13 14:49:49 --> Output Class Initialized
INFO - 2025-05-13 14:49:49 --> Security Class Initialized
DEBUG - 2025-05-13 14:49:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:49:49 --> Input Class Initialized
INFO - 2025-05-13 14:49:49 --> Language Class Initialized
INFO - 2025-05-13 14:49:49 --> Loader Class Initialized
INFO - 2025-05-13 14:49:49 --> Helper loaded: url_helper
INFO - 2025-05-13 14:49:49 --> Helper loaded: form_helper
INFO - 2025-05-13 14:49:49 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:49:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:49:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:49:49 --> Controller Class Initialized
INFO - 2025-05-13 14:49:49 --> Model "User_model" initialized
INFO - 2025-05-13 14:49:50 --> Config Class Initialized
INFO - 2025-05-13 14:49:50 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:49:50 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:49:50 --> Utf8 Class Initialized
INFO - 2025-05-13 14:49:50 --> URI Class Initialized
INFO - 2025-05-13 14:49:50 --> Router Class Initialized
INFO - 2025-05-13 14:49:50 --> Output Class Initialized
INFO - 2025-05-13 14:49:50 --> Security Class Initialized
DEBUG - 2025-05-13 14:49:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:49:50 --> Input Class Initialized
INFO - 2025-05-13 14:49:50 --> Language Class Initialized
INFO - 2025-05-13 14:49:50 --> Loader Class Initialized
INFO - 2025-05-13 14:49:50 --> Helper loaded: url_helper
INFO - 2025-05-13 14:49:50 --> Helper loaded: form_helper
INFO - 2025-05-13 14:49:50 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:49:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:49:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:49:50 --> Controller Class Initialized
INFO - 2025-05-13 14:49:50 --> Model "User_model" initialized
INFO - 2025-05-13 14:49:50 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-13 14:49:50 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-13 14:49:50 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-13 14:49:50 --> Final output sent to browser
DEBUG - 2025-05-13 14:49:50 --> Total execution time: 0.0655
INFO - 2025-05-13 14:49:52 --> Config Class Initialized
INFO - 2025-05-13 14:49:52 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:49:52 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:49:52 --> Utf8 Class Initialized
INFO - 2025-05-13 14:49:52 --> URI Class Initialized
INFO - 2025-05-13 14:49:52 --> Router Class Initialized
INFO - 2025-05-13 14:49:52 --> Output Class Initialized
INFO - 2025-05-13 14:49:52 --> Security Class Initialized
DEBUG - 2025-05-13 14:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:49:52 --> Input Class Initialized
INFO - 2025-05-13 14:49:52 --> Language Class Initialized
INFO - 2025-05-13 14:49:52 --> Loader Class Initialized
INFO - 2025-05-13 14:49:52 --> Helper loaded: url_helper
INFO - 2025-05-13 14:49:52 --> Helper loaded: form_helper
INFO - 2025-05-13 14:49:52 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:49:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:49:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:49:52 --> Controller Class Initialized
INFO - 2025-05-13 14:49:52 --> Model "User_model" initialized
INFO - 2025-05-13 14:49:52 --> Config Class Initialized
INFO - 2025-05-13 14:49:52 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:49:52 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:49:52 --> Utf8 Class Initialized
INFO - 2025-05-13 14:49:52 --> URI Class Initialized
INFO - 2025-05-13 14:49:52 --> Router Class Initialized
INFO - 2025-05-13 14:49:52 --> Output Class Initialized
INFO - 2025-05-13 14:49:52 --> Security Class Initialized
DEBUG - 2025-05-13 14:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:49:52 --> Input Class Initialized
INFO - 2025-05-13 14:49:52 --> Language Class Initialized
INFO - 2025-05-13 14:49:52 --> Loader Class Initialized
INFO - 2025-05-13 14:49:52 --> Helper loaded: url_helper
INFO - 2025-05-13 14:49:52 --> Helper loaded: form_helper
INFO - 2025-05-13 14:49:52 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:49:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:49:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:49:52 --> Controller Class Initialized
INFO - 2025-05-13 14:49:52 --> Model "User_model" initialized
INFO - 2025-05-13 14:49:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-13 14:49:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-13 14:49:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-13 14:49:52 --> Final output sent to browser
DEBUG - 2025-05-13 14:49:52 --> Total execution time: 0.0636
INFO - 2025-05-13 14:49:57 --> Config Class Initialized
INFO - 2025-05-13 14:49:57 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:49:57 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:49:57 --> Utf8 Class Initialized
INFO - 2025-05-13 14:49:57 --> URI Class Initialized
INFO - 2025-05-13 14:49:57 --> Router Class Initialized
INFO - 2025-05-13 14:49:57 --> Output Class Initialized
INFO - 2025-05-13 14:49:57 --> Security Class Initialized
DEBUG - 2025-05-13 14:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:49:57 --> Input Class Initialized
INFO - 2025-05-13 14:49:57 --> Language Class Initialized
INFO - 2025-05-13 14:49:57 --> Loader Class Initialized
INFO - 2025-05-13 14:49:57 --> Helper loaded: url_helper
INFO - 2025-05-13 14:49:57 --> Helper loaded: form_helper
INFO - 2025-05-13 14:49:57 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:49:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:49:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:49:57 --> Controller Class Initialized
INFO - 2025-05-13 14:49:57 --> Model "User_model" initialized
INFO - 2025-05-13 14:49:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-13 14:49:57 --> Final output sent to browser
DEBUG - 2025-05-13 14:49:57 --> Total execution time: 0.0868
INFO - 2025-05-13 14:50:07 --> Config Class Initialized
INFO - 2025-05-13 14:50:07 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:50:07 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:50:07 --> Utf8 Class Initialized
INFO - 2025-05-13 14:50:07 --> URI Class Initialized
INFO - 2025-05-13 14:50:07 --> Router Class Initialized
INFO - 2025-05-13 14:50:07 --> Output Class Initialized
INFO - 2025-05-13 14:50:07 --> Security Class Initialized
DEBUG - 2025-05-13 14:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:50:07 --> Input Class Initialized
INFO - 2025-05-13 14:50:07 --> Language Class Initialized
INFO - 2025-05-13 14:50:07 --> Loader Class Initialized
INFO - 2025-05-13 14:50:07 --> Helper loaded: url_helper
INFO - 2025-05-13 14:50:07 --> Helper loaded: form_helper
INFO - 2025-05-13 14:50:07 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:50:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:50:07 --> Controller Class Initialized
INFO - 2025-05-13 14:50:07 --> Model "User_model" initialized
INFO - 2025-05-13 14:50:07 --> Config Class Initialized
INFO - 2025-05-13 14:50:07 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:50:07 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:50:07 --> Utf8 Class Initialized
INFO - 2025-05-13 14:50:07 --> URI Class Initialized
INFO - 2025-05-13 14:50:07 --> Router Class Initialized
INFO - 2025-05-13 14:50:07 --> Output Class Initialized
INFO - 2025-05-13 14:50:07 --> Security Class Initialized
DEBUG - 2025-05-13 14:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:50:07 --> Input Class Initialized
INFO - 2025-05-13 14:50:07 --> Language Class Initialized
INFO - 2025-05-13 14:50:07 --> Loader Class Initialized
INFO - 2025-05-13 14:50:07 --> Helper loaded: url_helper
INFO - 2025-05-13 14:50:07 --> Helper loaded: form_helper
INFO - 2025-05-13 14:50:07 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:50:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:50:07 --> Controller Class Initialized
INFO - 2025-05-13 14:50:07 --> Model "User_model" initialized
INFO - 2025-05-13 14:50:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-13 14:50:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-13 14:50:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-13 14:50:07 --> Final output sent to browser
DEBUG - 2025-05-13 14:50:07 --> Total execution time: 0.0617
INFO - 2025-05-13 14:50:09 --> Config Class Initialized
INFO - 2025-05-13 14:50:09 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:50:09 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:50:09 --> Utf8 Class Initialized
INFO - 2025-05-13 14:50:09 --> URI Class Initialized
INFO - 2025-05-13 14:50:09 --> Router Class Initialized
INFO - 2025-05-13 14:50:09 --> Output Class Initialized
INFO - 2025-05-13 14:50:09 --> Security Class Initialized
DEBUG - 2025-05-13 14:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:50:09 --> Input Class Initialized
INFO - 2025-05-13 14:50:09 --> Language Class Initialized
INFO - 2025-05-13 14:50:09 --> Loader Class Initialized
INFO - 2025-05-13 14:50:09 --> Helper loaded: url_helper
INFO - 2025-05-13 14:50:09 --> Helper loaded: form_helper
INFO - 2025-05-13 14:50:09 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:50:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:50:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:50:09 --> Controller Class Initialized
INFO - 2025-05-13 14:50:09 --> Model "User_model" initialized
INFO - 2025-05-13 14:50:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-13 14:50:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/artikel.php
INFO - 2025-05-13 14:50:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-13 14:50:09 --> Final output sent to browser
DEBUG - 2025-05-13 14:50:09 --> Total execution time: 0.0657
INFO - 2025-05-13 14:50:11 --> Config Class Initialized
INFO - 2025-05-13 14:50:11 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:50:11 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:50:11 --> Utf8 Class Initialized
INFO - 2025-05-13 14:50:11 --> URI Class Initialized
INFO - 2025-05-13 14:50:11 --> Router Class Initialized
INFO - 2025-05-13 14:50:11 --> Output Class Initialized
INFO - 2025-05-13 14:50:11 --> Security Class Initialized
DEBUG - 2025-05-13 14:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:50:11 --> Input Class Initialized
INFO - 2025-05-13 14:50:11 --> Language Class Initialized
INFO - 2025-05-13 14:50:11 --> Loader Class Initialized
INFO - 2025-05-13 14:50:11 --> Helper loaded: url_helper
INFO - 2025-05-13 14:50:11 --> Helper loaded: form_helper
INFO - 2025-05-13 14:50:11 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:50:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:50:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:50:11 --> Controller Class Initialized
INFO - 2025-05-13 14:50:11 --> Model "User_model" initialized
INFO - 2025-05-13 14:50:11 --> Model "Workout_model" initialized
INFO - 2025-05-13 14:50:11 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 14:50:11 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 14:50:11 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 14:50:11 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 14:50:11 --> Final output sent to browser
DEBUG - 2025-05-13 14:50:11 --> Total execution time: 0.2962
INFO - 2025-05-13 14:51:43 --> Config Class Initialized
INFO - 2025-05-13 14:51:43 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:51:43 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:51:43 --> Utf8 Class Initialized
INFO - 2025-05-13 14:51:43 --> URI Class Initialized
INFO - 2025-05-13 14:51:43 --> Router Class Initialized
INFO - 2025-05-13 14:51:43 --> Output Class Initialized
INFO - 2025-05-13 14:51:43 --> Security Class Initialized
DEBUG - 2025-05-13 14:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:51:43 --> Input Class Initialized
INFO - 2025-05-13 14:51:43 --> Language Class Initialized
INFO - 2025-05-13 14:51:43 --> Loader Class Initialized
INFO - 2025-05-13 14:51:43 --> Helper loaded: url_helper
INFO - 2025-05-13 14:51:43 --> Helper loaded: form_helper
INFO - 2025-05-13 14:51:43 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:51:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:51:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:51:43 --> Controller Class Initialized
INFO - 2025-05-13 14:51:44 --> Model "Community_model" initialized
INFO - 2025-05-13 14:51:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\community/index.php
INFO - 2025-05-13 14:51:44 --> Final output sent to browser
DEBUG - 2025-05-13 14:51:44 --> Total execution time: 0.2692
INFO - 2025-05-13 14:56:23 --> Config Class Initialized
INFO - 2025-05-13 14:56:23 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:56:23 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:56:23 --> Utf8 Class Initialized
INFO - 2025-05-13 14:56:23 --> URI Class Initialized
INFO - 2025-05-13 14:56:23 --> Router Class Initialized
INFO - 2025-05-13 14:56:23 --> Output Class Initialized
INFO - 2025-05-13 14:56:23 --> Security Class Initialized
DEBUG - 2025-05-13 14:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:56:23 --> Input Class Initialized
INFO - 2025-05-13 14:56:23 --> Language Class Initialized
INFO - 2025-05-13 14:56:23 --> Loader Class Initialized
INFO - 2025-05-13 14:56:23 --> Helper loaded: url_helper
INFO - 2025-05-13 14:56:23 --> Helper loaded: form_helper
INFO - 2025-05-13 14:56:23 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:56:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:56:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:56:23 --> Controller Class Initialized
INFO - 2025-05-13 14:56:23 --> Model "Community_model" initialized
INFO - 2025-05-13 14:56:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\community/index.php
INFO - 2025-05-13 14:56:23 --> Final output sent to browser
DEBUG - 2025-05-13 14:56:23 --> Total execution time: 0.0858
INFO - 2025-05-13 14:57:12 --> Config Class Initialized
INFO - 2025-05-13 14:57:12 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:57:12 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:57:12 --> Utf8 Class Initialized
INFO - 2025-05-13 14:57:12 --> URI Class Initialized
INFO - 2025-05-13 14:57:12 --> Router Class Initialized
INFO - 2025-05-13 14:57:12 --> Output Class Initialized
INFO - 2025-05-13 14:57:12 --> Security Class Initialized
DEBUG - 2025-05-13 14:57:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:57:12 --> Input Class Initialized
INFO - 2025-05-13 14:57:12 --> Language Class Initialized
INFO - 2025-05-13 14:57:12 --> Loader Class Initialized
INFO - 2025-05-13 14:57:12 --> Helper loaded: url_helper
INFO - 2025-05-13 14:57:12 --> Helper loaded: form_helper
INFO - 2025-05-13 14:57:12 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:57:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:57:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:57:12 --> Controller Class Initialized
INFO - 2025-05-13 14:57:12 --> Model "Community_model" initialized
INFO - 2025-05-13 14:57:12 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\community/discussion.php
INFO - 2025-05-13 14:57:12 --> Final output sent to browser
DEBUG - 2025-05-13 14:57:12 --> Total execution time: 0.0956
INFO - 2025-05-13 14:57:21 --> Config Class Initialized
INFO - 2025-05-13 14:57:21 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:57:21 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:57:21 --> Utf8 Class Initialized
INFO - 2025-05-13 14:57:21 --> URI Class Initialized
INFO - 2025-05-13 14:57:21 --> Router Class Initialized
INFO - 2025-05-13 14:57:21 --> Output Class Initialized
INFO - 2025-05-13 14:57:21 --> Security Class Initialized
DEBUG - 2025-05-13 14:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:57:21 --> Input Class Initialized
INFO - 2025-05-13 14:57:21 --> Language Class Initialized
INFO - 2025-05-13 14:57:21 --> Loader Class Initialized
INFO - 2025-05-13 14:57:21 --> Helper loaded: url_helper
INFO - 2025-05-13 14:57:21 --> Helper loaded: form_helper
INFO - 2025-05-13 14:57:21 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:57:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:57:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:57:21 --> Controller Class Initialized
INFO - 2025-05-13 14:57:21 --> Model "Community_model" initialized
INFO - 2025-05-13 14:57:21 --> Config Class Initialized
INFO - 2025-05-13 14:57:21 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:57:21 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:57:21 --> Utf8 Class Initialized
INFO - 2025-05-13 14:57:21 --> URI Class Initialized
INFO - 2025-05-13 14:57:21 --> Router Class Initialized
INFO - 2025-05-13 14:57:21 --> Output Class Initialized
INFO - 2025-05-13 14:57:21 --> Security Class Initialized
DEBUG - 2025-05-13 14:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:57:21 --> Input Class Initialized
INFO - 2025-05-13 14:57:21 --> Language Class Initialized
INFO - 2025-05-13 14:57:21 --> Loader Class Initialized
INFO - 2025-05-13 14:57:21 --> Helper loaded: url_helper
INFO - 2025-05-13 14:57:21 --> Helper loaded: form_helper
INFO - 2025-05-13 14:57:21 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:57:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:57:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:57:21 --> Controller Class Initialized
INFO - 2025-05-13 14:57:21 --> Model "Community_model" initialized
INFO - 2025-05-13 14:57:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\community/discussion.php
INFO - 2025-05-13 14:57:21 --> Final output sent to browser
DEBUG - 2025-05-13 14:57:21 --> Total execution time: 0.0636
INFO - 2025-05-13 14:57:33 --> Config Class Initialized
INFO - 2025-05-13 14:57:33 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:57:33 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:57:33 --> Utf8 Class Initialized
INFO - 2025-05-13 14:57:33 --> URI Class Initialized
INFO - 2025-05-13 14:57:33 --> Router Class Initialized
INFO - 2025-05-13 14:57:33 --> Output Class Initialized
INFO - 2025-05-13 14:57:33 --> Security Class Initialized
DEBUG - 2025-05-13 14:57:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:57:33 --> Input Class Initialized
INFO - 2025-05-13 14:57:33 --> Language Class Initialized
INFO - 2025-05-13 14:57:33 --> Loader Class Initialized
INFO - 2025-05-13 14:57:33 --> Helper loaded: url_helper
INFO - 2025-05-13 14:57:33 --> Helper loaded: form_helper
INFO - 2025-05-13 14:57:33 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:57:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:57:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:57:33 --> Controller Class Initialized
INFO - 2025-05-13 14:57:33 --> Model "Community_model" initialized
INFO - 2025-05-13 14:57:33 --> Config Class Initialized
INFO - 2025-05-13 14:57:33 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:57:33 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:57:33 --> Utf8 Class Initialized
INFO - 2025-05-13 14:57:33 --> URI Class Initialized
INFO - 2025-05-13 14:57:33 --> Router Class Initialized
INFO - 2025-05-13 14:57:33 --> Output Class Initialized
INFO - 2025-05-13 14:57:33 --> Security Class Initialized
DEBUG - 2025-05-13 14:57:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:57:33 --> Input Class Initialized
INFO - 2025-05-13 14:57:33 --> Language Class Initialized
INFO - 2025-05-13 14:57:33 --> Loader Class Initialized
INFO - 2025-05-13 14:57:33 --> Helper loaded: url_helper
INFO - 2025-05-13 14:57:33 --> Helper loaded: form_helper
INFO - 2025-05-13 14:57:33 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:57:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:57:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:57:33 --> Controller Class Initialized
INFO - 2025-05-13 14:57:33 --> Model "Community_model" initialized
INFO - 2025-05-13 14:57:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\community/discussion.php
INFO - 2025-05-13 14:57:33 --> Final output sent to browser
DEBUG - 2025-05-13 14:57:33 --> Total execution time: 0.0751
INFO - 2025-05-13 14:57:37 --> Config Class Initialized
INFO - 2025-05-13 14:57:37 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:57:37 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:57:37 --> Utf8 Class Initialized
INFO - 2025-05-13 14:57:37 --> URI Class Initialized
INFO - 2025-05-13 14:57:37 --> Router Class Initialized
INFO - 2025-05-13 14:57:37 --> Output Class Initialized
INFO - 2025-05-13 14:57:37 --> Security Class Initialized
DEBUG - 2025-05-13 14:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:57:37 --> Input Class Initialized
INFO - 2025-05-13 14:57:37 --> Language Class Initialized
INFO - 2025-05-13 14:57:37 --> Loader Class Initialized
INFO - 2025-05-13 14:57:37 --> Helper loaded: url_helper
INFO - 2025-05-13 14:57:37 --> Helper loaded: form_helper
INFO - 2025-05-13 14:57:37 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:57:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:57:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:57:37 --> Controller Class Initialized
INFO - 2025-05-13 14:57:37 --> Model "Community_model" initialized
INFO - 2025-05-13 14:57:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\community/index.php
INFO - 2025-05-13 14:57:37 --> Final output sent to browser
DEBUG - 2025-05-13 14:57:37 --> Total execution time: 0.0827
INFO - 2025-05-13 14:58:40 --> Config Class Initialized
INFO - 2025-05-13 14:58:40 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:58:40 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:58:40 --> Utf8 Class Initialized
INFO - 2025-05-13 14:58:40 --> URI Class Initialized
INFO - 2025-05-13 14:58:40 --> Router Class Initialized
INFO - 2025-05-13 14:58:40 --> Output Class Initialized
INFO - 2025-05-13 14:58:40 --> Security Class Initialized
DEBUG - 2025-05-13 14:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:58:40 --> Input Class Initialized
INFO - 2025-05-13 14:58:40 --> Language Class Initialized
INFO - 2025-05-13 14:58:40 --> Loader Class Initialized
INFO - 2025-05-13 14:58:40 --> Helper loaded: url_helper
INFO - 2025-05-13 14:58:40 --> Helper loaded: form_helper
INFO - 2025-05-13 14:58:40 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:58:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:58:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:58:40 --> Controller Class Initialized
INFO - 2025-05-13 14:58:40 --> Model "Community_model" initialized
INFO - 2025-05-13 14:58:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\community/discussion.php
INFO - 2025-05-13 14:58:40 --> Final output sent to browser
DEBUG - 2025-05-13 14:58:40 --> Total execution time: 0.0750
INFO - 2025-05-13 14:58:47 --> Config Class Initialized
INFO - 2025-05-13 14:58:47 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:58:47 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:58:47 --> Utf8 Class Initialized
INFO - 2025-05-13 14:58:47 --> URI Class Initialized
INFO - 2025-05-13 14:58:47 --> Router Class Initialized
INFO - 2025-05-13 14:58:47 --> Output Class Initialized
INFO - 2025-05-13 14:58:47 --> Security Class Initialized
DEBUG - 2025-05-13 14:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:58:47 --> Input Class Initialized
INFO - 2025-05-13 14:58:47 --> Language Class Initialized
INFO - 2025-05-13 14:58:47 --> Loader Class Initialized
INFO - 2025-05-13 14:58:47 --> Helper loaded: url_helper
INFO - 2025-05-13 14:58:47 --> Helper loaded: form_helper
INFO - 2025-05-13 14:58:47 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:58:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:58:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:58:47 --> Controller Class Initialized
INFO - 2025-05-13 14:58:47 --> Model "Community_model" initialized
INFO - 2025-05-13 14:58:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\community/explore.php
INFO - 2025-05-13 14:58:47 --> Final output sent to browser
DEBUG - 2025-05-13 14:58:47 --> Total execution time: 0.0820
INFO - 2025-05-13 14:58:52 --> Config Class Initialized
INFO - 2025-05-13 14:58:52 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:58:52 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:58:52 --> Utf8 Class Initialized
INFO - 2025-05-13 14:58:52 --> URI Class Initialized
INFO - 2025-05-13 14:58:52 --> Router Class Initialized
INFO - 2025-05-13 14:58:52 --> Output Class Initialized
INFO - 2025-05-13 14:58:52 --> Security Class Initialized
DEBUG - 2025-05-13 14:58:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:58:52 --> Input Class Initialized
INFO - 2025-05-13 14:58:52 --> Language Class Initialized
INFO - 2025-05-13 14:58:52 --> Loader Class Initialized
INFO - 2025-05-13 14:58:52 --> Helper loaded: url_helper
INFO - 2025-05-13 14:58:52 --> Helper loaded: form_helper
INFO - 2025-05-13 14:58:52 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:58:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:58:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:58:52 --> Controller Class Initialized
INFO - 2025-05-13 14:58:52 --> Model "Community_model" initialized
INFO - 2025-05-13 14:58:52 --> Config Class Initialized
INFO - 2025-05-13 14:58:52 --> Hooks Class Initialized
DEBUG - 2025-05-13 14:58:52 --> UTF-8 Support Enabled
INFO - 2025-05-13 14:58:52 --> Utf8 Class Initialized
INFO - 2025-05-13 14:58:52 --> URI Class Initialized
INFO - 2025-05-13 14:58:52 --> Router Class Initialized
INFO - 2025-05-13 14:58:52 --> Output Class Initialized
INFO - 2025-05-13 14:58:52 --> Security Class Initialized
DEBUG - 2025-05-13 14:58:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 14:58:52 --> Input Class Initialized
INFO - 2025-05-13 14:58:52 --> Language Class Initialized
INFO - 2025-05-13 14:58:52 --> Loader Class Initialized
INFO - 2025-05-13 14:58:52 --> Helper loaded: url_helper
INFO - 2025-05-13 14:58:52 --> Helper loaded: form_helper
INFO - 2025-05-13 14:58:52 --> Database Driver Class Initialized
DEBUG - 2025-05-13 14:58:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 14:58:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 14:58:52 --> Controller Class Initialized
INFO - 2025-05-13 14:58:52 --> Model "Community_model" initialized
INFO - 2025-05-13 14:58:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\community/index.php
INFO - 2025-05-13 14:58:52 --> Final output sent to browser
DEBUG - 2025-05-13 14:58:52 --> Total execution time: 0.0580
INFO - 2025-05-13 15:02:13 --> Config Class Initialized
INFO - 2025-05-13 15:02:13 --> Hooks Class Initialized
DEBUG - 2025-05-13 15:02:13 --> UTF-8 Support Enabled
INFO - 2025-05-13 15:02:13 --> Utf8 Class Initialized
INFO - 2025-05-13 15:02:13 --> URI Class Initialized
INFO - 2025-05-13 15:02:13 --> Router Class Initialized
INFO - 2025-05-13 15:02:13 --> Output Class Initialized
INFO - 2025-05-13 15:02:13 --> Security Class Initialized
DEBUG - 2025-05-13 15:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 15:02:13 --> Input Class Initialized
INFO - 2025-05-13 15:02:13 --> Language Class Initialized
INFO - 2025-05-13 15:02:13 --> Loader Class Initialized
INFO - 2025-05-13 15:02:13 --> Helper loaded: url_helper
INFO - 2025-05-13 15:02:13 --> Helper loaded: form_helper
INFO - 2025-05-13 15:02:13 --> Database Driver Class Initialized
DEBUG - 2025-05-13 15:02:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 15:02:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 15:02:13 --> Controller Class Initialized
INFO - 2025-05-13 15:02:13 --> Model "Community_model" initialized
ERROR - 2025-05-13 15:02:13 --> Severity: Warning --> Undefined property: Community::$User_model C:\laragon\www\Project\fitnessrecord\application\controllers\Community.php 23
ERROR - 2025-05-13 15:02:13 --> Severity: error --> Exception: Call to a member function get_by_id() on null C:\laragon\www\Project\fitnessrecord\application\controllers\Community.php 23
INFO - 2025-05-13 15:02:35 --> Config Class Initialized
INFO - 2025-05-13 15:02:35 --> Hooks Class Initialized
DEBUG - 2025-05-13 15:02:35 --> UTF-8 Support Enabled
INFO - 2025-05-13 15:02:35 --> Utf8 Class Initialized
INFO - 2025-05-13 15:02:35 --> URI Class Initialized
INFO - 2025-05-13 15:02:35 --> Router Class Initialized
INFO - 2025-05-13 15:02:35 --> Output Class Initialized
INFO - 2025-05-13 15:02:35 --> Security Class Initialized
DEBUG - 2025-05-13 15:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 15:02:35 --> Input Class Initialized
INFO - 2025-05-13 15:02:35 --> Language Class Initialized
INFO - 2025-05-13 15:02:35 --> Loader Class Initialized
INFO - 2025-05-13 15:02:35 --> Helper loaded: url_helper
INFO - 2025-05-13 15:02:35 --> Helper loaded: form_helper
INFO - 2025-05-13 15:02:35 --> Database Driver Class Initialized
DEBUG - 2025-05-13 15:02:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 15:02:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 15:02:35 --> Controller Class Initialized
INFO - 2025-05-13 15:02:35 --> Model "Workout_model" initialized
INFO - 2025-05-13 15:02:35 --> Model "Community_model" initialized
ERROR - 2025-05-13 15:02:35 --> Severity: Warning --> Undefined property: Community::$User_model C:\laragon\www\Project\fitnessrecord\application\controllers\Community.php 24
ERROR - 2025-05-13 15:02:35 --> Severity: error --> Exception: Call to a member function get_by_id() on null C:\laragon\www\Project\fitnessrecord\application\controllers\Community.php 24
INFO - 2025-05-13 15:02:36 --> Config Class Initialized
INFO - 2025-05-13 15:02:36 --> Hooks Class Initialized
DEBUG - 2025-05-13 15:02:36 --> UTF-8 Support Enabled
INFO - 2025-05-13 15:02:36 --> Utf8 Class Initialized
INFO - 2025-05-13 15:02:36 --> URI Class Initialized
INFO - 2025-05-13 15:02:36 --> Router Class Initialized
INFO - 2025-05-13 15:02:36 --> Output Class Initialized
INFO - 2025-05-13 15:02:36 --> Security Class Initialized
DEBUG - 2025-05-13 15:02:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 15:02:36 --> Input Class Initialized
INFO - 2025-05-13 15:02:36 --> Language Class Initialized
INFO - 2025-05-13 15:02:36 --> Loader Class Initialized
INFO - 2025-05-13 15:02:36 --> Helper loaded: url_helper
INFO - 2025-05-13 15:02:36 --> Helper loaded: form_helper
INFO - 2025-05-13 15:02:36 --> Database Driver Class Initialized
DEBUG - 2025-05-13 15:02:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 15:02:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 15:02:36 --> Controller Class Initialized
INFO - 2025-05-13 15:02:36 --> Model "Workout_model" initialized
INFO - 2025-05-13 15:02:36 --> Model "Community_model" initialized
ERROR - 2025-05-13 15:02:36 --> Severity: Warning --> Undefined property: Community::$User_model C:\laragon\www\Project\fitnessrecord\application\controllers\Community.php 24
ERROR - 2025-05-13 15:02:36 --> Severity: error --> Exception: Call to a member function get_by_id() on null C:\laragon\www\Project\fitnessrecord\application\controllers\Community.php 24
INFO - 2025-05-13 15:03:01 --> Config Class Initialized
INFO - 2025-05-13 15:03:01 --> Hooks Class Initialized
DEBUG - 2025-05-13 15:03:01 --> UTF-8 Support Enabled
INFO - 2025-05-13 15:03:01 --> Utf8 Class Initialized
INFO - 2025-05-13 15:03:01 --> URI Class Initialized
INFO - 2025-05-13 15:03:01 --> Router Class Initialized
INFO - 2025-05-13 15:03:01 --> Output Class Initialized
INFO - 2025-05-13 15:03:01 --> Security Class Initialized
DEBUG - 2025-05-13 15:03:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 15:03:01 --> Input Class Initialized
INFO - 2025-05-13 15:03:01 --> Language Class Initialized
INFO - 2025-05-13 15:03:01 --> Loader Class Initialized
INFO - 2025-05-13 15:03:01 --> Helper loaded: url_helper
INFO - 2025-05-13 15:03:01 --> Helper loaded: form_helper
INFO - 2025-05-13 15:03:01 --> Database Driver Class Initialized
DEBUG - 2025-05-13 15:03:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 15:03:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 15:03:01 --> Controller Class Initialized
INFO - 2025-05-13 15:03:01 --> Model "User_model" initialized
INFO - 2025-05-13 15:03:01 --> Model "Community_model" initialized
INFO - 2025-05-13 15:03:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 15:03:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 15:03:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\community/index.php
INFO - 2025-05-13 15:03:01 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 15:03:01 --> Final output sent to browser
DEBUG - 2025-05-13 15:03:01 --> Total execution time: 0.0806
INFO - 2025-05-13 15:03:03 --> Config Class Initialized
INFO - 2025-05-13 15:03:03 --> Hooks Class Initialized
DEBUG - 2025-05-13 15:03:03 --> UTF-8 Support Enabled
INFO - 2025-05-13 15:03:03 --> Utf8 Class Initialized
INFO - 2025-05-13 15:03:03 --> URI Class Initialized
INFO - 2025-05-13 15:03:03 --> Router Class Initialized
INFO - 2025-05-13 15:03:03 --> Output Class Initialized
INFO - 2025-05-13 15:03:03 --> Security Class Initialized
DEBUG - 2025-05-13 15:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 15:03:03 --> Input Class Initialized
INFO - 2025-05-13 15:03:03 --> Language Class Initialized
INFO - 2025-05-13 15:03:03 --> Loader Class Initialized
INFO - 2025-05-13 15:03:03 --> Helper loaded: url_helper
INFO - 2025-05-13 15:03:03 --> Helper loaded: form_helper
INFO - 2025-05-13 15:03:03 --> Database Driver Class Initialized
DEBUG - 2025-05-13 15:03:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 15:03:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 15:03:03 --> Controller Class Initialized
INFO - 2025-05-13 15:03:03 --> Model "User_model" initialized
INFO - 2025-05-13 15:03:03 --> Model "Community_model" initialized
INFO - 2025-05-13 15:03:03 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\community/explore.php
INFO - 2025-05-13 15:03:03 --> Final output sent to browser
DEBUG - 2025-05-13 15:03:03 --> Total execution time: 0.0685
INFO - 2025-05-13 15:03:39 --> Config Class Initialized
INFO - 2025-05-13 15:03:39 --> Hooks Class Initialized
DEBUG - 2025-05-13 15:03:39 --> UTF-8 Support Enabled
INFO - 2025-05-13 15:03:39 --> Utf8 Class Initialized
INFO - 2025-05-13 15:03:39 --> URI Class Initialized
INFO - 2025-05-13 15:03:39 --> Router Class Initialized
INFO - 2025-05-13 15:03:39 --> Output Class Initialized
INFO - 2025-05-13 15:03:39 --> Security Class Initialized
DEBUG - 2025-05-13 15:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 15:03:39 --> Input Class Initialized
INFO - 2025-05-13 15:03:39 --> Language Class Initialized
INFO - 2025-05-13 15:03:39 --> Loader Class Initialized
INFO - 2025-05-13 15:03:39 --> Helper loaded: url_helper
INFO - 2025-05-13 15:03:39 --> Helper loaded: form_helper
INFO - 2025-05-13 15:03:39 --> Database Driver Class Initialized
DEBUG - 2025-05-13 15:03:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 15:03:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 15:03:39 --> Controller Class Initialized
INFO - 2025-05-13 15:03:39 --> Model "User_model" initialized
INFO - 2025-05-13 15:03:39 --> Model "Community_model" initialized
INFO - 2025-05-13 15:03:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 15:03:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 15:03:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\community/index.php
INFO - 2025-05-13 15:03:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 15:03:39 --> Final output sent to browser
DEBUG - 2025-05-13 15:03:39 --> Total execution time: 0.0760
INFO - 2025-05-13 15:04:38 --> Config Class Initialized
INFO - 2025-05-13 15:04:38 --> Hooks Class Initialized
DEBUG - 2025-05-13 15:04:38 --> UTF-8 Support Enabled
INFO - 2025-05-13 15:04:38 --> Utf8 Class Initialized
INFO - 2025-05-13 15:04:38 --> URI Class Initialized
INFO - 2025-05-13 15:04:38 --> Router Class Initialized
INFO - 2025-05-13 15:04:38 --> Output Class Initialized
INFO - 2025-05-13 15:04:38 --> Security Class Initialized
DEBUG - 2025-05-13 15:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 15:04:38 --> Input Class Initialized
INFO - 2025-05-13 15:04:38 --> Language Class Initialized
INFO - 2025-05-13 15:04:38 --> Loader Class Initialized
INFO - 2025-05-13 15:04:38 --> Helper loaded: url_helper
INFO - 2025-05-13 15:04:38 --> Helper loaded: form_helper
INFO - 2025-05-13 15:04:38 --> Database Driver Class Initialized
DEBUG - 2025-05-13 15:04:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 15:04:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 15:04:38 --> Controller Class Initialized
INFO - 2025-05-13 15:04:38 --> Model "User_model" initialized
INFO - 2025-05-13 15:04:38 --> Model "Community_model" initialized
INFO - 2025-05-13 15:04:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 15:04:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 15:04:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\community/index.php
INFO - 2025-05-13 15:04:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 15:04:38 --> Final output sent to browser
DEBUG - 2025-05-13 15:04:38 --> Total execution time: 0.0694
INFO - 2025-05-13 15:04:41 --> Config Class Initialized
INFO - 2025-05-13 15:04:41 --> Hooks Class Initialized
DEBUG - 2025-05-13 15:04:41 --> UTF-8 Support Enabled
INFO - 2025-05-13 15:04:41 --> Utf8 Class Initialized
INFO - 2025-05-13 15:04:41 --> URI Class Initialized
INFO - 2025-05-13 15:04:41 --> Router Class Initialized
INFO - 2025-05-13 15:04:41 --> Output Class Initialized
INFO - 2025-05-13 15:04:41 --> Security Class Initialized
DEBUG - 2025-05-13 15:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 15:04:41 --> Input Class Initialized
INFO - 2025-05-13 15:04:41 --> Language Class Initialized
INFO - 2025-05-13 15:04:41 --> Loader Class Initialized
INFO - 2025-05-13 15:04:41 --> Helper loaded: url_helper
INFO - 2025-05-13 15:04:41 --> Helper loaded: form_helper
INFO - 2025-05-13 15:04:41 --> Database Driver Class Initialized
DEBUG - 2025-05-13 15:04:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 15:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 15:04:41 --> Controller Class Initialized
INFO - 2025-05-13 15:04:41 --> Model "User_model" initialized
INFO - 2025-05-13 15:04:41 --> Model "Workout_model" initialized
INFO - 2025-05-13 15:04:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 15:04:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 15:04:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 15:04:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 15:04:41 --> Final output sent to browser
DEBUG - 2025-05-13 15:04:41 --> Total execution time: 0.0897
INFO - 2025-05-13 15:04:50 --> Config Class Initialized
INFO - 2025-05-13 15:04:50 --> Hooks Class Initialized
DEBUG - 2025-05-13 15:04:50 --> UTF-8 Support Enabled
INFO - 2025-05-13 15:04:50 --> Utf8 Class Initialized
INFO - 2025-05-13 15:04:50 --> URI Class Initialized
INFO - 2025-05-13 15:04:50 --> Router Class Initialized
INFO - 2025-05-13 15:04:50 --> Output Class Initialized
INFO - 2025-05-13 15:04:50 --> Security Class Initialized
DEBUG - 2025-05-13 15:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 15:04:50 --> Input Class Initialized
INFO - 2025-05-13 15:04:50 --> Language Class Initialized
INFO - 2025-05-13 15:04:50 --> Loader Class Initialized
INFO - 2025-05-13 15:04:50 --> Helper loaded: url_helper
INFO - 2025-05-13 15:04:50 --> Helper loaded: form_helper
INFO - 2025-05-13 15:04:50 --> Database Driver Class Initialized
DEBUG - 2025-05-13 15:04:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 15:04:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 15:04:50 --> Controller Class Initialized
INFO - 2025-05-13 15:04:50 --> Model "User_model" initialized
INFO - 2025-05-13 15:04:50 --> Model "Community_model" initialized
INFO - 2025-05-13 15:04:50 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 15:04:50 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 15:04:50 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\community/index.php
INFO - 2025-05-13 15:04:50 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 15:04:50 --> Final output sent to browser
DEBUG - 2025-05-13 15:04:50 --> Total execution time: 0.0801
INFO - 2025-05-13 15:05:02 --> Config Class Initialized
INFO - 2025-05-13 15:05:02 --> Hooks Class Initialized
DEBUG - 2025-05-13 15:05:02 --> UTF-8 Support Enabled
INFO - 2025-05-13 15:05:02 --> Utf8 Class Initialized
INFO - 2025-05-13 15:05:02 --> URI Class Initialized
INFO - 2025-05-13 15:05:02 --> Router Class Initialized
INFO - 2025-05-13 15:05:02 --> Output Class Initialized
INFO - 2025-05-13 15:05:02 --> Security Class Initialized
DEBUG - 2025-05-13 15:05:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 15:05:02 --> Input Class Initialized
INFO - 2025-05-13 15:05:02 --> Language Class Initialized
INFO - 2025-05-13 15:05:02 --> Loader Class Initialized
INFO - 2025-05-13 15:05:02 --> Helper loaded: url_helper
INFO - 2025-05-13 15:05:02 --> Helper loaded: form_helper
INFO - 2025-05-13 15:05:02 --> Database Driver Class Initialized
DEBUG - 2025-05-13 15:05:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 15:05:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 15:05:02 --> Controller Class Initialized
INFO - 2025-05-13 15:05:02 --> Model "User_model" initialized
INFO - 2025-05-13 15:05:02 --> Model "Workout_model" initialized
INFO - 2025-05-13 15:05:02 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 15:05:02 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 15:05:02 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 15:05:02 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 15:05:02 --> Final output sent to browser
DEBUG - 2025-05-13 15:05:02 --> Total execution time: 0.0717
INFO - 2025-05-13 15:05:23 --> Config Class Initialized
INFO - 2025-05-13 15:05:23 --> Hooks Class Initialized
DEBUG - 2025-05-13 15:05:23 --> UTF-8 Support Enabled
INFO - 2025-05-13 15:05:23 --> Utf8 Class Initialized
INFO - 2025-05-13 15:05:23 --> URI Class Initialized
INFO - 2025-05-13 15:05:23 --> Router Class Initialized
INFO - 2025-05-13 15:05:23 --> Output Class Initialized
INFO - 2025-05-13 15:05:23 --> Security Class Initialized
DEBUG - 2025-05-13 15:05:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 15:05:23 --> Input Class Initialized
INFO - 2025-05-13 15:05:23 --> Language Class Initialized
INFO - 2025-05-13 15:05:23 --> Loader Class Initialized
INFO - 2025-05-13 15:05:23 --> Helper loaded: url_helper
INFO - 2025-05-13 15:05:23 --> Helper loaded: form_helper
INFO - 2025-05-13 15:05:23 --> Database Driver Class Initialized
DEBUG - 2025-05-13 15:05:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 15:05:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 15:05:23 --> Controller Class Initialized
INFO - 2025-05-13 15:05:23 --> Model "User_model" initialized
INFO - 2025-05-13 15:05:23 --> Model "Community_model" initialized
INFO - 2025-05-13 15:05:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 15:05:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 15:05:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\community/index.php
INFO - 2025-05-13 15:05:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 15:05:23 --> Final output sent to browser
DEBUG - 2025-05-13 15:05:23 --> Total execution time: 0.0793
INFO - 2025-05-13 15:06:43 --> Config Class Initialized
INFO - 2025-05-13 15:06:43 --> Hooks Class Initialized
DEBUG - 2025-05-13 15:06:43 --> UTF-8 Support Enabled
INFO - 2025-05-13 15:06:43 --> Utf8 Class Initialized
INFO - 2025-05-13 15:06:43 --> URI Class Initialized
INFO - 2025-05-13 15:06:43 --> Router Class Initialized
INFO - 2025-05-13 15:06:43 --> Output Class Initialized
INFO - 2025-05-13 15:06:43 --> Security Class Initialized
DEBUG - 2025-05-13 15:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 15:06:43 --> Input Class Initialized
INFO - 2025-05-13 15:06:43 --> Language Class Initialized
INFO - 2025-05-13 15:06:43 --> Loader Class Initialized
INFO - 2025-05-13 15:06:43 --> Helper loaded: url_helper
INFO - 2025-05-13 15:06:43 --> Helper loaded: form_helper
INFO - 2025-05-13 15:06:43 --> Database Driver Class Initialized
DEBUG - 2025-05-13 15:06:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 15:06:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 15:06:43 --> Controller Class Initialized
INFO - 2025-05-13 15:06:43 --> Model "User_model" initialized
INFO - 2025-05-13 15:06:43 --> Model "Community_model" initialized
INFO - 2025-05-13 15:06:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 15:06:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 15:06:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\community/index.php
INFO - 2025-05-13 15:06:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 15:06:43 --> Final output sent to browser
DEBUG - 2025-05-13 15:06:43 --> Total execution time: 0.0717
INFO - 2025-05-13 15:08:00 --> Config Class Initialized
INFO - 2025-05-13 15:08:00 --> Hooks Class Initialized
DEBUG - 2025-05-13 15:08:00 --> UTF-8 Support Enabled
INFO - 2025-05-13 15:08:00 --> Utf8 Class Initialized
INFO - 2025-05-13 15:08:00 --> URI Class Initialized
INFO - 2025-05-13 15:08:00 --> Router Class Initialized
INFO - 2025-05-13 15:08:00 --> Output Class Initialized
INFO - 2025-05-13 15:08:00 --> Security Class Initialized
DEBUG - 2025-05-13 15:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 15:08:00 --> Input Class Initialized
INFO - 2025-05-13 15:08:00 --> Language Class Initialized
INFO - 2025-05-13 15:08:00 --> Loader Class Initialized
INFO - 2025-05-13 15:08:00 --> Helper loaded: url_helper
INFO - 2025-05-13 15:08:00 --> Helper loaded: form_helper
INFO - 2025-05-13 15:08:00 --> Database Driver Class Initialized
DEBUG - 2025-05-13 15:08:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 15:08:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 15:08:00 --> Controller Class Initialized
INFO - 2025-05-13 15:08:00 --> Model "User_model" initialized
INFO - 2025-05-13 15:08:00 --> Model "Community_model" initialized
INFO - 2025-05-13 15:08:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 15:08:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 15:08:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\community/index.php
INFO - 2025-05-13 15:08:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 15:08:00 --> Final output sent to browser
DEBUG - 2025-05-13 15:08:00 --> Total execution time: 0.0908
INFO - 2025-05-13 15:16:27 --> Config Class Initialized
INFO - 2025-05-13 15:16:27 --> Hooks Class Initialized
DEBUG - 2025-05-13 15:16:27 --> UTF-8 Support Enabled
INFO - 2025-05-13 15:16:27 --> Utf8 Class Initialized
INFO - 2025-05-13 15:16:27 --> URI Class Initialized
INFO - 2025-05-13 15:16:27 --> Router Class Initialized
INFO - 2025-05-13 15:16:27 --> Output Class Initialized
INFO - 2025-05-13 15:16:27 --> Security Class Initialized
DEBUG - 2025-05-13 15:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 15:16:27 --> Input Class Initialized
INFO - 2025-05-13 15:16:27 --> Language Class Initialized
INFO - 2025-05-13 15:16:27 --> Loader Class Initialized
INFO - 2025-05-13 15:16:27 --> Helper loaded: url_helper
INFO - 2025-05-13 15:16:27 --> Helper loaded: form_helper
INFO - 2025-05-13 15:16:27 --> Database Driver Class Initialized
DEBUG - 2025-05-13 15:16:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 15:16:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 15:16:27 --> Controller Class Initialized
INFO - 2025-05-13 15:16:27 --> Model "User_model" initialized
INFO - 2025-05-13 15:16:27 --> Model "Community_model" initialized
INFO - 2025-05-13 15:16:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 15:16:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 15:16:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\community/index.php
INFO - 2025-05-13 15:16:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 15:16:28 --> Final output sent to browser
DEBUG - 2025-05-13 15:16:28 --> Total execution time: 0.1188
INFO - 2025-05-13 15:16:33 --> Config Class Initialized
INFO - 2025-05-13 15:16:33 --> Hooks Class Initialized
DEBUG - 2025-05-13 15:16:33 --> UTF-8 Support Enabled
INFO - 2025-05-13 15:16:33 --> Utf8 Class Initialized
INFO - 2025-05-13 15:16:33 --> URI Class Initialized
INFO - 2025-05-13 15:16:33 --> Router Class Initialized
INFO - 2025-05-13 15:16:33 --> Output Class Initialized
INFO - 2025-05-13 15:16:33 --> Security Class Initialized
DEBUG - 2025-05-13 15:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 15:16:33 --> Input Class Initialized
INFO - 2025-05-13 15:16:33 --> Language Class Initialized
INFO - 2025-05-13 15:16:33 --> Loader Class Initialized
INFO - 2025-05-13 15:16:33 --> Helper loaded: url_helper
INFO - 2025-05-13 15:16:33 --> Helper loaded: form_helper
INFO - 2025-05-13 15:16:33 --> Database Driver Class Initialized
DEBUG - 2025-05-13 15:16:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 15:16:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 15:16:33 --> Controller Class Initialized
INFO - 2025-05-13 15:16:33 --> Model "User_model" initialized
INFO - 2025-05-13 15:16:33 --> Model "Workout_model" initialized
INFO - 2025-05-13 15:16:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 15:16:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 15:16:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-13 15:16:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 15:16:33 --> Final output sent to browser
DEBUG - 2025-05-13 15:16:33 --> Total execution time: 0.0901
INFO - 2025-05-13 15:16:37 --> Config Class Initialized
INFO - 2025-05-13 15:16:37 --> Hooks Class Initialized
DEBUG - 2025-05-13 15:16:37 --> UTF-8 Support Enabled
INFO - 2025-05-13 15:16:37 --> Utf8 Class Initialized
INFO - 2025-05-13 15:16:37 --> URI Class Initialized
INFO - 2025-05-13 15:16:37 --> Router Class Initialized
INFO - 2025-05-13 15:16:37 --> Output Class Initialized
INFO - 2025-05-13 15:16:37 --> Security Class Initialized
DEBUG - 2025-05-13 15:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 15:16:37 --> Input Class Initialized
INFO - 2025-05-13 15:16:37 --> Language Class Initialized
INFO - 2025-05-13 15:16:37 --> Loader Class Initialized
INFO - 2025-05-13 15:16:37 --> Helper loaded: url_helper
INFO - 2025-05-13 15:16:37 --> Helper loaded: form_helper
INFO - 2025-05-13 15:16:37 --> Database Driver Class Initialized
DEBUG - 2025-05-13 15:16:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 15:16:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 15:16:37 --> Controller Class Initialized
INFO - 2025-05-13 15:16:37 --> Model "User_model" initialized
INFO - 2025-05-13 15:16:37 --> Model "Workout_model" initialized
INFO - 2025-05-13 15:16:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 15:16:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 15:16:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 15:16:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 15:16:37 --> Final output sent to browser
DEBUG - 2025-05-13 15:16:37 --> Total execution time: 0.0984
INFO - 2025-05-13 15:16:39 --> Config Class Initialized
INFO - 2025-05-13 15:16:39 --> Hooks Class Initialized
DEBUG - 2025-05-13 15:16:39 --> UTF-8 Support Enabled
INFO - 2025-05-13 15:16:39 --> Utf8 Class Initialized
INFO - 2025-05-13 15:16:39 --> URI Class Initialized
INFO - 2025-05-13 15:16:39 --> Router Class Initialized
INFO - 2025-05-13 15:16:39 --> Output Class Initialized
INFO - 2025-05-13 15:16:39 --> Security Class Initialized
DEBUG - 2025-05-13 15:16:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 15:16:39 --> Input Class Initialized
INFO - 2025-05-13 15:16:39 --> Language Class Initialized
INFO - 2025-05-13 15:16:39 --> Loader Class Initialized
INFO - 2025-05-13 15:16:39 --> Helper loaded: url_helper
INFO - 2025-05-13 15:16:39 --> Helper loaded: form_helper
INFO - 2025-05-13 15:16:39 --> Database Driver Class Initialized
DEBUG - 2025-05-13 15:16:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 15:16:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 15:16:39 --> Controller Class Initialized
INFO - 2025-05-13 15:16:39 --> Model "Workout_model" initialized
INFO - 2025-05-13 15:16:39 --> Model "User_model" initialized
INFO - 2025-05-13 15:16:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 15:16:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 15:16:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-13 15:16:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 15:16:39 --> Final output sent to browser
DEBUG - 2025-05-13 15:16:39 --> Total execution time: 0.1489
INFO - 2025-05-13 15:17:38 --> Config Class Initialized
INFO - 2025-05-13 15:17:38 --> Hooks Class Initialized
DEBUG - 2025-05-13 15:17:38 --> UTF-8 Support Enabled
INFO - 2025-05-13 15:17:38 --> Utf8 Class Initialized
INFO - 2025-05-13 15:17:38 --> URI Class Initialized
INFO - 2025-05-13 15:17:38 --> Router Class Initialized
INFO - 2025-05-13 15:17:38 --> Output Class Initialized
INFO - 2025-05-13 15:17:38 --> Security Class Initialized
DEBUG - 2025-05-13 15:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 15:17:38 --> Input Class Initialized
INFO - 2025-05-13 15:17:38 --> Language Class Initialized
INFO - 2025-05-13 15:17:38 --> Loader Class Initialized
INFO - 2025-05-13 15:17:38 --> Helper loaded: url_helper
INFO - 2025-05-13 15:17:38 --> Helper loaded: form_helper
INFO - 2025-05-13 15:17:38 --> Database Driver Class Initialized
DEBUG - 2025-05-13 15:17:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 15:17:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 15:17:38 --> Controller Class Initialized
INFO - 2025-05-13 15:17:38 --> Model "Workout_model" initialized
INFO - 2025-05-13 15:17:38 --> Model "User_model" initialized
INFO - 2025-05-13 15:17:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 15:17:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 15:17:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-13 15:17:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 15:17:38 --> Final output sent to browser
DEBUG - 2025-05-13 15:17:38 --> Total execution time: 0.0691
INFO - 2025-05-13 15:17:42 --> Config Class Initialized
INFO - 2025-05-13 15:17:42 --> Hooks Class Initialized
DEBUG - 2025-05-13 15:17:42 --> UTF-8 Support Enabled
INFO - 2025-05-13 15:17:42 --> Utf8 Class Initialized
INFO - 2025-05-13 15:17:42 --> URI Class Initialized
INFO - 2025-05-13 15:17:42 --> Router Class Initialized
INFO - 2025-05-13 15:17:42 --> Output Class Initialized
INFO - 2025-05-13 15:17:42 --> Security Class Initialized
DEBUG - 2025-05-13 15:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 15:17:42 --> Input Class Initialized
INFO - 2025-05-13 15:17:42 --> Language Class Initialized
INFO - 2025-05-13 15:17:42 --> Loader Class Initialized
INFO - 2025-05-13 15:17:42 --> Helper loaded: url_helper
INFO - 2025-05-13 15:17:42 --> Helper loaded: form_helper
INFO - 2025-05-13 15:17:42 --> Database Driver Class Initialized
DEBUG - 2025-05-13 15:17:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 15:17:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 15:17:42 --> Controller Class Initialized
INFO - 2025-05-13 15:17:42 --> Model "User_model" initialized
INFO - 2025-05-13 15:17:42 --> Model "Community_model" initialized
INFO - 2025-05-13 15:17:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 15:17:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 15:17:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\community/index.php
INFO - 2025-05-13 15:17:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 15:17:42 --> Final output sent to browser
DEBUG - 2025-05-13 15:17:42 --> Total execution time: 0.0765
INFO - 2025-05-13 15:20:51 --> Config Class Initialized
INFO - 2025-05-13 15:20:51 --> Hooks Class Initialized
DEBUG - 2025-05-13 15:20:51 --> UTF-8 Support Enabled
INFO - 2025-05-13 15:20:51 --> Utf8 Class Initialized
INFO - 2025-05-13 15:20:51 --> URI Class Initialized
INFO - 2025-05-13 15:20:51 --> Router Class Initialized
INFO - 2025-05-13 15:20:51 --> Output Class Initialized
INFO - 2025-05-13 15:20:51 --> Security Class Initialized
DEBUG - 2025-05-13 15:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 15:20:51 --> Input Class Initialized
INFO - 2025-05-13 15:20:51 --> Language Class Initialized
INFO - 2025-05-13 15:20:51 --> Loader Class Initialized
INFO - 2025-05-13 15:20:51 --> Helper loaded: url_helper
INFO - 2025-05-13 15:20:51 --> Helper loaded: form_helper
INFO - 2025-05-13 15:20:51 --> Database Driver Class Initialized
DEBUG - 2025-05-13 15:20:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 15:20:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 15:20:51 --> Controller Class Initialized
INFO - 2025-05-13 15:20:51 --> Model "User_model" initialized
INFO - 2025-05-13 15:20:51 --> Model "Community_model" initialized
INFO - 2025-05-13 15:20:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 15:20:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 15:20:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\community/index.php
INFO - 2025-05-13 15:20:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 15:20:51 --> Final output sent to browser
DEBUG - 2025-05-13 15:20:51 --> Total execution time: 0.0921
INFO - 2025-05-13 15:22:04 --> Config Class Initialized
INFO - 2025-05-13 15:22:04 --> Hooks Class Initialized
DEBUG - 2025-05-13 15:22:04 --> UTF-8 Support Enabled
INFO - 2025-05-13 15:22:04 --> Utf8 Class Initialized
INFO - 2025-05-13 15:22:04 --> URI Class Initialized
INFO - 2025-05-13 15:22:04 --> Router Class Initialized
INFO - 2025-05-13 15:22:04 --> Output Class Initialized
INFO - 2025-05-13 15:22:04 --> Security Class Initialized
DEBUG - 2025-05-13 15:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 15:22:04 --> Input Class Initialized
INFO - 2025-05-13 15:22:04 --> Language Class Initialized
INFO - 2025-05-13 15:22:04 --> Loader Class Initialized
INFO - 2025-05-13 15:22:04 --> Helper loaded: url_helper
INFO - 2025-05-13 15:22:04 --> Helper loaded: form_helper
INFO - 2025-05-13 15:22:04 --> Database Driver Class Initialized
DEBUG - 2025-05-13 15:22:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 15:22:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 15:22:04 --> Controller Class Initialized
INFO - 2025-05-13 15:22:04 --> Model "User_model" initialized
INFO - 2025-05-13 15:22:04 --> Model "Community_model" initialized
INFO - 2025-05-13 15:22:04 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 15:22:04 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 15:22:04 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\community/index.php
INFO - 2025-05-13 15:22:04 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 15:22:04 --> Final output sent to browser
DEBUG - 2025-05-13 15:22:04 --> Total execution time: 0.0767
INFO - 2025-05-13 15:22:15 --> Config Class Initialized
INFO - 2025-05-13 15:22:15 --> Hooks Class Initialized
DEBUG - 2025-05-13 15:22:15 --> UTF-8 Support Enabled
INFO - 2025-05-13 15:22:15 --> Utf8 Class Initialized
INFO - 2025-05-13 15:22:15 --> URI Class Initialized
INFO - 2025-05-13 15:22:15 --> Router Class Initialized
INFO - 2025-05-13 15:22:15 --> Output Class Initialized
INFO - 2025-05-13 15:22:15 --> Security Class Initialized
DEBUG - 2025-05-13 15:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 15:22:15 --> Input Class Initialized
INFO - 2025-05-13 15:22:15 --> Language Class Initialized
INFO - 2025-05-13 15:22:15 --> Loader Class Initialized
INFO - 2025-05-13 15:22:15 --> Helper loaded: url_helper
INFO - 2025-05-13 15:22:15 --> Helper loaded: form_helper
INFO - 2025-05-13 15:22:16 --> Database Driver Class Initialized
DEBUG - 2025-05-13 15:22:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 15:22:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 15:22:16 --> Controller Class Initialized
INFO - 2025-05-13 15:22:16 --> Model "Workout_model" initialized
INFO - 2025-05-13 15:22:16 --> Model "User_model" initialized
INFO - 2025-05-13 15:22:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 15:22:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 15:22:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-13 15:22:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 15:22:16 --> Final output sent to browser
DEBUG - 2025-05-13 15:22:16 --> Total execution time: 0.0876
INFO - 2025-05-13 15:22:22 --> Config Class Initialized
INFO - 2025-05-13 15:22:22 --> Hooks Class Initialized
DEBUG - 2025-05-13 15:22:22 --> UTF-8 Support Enabled
INFO - 2025-05-13 15:22:22 --> Utf8 Class Initialized
INFO - 2025-05-13 15:22:22 --> URI Class Initialized
INFO - 2025-05-13 15:22:22 --> Router Class Initialized
INFO - 2025-05-13 15:22:22 --> Output Class Initialized
INFO - 2025-05-13 15:22:22 --> Security Class Initialized
DEBUG - 2025-05-13 15:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 15:22:22 --> Input Class Initialized
INFO - 2025-05-13 15:22:22 --> Language Class Initialized
INFO - 2025-05-13 15:22:22 --> Loader Class Initialized
INFO - 2025-05-13 15:22:22 --> Helper loaded: url_helper
INFO - 2025-05-13 15:22:22 --> Helper loaded: form_helper
INFO - 2025-05-13 15:22:22 --> Database Driver Class Initialized
DEBUG - 2025-05-13 15:22:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 15:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 15:22:22 --> Controller Class Initialized
INFO - 2025-05-13 15:22:22 --> Model "User_model" initialized
INFO - 2025-05-13 15:22:22 --> Model "Workout_model" initialized
INFO - 2025-05-13 15:22:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 15:22:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 15:22:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-13 15:22:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 15:22:22 --> Final output sent to browser
DEBUG - 2025-05-13 15:22:22 --> Total execution time: 0.0856
INFO - 2025-05-13 15:22:23 --> Config Class Initialized
INFO - 2025-05-13 15:22:23 --> Hooks Class Initialized
DEBUG - 2025-05-13 15:22:23 --> UTF-8 Support Enabled
INFO - 2025-05-13 15:22:23 --> Utf8 Class Initialized
INFO - 2025-05-13 15:22:23 --> URI Class Initialized
INFO - 2025-05-13 15:22:23 --> Router Class Initialized
INFO - 2025-05-13 15:22:23 --> Output Class Initialized
INFO - 2025-05-13 15:22:23 --> Security Class Initialized
DEBUG - 2025-05-13 15:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 15:22:23 --> Input Class Initialized
INFO - 2025-05-13 15:22:23 --> Language Class Initialized
INFO - 2025-05-13 15:22:23 --> Loader Class Initialized
INFO - 2025-05-13 15:22:23 --> Helper loaded: url_helper
INFO - 2025-05-13 15:22:23 --> Helper loaded: form_helper
INFO - 2025-05-13 15:22:23 --> Database Driver Class Initialized
DEBUG - 2025-05-13 15:22:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 15:22:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 15:22:23 --> Controller Class Initialized
INFO - 2025-05-13 15:22:23 --> Model "User_model" initialized
INFO - 2025-05-13 15:22:23 --> Model "Workout_model" initialized
INFO - 2025-05-13 15:22:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 15:22:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 15:22:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 15:22:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 15:22:23 --> Final output sent to browser
DEBUG - 2025-05-13 15:22:23 --> Total execution time: 0.0653
INFO - 2025-05-13 15:22:24 --> Config Class Initialized
INFO - 2025-05-13 15:22:24 --> Hooks Class Initialized
DEBUG - 2025-05-13 15:22:24 --> UTF-8 Support Enabled
INFO - 2025-05-13 15:22:24 --> Utf8 Class Initialized
INFO - 2025-05-13 15:22:24 --> URI Class Initialized
INFO - 2025-05-13 15:22:24 --> Router Class Initialized
INFO - 2025-05-13 15:22:24 --> Output Class Initialized
INFO - 2025-05-13 15:22:24 --> Security Class Initialized
DEBUG - 2025-05-13 15:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 15:22:24 --> Input Class Initialized
INFO - 2025-05-13 15:22:24 --> Language Class Initialized
INFO - 2025-05-13 15:22:24 --> Loader Class Initialized
INFO - 2025-05-13 15:22:24 --> Helper loaded: url_helper
INFO - 2025-05-13 15:22:24 --> Helper loaded: form_helper
INFO - 2025-05-13 15:22:25 --> Database Driver Class Initialized
DEBUG - 2025-05-13 15:22:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 15:22:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 15:22:25 --> Controller Class Initialized
INFO - 2025-05-13 15:22:25 --> Model "User_model" initialized
INFO - 2025-05-13 15:22:25 --> Model "Workout_model" initialized
INFO - 2025-05-13 15:22:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 15:22:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 15:22:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-13 15:22:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 15:22:25 --> Final output sent to browser
DEBUG - 2025-05-13 15:22:25 --> Total execution time: 0.0756
INFO - 2025-05-13 15:22:27 --> Config Class Initialized
INFO - 2025-05-13 15:22:27 --> Hooks Class Initialized
DEBUG - 2025-05-13 15:22:27 --> UTF-8 Support Enabled
INFO - 2025-05-13 15:22:27 --> Utf8 Class Initialized
INFO - 2025-05-13 15:22:27 --> URI Class Initialized
INFO - 2025-05-13 15:22:27 --> Router Class Initialized
INFO - 2025-05-13 15:22:27 --> Output Class Initialized
INFO - 2025-05-13 15:22:27 --> Security Class Initialized
DEBUG - 2025-05-13 15:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 15:22:27 --> Input Class Initialized
INFO - 2025-05-13 15:22:27 --> Language Class Initialized
INFO - 2025-05-13 15:22:27 --> Loader Class Initialized
INFO - 2025-05-13 15:22:27 --> Helper loaded: url_helper
INFO - 2025-05-13 15:22:27 --> Helper loaded: form_helper
INFO - 2025-05-13 15:22:27 --> Database Driver Class Initialized
DEBUG - 2025-05-13 15:22:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 15:22:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 15:22:27 --> Controller Class Initialized
INFO - 2025-05-13 15:22:27 --> Model "Workout_model" initialized
INFO - 2025-05-13 15:22:27 --> Model "User_model" initialized
INFO - 2025-05-13 15:22:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 15:22:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 15:22:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-13 15:22:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 15:22:27 --> Final output sent to browser
DEBUG - 2025-05-13 15:22:27 --> Total execution time: 0.0749
INFO - 2025-05-13 15:22:28 --> Config Class Initialized
INFO - 2025-05-13 15:22:28 --> Hooks Class Initialized
DEBUG - 2025-05-13 15:22:28 --> UTF-8 Support Enabled
INFO - 2025-05-13 15:22:28 --> Utf8 Class Initialized
INFO - 2025-05-13 15:22:28 --> URI Class Initialized
INFO - 2025-05-13 15:22:28 --> Router Class Initialized
INFO - 2025-05-13 15:22:28 --> Output Class Initialized
INFO - 2025-05-13 15:22:28 --> Security Class Initialized
DEBUG - 2025-05-13 15:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 15:22:28 --> Input Class Initialized
INFO - 2025-05-13 15:22:28 --> Language Class Initialized
INFO - 2025-05-13 15:22:28 --> Loader Class Initialized
INFO - 2025-05-13 15:22:28 --> Helper loaded: url_helper
INFO - 2025-05-13 15:22:28 --> Helper loaded: form_helper
INFO - 2025-05-13 15:22:28 --> Database Driver Class Initialized
DEBUG - 2025-05-13 15:22:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 15:22:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 15:22:28 --> Controller Class Initialized
INFO - 2025-05-13 15:22:28 --> Model "User_model" initialized
INFO - 2025-05-13 15:22:28 --> Model "Workout_model" initialized
INFO - 2025-05-13 15:22:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 15:22:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 15:22:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 15:22:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 15:22:28 --> Final output sent to browser
DEBUG - 2025-05-13 15:22:28 --> Total execution time: 0.0751
INFO - 2025-05-13 15:22:36 --> Config Class Initialized
INFO - 2025-05-13 15:22:36 --> Hooks Class Initialized
DEBUG - 2025-05-13 15:22:36 --> UTF-8 Support Enabled
INFO - 2025-05-13 15:22:36 --> Utf8 Class Initialized
INFO - 2025-05-13 15:22:36 --> URI Class Initialized
INFO - 2025-05-13 15:22:36 --> Router Class Initialized
INFO - 2025-05-13 15:22:36 --> Output Class Initialized
INFO - 2025-05-13 15:22:36 --> Security Class Initialized
DEBUG - 2025-05-13 15:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 15:22:36 --> Input Class Initialized
INFO - 2025-05-13 15:22:36 --> Language Class Initialized
INFO - 2025-05-13 15:22:36 --> Loader Class Initialized
INFO - 2025-05-13 15:22:36 --> Helper loaded: url_helper
INFO - 2025-05-13 15:22:36 --> Helper loaded: form_helper
INFO - 2025-05-13 15:22:36 --> Database Driver Class Initialized
DEBUG - 2025-05-13 15:22:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 15:22:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 15:22:36 --> Controller Class Initialized
INFO - 2025-05-13 15:22:36 --> Model "User_model" initialized
INFO - 2025-05-13 15:22:36 --> Model "Workout_model" initialized
INFO - 2025-05-13 15:22:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 15:22:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 15:22:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-13 15:22:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 15:22:36 --> Final output sent to browser
DEBUG - 2025-05-13 15:22:36 --> Total execution time: 0.0823
INFO - 2025-05-13 15:22:56 --> Config Class Initialized
INFO - 2025-05-13 15:22:56 --> Hooks Class Initialized
DEBUG - 2025-05-13 15:22:56 --> UTF-8 Support Enabled
INFO - 2025-05-13 15:22:56 --> Utf8 Class Initialized
INFO - 2025-05-13 15:22:56 --> URI Class Initialized
INFO - 2025-05-13 15:22:56 --> Router Class Initialized
INFO - 2025-05-13 15:22:56 --> Output Class Initialized
INFO - 2025-05-13 15:22:56 --> Security Class Initialized
DEBUG - 2025-05-13 15:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 15:22:56 --> Input Class Initialized
INFO - 2025-05-13 15:22:56 --> Language Class Initialized
INFO - 2025-05-13 15:22:56 --> Loader Class Initialized
INFO - 2025-05-13 15:22:56 --> Helper loaded: url_helper
INFO - 2025-05-13 15:22:56 --> Helper loaded: form_helper
INFO - 2025-05-13 15:22:56 --> Database Driver Class Initialized
DEBUG - 2025-05-13 15:22:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 15:22:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 15:22:56 --> Controller Class Initialized
INFO - 2025-05-13 15:22:56 --> Model "User_model" initialized
INFO - 2025-05-13 15:22:56 --> Model "Workout_model" initialized
INFO - 2025-05-13 15:22:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 15:22:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 15:22:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-13 15:22:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 15:22:56 --> Final output sent to browser
DEBUG - 2025-05-13 15:22:56 --> Total execution time: 0.0993
INFO - 2025-05-13 15:22:59 --> Config Class Initialized
INFO - 2025-05-13 15:22:59 --> Hooks Class Initialized
DEBUG - 2025-05-13 15:22:59 --> UTF-8 Support Enabled
INFO - 2025-05-13 15:22:59 --> Utf8 Class Initialized
INFO - 2025-05-13 15:22:59 --> URI Class Initialized
INFO - 2025-05-13 15:22:59 --> Router Class Initialized
INFO - 2025-05-13 15:22:59 --> Output Class Initialized
INFO - 2025-05-13 15:22:59 --> Security Class Initialized
DEBUG - 2025-05-13 15:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 15:22:59 --> Input Class Initialized
INFO - 2025-05-13 15:22:59 --> Language Class Initialized
INFO - 2025-05-13 15:22:59 --> Loader Class Initialized
INFO - 2025-05-13 15:22:59 --> Helper loaded: url_helper
INFO - 2025-05-13 15:22:59 --> Helper loaded: form_helper
INFO - 2025-05-13 15:22:59 --> Database Driver Class Initialized
DEBUG - 2025-05-13 15:22:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 15:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 15:22:59 --> Controller Class Initialized
INFO - 2025-05-13 15:22:59 --> Model "User_model" initialized
INFO - 2025-05-13 15:22:59 --> Model "Community_model" initialized
INFO - 2025-05-13 15:22:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 15:22:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 15:22:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\community/index.php
INFO - 2025-05-13 15:22:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 15:22:59 --> Final output sent to browser
DEBUG - 2025-05-13 15:22:59 --> Total execution time: 0.0934
INFO - 2025-05-13 15:24:11 --> Config Class Initialized
INFO - 2025-05-13 15:24:11 --> Hooks Class Initialized
DEBUG - 2025-05-13 15:24:11 --> UTF-8 Support Enabled
INFO - 2025-05-13 15:24:11 --> Utf8 Class Initialized
INFO - 2025-05-13 15:24:11 --> URI Class Initialized
INFO - 2025-05-13 15:24:11 --> Router Class Initialized
INFO - 2025-05-13 15:24:11 --> Output Class Initialized
INFO - 2025-05-13 15:24:11 --> Security Class Initialized
DEBUG - 2025-05-13 15:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 15:24:11 --> Input Class Initialized
INFO - 2025-05-13 15:24:11 --> Language Class Initialized
INFO - 2025-05-13 15:24:11 --> Loader Class Initialized
INFO - 2025-05-13 15:24:11 --> Helper loaded: url_helper
INFO - 2025-05-13 15:24:11 --> Helper loaded: form_helper
INFO - 2025-05-13 15:24:11 --> Database Driver Class Initialized
DEBUG - 2025-05-13 15:24:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 15:24:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 15:24:11 --> Controller Class Initialized
INFO - 2025-05-13 15:24:11 --> Model "User_model" initialized
INFO - 2025-05-13 15:24:11 --> Model "Community_model" initialized
INFO - 2025-05-13 15:24:11 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 15:24:11 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 15:24:11 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\community/index.php
INFO - 2025-05-13 15:24:11 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 15:24:11 --> Final output sent to browser
DEBUG - 2025-05-13 15:24:11 --> Total execution time: 0.0902
INFO - 2025-05-13 15:25:14 --> Config Class Initialized
INFO - 2025-05-13 15:25:14 --> Hooks Class Initialized
DEBUG - 2025-05-13 15:25:14 --> UTF-8 Support Enabled
INFO - 2025-05-13 15:25:14 --> Utf8 Class Initialized
INFO - 2025-05-13 15:25:14 --> URI Class Initialized
INFO - 2025-05-13 15:25:14 --> Router Class Initialized
INFO - 2025-05-13 15:25:14 --> Output Class Initialized
INFO - 2025-05-13 15:25:14 --> Security Class Initialized
DEBUG - 2025-05-13 15:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 15:25:14 --> Input Class Initialized
INFO - 2025-05-13 15:25:14 --> Language Class Initialized
INFO - 2025-05-13 15:25:14 --> Loader Class Initialized
INFO - 2025-05-13 15:25:14 --> Helper loaded: url_helper
INFO - 2025-05-13 15:25:14 --> Helper loaded: form_helper
INFO - 2025-05-13 15:25:14 --> Database Driver Class Initialized
DEBUG - 2025-05-13 15:25:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 15:25:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 15:25:15 --> Controller Class Initialized
INFO - 2025-05-13 15:25:15 --> Model "User_model" initialized
INFO - 2025-05-13 15:25:15 --> Model "Community_model" initialized
INFO - 2025-05-13 15:25:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 15:25:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 15:25:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\community/index.php
INFO - 2025-05-13 15:25:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 15:25:15 --> Final output sent to browser
DEBUG - 2025-05-13 15:25:15 --> Total execution time: 0.0956
INFO - 2025-05-13 15:25:35 --> Config Class Initialized
INFO - 2025-05-13 15:25:35 --> Hooks Class Initialized
DEBUG - 2025-05-13 15:25:35 --> UTF-8 Support Enabled
INFO - 2025-05-13 15:25:35 --> Utf8 Class Initialized
INFO - 2025-05-13 15:25:35 --> URI Class Initialized
INFO - 2025-05-13 15:25:35 --> Router Class Initialized
INFO - 2025-05-13 15:25:35 --> Output Class Initialized
INFO - 2025-05-13 15:25:35 --> Security Class Initialized
DEBUG - 2025-05-13 15:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 15:25:35 --> Input Class Initialized
INFO - 2025-05-13 15:25:35 --> Language Class Initialized
INFO - 2025-05-13 15:25:35 --> Loader Class Initialized
INFO - 2025-05-13 15:25:35 --> Helper loaded: url_helper
INFO - 2025-05-13 15:25:35 --> Helper loaded: form_helper
INFO - 2025-05-13 15:25:35 --> Database Driver Class Initialized
DEBUG - 2025-05-13 15:25:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 15:25:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 15:25:35 --> Controller Class Initialized
INFO - 2025-05-13 15:25:35 --> Model "User_model" initialized
INFO - 2025-05-13 15:25:35 --> Model "Community_model" initialized
INFO - 2025-05-13 15:25:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 15:25:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 15:25:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\community/index.php
INFO - 2025-05-13 15:25:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 15:25:35 --> Final output sent to browser
DEBUG - 2025-05-13 15:25:35 --> Total execution time: 0.0895
INFO - 2025-05-13 15:29:05 --> Config Class Initialized
INFO - 2025-05-13 15:29:05 --> Hooks Class Initialized
DEBUG - 2025-05-13 15:29:05 --> UTF-8 Support Enabled
INFO - 2025-05-13 15:29:05 --> Utf8 Class Initialized
INFO - 2025-05-13 15:29:05 --> URI Class Initialized
INFO - 2025-05-13 15:29:05 --> Router Class Initialized
INFO - 2025-05-13 15:29:05 --> Output Class Initialized
INFO - 2025-05-13 15:29:05 --> Security Class Initialized
DEBUG - 2025-05-13 15:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 15:29:05 --> Input Class Initialized
INFO - 2025-05-13 15:29:05 --> Language Class Initialized
INFO - 2025-05-13 15:29:05 --> Loader Class Initialized
INFO - 2025-05-13 15:29:05 --> Helper loaded: url_helper
INFO - 2025-05-13 15:29:05 --> Helper loaded: form_helper
INFO - 2025-05-13 15:29:05 --> Database Driver Class Initialized
DEBUG - 2025-05-13 15:29:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 15:29:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 15:29:05 --> Controller Class Initialized
INFO - 2025-05-13 15:29:05 --> Model "User_model" initialized
INFO - 2025-05-13 15:29:05 --> Model "Community_model" initialized
INFO - 2025-05-13 15:29:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 15:29:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 15:29:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\community/index.php
INFO - 2025-05-13 15:29:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 15:29:05 --> Final output sent to browser
DEBUG - 2025-05-13 15:29:05 --> Total execution time: 0.0909
INFO - 2025-05-13 15:30:06 --> Config Class Initialized
INFO - 2025-05-13 15:30:06 --> Hooks Class Initialized
DEBUG - 2025-05-13 15:30:06 --> UTF-8 Support Enabled
INFO - 2025-05-13 15:30:06 --> Utf8 Class Initialized
INFO - 2025-05-13 15:30:06 --> URI Class Initialized
INFO - 2025-05-13 15:30:06 --> Router Class Initialized
INFO - 2025-05-13 15:30:06 --> Output Class Initialized
INFO - 2025-05-13 15:30:06 --> Security Class Initialized
DEBUG - 2025-05-13 15:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 15:30:06 --> Input Class Initialized
INFO - 2025-05-13 15:30:06 --> Language Class Initialized
INFO - 2025-05-13 15:30:06 --> Loader Class Initialized
INFO - 2025-05-13 15:30:06 --> Helper loaded: url_helper
INFO - 2025-05-13 15:30:06 --> Helper loaded: form_helper
INFO - 2025-05-13 15:30:06 --> Database Driver Class Initialized
DEBUG - 2025-05-13 15:30:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 15:30:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 15:30:06 --> Controller Class Initialized
INFO - 2025-05-13 15:30:06 --> Model "User_model" initialized
INFO - 2025-05-13 15:30:06 --> Model "Community_model" initialized
INFO - 2025-05-13 15:30:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 15:30:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 15:30:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\community/index.php
INFO - 2025-05-13 15:30:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 15:30:06 --> Final output sent to browser
DEBUG - 2025-05-13 15:30:06 --> Total execution time: 0.0739
INFO - 2025-05-13 15:37:13 --> Config Class Initialized
INFO - 2025-05-13 15:37:13 --> Hooks Class Initialized
DEBUG - 2025-05-13 15:37:13 --> UTF-8 Support Enabled
INFO - 2025-05-13 15:37:13 --> Utf8 Class Initialized
INFO - 2025-05-13 15:37:13 --> URI Class Initialized
INFO - 2025-05-13 15:37:13 --> Router Class Initialized
INFO - 2025-05-13 15:37:13 --> Output Class Initialized
INFO - 2025-05-13 15:37:13 --> Security Class Initialized
DEBUG - 2025-05-13 15:37:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 15:37:13 --> Input Class Initialized
INFO - 2025-05-13 15:37:13 --> Language Class Initialized
INFO - 2025-05-13 15:37:13 --> Loader Class Initialized
INFO - 2025-05-13 15:37:13 --> Helper loaded: url_helper
INFO - 2025-05-13 15:37:13 --> Helper loaded: form_helper
INFO - 2025-05-13 15:37:13 --> Database Driver Class Initialized
DEBUG - 2025-05-13 15:37:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 15:37:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 15:37:13 --> Controller Class Initialized
INFO - 2025-05-13 15:37:13 --> Model "User_model" initialized
INFO - 2025-05-13 15:37:13 --> Model "Community_model" initialized
INFO - 2025-05-13 15:37:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 15:37:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 15:37:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\community/index.php
INFO - 2025-05-13 15:37:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 15:37:13 --> Final output sent to browser
DEBUG - 2025-05-13 15:37:13 --> Total execution time: 0.0724
INFO - 2025-05-13 15:38:11 --> Config Class Initialized
INFO - 2025-05-13 15:38:11 --> Hooks Class Initialized
DEBUG - 2025-05-13 15:38:11 --> UTF-8 Support Enabled
INFO - 2025-05-13 15:38:11 --> Utf8 Class Initialized
INFO - 2025-05-13 15:38:11 --> URI Class Initialized
INFO - 2025-05-13 15:38:11 --> Router Class Initialized
INFO - 2025-05-13 15:38:11 --> Output Class Initialized
INFO - 2025-05-13 15:38:11 --> Security Class Initialized
DEBUG - 2025-05-13 15:38:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 15:38:11 --> Input Class Initialized
INFO - 2025-05-13 15:38:11 --> Language Class Initialized
INFO - 2025-05-13 15:38:11 --> Loader Class Initialized
INFO - 2025-05-13 15:38:11 --> Helper loaded: url_helper
INFO - 2025-05-13 15:38:11 --> Helper loaded: form_helper
INFO - 2025-05-13 15:38:11 --> Database Driver Class Initialized
DEBUG - 2025-05-13 15:38:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 15:38:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 15:38:11 --> Controller Class Initialized
INFO - 2025-05-13 15:38:11 --> Model "User_model" initialized
INFO - 2025-05-13 15:38:11 --> Model "Community_model" initialized
INFO - 2025-05-13 15:38:11 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 15:38:11 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 15:38:11 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\community/index.php
INFO - 2025-05-13 15:38:11 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 15:38:11 --> Final output sent to browser
DEBUG - 2025-05-13 15:38:11 --> Total execution time: 0.0843
INFO - 2025-05-13 15:39:53 --> Config Class Initialized
INFO - 2025-05-13 15:39:53 --> Hooks Class Initialized
DEBUG - 2025-05-13 15:39:53 --> UTF-8 Support Enabled
INFO - 2025-05-13 15:39:53 --> Utf8 Class Initialized
INFO - 2025-05-13 15:39:53 --> URI Class Initialized
INFO - 2025-05-13 15:39:53 --> Router Class Initialized
INFO - 2025-05-13 15:39:53 --> Output Class Initialized
INFO - 2025-05-13 15:39:53 --> Security Class Initialized
DEBUG - 2025-05-13 15:39:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 15:39:53 --> Input Class Initialized
INFO - 2025-05-13 15:39:53 --> Language Class Initialized
INFO - 2025-05-13 15:39:53 --> Loader Class Initialized
INFO - 2025-05-13 15:39:53 --> Helper loaded: url_helper
INFO - 2025-05-13 15:39:53 --> Helper loaded: form_helper
INFO - 2025-05-13 15:39:53 --> Database Driver Class Initialized
DEBUG - 2025-05-13 15:39:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 15:39:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 15:39:53 --> Controller Class Initialized
INFO - 2025-05-13 15:39:53 --> Model "User_model" initialized
INFO - 2025-05-13 15:39:53 --> Model "Community_model" initialized
INFO - 2025-05-13 15:39:53 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 15:39:53 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 15:39:53 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\community/index.php
INFO - 2025-05-13 15:39:53 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 15:39:53 --> Final output sent to browser
DEBUG - 2025-05-13 15:39:53 --> Total execution time: 0.0933
INFO - 2025-05-13 15:47:27 --> Config Class Initialized
INFO - 2025-05-13 15:47:27 --> Hooks Class Initialized
DEBUG - 2025-05-13 15:47:27 --> UTF-8 Support Enabled
INFO - 2025-05-13 15:47:27 --> Utf8 Class Initialized
INFO - 2025-05-13 15:47:27 --> URI Class Initialized
INFO - 2025-05-13 15:47:27 --> Router Class Initialized
INFO - 2025-05-13 15:47:27 --> Output Class Initialized
INFO - 2025-05-13 15:47:27 --> Security Class Initialized
DEBUG - 2025-05-13 15:47:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 15:47:27 --> Input Class Initialized
INFO - 2025-05-13 15:47:27 --> Language Class Initialized
INFO - 2025-05-13 15:47:27 --> Loader Class Initialized
INFO - 2025-05-13 15:47:27 --> Helper loaded: url_helper
INFO - 2025-05-13 15:47:27 --> Helper loaded: form_helper
INFO - 2025-05-13 15:47:27 --> Database Driver Class Initialized
DEBUG - 2025-05-13 15:47:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 15:47:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 15:47:27 --> Controller Class Initialized
INFO - 2025-05-13 15:47:27 --> Model "User_model" initialized
INFO - 2025-05-13 15:47:27 --> Model "Community_model" initialized
INFO - 2025-05-13 15:47:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\community/index.php
INFO - 2025-05-13 15:47:27 --> Final output sent to browser
DEBUG - 2025-05-13 15:47:27 --> Total execution time: 0.0874
INFO - 2025-05-13 15:47:41 --> Config Class Initialized
INFO - 2025-05-13 15:47:41 --> Hooks Class Initialized
DEBUG - 2025-05-13 15:47:41 --> UTF-8 Support Enabled
INFO - 2025-05-13 15:47:41 --> Utf8 Class Initialized
INFO - 2025-05-13 15:47:41 --> URI Class Initialized
INFO - 2025-05-13 15:47:41 --> Router Class Initialized
INFO - 2025-05-13 15:47:41 --> Output Class Initialized
INFO - 2025-05-13 15:47:41 --> Security Class Initialized
DEBUG - 2025-05-13 15:47:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 15:47:41 --> Input Class Initialized
INFO - 2025-05-13 15:47:41 --> Language Class Initialized
INFO - 2025-05-13 15:47:41 --> Loader Class Initialized
INFO - 2025-05-13 15:47:41 --> Helper loaded: url_helper
INFO - 2025-05-13 15:47:41 --> Helper loaded: form_helper
INFO - 2025-05-13 15:47:41 --> Database Driver Class Initialized
DEBUG - 2025-05-13 15:47:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 15:47:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 15:47:41 --> Controller Class Initialized
INFO - 2025-05-13 15:47:41 --> Model "User_model" initialized
INFO - 2025-05-13 15:47:41 --> Model "Community_model" initialized
INFO - 2025-05-13 15:47:41 --> Final output sent to browser
DEBUG - 2025-05-13 15:47:41 --> Total execution time: 0.0751
INFO - 2025-05-13 15:47:48 --> Config Class Initialized
INFO - 2025-05-13 15:47:48 --> Hooks Class Initialized
DEBUG - 2025-05-13 15:47:48 --> UTF-8 Support Enabled
INFO - 2025-05-13 15:47:48 --> Utf8 Class Initialized
INFO - 2025-05-13 15:47:48 --> URI Class Initialized
INFO - 2025-05-13 15:47:48 --> Router Class Initialized
INFO - 2025-05-13 15:47:48 --> Output Class Initialized
INFO - 2025-05-13 15:47:48 --> Security Class Initialized
DEBUG - 2025-05-13 15:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 15:47:48 --> Input Class Initialized
INFO - 2025-05-13 15:47:48 --> Language Class Initialized
INFO - 2025-05-13 15:47:48 --> Loader Class Initialized
INFO - 2025-05-13 15:47:48 --> Helper loaded: url_helper
INFO - 2025-05-13 15:47:48 --> Helper loaded: form_helper
INFO - 2025-05-13 15:47:48 --> Database Driver Class Initialized
DEBUG - 2025-05-13 15:47:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 15:47:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 15:47:48 --> Controller Class Initialized
INFO - 2025-05-13 15:47:48 --> Model "User_model" initialized
INFO - 2025-05-13 15:47:48 --> Model "Community_model" initialized
INFO - 2025-05-13 15:47:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\community/index.php
INFO - 2025-05-13 15:47:48 --> Final output sent to browser
DEBUG - 2025-05-13 15:47:48 --> Total execution time: 0.0681
INFO - 2025-05-13 15:47:51 --> Config Class Initialized
INFO - 2025-05-13 15:47:51 --> Hooks Class Initialized
DEBUG - 2025-05-13 15:47:51 --> UTF-8 Support Enabled
INFO - 2025-05-13 15:47:51 --> Utf8 Class Initialized
INFO - 2025-05-13 15:47:51 --> URI Class Initialized
INFO - 2025-05-13 15:47:51 --> Router Class Initialized
INFO - 2025-05-13 15:47:51 --> Output Class Initialized
INFO - 2025-05-13 15:47:51 --> Security Class Initialized
DEBUG - 2025-05-13 15:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 15:47:51 --> Input Class Initialized
INFO - 2025-05-13 15:47:51 --> Language Class Initialized
INFO - 2025-05-13 15:47:51 --> Loader Class Initialized
INFO - 2025-05-13 15:47:51 --> Helper loaded: url_helper
INFO - 2025-05-13 15:47:51 --> Helper loaded: form_helper
INFO - 2025-05-13 15:47:51 --> Database Driver Class Initialized
DEBUG - 2025-05-13 15:47:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 15:47:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 15:47:51 --> Controller Class Initialized
INFO - 2025-05-13 15:47:51 --> Model "User_model" initialized
INFO - 2025-05-13 15:47:51 --> Model "Community_model" initialized
INFO - 2025-05-13 15:47:51 --> Final output sent to browser
DEBUG - 2025-05-13 15:47:51 --> Total execution time: 0.0575
INFO - 2025-05-13 15:47:58 --> Config Class Initialized
INFO - 2025-05-13 15:47:58 --> Hooks Class Initialized
DEBUG - 2025-05-13 15:47:58 --> UTF-8 Support Enabled
INFO - 2025-05-13 15:47:58 --> Utf8 Class Initialized
INFO - 2025-05-13 15:47:58 --> URI Class Initialized
INFO - 2025-05-13 15:47:58 --> Router Class Initialized
INFO - 2025-05-13 15:47:58 --> Output Class Initialized
INFO - 2025-05-13 15:47:58 --> Security Class Initialized
DEBUG - 2025-05-13 15:47:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 15:47:58 --> Input Class Initialized
INFO - 2025-05-13 15:47:58 --> Language Class Initialized
INFO - 2025-05-13 15:47:58 --> Loader Class Initialized
INFO - 2025-05-13 15:47:58 --> Helper loaded: url_helper
INFO - 2025-05-13 15:47:58 --> Helper loaded: form_helper
INFO - 2025-05-13 15:47:58 --> Database Driver Class Initialized
DEBUG - 2025-05-13 15:47:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 15:47:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 15:47:58 --> Controller Class Initialized
INFO - 2025-05-13 15:47:58 --> Model "User_model" initialized
INFO - 2025-05-13 15:47:58 --> Model "Community_model" initialized
INFO - 2025-05-13 15:47:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\community/index.php
INFO - 2025-05-13 15:47:58 --> Final output sent to browser
DEBUG - 2025-05-13 15:47:58 --> Total execution time: 0.0716
INFO - 2025-05-13 15:48:02 --> Config Class Initialized
INFO - 2025-05-13 15:48:02 --> Hooks Class Initialized
DEBUG - 2025-05-13 15:48:02 --> UTF-8 Support Enabled
INFO - 2025-05-13 15:48:02 --> Utf8 Class Initialized
INFO - 2025-05-13 15:48:02 --> URI Class Initialized
INFO - 2025-05-13 15:48:02 --> Router Class Initialized
INFO - 2025-05-13 15:48:02 --> Output Class Initialized
INFO - 2025-05-13 15:48:02 --> Security Class Initialized
DEBUG - 2025-05-13 15:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 15:48:02 --> Input Class Initialized
INFO - 2025-05-13 15:48:02 --> Language Class Initialized
INFO - 2025-05-13 15:48:02 --> Loader Class Initialized
INFO - 2025-05-13 15:48:02 --> Helper loaded: url_helper
INFO - 2025-05-13 15:48:02 --> Helper loaded: form_helper
INFO - 2025-05-13 15:48:02 --> Database Driver Class Initialized
DEBUG - 2025-05-13 15:48:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 15:48:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 15:48:02 --> Controller Class Initialized
INFO - 2025-05-13 15:48:02 --> Model "User_model" initialized
INFO - 2025-05-13 15:48:02 --> Model "Community_model" initialized
INFO - 2025-05-13 15:48:02 --> Final output sent to browser
DEBUG - 2025-05-13 15:48:02 --> Total execution time: 0.0726
INFO - 2025-05-13 15:50:30 --> Config Class Initialized
INFO - 2025-05-13 15:50:30 --> Hooks Class Initialized
DEBUG - 2025-05-13 15:50:30 --> UTF-8 Support Enabled
INFO - 2025-05-13 15:50:30 --> Utf8 Class Initialized
INFO - 2025-05-13 15:50:30 --> URI Class Initialized
INFO - 2025-05-13 15:50:30 --> Router Class Initialized
INFO - 2025-05-13 15:50:30 --> Output Class Initialized
INFO - 2025-05-13 15:50:30 --> Security Class Initialized
DEBUG - 2025-05-13 15:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 15:50:30 --> Input Class Initialized
INFO - 2025-05-13 15:50:30 --> Language Class Initialized
INFO - 2025-05-13 15:50:30 --> Loader Class Initialized
INFO - 2025-05-13 15:50:30 --> Helper loaded: url_helper
INFO - 2025-05-13 15:50:30 --> Helper loaded: form_helper
INFO - 2025-05-13 15:50:30 --> Database Driver Class Initialized
DEBUG - 2025-05-13 15:50:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 15:50:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 15:50:30 --> Controller Class Initialized
INFO - 2025-05-13 15:50:30 --> Model "User_model" initialized
INFO - 2025-05-13 15:50:30 --> Model "Community_model" initialized
INFO - 2025-05-13 15:50:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 15:50:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 15:50:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\community/index.php
INFO - 2025-05-13 15:50:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 15:50:30 --> Final output sent to browser
DEBUG - 2025-05-13 15:50:30 --> Total execution time: 0.0831
INFO - 2025-05-13 15:50:34 --> Config Class Initialized
INFO - 2025-05-13 15:50:34 --> Hooks Class Initialized
DEBUG - 2025-05-13 15:50:34 --> UTF-8 Support Enabled
INFO - 2025-05-13 15:50:34 --> Utf8 Class Initialized
INFO - 2025-05-13 15:50:34 --> URI Class Initialized
INFO - 2025-05-13 15:50:34 --> Router Class Initialized
INFO - 2025-05-13 15:50:34 --> Output Class Initialized
INFO - 2025-05-13 15:50:34 --> Security Class Initialized
DEBUG - 2025-05-13 15:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 15:50:34 --> Input Class Initialized
INFO - 2025-05-13 15:50:34 --> Language Class Initialized
INFO - 2025-05-13 15:50:34 --> Loader Class Initialized
INFO - 2025-05-13 15:50:34 --> Helper loaded: url_helper
INFO - 2025-05-13 15:50:34 --> Helper loaded: form_helper
INFO - 2025-05-13 15:50:34 --> Database Driver Class Initialized
DEBUG - 2025-05-13 15:50:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 15:50:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 15:50:34 --> Controller Class Initialized
INFO - 2025-05-13 15:50:34 --> Model "User_model" initialized
INFO - 2025-05-13 15:50:34 --> Model "Community_model" initialized
INFO - 2025-05-13 15:50:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\community/discussion.php
INFO - 2025-05-13 15:50:34 --> Final output sent to browser
DEBUG - 2025-05-13 15:50:34 --> Total execution time: 0.1042
INFO - 2025-05-13 15:50:41 --> Config Class Initialized
INFO - 2025-05-13 15:50:41 --> Hooks Class Initialized
DEBUG - 2025-05-13 15:50:41 --> UTF-8 Support Enabled
INFO - 2025-05-13 15:50:41 --> Utf8 Class Initialized
INFO - 2025-05-13 15:50:41 --> URI Class Initialized
INFO - 2025-05-13 15:50:41 --> Router Class Initialized
INFO - 2025-05-13 15:50:41 --> Output Class Initialized
INFO - 2025-05-13 15:50:41 --> Security Class Initialized
DEBUG - 2025-05-13 15:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 15:50:41 --> Input Class Initialized
INFO - 2025-05-13 15:50:41 --> Language Class Initialized
INFO - 2025-05-13 15:50:41 --> Loader Class Initialized
INFO - 2025-05-13 15:50:41 --> Helper loaded: url_helper
INFO - 2025-05-13 15:50:41 --> Helper loaded: form_helper
INFO - 2025-05-13 15:50:41 --> Database Driver Class Initialized
DEBUG - 2025-05-13 15:50:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 15:50:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 15:50:41 --> Controller Class Initialized
INFO - 2025-05-13 15:50:41 --> Model "User_model" initialized
INFO - 2025-05-13 15:50:41 --> Model "Community_model" initialized
INFO - 2025-05-13 15:50:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 15:50:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 15:50:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\community/index.php
INFO - 2025-05-13 15:50:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 15:50:41 --> Final output sent to browser
DEBUG - 2025-05-13 15:50:41 --> Total execution time: 0.1036
INFO - 2025-05-13 15:51:30 --> Config Class Initialized
INFO - 2025-05-13 15:51:30 --> Hooks Class Initialized
DEBUG - 2025-05-13 15:51:30 --> UTF-8 Support Enabled
INFO - 2025-05-13 15:51:30 --> Utf8 Class Initialized
INFO - 2025-05-13 15:51:30 --> URI Class Initialized
INFO - 2025-05-13 15:51:30 --> Router Class Initialized
INFO - 2025-05-13 15:51:30 --> Output Class Initialized
INFO - 2025-05-13 15:51:30 --> Security Class Initialized
DEBUG - 2025-05-13 15:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 15:51:30 --> Input Class Initialized
INFO - 2025-05-13 15:51:30 --> Language Class Initialized
INFO - 2025-05-13 15:51:30 --> Loader Class Initialized
INFO - 2025-05-13 15:51:30 --> Helper loaded: url_helper
INFO - 2025-05-13 15:51:30 --> Helper loaded: form_helper
INFO - 2025-05-13 15:51:30 --> Database Driver Class Initialized
DEBUG - 2025-05-13 15:51:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 15:51:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 15:51:30 --> Controller Class Initialized
INFO - 2025-05-13 15:51:30 --> Model "User_model" initialized
INFO - 2025-05-13 15:51:30 --> Model "Community_model" initialized
INFO - 2025-05-13 15:51:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 15:51:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 15:51:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\community/index.php
INFO - 2025-05-13 15:51:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 15:51:30 --> Final output sent to browser
DEBUG - 2025-05-13 15:51:30 --> Total execution time: 0.0728
INFO - 2025-05-13 15:54:46 --> Config Class Initialized
INFO - 2025-05-13 15:54:46 --> Hooks Class Initialized
DEBUG - 2025-05-13 15:54:46 --> UTF-8 Support Enabled
INFO - 2025-05-13 15:54:46 --> Utf8 Class Initialized
INFO - 2025-05-13 15:54:46 --> URI Class Initialized
INFO - 2025-05-13 15:54:46 --> Router Class Initialized
INFO - 2025-05-13 15:54:46 --> Output Class Initialized
INFO - 2025-05-13 15:54:46 --> Security Class Initialized
DEBUG - 2025-05-13 15:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 15:54:46 --> Input Class Initialized
INFO - 2025-05-13 15:54:46 --> Language Class Initialized
INFO - 2025-05-13 15:54:46 --> Loader Class Initialized
INFO - 2025-05-13 15:54:46 --> Helper loaded: url_helper
INFO - 2025-05-13 15:54:46 --> Helper loaded: form_helper
INFO - 2025-05-13 15:54:46 --> Database Driver Class Initialized
DEBUG - 2025-05-13 15:54:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 15:54:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 15:54:46 --> Controller Class Initialized
INFO - 2025-05-13 15:54:46 --> Model "User_model" initialized
INFO - 2025-05-13 15:54:46 --> Model "Community_model" initialized
INFO - 2025-05-13 15:54:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 15:54:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 15:54:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\community/index.php
INFO - 2025-05-13 15:54:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 15:54:46 --> Final output sent to browser
DEBUG - 2025-05-13 15:54:46 --> Total execution time: 0.1005
INFO - 2025-05-13 15:54:48 --> Config Class Initialized
INFO - 2025-05-13 15:54:48 --> Hooks Class Initialized
DEBUG - 2025-05-13 15:54:48 --> UTF-8 Support Enabled
INFO - 2025-05-13 15:54:48 --> Utf8 Class Initialized
INFO - 2025-05-13 15:54:48 --> URI Class Initialized
INFO - 2025-05-13 15:54:48 --> Router Class Initialized
INFO - 2025-05-13 15:54:48 --> Output Class Initialized
INFO - 2025-05-13 15:54:48 --> Security Class Initialized
DEBUG - 2025-05-13 15:54:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 15:54:48 --> Input Class Initialized
INFO - 2025-05-13 15:54:48 --> Language Class Initialized
INFO - 2025-05-13 15:54:48 --> Loader Class Initialized
INFO - 2025-05-13 15:54:48 --> Helper loaded: url_helper
INFO - 2025-05-13 15:54:48 --> Helper loaded: form_helper
INFO - 2025-05-13 15:54:48 --> Database Driver Class Initialized
DEBUG - 2025-05-13 15:54:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 15:54:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 15:54:48 --> Controller Class Initialized
INFO - 2025-05-13 15:54:48 --> Model "User_model" initialized
INFO - 2025-05-13 15:54:48 --> Model "Community_model" initialized
INFO - 2025-05-13 15:54:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 15:54:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 15:54:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\community/index.php
INFO - 2025-05-13 15:54:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 15:54:48 --> Final output sent to browser
DEBUG - 2025-05-13 15:54:48 --> Total execution time: 0.0811
INFO - 2025-05-13 15:54:49 --> Config Class Initialized
INFO - 2025-05-13 15:54:49 --> Hooks Class Initialized
DEBUG - 2025-05-13 15:54:49 --> UTF-8 Support Enabled
INFO - 2025-05-13 15:54:49 --> Utf8 Class Initialized
INFO - 2025-05-13 15:54:49 --> URI Class Initialized
INFO - 2025-05-13 15:54:49 --> Router Class Initialized
INFO - 2025-05-13 15:54:49 --> Output Class Initialized
INFO - 2025-05-13 15:54:49 --> Security Class Initialized
DEBUG - 2025-05-13 15:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 15:54:49 --> Input Class Initialized
INFO - 2025-05-13 15:54:49 --> Language Class Initialized
INFO - 2025-05-13 15:54:49 --> Loader Class Initialized
INFO - 2025-05-13 15:54:49 --> Helper loaded: url_helper
INFO - 2025-05-13 15:54:49 --> Helper loaded: form_helper
INFO - 2025-05-13 15:54:49 --> Database Driver Class Initialized
DEBUG - 2025-05-13 15:54:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 15:54:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 15:54:49 --> Controller Class Initialized
INFO - 2025-05-13 15:54:49 --> Model "User_model" initialized
INFO - 2025-05-13 15:54:49 --> Model "Community_model" initialized
INFO - 2025-05-13 15:54:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 15:54:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 15:54:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\community/index.php
INFO - 2025-05-13 15:54:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 15:54:49 --> Final output sent to browser
DEBUG - 2025-05-13 15:54:49 --> Total execution time: 0.0785
INFO - 2025-05-13 15:58:17 --> Config Class Initialized
INFO - 2025-05-13 15:58:17 --> Hooks Class Initialized
DEBUG - 2025-05-13 15:58:17 --> UTF-8 Support Enabled
INFO - 2025-05-13 15:58:17 --> Utf8 Class Initialized
INFO - 2025-05-13 15:58:17 --> URI Class Initialized
INFO - 2025-05-13 15:58:17 --> Router Class Initialized
INFO - 2025-05-13 15:58:17 --> Output Class Initialized
INFO - 2025-05-13 15:58:17 --> Security Class Initialized
DEBUG - 2025-05-13 15:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 15:58:17 --> Input Class Initialized
INFO - 2025-05-13 15:58:17 --> Language Class Initialized
INFO - 2025-05-13 15:58:17 --> Loader Class Initialized
INFO - 2025-05-13 15:58:17 --> Helper loaded: url_helper
INFO - 2025-05-13 15:58:17 --> Helper loaded: form_helper
INFO - 2025-05-13 15:58:17 --> Database Driver Class Initialized
DEBUG - 2025-05-13 15:58:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 15:58:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 15:58:17 --> Controller Class Initialized
INFO - 2025-05-13 15:58:17 --> Model "User_model" initialized
INFO - 2025-05-13 15:58:17 --> Model "Community_model" initialized
INFO - 2025-05-13 15:58:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 15:58:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 15:58:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\community/index.php
INFO - 2025-05-13 15:58:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 15:58:17 --> Final output sent to browser
DEBUG - 2025-05-13 15:58:17 --> Total execution time: 0.0668
INFO - 2025-05-13 16:01:08 --> Config Class Initialized
INFO - 2025-05-13 16:01:08 --> Hooks Class Initialized
DEBUG - 2025-05-13 16:01:08 --> UTF-8 Support Enabled
INFO - 2025-05-13 16:01:08 --> Utf8 Class Initialized
INFO - 2025-05-13 16:01:08 --> URI Class Initialized
INFO - 2025-05-13 16:01:08 --> Router Class Initialized
INFO - 2025-05-13 16:01:08 --> Output Class Initialized
INFO - 2025-05-13 16:01:08 --> Security Class Initialized
DEBUG - 2025-05-13 16:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 16:01:08 --> Input Class Initialized
INFO - 2025-05-13 16:01:08 --> Language Class Initialized
INFO - 2025-05-13 16:01:08 --> Loader Class Initialized
INFO - 2025-05-13 16:01:08 --> Helper loaded: url_helper
INFO - 2025-05-13 16:01:08 --> Helper loaded: form_helper
INFO - 2025-05-13 16:01:08 --> Database Driver Class Initialized
DEBUG - 2025-05-13 16:01:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 16:01:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 16:01:08 --> Controller Class Initialized
INFO - 2025-05-13 16:01:08 --> Model "User_model" initialized
INFO - 2025-05-13 16:01:08 --> Model "Community_model" initialized
INFO - 2025-05-13 16:01:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 16:01:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 16:01:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\community/index.php
INFO - 2025-05-13 16:01:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 16:01:08 --> Final output sent to browser
DEBUG - 2025-05-13 16:01:08 --> Total execution time: 0.0888
INFO - 2025-05-13 16:04:34 --> Config Class Initialized
INFO - 2025-05-13 16:04:34 --> Hooks Class Initialized
DEBUG - 2025-05-13 16:04:34 --> UTF-8 Support Enabled
INFO - 2025-05-13 16:04:34 --> Utf8 Class Initialized
INFO - 2025-05-13 16:04:34 --> URI Class Initialized
INFO - 2025-05-13 16:04:34 --> Router Class Initialized
INFO - 2025-05-13 16:04:34 --> Output Class Initialized
INFO - 2025-05-13 16:04:34 --> Security Class Initialized
DEBUG - 2025-05-13 16:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 16:04:34 --> Input Class Initialized
INFO - 2025-05-13 16:04:34 --> Language Class Initialized
INFO - 2025-05-13 16:04:34 --> Loader Class Initialized
INFO - 2025-05-13 16:04:34 --> Helper loaded: url_helper
INFO - 2025-05-13 16:04:34 --> Helper loaded: form_helper
INFO - 2025-05-13 16:04:34 --> Database Driver Class Initialized
DEBUG - 2025-05-13 16:04:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 16:04:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 16:04:34 --> Controller Class Initialized
INFO - 2025-05-13 16:04:34 --> Model "User_model" initialized
INFO - 2025-05-13 16:04:34 --> Model "Community_model" initialized
INFO - 2025-05-13 16:04:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 16:04:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 16:04:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\community/index.php
INFO - 2025-05-13 16:04:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 16:04:34 --> Final output sent to browser
DEBUG - 2025-05-13 16:04:34 --> Total execution time: 0.1023
INFO - 2025-05-13 16:04:42 --> Config Class Initialized
INFO - 2025-05-13 16:04:42 --> Hooks Class Initialized
DEBUG - 2025-05-13 16:04:42 --> UTF-8 Support Enabled
INFO - 2025-05-13 16:04:42 --> Utf8 Class Initialized
INFO - 2025-05-13 16:04:42 --> URI Class Initialized
INFO - 2025-05-13 16:04:42 --> Router Class Initialized
INFO - 2025-05-13 16:04:42 --> Output Class Initialized
INFO - 2025-05-13 16:04:42 --> Security Class Initialized
DEBUG - 2025-05-13 16:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 16:04:42 --> Input Class Initialized
INFO - 2025-05-13 16:04:42 --> Language Class Initialized
INFO - 2025-05-13 16:04:42 --> Loader Class Initialized
INFO - 2025-05-13 16:04:42 --> Helper loaded: url_helper
INFO - 2025-05-13 16:04:42 --> Helper loaded: form_helper
INFO - 2025-05-13 16:04:42 --> Database Driver Class Initialized
DEBUG - 2025-05-13 16:04:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 16:04:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 16:04:42 --> Controller Class Initialized
INFO - 2025-05-13 16:04:42 --> Model "User_model" initialized
INFO - 2025-05-13 16:04:43 --> Model "Workout_model" initialized
INFO - 2025-05-13 16:04:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 16:04:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 16:04:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 16:04:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 16:04:43 --> Final output sent to browser
DEBUG - 2025-05-13 16:04:43 --> Total execution time: 0.0863
INFO - 2025-05-13 16:04:45 --> Config Class Initialized
INFO - 2025-05-13 16:04:45 --> Hooks Class Initialized
DEBUG - 2025-05-13 16:04:45 --> UTF-8 Support Enabled
INFO - 2025-05-13 16:04:45 --> Utf8 Class Initialized
INFO - 2025-05-13 16:04:45 --> URI Class Initialized
INFO - 2025-05-13 16:04:45 --> Router Class Initialized
INFO - 2025-05-13 16:04:45 --> Output Class Initialized
INFO - 2025-05-13 16:04:45 --> Security Class Initialized
DEBUG - 2025-05-13 16:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 16:04:45 --> Input Class Initialized
INFO - 2025-05-13 16:04:45 --> Language Class Initialized
INFO - 2025-05-13 16:04:45 --> Loader Class Initialized
INFO - 2025-05-13 16:04:45 --> Helper loaded: url_helper
INFO - 2025-05-13 16:04:45 --> Helper loaded: form_helper
INFO - 2025-05-13 16:04:45 --> Database Driver Class Initialized
DEBUG - 2025-05-13 16:04:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 16:04:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 16:04:45 --> Controller Class Initialized
INFO - 2025-05-13 16:04:45 --> Model "User_model" initialized
INFO - 2025-05-13 16:04:45 --> Model "Workout_model" initialized
INFO - 2025-05-13 16:04:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 16:04:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 16:04:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-13 16:04:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 16:04:45 --> Final output sent to browser
DEBUG - 2025-05-13 16:04:45 --> Total execution time: 0.0864
INFO - 2025-05-13 16:04:47 --> Config Class Initialized
INFO - 2025-05-13 16:04:47 --> Hooks Class Initialized
DEBUG - 2025-05-13 16:04:47 --> UTF-8 Support Enabled
INFO - 2025-05-13 16:04:47 --> Utf8 Class Initialized
INFO - 2025-05-13 16:04:47 --> URI Class Initialized
INFO - 2025-05-13 16:04:47 --> Router Class Initialized
INFO - 2025-05-13 16:04:47 --> Output Class Initialized
INFO - 2025-05-13 16:04:47 --> Security Class Initialized
DEBUG - 2025-05-13 16:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 16:04:47 --> Input Class Initialized
INFO - 2025-05-13 16:04:47 --> Language Class Initialized
INFO - 2025-05-13 16:04:47 --> Loader Class Initialized
INFO - 2025-05-13 16:04:47 --> Helper loaded: url_helper
INFO - 2025-05-13 16:04:47 --> Helper loaded: form_helper
INFO - 2025-05-13 16:04:47 --> Database Driver Class Initialized
DEBUG - 2025-05-13 16:04:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 16:04:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 16:04:47 --> Controller Class Initialized
INFO - 2025-05-13 16:04:47 --> Model "Workout_model" initialized
INFO - 2025-05-13 16:04:47 --> Model "User_model" initialized
INFO - 2025-05-13 16:04:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 16:04:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 16:04:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-13 16:04:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 16:04:47 --> Final output sent to browser
DEBUG - 2025-05-13 16:04:47 --> Total execution time: 0.0855
INFO - 2025-05-13 16:04:48 --> Config Class Initialized
INFO - 2025-05-13 16:04:48 --> Hooks Class Initialized
DEBUG - 2025-05-13 16:04:48 --> UTF-8 Support Enabled
INFO - 2025-05-13 16:04:48 --> Utf8 Class Initialized
INFO - 2025-05-13 16:04:48 --> URI Class Initialized
INFO - 2025-05-13 16:04:48 --> Router Class Initialized
INFO - 2025-05-13 16:04:48 --> Output Class Initialized
INFO - 2025-05-13 16:04:48 --> Security Class Initialized
DEBUG - 2025-05-13 16:04:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 16:04:48 --> Input Class Initialized
INFO - 2025-05-13 16:04:48 --> Language Class Initialized
INFO - 2025-05-13 16:04:48 --> Loader Class Initialized
INFO - 2025-05-13 16:04:48 --> Helper loaded: url_helper
INFO - 2025-05-13 16:04:48 --> Helper loaded: form_helper
INFO - 2025-05-13 16:04:48 --> Database Driver Class Initialized
DEBUG - 2025-05-13 16:04:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 16:04:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 16:04:48 --> Controller Class Initialized
INFO - 2025-05-13 16:04:48 --> Model "User_model" initialized
INFO - 2025-05-13 16:04:48 --> Model "Workout_model" initialized
INFO - 2025-05-13 16:04:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 16:04:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 16:04:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-13 16:04:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 16:04:48 --> Final output sent to browser
DEBUG - 2025-05-13 16:04:48 --> Total execution time: 0.1143
INFO - 2025-05-13 16:04:50 --> Config Class Initialized
INFO - 2025-05-13 16:04:50 --> Hooks Class Initialized
DEBUG - 2025-05-13 16:04:50 --> UTF-8 Support Enabled
INFO - 2025-05-13 16:04:50 --> Utf8 Class Initialized
INFO - 2025-05-13 16:04:50 --> URI Class Initialized
INFO - 2025-05-13 16:04:50 --> Router Class Initialized
INFO - 2025-05-13 16:04:50 --> Output Class Initialized
INFO - 2025-05-13 16:04:50 --> Security Class Initialized
DEBUG - 2025-05-13 16:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 16:04:50 --> Input Class Initialized
INFO - 2025-05-13 16:04:50 --> Language Class Initialized
INFO - 2025-05-13 16:04:50 --> Loader Class Initialized
INFO - 2025-05-13 16:04:50 --> Helper loaded: url_helper
INFO - 2025-05-13 16:04:50 --> Helper loaded: form_helper
INFO - 2025-05-13 16:04:50 --> Database Driver Class Initialized
DEBUG - 2025-05-13 16:04:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 16:04:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 16:04:50 --> Controller Class Initialized
INFO - 2025-05-13 16:04:50 --> Model "User_model" initialized
INFO - 2025-05-13 16:04:50 --> Model "Workout_model" initialized
INFO - 2025-05-13 16:04:50 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 16:04:50 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 16:04:50 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 16:04:50 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 16:04:50 --> Final output sent to browser
DEBUG - 2025-05-13 16:04:50 --> Total execution time: 0.0736
INFO - 2025-05-13 16:05:12 --> Config Class Initialized
INFO - 2025-05-13 16:05:12 --> Hooks Class Initialized
DEBUG - 2025-05-13 16:05:12 --> UTF-8 Support Enabled
INFO - 2025-05-13 16:05:12 --> Utf8 Class Initialized
INFO - 2025-05-13 16:05:12 --> URI Class Initialized
INFO - 2025-05-13 16:05:12 --> Router Class Initialized
INFO - 2025-05-13 16:05:12 --> Output Class Initialized
INFO - 2025-05-13 16:05:12 --> Security Class Initialized
DEBUG - 2025-05-13 16:05:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 16:05:12 --> Input Class Initialized
INFO - 2025-05-13 16:05:12 --> Language Class Initialized
INFO - 2025-05-13 16:05:12 --> Loader Class Initialized
INFO - 2025-05-13 16:05:12 --> Helper loaded: url_helper
INFO - 2025-05-13 16:05:12 --> Helper loaded: form_helper
INFO - 2025-05-13 16:05:12 --> Database Driver Class Initialized
DEBUG - 2025-05-13 16:05:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 16:05:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 16:05:12 --> Controller Class Initialized
INFO - 2025-05-13 16:05:12 --> Model "User_model" initialized
INFO - 2025-05-13 16:05:12 --> Model "Workout_model" initialized
INFO - 2025-05-13 16:05:12 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 16:05:12 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 16:05:12 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 16:05:12 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 16:05:12 --> Final output sent to browser
DEBUG - 2025-05-13 16:05:12 --> Total execution time: 0.0733
INFO - 2025-05-13 16:05:27 --> Config Class Initialized
INFO - 2025-05-13 16:05:27 --> Hooks Class Initialized
DEBUG - 2025-05-13 16:05:27 --> UTF-8 Support Enabled
INFO - 2025-05-13 16:05:27 --> Utf8 Class Initialized
INFO - 2025-05-13 16:05:27 --> URI Class Initialized
INFO - 2025-05-13 16:05:27 --> Router Class Initialized
INFO - 2025-05-13 16:05:27 --> Output Class Initialized
INFO - 2025-05-13 16:05:27 --> Security Class Initialized
DEBUG - 2025-05-13 16:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 16:05:27 --> Input Class Initialized
INFO - 2025-05-13 16:05:27 --> Language Class Initialized
INFO - 2025-05-13 16:05:27 --> Loader Class Initialized
INFO - 2025-05-13 16:05:27 --> Helper loaded: url_helper
INFO - 2025-05-13 16:05:27 --> Helper loaded: form_helper
INFO - 2025-05-13 16:05:27 --> Database Driver Class Initialized
DEBUG - 2025-05-13 16:05:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 16:05:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 16:05:27 --> Controller Class Initialized
INFO - 2025-05-13 16:05:27 --> Model "User_model" initialized
INFO - 2025-05-13 16:05:27 --> Model "Workout_model" initialized
INFO - 2025-05-13 16:05:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 16:05:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 16:05:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 16:05:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 16:05:27 --> Final output sent to browser
DEBUG - 2025-05-13 16:05:27 --> Total execution time: 0.1055
INFO - 2025-05-13 16:05:32 --> Config Class Initialized
INFO - 2025-05-13 16:05:32 --> Hooks Class Initialized
DEBUG - 2025-05-13 16:05:32 --> UTF-8 Support Enabled
INFO - 2025-05-13 16:05:32 --> Utf8 Class Initialized
INFO - 2025-05-13 16:05:32 --> URI Class Initialized
INFO - 2025-05-13 16:05:32 --> Router Class Initialized
INFO - 2025-05-13 16:05:32 --> Output Class Initialized
INFO - 2025-05-13 16:05:32 --> Security Class Initialized
DEBUG - 2025-05-13 16:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 16:05:32 --> Input Class Initialized
INFO - 2025-05-13 16:05:32 --> Language Class Initialized
INFO - 2025-05-13 16:05:32 --> Loader Class Initialized
INFO - 2025-05-13 16:05:32 --> Helper loaded: url_helper
INFO - 2025-05-13 16:05:32 --> Helper loaded: form_helper
INFO - 2025-05-13 16:05:32 --> Database Driver Class Initialized
DEBUG - 2025-05-13 16:05:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 16:05:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 16:05:32 --> Controller Class Initialized
INFO - 2025-05-13 16:05:32 --> Model "User_model" initialized
INFO - 2025-05-13 16:05:32 --> Model "Workout_model" initialized
INFO - 2025-05-13 16:05:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 16:05:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 16:05:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-13 16:05:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 16:05:32 --> Final output sent to browser
DEBUG - 2025-05-13 16:05:32 --> Total execution time: 0.0872
INFO - 2025-05-13 16:05:34 --> Config Class Initialized
INFO - 2025-05-13 16:05:34 --> Hooks Class Initialized
DEBUG - 2025-05-13 16:05:34 --> UTF-8 Support Enabled
INFO - 2025-05-13 16:05:34 --> Utf8 Class Initialized
INFO - 2025-05-13 16:05:34 --> URI Class Initialized
INFO - 2025-05-13 16:05:34 --> Router Class Initialized
INFO - 2025-05-13 16:05:34 --> Output Class Initialized
INFO - 2025-05-13 16:05:34 --> Security Class Initialized
DEBUG - 2025-05-13 16:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 16:05:34 --> Input Class Initialized
INFO - 2025-05-13 16:05:34 --> Language Class Initialized
INFO - 2025-05-13 16:05:34 --> Loader Class Initialized
INFO - 2025-05-13 16:05:34 --> Helper loaded: url_helper
INFO - 2025-05-13 16:05:34 --> Helper loaded: form_helper
INFO - 2025-05-13 16:05:34 --> Database Driver Class Initialized
DEBUG - 2025-05-13 16:05:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 16:05:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 16:05:34 --> Controller Class Initialized
INFO - 2025-05-13 16:05:34 --> Model "Workout_model" initialized
INFO - 2025-05-13 16:05:34 --> Model "User_model" initialized
INFO - 2025-05-13 16:05:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 16:05:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 16:05:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-13 16:05:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 16:05:34 --> Final output sent to browser
DEBUG - 2025-05-13 16:05:34 --> Total execution time: 0.0804
INFO - 2025-05-13 16:05:44 --> Config Class Initialized
INFO - 2025-05-13 16:05:44 --> Hooks Class Initialized
DEBUG - 2025-05-13 16:05:44 --> UTF-8 Support Enabled
INFO - 2025-05-13 16:05:44 --> Utf8 Class Initialized
INFO - 2025-05-13 16:05:44 --> URI Class Initialized
INFO - 2025-05-13 16:05:44 --> Router Class Initialized
INFO - 2025-05-13 16:05:44 --> Output Class Initialized
INFO - 2025-05-13 16:05:44 --> Security Class Initialized
DEBUG - 2025-05-13 16:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 16:05:44 --> Input Class Initialized
INFO - 2025-05-13 16:05:44 --> Language Class Initialized
INFO - 2025-05-13 16:05:44 --> Loader Class Initialized
INFO - 2025-05-13 16:05:44 --> Helper loaded: url_helper
INFO - 2025-05-13 16:05:44 --> Helper loaded: form_helper
INFO - 2025-05-13 16:05:44 --> Database Driver Class Initialized
DEBUG - 2025-05-13 16:05:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 16:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 16:05:44 --> Controller Class Initialized
INFO - 2025-05-13 16:05:44 --> Model "User_model" initialized
INFO - 2025-05-13 16:05:44 --> Model "Community_model" initialized
INFO - 2025-05-13 16:05:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 16:05:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 16:05:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\community/index.php
INFO - 2025-05-13 16:05:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 16:05:44 --> Final output sent to browser
DEBUG - 2025-05-13 16:05:44 --> Total execution time: 0.0959
INFO - 2025-05-13 16:37:19 --> Config Class Initialized
INFO - 2025-05-13 16:37:19 --> Hooks Class Initialized
DEBUG - 2025-05-13 16:37:19 --> UTF-8 Support Enabled
INFO - 2025-05-13 16:37:19 --> Utf8 Class Initialized
INFO - 2025-05-13 16:37:19 --> URI Class Initialized
INFO - 2025-05-13 16:37:19 --> Router Class Initialized
INFO - 2025-05-13 16:37:19 --> Output Class Initialized
INFO - 2025-05-13 16:37:19 --> Security Class Initialized
DEBUG - 2025-05-13 16:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 16:37:19 --> Input Class Initialized
INFO - 2025-05-13 16:37:19 --> Language Class Initialized
INFO - 2025-05-13 16:37:19 --> Loader Class Initialized
INFO - 2025-05-13 16:37:19 --> Helper loaded: url_helper
INFO - 2025-05-13 16:37:19 --> Helper loaded: form_helper
INFO - 2025-05-13 16:37:19 --> Database Driver Class Initialized
DEBUG - 2025-05-13 16:37:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 16:37:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 16:37:19 --> Controller Class Initialized
INFO - 2025-05-13 16:37:19 --> Model "User_model" initialized
INFO - 2025-05-13 16:37:19 --> Model "Community_model" initialized
INFO - 2025-05-13 16:37:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/community.php
INFO - 2025-05-13 16:37:19 --> Final output sent to browser
DEBUG - 2025-05-13 16:37:19 --> Total execution time: 0.0821
INFO - 2025-05-13 16:37:26 --> Config Class Initialized
INFO - 2025-05-13 16:37:26 --> Hooks Class Initialized
DEBUG - 2025-05-13 16:37:26 --> UTF-8 Support Enabled
INFO - 2025-05-13 16:37:26 --> Utf8 Class Initialized
INFO - 2025-05-13 16:37:26 --> URI Class Initialized
INFO - 2025-05-13 16:37:26 --> Router Class Initialized
INFO - 2025-05-13 16:37:26 --> Output Class Initialized
INFO - 2025-05-13 16:37:26 --> Security Class Initialized
DEBUG - 2025-05-13 16:37:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 16:37:26 --> Input Class Initialized
INFO - 2025-05-13 16:37:26 --> Language Class Initialized
INFO - 2025-05-13 16:37:26 --> Loader Class Initialized
INFO - 2025-05-13 16:37:26 --> Helper loaded: url_helper
INFO - 2025-05-13 16:37:26 --> Helper loaded: form_helper
INFO - 2025-05-13 16:37:26 --> Database Driver Class Initialized
DEBUG - 2025-05-13 16:37:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 16:37:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 16:37:26 --> Controller Class Initialized
INFO - 2025-05-13 16:37:26 --> Model "User_model" initialized
INFO - 2025-05-13 16:37:26 --> Model "Community_model" initialized
ERROR - 2025-05-13 16:37:26 --> Query error: Unknown column 'content' in 'field list' - Invalid query: INSERT INTO `posts` (`user_id`, `content`) VALUES ('2', 'bjkkjb')
INFO - 2025-05-13 16:37:26 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-13 16:38:31 --> Config Class Initialized
INFO - 2025-05-13 16:38:31 --> Hooks Class Initialized
DEBUG - 2025-05-13 16:38:31 --> UTF-8 Support Enabled
INFO - 2025-05-13 16:38:31 --> Utf8 Class Initialized
INFO - 2025-05-13 16:38:31 --> URI Class Initialized
INFO - 2025-05-13 16:38:31 --> Router Class Initialized
INFO - 2025-05-13 16:38:31 --> Output Class Initialized
INFO - 2025-05-13 16:38:31 --> Security Class Initialized
DEBUG - 2025-05-13 16:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 16:38:31 --> Input Class Initialized
INFO - 2025-05-13 16:38:31 --> Language Class Initialized
INFO - 2025-05-13 16:38:31 --> Loader Class Initialized
INFO - 2025-05-13 16:38:31 --> Helper loaded: url_helper
INFO - 2025-05-13 16:38:31 --> Helper loaded: form_helper
INFO - 2025-05-13 16:38:31 --> Database Driver Class Initialized
DEBUG - 2025-05-13 16:38:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 16:38:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 16:38:31 --> Controller Class Initialized
INFO - 2025-05-13 16:38:31 --> Model "User_model" initialized
INFO - 2025-05-13 16:38:31 --> Model "Community_model" initialized
INFO - 2025-05-13 16:38:31 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/community.php
INFO - 2025-05-13 16:38:31 --> Final output sent to browser
DEBUG - 2025-05-13 16:38:31 --> Total execution time: 0.0727
INFO - 2025-05-13 16:38:33 --> Config Class Initialized
INFO - 2025-05-13 16:38:33 --> Hooks Class Initialized
DEBUG - 2025-05-13 16:38:33 --> UTF-8 Support Enabled
INFO - 2025-05-13 16:38:33 --> Utf8 Class Initialized
INFO - 2025-05-13 16:38:33 --> URI Class Initialized
INFO - 2025-05-13 16:38:33 --> Router Class Initialized
INFO - 2025-05-13 16:38:33 --> Output Class Initialized
INFO - 2025-05-13 16:38:33 --> Security Class Initialized
DEBUG - 2025-05-13 16:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 16:38:33 --> Input Class Initialized
INFO - 2025-05-13 16:38:33 --> Language Class Initialized
INFO - 2025-05-13 16:38:33 --> Loader Class Initialized
INFO - 2025-05-13 16:38:33 --> Helper loaded: url_helper
INFO - 2025-05-13 16:38:33 --> Helper loaded: form_helper
INFO - 2025-05-13 16:38:33 --> Database Driver Class Initialized
DEBUG - 2025-05-13 16:38:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 16:38:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 16:38:33 --> Controller Class Initialized
INFO - 2025-05-13 16:38:33 --> Model "User_model" initialized
INFO - 2025-05-13 16:38:33 --> Model "Community_model" initialized
INFO - 2025-05-13 16:38:33 --> Config Class Initialized
INFO - 2025-05-13 16:38:33 --> Hooks Class Initialized
DEBUG - 2025-05-13 16:38:33 --> UTF-8 Support Enabled
INFO - 2025-05-13 16:38:33 --> Utf8 Class Initialized
INFO - 2025-05-13 16:38:33 --> URI Class Initialized
INFO - 2025-05-13 16:38:33 --> Router Class Initialized
INFO - 2025-05-13 16:38:33 --> Output Class Initialized
INFO - 2025-05-13 16:38:33 --> Security Class Initialized
DEBUG - 2025-05-13 16:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 16:38:33 --> Input Class Initialized
INFO - 2025-05-13 16:38:33 --> Language Class Initialized
INFO - 2025-05-13 16:38:33 --> Loader Class Initialized
INFO - 2025-05-13 16:38:33 --> Helper loaded: url_helper
INFO - 2025-05-13 16:38:33 --> Helper loaded: form_helper
INFO - 2025-05-13 16:38:33 --> Database Driver Class Initialized
DEBUG - 2025-05-13 16:38:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 16:38:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 16:38:33 --> Controller Class Initialized
INFO - 2025-05-13 16:38:33 --> Model "User_model" initialized
INFO - 2025-05-13 16:38:33 --> Model "Community_model" initialized
INFO - 2025-05-13 16:38:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/community.php
INFO - 2025-05-13 16:38:33 --> Final output sent to browser
DEBUG - 2025-05-13 16:38:33 --> Total execution time: 0.0704
INFO - 2025-05-13 16:38:43 --> Config Class Initialized
INFO - 2025-05-13 16:38:43 --> Hooks Class Initialized
DEBUG - 2025-05-13 16:38:43 --> UTF-8 Support Enabled
INFO - 2025-05-13 16:38:43 --> Utf8 Class Initialized
INFO - 2025-05-13 16:38:43 --> URI Class Initialized
INFO - 2025-05-13 16:38:43 --> Router Class Initialized
INFO - 2025-05-13 16:38:43 --> Output Class Initialized
INFO - 2025-05-13 16:38:43 --> Security Class Initialized
DEBUG - 2025-05-13 16:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 16:38:43 --> Input Class Initialized
INFO - 2025-05-13 16:38:43 --> Language Class Initialized
INFO - 2025-05-13 16:38:43 --> Loader Class Initialized
INFO - 2025-05-13 16:38:43 --> Helper loaded: url_helper
INFO - 2025-05-13 16:38:43 --> Helper loaded: form_helper
INFO - 2025-05-13 16:38:43 --> Database Driver Class Initialized
DEBUG - 2025-05-13 16:38:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 16:38:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 16:38:43 --> Controller Class Initialized
INFO - 2025-05-13 16:38:43 --> Model "User_model" initialized
INFO - 2025-05-13 16:38:43 --> Model "Workout_model" initialized
INFO - 2025-05-13 16:38:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 16:38:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 16:38:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 16:38:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 16:38:43 --> Final output sent to browser
DEBUG - 2025-05-13 16:38:43 --> Total execution time: 0.0929
INFO - 2025-05-13 16:38:48 --> Config Class Initialized
INFO - 2025-05-13 16:38:48 --> Hooks Class Initialized
DEBUG - 2025-05-13 16:38:48 --> UTF-8 Support Enabled
INFO - 2025-05-13 16:38:48 --> Utf8 Class Initialized
INFO - 2025-05-13 16:38:48 --> URI Class Initialized
INFO - 2025-05-13 16:38:48 --> Router Class Initialized
INFO - 2025-05-13 16:38:48 --> Output Class Initialized
INFO - 2025-05-13 16:38:48 --> Security Class Initialized
DEBUG - 2025-05-13 16:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 16:38:48 --> Input Class Initialized
INFO - 2025-05-13 16:38:48 --> Language Class Initialized
INFO - 2025-05-13 16:38:49 --> Loader Class Initialized
INFO - 2025-05-13 16:38:49 --> Helper loaded: url_helper
INFO - 2025-05-13 16:38:49 --> Helper loaded: form_helper
INFO - 2025-05-13 16:38:49 --> Database Driver Class Initialized
DEBUG - 2025-05-13 16:38:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 16:38:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 16:38:49 --> Controller Class Initialized
INFO - 2025-05-13 16:38:49 --> Model "User_model" initialized
INFO - 2025-05-13 16:38:49 --> Config Class Initialized
INFO - 2025-05-13 16:38:49 --> Hooks Class Initialized
DEBUG - 2025-05-13 16:38:49 --> UTF-8 Support Enabled
INFO - 2025-05-13 16:38:49 --> Utf8 Class Initialized
INFO - 2025-05-13 16:38:49 --> URI Class Initialized
INFO - 2025-05-13 16:38:49 --> Router Class Initialized
INFO - 2025-05-13 16:38:49 --> Output Class Initialized
INFO - 2025-05-13 16:38:49 --> Security Class Initialized
DEBUG - 2025-05-13 16:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 16:38:49 --> Input Class Initialized
INFO - 2025-05-13 16:38:49 --> Language Class Initialized
INFO - 2025-05-13 16:38:49 --> Loader Class Initialized
INFO - 2025-05-13 16:38:49 --> Helper loaded: url_helper
INFO - 2025-05-13 16:38:49 --> Helper loaded: form_helper
INFO - 2025-05-13 16:38:49 --> Database Driver Class Initialized
DEBUG - 2025-05-13 16:38:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 16:38:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 16:38:49 --> Controller Class Initialized
INFO - 2025-05-13 16:38:49 --> Model "User_model" initialized
INFO - 2025-05-13 16:38:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-13 16:38:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-13 16:38:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-13 16:38:49 --> Final output sent to browser
DEBUG - 2025-05-13 16:38:49 --> Total execution time: 0.0718
INFO - 2025-05-13 16:38:52 --> Config Class Initialized
INFO - 2025-05-13 16:38:52 --> Hooks Class Initialized
DEBUG - 2025-05-13 16:38:52 --> UTF-8 Support Enabled
INFO - 2025-05-13 16:38:52 --> Utf8 Class Initialized
INFO - 2025-05-13 16:38:52 --> URI Class Initialized
INFO - 2025-05-13 16:38:52 --> Router Class Initialized
INFO - 2025-05-13 16:38:52 --> Output Class Initialized
INFO - 2025-05-13 16:38:52 --> Security Class Initialized
DEBUG - 2025-05-13 16:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 16:38:52 --> Input Class Initialized
INFO - 2025-05-13 16:38:52 --> Language Class Initialized
INFO - 2025-05-13 16:38:52 --> Loader Class Initialized
INFO - 2025-05-13 16:38:52 --> Helper loaded: url_helper
INFO - 2025-05-13 16:38:52 --> Helper loaded: form_helper
INFO - 2025-05-13 16:38:52 --> Database Driver Class Initialized
DEBUG - 2025-05-13 16:38:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 16:38:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 16:38:52 --> Controller Class Initialized
INFO - 2025-05-13 16:38:52 --> Model "User_model" initialized
INFO - 2025-05-13 16:38:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-13 16:38:52 --> Final output sent to browser
DEBUG - 2025-05-13 16:38:52 --> Total execution time: 0.0798
INFO - 2025-05-13 16:39:06 --> Config Class Initialized
INFO - 2025-05-13 16:39:06 --> Hooks Class Initialized
DEBUG - 2025-05-13 16:39:06 --> UTF-8 Support Enabled
INFO - 2025-05-13 16:39:06 --> Utf8 Class Initialized
INFO - 2025-05-13 16:39:06 --> URI Class Initialized
INFO - 2025-05-13 16:39:06 --> Router Class Initialized
INFO - 2025-05-13 16:39:06 --> Output Class Initialized
INFO - 2025-05-13 16:39:06 --> Security Class Initialized
DEBUG - 2025-05-13 16:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 16:39:06 --> Input Class Initialized
INFO - 2025-05-13 16:39:06 --> Language Class Initialized
INFO - 2025-05-13 16:39:06 --> Loader Class Initialized
INFO - 2025-05-13 16:39:06 --> Helper loaded: url_helper
INFO - 2025-05-13 16:39:06 --> Helper loaded: form_helper
INFO - 2025-05-13 16:39:06 --> Database Driver Class Initialized
DEBUG - 2025-05-13 16:39:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 16:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 16:39:06 --> Controller Class Initialized
INFO - 2025-05-13 16:39:06 --> Model "User_model" initialized
INFO - 2025-05-13 16:39:06 --> Config Class Initialized
INFO - 2025-05-13 16:39:06 --> Hooks Class Initialized
DEBUG - 2025-05-13 16:39:06 --> UTF-8 Support Enabled
INFO - 2025-05-13 16:39:06 --> Utf8 Class Initialized
INFO - 2025-05-13 16:39:06 --> URI Class Initialized
INFO - 2025-05-13 16:39:06 --> Router Class Initialized
INFO - 2025-05-13 16:39:06 --> Output Class Initialized
INFO - 2025-05-13 16:39:06 --> Security Class Initialized
DEBUG - 2025-05-13 16:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 16:39:06 --> Input Class Initialized
INFO - 2025-05-13 16:39:06 --> Language Class Initialized
INFO - 2025-05-13 16:39:06 --> Loader Class Initialized
INFO - 2025-05-13 16:39:06 --> Helper loaded: url_helper
INFO - 2025-05-13 16:39:06 --> Helper loaded: form_helper
INFO - 2025-05-13 16:39:06 --> Database Driver Class Initialized
DEBUG - 2025-05-13 16:39:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 16:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 16:39:06 --> Controller Class Initialized
INFO - 2025-05-13 16:39:06 --> Model "User_model" initialized
INFO - 2025-05-13 16:39:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-13 16:39:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-13 16:39:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-13 16:39:06 --> Final output sent to browser
DEBUG - 2025-05-13 16:39:06 --> Total execution time: 0.0704
INFO - 2025-05-13 16:39:08 --> Config Class Initialized
INFO - 2025-05-13 16:39:08 --> Hooks Class Initialized
DEBUG - 2025-05-13 16:39:08 --> UTF-8 Support Enabled
INFO - 2025-05-13 16:39:08 --> Utf8 Class Initialized
INFO - 2025-05-13 16:39:08 --> URI Class Initialized
INFO - 2025-05-13 16:39:08 --> Router Class Initialized
INFO - 2025-05-13 16:39:08 --> Output Class Initialized
INFO - 2025-05-13 16:39:08 --> Security Class Initialized
DEBUG - 2025-05-13 16:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 16:39:08 --> Input Class Initialized
INFO - 2025-05-13 16:39:08 --> Language Class Initialized
INFO - 2025-05-13 16:39:08 --> Loader Class Initialized
INFO - 2025-05-13 16:39:08 --> Helper loaded: url_helper
INFO - 2025-05-13 16:39:08 --> Helper loaded: form_helper
INFO - 2025-05-13 16:39:08 --> Database Driver Class Initialized
DEBUG - 2025-05-13 16:39:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 16:39:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 16:39:08 --> Controller Class Initialized
INFO - 2025-05-13 16:39:08 --> Model "User_model" initialized
INFO - 2025-05-13 16:39:08 --> Model "Workout_model" initialized
INFO - 2025-05-13 16:39:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 16:39:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 16:39:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 16:39:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 16:39:08 --> Final output sent to browser
DEBUG - 2025-05-13 16:39:08 --> Total execution time: 0.0669
INFO - 2025-05-13 16:39:13 --> Config Class Initialized
INFO - 2025-05-13 16:39:13 --> Hooks Class Initialized
DEBUG - 2025-05-13 16:39:13 --> UTF-8 Support Enabled
INFO - 2025-05-13 16:39:13 --> Utf8 Class Initialized
INFO - 2025-05-13 16:39:13 --> URI Class Initialized
INFO - 2025-05-13 16:39:13 --> Router Class Initialized
INFO - 2025-05-13 16:39:13 --> Output Class Initialized
INFO - 2025-05-13 16:39:13 --> Security Class Initialized
DEBUG - 2025-05-13 16:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 16:39:13 --> Input Class Initialized
INFO - 2025-05-13 16:39:13 --> Language Class Initialized
INFO - 2025-05-13 16:39:13 --> Loader Class Initialized
INFO - 2025-05-13 16:39:13 --> Helper loaded: url_helper
INFO - 2025-05-13 16:39:13 --> Helper loaded: form_helper
INFO - 2025-05-13 16:39:13 --> Database Driver Class Initialized
DEBUG - 2025-05-13 16:39:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 16:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 16:39:13 --> Controller Class Initialized
INFO - 2025-05-13 16:39:13 --> Model "User_model" initialized
INFO - 2025-05-13 16:39:13 --> Model "Community_model" initialized
INFO - 2025-05-13 16:39:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/community.php
INFO - 2025-05-13 16:39:13 --> Final output sent to browser
DEBUG - 2025-05-13 16:39:13 --> Total execution time: 0.0791
INFO - 2025-05-13 16:39:17 --> Config Class Initialized
INFO - 2025-05-13 16:39:17 --> Hooks Class Initialized
DEBUG - 2025-05-13 16:39:17 --> UTF-8 Support Enabled
INFO - 2025-05-13 16:39:17 --> Utf8 Class Initialized
INFO - 2025-05-13 16:39:17 --> URI Class Initialized
INFO - 2025-05-13 16:39:17 --> Router Class Initialized
INFO - 2025-05-13 16:39:17 --> Output Class Initialized
INFO - 2025-05-13 16:39:17 --> Security Class Initialized
DEBUG - 2025-05-13 16:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 16:39:17 --> Input Class Initialized
INFO - 2025-05-13 16:39:17 --> Language Class Initialized
INFO - 2025-05-13 16:39:17 --> Loader Class Initialized
INFO - 2025-05-13 16:39:17 --> Helper loaded: url_helper
INFO - 2025-05-13 16:39:17 --> Helper loaded: form_helper
INFO - 2025-05-13 16:39:17 --> Database Driver Class Initialized
DEBUG - 2025-05-13 16:39:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 16:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 16:39:17 --> Controller Class Initialized
INFO - 2025-05-13 16:39:17 --> Model "User_model" initialized
INFO - 2025-05-13 16:39:17 --> Model "Community_model" initialized
INFO - 2025-05-13 16:39:17 --> Config Class Initialized
INFO - 2025-05-13 16:39:17 --> Hooks Class Initialized
DEBUG - 2025-05-13 16:39:17 --> UTF-8 Support Enabled
INFO - 2025-05-13 16:39:17 --> Utf8 Class Initialized
INFO - 2025-05-13 16:39:17 --> URI Class Initialized
INFO - 2025-05-13 16:39:17 --> Router Class Initialized
INFO - 2025-05-13 16:39:17 --> Output Class Initialized
INFO - 2025-05-13 16:39:17 --> Security Class Initialized
DEBUG - 2025-05-13 16:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 16:39:17 --> Input Class Initialized
INFO - 2025-05-13 16:39:17 --> Language Class Initialized
INFO - 2025-05-13 16:39:17 --> Loader Class Initialized
INFO - 2025-05-13 16:39:17 --> Helper loaded: url_helper
INFO - 2025-05-13 16:39:17 --> Helper loaded: form_helper
INFO - 2025-05-13 16:39:17 --> Database Driver Class Initialized
DEBUG - 2025-05-13 16:39:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 16:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 16:39:17 --> Controller Class Initialized
INFO - 2025-05-13 16:39:17 --> Model "User_model" initialized
INFO - 2025-05-13 16:39:17 --> Model "Community_model" initialized
INFO - 2025-05-13 16:39:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/community.php
INFO - 2025-05-13 16:39:17 --> Final output sent to browser
DEBUG - 2025-05-13 16:39:17 --> Total execution time: 0.0584
INFO - 2025-05-13 16:39:24 --> Config Class Initialized
INFO - 2025-05-13 16:39:24 --> Hooks Class Initialized
DEBUG - 2025-05-13 16:39:25 --> UTF-8 Support Enabled
INFO - 2025-05-13 16:39:25 --> Utf8 Class Initialized
INFO - 2025-05-13 16:39:25 --> URI Class Initialized
INFO - 2025-05-13 16:39:25 --> Router Class Initialized
INFO - 2025-05-13 16:39:25 --> Output Class Initialized
INFO - 2025-05-13 16:39:25 --> Security Class Initialized
DEBUG - 2025-05-13 16:39:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 16:39:25 --> Input Class Initialized
INFO - 2025-05-13 16:39:25 --> Language Class Initialized
INFO - 2025-05-13 16:39:25 --> Loader Class Initialized
INFO - 2025-05-13 16:39:25 --> Helper loaded: url_helper
INFO - 2025-05-13 16:39:25 --> Helper loaded: form_helper
INFO - 2025-05-13 16:39:25 --> Database Driver Class Initialized
DEBUG - 2025-05-13 16:39:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 16:39:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 16:39:25 --> Controller Class Initialized
INFO - 2025-05-13 16:39:25 --> Model "User_model" initialized
INFO - 2025-05-13 16:39:25 --> Model "Community_model" initialized
INFO - 2025-05-13 16:39:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/community.php
INFO - 2025-05-13 16:39:25 --> Final output sent to browser
DEBUG - 2025-05-13 16:39:25 --> Total execution time: 0.0850
INFO - 2025-05-13 16:39:29 --> Config Class Initialized
INFO - 2025-05-13 16:39:29 --> Hooks Class Initialized
DEBUG - 2025-05-13 16:39:29 --> UTF-8 Support Enabled
INFO - 2025-05-13 16:39:29 --> Utf8 Class Initialized
INFO - 2025-05-13 16:39:29 --> URI Class Initialized
INFO - 2025-05-13 16:39:29 --> Router Class Initialized
INFO - 2025-05-13 16:39:29 --> Output Class Initialized
INFO - 2025-05-13 16:39:29 --> Security Class Initialized
DEBUG - 2025-05-13 16:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 16:39:29 --> Input Class Initialized
INFO - 2025-05-13 16:39:29 --> Language Class Initialized
INFO - 2025-05-13 16:39:29 --> Loader Class Initialized
INFO - 2025-05-13 16:39:29 --> Helper loaded: url_helper
INFO - 2025-05-13 16:39:29 --> Helper loaded: form_helper
INFO - 2025-05-13 16:39:29 --> Database Driver Class Initialized
DEBUG - 2025-05-13 16:39:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 16:39:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 16:39:29 --> Controller Class Initialized
INFO - 2025-05-13 16:39:29 --> Model "User_model" initialized
INFO - 2025-05-13 16:39:29 --> Model "Workout_model" initialized
INFO - 2025-05-13 16:39:29 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 16:39:29 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 16:39:29 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 16:39:29 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 16:39:29 --> Final output sent to browser
DEBUG - 2025-05-13 16:39:29 --> Total execution time: 0.0920
INFO - 2025-05-13 16:40:39 --> Config Class Initialized
INFO - 2025-05-13 16:40:39 --> Hooks Class Initialized
DEBUG - 2025-05-13 16:40:39 --> UTF-8 Support Enabled
INFO - 2025-05-13 16:40:39 --> Utf8 Class Initialized
INFO - 2025-05-13 16:40:39 --> URI Class Initialized
INFO - 2025-05-13 16:40:39 --> Router Class Initialized
INFO - 2025-05-13 16:40:39 --> Output Class Initialized
INFO - 2025-05-13 16:40:39 --> Security Class Initialized
DEBUG - 2025-05-13 16:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 16:40:39 --> Input Class Initialized
INFO - 2025-05-13 16:40:39 --> Language Class Initialized
INFO - 2025-05-13 16:40:39 --> Loader Class Initialized
INFO - 2025-05-13 16:40:39 --> Helper loaded: url_helper
INFO - 2025-05-13 16:40:39 --> Helper loaded: form_helper
INFO - 2025-05-13 16:40:39 --> Database Driver Class Initialized
DEBUG - 2025-05-13 16:40:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 16:40:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 16:40:39 --> Controller Class Initialized
INFO - 2025-05-13 16:40:39 --> Model "User_model" initialized
INFO - 2025-05-13 16:40:39 --> Model "Workout_model" initialized
INFO - 2025-05-13 16:40:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 16:40:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 16:40:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 16:40:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 16:40:39 --> Final output sent to browser
DEBUG - 2025-05-13 16:40:39 --> Total execution time: 0.0684
INFO - 2025-05-13 16:40:42 --> Config Class Initialized
INFO - 2025-05-13 16:40:42 --> Hooks Class Initialized
DEBUG - 2025-05-13 16:40:42 --> UTF-8 Support Enabled
INFO - 2025-05-13 16:40:42 --> Utf8 Class Initialized
INFO - 2025-05-13 16:40:42 --> URI Class Initialized
INFO - 2025-05-13 16:40:42 --> Router Class Initialized
INFO - 2025-05-13 16:40:42 --> Output Class Initialized
INFO - 2025-05-13 16:40:42 --> Security Class Initialized
DEBUG - 2025-05-13 16:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 16:40:42 --> Input Class Initialized
INFO - 2025-05-13 16:40:42 --> Language Class Initialized
INFO - 2025-05-13 16:40:42 --> Loader Class Initialized
INFO - 2025-05-13 16:40:42 --> Helper loaded: url_helper
INFO - 2025-05-13 16:40:42 --> Helper loaded: form_helper
INFO - 2025-05-13 16:40:42 --> Database Driver Class Initialized
DEBUG - 2025-05-13 16:40:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 16:40:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 16:40:42 --> Controller Class Initialized
INFO - 2025-05-13 16:40:42 --> Model "User_model" initialized
INFO - 2025-05-13 16:40:42 --> Model "Community_model" initialized
INFO - 2025-05-13 16:40:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 16:40:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 16:40:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/community.php
INFO - 2025-05-13 16:40:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 16:40:42 --> Final output sent to browser
DEBUG - 2025-05-13 16:40:42 --> Total execution time: 0.0711
INFO - 2025-05-13 16:41:12 --> Config Class Initialized
INFO - 2025-05-13 16:41:12 --> Hooks Class Initialized
DEBUG - 2025-05-13 16:41:12 --> UTF-8 Support Enabled
INFO - 2025-05-13 16:41:12 --> Utf8 Class Initialized
INFO - 2025-05-13 16:41:12 --> URI Class Initialized
INFO - 2025-05-13 16:41:12 --> Router Class Initialized
INFO - 2025-05-13 16:41:12 --> Output Class Initialized
INFO - 2025-05-13 16:41:12 --> Security Class Initialized
DEBUG - 2025-05-13 16:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 16:41:12 --> Input Class Initialized
INFO - 2025-05-13 16:41:12 --> Language Class Initialized
INFO - 2025-05-13 16:41:12 --> Loader Class Initialized
INFO - 2025-05-13 16:41:12 --> Helper loaded: url_helper
INFO - 2025-05-13 16:41:12 --> Helper loaded: form_helper
INFO - 2025-05-13 16:41:12 --> Database Driver Class Initialized
DEBUG - 2025-05-13 16:41:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 16:41:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 16:41:12 --> Controller Class Initialized
INFO - 2025-05-13 16:41:12 --> Model "User_model" initialized
INFO - 2025-05-13 16:41:12 --> Model "Community_model" initialized
INFO - 2025-05-13 16:41:12 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 16:41:12 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 16:41:12 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/community.php
INFO - 2025-05-13 16:41:12 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 16:41:12 --> Final output sent to browser
DEBUG - 2025-05-13 16:41:12 --> Total execution time: 0.0711
INFO - 2025-05-13 16:42:35 --> Config Class Initialized
INFO - 2025-05-13 16:42:35 --> Hooks Class Initialized
DEBUG - 2025-05-13 16:42:35 --> UTF-8 Support Enabled
INFO - 2025-05-13 16:42:35 --> Utf8 Class Initialized
INFO - 2025-05-13 16:42:35 --> URI Class Initialized
INFO - 2025-05-13 16:42:35 --> Router Class Initialized
INFO - 2025-05-13 16:42:35 --> Output Class Initialized
INFO - 2025-05-13 16:42:35 --> Security Class Initialized
DEBUG - 2025-05-13 16:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 16:42:35 --> Input Class Initialized
INFO - 2025-05-13 16:42:35 --> Language Class Initialized
INFO - 2025-05-13 16:42:35 --> Loader Class Initialized
INFO - 2025-05-13 16:42:35 --> Helper loaded: url_helper
INFO - 2025-05-13 16:42:35 --> Helper loaded: form_helper
INFO - 2025-05-13 16:42:35 --> Database Driver Class Initialized
DEBUG - 2025-05-13 16:42:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 16:42:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 16:42:35 --> Controller Class Initialized
INFO - 2025-05-13 16:42:35 --> Model "User_model" initialized
INFO - 2025-05-13 16:42:35 --> Model "Community_model" initialized
INFO - 2025-05-13 16:42:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 16:42:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 16:42:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/community.php
INFO - 2025-05-13 16:42:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 16:42:35 --> Final output sent to browser
DEBUG - 2025-05-13 16:42:35 --> Total execution time: 0.0825
INFO - 2025-05-13 16:44:09 --> Config Class Initialized
INFO - 2025-05-13 16:44:09 --> Hooks Class Initialized
DEBUG - 2025-05-13 16:44:09 --> UTF-8 Support Enabled
INFO - 2025-05-13 16:44:09 --> Utf8 Class Initialized
INFO - 2025-05-13 16:44:09 --> URI Class Initialized
INFO - 2025-05-13 16:44:09 --> Router Class Initialized
INFO - 2025-05-13 16:44:09 --> Output Class Initialized
INFO - 2025-05-13 16:44:09 --> Security Class Initialized
DEBUG - 2025-05-13 16:44:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 16:44:09 --> Input Class Initialized
INFO - 2025-05-13 16:44:09 --> Language Class Initialized
INFO - 2025-05-13 16:44:09 --> Loader Class Initialized
INFO - 2025-05-13 16:44:09 --> Helper loaded: url_helper
INFO - 2025-05-13 16:44:09 --> Helper loaded: form_helper
INFO - 2025-05-13 16:44:09 --> Database Driver Class Initialized
DEBUG - 2025-05-13 16:44:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 16:44:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 16:44:09 --> Controller Class Initialized
INFO - 2025-05-13 16:44:09 --> Model "User_model" initialized
INFO - 2025-05-13 16:44:09 --> Model "Community_model" initialized
INFO - 2025-05-13 16:44:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 16:44:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 16:44:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/community.php
INFO - 2025-05-13 16:44:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 16:44:09 --> Final output sent to browser
DEBUG - 2025-05-13 16:44:09 --> Total execution time: 0.0800
INFO - 2025-05-13 16:44:13 --> Config Class Initialized
INFO - 2025-05-13 16:44:13 --> Hooks Class Initialized
DEBUG - 2025-05-13 16:44:13 --> UTF-8 Support Enabled
INFO - 2025-05-13 16:44:13 --> Utf8 Class Initialized
INFO - 2025-05-13 16:44:13 --> URI Class Initialized
INFO - 2025-05-13 16:44:13 --> Router Class Initialized
INFO - 2025-05-13 16:44:13 --> Output Class Initialized
INFO - 2025-05-13 16:44:13 --> Security Class Initialized
DEBUG - 2025-05-13 16:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 16:44:13 --> Input Class Initialized
INFO - 2025-05-13 16:44:13 --> Language Class Initialized
INFO - 2025-05-13 16:44:13 --> Loader Class Initialized
INFO - 2025-05-13 16:44:13 --> Helper loaded: url_helper
INFO - 2025-05-13 16:44:13 --> Helper loaded: form_helper
INFO - 2025-05-13 16:44:13 --> Database Driver Class Initialized
DEBUG - 2025-05-13 16:44:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 16:44:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 16:44:13 --> Controller Class Initialized
INFO - 2025-05-13 16:44:13 --> Model "User_model" initialized
INFO - 2025-05-13 16:44:13 --> Model "Workout_model" initialized
INFO - 2025-05-13 16:44:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 16:44:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 16:44:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-13 16:44:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 16:44:13 --> Final output sent to browser
DEBUG - 2025-05-13 16:44:13 --> Total execution time: 0.0641
INFO - 2025-05-13 16:44:21 --> Config Class Initialized
INFO - 2025-05-13 16:44:21 --> Hooks Class Initialized
DEBUG - 2025-05-13 16:44:21 --> UTF-8 Support Enabled
INFO - 2025-05-13 16:44:21 --> Utf8 Class Initialized
INFO - 2025-05-13 16:44:21 --> URI Class Initialized
INFO - 2025-05-13 16:44:21 --> Router Class Initialized
INFO - 2025-05-13 16:44:21 --> Output Class Initialized
INFO - 2025-05-13 16:44:21 --> Security Class Initialized
DEBUG - 2025-05-13 16:44:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 16:44:21 --> Input Class Initialized
INFO - 2025-05-13 16:44:21 --> Language Class Initialized
INFO - 2025-05-13 16:44:21 --> Loader Class Initialized
INFO - 2025-05-13 16:44:21 --> Helper loaded: url_helper
INFO - 2025-05-13 16:44:21 --> Helper loaded: form_helper
INFO - 2025-05-13 16:44:21 --> Database Driver Class Initialized
DEBUG - 2025-05-13 16:44:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 16:44:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 16:44:21 --> Controller Class Initialized
INFO - 2025-05-13 16:44:21 --> Model "User_model" initialized
INFO - 2025-05-13 16:44:21 --> Model "Community_model" initialized
INFO - 2025-05-13 16:44:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 16:44:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 16:44:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/community.php
INFO - 2025-05-13 16:44:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 16:44:21 --> Final output sent to browser
DEBUG - 2025-05-13 16:44:21 --> Total execution time: 0.0682
INFO - 2025-05-13 16:44:32 --> Config Class Initialized
INFO - 2025-05-13 16:44:32 --> Hooks Class Initialized
DEBUG - 2025-05-13 16:44:32 --> UTF-8 Support Enabled
INFO - 2025-05-13 16:44:32 --> Utf8 Class Initialized
INFO - 2025-05-13 16:44:32 --> URI Class Initialized
INFO - 2025-05-13 16:44:32 --> Router Class Initialized
INFO - 2025-05-13 16:44:32 --> Output Class Initialized
INFO - 2025-05-13 16:44:32 --> Security Class Initialized
DEBUG - 2025-05-13 16:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 16:44:32 --> Input Class Initialized
INFO - 2025-05-13 16:44:32 --> Language Class Initialized
INFO - 2025-05-13 16:44:32 --> Loader Class Initialized
INFO - 2025-05-13 16:44:32 --> Helper loaded: url_helper
INFO - 2025-05-13 16:44:32 --> Helper loaded: form_helper
INFO - 2025-05-13 16:44:32 --> Database Driver Class Initialized
DEBUG - 2025-05-13 16:44:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 16:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 16:44:32 --> Controller Class Initialized
INFO - 2025-05-13 16:44:32 --> Model "User_model" initialized
INFO - 2025-05-13 16:44:32 --> Model "Community_model" initialized
INFO - 2025-05-13 16:44:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 16:44:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 16:44:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/community.php
INFO - 2025-05-13 16:44:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 16:44:32 --> Final output sent to browser
DEBUG - 2025-05-13 16:44:32 --> Total execution time: 0.0818
INFO - 2025-05-13 16:47:21 --> Config Class Initialized
INFO - 2025-05-13 16:47:21 --> Hooks Class Initialized
DEBUG - 2025-05-13 16:47:21 --> UTF-8 Support Enabled
INFO - 2025-05-13 16:47:21 --> Utf8 Class Initialized
INFO - 2025-05-13 16:47:21 --> URI Class Initialized
INFO - 2025-05-13 16:47:21 --> Router Class Initialized
INFO - 2025-05-13 16:47:21 --> Output Class Initialized
INFO - 2025-05-13 16:47:21 --> Security Class Initialized
DEBUG - 2025-05-13 16:47:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 16:47:21 --> Input Class Initialized
INFO - 2025-05-13 16:47:21 --> Language Class Initialized
INFO - 2025-05-13 16:47:21 --> Loader Class Initialized
INFO - 2025-05-13 16:47:21 --> Helper loaded: url_helper
INFO - 2025-05-13 16:47:21 --> Helper loaded: form_helper
INFO - 2025-05-13 16:47:21 --> Database Driver Class Initialized
DEBUG - 2025-05-13 16:47:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 16:47:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 16:47:21 --> Controller Class Initialized
INFO - 2025-05-13 16:47:21 --> Model "User_model" initialized
INFO - 2025-05-13 16:47:21 --> Model "Community_model" initialized
INFO - 2025-05-13 16:47:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 16:47:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 16:47:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/community.php
INFO - 2025-05-13 16:47:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 16:47:21 --> Final output sent to browser
DEBUG - 2025-05-13 16:47:21 --> Total execution time: 0.0678
INFO - 2025-05-13 16:47:24 --> Config Class Initialized
INFO - 2025-05-13 16:47:24 --> Hooks Class Initialized
DEBUG - 2025-05-13 16:47:24 --> UTF-8 Support Enabled
INFO - 2025-05-13 16:47:24 --> Utf8 Class Initialized
INFO - 2025-05-13 16:47:24 --> URI Class Initialized
INFO - 2025-05-13 16:47:24 --> Router Class Initialized
INFO - 2025-05-13 16:47:24 --> Output Class Initialized
INFO - 2025-05-13 16:47:24 --> Security Class Initialized
DEBUG - 2025-05-13 16:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 16:47:24 --> Input Class Initialized
INFO - 2025-05-13 16:47:24 --> Language Class Initialized
INFO - 2025-05-13 16:47:24 --> Loader Class Initialized
INFO - 2025-05-13 16:47:24 --> Helper loaded: url_helper
INFO - 2025-05-13 16:47:24 --> Helper loaded: form_helper
INFO - 2025-05-13 16:47:24 --> Database Driver Class Initialized
DEBUG - 2025-05-13 16:47:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 16:47:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 16:47:24 --> Controller Class Initialized
INFO - 2025-05-13 16:47:24 --> Model "User_model" initialized
INFO - 2025-05-13 16:47:24 --> Model "Workout_model" initialized
INFO - 2025-05-13 16:47:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 16:47:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 16:47:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 16:47:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 16:47:24 --> Final output sent to browser
DEBUG - 2025-05-13 16:47:24 --> Total execution time: 0.0877
INFO - 2025-05-13 16:49:20 --> Config Class Initialized
INFO - 2025-05-13 16:49:20 --> Hooks Class Initialized
DEBUG - 2025-05-13 16:49:20 --> UTF-8 Support Enabled
INFO - 2025-05-13 16:49:20 --> Utf8 Class Initialized
INFO - 2025-05-13 16:49:20 --> URI Class Initialized
INFO - 2025-05-13 16:49:20 --> Router Class Initialized
INFO - 2025-05-13 16:49:20 --> Output Class Initialized
INFO - 2025-05-13 16:49:20 --> Security Class Initialized
DEBUG - 2025-05-13 16:49:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 16:49:20 --> Input Class Initialized
INFO - 2025-05-13 16:49:20 --> Language Class Initialized
INFO - 2025-05-13 16:49:20 --> Loader Class Initialized
INFO - 2025-05-13 16:49:20 --> Helper loaded: url_helper
INFO - 2025-05-13 16:49:20 --> Helper loaded: form_helper
INFO - 2025-05-13 16:49:20 --> Database Driver Class Initialized
DEBUG - 2025-05-13 16:49:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 16:49:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 16:49:20 --> Controller Class Initialized
INFO - 2025-05-13 16:49:20 --> Model "User_model" initialized
INFO - 2025-05-13 16:49:20 --> Model "Workout_model" initialized
INFO - 2025-05-13 16:49:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 16:49:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 16:49:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 16:49:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 16:49:20 --> Final output sent to browser
DEBUG - 2025-05-13 16:49:20 --> Total execution time: 0.0758
INFO - 2025-05-13 16:49:21 --> Config Class Initialized
INFO - 2025-05-13 16:49:21 --> Hooks Class Initialized
DEBUG - 2025-05-13 16:49:21 --> UTF-8 Support Enabled
INFO - 2025-05-13 16:49:21 --> Utf8 Class Initialized
INFO - 2025-05-13 16:49:21 --> URI Class Initialized
INFO - 2025-05-13 16:49:21 --> Router Class Initialized
INFO - 2025-05-13 16:49:21 --> Output Class Initialized
INFO - 2025-05-13 16:49:21 --> Security Class Initialized
DEBUG - 2025-05-13 16:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 16:49:21 --> Input Class Initialized
INFO - 2025-05-13 16:49:21 --> Language Class Initialized
INFO - 2025-05-13 16:49:21 --> Loader Class Initialized
INFO - 2025-05-13 16:49:21 --> Helper loaded: url_helper
INFO - 2025-05-13 16:49:21 --> Helper loaded: form_helper
INFO - 2025-05-13 16:49:21 --> Database Driver Class Initialized
DEBUG - 2025-05-13 16:49:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 16:49:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 16:49:21 --> Controller Class Initialized
INFO - 2025-05-13 16:49:21 --> Model "User_model" initialized
INFO - 2025-05-13 16:49:21 --> Model "Community_model" initialized
INFO - 2025-05-13 16:49:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 16:49:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 16:49:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/community.php
INFO - 2025-05-13 16:49:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 16:49:21 --> Final output sent to browser
DEBUG - 2025-05-13 16:49:21 --> Total execution time: 0.0714
INFO - 2025-05-13 16:49:23 --> Config Class Initialized
INFO - 2025-05-13 16:49:23 --> Hooks Class Initialized
DEBUG - 2025-05-13 16:49:23 --> UTF-8 Support Enabled
INFO - 2025-05-13 16:49:23 --> Utf8 Class Initialized
INFO - 2025-05-13 16:49:23 --> URI Class Initialized
INFO - 2025-05-13 16:49:23 --> Router Class Initialized
INFO - 2025-05-13 16:49:23 --> Output Class Initialized
INFO - 2025-05-13 16:49:23 --> Security Class Initialized
DEBUG - 2025-05-13 16:49:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 16:49:23 --> Input Class Initialized
INFO - 2025-05-13 16:49:23 --> Language Class Initialized
INFO - 2025-05-13 16:49:23 --> Loader Class Initialized
INFO - 2025-05-13 16:49:23 --> Helper loaded: url_helper
INFO - 2025-05-13 16:49:23 --> Helper loaded: form_helper
INFO - 2025-05-13 16:49:23 --> Database Driver Class Initialized
DEBUG - 2025-05-13 16:49:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 16:49:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 16:49:23 --> Controller Class Initialized
INFO - 2025-05-13 16:49:23 --> Model "Workout_model" initialized
INFO - 2025-05-13 16:49:23 --> Model "User_model" initialized
INFO - 2025-05-13 16:49:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 16:49:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 16:49:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-13 16:49:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 16:49:23 --> Final output sent to browser
DEBUG - 2025-05-13 16:49:23 --> Total execution time: 0.0766
INFO - 2025-05-13 16:49:24 --> Config Class Initialized
INFO - 2025-05-13 16:49:24 --> Hooks Class Initialized
DEBUG - 2025-05-13 16:49:24 --> UTF-8 Support Enabled
INFO - 2025-05-13 16:49:24 --> Utf8 Class Initialized
INFO - 2025-05-13 16:49:24 --> URI Class Initialized
INFO - 2025-05-13 16:49:24 --> Router Class Initialized
INFO - 2025-05-13 16:49:24 --> Output Class Initialized
INFO - 2025-05-13 16:49:24 --> Security Class Initialized
DEBUG - 2025-05-13 16:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 16:49:24 --> Input Class Initialized
INFO - 2025-05-13 16:49:24 --> Language Class Initialized
INFO - 2025-05-13 16:49:24 --> Loader Class Initialized
INFO - 2025-05-13 16:49:24 --> Helper loaded: url_helper
INFO - 2025-05-13 16:49:24 --> Helper loaded: form_helper
INFO - 2025-05-13 16:49:24 --> Database Driver Class Initialized
DEBUG - 2025-05-13 16:49:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 16:49:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 16:49:24 --> Controller Class Initialized
INFO - 2025-05-13 16:49:24 --> Model "User_model" initialized
INFO - 2025-05-13 16:49:24 --> Model "Workout_model" initialized
INFO - 2025-05-13 16:49:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 16:49:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 16:49:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-13 16:49:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 16:49:24 --> Final output sent to browser
DEBUG - 2025-05-13 16:49:24 --> Total execution time: 0.0798
INFO - 2025-05-13 16:49:25 --> Config Class Initialized
INFO - 2025-05-13 16:49:25 --> Hooks Class Initialized
DEBUG - 2025-05-13 16:49:25 --> UTF-8 Support Enabled
INFO - 2025-05-13 16:49:25 --> Utf8 Class Initialized
INFO - 2025-05-13 16:49:25 --> URI Class Initialized
INFO - 2025-05-13 16:49:25 --> Router Class Initialized
INFO - 2025-05-13 16:49:25 --> Output Class Initialized
INFO - 2025-05-13 16:49:25 --> Security Class Initialized
DEBUG - 2025-05-13 16:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 16:49:25 --> Input Class Initialized
INFO - 2025-05-13 16:49:25 --> Language Class Initialized
INFO - 2025-05-13 16:49:25 --> Loader Class Initialized
INFO - 2025-05-13 16:49:25 --> Helper loaded: url_helper
INFO - 2025-05-13 16:49:25 --> Helper loaded: form_helper
INFO - 2025-05-13 16:49:25 --> Database Driver Class Initialized
DEBUG - 2025-05-13 16:49:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 16:49:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 16:49:25 --> Controller Class Initialized
INFO - 2025-05-13 16:49:25 --> Model "User_model" initialized
INFO - 2025-05-13 16:49:25 --> Model "Workout_model" initialized
INFO - 2025-05-13 16:49:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 16:49:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 16:49:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 16:49:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 16:49:25 --> Final output sent to browser
DEBUG - 2025-05-13 16:49:25 --> Total execution time: 0.0705
INFO - 2025-05-13 16:49:26 --> Config Class Initialized
INFO - 2025-05-13 16:49:26 --> Hooks Class Initialized
DEBUG - 2025-05-13 16:49:26 --> UTF-8 Support Enabled
INFO - 2025-05-13 16:49:26 --> Utf8 Class Initialized
INFO - 2025-05-13 16:49:26 --> URI Class Initialized
INFO - 2025-05-13 16:49:26 --> Router Class Initialized
INFO - 2025-05-13 16:49:26 --> Output Class Initialized
INFO - 2025-05-13 16:49:26 --> Security Class Initialized
DEBUG - 2025-05-13 16:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 16:49:26 --> Input Class Initialized
INFO - 2025-05-13 16:49:26 --> Language Class Initialized
INFO - 2025-05-13 16:49:26 --> Loader Class Initialized
INFO - 2025-05-13 16:49:26 --> Helper loaded: url_helper
INFO - 2025-05-13 16:49:26 --> Helper loaded: form_helper
INFO - 2025-05-13 16:49:26 --> Database Driver Class Initialized
DEBUG - 2025-05-13 16:49:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 16:49:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 16:49:26 --> Controller Class Initialized
INFO - 2025-05-13 16:49:26 --> Model "User_model" initialized
INFO - 2025-05-13 16:49:26 --> Model "Community_model" initialized
INFO - 2025-05-13 16:49:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 16:49:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 16:49:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/community.php
INFO - 2025-05-13 16:49:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 16:49:26 --> Final output sent to browser
DEBUG - 2025-05-13 16:49:26 --> Total execution time: 0.0600
INFO - 2025-05-13 16:49:29 --> Config Class Initialized
INFO - 2025-05-13 16:49:29 --> Hooks Class Initialized
DEBUG - 2025-05-13 16:49:29 --> UTF-8 Support Enabled
INFO - 2025-05-13 16:49:29 --> Utf8 Class Initialized
INFO - 2025-05-13 16:49:29 --> URI Class Initialized
INFO - 2025-05-13 16:49:29 --> Router Class Initialized
INFO - 2025-05-13 16:49:29 --> Output Class Initialized
INFO - 2025-05-13 16:49:29 --> Security Class Initialized
DEBUG - 2025-05-13 16:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 16:49:29 --> Input Class Initialized
INFO - 2025-05-13 16:49:29 --> Language Class Initialized
INFO - 2025-05-13 16:49:29 --> Loader Class Initialized
INFO - 2025-05-13 16:49:29 --> Helper loaded: url_helper
INFO - 2025-05-13 16:49:29 --> Helper loaded: form_helper
INFO - 2025-05-13 16:49:29 --> Database Driver Class Initialized
DEBUG - 2025-05-13 16:49:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 16:49:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 16:49:29 --> Controller Class Initialized
INFO - 2025-05-13 16:49:29 --> Model "User_model" initialized
INFO - 2025-05-13 16:49:29 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-13 16:49:29 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-13 16:49:29 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-13 16:49:29 --> Final output sent to browser
DEBUG - 2025-05-13 16:49:29 --> Total execution time: 0.0836
INFO - 2025-05-13 16:49:33 --> Config Class Initialized
INFO - 2025-05-13 16:49:33 --> Hooks Class Initialized
DEBUG - 2025-05-13 16:49:33 --> UTF-8 Support Enabled
INFO - 2025-05-13 16:49:33 --> Utf8 Class Initialized
INFO - 2025-05-13 16:49:33 --> URI Class Initialized
INFO - 2025-05-13 16:49:33 --> Router Class Initialized
INFO - 2025-05-13 16:49:33 --> Output Class Initialized
INFO - 2025-05-13 16:49:33 --> Security Class Initialized
DEBUG - 2025-05-13 16:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 16:49:33 --> Input Class Initialized
INFO - 2025-05-13 16:49:33 --> Language Class Initialized
INFO - 2025-05-13 16:49:33 --> Loader Class Initialized
INFO - 2025-05-13 16:49:33 --> Helper loaded: url_helper
INFO - 2025-05-13 16:49:33 --> Helper loaded: form_helper
INFO - 2025-05-13 16:49:33 --> Database Driver Class Initialized
DEBUG - 2025-05-13 16:49:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 16:49:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 16:49:33 --> Controller Class Initialized
INFO - 2025-05-13 16:49:33 --> Model "User_model" initialized
INFO - 2025-05-13 16:49:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-13 16:49:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/artikel.php
INFO - 2025-05-13 16:49:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-13 16:49:33 --> Final output sent to browser
DEBUG - 2025-05-13 16:49:33 --> Total execution time: 0.0931
INFO - 2025-05-13 16:49:40 --> Config Class Initialized
INFO - 2025-05-13 16:49:40 --> Hooks Class Initialized
DEBUG - 2025-05-13 16:49:40 --> UTF-8 Support Enabled
INFO - 2025-05-13 16:49:40 --> Utf8 Class Initialized
INFO - 2025-05-13 16:49:40 --> URI Class Initialized
INFO - 2025-05-13 16:49:40 --> Router Class Initialized
INFO - 2025-05-13 16:49:40 --> Output Class Initialized
INFO - 2025-05-13 16:49:40 --> Security Class Initialized
DEBUG - 2025-05-13 16:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 16:49:40 --> Input Class Initialized
INFO - 2025-05-13 16:49:40 --> Language Class Initialized
INFO - 2025-05-13 16:49:40 --> Loader Class Initialized
INFO - 2025-05-13 16:49:40 --> Helper loaded: url_helper
INFO - 2025-05-13 16:49:40 --> Helper loaded: form_helper
INFO - 2025-05-13 16:49:40 --> Database Driver Class Initialized
DEBUG - 2025-05-13 16:49:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 16:49:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 16:49:40 --> Controller Class Initialized
INFO - 2025-05-13 16:49:40 --> Model "User_model" initialized
INFO - 2025-05-13 16:49:40 --> Model "Workout_model" initialized
INFO - 2025-05-13 16:49:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 16:49:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 16:49:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-13 16:49:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 16:49:40 --> Final output sent to browser
DEBUG - 2025-05-13 16:49:40 --> Total execution time: 0.0866
INFO - 2025-05-13 16:49:42 --> Config Class Initialized
INFO - 2025-05-13 16:49:42 --> Hooks Class Initialized
DEBUG - 2025-05-13 16:49:42 --> UTF-8 Support Enabled
INFO - 2025-05-13 16:49:42 --> Utf8 Class Initialized
INFO - 2025-05-13 16:49:42 --> URI Class Initialized
INFO - 2025-05-13 16:49:42 --> Router Class Initialized
INFO - 2025-05-13 16:49:42 --> Output Class Initialized
INFO - 2025-05-13 16:49:42 --> Security Class Initialized
DEBUG - 2025-05-13 16:49:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 16:49:42 --> Input Class Initialized
INFO - 2025-05-13 16:49:42 --> Language Class Initialized
INFO - 2025-05-13 16:49:42 --> Loader Class Initialized
INFO - 2025-05-13 16:49:42 --> Helper loaded: url_helper
INFO - 2025-05-13 16:49:42 --> Helper loaded: form_helper
INFO - 2025-05-13 16:49:42 --> Database Driver Class Initialized
DEBUG - 2025-05-13 16:49:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 16:49:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 16:49:42 --> Controller Class Initialized
INFO - 2025-05-13 16:49:42 --> Model "User_model" initialized
INFO - 2025-05-13 16:49:42 --> Model "Community_model" initialized
INFO - 2025-05-13 16:49:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-13 16:49:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-13 16:49:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/community.php
INFO - 2025-05-13 16:49:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-13 16:49:42 --> Final output sent to browser
DEBUG - 2025-05-13 16:49:42 --> Total execution time: 0.0742
INFO - 2025-05-13 16:49:48 --> Config Class Initialized
INFO - 2025-05-13 16:49:48 --> Hooks Class Initialized
DEBUG - 2025-05-13 16:49:48 --> UTF-8 Support Enabled
INFO - 2025-05-13 16:49:48 --> Utf8 Class Initialized
INFO - 2025-05-13 16:49:48 --> URI Class Initialized
INFO - 2025-05-13 16:49:48 --> Router Class Initialized
INFO - 2025-05-13 16:49:48 --> Output Class Initialized
INFO - 2025-05-13 16:49:48 --> Security Class Initialized
DEBUG - 2025-05-13 16:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 16:49:48 --> Input Class Initialized
INFO - 2025-05-13 16:49:48 --> Language Class Initialized
INFO - 2025-05-13 16:49:48 --> Loader Class Initialized
INFO - 2025-05-13 16:49:48 --> Helper loaded: url_helper
INFO - 2025-05-13 16:49:48 --> Helper loaded: form_helper
INFO - 2025-05-13 16:49:48 --> Database Driver Class Initialized
DEBUG - 2025-05-13 16:49:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 16:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 16:49:48 --> Controller Class Initialized
INFO - 2025-05-13 16:49:48 --> Model "User_model" initialized
INFO - 2025-05-13 16:49:48 --> Config Class Initialized
INFO - 2025-05-13 16:49:48 --> Hooks Class Initialized
DEBUG - 2025-05-13 16:49:48 --> UTF-8 Support Enabled
INFO - 2025-05-13 16:49:48 --> Utf8 Class Initialized
INFO - 2025-05-13 16:49:48 --> URI Class Initialized
INFO - 2025-05-13 16:49:48 --> Router Class Initialized
INFO - 2025-05-13 16:49:48 --> Output Class Initialized
INFO - 2025-05-13 16:49:48 --> Security Class Initialized
DEBUG - 2025-05-13 16:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-13 16:49:48 --> Input Class Initialized
INFO - 2025-05-13 16:49:48 --> Language Class Initialized
INFO - 2025-05-13 16:49:48 --> Loader Class Initialized
INFO - 2025-05-13 16:49:48 --> Helper loaded: url_helper
INFO - 2025-05-13 16:49:48 --> Helper loaded: form_helper
INFO - 2025-05-13 16:49:48 --> Database Driver Class Initialized
DEBUG - 2025-05-13 16:49:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-13 16:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-13 16:49:48 --> Controller Class Initialized
INFO - 2025-05-13 16:49:48 --> Model "User_model" initialized
INFO - 2025-05-13 16:49:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-13 16:49:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-13 16:49:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-13 16:49:48 --> Final output sent to browser
DEBUG - 2025-05-13 16:49:48 --> Total execution time: 0.0721
