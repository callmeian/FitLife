<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-05-24 13:41:48 --> Config Class Initialized
INFO - 2025-05-24 13:41:48 --> Hooks Class Initialized
DEBUG - 2025-05-24 13:41:48 --> UTF-8 Support Enabled
INFO - 2025-05-24 13:41:48 --> Utf8 Class Initialized
INFO - 2025-05-24 13:41:48 --> URI Class Initialized
DEBUG - 2025-05-24 13:41:48 --> No URI present. Default controller set.
INFO - 2025-05-24 13:41:48 --> Router Class Initialized
INFO - 2025-05-24 13:41:48 --> Output Class Initialized
INFO - 2025-05-24 13:41:48 --> Security Class Initialized
DEBUG - 2025-05-24 13:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 13:41:48 --> Input Class Initialized
INFO - 2025-05-24 13:41:48 --> Language Class Initialized
INFO - 2025-05-24 13:41:48 --> Loader Class Initialized
INFO - 2025-05-24 13:41:48 --> Helper loaded: url_helper
INFO - 2025-05-24 13:41:48 --> Helper loaded: form_helper
INFO - 2025-05-24 13:41:48 --> Database Driver Class Initialized
DEBUG - 2025-05-24 13:41:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 13:41:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 13:41:48 --> Controller Class Initialized
INFO - 2025-05-24 13:41:48 --> Model "User_model" initialized
INFO - 2025-05-24 13:41:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-24 13:41:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-24 13:41:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-24 13:41:48 --> Final output sent to browser
DEBUG - 2025-05-24 13:41:48 --> Total execution time: 0.1587
INFO - 2025-05-24 13:41:51 --> Config Class Initialized
INFO - 2025-05-24 13:41:51 --> Hooks Class Initialized
DEBUG - 2025-05-24 13:41:51 --> UTF-8 Support Enabled
INFO - 2025-05-24 13:41:51 --> Utf8 Class Initialized
INFO - 2025-05-24 13:41:51 --> URI Class Initialized
INFO - 2025-05-24 13:41:51 --> Router Class Initialized
INFO - 2025-05-24 13:41:51 --> Output Class Initialized
INFO - 2025-05-24 13:41:51 --> Security Class Initialized
DEBUG - 2025-05-24 13:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 13:41:51 --> Input Class Initialized
INFO - 2025-05-24 13:41:51 --> Language Class Initialized
INFO - 2025-05-24 13:41:51 --> Loader Class Initialized
INFO - 2025-05-24 13:41:51 --> Helper loaded: url_helper
INFO - 2025-05-24 13:41:51 --> Helper loaded: form_helper
INFO - 2025-05-24 13:41:51 --> Database Driver Class Initialized
DEBUG - 2025-05-24 13:41:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 13:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 13:41:51 --> Controller Class Initialized
INFO - 2025-05-24 13:41:51 --> Model "User_model" initialized
INFO - 2025-05-24 13:41:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-24 13:41:51 --> Final output sent to browser
DEBUG - 2025-05-24 13:41:51 --> Total execution time: 0.0935
INFO - 2025-05-24 13:41:57 --> Config Class Initialized
INFO - 2025-05-24 13:41:57 --> Hooks Class Initialized
DEBUG - 2025-05-24 13:41:57 --> UTF-8 Support Enabled
INFO - 2025-05-24 13:41:57 --> Utf8 Class Initialized
INFO - 2025-05-24 13:41:57 --> URI Class Initialized
INFO - 2025-05-24 13:41:57 --> Router Class Initialized
INFO - 2025-05-24 13:41:57 --> Output Class Initialized
INFO - 2025-05-24 13:41:57 --> Security Class Initialized
DEBUG - 2025-05-24 13:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 13:41:57 --> Input Class Initialized
INFO - 2025-05-24 13:41:57 --> Language Class Initialized
INFO - 2025-05-24 13:41:57 --> Loader Class Initialized
INFO - 2025-05-24 13:41:57 --> Helper loaded: url_helper
INFO - 2025-05-24 13:41:57 --> Helper loaded: form_helper
INFO - 2025-05-24 13:41:57 --> Database Driver Class Initialized
DEBUG - 2025-05-24 13:41:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 13:41:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 13:41:57 --> Controller Class Initialized
INFO - 2025-05-24 13:41:57 --> Model "User_model" initialized
INFO - 2025-05-24 13:41:57 --> Config Class Initialized
INFO - 2025-05-24 13:41:57 --> Hooks Class Initialized
DEBUG - 2025-05-24 13:41:57 --> UTF-8 Support Enabled
INFO - 2025-05-24 13:41:57 --> Utf8 Class Initialized
INFO - 2025-05-24 13:41:57 --> URI Class Initialized
INFO - 2025-05-24 13:41:57 --> Router Class Initialized
INFO - 2025-05-24 13:41:57 --> Output Class Initialized
INFO - 2025-05-24 13:41:57 --> Security Class Initialized
DEBUG - 2025-05-24 13:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 13:41:57 --> Input Class Initialized
INFO - 2025-05-24 13:41:57 --> Language Class Initialized
INFO - 2025-05-24 13:41:58 --> Loader Class Initialized
INFO - 2025-05-24 13:41:58 --> Helper loaded: url_helper
INFO - 2025-05-24 13:41:58 --> Helper loaded: form_helper
INFO - 2025-05-24 13:41:58 --> Database Driver Class Initialized
DEBUG - 2025-05-24 13:41:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 13:41:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 13:41:58 --> Controller Class Initialized
INFO - 2025-05-24 13:41:58 --> Model "User_model" initialized
INFO - 2025-05-24 13:41:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-24 13:41:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-24 13:41:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-24 13:41:58 --> Final output sent to browser
DEBUG - 2025-05-24 13:41:58 --> Total execution time: 0.0615
INFO - 2025-05-24 13:42:00 --> Config Class Initialized
INFO - 2025-05-24 13:42:00 --> Hooks Class Initialized
DEBUG - 2025-05-24 13:42:00 --> UTF-8 Support Enabled
INFO - 2025-05-24 13:42:00 --> Utf8 Class Initialized
INFO - 2025-05-24 13:42:00 --> URI Class Initialized
INFO - 2025-05-24 13:42:00 --> Router Class Initialized
INFO - 2025-05-24 13:42:00 --> Output Class Initialized
INFO - 2025-05-24 13:42:00 --> Security Class Initialized
DEBUG - 2025-05-24 13:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 13:42:00 --> Input Class Initialized
INFO - 2025-05-24 13:42:00 --> Language Class Initialized
INFO - 2025-05-24 13:42:00 --> Loader Class Initialized
INFO - 2025-05-24 13:42:00 --> Helper loaded: url_helper
INFO - 2025-05-24 13:42:00 --> Helper loaded: form_helper
INFO - 2025-05-24 13:42:00 --> Database Driver Class Initialized
DEBUG - 2025-05-24 13:42:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 13:42:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 13:42:00 --> Controller Class Initialized
INFO - 2025-05-24 13:42:00 --> Model "User_model" initialized
INFO - 2025-05-24 13:42:00 --> Model "Workout_model" initialized
INFO - 2025-05-24 13:42:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 13:42:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 13:42:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-24 13:42:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 13:42:00 --> Final output sent to browser
DEBUG - 2025-05-24 13:42:00 --> Total execution time: 0.1327
INFO - 2025-05-24 13:42:07 --> Config Class Initialized
INFO - 2025-05-24 13:42:07 --> Hooks Class Initialized
DEBUG - 2025-05-24 13:42:07 --> UTF-8 Support Enabled
INFO - 2025-05-24 13:42:07 --> Utf8 Class Initialized
INFO - 2025-05-24 13:42:07 --> URI Class Initialized
INFO - 2025-05-24 13:42:07 --> Router Class Initialized
INFO - 2025-05-24 13:42:07 --> Output Class Initialized
INFO - 2025-05-24 13:42:07 --> Security Class Initialized
DEBUG - 2025-05-24 13:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 13:42:07 --> Input Class Initialized
INFO - 2025-05-24 13:42:07 --> Language Class Initialized
INFO - 2025-05-24 13:42:07 --> Loader Class Initialized
INFO - 2025-05-24 13:42:07 --> Helper loaded: url_helper
INFO - 2025-05-24 13:42:07 --> Helper loaded: form_helper
INFO - 2025-05-24 13:42:07 --> Database Driver Class Initialized
DEBUG - 2025-05-24 13:42:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 13:42:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 13:42:07 --> Controller Class Initialized
INFO - 2025-05-24 13:42:07 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 13:42:07 --> Model "User_model" initialized
INFO - 2025-05-24 13:42:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 13:42:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 13:42:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-05-24 13:42:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 13:42:07 --> Final output sent to browser
DEBUG - 2025-05-24 13:42:07 --> Total execution time: 0.0772
INFO - 2025-05-24 13:42:31 --> Config Class Initialized
INFO - 2025-05-24 13:42:31 --> Hooks Class Initialized
DEBUG - 2025-05-24 13:42:31 --> UTF-8 Support Enabled
INFO - 2025-05-24 13:42:31 --> Utf8 Class Initialized
INFO - 2025-05-24 13:42:31 --> URI Class Initialized
INFO - 2025-05-24 13:42:31 --> Router Class Initialized
INFO - 2025-05-24 13:42:31 --> Output Class Initialized
INFO - 2025-05-24 13:42:31 --> Security Class Initialized
DEBUG - 2025-05-24 13:42:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 13:42:31 --> Input Class Initialized
INFO - 2025-05-24 13:42:31 --> Language Class Initialized
INFO - 2025-05-24 13:42:31 --> Loader Class Initialized
INFO - 2025-05-24 13:42:31 --> Helper loaded: url_helper
INFO - 2025-05-24 13:42:31 --> Helper loaded: form_helper
INFO - 2025-05-24 13:42:31 --> Database Driver Class Initialized
DEBUG - 2025-05-24 13:42:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 13:42:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 13:42:31 --> Controller Class Initialized
INFO - 2025-05-24 13:42:31 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 13:42:31 --> Model "User_model" initialized
INFO - 2025-05-24 13:42:31 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 13:42:31 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 13:42:31 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-05-24 13:42:31 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 13:42:31 --> Final output sent to browser
DEBUG - 2025-05-24 13:42:31 --> Total execution time: 0.0853
INFO - 2025-05-24 13:42:34 --> Config Class Initialized
INFO - 2025-05-24 13:42:34 --> Hooks Class Initialized
DEBUG - 2025-05-24 13:42:34 --> UTF-8 Support Enabled
INFO - 2025-05-24 13:42:34 --> Utf8 Class Initialized
INFO - 2025-05-24 13:42:34 --> URI Class Initialized
INFO - 2025-05-24 13:42:34 --> Router Class Initialized
INFO - 2025-05-24 13:42:34 --> Output Class Initialized
INFO - 2025-05-24 13:42:34 --> Security Class Initialized
DEBUG - 2025-05-24 13:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 13:42:34 --> Input Class Initialized
INFO - 2025-05-24 13:42:34 --> Language Class Initialized
INFO - 2025-05-24 13:42:34 --> Loader Class Initialized
INFO - 2025-05-24 13:42:34 --> Helper loaded: url_helper
INFO - 2025-05-24 13:42:34 --> Helper loaded: form_helper
INFO - 2025-05-24 13:42:34 --> Database Driver Class Initialized
DEBUG - 2025-05-24 13:42:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 13:42:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 13:42:34 --> Controller Class Initialized
INFO - 2025-05-24 13:42:34 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 13:42:34 --> Model "User_model" initialized
INFO - 2025-05-24 13:42:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 13:42:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 13:42:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/menu.php
INFO - 2025-05-24 13:42:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 13:42:34 --> Final output sent to browser
DEBUG - 2025-05-24 13:42:34 --> Total execution time: 0.0754
INFO - 2025-05-24 13:42:42 --> Config Class Initialized
INFO - 2025-05-24 13:42:42 --> Hooks Class Initialized
DEBUG - 2025-05-24 13:42:42 --> UTF-8 Support Enabled
INFO - 2025-05-24 13:42:42 --> Utf8 Class Initialized
INFO - 2025-05-24 13:42:42 --> URI Class Initialized
INFO - 2025-05-24 13:42:42 --> Router Class Initialized
INFO - 2025-05-24 13:42:42 --> Output Class Initialized
INFO - 2025-05-24 13:42:42 --> Security Class Initialized
DEBUG - 2025-05-24 13:42:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 13:42:42 --> Input Class Initialized
INFO - 2025-05-24 13:42:42 --> Language Class Initialized
INFO - 2025-05-24 13:42:42 --> Loader Class Initialized
INFO - 2025-05-24 13:42:42 --> Helper loaded: url_helper
INFO - 2025-05-24 13:42:42 --> Helper loaded: form_helper
INFO - 2025-05-24 13:42:42 --> Database Driver Class Initialized
DEBUG - 2025-05-24 13:42:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 13:42:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 13:42:42 --> Controller Class Initialized
INFO - 2025-05-24 13:42:42 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 13:42:42 --> Model "User_model" initialized
INFO - 2025-05-24 13:42:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 13:42:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 13:42:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/start.php
INFO - 2025-05-24 13:42:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 13:42:42 --> Final output sent to browser
DEBUG - 2025-05-24 13:42:42 --> Total execution time: 0.0895
INFO - 2025-05-24 13:43:43 --> Config Class Initialized
INFO - 2025-05-24 13:43:43 --> Hooks Class Initialized
DEBUG - 2025-05-24 13:43:43 --> UTF-8 Support Enabled
INFO - 2025-05-24 13:43:43 --> Utf8 Class Initialized
INFO - 2025-05-24 13:43:43 --> URI Class Initialized
INFO - 2025-05-24 13:43:43 --> Router Class Initialized
INFO - 2025-05-24 13:43:43 --> Output Class Initialized
INFO - 2025-05-24 13:43:43 --> Security Class Initialized
DEBUG - 2025-05-24 13:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 13:43:43 --> Input Class Initialized
INFO - 2025-05-24 13:43:43 --> Language Class Initialized
INFO - 2025-05-24 13:43:43 --> Loader Class Initialized
INFO - 2025-05-24 13:43:43 --> Helper loaded: url_helper
INFO - 2025-05-24 13:43:43 --> Helper loaded: form_helper
INFO - 2025-05-24 13:43:43 --> Database Driver Class Initialized
DEBUG - 2025-05-24 13:43:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 13:43:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 13:43:43 --> Controller Class Initialized
INFO - 2025-05-24 13:43:43 --> Model "Progress_model" initialized
INFO - 2025-05-24 13:43:43 --> Model "User_model" initialized
INFO - 2025-05-24 13:43:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 13:43:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 13:43:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-24 13:43:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 13:43:43 --> Final output sent to browser
DEBUG - 2025-05-24 13:43:43 --> Total execution time: 0.0597
INFO - 2025-05-24 13:43:44 --> Config Class Initialized
INFO - 2025-05-24 13:43:44 --> Hooks Class Initialized
DEBUG - 2025-05-24 13:43:44 --> UTF-8 Support Enabled
INFO - 2025-05-24 13:43:44 --> Utf8 Class Initialized
INFO - 2025-05-24 13:43:44 --> URI Class Initialized
INFO - 2025-05-24 13:43:44 --> Router Class Initialized
INFO - 2025-05-24 13:43:44 --> Output Class Initialized
INFO - 2025-05-24 13:43:44 --> Security Class Initialized
DEBUG - 2025-05-24 13:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 13:43:44 --> Input Class Initialized
INFO - 2025-05-24 13:43:44 --> Language Class Initialized
INFO - 2025-05-24 13:43:44 --> Loader Class Initialized
INFO - 2025-05-24 13:43:44 --> Helper loaded: url_helper
INFO - 2025-05-24 13:43:44 --> Helper loaded: form_helper
INFO - 2025-05-24 13:43:44 --> Database Driver Class Initialized
DEBUG - 2025-05-24 13:43:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 13:43:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 13:43:44 --> Controller Class Initialized
INFO - 2025-05-24 13:43:44 --> Model "Progress_model" initialized
INFO - 2025-05-24 13:43:44 --> Model "User_model" initialized
INFO - 2025-05-24 13:43:44 --> Final output sent to browser
DEBUG - 2025-05-24 13:43:44 --> Total execution time: 0.0694
INFO - 2025-05-24 13:43:48 --> Config Class Initialized
INFO - 2025-05-24 13:43:48 --> Hooks Class Initialized
DEBUG - 2025-05-24 13:43:48 --> UTF-8 Support Enabled
INFO - 2025-05-24 13:43:48 --> Utf8 Class Initialized
INFO - 2025-05-24 13:43:48 --> URI Class Initialized
INFO - 2025-05-24 13:43:48 --> Router Class Initialized
INFO - 2025-05-24 13:43:48 --> Output Class Initialized
INFO - 2025-05-24 13:43:48 --> Security Class Initialized
DEBUG - 2025-05-24 13:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 13:43:48 --> Input Class Initialized
INFO - 2025-05-24 13:43:48 --> Language Class Initialized
INFO - 2025-05-24 13:43:48 --> Loader Class Initialized
INFO - 2025-05-24 13:43:48 --> Helper loaded: url_helper
INFO - 2025-05-24 13:43:48 --> Helper loaded: form_helper
INFO - 2025-05-24 13:43:48 --> Database Driver Class Initialized
DEBUG - 2025-05-24 13:43:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 13:43:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 13:43:48 --> Controller Class Initialized
INFO - 2025-05-24 13:43:48 --> Model "Progress_model" initialized
INFO - 2025-05-24 13:43:48 --> Model "User_model" initialized
INFO - 2025-05-24 13:43:48 --> Final output sent to browser
DEBUG - 2025-05-24 13:43:48 --> Total execution time: 0.0672
INFO - 2025-05-24 13:43:59 --> Config Class Initialized
INFO - 2025-05-24 13:43:59 --> Hooks Class Initialized
DEBUG - 2025-05-24 13:43:59 --> UTF-8 Support Enabled
INFO - 2025-05-24 13:43:59 --> Utf8 Class Initialized
INFO - 2025-05-24 13:43:59 --> URI Class Initialized
INFO - 2025-05-24 13:43:59 --> Router Class Initialized
INFO - 2025-05-24 13:43:59 --> Output Class Initialized
INFO - 2025-05-24 13:43:59 --> Security Class Initialized
DEBUG - 2025-05-24 13:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 13:43:59 --> Input Class Initialized
INFO - 2025-05-24 13:43:59 --> Language Class Initialized
INFO - 2025-05-24 13:43:59 --> Loader Class Initialized
INFO - 2025-05-24 13:43:59 --> Helper loaded: url_helper
INFO - 2025-05-24 13:43:59 --> Helper loaded: form_helper
INFO - 2025-05-24 13:43:59 --> Database Driver Class Initialized
DEBUG - 2025-05-24 13:43:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 13:43:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 13:43:59 --> Controller Class Initialized
INFO - 2025-05-24 13:43:59 --> Model "Progress_model" initialized
INFO - 2025-05-24 13:43:59 --> Model "User_model" initialized
INFO - 2025-05-24 13:43:59 --> Final output sent to browser
DEBUG - 2025-05-24 13:43:59 --> Total execution time: 0.0621
INFO - 2025-05-24 14:31:24 --> Config Class Initialized
INFO - 2025-05-24 14:31:24 --> Hooks Class Initialized
DEBUG - 2025-05-24 14:31:24 --> UTF-8 Support Enabled
INFO - 2025-05-24 14:31:24 --> Utf8 Class Initialized
INFO - 2025-05-24 14:31:24 --> URI Class Initialized
INFO - 2025-05-24 14:31:24 --> Router Class Initialized
INFO - 2025-05-24 14:31:24 --> Output Class Initialized
INFO - 2025-05-24 14:31:24 --> Security Class Initialized
DEBUG - 2025-05-24 14:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 14:31:24 --> Input Class Initialized
INFO - 2025-05-24 14:31:24 --> Language Class Initialized
INFO - 2025-05-24 14:31:24 --> Loader Class Initialized
INFO - 2025-05-24 14:31:24 --> Helper loaded: url_helper
INFO - 2025-05-24 14:31:25 --> Helper loaded: form_helper
INFO - 2025-05-24 14:31:25 --> Database Driver Class Initialized
DEBUG - 2025-05-24 14:31:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 14:31:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 14:31:25 --> Controller Class Initialized
INFO - 2025-05-24 14:31:25 --> Model "Progress_model" initialized
INFO - 2025-05-24 14:31:25 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 14:31:25 --> Model "User_model" initialized
INFO - 2025-05-24 14:31:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 14:31:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 14:31:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-24 14:31:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 14:31:25 --> Final output sent to browser
DEBUG - 2025-05-24 14:31:25 --> Total execution time: 1.8665
INFO - 2025-05-24 14:31:26 --> Config Class Initialized
INFO - 2025-05-24 14:31:26 --> Hooks Class Initialized
DEBUG - 2025-05-24 14:31:26 --> UTF-8 Support Enabled
INFO - 2025-05-24 14:31:26 --> Utf8 Class Initialized
INFO - 2025-05-24 14:31:26 --> URI Class Initialized
INFO - 2025-05-24 14:31:26 --> Router Class Initialized
INFO - 2025-05-24 14:31:26 --> Output Class Initialized
INFO - 2025-05-24 14:31:26 --> Security Class Initialized
DEBUG - 2025-05-24 14:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 14:31:26 --> Input Class Initialized
INFO - 2025-05-24 14:31:26 --> Language Class Initialized
INFO - 2025-05-24 14:31:26 --> Loader Class Initialized
INFO - 2025-05-24 14:31:26 --> Helper loaded: url_helper
INFO - 2025-05-24 14:31:26 --> Helper loaded: form_helper
INFO - 2025-05-24 14:31:26 --> Database Driver Class Initialized
DEBUG - 2025-05-24 14:31:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 14:31:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 14:31:26 --> Controller Class Initialized
INFO - 2025-05-24 14:31:26 --> Model "Progress_model" initialized
INFO - 2025-05-24 14:31:26 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 14:31:26 --> Model "User_model" initialized
ERROR - 2025-05-24 14:31:26 --> Severity: error --> Exception: Call to undefined method Olahraga_model::get_selesai_progress() C:\laragon\www\Project\fitnessrecord\application\controllers\Progress.php 40
INFO - 2025-05-24 14:38:21 --> Config Class Initialized
INFO - 2025-05-24 14:38:21 --> Hooks Class Initialized
DEBUG - 2025-05-24 14:38:21 --> UTF-8 Support Enabled
INFO - 2025-05-24 14:38:21 --> Utf8 Class Initialized
INFO - 2025-05-24 14:38:21 --> URI Class Initialized
INFO - 2025-05-24 14:38:21 --> Router Class Initialized
INFO - 2025-05-24 14:38:21 --> Output Class Initialized
INFO - 2025-05-24 14:38:21 --> Security Class Initialized
DEBUG - 2025-05-24 14:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 14:38:21 --> Input Class Initialized
INFO - 2025-05-24 14:38:21 --> Language Class Initialized
INFO - 2025-05-24 14:38:21 --> Loader Class Initialized
INFO - 2025-05-24 14:38:21 --> Helper loaded: url_helper
INFO - 2025-05-24 14:38:21 --> Helper loaded: form_helper
INFO - 2025-05-24 14:38:21 --> Database Driver Class Initialized
DEBUG - 2025-05-24 14:38:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 14:38:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 14:38:21 --> Controller Class Initialized
INFO - 2025-05-24 14:38:21 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 14:38:21 --> Model "User_model" initialized
INFO - 2025-05-24 14:38:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 14:38:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 14:38:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-05-24 14:38:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 14:38:21 --> Final output sent to browser
DEBUG - 2025-05-24 14:38:21 --> Total execution time: 0.0845
INFO - 2025-05-24 14:38:24 --> Config Class Initialized
INFO - 2025-05-24 14:38:24 --> Hooks Class Initialized
DEBUG - 2025-05-24 14:38:24 --> UTF-8 Support Enabled
INFO - 2025-05-24 14:38:24 --> Utf8 Class Initialized
INFO - 2025-05-24 14:38:24 --> URI Class Initialized
INFO - 2025-05-24 14:38:24 --> Router Class Initialized
INFO - 2025-05-24 14:38:24 --> Output Class Initialized
INFO - 2025-05-24 14:38:24 --> Security Class Initialized
DEBUG - 2025-05-24 14:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 14:38:24 --> Input Class Initialized
INFO - 2025-05-24 14:38:24 --> Language Class Initialized
INFO - 2025-05-24 14:38:24 --> Loader Class Initialized
INFO - 2025-05-24 14:38:24 --> Helper loaded: url_helper
INFO - 2025-05-24 14:38:24 --> Helper loaded: form_helper
INFO - 2025-05-24 14:38:24 --> Database Driver Class Initialized
DEBUG - 2025-05-24 14:38:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 14:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 14:38:24 --> Controller Class Initialized
INFO - 2025-05-24 14:38:24 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 14:38:24 --> Model "User_model" initialized
INFO - 2025-05-24 14:38:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 14:38:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 14:38:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-05-24 14:38:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 14:38:24 --> Final output sent to browser
DEBUG - 2025-05-24 14:38:24 --> Total execution time: 0.0985
INFO - 2025-05-24 14:38:25 --> Config Class Initialized
INFO - 2025-05-24 14:38:25 --> Hooks Class Initialized
DEBUG - 2025-05-24 14:38:25 --> UTF-8 Support Enabled
INFO - 2025-05-24 14:38:25 --> Utf8 Class Initialized
INFO - 2025-05-24 14:38:25 --> URI Class Initialized
INFO - 2025-05-24 14:38:25 --> Router Class Initialized
INFO - 2025-05-24 14:38:25 --> Output Class Initialized
INFO - 2025-05-24 14:38:25 --> Security Class Initialized
DEBUG - 2025-05-24 14:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 14:38:25 --> Input Class Initialized
INFO - 2025-05-24 14:38:25 --> Language Class Initialized
INFO - 2025-05-24 14:38:25 --> Loader Class Initialized
INFO - 2025-05-24 14:38:25 --> Helper loaded: url_helper
INFO - 2025-05-24 14:38:25 --> Helper loaded: form_helper
INFO - 2025-05-24 14:38:25 --> Database Driver Class Initialized
DEBUG - 2025-05-24 14:38:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 14:38:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 14:38:25 --> Controller Class Initialized
INFO - 2025-05-24 14:38:25 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 14:38:25 --> Model "User_model" initialized
INFO - 2025-05-24 14:38:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 14:38:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 14:38:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/menu.php
INFO - 2025-05-24 14:38:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 14:38:25 --> Final output sent to browser
DEBUG - 2025-05-24 14:38:25 --> Total execution time: 0.1127
INFO - 2025-05-24 15:04:47 --> Config Class Initialized
INFO - 2025-05-24 15:04:47 --> Hooks Class Initialized
DEBUG - 2025-05-24 15:04:47 --> UTF-8 Support Enabled
INFO - 2025-05-24 15:04:47 --> Utf8 Class Initialized
INFO - 2025-05-24 15:04:47 --> URI Class Initialized
INFO - 2025-05-24 15:04:47 --> Router Class Initialized
INFO - 2025-05-24 15:04:47 --> Output Class Initialized
INFO - 2025-05-24 15:04:47 --> Security Class Initialized
DEBUG - 2025-05-24 15:04:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 15:04:47 --> Input Class Initialized
INFO - 2025-05-24 15:04:47 --> Language Class Initialized
INFO - 2025-05-24 15:04:47 --> Loader Class Initialized
INFO - 2025-05-24 15:04:47 --> Helper loaded: url_helper
INFO - 2025-05-24 15:04:47 --> Helper loaded: form_helper
INFO - 2025-05-24 15:04:47 --> Database Driver Class Initialized
DEBUG - 2025-05-24 15:04:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 15:04:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 15:04:47 --> Controller Class Initialized
INFO - 2025-05-24 15:04:47 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 15:04:47 --> Model "User_model" initialized
INFO - 2025-05-24 15:04:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 15:04:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 15:04:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/menu.php
INFO - 2025-05-24 15:04:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 15:04:47 --> Final output sent to browser
DEBUG - 2025-05-24 15:04:47 --> Total execution time: 0.0783
INFO - 2025-05-24 15:04:50 --> Config Class Initialized
INFO - 2025-05-24 15:04:50 --> Hooks Class Initialized
DEBUG - 2025-05-24 15:04:50 --> UTF-8 Support Enabled
INFO - 2025-05-24 15:04:50 --> Utf8 Class Initialized
INFO - 2025-05-24 15:04:50 --> URI Class Initialized
INFO - 2025-05-24 15:04:50 --> Router Class Initialized
INFO - 2025-05-24 15:04:50 --> Output Class Initialized
INFO - 2025-05-24 15:04:50 --> Security Class Initialized
DEBUG - 2025-05-24 15:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 15:04:50 --> Input Class Initialized
INFO - 2025-05-24 15:04:50 --> Language Class Initialized
INFO - 2025-05-24 15:04:50 --> Loader Class Initialized
INFO - 2025-05-24 15:04:50 --> Helper loaded: url_helper
INFO - 2025-05-24 15:04:50 --> Helper loaded: form_helper
INFO - 2025-05-24 15:04:50 --> Database Driver Class Initialized
DEBUG - 2025-05-24 15:04:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 15:04:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 15:04:50 --> Controller Class Initialized
INFO - 2025-05-24 15:04:50 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 15:04:50 --> Model "User_model" initialized
INFO - 2025-05-24 15:04:50 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 15:04:50 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 15:04:50 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/start.php
INFO - 2025-05-24 15:04:50 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 15:04:50 --> Final output sent to browser
DEBUG - 2025-05-24 15:04:50 --> Total execution time: 0.0775
INFO - 2025-05-24 15:05:01 --> Config Class Initialized
INFO - 2025-05-24 15:05:01 --> Hooks Class Initialized
DEBUG - 2025-05-24 15:05:01 --> UTF-8 Support Enabled
INFO - 2025-05-24 15:05:01 --> Utf8 Class Initialized
INFO - 2025-05-24 15:05:01 --> URI Class Initialized
INFO - 2025-05-24 15:05:01 --> Router Class Initialized
INFO - 2025-05-24 15:05:01 --> Output Class Initialized
INFO - 2025-05-24 15:05:01 --> Security Class Initialized
DEBUG - 2025-05-24 15:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 15:05:01 --> Input Class Initialized
INFO - 2025-05-24 15:05:01 --> Language Class Initialized
ERROR - 2025-05-24 15:05:01 --> 404 Page Not Found: Progress/save
INFO - 2025-05-24 15:05:06 --> Config Class Initialized
INFO - 2025-05-24 15:05:06 --> Hooks Class Initialized
DEBUG - 2025-05-24 15:05:06 --> UTF-8 Support Enabled
INFO - 2025-05-24 15:05:06 --> Utf8 Class Initialized
INFO - 2025-05-24 15:05:06 --> URI Class Initialized
INFO - 2025-05-24 15:05:06 --> Router Class Initialized
INFO - 2025-05-24 15:05:06 --> Output Class Initialized
INFO - 2025-05-24 15:05:06 --> Security Class Initialized
DEBUG - 2025-05-24 15:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 15:05:06 --> Input Class Initialized
INFO - 2025-05-24 15:05:06 --> Language Class Initialized
INFO - 2025-05-24 15:05:06 --> Loader Class Initialized
INFO - 2025-05-24 15:05:06 --> Helper loaded: url_helper
INFO - 2025-05-24 15:05:06 --> Helper loaded: form_helper
INFO - 2025-05-24 15:05:06 --> Database Driver Class Initialized
DEBUG - 2025-05-24 15:05:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 15:05:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 15:05:06 --> Controller Class Initialized
INFO - 2025-05-24 15:05:06 --> Model "Progress_model" initialized
INFO - 2025-05-24 15:05:06 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 15:05:06 --> Model "User_model" initialized
INFO - 2025-05-24 15:05:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 15:05:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 15:05:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-24 15:05:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 15:05:06 --> Final output sent to browser
DEBUG - 2025-05-24 15:05:06 --> Total execution time: 0.0947
INFO - 2025-05-24 15:05:06 --> Config Class Initialized
INFO - 2025-05-24 15:05:06 --> Hooks Class Initialized
DEBUG - 2025-05-24 15:05:06 --> UTF-8 Support Enabled
INFO - 2025-05-24 15:05:06 --> Utf8 Class Initialized
INFO - 2025-05-24 15:05:06 --> URI Class Initialized
INFO - 2025-05-24 15:05:06 --> Router Class Initialized
INFO - 2025-05-24 15:05:06 --> Output Class Initialized
INFO - 2025-05-24 15:05:06 --> Security Class Initialized
DEBUG - 2025-05-24 15:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 15:05:06 --> Input Class Initialized
INFO - 2025-05-24 15:05:06 --> Language Class Initialized
INFO - 2025-05-24 15:05:06 --> Loader Class Initialized
INFO - 2025-05-24 15:05:06 --> Helper loaded: url_helper
INFO - 2025-05-24 15:05:06 --> Helper loaded: form_helper
INFO - 2025-05-24 15:05:06 --> Database Driver Class Initialized
DEBUG - 2025-05-24 15:05:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 15:05:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 15:05:06 --> Controller Class Initialized
INFO - 2025-05-24 15:05:06 --> Model "Progress_model" initialized
INFO - 2025-05-24 15:05:06 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 15:05:06 --> Model "User_model" initialized
INFO - 2025-05-24 15:05:06 --> Final output sent to browser
DEBUG - 2025-05-24 15:05:06 --> Total execution time: 0.0616
INFO - 2025-05-24 15:05:56 --> Config Class Initialized
INFO - 2025-05-24 15:05:56 --> Hooks Class Initialized
DEBUG - 2025-05-24 15:05:56 --> UTF-8 Support Enabled
INFO - 2025-05-24 15:05:56 --> Utf8 Class Initialized
INFO - 2025-05-24 15:05:56 --> URI Class Initialized
INFO - 2025-05-24 15:05:56 --> Router Class Initialized
INFO - 2025-05-24 15:05:56 --> Output Class Initialized
INFO - 2025-05-24 15:05:56 --> Security Class Initialized
DEBUG - 2025-05-24 15:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 15:05:56 --> Input Class Initialized
INFO - 2025-05-24 15:05:56 --> Language Class Initialized
INFO - 2025-05-24 15:05:56 --> Loader Class Initialized
INFO - 2025-05-24 15:05:56 --> Helper loaded: url_helper
INFO - 2025-05-24 15:05:56 --> Helper loaded: form_helper
INFO - 2025-05-24 15:05:56 --> Database Driver Class Initialized
DEBUG - 2025-05-24 15:05:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 15:05:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 15:05:56 --> Controller Class Initialized
INFO - 2025-05-24 15:05:56 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 15:05:56 --> Model "User_model" initialized
INFO - 2025-05-24 15:05:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 15:05:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 15:05:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-05-24 15:05:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 15:05:56 --> Final output sent to browser
DEBUG - 2025-05-24 15:05:56 --> Total execution time: 0.0750
INFO - 2025-05-24 15:05:57 --> Config Class Initialized
INFO - 2025-05-24 15:05:57 --> Hooks Class Initialized
DEBUG - 2025-05-24 15:05:57 --> UTF-8 Support Enabled
INFO - 2025-05-24 15:05:57 --> Utf8 Class Initialized
INFO - 2025-05-24 15:05:57 --> URI Class Initialized
INFO - 2025-05-24 15:05:57 --> Router Class Initialized
INFO - 2025-05-24 15:05:57 --> Output Class Initialized
INFO - 2025-05-24 15:05:57 --> Security Class Initialized
DEBUG - 2025-05-24 15:05:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 15:05:57 --> Input Class Initialized
INFO - 2025-05-24 15:05:57 --> Language Class Initialized
INFO - 2025-05-24 15:05:57 --> Loader Class Initialized
INFO - 2025-05-24 15:05:57 --> Helper loaded: url_helper
INFO - 2025-05-24 15:05:57 --> Helper loaded: form_helper
INFO - 2025-05-24 15:05:57 --> Database Driver Class Initialized
DEBUG - 2025-05-24 15:05:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 15:05:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 15:05:57 --> Controller Class Initialized
INFO - 2025-05-24 15:05:57 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 15:05:57 --> Model "User_model" initialized
INFO - 2025-05-24 15:05:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 15:05:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 15:05:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-05-24 15:05:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 15:05:57 --> Final output sent to browser
DEBUG - 2025-05-24 15:05:57 --> Total execution time: 0.0637
INFO - 2025-05-24 15:05:59 --> Config Class Initialized
INFO - 2025-05-24 15:05:59 --> Hooks Class Initialized
DEBUG - 2025-05-24 15:05:59 --> UTF-8 Support Enabled
INFO - 2025-05-24 15:05:59 --> Utf8 Class Initialized
INFO - 2025-05-24 15:05:59 --> URI Class Initialized
INFO - 2025-05-24 15:05:59 --> Router Class Initialized
INFO - 2025-05-24 15:05:59 --> Output Class Initialized
INFO - 2025-05-24 15:05:59 --> Security Class Initialized
DEBUG - 2025-05-24 15:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 15:05:59 --> Input Class Initialized
INFO - 2025-05-24 15:05:59 --> Language Class Initialized
INFO - 2025-05-24 15:05:59 --> Loader Class Initialized
INFO - 2025-05-24 15:05:59 --> Helper loaded: url_helper
INFO - 2025-05-24 15:05:59 --> Helper loaded: form_helper
INFO - 2025-05-24 15:05:59 --> Database Driver Class Initialized
DEBUG - 2025-05-24 15:05:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 15:05:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 15:05:59 --> Controller Class Initialized
INFO - 2025-05-24 15:05:59 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 15:05:59 --> Model "User_model" initialized
INFO - 2025-05-24 15:05:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 15:05:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 15:05:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/menu.php
INFO - 2025-05-24 15:05:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 15:05:59 --> Final output sent to browser
DEBUG - 2025-05-24 15:05:59 --> Total execution time: 0.0792
INFO - 2025-05-24 15:06:00 --> Config Class Initialized
INFO - 2025-05-24 15:06:00 --> Hooks Class Initialized
DEBUG - 2025-05-24 15:06:00 --> UTF-8 Support Enabled
INFO - 2025-05-24 15:06:00 --> Utf8 Class Initialized
INFO - 2025-05-24 15:06:00 --> URI Class Initialized
INFO - 2025-05-24 15:06:00 --> Router Class Initialized
INFO - 2025-05-24 15:06:00 --> Output Class Initialized
INFO - 2025-05-24 15:06:00 --> Security Class Initialized
DEBUG - 2025-05-24 15:06:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 15:06:00 --> Input Class Initialized
INFO - 2025-05-24 15:06:00 --> Language Class Initialized
INFO - 2025-05-24 15:06:00 --> Loader Class Initialized
INFO - 2025-05-24 15:06:00 --> Helper loaded: url_helper
INFO - 2025-05-24 15:06:00 --> Helper loaded: form_helper
INFO - 2025-05-24 15:06:00 --> Database Driver Class Initialized
DEBUG - 2025-05-24 15:06:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 15:06:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 15:06:00 --> Controller Class Initialized
INFO - 2025-05-24 15:06:00 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 15:06:00 --> Model "User_model" initialized
INFO - 2025-05-24 15:06:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 15:06:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 15:06:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/start.php
INFO - 2025-05-24 15:06:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 15:06:00 --> Final output sent to browser
DEBUG - 2025-05-24 15:06:00 --> Total execution time: 0.0819
INFO - 2025-05-24 15:06:16 --> Config Class Initialized
INFO - 2025-05-24 15:06:16 --> Hooks Class Initialized
DEBUG - 2025-05-24 15:06:16 --> UTF-8 Support Enabled
INFO - 2025-05-24 15:06:16 --> Utf8 Class Initialized
INFO - 2025-05-24 15:06:16 --> URI Class Initialized
INFO - 2025-05-24 15:06:16 --> Router Class Initialized
INFO - 2025-05-24 15:06:16 --> Output Class Initialized
INFO - 2025-05-24 15:06:16 --> Security Class Initialized
DEBUG - 2025-05-24 15:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 15:06:16 --> Input Class Initialized
INFO - 2025-05-24 15:06:16 --> Language Class Initialized
INFO - 2025-05-24 15:06:16 --> Loader Class Initialized
INFO - 2025-05-24 15:06:16 --> Helper loaded: url_helper
INFO - 2025-05-24 15:06:16 --> Helper loaded: form_helper
INFO - 2025-05-24 15:06:16 --> Database Driver Class Initialized
DEBUG - 2025-05-24 15:06:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 15:06:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 15:06:16 --> Controller Class Initialized
INFO - 2025-05-24 15:06:16 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 15:06:16 --> Model "User_model" initialized
INFO - 2025-05-24 15:06:16 --> Final output sent to browser
DEBUG - 2025-05-24 15:06:16 --> Total execution time: 0.0702
INFO - 2025-05-24 15:06:26 --> Config Class Initialized
INFO - 2025-05-24 15:06:26 --> Hooks Class Initialized
DEBUG - 2025-05-24 15:06:26 --> UTF-8 Support Enabled
INFO - 2025-05-24 15:06:26 --> Utf8 Class Initialized
INFO - 2025-05-24 15:06:26 --> URI Class Initialized
INFO - 2025-05-24 15:06:26 --> Router Class Initialized
INFO - 2025-05-24 15:06:26 --> Output Class Initialized
INFO - 2025-05-24 15:06:26 --> Security Class Initialized
DEBUG - 2025-05-24 15:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 15:06:26 --> Input Class Initialized
INFO - 2025-05-24 15:06:26 --> Language Class Initialized
INFO - 2025-05-24 15:06:27 --> Loader Class Initialized
INFO - 2025-05-24 15:06:27 --> Helper loaded: url_helper
INFO - 2025-05-24 15:06:27 --> Helper loaded: form_helper
INFO - 2025-05-24 15:06:27 --> Database Driver Class Initialized
DEBUG - 2025-05-24 15:06:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 15:06:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 15:06:27 --> Controller Class Initialized
INFO - 2025-05-24 15:06:27 --> Model "Progress_model" initialized
INFO - 2025-05-24 15:06:27 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 15:06:27 --> Model "User_model" initialized
INFO - 2025-05-24 15:06:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 15:06:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 15:06:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-24 15:06:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 15:06:27 --> Final output sent to browser
DEBUG - 2025-05-24 15:06:27 --> Total execution time: 0.0681
INFO - 2025-05-24 15:06:27 --> Config Class Initialized
INFO - 2025-05-24 15:06:27 --> Hooks Class Initialized
DEBUG - 2025-05-24 15:06:27 --> UTF-8 Support Enabled
INFO - 2025-05-24 15:06:27 --> Utf8 Class Initialized
INFO - 2025-05-24 15:06:27 --> URI Class Initialized
INFO - 2025-05-24 15:06:27 --> Router Class Initialized
INFO - 2025-05-24 15:06:27 --> Output Class Initialized
INFO - 2025-05-24 15:06:27 --> Security Class Initialized
DEBUG - 2025-05-24 15:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 15:06:27 --> Input Class Initialized
INFO - 2025-05-24 15:06:27 --> Language Class Initialized
INFO - 2025-05-24 15:06:27 --> Loader Class Initialized
INFO - 2025-05-24 15:06:27 --> Helper loaded: url_helper
INFO - 2025-05-24 15:06:27 --> Helper loaded: form_helper
INFO - 2025-05-24 15:06:27 --> Database Driver Class Initialized
DEBUG - 2025-05-24 15:06:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 15:06:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 15:06:27 --> Controller Class Initialized
INFO - 2025-05-24 15:06:27 --> Model "Progress_model" initialized
INFO - 2025-05-24 15:06:27 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 15:06:27 --> Model "User_model" initialized
INFO - 2025-05-24 15:06:27 --> Final output sent to browser
DEBUG - 2025-05-24 15:06:27 --> Total execution time: 0.0793
INFO - 2025-05-24 15:06:32 --> Config Class Initialized
INFO - 2025-05-24 15:06:32 --> Hooks Class Initialized
DEBUG - 2025-05-24 15:06:32 --> UTF-8 Support Enabled
INFO - 2025-05-24 15:06:32 --> Utf8 Class Initialized
INFO - 2025-05-24 15:06:32 --> URI Class Initialized
INFO - 2025-05-24 15:06:32 --> Router Class Initialized
INFO - 2025-05-24 15:06:32 --> Output Class Initialized
INFO - 2025-05-24 15:06:32 --> Security Class Initialized
DEBUG - 2025-05-24 15:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 15:06:32 --> Input Class Initialized
INFO - 2025-05-24 15:06:32 --> Language Class Initialized
INFO - 2025-05-24 15:06:32 --> Loader Class Initialized
INFO - 2025-05-24 15:06:32 --> Helper loaded: url_helper
INFO - 2025-05-24 15:06:32 --> Helper loaded: form_helper
INFO - 2025-05-24 15:06:32 --> Database Driver Class Initialized
DEBUG - 2025-05-24 15:06:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 15:06:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 15:06:32 --> Controller Class Initialized
INFO - 2025-05-24 15:06:32 --> Model "Progress_model" initialized
INFO - 2025-05-24 15:06:32 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 15:06:32 --> Model "User_model" initialized
INFO - 2025-05-24 15:06:32 --> Final output sent to browser
DEBUG - 2025-05-24 15:06:32 --> Total execution time: 0.0562
INFO - 2025-05-24 15:07:59 --> Config Class Initialized
INFO - 2025-05-24 15:07:59 --> Hooks Class Initialized
DEBUG - 2025-05-24 15:07:59 --> UTF-8 Support Enabled
INFO - 2025-05-24 15:07:59 --> Utf8 Class Initialized
INFO - 2025-05-24 15:07:59 --> URI Class Initialized
INFO - 2025-05-24 15:07:59 --> Router Class Initialized
INFO - 2025-05-24 15:07:59 --> Output Class Initialized
INFO - 2025-05-24 15:07:59 --> Security Class Initialized
DEBUG - 2025-05-24 15:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 15:07:59 --> Input Class Initialized
INFO - 2025-05-24 15:07:59 --> Language Class Initialized
INFO - 2025-05-24 15:07:59 --> Loader Class Initialized
INFO - 2025-05-24 15:07:59 --> Helper loaded: url_helper
INFO - 2025-05-24 15:07:59 --> Helper loaded: form_helper
INFO - 2025-05-24 15:07:59 --> Database Driver Class Initialized
DEBUG - 2025-05-24 15:07:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 15:07:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 15:07:59 --> Controller Class Initialized
INFO - 2025-05-24 15:07:59 --> Model "Progress_model" initialized
INFO - 2025-05-24 15:07:59 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 15:07:59 --> Model "User_model" initialized
INFO - 2025-05-24 15:07:59 --> Final output sent to browser
DEBUG - 2025-05-24 15:07:59 --> Total execution time: 0.0711
INFO - 2025-05-24 15:10:30 --> Config Class Initialized
INFO - 2025-05-24 15:10:30 --> Hooks Class Initialized
DEBUG - 2025-05-24 15:10:30 --> UTF-8 Support Enabled
INFO - 2025-05-24 15:10:30 --> Utf8 Class Initialized
INFO - 2025-05-24 15:10:30 --> URI Class Initialized
INFO - 2025-05-24 15:10:30 --> Router Class Initialized
INFO - 2025-05-24 15:10:30 --> Output Class Initialized
INFO - 2025-05-24 15:10:30 --> Security Class Initialized
DEBUG - 2025-05-24 15:10:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 15:10:30 --> Input Class Initialized
INFO - 2025-05-24 15:10:30 --> Language Class Initialized
INFO - 2025-05-24 15:10:30 --> Loader Class Initialized
INFO - 2025-05-24 15:10:30 --> Helper loaded: url_helper
INFO - 2025-05-24 15:10:30 --> Helper loaded: form_helper
INFO - 2025-05-24 15:10:30 --> Database Driver Class Initialized
DEBUG - 2025-05-24 15:10:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 15:10:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 15:10:30 --> Controller Class Initialized
INFO - 2025-05-24 15:10:30 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 15:10:30 --> Model "User_model" initialized
INFO - 2025-05-24 15:10:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 15:10:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 15:10:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-05-24 15:10:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 15:10:30 --> Final output sent to browser
DEBUG - 2025-05-24 15:10:30 --> Total execution time: 0.0799
INFO - 2025-05-24 15:10:32 --> Config Class Initialized
INFO - 2025-05-24 15:10:32 --> Hooks Class Initialized
DEBUG - 2025-05-24 15:10:32 --> UTF-8 Support Enabled
INFO - 2025-05-24 15:10:32 --> Utf8 Class Initialized
INFO - 2025-05-24 15:10:32 --> URI Class Initialized
INFO - 2025-05-24 15:10:32 --> Router Class Initialized
INFO - 2025-05-24 15:10:32 --> Output Class Initialized
INFO - 2025-05-24 15:10:32 --> Security Class Initialized
DEBUG - 2025-05-24 15:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 15:10:32 --> Input Class Initialized
INFO - 2025-05-24 15:10:32 --> Language Class Initialized
INFO - 2025-05-24 15:10:32 --> Loader Class Initialized
INFO - 2025-05-24 15:10:32 --> Helper loaded: url_helper
INFO - 2025-05-24 15:10:32 --> Helper loaded: form_helper
INFO - 2025-05-24 15:10:32 --> Database Driver Class Initialized
DEBUG - 2025-05-24 15:10:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 15:10:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 15:10:32 --> Controller Class Initialized
INFO - 2025-05-24 15:10:32 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 15:10:32 --> Model "User_model" initialized
INFO - 2025-05-24 15:10:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 15:10:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 15:10:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-05-24 15:10:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 15:10:32 --> Final output sent to browser
DEBUG - 2025-05-24 15:10:32 --> Total execution time: 0.0710
INFO - 2025-05-24 15:10:33 --> Config Class Initialized
INFO - 2025-05-24 15:10:33 --> Hooks Class Initialized
DEBUG - 2025-05-24 15:10:33 --> UTF-8 Support Enabled
INFO - 2025-05-24 15:10:33 --> Utf8 Class Initialized
INFO - 2025-05-24 15:10:33 --> URI Class Initialized
INFO - 2025-05-24 15:10:33 --> Router Class Initialized
INFO - 2025-05-24 15:10:33 --> Output Class Initialized
INFO - 2025-05-24 15:10:33 --> Security Class Initialized
DEBUG - 2025-05-24 15:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 15:10:33 --> Input Class Initialized
INFO - 2025-05-24 15:10:33 --> Language Class Initialized
INFO - 2025-05-24 15:10:33 --> Loader Class Initialized
INFO - 2025-05-24 15:10:33 --> Helper loaded: url_helper
INFO - 2025-05-24 15:10:33 --> Helper loaded: form_helper
INFO - 2025-05-24 15:10:33 --> Database Driver Class Initialized
DEBUG - 2025-05-24 15:10:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 15:10:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 15:10:34 --> Controller Class Initialized
INFO - 2025-05-24 15:10:34 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 15:10:34 --> Model "User_model" initialized
INFO - 2025-05-24 15:10:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 15:10:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 15:10:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/menu.php
INFO - 2025-05-24 15:10:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 15:10:34 --> Final output sent to browser
DEBUG - 2025-05-24 15:10:34 --> Total execution time: 0.0800
INFO - 2025-05-24 15:51:05 --> Config Class Initialized
INFO - 2025-05-24 15:51:05 --> Hooks Class Initialized
DEBUG - 2025-05-24 15:51:05 --> UTF-8 Support Enabled
INFO - 2025-05-24 15:51:05 --> Utf8 Class Initialized
INFO - 2025-05-24 15:51:05 --> URI Class Initialized
INFO - 2025-05-24 15:51:05 --> Router Class Initialized
INFO - 2025-05-24 15:51:05 --> Output Class Initialized
INFO - 2025-05-24 15:51:05 --> Security Class Initialized
DEBUG - 2025-05-24 15:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 15:51:05 --> Input Class Initialized
INFO - 2025-05-24 15:51:05 --> Language Class Initialized
INFO - 2025-05-24 15:51:05 --> Loader Class Initialized
INFO - 2025-05-24 15:51:05 --> Helper loaded: url_helper
INFO - 2025-05-24 15:51:05 --> Helper loaded: form_helper
INFO - 2025-05-24 15:51:05 --> Database Driver Class Initialized
DEBUG - 2025-05-24 15:51:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 15:51:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 15:51:05 --> Controller Class Initialized
INFO - 2025-05-24 15:51:05 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 15:51:05 --> Model "User_model" initialized
INFO - 2025-05-24 15:51:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 15:51:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 15:51:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/menu.php
INFO - 2025-05-24 15:51:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 15:51:05 --> Final output sent to browser
DEBUG - 2025-05-24 15:51:05 --> Total execution time: 0.0836
INFO - 2025-05-24 15:51:09 --> Config Class Initialized
INFO - 2025-05-24 15:51:09 --> Hooks Class Initialized
DEBUG - 2025-05-24 15:51:09 --> UTF-8 Support Enabled
INFO - 2025-05-24 15:51:09 --> Utf8 Class Initialized
INFO - 2025-05-24 15:51:09 --> URI Class Initialized
INFO - 2025-05-24 15:51:09 --> Router Class Initialized
INFO - 2025-05-24 15:51:09 --> Output Class Initialized
INFO - 2025-05-24 15:51:09 --> Security Class Initialized
DEBUG - 2025-05-24 15:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 15:51:09 --> Input Class Initialized
INFO - 2025-05-24 15:51:09 --> Language Class Initialized
INFO - 2025-05-24 15:51:09 --> Loader Class Initialized
INFO - 2025-05-24 15:51:09 --> Helper loaded: url_helper
INFO - 2025-05-24 15:51:09 --> Helper loaded: form_helper
INFO - 2025-05-24 15:51:09 --> Database Driver Class Initialized
DEBUG - 2025-05-24 15:51:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 15:51:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 15:51:09 --> Controller Class Initialized
INFO - 2025-05-24 15:51:09 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 15:51:09 --> Model "User_model" initialized
INFO - 2025-05-24 15:51:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 15:51:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 15:51:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/start.php
INFO - 2025-05-24 15:51:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 15:51:09 --> Final output sent to browser
DEBUG - 2025-05-24 15:51:09 --> Total execution time: 0.0819
INFO - 2025-05-24 15:51:19 --> Config Class Initialized
INFO - 2025-05-24 15:51:19 --> Hooks Class Initialized
DEBUG - 2025-05-24 15:51:19 --> UTF-8 Support Enabled
INFO - 2025-05-24 15:51:19 --> Utf8 Class Initialized
INFO - 2025-05-24 15:51:19 --> URI Class Initialized
INFO - 2025-05-24 15:51:19 --> Router Class Initialized
INFO - 2025-05-24 15:51:19 --> Output Class Initialized
INFO - 2025-05-24 15:51:19 --> Security Class Initialized
DEBUG - 2025-05-24 15:51:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 15:51:19 --> Input Class Initialized
INFO - 2025-05-24 15:51:19 --> Language Class Initialized
INFO - 2025-05-24 15:51:19 --> Loader Class Initialized
INFO - 2025-05-24 15:51:19 --> Helper loaded: url_helper
INFO - 2025-05-24 15:51:19 --> Helper loaded: form_helper
INFO - 2025-05-24 15:51:19 --> Database Driver Class Initialized
DEBUG - 2025-05-24 15:51:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 15:51:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 15:51:19 --> Controller Class Initialized
INFO - 2025-05-24 15:51:19 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 15:51:19 --> Model "User_model" initialized
INFO - 2025-05-24 15:51:19 --> Final output sent to browser
DEBUG - 2025-05-24 15:51:19 --> Total execution time: 0.0990
INFO - 2025-05-24 15:51:24 --> Config Class Initialized
INFO - 2025-05-24 15:51:24 --> Hooks Class Initialized
DEBUG - 2025-05-24 15:51:24 --> UTF-8 Support Enabled
INFO - 2025-05-24 15:51:24 --> Utf8 Class Initialized
INFO - 2025-05-24 15:51:24 --> URI Class Initialized
INFO - 2025-05-24 15:51:24 --> Router Class Initialized
INFO - 2025-05-24 15:51:24 --> Output Class Initialized
INFO - 2025-05-24 15:51:24 --> Security Class Initialized
DEBUG - 2025-05-24 15:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 15:51:24 --> Input Class Initialized
INFO - 2025-05-24 15:51:24 --> Language Class Initialized
INFO - 2025-05-24 15:51:24 --> Loader Class Initialized
INFO - 2025-05-24 15:51:24 --> Helper loaded: url_helper
INFO - 2025-05-24 15:51:24 --> Helper loaded: form_helper
INFO - 2025-05-24 15:51:24 --> Database Driver Class Initialized
DEBUG - 2025-05-24 15:51:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 15:51:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 15:51:24 --> Controller Class Initialized
INFO - 2025-05-24 15:51:24 --> Model "Progress_model" initialized
INFO - 2025-05-24 15:51:24 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 15:51:24 --> Model "User_model" initialized
INFO - 2025-05-24 15:51:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 15:51:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 15:51:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-24 15:51:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 15:51:24 --> Final output sent to browser
DEBUG - 2025-05-24 15:51:24 --> Total execution time: 0.0648
INFO - 2025-05-24 15:51:24 --> Config Class Initialized
INFO - 2025-05-24 15:51:24 --> Hooks Class Initialized
DEBUG - 2025-05-24 15:51:24 --> UTF-8 Support Enabled
INFO - 2025-05-24 15:51:24 --> Utf8 Class Initialized
INFO - 2025-05-24 15:51:24 --> URI Class Initialized
INFO - 2025-05-24 15:51:24 --> Router Class Initialized
INFO - 2025-05-24 15:51:24 --> Output Class Initialized
INFO - 2025-05-24 15:51:24 --> Security Class Initialized
DEBUG - 2025-05-24 15:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 15:51:24 --> Input Class Initialized
INFO - 2025-05-24 15:51:24 --> Language Class Initialized
INFO - 2025-05-24 15:51:24 --> Loader Class Initialized
INFO - 2025-05-24 15:51:24 --> Helper loaded: url_helper
INFO - 2025-05-24 15:51:24 --> Helper loaded: form_helper
INFO - 2025-05-24 15:51:24 --> Database Driver Class Initialized
DEBUG - 2025-05-24 15:51:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 15:51:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 15:51:24 --> Controller Class Initialized
INFO - 2025-05-24 15:51:24 --> Model "Progress_model" initialized
INFO - 2025-05-24 15:51:24 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 15:51:24 --> Model "User_model" initialized
INFO - 2025-05-24 15:51:24 --> Final output sent to browser
DEBUG - 2025-05-24 15:51:24 --> Total execution time: 0.0777
INFO - 2025-05-24 15:51:27 --> Config Class Initialized
INFO - 2025-05-24 15:51:27 --> Hooks Class Initialized
DEBUG - 2025-05-24 15:51:27 --> UTF-8 Support Enabled
INFO - 2025-05-24 15:51:27 --> Utf8 Class Initialized
INFO - 2025-05-24 15:51:27 --> URI Class Initialized
INFO - 2025-05-24 15:51:27 --> Router Class Initialized
INFO - 2025-05-24 15:51:27 --> Output Class Initialized
INFO - 2025-05-24 15:51:27 --> Security Class Initialized
DEBUG - 2025-05-24 15:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 15:51:27 --> Input Class Initialized
INFO - 2025-05-24 15:51:27 --> Language Class Initialized
INFO - 2025-05-24 15:51:27 --> Loader Class Initialized
INFO - 2025-05-24 15:51:27 --> Helper loaded: url_helper
INFO - 2025-05-24 15:51:27 --> Helper loaded: form_helper
INFO - 2025-05-24 15:51:27 --> Database Driver Class Initialized
DEBUG - 2025-05-24 15:51:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 15:51:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 15:51:27 --> Controller Class Initialized
INFO - 2025-05-24 15:51:27 --> Model "Progress_model" initialized
INFO - 2025-05-24 15:51:27 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 15:51:27 --> Model "User_model" initialized
INFO - 2025-05-24 15:51:27 --> Final output sent to browser
DEBUG - 2025-05-24 15:51:27 --> Total execution time: 0.0573
INFO - 2025-05-24 16:00:34 --> Config Class Initialized
INFO - 2025-05-24 16:00:34 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:00:34 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:00:34 --> Utf8 Class Initialized
INFO - 2025-05-24 16:00:34 --> URI Class Initialized
INFO - 2025-05-24 16:00:34 --> Router Class Initialized
INFO - 2025-05-24 16:00:34 --> Output Class Initialized
INFO - 2025-05-24 16:00:34 --> Security Class Initialized
DEBUG - 2025-05-24 16:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:00:34 --> Input Class Initialized
INFO - 2025-05-24 16:00:34 --> Language Class Initialized
INFO - 2025-05-24 16:00:34 --> Loader Class Initialized
INFO - 2025-05-24 16:00:34 --> Helper loaded: url_helper
INFO - 2025-05-24 16:00:34 --> Helper loaded: form_helper
INFO - 2025-05-24 16:00:34 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:00:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:00:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:00:34 --> Controller Class Initialized
INFO - 2025-05-24 16:00:34 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:00:34 --> Model "User_model" initialized
INFO - 2025-05-24 16:00:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 16:00:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 16:00:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-05-24 16:00:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 16:00:34 --> Final output sent to browser
DEBUG - 2025-05-24 16:00:34 --> Total execution time: 0.0704
INFO - 2025-05-24 16:00:36 --> Config Class Initialized
INFO - 2025-05-24 16:00:36 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:00:36 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:00:36 --> Utf8 Class Initialized
INFO - 2025-05-24 16:00:36 --> URI Class Initialized
INFO - 2025-05-24 16:00:36 --> Router Class Initialized
INFO - 2025-05-24 16:00:36 --> Output Class Initialized
INFO - 2025-05-24 16:00:36 --> Security Class Initialized
DEBUG - 2025-05-24 16:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:00:36 --> Input Class Initialized
INFO - 2025-05-24 16:00:36 --> Language Class Initialized
INFO - 2025-05-24 16:00:36 --> Loader Class Initialized
INFO - 2025-05-24 16:00:36 --> Helper loaded: url_helper
INFO - 2025-05-24 16:00:36 --> Helper loaded: form_helper
INFO - 2025-05-24 16:00:36 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:00:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:00:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:00:36 --> Controller Class Initialized
INFO - 2025-05-24 16:00:36 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:00:36 --> Model "User_model" initialized
INFO - 2025-05-24 16:00:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 16:00:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 16:00:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-05-24 16:00:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 16:00:36 --> Final output sent to browser
DEBUG - 2025-05-24 16:00:36 --> Total execution time: 0.0619
INFO - 2025-05-24 16:00:38 --> Config Class Initialized
INFO - 2025-05-24 16:00:38 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:00:38 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:00:38 --> Utf8 Class Initialized
INFO - 2025-05-24 16:00:38 --> URI Class Initialized
INFO - 2025-05-24 16:00:38 --> Router Class Initialized
INFO - 2025-05-24 16:00:38 --> Output Class Initialized
INFO - 2025-05-24 16:00:38 --> Security Class Initialized
DEBUG - 2025-05-24 16:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:00:38 --> Input Class Initialized
INFO - 2025-05-24 16:00:38 --> Language Class Initialized
INFO - 2025-05-24 16:00:38 --> Loader Class Initialized
INFO - 2025-05-24 16:00:38 --> Helper loaded: url_helper
INFO - 2025-05-24 16:00:38 --> Helper loaded: form_helper
INFO - 2025-05-24 16:00:38 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:00:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:00:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:00:38 --> Controller Class Initialized
INFO - 2025-05-24 16:00:38 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:00:38 --> Model "User_model" initialized
INFO - 2025-05-24 16:00:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 16:00:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 16:00:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/menu.php
INFO - 2025-05-24 16:00:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 16:00:38 --> Final output sent to browser
DEBUG - 2025-05-24 16:00:38 --> Total execution time: 0.0780
INFO - 2025-05-24 16:00:39 --> Config Class Initialized
INFO - 2025-05-24 16:00:39 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:00:39 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:00:39 --> Utf8 Class Initialized
INFO - 2025-05-24 16:00:39 --> URI Class Initialized
INFO - 2025-05-24 16:00:39 --> Router Class Initialized
INFO - 2025-05-24 16:00:39 --> Output Class Initialized
INFO - 2025-05-24 16:00:39 --> Security Class Initialized
DEBUG - 2025-05-24 16:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:00:39 --> Input Class Initialized
INFO - 2025-05-24 16:00:39 --> Language Class Initialized
INFO - 2025-05-24 16:00:39 --> Loader Class Initialized
INFO - 2025-05-24 16:00:39 --> Helper loaded: url_helper
INFO - 2025-05-24 16:00:39 --> Helper loaded: form_helper
INFO - 2025-05-24 16:00:39 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:00:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:00:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:00:39 --> Controller Class Initialized
INFO - 2025-05-24 16:00:39 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:00:39 --> Model "User_model" initialized
INFO - 2025-05-24 16:00:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 16:00:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 16:00:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/start.php
INFO - 2025-05-24 16:00:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 16:00:39 --> Final output sent to browser
DEBUG - 2025-05-24 16:00:39 --> Total execution time: 0.0657
INFO - 2025-05-24 16:00:47 --> Config Class Initialized
INFO - 2025-05-24 16:00:47 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:00:47 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:00:47 --> Utf8 Class Initialized
INFO - 2025-05-24 16:00:47 --> URI Class Initialized
INFO - 2025-05-24 16:00:47 --> Router Class Initialized
INFO - 2025-05-24 16:00:47 --> Output Class Initialized
INFO - 2025-05-24 16:00:47 --> Security Class Initialized
DEBUG - 2025-05-24 16:00:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:00:47 --> Input Class Initialized
INFO - 2025-05-24 16:00:47 --> Language Class Initialized
INFO - 2025-05-24 16:00:47 --> Loader Class Initialized
INFO - 2025-05-24 16:00:47 --> Helper loaded: url_helper
INFO - 2025-05-24 16:00:47 --> Helper loaded: form_helper
INFO - 2025-05-24 16:00:47 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:00:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:00:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:00:47 --> Controller Class Initialized
INFO - 2025-05-24 16:00:47 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:00:47 --> Model "User_model" initialized
INFO - 2025-05-24 16:00:47 --> Final output sent to browser
DEBUG - 2025-05-24 16:00:47 --> Total execution time: 0.0942
INFO - 2025-05-24 16:00:53 --> Config Class Initialized
INFO - 2025-05-24 16:00:53 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:00:53 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:00:53 --> Utf8 Class Initialized
INFO - 2025-05-24 16:00:53 --> URI Class Initialized
INFO - 2025-05-24 16:00:53 --> Router Class Initialized
INFO - 2025-05-24 16:00:53 --> Output Class Initialized
INFO - 2025-05-24 16:00:53 --> Security Class Initialized
DEBUG - 2025-05-24 16:00:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:00:53 --> Input Class Initialized
INFO - 2025-05-24 16:00:53 --> Language Class Initialized
INFO - 2025-05-24 16:00:53 --> Loader Class Initialized
INFO - 2025-05-24 16:00:53 --> Helper loaded: url_helper
INFO - 2025-05-24 16:00:53 --> Helper loaded: form_helper
INFO - 2025-05-24 16:00:53 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:00:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:00:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:00:53 --> Controller Class Initialized
INFO - 2025-05-24 16:00:53 --> Model "Progress_model" initialized
INFO - 2025-05-24 16:00:53 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:00:53 --> Model "User_model" initialized
INFO - 2025-05-24 16:00:53 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 16:00:53 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 16:00:53 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-24 16:00:53 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 16:00:53 --> Final output sent to browser
DEBUG - 2025-05-24 16:00:53 --> Total execution time: 0.1010
INFO - 2025-05-24 16:00:53 --> Config Class Initialized
INFO - 2025-05-24 16:00:53 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:00:53 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:00:53 --> Utf8 Class Initialized
INFO - 2025-05-24 16:00:53 --> URI Class Initialized
INFO - 2025-05-24 16:00:53 --> Router Class Initialized
INFO - 2025-05-24 16:00:53 --> Output Class Initialized
INFO - 2025-05-24 16:00:53 --> Security Class Initialized
DEBUG - 2025-05-24 16:00:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:00:53 --> Input Class Initialized
INFO - 2025-05-24 16:00:53 --> Language Class Initialized
INFO - 2025-05-24 16:00:53 --> Loader Class Initialized
INFO - 2025-05-24 16:00:53 --> Helper loaded: url_helper
INFO - 2025-05-24 16:00:53 --> Helper loaded: form_helper
INFO - 2025-05-24 16:00:53 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:00:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:00:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:00:53 --> Controller Class Initialized
INFO - 2025-05-24 16:00:53 --> Model "Progress_model" initialized
INFO - 2025-05-24 16:00:53 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:00:53 --> Model "User_model" initialized
INFO - 2025-05-24 16:00:53 --> Final output sent to browser
DEBUG - 2025-05-24 16:00:53 --> Total execution time: 0.0736
INFO - 2025-05-24 16:00:56 --> Config Class Initialized
INFO - 2025-05-24 16:00:56 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:00:56 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:00:56 --> Utf8 Class Initialized
INFO - 2025-05-24 16:00:56 --> URI Class Initialized
INFO - 2025-05-24 16:00:56 --> Router Class Initialized
INFO - 2025-05-24 16:00:56 --> Output Class Initialized
INFO - 2025-05-24 16:00:56 --> Security Class Initialized
DEBUG - 2025-05-24 16:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:00:56 --> Input Class Initialized
INFO - 2025-05-24 16:00:56 --> Language Class Initialized
INFO - 2025-05-24 16:00:56 --> Loader Class Initialized
INFO - 2025-05-24 16:00:56 --> Helper loaded: url_helper
INFO - 2025-05-24 16:00:56 --> Helper loaded: form_helper
INFO - 2025-05-24 16:00:56 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:00:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:00:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:00:56 --> Controller Class Initialized
INFO - 2025-05-24 16:00:56 --> Model "Progress_model" initialized
INFO - 2025-05-24 16:00:56 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:00:56 --> Model "User_model" initialized
INFO - 2025-05-24 16:00:56 --> Final output sent to browser
DEBUG - 2025-05-24 16:00:56 --> Total execution time: 0.0657
INFO - 2025-05-24 16:01:15 --> Config Class Initialized
INFO - 2025-05-24 16:01:15 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:01:15 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:01:15 --> Utf8 Class Initialized
INFO - 2025-05-24 16:01:15 --> URI Class Initialized
INFO - 2025-05-24 16:01:15 --> Router Class Initialized
INFO - 2025-05-24 16:01:15 --> Output Class Initialized
INFO - 2025-05-24 16:01:15 --> Security Class Initialized
DEBUG - 2025-05-24 16:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:01:15 --> Input Class Initialized
INFO - 2025-05-24 16:01:15 --> Language Class Initialized
INFO - 2025-05-24 16:01:15 --> Loader Class Initialized
INFO - 2025-05-24 16:01:15 --> Helper loaded: url_helper
INFO - 2025-05-24 16:01:15 --> Helper loaded: form_helper
INFO - 2025-05-24 16:01:15 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:01:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:01:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:01:15 --> Controller Class Initialized
INFO - 2025-05-24 16:01:15 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:01:15 --> Model "User_model" initialized
INFO - 2025-05-24 16:01:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 16:01:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 16:01:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-05-24 16:01:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 16:01:15 --> Final output sent to browser
DEBUG - 2025-05-24 16:01:15 --> Total execution time: 0.0682
INFO - 2025-05-24 16:01:17 --> Config Class Initialized
INFO - 2025-05-24 16:01:17 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:01:17 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:01:17 --> Utf8 Class Initialized
INFO - 2025-05-24 16:01:17 --> URI Class Initialized
INFO - 2025-05-24 16:01:17 --> Router Class Initialized
INFO - 2025-05-24 16:01:17 --> Output Class Initialized
INFO - 2025-05-24 16:01:17 --> Security Class Initialized
DEBUG - 2025-05-24 16:01:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:01:17 --> Input Class Initialized
INFO - 2025-05-24 16:01:17 --> Language Class Initialized
INFO - 2025-05-24 16:01:17 --> Loader Class Initialized
INFO - 2025-05-24 16:01:17 --> Helper loaded: url_helper
INFO - 2025-05-24 16:01:17 --> Helper loaded: form_helper
INFO - 2025-05-24 16:01:17 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:01:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:01:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:01:17 --> Controller Class Initialized
INFO - 2025-05-24 16:01:17 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:01:17 --> Model "User_model" initialized
INFO - 2025-05-24 16:01:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 16:01:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 16:01:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-05-24 16:01:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 16:01:17 --> Final output sent to browser
DEBUG - 2025-05-24 16:01:17 --> Total execution time: 0.0697
INFO - 2025-05-24 16:01:22 --> Config Class Initialized
INFO - 2025-05-24 16:01:22 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:01:22 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:01:22 --> Utf8 Class Initialized
INFO - 2025-05-24 16:01:22 --> URI Class Initialized
INFO - 2025-05-24 16:01:22 --> Router Class Initialized
INFO - 2025-05-24 16:01:22 --> Output Class Initialized
INFO - 2025-05-24 16:01:22 --> Security Class Initialized
DEBUG - 2025-05-24 16:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:01:22 --> Input Class Initialized
INFO - 2025-05-24 16:01:22 --> Language Class Initialized
INFO - 2025-05-24 16:01:22 --> Loader Class Initialized
INFO - 2025-05-24 16:01:22 --> Helper loaded: url_helper
INFO - 2025-05-24 16:01:22 --> Helper loaded: form_helper
INFO - 2025-05-24 16:01:22 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:01:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:01:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:01:22 --> Controller Class Initialized
INFO - 2025-05-24 16:01:22 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:01:22 --> Model "User_model" initialized
INFO - 2025-05-24 16:01:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 16:01:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 16:01:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/menu.php
INFO - 2025-05-24 16:01:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 16:01:22 --> Final output sent to browser
DEBUG - 2025-05-24 16:01:22 --> Total execution time: 0.0827
INFO - 2025-05-24 16:02:12 --> Config Class Initialized
INFO - 2025-05-24 16:02:12 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:02:12 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:02:12 --> Utf8 Class Initialized
INFO - 2025-05-24 16:02:12 --> URI Class Initialized
INFO - 2025-05-24 16:02:12 --> Router Class Initialized
INFO - 2025-05-24 16:02:12 --> Output Class Initialized
INFO - 2025-05-24 16:02:12 --> Security Class Initialized
DEBUG - 2025-05-24 16:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:02:12 --> Input Class Initialized
INFO - 2025-05-24 16:02:12 --> Language Class Initialized
INFO - 2025-05-24 16:02:12 --> Loader Class Initialized
INFO - 2025-05-24 16:02:12 --> Helper loaded: url_helper
INFO - 2025-05-24 16:02:12 --> Helper loaded: form_helper
INFO - 2025-05-24 16:02:12 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:02:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:02:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:02:12 --> Controller Class Initialized
INFO - 2025-05-24 16:02:12 --> Model "Progress_model" initialized
INFO - 2025-05-24 16:02:12 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:02:12 --> Model "User_model" initialized
INFO - 2025-05-24 16:02:12 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 16:02:12 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 16:02:12 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-24 16:02:12 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 16:02:12 --> Final output sent to browser
DEBUG - 2025-05-24 16:02:12 --> Total execution time: 0.0773
INFO - 2025-05-24 16:02:13 --> Config Class Initialized
INFO - 2025-05-24 16:02:13 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:02:13 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:02:13 --> Utf8 Class Initialized
INFO - 2025-05-24 16:02:13 --> URI Class Initialized
INFO - 2025-05-24 16:02:13 --> Router Class Initialized
INFO - 2025-05-24 16:02:13 --> Output Class Initialized
INFO - 2025-05-24 16:02:13 --> Security Class Initialized
DEBUG - 2025-05-24 16:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:02:13 --> Input Class Initialized
INFO - 2025-05-24 16:02:13 --> Language Class Initialized
INFO - 2025-05-24 16:02:13 --> Loader Class Initialized
INFO - 2025-05-24 16:02:13 --> Helper loaded: url_helper
INFO - 2025-05-24 16:02:13 --> Helper loaded: form_helper
INFO - 2025-05-24 16:02:13 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:02:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:02:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:02:13 --> Controller Class Initialized
INFO - 2025-05-24 16:02:13 --> Model "Progress_model" initialized
INFO - 2025-05-24 16:02:13 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:02:13 --> Model "User_model" initialized
INFO - 2025-05-24 16:02:13 --> Final output sent to browser
DEBUG - 2025-05-24 16:02:13 --> Total execution time: 0.0823
INFO - 2025-05-24 16:02:16 --> Config Class Initialized
INFO - 2025-05-24 16:02:16 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:02:16 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:02:16 --> Utf8 Class Initialized
INFO - 2025-05-24 16:02:16 --> URI Class Initialized
INFO - 2025-05-24 16:02:16 --> Router Class Initialized
INFO - 2025-05-24 16:02:16 --> Output Class Initialized
INFO - 2025-05-24 16:02:16 --> Security Class Initialized
DEBUG - 2025-05-24 16:02:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:02:16 --> Input Class Initialized
INFO - 2025-05-24 16:02:16 --> Language Class Initialized
INFO - 2025-05-24 16:02:16 --> Loader Class Initialized
INFO - 2025-05-24 16:02:16 --> Helper loaded: url_helper
INFO - 2025-05-24 16:02:16 --> Helper loaded: form_helper
INFO - 2025-05-24 16:02:16 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:02:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:02:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:02:16 --> Controller Class Initialized
INFO - 2025-05-24 16:02:16 --> Model "Progress_model" initialized
INFO - 2025-05-24 16:02:16 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:02:16 --> Model "User_model" initialized
INFO - 2025-05-24 16:02:16 --> Final output sent to browser
DEBUG - 2025-05-24 16:02:16 --> Total execution time: 0.0762
INFO - 2025-05-24 16:05:19 --> Config Class Initialized
INFO - 2025-05-24 16:05:19 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:05:19 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:05:19 --> Utf8 Class Initialized
INFO - 2025-05-24 16:05:19 --> URI Class Initialized
INFO - 2025-05-24 16:05:19 --> Router Class Initialized
INFO - 2025-05-24 16:05:19 --> Output Class Initialized
INFO - 2025-05-24 16:05:19 --> Security Class Initialized
DEBUG - 2025-05-24 16:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:05:19 --> Input Class Initialized
INFO - 2025-05-24 16:05:19 --> Language Class Initialized
INFO - 2025-05-24 16:05:19 --> Loader Class Initialized
INFO - 2025-05-24 16:05:19 --> Helper loaded: url_helper
INFO - 2025-05-24 16:05:19 --> Helper loaded: form_helper
INFO - 2025-05-24 16:05:19 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:05:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:05:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:05:19 --> Controller Class Initialized
INFO - 2025-05-24 16:05:19 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:05:19 --> Model "User_model" initialized
INFO - 2025-05-24 16:05:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 16:05:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 16:05:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-05-24 16:05:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 16:05:19 --> Final output sent to browser
DEBUG - 2025-05-24 16:05:19 --> Total execution time: 0.0808
INFO - 2025-05-24 16:05:20 --> Config Class Initialized
INFO - 2025-05-24 16:05:20 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:05:20 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:05:20 --> Utf8 Class Initialized
INFO - 2025-05-24 16:05:20 --> URI Class Initialized
INFO - 2025-05-24 16:05:20 --> Router Class Initialized
INFO - 2025-05-24 16:05:20 --> Output Class Initialized
INFO - 2025-05-24 16:05:20 --> Security Class Initialized
DEBUG - 2025-05-24 16:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:05:20 --> Input Class Initialized
INFO - 2025-05-24 16:05:20 --> Language Class Initialized
INFO - 2025-05-24 16:05:20 --> Loader Class Initialized
INFO - 2025-05-24 16:05:20 --> Helper loaded: url_helper
INFO - 2025-05-24 16:05:20 --> Helper loaded: form_helper
INFO - 2025-05-24 16:05:20 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:05:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:05:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:05:20 --> Controller Class Initialized
INFO - 2025-05-24 16:05:20 --> Model "Progress_model" initialized
INFO - 2025-05-24 16:05:20 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:05:20 --> Model "User_model" initialized
INFO - 2025-05-24 16:05:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 16:05:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 16:05:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-24 16:05:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 16:05:20 --> Final output sent to browser
DEBUG - 2025-05-24 16:05:20 --> Total execution time: 0.0724
INFO - 2025-05-24 16:05:21 --> Config Class Initialized
INFO - 2025-05-24 16:05:21 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:05:21 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:05:21 --> Utf8 Class Initialized
INFO - 2025-05-24 16:05:21 --> URI Class Initialized
INFO - 2025-05-24 16:05:21 --> Router Class Initialized
INFO - 2025-05-24 16:05:21 --> Output Class Initialized
INFO - 2025-05-24 16:05:21 --> Security Class Initialized
DEBUG - 2025-05-24 16:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:05:21 --> Input Class Initialized
INFO - 2025-05-24 16:05:21 --> Language Class Initialized
INFO - 2025-05-24 16:05:21 --> Loader Class Initialized
INFO - 2025-05-24 16:05:21 --> Helper loaded: url_helper
INFO - 2025-05-24 16:05:21 --> Helper loaded: form_helper
INFO - 2025-05-24 16:05:21 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:05:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:05:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:05:21 --> Controller Class Initialized
INFO - 2025-05-24 16:05:21 --> Model "Progress_model" initialized
INFO - 2025-05-24 16:05:21 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:05:21 --> Model "User_model" initialized
INFO - 2025-05-24 16:05:21 --> Final output sent to browser
DEBUG - 2025-05-24 16:05:21 --> Total execution time: 0.0835
INFO - 2025-05-24 16:05:27 --> Config Class Initialized
INFO - 2025-05-24 16:05:27 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:05:27 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:05:27 --> Utf8 Class Initialized
INFO - 2025-05-24 16:05:27 --> URI Class Initialized
INFO - 2025-05-24 16:05:27 --> Router Class Initialized
INFO - 2025-05-24 16:05:27 --> Output Class Initialized
INFO - 2025-05-24 16:05:27 --> Security Class Initialized
DEBUG - 2025-05-24 16:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:05:27 --> Input Class Initialized
INFO - 2025-05-24 16:05:27 --> Language Class Initialized
INFO - 2025-05-24 16:05:27 --> Loader Class Initialized
INFO - 2025-05-24 16:05:27 --> Helper loaded: url_helper
INFO - 2025-05-24 16:05:27 --> Helper loaded: form_helper
INFO - 2025-05-24 16:05:27 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:05:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:05:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:05:27 --> Controller Class Initialized
INFO - 2025-05-24 16:05:27 --> Model "User_model" initialized
INFO - 2025-05-24 16:05:27 --> Config Class Initialized
INFO - 2025-05-24 16:05:27 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:05:27 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:05:27 --> Utf8 Class Initialized
INFO - 2025-05-24 16:05:27 --> URI Class Initialized
INFO - 2025-05-24 16:05:27 --> Router Class Initialized
INFO - 2025-05-24 16:05:27 --> Output Class Initialized
INFO - 2025-05-24 16:05:27 --> Security Class Initialized
DEBUG - 2025-05-24 16:05:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:05:27 --> Input Class Initialized
INFO - 2025-05-24 16:05:27 --> Language Class Initialized
INFO - 2025-05-24 16:05:27 --> Loader Class Initialized
INFO - 2025-05-24 16:05:27 --> Helper loaded: url_helper
INFO - 2025-05-24 16:05:27 --> Helper loaded: form_helper
INFO - 2025-05-24 16:05:27 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:05:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:05:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:05:27 --> Controller Class Initialized
INFO - 2025-05-24 16:05:27 --> Model "User_model" initialized
INFO - 2025-05-24 16:05:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-24 16:05:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-24 16:05:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-24 16:05:28 --> Final output sent to browser
DEBUG - 2025-05-24 16:05:28 --> Total execution time: 0.2496
INFO - 2025-05-24 16:05:29 --> Config Class Initialized
INFO - 2025-05-24 16:05:29 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:05:29 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:05:29 --> Utf8 Class Initialized
INFO - 2025-05-24 16:05:29 --> URI Class Initialized
INFO - 2025-05-24 16:05:29 --> Router Class Initialized
INFO - 2025-05-24 16:05:29 --> Output Class Initialized
INFO - 2025-05-24 16:05:29 --> Security Class Initialized
DEBUG - 2025-05-24 16:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:05:29 --> Input Class Initialized
INFO - 2025-05-24 16:05:29 --> Language Class Initialized
INFO - 2025-05-24 16:05:29 --> Loader Class Initialized
INFO - 2025-05-24 16:05:29 --> Helper loaded: url_helper
INFO - 2025-05-24 16:05:29 --> Helper loaded: form_helper
INFO - 2025-05-24 16:05:29 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:05:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:05:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:05:29 --> Controller Class Initialized
INFO - 2025-05-24 16:05:29 --> Model "User_model" initialized
INFO - 2025-05-24 16:05:29 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-24 16:05:29 --> Final output sent to browser
DEBUG - 2025-05-24 16:05:29 --> Total execution time: 0.1009
INFO - 2025-05-24 16:05:35 --> Config Class Initialized
INFO - 2025-05-24 16:05:35 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:05:35 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:05:35 --> Utf8 Class Initialized
INFO - 2025-05-24 16:05:35 --> URI Class Initialized
INFO - 2025-05-24 16:05:35 --> Router Class Initialized
INFO - 2025-05-24 16:05:35 --> Output Class Initialized
INFO - 2025-05-24 16:05:35 --> Security Class Initialized
DEBUG - 2025-05-24 16:05:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:05:35 --> Input Class Initialized
INFO - 2025-05-24 16:05:35 --> Language Class Initialized
INFO - 2025-05-24 16:05:35 --> Loader Class Initialized
INFO - 2025-05-24 16:05:35 --> Helper loaded: url_helper
INFO - 2025-05-24 16:05:35 --> Helper loaded: form_helper
INFO - 2025-05-24 16:05:35 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:05:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:05:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:05:35 --> Controller Class Initialized
INFO - 2025-05-24 16:05:35 --> Model "User_model" initialized
INFO - 2025-05-24 16:05:35 --> Config Class Initialized
INFO - 2025-05-24 16:05:35 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:05:35 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:05:35 --> Utf8 Class Initialized
INFO - 2025-05-24 16:05:35 --> URI Class Initialized
INFO - 2025-05-24 16:05:35 --> Router Class Initialized
INFO - 2025-05-24 16:05:35 --> Output Class Initialized
INFO - 2025-05-24 16:05:35 --> Security Class Initialized
DEBUG - 2025-05-24 16:05:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:05:35 --> Input Class Initialized
INFO - 2025-05-24 16:05:35 --> Language Class Initialized
INFO - 2025-05-24 16:05:35 --> Loader Class Initialized
INFO - 2025-05-24 16:05:35 --> Helper loaded: url_helper
INFO - 2025-05-24 16:05:35 --> Helper loaded: form_helper
INFO - 2025-05-24 16:05:35 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:05:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:05:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:05:35 --> Controller Class Initialized
INFO - 2025-05-24 16:05:35 --> Model "User_model" initialized
INFO - 2025-05-24 16:05:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-24 16:05:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-24 16:05:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-24 16:05:35 --> Final output sent to browser
DEBUG - 2025-05-24 16:05:35 --> Total execution time: 0.0641
INFO - 2025-05-24 16:05:37 --> Config Class Initialized
INFO - 2025-05-24 16:05:37 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:05:37 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:05:37 --> Utf8 Class Initialized
INFO - 2025-05-24 16:05:37 --> URI Class Initialized
INFO - 2025-05-24 16:05:37 --> Router Class Initialized
INFO - 2025-05-24 16:05:37 --> Output Class Initialized
INFO - 2025-05-24 16:05:37 --> Security Class Initialized
DEBUG - 2025-05-24 16:05:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:05:37 --> Input Class Initialized
INFO - 2025-05-24 16:05:37 --> Language Class Initialized
INFO - 2025-05-24 16:05:37 --> Loader Class Initialized
INFO - 2025-05-24 16:05:37 --> Helper loaded: url_helper
INFO - 2025-05-24 16:05:37 --> Helper loaded: form_helper
INFO - 2025-05-24 16:05:37 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:05:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:05:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:05:37 --> Controller Class Initialized
INFO - 2025-05-24 16:05:37 --> Model "User_model" initialized
INFO - 2025-05-24 16:05:37 --> Model "Workout_model" initialized
INFO - 2025-05-24 16:05:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 16:05:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 16:05:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-24 16:05:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 16:05:37 --> Final output sent to browser
DEBUG - 2025-05-24 16:05:37 --> Total execution time: 0.1208
INFO - 2025-05-24 16:05:38 --> Config Class Initialized
INFO - 2025-05-24 16:05:38 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:05:38 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:05:38 --> Utf8 Class Initialized
INFO - 2025-05-24 16:05:38 --> URI Class Initialized
INFO - 2025-05-24 16:05:38 --> Router Class Initialized
INFO - 2025-05-24 16:05:38 --> Output Class Initialized
INFO - 2025-05-24 16:05:38 --> Security Class Initialized
DEBUG - 2025-05-24 16:05:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:05:38 --> Input Class Initialized
INFO - 2025-05-24 16:05:38 --> Language Class Initialized
INFO - 2025-05-24 16:05:38 --> Loader Class Initialized
INFO - 2025-05-24 16:05:38 --> Helper loaded: url_helper
INFO - 2025-05-24 16:05:38 --> Helper loaded: form_helper
INFO - 2025-05-24 16:05:38 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:05:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:05:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:05:38 --> Controller Class Initialized
INFO - 2025-05-24 16:05:38 --> Model "Progress_model" initialized
INFO - 2025-05-24 16:05:38 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:05:38 --> Model "User_model" initialized
INFO - 2025-05-24 16:05:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 16:05:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 16:05:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-24 16:05:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 16:05:38 --> Final output sent to browser
DEBUG - 2025-05-24 16:05:38 --> Total execution time: 0.0624
INFO - 2025-05-24 16:05:39 --> Config Class Initialized
INFO - 2025-05-24 16:05:39 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:05:39 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:05:39 --> Utf8 Class Initialized
INFO - 2025-05-24 16:05:39 --> URI Class Initialized
INFO - 2025-05-24 16:05:39 --> Router Class Initialized
INFO - 2025-05-24 16:05:39 --> Output Class Initialized
INFO - 2025-05-24 16:05:39 --> Security Class Initialized
DEBUG - 2025-05-24 16:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:05:39 --> Input Class Initialized
INFO - 2025-05-24 16:05:39 --> Language Class Initialized
INFO - 2025-05-24 16:05:39 --> Loader Class Initialized
INFO - 2025-05-24 16:05:39 --> Helper loaded: url_helper
INFO - 2025-05-24 16:05:39 --> Helper loaded: form_helper
INFO - 2025-05-24 16:05:39 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:05:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:05:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:05:39 --> Controller Class Initialized
INFO - 2025-05-24 16:05:39 --> Model "Progress_model" initialized
INFO - 2025-05-24 16:05:39 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:05:39 --> Model "User_model" initialized
INFO - 2025-05-24 16:05:39 --> Final output sent to browser
DEBUG - 2025-05-24 16:05:39 --> Total execution time: 0.0801
INFO - 2025-05-24 16:05:44 --> Config Class Initialized
INFO - 2025-05-24 16:05:44 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:05:44 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:05:44 --> Utf8 Class Initialized
INFO - 2025-05-24 16:05:44 --> URI Class Initialized
INFO - 2025-05-24 16:05:44 --> Router Class Initialized
INFO - 2025-05-24 16:05:44 --> Output Class Initialized
INFO - 2025-05-24 16:05:44 --> Security Class Initialized
DEBUG - 2025-05-24 16:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:05:44 --> Input Class Initialized
INFO - 2025-05-24 16:05:44 --> Language Class Initialized
INFO - 2025-05-24 16:05:44 --> Loader Class Initialized
INFO - 2025-05-24 16:05:44 --> Helper loaded: url_helper
INFO - 2025-05-24 16:05:44 --> Helper loaded: form_helper
INFO - 2025-05-24 16:05:44 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:05:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:05:44 --> Controller Class Initialized
INFO - 2025-05-24 16:05:44 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:05:44 --> Model "User_model" initialized
INFO - 2025-05-24 16:05:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 16:05:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 16:05:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-05-24 16:05:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 16:05:44 --> Final output sent to browser
DEBUG - 2025-05-24 16:05:44 --> Total execution time: 0.0855
INFO - 2025-05-24 16:05:48 --> Config Class Initialized
INFO - 2025-05-24 16:05:48 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:05:48 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:05:48 --> Utf8 Class Initialized
INFO - 2025-05-24 16:05:48 --> URI Class Initialized
INFO - 2025-05-24 16:05:48 --> Router Class Initialized
INFO - 2025-05-24 16:05:48 --> Output Class Initialized
INFO - 2025-05-24 16:05:48 --> Security Class Initialized
DEBUG - 2025-05-24 16:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:05:48 --> Input Class Initialized
INFO - 2025-05-24 16:05:48 --> Language Class Initialized
INFO - 2025-05-24 16:05:48 --> Loader Class Initialized
INFO - 2025-05-24 16:05:48 --> Helper loaded: url_helper
INFO - 2025-05-24 16:05:48 --> Helper loaded: form_helper
INFO - 2025-05-24 16:05:48 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:05:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:05:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:05:48 --> Controller Class Initialized
INFO - 2025-05-24 16:05:48 --> Model "Progress_model" initialized
INFO - 2025-05-24 16:05:48 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:05:48 --> Model "User_model" initialized
INFO - 2025-05-24 16:05:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 16:05:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 16:05:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-24 16:05:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 16:05:48 --> Final output sent to browser
DEBUG - 2025-05-24 16:05:48 --> Total execution time: 0.0944
INFO - 2025-05-24 16:05:48 --> Config Class Initialized
INFO - 2025-05-24 16:05:48 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:05:49 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:05:49 --> Utf8 Class Initialized
INFO - 2025-05-24 16:05:49 --> URI Class Initialized
INFO - 2025-05-24 16:05:49 --> Router Class Initialized
INFO - 2025-05-24 16:05:49 --> Output Class Initialized
INFO - 2025-05-24 16:05:49 --> Security Class Initialized
DEBUG - 2025-05-24 16:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:05:49 --> Input Class Initialized
INFO - 2025-05-24 16:05:49 --> Language Class Initialized
INFO - 2025-05-24 16:05:49 --> Loader Class Initialized
INFO - 2025-05-24 16:05:49 --> Helper loaded: url_helper
INFO - 2025-05-24 16:05:49 --> Helper loaded: form_helper
INFO - 2025-05-24 16:05:49 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:05:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:05:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:05:49 --> Controller Class Initialized
INFO - 2025-05-24 16:05:49 --> Model "Progress_model" initialized
INFO - 2025-05-24 16:05:49 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:05:49 --> Model "User_model" initialized
INFO - 2025-05-24 16:05:49 --> Final output sent to browser
DEBUG - 2025-05-24 16:05:49 --> Total execution time: 0.0695
INFO - 2025-05-24 16:17:25 --> Config Class Initialized
INFO - 2025-05-24 16:17:25 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:17:25 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:17:25 --> Utf8 Class Initialized
INFO - 2025-05-24 16:17:25 --> URI Class Initialized
INFO - 2025-05-24 16:17:25 --> Router Class Initialized
INFO - 2025-05-24 16:17:25 --> Output Class Initialized
INFO - 2025-05-24 16:17:25 --> Security Class Initialized
DEBUG - 2025-05-24 16:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:17:25 --> Input Class Initialized
INFO - 2025-05-24 16:17:25 --> Language Class Initialized
INFO - 2025-05-24 16:17:25 --> Loader Class Initialized
INFO - 2025-05-24 16:17:25 --> Helper loaded: url_helper
INFO - 2025-05-24 16:17:25 --> Helper loaded: form_helper
INFO - 2025-05-24 16:17:25 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:17:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:17:25 --> Controller Class Initialized
INFO - 2025-05-24 16:17:25 --> Model "Progress_model" initialized
INFO - 2025-05-24 16:17:25 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:17:25 --> Model "User_model" initialized
INFO - 2025-05-24 16:17:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 16:17:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 16:17:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-24 16:17:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 16:17:25 --> Final output sent to browser
DEBUG - 2025-05-24 16:17:25 --> Total execution time: 0.0780
INFO - 2025-05-24 16:17:26 --> Config Class Initialized
INFO - 2025-05-24 16:17:26 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:17:26 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:17:26 --> Utf8 Class Initialized
INFO - 2025-05-24 16:17:26 --> URI Class Initialized
INFO - 2025-05-24 16:17:26 --> Router Class Initialized
INFO - 2025-05-24 16:17:26 --> Output Class Initialized
INFO - 2025-05-24 16:17:26 --> Security Class Initialized
DEBUG - 2025-05-24 16:17:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:17:26 --> Input Class Initialized
INFO - 2025-05-24 16:17:26 --> Language Class Initialized
INFO - 2025-05-24 16:17:26 --> Loader Class Initialized
INFO - 2025-05-24 16:17:26 --> Helper loaded: url_helper
INFO - 2025-05-24 16:17:26 --> Helper loaded: form_helper
INFO - 2025-05-24 16:17:26 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:17:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:17:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:17:26 --> Controller Class Initialized
INFO - 2025-05-24 16:17:26 --> Model "Progress_model" initialized
INFO - 2025-05-24 16:17:26 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:17:26 --> Model "User_model" initialized
ERROR - 2025-05-24 16:17:26 --> Query error: Unknown column 'user_id' in 'where clause' - Invalid query: SELECT *
FROM `fitness_progress`
WHERE `status` = 'selesai'
AND `user_id` = '1'
INFO - 2025-05-24 16:17:26 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-24 16:17:33 --> Config Class Initialized
INFO - 2025-05-24 16:17:33 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:17:33 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:17:33 --> Utf8 Class Initialized
INFO - 2025-05-24 16:17:33 --> URI Class Initialized
INFO - 2025-05-24 16:17:33 --> Router Class Initialized
INFO - 2025-05-24 16:17:33 --> Output Class Initialized
INFO - 2025-05-24 16:17:33 --> Security Class Initialized
DEBUG - 2025-05-24 16:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:17:33 --> Input Class Initialized
INFO - 2025-05-24 16:17:33 --> Language Class Initialized
INFO - 2025-05-24 16:17:33 --> Loader Class Initialized
INFO - 2025-05-24 16:17:33 --> Helper loaded: url_helper
INFO - 2025-05-24 16:17:33 --> Helper loaded: form_helper
INFO - 2025-05-24 16:17:33 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:17:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:17:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:17:33 --> Controller Class Initialized
INFO - 2025-05-24 16:17:33 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:17:33 --> Model "User_model" initialized
INFO - 2025-05-24 16:17:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 16:17:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 16:17:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-05-24 16:17:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 16:17:33 --> Final output sent to browser
DEBUG - 2025-05-24 16:17:33 --> Total execution time: 0.0772
INFO - 2025-05-24 16:17:35 --> Config Class Initialized
INFO - 2025-05-24 16:17:35 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:17:35 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:17:35 --> Utf8 Class Initialized
INFO - 2025-05-24 16:17:35 --> URI Class Initialized
INFO - 2025-05-24 16:17:35 --> Router Class Initialized
INFO - 2025-05-24 16:17:35 --> Output Class Initialized
INFO - 2025-05-24 16:17:35 --> Security Class Initialized
DEBUG - 2025-05-24 16:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:17:35 --> Input Class Initialized
INFO - 2025-05-24 16:17:35 --> Language Class Initialized
INFO - 2025-05-24 16:17:35 --> Loader Class Initialized
INFO - 2025-05-24 16:17:35 --> Helper loaded: url_helper
INFO - 2025-05-24 16:17:35 --> Helper loaded: form_helper
INFO - 2025-05-24 16:17:35 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:17:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:17:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:17:35 --> Controller Class Initialized
INFO - 2025-05-24 16:17:35 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:17:35 --> Model "User_model" initialized
INFO - 2025-05-24 16:17:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 16:17:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 16:17:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-05-24 16:17:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 16:17:35 --> Final output sent to browser
DEBUG - 2025-05-24 16:17:35 --> Total execution time: 0.0805
INFO - 2025-05-24 16:17:37 --> Config Class Initialized
INFO - 2025-05-24 16:17:37 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:17:37 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:17:37 --> Utf8 Class Initialized
INFO - 2025-05-24 16:17:37 --> URI Class Initialized
INFO - 2025-05-24 16:17:37 --> Router Class Initialized
INFO - 2025-05-24 16:17:37 --> Output Class Initialized
INFO - 2025-05-24 16:17:37 --> Security Class Initialized
DEBUG - 2025-05-24 16:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:17:37 --> Input Class Initialized
INFO - 2025-05-24 16:17:37 --> Language Class Initialized
INFO - 2025-05-24 16:17:37 --> Loader Class Initialized
INFO - 2025-05-24 16:17:37 --> Helper loaded: url_helper
INFO - 2025-05-24 16:17:37 --> Helper loaded: form_helper
INFO - 2025-05-24 16:17:37 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:17:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:17:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:17:37 --> Controller Class Initialized
INFO - 2025-05-24 16:17:37 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:17:37 --> Model "User_model" initialized
INFO - 2025-05-24 16:17:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 16:17:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 16:17:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/menu.php
INFO - 2025-05-24 16:17:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 16:17:37 --> Final output sent to browser
DEBUG - 2025-05-24 16:17:37 --> Total execution time: 0.0634
INFO - 2025-05-24 16:17:39 --> Config Class Initialized
INFO - 2025-05-24 16:17:39 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:17:39 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:17:39 --> Utf8 Class Initialized
INFO - 2025-05-24 16:17:39 --> URI Class Initialized
INFO - 2025-05-24 16:17:39 --> Router Class Initialized
INFO - 2025-05-24 16:17:39 --> Output Class Initialized
INFO - 2025-05-24 16:17:39 --> Security Class Initialized
DEBUG - 2025-05-24 16:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:17:39 --> Input Class Initialized
INFO - 2025-05-24 16:17:39 --> Language Class Initialized
INFO - 2025-05-24 16:17:39 --> Loader Class Initialized
INFO - 2025-05-24 16:17:39 --> Helper loaded: url_helper
INFO - 2025-05-24 16:17:39 --> Helper loaded: form_helper
INFO - 2025-05-24 16:17:39 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:17:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:17:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:17:39 --> Controller Class Initialized
INFO - 2025-05-24 16:17:39 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:17:39 --> Model "User_model" initialized
INFO - 2025-05-24 16:17:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 16:17:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 16:17:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/start.php
INFO - 2025-05-24 16:17:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 16:17:39 --> Final output sent to browser
DEBUG - 2025-05-24 16:17:39 --> Total execution time: 0.1033
INFO - 2025-05-24 16:17:44 --> Config Class Initialized
INFO - 2025-05-24 16:17:44 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:17:44 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:17:44 --> Utf8 Class Initialized
INFO - 2025-05-24 16:17:44 --> URI Class Initialized
INFO - 2025-05-24 16:17:44 --> Router Class Initialized
INFO - 2025-05-24 16:17:44 --> Output Class Initialized
INFO - 2025-05-24 16:17:44 --> Security Class Initialized
DEBUG - 2025-05-24 16:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:17:44 --> Input Class Initialized
INFO - 2025-05-24 16:17:44 --> Language Class Initialized
INFO - 2025-05-24 16:17:44 --> Loader Class Initialized
INFO - 2025-05-24 16:17:44 --> Helper loaded: url_helper
INFO - 2025-05-24 16:17:44 --> Helper loaded: form_helper
INFO - 2025-05-24 16:17:44 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:17:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:17:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:17:44 --> Controller Class Initialized
INFO - 2025-05-24 16:17:44 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:17:44 --> Model "User_model" initialized
INFO - 2025-05-24 16:17:44 --> Final output sent to browser
DEBUG - 2025-05-24 16:17:44 --> Total execution time: 0.0763
INFO - 2025-05-24 16:17:56 --> Config Class Initialized
INFO - 2025-05-24 16:17:56 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:17:56 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:17:56 --> Utf8 Class Initialized
INFO - 2025-05-24 16:17:56 --> URI Class Initialized
INFO - 2025-05-24 16:17:56 --> Router Class Initialized
INFO - 2025-05-24 16:17:56 --> Output Class Initialized
INFO - 2025-05-24 16:17:56 --> Security Class Initialized
DEBUG - 2025-05-24 16:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:17:56 --> Input Class Initialized
INFO - 2025-05-24 16:17:56 --> Language Class Initialized
INFO - 2025-05-24 16:17:56 --> Loader Class Initialized
INFO - 2025-05-24 16:17:56 --> Helper loaded: url_helper
INFO - 2025-05-24 16:17:56 --> Helper loaded: form_helper
INFO - 2025-05-24 16:17:56 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:17:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:17:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:17:56 --> Controller Class Initialized
INFO - 2025-05-24 16:17:56 --> Model "Progress_model" initialized
INFO - 2025-05-24 16:17:56 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:17:56 --> Model "User_model" initialized
INFO - 2025-05-24 16:17:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 16:17:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 16:17:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-24 16:17:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 16:17:56 --> Final output sent to browser
DEBUG - 2025-05-24 16:17:56 --> Total execution time: 0.0770
INFO - 2025-05-24 16:17:56 --> Config Class Initialized
INFO - 2025-05-24 16:17:56 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:17:56 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:17:56 --> Utf8 Class Initialized
INFO - 2025-05-24 16:17:56 --> URI Class Initialized
INFO - 2025-05-24 16:17:56 --> Router Class Initialized
INFO - 2025-05-24 16:17:56 --> Output Class Initialized
INFO - 2025-05-24 16:17:56 --> Security Class Initialized
DEBUG - 2025-05-24 16:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:17:56 --> Input Class Initialized
INFO - 2025-05-24 16:17:56 --> Language Class Initialized
INFO - 2025-05-24 16:17:56 --> Loader Class Initialized
INFO - 2025-05-24 16:17:56 --> Helper loaded: url_helper
INFO - 2025-05-24 16:17:56 --> Helper loaded: form_helper
INFO - 2025-05-24 16:17:56 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:17:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:17:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:17:56 --> Controller Class Initialized
INFO - 2025-05-24 16:17:56 --> Model "Progress_model" initialized
INFO - 2025-05-24 16:17:56 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:17:56 --> Model "User_model" initialized
ERROR - 2025-05-24 16:17:56 --> Query error: Unknown column 'user_id' in 'where clause' - Invalid query: SELECT *
FROM `fitness_progress`
WHERE `status` = 'selesai'
AND `user_id` = '1'
INFO - 2025-05-24 16:17:56 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-24 16:20:35 --> Config Class Initialized
INFO - 2025-05-24 16:20:35 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:20:35 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:20:35 --> Utf8 Class Initialized
INFO - 2025-05-24 16:20:35 --> URI Class Initialized
INFO - 2025-05-24 16:20:35 --> Router Class Initialized
INFO - 2025-05-24 16:20:35 --> Output Class Initialized
INFO - 2025-05-24 16:20:35 --> Security Class Initialized
DEBUG - 2025-05-24 16:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:20:35 --> Input Class Initialized
INFO - 2025-05-24 16:20:35 --> Language Class Initialized
INFO - 2025-05-24 16:20:35 --> Loader Class Initialized
INFO - 2025-05-24 16:20:35 --> Helper loaded: url_helper
INFO - 2025-05-24 16:20:35 --> Helper loaded: form_helper
INFO - 2025-05-24 16:20:35 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:20:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:20:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:20:35 --> Controller Class Initialized
INFO - 2025-05-24 16:20:35 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:20:35 --> Model "User_model" initialized
INFO - 2025-05-24 16:20:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 16:20:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 16:20:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-05-24 16:20:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 16:20:35 --> Final output sent to browser
DEBUG - 2025-05-24 16:20:35 --> Total execution time: 0.0790
INFO - 2025-05-24 16:20:41 --> Config Class Initialized
INFO - 2025-05-24 16:20:41 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:20:41 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:20:41 --> Utf8 Class Initialized
INFO - 2025-05-24 16:20:41 --> URI Class Initialized
INFO - 2025-05-24 16:20:41 --> Router Class Initialized
INFO - 2025-05-24 16:20:41 --> Output Class Initialized
INFO - 2025-05-24 16:20:41 --> Security Class Initialized
DEBUG - 2025-05-24 16:20:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:20:41 --> Input Class Initialized
INFO - 2025-05-24 16:20:41 --> Language Class Initialized
INFO - 2025-05-24 16:20:41 --> Loader Class Initialized
INFO - 2025-05-24 16:20:41 --> Helper loaded: url_helper
INFO - 2025-05-24 16:20:41 --> Helper loaded: form_helper
INFO - 2025-05-24 16:20:41 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:20:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:20:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:20:41 --> Controller Class Initialized
INFO - 2025-05-24 16:20:41 --> Model "Progress_model" initialized
INFO - 2025-05-24 16:20:41 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:20:41 --> Model "User_model" initialized
INFO - 2025-05-24 16:20:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 16:20:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 16:20:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-24 16:20:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 16:20:41 --> Final output sent to browser
DEBUG - 2025-05-24 16:20:41 --> Total execution time: 0.0897
INFO - 2025-05-24 16:20:41 --> Config Class Initialized
INFO - 2025-05-24 16:20:41 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:20:41 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:20:41 --> Utf8 Class Initialized
INFO - 2025-05-24 16:20:41 --> URI Class Initialized
INFO - 2025-05-24 16:20:42 --> Router Class Initialized
INFO - 2025-05-24 16:20:42 --> Output Class Initialized
INFO - 2025-05-24 16:20:42 --> Security Class Initialized
DEBUG - 2025-05-24 16:20:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:20:42 --> Input Class Initialized
INFO - 2025-05-24 16:20:42 --> Language Class Initialized
INFO - 2025-05-24 16:20:42 --> Loader Class Initialized
INFO - 2025-05-24 16:20:42 --> Helper loaded: url_helper
INFO - 2025-05-24 16:20:42 --> Helper loaded: form_helper
INFO - 2025-05-24 16:20:42 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:20:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:20:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:20:42 --> Controller Class Initialized
INFO - 2025-05-24 16:20:42 --> Model "Progress_model" initialized
INFO - 2025-05-24 16:20:42 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:20:42 --> Model "User_model" initialized
ERROR - 2025-05-24 16:20:42 --> Query error: Unknown column 'user_id' in 'where clause' - Invalid query: SELECT *
FROM `fitness_progress`
WHERE `status` = 'selesai'
AND `user_id` = '1'
INFO - 2025-05-24 16:20:42 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-24 16:20:47 --> Config Class Initialized
INFO - 2025-05-24 16:20:47 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:20:47 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:20:47 --> Utf8 Class Initialized
INFO - 2025-05-24 16:20:47 --> URI Class Initialized
INFO - 2025-05-24 16:20:47 --> Router Class Initialized
INFO - 2025-05-24 16:20:47 --> Output Class Initialized
INFO - 2025-05-24 16:20:47 --> Security Class Initialized
DEBUG - 2025-05-24 16:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:20:47 --> Input Class Initialized
INFO - 2025-05-24 16:20:47 --> Language Class Initialized
INFO - 2025-05-24 16:20:47 --> Loader Class Initialized
INFO - 2025-05-24 16:20:47 --> Helper loaded: url_helper
INFO - 2025-05-24 16:20:47 --> Helper loaded: form_helper
INFO - 2025-05-24 16:20:47 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:20:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:20:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:20:47 --> Controller Class Initialized
INFO - 2025-05-24 16:20:47 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:20:47 --> Model "User_model" initialized
INFO - 2025-05-24 16:20:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 16:20:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 16:20:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-05-24 16:20:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 16:20:47 --> Final output sent to browser
DEBUG - 2025-05-24 16:20:47 --> Total execution time: 0.0858
INFO - 2025-05-24 16:20:50 --> Config Class Initialized
INFO - 2025-05-24 16:20:50 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:20:50 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:20:50 --> Utf8 Class Initialized
INFO - 2025-05-24 16:20:50 --> URI Class Initialized
INFO - 2025-05-24 16:20:50 --> Router Class Initialized
INFO - 2025-05-24 16:20:50 --> Output Class Initialized
INFO - 2025-05-24 16:20:50 --> Security Class Initialized
DEBUG - 2025-05-24 16:20:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:20:50 --> Input Class Initialized
INFO - 2025-05-24 16:20:50 --> Language Class Initialized
INFO - 2025-05-24 16:20:50 --> Loader Class Initialized
INFO - 2025-05-24 16:20:50 --> Helper loaded: url_helper
INFO - 2025-05-24 16:20:50 --> Helper loaded: form_helper
INFO - 2025-05-24 16:20:50 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:20:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:20:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:20:50 --> Controller Class Initialized
INFO - 2025-05-24 16:20:50 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:20:50 --> Model "User_model" initialized
INFO - 2025-05-24 16:20:50 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 16:20:50 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 16:20:50 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-05-24 16:20:50 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 16:20:50 --> Final output sent to browser
DEBUG - 2025-05-24 16:20:50 --> Total execution time: 0.0983
INFO - 2025-05-24 16:20:52 --> Config Class Initialized
INFO - 2025-05-24 16:20:52 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:20:52 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:20:52 --> Utf8 Class Initialized
INFO - 2025-05-24 16:20:52 --> URI Class Initialized
INFO - 2025-05-24 16:20:52 --> Router Class Initialized
INFO - 2025-05-24 16:20:52 --> Output Class Initialized
INFO - 2025-05-24 16:20:52 --> Security Class Initialized
DEBUG - 2025-05-24 16:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:20:52 --> Input Class Initialized
INFO - 2025-05-24 16:20:52 --> Language Class Initialized
INFO - 2025-05-24 16:20:52 --> Loader Class Initialized
INFO - 2025-05-24 16:20:52 --> Helper loaded: url_helper
INFO - 2025-05-24 16:20:52 --> Helper loaded: form_helper
INFO - 2025-05-24 16:20:52 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:20:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:20:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:20:52 --> Controller Class Initialized
INFO - 2025-05-24 16:20:52 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:20:52 --> Model "User_model" initialized
INFO - 2025-05-24 16:20:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 16:20:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 16:20:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/menu.php
INFO - 2025-05-24 16:20:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 16:20:52 --> Final output sent to browser
DEBUG - 2025-05-24 16:20:52 --> Total execution time: 0.0773
INFO - 2025-05-24 16:20:54 --> Config Class Initialized
INFO - 2025-05-24 16:20:54 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:20:54 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:20:54 --> Utf8 Class Initialized
INFO - 2025-05-24 16:20:54 --> URI Class Initialized
INFO - 2025-05-24 16:20:54 --> Router Class Initialized
INFO - 2025-05-24 16:20:54 --> Output Class Initialized
INFO - 2025-05-24 16:20:54 --> Security Class Initialized
DEBUG - 2025-05-24 16:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:20:54 --> Input Class Initialized
INFO - 2025-05-24 16:20:54 --> Language Class Initialized
INFO - 2025-05-24 16:20:54 --> Loader Class Initialized
INFO - 2025-05-24 16:20:54 --> Helper loaded: url_helper
INFO - 2025-05-24 16:20:54 --> Helper loaded: form_helper
INFO - 2025-05-24 16:20:54 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:20:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:20:54 --> Controller Class Initialized
INFO - 2025-05-24 16:20:54 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:20:54 --> Model "User_model" initialized
INFO - 2025-05-24 16:20:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 16:20:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 16:20:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/start.php
INFO - 2025-05-24 16:20:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 16:20:54 --> Final output sent to browser
DEBUG - 2025-05-24 16:20:54 --> Total execution time: 0.0976
INFO - 2025-05-24 16:21:04 --> Config Class Initialized
INFO - 2025-05-24 16:21:04 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:21:04 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:21:04 --> Utf8 Class Initialized
INFO - 2025-05-24 16:21:04 --> URI Class Initialized
INFO - 2025-05-24 16:21:04 --> Router Class Initialized
INFO - 2025-05-24 16:21:04 --> Output Class Initialized
INFO - 2025-05-24 16:21:04 --> Security Class Initialized
DEBUG - 2025-05-24 16:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:21:04 --> Input Class Initialized
INFO - 2025-05-24 16:21:04 --> Language Class Initialized
INFO - 2025-05-24 16:21:04 --> Loader Class Initialized
INFO - 2025-05-24 16:21:04 --> Helper loaded: url_helper
INFO - 2025-05-24 16:21:04 --> Helper loaded: form_helper
INFO - 2025-05-24 16:21:04 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:21:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:21:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:21:04 --> Controller Class Initialized
INFO - 2025-05-24 16:21:04 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:21:04 --> Model "User_model" initialized
INFO - 2025-05-24 16:21:04 --> Final output sent to browser
DEBUG - 2025-05-24 16:21:04 --> Total execution time: 0.0852
INFO - 2025-05-24 16:21:07 --> Config Class Initialized
INFO - 2025-05-24 16:21:07 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:21:07 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:21:07 --> Utf8 Class Initialized
INFO - 2025-05-24 16:21:07 --> URI Class Initialized
INFO - 2025-05-24 16:21:07 --> Router Class Initialized
INFO - 2025-05-24 16:21:07 --> Output Class Initialized
INFO - 2025-05-24 16:21:07 --> Security Class Initialized
DEBUG - 2025-05-24 16:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:21:07 --> Input Class Initialized
INFO - 2025-05-24 16:21:07 --> Language Class Initialized
INFO - 2025-05-24 16:21:07 --> Loader Class Initialized
INFO - 2025-05-24 16:21:07 --> Helper loaded: url_helper
INFO - 2025-05-24 16:21:07 --> Helper loaded: form_helper
INFO - 2025-05-24 16:21:07 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:21:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:21:07 --> Controller Class Initialized
INFO - 2025-05-24 16:21:07 --> Model "Progress_model" initialized
INFO - 2025-05-24 16:21:07 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:21:07 --> Model "User_model" initialized
INFO - 2025-05-24 16:21:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 16:21:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 16:21:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-24 16:21:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 16:21:07 --> Final output sent to browser
DEBUG - 2025-05-24 16:21:07 --> Total execution time: 0.0868
INFO - 2025-05-24 16:21:08 --> Config Class Initialized
INFO - 2025-05-24 16:21:08 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:21:08 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:21:08 --> Utf8 Class Initialized
INFO - 2025-05-24 16:21:08 --> URI Class Initialized
INFO - 2025-05-24 16:21:08 --> Router Class Initialized
INFO - 2025-05-24 16:21:08 --> Output Class Initialized
INFO - 2025-05-24 16:21:08 --> Security Class Initialized
DEBUG - 2025-05-24 16:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:21:08 --> Input Class Initialized
INFO - 2025-05-24 16:21:08 --> Language Class Initialized
INFO - 2025-05-24 16:21:08 --> Loader Class Initialized
INFO - 2025-05-24 16:21:08 --> Helper loaded: url_helper
INFO - 2025-05-24 16:21:08 --> Helper loaded: form_helper
INFO - 2025-05-24 16:21:08 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:21:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:21:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:21:08 --> Controller Class Initialized
INFO - 2025-05-24 16:21:08 --> Model "Progress_model" initialized
INFO - 2025-05-24 16:21:08 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:21:08 --> Model "User_model" initialized
ERROR - 2025-05-24 16:21:08 --> Query error: Unknown column 'user_id' in 'where clause' - Invalid query: SELECT *
FROM `fitness_progress`
WHERE `status` = 'selesai'
AND `user_id` = '1'
INFO - 2025-05-24 16:21:08 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-24 16:28:30 --> Config Class Initialized
INFO - 2025-05-24 16:28:30 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:28:30 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:28:30 --> Utf8 Class Initialized
INFO - 2025-05-24 16:28:30 --> URI Class Initialized
INFO - 2025-05-24 16:28:30 --> Router Class Initialized
INFO - 2025-05-24 16:28:30 --> Output Class Initialized
INFO - 2025-05-24 16:28:30 --> Security Class Initialized
DEBUG - 2025-05-24 16:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:28:30 --> Input Class Initialized
INFO - 2025-05-24 16:28:30 --> Language Class Initialized
INFO - 2025-05-24 16:28:30 --> Loader Class Initialized
INFO - 2025-05-24 16:28:30 --> Helper loaded: url_helper
INFO - 2025-05-24 16:28:30 --> Helper loaded: form_helper
INFO - 2025-05-24 16:28:30 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:28:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:28:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:28:30 --> Controller Class Initialized
INFO - 2025-05-24 16:28:30 --> Model "Progress_model" initialized
INFO - 2025-05-24 16:28:30 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:28:30 --> Model "User_model" initialized
INFO - 2025-05-24 16:28:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 16:28:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 16:28:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-24 16:28:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 16:28:30 --> Final output sent to browser
DEBUG - 2025-05-24 16:28:30 --> Total execution time: 0.0697
INFO - 2025-05-24 16:28:31 --> Config Class Initialized
INFO - 2025-05-24 16:28:31 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:28:31 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:28:31 --> Utf8 Class Initialized
INFO - 2025-05-24 16:28:31 --> URI Class Initialized
INFO - 2025-05-24 16:28:31 --> Router Class Initialized
INFO - 2025-05-24 16:28:31 --> Output Class Initialized
INFO - 2025-05-24 16:28:31 --> Security Class Initialized
DEBUG - 2025-05-24 16:28:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:28:31 --> Input Class Initialized
INFO - 2025-05-24 16:28:31 --> Language Class Initialized
INFO - 2025-05-24 16:28:31 --> Loader Class Initialized
INFO - 2025-05-24 16:28:31 --> Helper loaded: url_helper
INFO - 2025-05-24 16:28:31 --> Helper loaded: form_helper
INFO - 2025-05-24 16:28:31 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:28:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:28:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:28:31 --> Controller Class Initialized
INFO - 2025-05-24 16:28:31 --> Model "Progress_model" initialized
INFO - 2025-05-24 16:28:31 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:28:31 --> Model "User_model" initialized
INFO - 2025-05-24 16:28:31 --> Final output sent to browser
DEBUG - 2025-05-24 16:28:31 --> Total execution time: 0.0850
INFO - 2025-05-24 16:28:32 --> Config Class Initialized
INFO - 2025-05-24 16:28:32 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:28:32 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:28:32 --> Utf8 Class Initialized
INFO - 2025-05-24 16:28:32 --> URI Class Initialized
INFO - 2025-05-24 16:28:32 --> Router Class Initialized
INFO - 2025-05-24 16:28:32 --> Output Class Initialized
INFO - 2025-05-24 16:28:32 --> Security Class Initialized
DEBUG - 2025-05-24 16:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:28:32 --> Input Class Initialized
INFO - 2025-05-24 16:28:32 --> Language Class Initialized
INFO - 2025-05-24 16:28:32 --> Loader Class Initialized
INFO - 2025-05-24 16:28:32 --> Helper loaded: url_helper
INFO - 2025-05-24 16:28:32 --> Helper loaded: form_helper
INFO - 2025-05-24 16:28:32 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:28:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:28:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:28:32 --> Controller Class Initialized
INFO - 2025-05-24 16:28:32 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:28:32 --> Model "User_model" initialized
INFO - 2025-05-24 16:28:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 16:28:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 16:28:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-05-24 16:28:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 16:28:32 --> Final output sent to browser
DEBUG - 2025-05-24 16:28:32 --> Total execution time: 0.0698
INFO - 2025-05-24 16:28:38 --> Config Class Initialized
INFO - 2025-05-24 16:28:38 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:28:38 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:28:38 --> Utf8 Class Initialized
INFO - 2025-05-24 16:28:38 --> URI Class Initialized
INFO - 2025-05-24 16:28:38 --> Router Class Initialized
INFO - 2025-05-24 16:28:38 --> Output Class Initialized
INFO - 2025-05-24 16:28:38 --> Security Class Initialized
DEBUG - 2025-05-24 16:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:28:38 --> Input Class Initialized
INFO - 2025-05-24 16:28:38 --> Language Class Initialized
INFO - 2025-05-24 16:28:38 --> Loader Class Initialized
INFO - 2025-05-24 16:28:38 --> Helper loaded: url_helper
INFO - 2025-05-24 16:28:38 --> Helper loaded: form_helper
INFO - 2025-05-24 16:28:38 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:28:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:28:38 --> Controller Class Initialized
INFO - 2025-05-24 16:28:38 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:28:38 --> Model "User_model" initialized
INFO - 2025-05-24 16:28:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 16:28:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 16:28:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-05-24 16:28:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 16:28:38 --> Final output sent to browser
DEBUG - 2025-05-24 16:28:38 --> Total execution time: 0.1131
INFO - 2025-05-24 16:28:40 --> Config Class Initialized
INFO - 2025-05-24 16:28:40 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:28:40 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:28:40 --> Utf8 Class Initialized
INFO - 2025-05-24 16:28:40 --> URI Class Initialized
INFO - 2025-05-24 16:28:40 --> Router Class Initialized
INFO - 2025-05-24 16:28:40 --> Output Class Initialized
INFO - 2025-05-24 16:28:40 --> Security Class Initialized
DEBUG - 2025-05-24 16:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:28:40 --> Input Class Initialized
INFO - 2025-05-24 16:28:40 --> Language Class Initialized
INFO - 2025-05-24 16:28:40 --> Loader Class Initialized
INFO - 2025-05-24 16:28:40 --> Helper loaded: url_helper
INFO - 2025-05-24 16:28:40 --> Helper loaded: form_helper
INFO - 2025-05-24 16:28:40 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:28:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:28:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:28:40 --> Controller Class Initialized
INFO - 2025-05-24 16:28:40 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:28:40 --> Model "User_model" initialized
INFO - 2025-05-24 16:28:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 16:28:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 16:28:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/menu.php
INFO - 2025-05-24 16:28:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 16:28:40 --> Final output sent to browser
DEBUG - 2025-05-24 16:28:40 --> Total execution time: 0.0702
INFO - 2025-05-24 16:28:42 --> Config Class Initialized
INFO - 2025-05-24 16:28:42 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:28:42 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:28:42 --> Utf8 Class Initialized
INFO - 2025-05-24 16:28:42 --> URI Class Initialized
INFO - 2025-05-24 16:28:42 --> Router Class Initialized
INFO - 2025-05-24 16:28:42 --> Output Class Initialized
INFO - 2025-05-24 16:28:42 --> Security Class Initialized
DEBUG - 2025-05-24 16:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:28:42 --> Input Class Initialized
INFO - 2025-05-24 16:28:42 --> Language Class Initialized
INFO - 2025-05-24 16:28:42 --> Loader Class Initialized
INFO - 2025-05-24 16:28:42 --> Helper loaded: url_helper
INFO - 2025-05-24 16:28:42 --> Helper loaded: form_helper
INFO - 2025-05-24 16:28:42 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:28:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:28:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:28:42 --> Controller Class Initialized
INFO - 2025-05-24 16:28:42 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:28:42 --> Model "User_model" initialized
INFO - 2025-05-24 16:28:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 16:28:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 16:28:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/start.php
INFO - 2025-05-24 16:28:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 16:28:42 --> Final output sent to browser
DEBUG - 2025-05-24 16:28:42 --> Total execution time: 0.0888
INFO - 2025-05-24 16:28:51 --> Config Class Initialized
INFO - 2025-05-24 16:28:51 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:28:51 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:28:51 --> Utf8 Class Initialized
INFO - 2025-05-24 16:28:51 --> URI Class Initialized
INFO - 2025-05-24 16:28:51 --> Router Class Initialized
INFO - 2025-05-24 16:28:51 --> Output Class Initialized
INFO - 2025-05-24 16:28:51 --> Security Class Initialized
DEBUG - 2025-05-24 16:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:28:51 --> Input Class Initialized
INFO - 2025-05-24 16:28:51 --> Language Class Initialized
INFO - 2025-05-24 16:28:51 --> Loader Class Initialized
INFO - 2025-05-24 16:28:51 --> Helper loaded: url_helper
INFO - 2025-05-24 16:28:51 --> Helper loaded: form_helper
INFO - 2025-05-24 16:28:51 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:28:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:28:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:28:51 --> Controller Class Initialized
INFO - 2025-05-24 16:28:51 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:28:51 --> Model "User_model" initialized
INFO - 2025-05-24 16:28:51 --> Final output sent to browser
DEBUG - 2025-05-24 16:28:51 --> Total execution time: 0.0945
INFO - 2025-05-24 16:28:54 --> Config Class Initialized
INFO - 2025-05-24 16:28:54 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:28:54 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:28:54 --> Utf8 Class Initialized
INFO - 2025-05-24 16:28:54 --> URI Class Initialized
INFO - 2025-05-24 16:28:54 --> Router Class Initialized
INFO - 2025-05-24 16:28:54 --> Output Class Initialized
INFO - 2025-05-24 16:28:54 --> Security Class Initialized
DEBUG - 2025-05-24 16:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:28:54 --> Input Class Initialized
INFO - 2025-05-24 16:28:54 --> Language Class Initialized
INFO - 2025-05-24 16:28:54 --> Loader Class Initialized
INFO - 2025-05-24 16:28:54 --> Helper loaded: url_helper
INFO - 2025-05-24 16:28:54 --> Helper loaded: form_helper
INFO - 2025-05-24 16:28:54 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:28:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:28:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:28:54 --> Controller Class Initialized
INFO - 2025-05-24 16:28:54 --> Model "Progress_model" initialized
INFO - 2025-05-24 16:28:54 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:28:54 --> Model "User_model" initialized
INFO - 2025-05-24 16:28:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 16:28:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 16:28:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-24 16:28:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 16:28:54 --> Final output sent to browser
DEBUG - 2025-05-24 16:28:54 --> Total execution time: 0.0865
INFO - 2025-05-24 16:28:54 --> Config Class Initialized
INFO - 2025-05-24 16:28:54 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:28:54 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:28:54 --> Utf8 Class Initialized
INFO - 2025-05-24 16:28:54 --> URI Class Initialized
INFO - 2025-05-24 16:28:54 --> Router Class Initialized
INFO - 2025-05-24 16:28:54 --> Output Class Initialized
INFO - 2025-05-24 16:28:54 --> Security Class Initialized
DEBUG - 2025-05-24 16:28:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:28:55 --> Input Class Initialized
INFO - 2025-05-24 16:28:55 --> Language Class Initialized
INFO - 2025-05-24 16:28:55 --> Loader Class Initialized
INFO - 2025-05-24 16:28:55 --> Helper loaded: url_helper
INFO - 2025-05-24 16:28:55 --> Helper loaded: form_helper
INFO - 2025-05-24 16:28:55 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:28:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:28:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:28:55 --> Controller Class Initialized
INFO - 2025-05-24 16:28:55 --> Model "Progress_model" initialized
INFO - 2025-05-24 16:28:55 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:28:55 --> Model "User_model" initialized
INFO - 2025-05-24 16:28:55 --> Final output sent to browser
DEBUG - 2025-05-24 16:28:55 --> Total execution time: 0.0801
INFO - 2025-05-24 16:30:52 --> Config Class Initialized
INFO - 2025-05-24 16:30:52 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:30:52 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:30:52 --> Utf8 Class Initialized
INFO - 2025-05-24 16:30:52 --> URI Class Initialized
INFO - 2025-05-24 16:30:52 --> Router Class Initialized
INFO - 2025-05-24 16:30:52 --> Output Class Initialized
INFO - 2025-05-24 16:30:52 --> Security Class Initialized
DEBUG - 2025-05-24 16:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:30:52 --> Input Class Initialized
INFO - 2025-05-24 16:30:52 --> Language Class Initialized
INFO - 2025-05-24 16:30:52 --> Loader Class Initialized
INFO - 2025-05-24 16:30:52 --> Helper loaded: url_helper
INFO - 2025-05-24 16:30:52 --> Helper loaded: form_helper
INFO - 2025-05-24 16:30:52 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:30:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:30:52 --> Controller Class Initialized
INFO - 2025-05-24 16:30:52 --> Model "User_model" initialized
INFO - 2025-05-24 16:30:52 --> Config Class Initialized
INFO - 2025-05-24 16:30:52 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:30:52 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:30:52 --> Utf8 Class Initialized
INFO - 2025-05-24 16:30:52 --> URI Class Initialized
INFO - 2025-05-24 16:30:52 --> Router Class Initialized
INFO - 2025-05-24 16:30:52 --> Output Class Initialized
INFO - 2025-05-24 16:30:52 --> Security Class Initialized
DEBUG - 2025-05-24 16:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:30:52 --> Input Class Initialized
INFO - 2025-05-24 16:30:52 --> Language Class Initialized
INFO - 2025-05-24 16:30:52 --> Loader Class Initialized
INFO - 2025-05-24 16:30:52 --> Helper loaded: url_helper
INFO - 2025-05-24 16:30:52 --> Helper loaded: form_helper
INFO - 2025-05-24 16:30:52 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:30:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:30:52 --> Controller Class Initialized
INFO - 2025-05-24 16:30:52 --> Model "User_model" initialized
INFO - 2025-05-24 16:30:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-24 16:30:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-24 16:30:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-24 16:30:52 --> Final output sent to browser
DEBUG - 2025-05-24 16:30:52 --> Total execution time: 0.0767
INFO - 2025-05-24 16:30:54 --> Config Class Initialized
INFO - 2025-05-24 16:30:54 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:30:54 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:30:54 --> Utf8 Class Initialized
INFO - 2025-05-24 16:30:54 --> URI Class Initialized
INFO - 2025-05-24 16:30:54 --> Router Class Initialized
INFO - 2025-05-24 16:30:54 --> Output Class Initialized
INFO - 2025-05-24 16:30:54 --> Security Class Initialized
DEBUG - 2025-05-24 16:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:30:54 --> Input Class Initialized
INFO - 2025-05-24 16:30:54 --> Language Class Initialized
INFO - 2025-05-24 16:30:54 --> Loader Class Initialized
INFO - 2025-05-24 16:30:54 --> Helper loaded: url_helper
INFO - 2025-05-24 16:30:54 --> Helper loaded: form_helper
INFO - 2025-05-24 16:30:54 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:30:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:30:54 --> Controller Class Initialized
INFO - 2025-05-24 16:30:54 --> Model "User_model" initialized
INFO - 2025-05-24 16:30:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-24 16:30:54 --> Final output sent to browser
DEBUG - 2025-05-24 16:30:54 --> Total execution time: 0.0913
INFO - 2025-05-24 16:31:00 --> Config Class Initialized
INFO - 2025-05-24 16:31:00 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:31:00 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:31:00 --> Utf8 Class Initialized
INFO - 2025-05-24 16:31:00 --> URI Class Initialized
INFO - 2025-05-24 16:31:00 --> Router Class Initialized
INFO - 2025-05-24 16:31:00 --> Output Class Initialized
INFO - 2025-05-24 16:31:00 --> Security Class Initialized
DEBUG - 2025-05-24 16:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:31:00 --> Input Class Initialized
INFO - 2025-05-24 16:31:00 --> Language Class Initialized
INFO - 2025-05-24 16:31:00 --> Loader Class Initialized
INFO - 2025-05-24 16:31:00 --> Helper loaded: url_helper
INFO - 2025-05-24 16:31:00 --> Helper loaded: form_helper
INFO - 2025-05-24 16:31:00 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:31:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:31:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:31:00 --> Controller Class Initialized
INFO - 2025-05-24 16:31:00 --> Model "User_model" initialized
INFO - 2025-05-24 16:31:00 --> Config Class Initialized
INFO - 2025-05-24 16:31:00 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:31:00 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:31:00 --> Utf8 Class Initialized
INFO - 2025-05-24 16:31:00 --> URI Class Initialized
INFO - 2025-05-24 16:31:00 --> Router Class Initialized
INFO - 2025-05-24 16:31:00 --> Output Class Initialized
INFO - 2025-05-24 16:31:00 --> Security Class Initialized
DEBUG - 2025-05-24 16:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:31:00 --> Input Class Initialized
INFO - 2025-05-24 16:31:00 --> Language Class Initialized
INFO - 2025-05-24 16:31:00 --> Loader Class Initialized
INFO - 2025-05-24 16:31:00 --> Helper loaded: url_helper
INFO - 2025-05-24 16:31:00 --> Helper loaded: form_helper
INFO - 2025-05-24 16:31:00 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:31:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:31:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:31:00 --> Controller Class Initialized
INFO - 2025-05-24 16:31:00 --> Model "User_model" initialized
INFO - 2025-05-24 16:31:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-24 16:31:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-24 16:31:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-24 16:31:00 --> Final output sent to browser
DEBUG - 2025-05-24 16:31:00 --> Total execution time: 0.0706
INFO - 2025-05-24 16:31:02 --> Config Class Initialized
INFO - 2025-05-24 16:31:02 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:31:02 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:31:02 --> Utf8 Class Initialized
INFO - 2025-05-24 16:31:02 --> URI Class Initialized
INFO - 2025-05-24 16:31:02 --> Router Class Initialized
INFO - 2025-05-24 16:31:02 --> Output Class Initialized
INFO - 2025-05-24 16:31:02 --> Security Class Initialized
DEBUG - 2025-05-24 16:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:31:02 --> Input Class Initialized
INFO - 2025-05-24 16:31:02 --> Language Class Initialized
INFO - 2025-05-24 16:31:02 --> Loader Class Initialized
INFO - 2025-05-24 16:31:02 --> Helper loaded: url_helper
INFO - 2025-05-24 16:31:02 --> Helper loaded: form_helper
INFO - 2025-05-24 16:31:02 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:31:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:31:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:31:02 --> Controller Class Initialized
INFO - 2025-05-24 16:31:02 --> Model "User_model" initialized
INFO - 2025-05-24 16:31:02 --> Model "Workout_model" initialized
INFO - 2025-05-24 16:31:02 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 16:31:02 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 16:31:02 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-24 16:31:02 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 16:31:02 --> Final output sent to browser
DEBUG - 2025-05-24 16:31:02 --> Total execution time: 0.0942
INFO - 2025-05-24 16:31:04 --> Config Class Initialized
INFO - 2025-05-24 16:31:04 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:31:04 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:31:04 --> Utf8 Class Initialized
INFO - 2025-05-24 16:31:04 --> URI Class Initialized
INFO - 2025-05-24 16:31:04 --> Router Class Initialized
INFO - 2025-05-24 16:31:04 --> Output Class Initialized
INFO - 2025-05-24 16:31:04 --> Security Class Initialized
DEBUG - 2025-05-24 16:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:31:04 --> Input Class Initialized
INFO - 2025-05-24 16:31:04 --> Language Class Initialized
INFO - 2025-05-24 16:31:04 --> Loader Class Initialized
INFO - 2025-05-24 16:31:04 --> Helper loaded: url_helper
INFO - 2025-05-24 16:31:04 --> Helper loaded: form_helper
INFO - 2025-05-24 16:31:04 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:31:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:31:04 --> Controller Class Initialized
INFO - 2025-05-24 16:31:04 --> Model "Progress_model" initialized
INFO - 2025-05-24 16:31:04 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:31:04 --> Model "User_model" initialized
INFO - 2025-05-24 16:31:04 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 16:31:04 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 16:31:04 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-24 16:31:04 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 16:31:04 --> Final output sent to browser
DEBUG - 2025-05-24 16:31:04 --> Total execution time: 0.0633
INFO - 2025-05-24 16:31:04 --> Config Class Initialized
INFO - 2025-05-24 16:31:04 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:31:04 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:31:04 --> Utf8 Class Initialized
INFO - 2025-05-24 16:31:04 --> URI Class Initialized
INFO - 2025-05-24 16:31:04 --> Router Class Initialized
INFO - 2025-05-24 16:31:04 --> Output Class Initialized
INFO - 2025-05-24 16:31:04 --> Security Class Initialized
DEBUG - 2025-05-24 16:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:31:04 --> Input Class Initialized
INFO - 2025-05-24 16:31:04 --> Language Class Initialized
INFO - 2025-05-24 16:31:04 --> Loader Class Initialized
INFO - 2025-05-24 16:31:04 --> Helper loaded: url_helper
INFO - 2025-05-24 16:31:04 --> Helper loaded: form_helper
INFO - 2025-05-24 16:31:04 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:31:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:31:04 --> Controller Class Initialized
INFO - 2025-05-24 16:31:04 --> Model "Progress_model" initialized
INFO - 2025-05-24 16:31:04 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:31:04 --> Model "User_model" initialized
INFO - 2025-05-24 16:31:04 --> Final output sent to browser
DEBUG - 2025-05-24 16:31:04 --> Total execution time: 0.0666
INFO - 2025-05-24 16:31:07 --> Config Class Initialized
INFO - 2025-05-24 16:31:07 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:31:07 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:31:07 --> Utf8 Class Initialized
INFO - 2025-05-24 16:31:07 --> URI Class Initialized
INFO - 2025-05-24 16:31:07 --> Router Class Initialized
INFO - 2025-05-24 16:31:07 --> Output Class Initialized
INFO - 2025-05-24 16:31:07 --> Security Class Initialized
DEBUG - 2025-05-24 16:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:31:07 --> Input Class Initialized
INFO - 2025-05-24 16:31:07 --> Language Class Initialized
INFO - 2025-05-24 16:31:07 --> Loader Class Initialized
INFO - 2025-05-24 16:31:07 --> Helper loaded: url_helper
INFO - 2025-05-24 16:31:07 --> Helper loaded: form_helper
INFO - 2025-05-24 16:31:07 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:31:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:31:07 --> Controller Class Initialized
INFO - 2025-05-24 16:31:07 --> Model "User_model" initialized
INFO - 2025-05-24 16:31:07 --> Model "Workout_model" initialized
INFO - 2025-05-24 16:31:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 16:31:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 16:31:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-24 16:31:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 16:31:07 --> Final output sent to browser
DEBUG - 2025-05-24 16:31:07 --> Total execution time: 0.1038
INFO - 2025-05-24 16:31:09 --> Config Class Initialized
INFO - 2025-05-24 16:31:09 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:31:09 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:31:09 --> Utf8 Class Initialized
INFO - 2025-05-24 16:31:09 --> URI Class Initialized
INFO - 2025-05-24 16:31:09 --> Router Class Initialized
INFO - 2025-05-24 16:31:09 --> Output Class Initialized
INFO - 2025-05-24 16:31:09 --> Security Class Initialized
DEBUG - 2025-05-24 16:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:31:09 --> Input Class Initialized
INFO - 2025-05-24 16:31:09 --> Language Class Initialized
INFO - 2025-05-24 16:31:09 --> Loader Class Initialized
INFO - 2025-05-24 16:31:09 --> Helper loaded: url_helper
INFO - 2025-05-24 16:31:09 --> Helper loaded: form_helper
INFO - 2025-05-24 16:31:09 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:31:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:31:09 --> Controller Class Initialized
INFO - 2025-05-24 16:31:09 --> Model "Progress_model" initialized
INFO - 2025-05-24 16:31:09 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:31:09 --> Model "User_model" initialized
INFO - 2025-05-24 16:31:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 16:31:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 16:31:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-24 16:31:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 16:31:09 --> Final output sent to browser
DEBUG - 2025-05-24 16:31:09 --> Total execution time: 0.0645
INFO - 2025-05-24 16:31:09 --> Config Class Initialized
INFO - 2025-05-24 16:31:09 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:31:09 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:31:09 --> Utf8 Class Initialized
INFO - 2025-05-24 16:31:09 --> URI Class Initialized
INFO - 2025-05-24 16:31:09 --> Router Class Initialized
INFO - 2025-05-24 16:31:09 --> Output Class Initialized
INFO - 2025-05-24 16:31:09 --> Security Class Initialized
DEBUG - 2025-05-24 16:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:31:09 --> Input Class Initialized
INFO - 2025-05-24 16:31:09 --> Language Class Initialized
INFO - 2025-05-24 16:31:09 --> Loader Class Initialized
INFO - 2025-05-24 16:31:09 --> Helper loaded: url_helper
INFO - 2025-05-24 16:31:09 --> Helper loaded: form_helper
INFO - 2025-05-24 16:31:09 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:31:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:31:09 --> Controller Class Initialized
INFO - 2025-05-24 16:31:09 --> Model "Progress_model" initialized
INFO - 2025-05-24 16:31:09 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:31:09 --> Model "User_model" initialized
INFO - 2025-05-24 16:31:09 --> Final output sent to browser
DEBUG - 2025-05-24 16:31:09 --> Total execution time: 0.0590
INFO - 2025-05-24 16:31:11 --> Config Class Initialized
INFO - 2025-05-24 16:31:11 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:31:11 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:31:11 --> Utf8 Class Initialized
INFO - 2025-05-24 16:31:11 --> URI Class Initialized
INFO - 2025-05-24 16:31:11 --> Router Class Initialized
INFO - 2025-05-24 16:31:11 --> Output Class Initialized
INFO - 2025-05-24 16:31:11 --> Security Class Initialized
DEBUG - 2025-05-24 16:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:31:11 --> Input Class Initialized
INFO - 2025-05-24 16:31:11 --> Language Class Initialized
INFO - 2025-05-24 16:31:11 --> Loader Class Initialized
INFO - 2025-05-24 16:31:11 --> Helper loaded: url_helper
INFO - 2025-05-24 16:31:11 --> Helper loaded: form_helper
INFO - 2025-05-24 16:31:11 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:31:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:31:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:31:11 --> Controller Class Initialized
INFO - 2025-05-24 16:31:11 --> Model "User_model" initialized
INFO - 2025-05-24 16:31:11 --> Model "Workout_model" initialized
INFO - 2025-05-24 16:31:11 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 16:31:11 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 16:31:11 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-24 16:31:11 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 16:31:11 --> Final output sent to browser
DEBUG - 2025-05-24 16:31:11 --> Total execution time: 0.0693
INFO - 2025-05-24 16:31:17 --> Config Class Initialized
INFO - 2025-05-24 16:31:17 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:31:17 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:31:17 --> Utf8 Class Initialized
INFO - 2025-05-24 16:31:17 --> URI Class Initialized
INFO - 2025-05-24 16:31:17 --> Router Class Initialized
INFO - 2025-05-24 16:31:17 --> Output Class Initialized
INFO - 2025-05-24 16:31:17 --> Security Class Initialized
DEBUG - 2025-05-24 16:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:31:17 --> Input Class Initialized
INFO - 2025-05-24 16:31:17 --> Language Class Initialized
INFO - 2025-05-24 16:31:17 --> Loader Class Initialized
INFO - 2025-05-24 16:31:17 --> Helper loaded: url_helper
INFO - 2025-05-24 16:31:17 --> Helper loaded: form_helper
INFO - 2025-05-24 16:31:17 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:31:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:31:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:31:17 --> Controller Class Initialized
INFO - 2025-05-24 16:31:17 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:31:17 --> Model "User_model" initialized
INFO - 2025-05-24 16:31:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 16:31:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 16:31:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-05-24 16:31:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 16:31:17 --> Final output sent to browser
DEBUG - 2025-05-24 16:31:17 --> Total execution time: 0.0827
INFO - 2025-05-24 16:31:19 --> Config Class Initialized
INFO - 2025-05-24 16:31:19 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:31:19 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:31:19 --> Utf8 Class Initialized
INFO - 2025-05-24 16:31:19 --> URI Class Initialized
INFO - 2025-05-24 16:31:19 --> Router Class Initialized
INFO - 2025-05-24 16:31:19 --> Output Class Initialized
INFO - 2025-05-24 16:31:19 --> Security Class Initialized
DEBUG - 2025-05-24 16:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:31:19 --> Input Class Initialized
INFO - 2025-05-24 16:31:19 --> Language Class Initialized
INFO - 2025-05-24 16:31:19 --> Loader Class Initialized
INFO - 2025-05-24 16:31:19 --> Helper loaded: url_helper
INFO - 2025-05-24 16:31:19 --> Helper loaded: form_helper
INFO - 2025-05-24 16:31:19 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:31:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:31:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:31:19 --> Controller Class Initialized
INFO - 2025-05-24 16:31:19 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:31:19 --> Model "User_model" initialized
INFO - 2025-05-24 16:31:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 16:31:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 16:31:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-05-24 16:31:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 16:31:19 --> Final output sent to browser
DEBUG - 2025-05-24 16:31:19 --> Total execution time: 0.0672
INFO - 2025-05-24 16:31:20 --> Config Class Initialized
INFO - 2025-05-24 16:31:20 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:31:20 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:31:20 --> Utf8 Class Initialized
INFO - 2025-05-24 16:31:20 --> URI Class Initialized
INFO - 2025-05-24 16:31:20 --> Router Class Initialized
INFO - 2025-05-24 16:31:20 --> Output Class Initialized
INFO - 2025-05-24 16:31:20 --> Security Class Initialized
DEBUG - 2025-05-24 16:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:31:20 --> Input Class Initialized
INFO - 2025-05-24 16:31:20 --> Language Class Initialized
INFO - 2025-05-24 16:31:20 --> Loader Class Initialized
INFO - 2025-05-24 16:31:20 --> Helper loaded: url_helper
INFO - 2025-05-24 16:31:20 --> Helper loaded: form_helper
INFO - 2025-05-24 16:31:20 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:31:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:31:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:31:21 --> Controller Class Initialized
INFO - 2025-05-24 16:31:21 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:31:21 --> Model "User_model" initialized
INFO - 2025-05-24 16:31:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 16:31:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 16:31:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/menu.php
INFO - 2025-05-24 16:31:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 16:31:21 --> Final output sent to browser
DEBUG - 2025-05-24 16:31:21 --> Total execution time: 0.0740
INFO - 2025-05-24 16:31:22 --> Config Class Initialized
INFO - 2025-05-24 16:31:22 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:31:22 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:31:22 --> Utf8 Class Initialized
INFO - 2025-05-24 16:31:22 --> URI Class Initialized
INFO - 2025-05-24 16:31:22 --> Router Class Initialized
INFO - 2025-05-24 16:31:22 --> Output Class Initialized
INFO - 2025-05-24 16:31:22 --> Security Class Initialized
DEBUG - 2025-05-24 16:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:31:22 --> Input Class Initialized
INFO - 2025-05-24 16:31:22 --> Language Class Initialized
INFO - 2025-05-24 16:31:22 --> Loader Class Initialized
INFO - 2025-05-24 16:31:22 --> Helper loaded: url_helper
INFO - 2025-05-24 16:31:22 --> Helper loaded: form_helper
INFO - 2025-05-24 16:31:22 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:31:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:31:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:31:22 --> Controller Class Initialized
INFO - 2025-05-24 16:31:22 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:31:22 --> Model "User_model" initialized
INFO - 2025-05-24 16:31:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 16:31:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 16:31:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/start.php
INFO - 2025-05-24 16:31:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 16:31:22 --> Final output sent to browser
DEBUG - 2025-05-24 16:31:22 --> Total execution time: 0.0938
INFO - 2025-05-24 16:31:31 --> Config Class Initialized
INFO - 2025-05-24 16:31:31 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:31:31 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:31:31 --> Utf8 Class Initialized
INFO - 2025-05-24 16:31:31 --> URI Class Initialized
INFO - 2025-05-24 16:31:31 --> Router Class Initialized
INFO - 2025-05-24 16:31:31 --> Output Class Initialized
INFO - 2025-05-24 16:31:31 --> Security Class Initialized
DEBUG - 2025-05-24 16:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:31:31 --> Input Class Initialized
INFO - 2025-05-24 16:31:31 --> Language Class Initialized
INFO - 2025-05-24 16:31:31 --> Loader Class Initialized
INFO - 2025-05-24 16:31:31 --> Helper loaded: url_helper
INFO - 2025-05-24 16:31:31 --> Helper loaded: form_helper
INFO - 2025-05-24 16:31:31 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:31:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:31:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:31:31 --> Controller Class Initialized
INFO - 2025-05-24 16:31:31 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:31:31 --> Model "User_model" initialized
INFO - 2025-05-24 16:31:31 --> Final output sent to browser
DEBUG - 2025-05-24 16:31:31 --> Total execution time: 0.0787
INFO - 2025-05-24 16:31:35 --> Config Class Initialized
INFO - 2025-05-24 16:31:35 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:31:35 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:31:35 --> Utf8 Class Initialized
INFO - 2025-05-24 16:31:35 --> URI Class Initialized
INFO - 2025-05-24 16:31:35 --> Router Class Initialized
INFO - 2025-05-24 16:31:35 --> Output Class Initialized
INFO - 2025-05-24 16:31:35 --> Security Class Initialized
DEBUG - 2025-05-24 16:31:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:31:35 --> Input Class Initialized
INFO - 2025-05-24 16:31:35 --> Language Class Initialized
INFO - 2025-05-24 16:31:35 --> Loader Class Initialized
INFO - 2025-05-24 16:31:35 --> Helper loaded: url_helper
INFO - 2025-05-24 16:31:35 --> Helper loaded: form_helper
INFO - 2025-05-24 16:31:35 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:31:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:31:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:31:35 --> Controller Class Initialized
INFO - 2025-05-24 16:31:35 --> Model "Progress_model" initialized
INFO - 2025-05-24 16:31:35 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:31:35 --> Model "User_model" initialized
INFO - 2025-05-24 16:31:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 16:31:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 16:31:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-24 16:31:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 16:31:35 --> Final output sent to browser
DEBUG - 2025-05-24 16:31:35 --> Total execution time: 0.1013
INFO - 2025-05-24 16:31:35 --> Config Class Initialized
INFO - 2025-05-24 16:31:35 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:31:35 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:31:35 --> Utf8 Class Initialized
INFO - 2025-05-24 16:31:35 --> URI Class Initialized
INFO - 2025-05-24 16:31:35 --> Router Class Initialized
INFO - 2025-05-24 16:31:35 --> Output Class Initialized
INFO - 2025-05-24 16:31:35 --> Security Class Initialized
DEBUG - 2025-05-24 16:31:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:31:35 --> Input Class Initialized
INFO - 2025-05-24 16:31:35 --> Language Class Initialized
INFO - 2025-05-24 16:31:35 --> Loader Class Initialized
INFO - 2025-05-24 16:31:35 --> Helper loaded: url_helper
INFO - 2025-05-24 16:31:35 --> Helper loaded: form_helper
INFO - 2025-05-24 16:31:35 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:31:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:31:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:31:35 --> Controller Class Initialized
INFO - 2025-05-24 16:31:35 --> Model "Progress_model" initialized
INFO - 2025-05-24 16:31:35 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:31:35 --> Model "User_model" initialized
INFO - 2025-05-24 16:31:35 --> Final output sent to browser
DEBUG - 2025-05-24 16:31:35 --> Total execution time: 0.0698
INFO - 2025-05-24 16:36:32 --> Config Class Initialized
INFO - 2025-05-24 16:36:32 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:36:32 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:36:32 --> Utf8 Class Initialized
INFO - 2025-05-24 16:36:32 --> URI Class Initialized
INFO - 2025-05-24 16:36:32 --> Router Class Initialized
INFO - 2025-05-24 16:36:32 --> Output Class Initialized
INFO - 2025-05-24 16:36:32 --> Security Class Initialized
DEBUG - 2025-05-24 16:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:36:32 --> Input Class Initialized
INFO - 2025-05-24 16:36:32 --> Language Class Initialized
INFO - 2025-05-24 16:36:32 --> Loader Class Initialized
INFO - 2025-05-24 16:36:32 --> Helper loaded: url_helper
INFO - 2025-05-24 16:36:32 --> Helper loaded: form_helper
INFO - 2025-05-24 16:36:32 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:36:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:36:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:36:32 --> Controller Class Initialized
INFO - 2025-05-24 16:36:32 --> Model "Progress_model" initialized
INFO - 2025-05-24 16:36:32 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:36:32 --> Model "User_model" initialized
INFO - 2025-05-24 16:36:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 16:36:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 16:36:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-24 16:36:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 16:36:32 --> Final output sent to browser
DEBUG - 2025-05-24 16:36:32 --> Total execution time: 0.1307
INFO - 2025-05-24 16:36:33 --> Config Class Initialized
INFO - 2025-05-24 16:36:33 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:36:33 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:36:33 --> Utf8 Class Initialized
INFO - 2025-05-24 16:36:33 --> URI Class Initialized
INFO - 2025-05-24 16:36:33 --> Router Class Initialized
INFO - 2025-05-24 16:36:33 --> Output Class Initialized
INFO - 2025-05-24 16:36:33 --> Security Class Initialized
DEBUG - 2025-05-24 16:36:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:36:33 --> Input Class Initialized
INFO - 2025-05-24 16:36:33 --> Language Class Initialized
INFO - 2025-05-24 16:36:33 --> Loader Class Initialized
INFO - 2025-05-24 16:36:33 --> Helper loaded: url_helper
INFO - 2025-05-24 16:36:33 --> Helper loaded: form_helper
INFO - 2025-05-24 16:36:33 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:36:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:36:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:36:33 --> Controller Class Initialized
INFO - 2025-05-24 16:36:33 --> Model "Progress_model" initialized
INFO - 2025-05-24 16:36:33 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:36:33 --> Model "User_model" initialized
INFO - 2025-05-24 16:36:33 --> Final output sent to browser
DEBUG - 2025-05-24 16:36:33 --> Total execution time: 0.0881
INFO - 2025-05-24 16:36:35 --> Config Class Initialized
INFO - 2025-05-24 16:36:35 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:36:35 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:36:35 --> Utf8 Class Initialized
INFO - 2025-05-24 16:36:35 --> URI Class Initialized
INFO - 2025-05-24 16:36:35 --> Router Class Initialized
INFO - 2025-05-24 16:36:35 --> Output Class Initialized
INFO - 2025-05-24 16:36:35 --> Security Class Initialized
DEBUG - 2025-05-24 16:36:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:36:35 --> Input Class Initialized
INFO - 2025-05-24 16:36:35 --> Language Class Initialized
INFO - 2025-05-24 16:36:35 --> Loader Class Initialized
INFO - 2025-05-24 16:36:35 --> Helper loaded: url_helper
INFO - 2025-05-24 16:36:35 --> Helper loaded: form_helper
INFO - 2025-05-24 16:36:35 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:36:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:36:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:36:35 --> Controller Class Initialized
INFO - 2025-05-24 16:36:35 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:36:35 --> Model "User_model" initialized
INFO - 2025-05-24 16:36:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 16:36:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 16:36:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-05-24 16:36:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 16:36:35 --> Final output sent to browser
DEBUG - 2025-05-24 16:36:35 --> Total execution time: 0.0757
INFO - 2025-05-24 16:36:36 --> Config Class Initialized
INFO - 2025-05-24 16:36:36 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:36:36 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:36:36 --> Utf8 Class Initialized
INFO - 2025-05-24 16:36:36 --> URI Class Initialized
INFO - 2025-05-24 16:36:36 --> Router Class Initialized
INFO - 2025-05-24 16:36:36 --> Output Class Initialized
INFO - 2025-05-24 16:36:36 --> Security Class Initialized
DEBUG - 2025-05-24 16:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:36:36 --> Input Class Initialized
INFO - 2025-05-24 16:36:36 --> Language Class Initialized
INFO - 2025-05-24 16:36:36 --> Loader Class Initialized
INFO - 2025-05-24 16:36:36 --> Helper loaded: url_helper
INFO - 2025-05-24 16:36:36 --> Helper loaded: form_helper
INFO - 2025-05-24 16:36:36 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:36:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:36:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:36:36 --> Controller Class Initialized
INFO - 2025-05-24 16:36:36 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:36:36 --> Model "User_model" initialized
INFO - 2025-05-24 16:36:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 16:36:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 16:36:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-05-24 16:36:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 16:36:36 --> Final output sent to browser
DEBUG - 2025-05-24 16:36:36 --> Total execution time: 0.0805
INFO - 2025-05-24 16:36:39 --> Config Class Initialized
INFO - 2025-05-24 16:36:39 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:36:39 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:36:39 --> Utf8 Class Initialized
INFO - 2025-05-24 16:36:39 --> URI Class Initialized
INFO - 2025-05-24 16:36:39 --> Router Class Initialized
INFO - 2025-05-24 16:36:39 --> Output Class Initialized
INFO - 2025-05-24 16:36:39 --> Security Class Initialized
DEBUG - 2025-05-24 16:36:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:36:39 --> Input Class Initialized
INFO - 2025-05-24 16:36:39 --> Language Class Initialized
INFO - 2025-05-24 16:36:39 --> Loader Class Initialized
INFO - 2025-05-24 16:36:39 --> Helper loaded: url_helper
INFO - 2025-05-24 16:36:39 --> Helper loaded: form_helper
INFO - 2025-05-24 16:36:39 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:36:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:36:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:36:39 --> Controller Class Initialized
INFO - 2025-05-24 16:36:39 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:36:39 --> Model "User_model" initialized
INFO - 2025-05-24 16:36:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 16:36:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 16:36:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/menu.php
INFO - 2025-05-24 16:36:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 16:36:39 --> Final output sent to browser
DEBUG - 2025-05-24 16:36:39 --> Total execution time: 0.0770
INFO - 2025-05-24 16:36:40 --> Config Class Initialized
INFO - 2025-05-24 16:36:40 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:36:40 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:36:40 --> Utf8 Class Initialized
INFO - 2025-05-24 16:36:40 --> URI Class Initialized
INFO - 2025-05-24 16:36:40 --> Router Class Initialized
INFO - 2025-05-24 16:36:40 --> Output Class Initialized
INFO - 2025-05-24 16:36:40 --> Security Class Initialized
DEBUG - 2025-05-24 16:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:36:40 --> Input Class Initialized
INFO - 2025-05-24 16:36:40 --> Language Class Initialized
INFO - 2025-05-24 16:36:40 --> Loader Class Initialized
INFO - 2025-05-24 16:36:40 --> Helper loaded: url_helper
INFO - 2025-05-24 16:36:40 --> Helper loaded: form_helper
INFO - 2025-05-24 16:36:40 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:36:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:36:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:36:40 --> Controller Class Initialized
INFO - 2025-05-24 16:36:40 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:36:40 --> Model "User_model" initialized
INFO - 2025-05-24 16:36:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 16:36:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 16:36:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/start.php
INFO - 2025-05-24 16:36:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 16:36:40 --> Final output sent to browser
DEBUG - 2025-05-24 16:36:40 --> Total execution time: 0.0761
INFO - 2025-05-24 16:36:54 --> Config Class Initialized
INFO - 2025-05-24 16:36:54 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:36:54 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:36:54 --> Utf8 Class Initialized
INFO - 2025-05-24 16:36:54 --> URI Class Initialized
INFO - 2025-05-24 16:36:54 --> Router Class Initialized
INFO - 2025-05-24 16:36:54 --> Output Class Initialized
INFO - 2025-05-24 16:36:54 --> Security Class Initialized
DEBUG - 2025-05-24 16:36:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:36:54 --> Input Class Initialized
INFO - 2025-05-24 16:36:54 --> Language Class Initialized
INFO - 2025-05-24 16:36:54 --> Loader Class Initialized
INFO - 2025-05-24 16:36:54 --> Helper loaded: url_helper
INFO - 2025-05-24 16:36:54 --> Helper loaded: form_helper
INFO - 2025-05-24 16:36:54 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:36:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:36:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:36:54 --> Controller Class Initialized
INFO - 2025-05-24 16:36:54 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:36:54 --> Model "User_model" initialized
INFO - 2025-05-24 16:36:54 --> Final output sent to browser
DEBUG - 2025-05-24 16:36:54 --> Total execution time: 0.0617
INFO - 2025-05-24 16:36:58 --> Config Class Initialized
INFO - 2025-05-24 16:36:58 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:36:58 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:36:58 --> Utf8 Class Initialized
INFO - 2025-05-24 16:36:58 --> URI Class Initialized
INFO - 2025-05-24 16:36:58 --> Router Class Initialized
INFO - 2025-05-24 16:36:58 --> Output Class Initialized
INFO - 2025-05-24 16:36:58 --> Security Class Initialized
DEBUG - 2025-05-24 16:36:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:36:58 --> Input Class Initialized
INFO - 2025-05-24 16:36:58 --> Language Class Initialized
INFO - 2025-05-24 16:36:58 --> Loader Class Initialized
INFO - 2025-05-24 16:36:58 --> Helper loaded: url_helper
INFO - 2025-05-24 16:36:58 --> Helper loaded: form_helper
INFO - 2025-05-24 16:36:58 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:36:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:36:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:36:58 --> Controller Class Initialized
INFO - 2025-05-24 16:36:58 --> Model "Progress_model" initialized
INFO - 2025-05-24 16:36:58 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:36:58 --> Model "User_model" initialized
INFO - 2025-05-24 16:36:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 16:36:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 16:36:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-24 16:36:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 16:36:58 --> Final output sent to browser
DEBUG - 2025-05-24 16:36:58 --> Total execution time: 0.0716
INFO - 2025-05-24 16:36:58 --> Config Class Initialized
INFO - 2025-05-24 16:36:58 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:36:58 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:36:58 --> Utf8 Class Initialized
INFO - 2025-05-24 16:36:58 --> URI Class Initialized
INFO - 2025-05-24 16:36:58 --> Router Class Initialized
INFO - 2025-05-24 16:36:58 --> Output Class Initialized
INFO - 2025-05-24 16:36:58 --> Security Class Initialized
DEBUG - 2025-05-24 16:36:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:36:58 --> Input Class Initialized
INFO - 2025-05-24 16:36:58 --> Language Class Initialized
INFO - 2025-05-24 16:36:58 --> Loader Class Initialized
INFO - 2025-05-24 16:36:58 --> Helper loaded: url_helper
INFO - 2025-05-24 16:36:58 --> Helper loaded: form_helper
INFO - 2025-05-24 16:36:58 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:36:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:36:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:36:58 --> Controller Class Initialized
INFO - 2025-05-24 16:36:58 --> Model "Progress_model" initialized
INFO - 2025-05-24 16:36:58 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:36:58 --> Model "User_model" initialized
INFO - 2025-05-24 16:36:58 --> Final output sent to browser
DEBUG - 2025-05-24 16:36:58 --> Total execution time: 0.0986
INFO - 2025-05-24 16:37:55 --> Config Class Initialized
INFO - 2025-05-24 16:37:55 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:37:55 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:37:55 --> Utf8 Class Initialized
INFO - 2025-05-24 16:37:55 --> URI Class Initialized
INFO - 2025-05-24 16:37:55 --> Router Class Initialized
INFO - 2025-05-24 16:37:55 --> Output Class Initialized
INFO - 2025-05-24 16:37:55 --> Security Class Initialized
DEBUG - 2025-05-24 16:37:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:37:55 --> Input Class Initialized
INFO - 2025-05-24 16:37:55 --> Language Class Initialized
INFO - 2025-05-24 16:37:55 --> Loader Class Initialized
INFO - 2025-05-24 16:37:55 --> Helper loaded: url_helper
INFO - 2025-05-24 16:37:55 --> Helper loaded: form_helper
INFO - 2025-05-24 16:37:55 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:37:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:37:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:37:55 --> Controller Class Initialized
INFO - 2025-05-24 16:37:55 --> Model "Progress_model" initialized
INFO - 2025-05-24 16:37:55 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:37:55 --> Model "User_model" initialized
INFO - 2025-05-24 16:37:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 16:37:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 16:37:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-24 16:37:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 16:37:55 --> Final output sent to browser
DEBUG - 2025-05-24 16:37:55 --> Total execution time: 0.0996
INFO - 2025-05-24 16:38:02 --> Config Class Initialized
INFO - 2025-05-24 16:38:02 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:38:02 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:38:02 --> Utf8 Class Initialized
INFO - 2025-05-24 16:38:02 --> URI Class Initialized
INFO - 2025-05-24 16:38:02 --> Router Class Initialized
INFO - 2025-05-24 16:38:02 --> Output Class Initialized
INFO - 2025-05-24 16:38:02 --> Security Class Initialized
DEBUG - 2025-05-24 16:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:38:02 --> Input Class Initialized
INFO - 2025-05-24 16:38:02 --> Language Class Initialized
INFO - 2025-05-24 16:38:02 --> Loader Class Initialized
INFO - 2025-05-24 16:38:02 --> Helper loaded: url_helper
INFO - 2025-05-24 16:38:02 --> Helper loaded: form_helper
INFO - 2025-05-24 16:38:02 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:38:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:38:02 --> Controller Class Initialized
INFO - 2025-05-24 16:38:02 --> Model "Progress_model" initialized
INFO - 2025-05-24 16:38:02 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:38:02 --> Model "User_model" initialized
INFO - 2025-05-24 16:38:02 --> Final output sent to browser
DEBUG - 2025-05-24 16:38:02 --> Total execution time: 0.0730
INFO - 2025-05-24 16:38:05 --> Config Class Initialized
INFO - 2025-05-24 16:38:05 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:38:05 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:38:05 --> Utf8 Class Initialized
INFO - 2025-05-24 16:38:05 --> URI Class Initialized
INFO - 2025-05-24 16:38:05 --> Router Class Initialized
INFO - 2025-05-24 16:38:05 --> Output Class Initialized
INFO - 2025-05-24 16:38:05 --> Security Class Initialized
DEBUG - 2025-05-24 16:38:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:38:05 --> Input Class Initialized
INFO - 2025-05-24 16:38:05 --> Language Class Initialized
INFO - 2025-05-24 16:38:05 --> Loader Class Initialized
INFO - 2025-05-24 16:38:05 --> Helper loaded: url_helper
INFO - 2025-05-24 16:38:05 --> Helper loaded: form_helper
INFO - 2025-05-24 16:38:05 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:38:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:38:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:38:05 --> Controller Class Initialized
INFO - 2025-05-24 16:38:05 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:38:05 --> Model "User_model" initialized
INFO - 2025-05-24 16:38:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 16:38:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 16:38:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-05-24 16:38:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 16:38:05 --> Final output sent to browser
DEBUG - 2025-05-24 16:38:05 --> Total execution time: 0.0683
INFO - 2025-05-24 16:38:06 --> Config Class Initialized
INFO - 2025-05-24 16:38:06 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:38:06 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:38:06 --> Utf8 Class Initialized
INFO - 2025-05-24 16:38:06 --> URI Class Initialized
INFO - 2025-05-24 16:38:06 --> Router Class Initialized
INFO - 2025-05-24 16:38:06 --> Output Class Initialized
INFO - 2025-05-24 16:38:06 --> Security Class Initialized
DEBUG - 2025-05-24 16:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:38:06 --> Input Class Initialized
INFO - 2025-05-24 16:38:06 --> Language Class Initialized
INFO - 2025-05-24 16:38:06 --> Loader Class Initialized
INFO - 2025-05-24 16:38:06 --> Helper loaded: url_helper
INFO - 2025-05-24 16:38:06 --> Helper loaded: form_helper
INFO - 2025-05-24 16:38:06 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:38:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:38:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:38:06 --> Controller Class Initialized
INFO - 2025-05-24 16:38:06 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:38:06 --> Model "User_model" initialized
INFO - 2025-05-24 16:38:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 16:38:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 16:38:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-05-24 16:38:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 16:38:06 --> Final output sent to browser
DEBUG - 2025-05-24 16:38:06 --> Total execution time: 0.0783
INFO - 2025-05-24 16:38:09 --> Config Class Initialized
INFO - 2025-05-24 16:38:09 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:38:09 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:38:09 --> Utf8 Class Initialized
INFO - 2025-05-24 16:38:09 --> URI Class Initialized
INFO - 2025-05-24 16:38:09 --> Router Class Initialized
INFO - 2025-05-24 16:38:09 --> Output Class Initialized
INFO - 2025-05-24 16:38:09 --> Security Class Initialized
DEBUG - 2025-05-24 16:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:38:09 --> Input Class Initialized
INFO - 2025-05-24 16:38:09 --> Language Class Initialized
INFO - 2025-05-24 16:38:09 --> Loader Class Initialized
INFO - 2025-05-24 16:38:09 --> Helper loaded: url_helper
INFO - 2025-05-24 16:38:09 --> Helper loaded: form_helper
INFO - 2025-05-24 16:38:09 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:38:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:38:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:38:09 --> Controller Class Initialized
INFO - 2025-05-24 16:38:09 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:38:09 --> Model "User_model" initialized
INFO - 2025-05-24 16:38:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 16:38:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 16:38:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/menu.php
INFO - 2025-05-24 16:38:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 16:38:09 --> Final output sent to browser
DEBUG - 2025-05-24 16:38:09 --> Total execution time: 0.0819
INFO - 2025-05-24 16:38:11 --> Config Class Initialized
INFO - 2025-05-24 16:38:11 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:38:11 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:38:11 --> Utf8 Class Initialized
INFO - 2025-05-24 16:38:11 --> URI Class Initialized
INFO - 2025-05-24 16:38:11 --> Router Class Initialized
INFO - 2025-05-24 16:38:11 --> Output Class Initialized
INFO - 2025-05-24 16:38:11 --> Security Class Initialized
DEBUG - 2025-05-24 16:38:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:38:11 --> Input Class Initialized
INFO - 2025-05-24 16:38:11 --> Language Class Initialized
INFO - 2025-05-24 16:38:11 --> Loader Class Initialized
INFO - 2025-05-24 16:38:11 --> Helper loaded: url_helper
INFO - 2025-05-24 16:38:11 --> Helper loaded: form_helper
INFO - 2025-05-24 16:38:12 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:38:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:38:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:38:12 --> Controller Class Initialized
INFO - 2025-05-24 16:38:12 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:38:12 --> Model "User_model" initialized
INFO - 2025-05-24 16:38:12 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 16:38:12 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 16:38:12 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/start.php
INFO - 2025-05-24 16:38:12 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 16:38:12 --> Final output sent to browser
DEBUG - 2025-05-24 16:38:12 --> Total execution time: 0.0863
INFO - 2025-05-24 16:38:28 --> Config Class Initialized
INFO - 2025-05-24 16:38:28 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:38:28 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:38:28 --> Utf8 Class Initialized
INFO - 2025-05-24 16:38:28 --> URI Class Initialized
INFO - 2025-05-24 16:38:28 --> Router Class Initialized
INFO - 2025-05-24 16:38:28 --> Output Class Initialized
INFO - 2025-05-24 16:38:28 --> Security Class Initialized
DEBUG - 2025-05-24 16:38:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:38:28 --> Input Class Initialized
INFO - 2025-05-24 16:38:28 --> Language Class Initialized
INFO - 2025-05-24 16:38:28 --> Loader Class Initialized
INFO - 2025-05-24 16:38:28 --> Helper loaded: url_helper
INFO - 2025-05-24 16:38:28 --> Helper loaded: form_helper
INFO - 2025-05-24 16:38:28 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:38:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:38:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:38:28 --> Controller Class Initialized
INFO - 2025-05-24 16:38:28 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:38:28 --> Model "User_model" initialized
INFO - 2025-05-24 16:38:28 --> Final output sent to browser
DEBUG - 2025-05-24 16:38:28 --> Total execution time: 0.0808
INFO - 2025-05-24 16:38:34 --> Config Class Initialized
INFO - 2025-05-24 16:38:34 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:38:34 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:38:34 --> Utf8 Class Initialized
INFO - 2025-05-24 16:38:34 --> URI Class Initialized
INFO - 2025-05-24 16:38:34 --> Router Class Initialized
INFO - 2025-05-24 16:38:34 --> Output Class Initialized
INFO - 2025-05-24 16:38:34 --> Security Class Initialized
DEBUG - 2025-05-24 16:38:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:38:34 --> Input Class Initialized
INFO - 2025-05-24 16:38:34 --> Language Class Initialized
INFO - 2025-05-24 16:38:34 --> Loader Class Initialized
INFO - 2025-05-24 16:38:34 --> Helper loaded: url_helper
INFO - 2025-05-24 16:38:34 --> Helper loaded: form_helper
INFO - 2025-05-24 16:38:34 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:38:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:38:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:38:34 --> Controller Class Initialized
INFO - 2025-05-24 16:38:34 --> Model "Progress_model" initialized
INFO - 2025-05-24 16:38:34 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:38:34 --> Model "User_model" initialized
INFO - 2025-05-24 16:38:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 16:38:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 16:38:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-24 16:38:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 16:38:34 --> Final output sent to browser
DEBUG - 2025-05-24 16:38:34 --> Total execution time: 0.0858
INFO - 2025-05-24 16:38:34 --> Config Class Initialized
INFO - 2025-05-24 16:38:34 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:38:34 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:38:34 --> Utf8 Class Initialized
INFO - 2025-05-24 16:38:34 --> URI Class Initialized
INFO - 2025-05-24 16:38:34 --> Router Class Initialized
INFO - 2025-05-24 16:38:34 --> Output Class Initialized
INFO - 2025-05-24 16:38:34 --> Security Class Initialized
DEBUG - 2025-05-24 16:38:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:38:34 --> Input Class Initialized
INFO - 2025-05-24 16:38:34 --> Language Class Initialized
INFO - 2025-05-24 16:38:34 --> Loader Class Initialized
INFO - 2025-05-24 16:38:34 --> Helper loaded: url_helper
INFO - 2025-05-24 16:38:34 --> Helper loaded: form_helper
INFO - 2025-05-24 16:38:34 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:38:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:38:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:38:34 --> Controller Class Initialized
INFO - 2025-05-24 16:38:34 --> Model "Progress_model" initialized
INFO - 2025-05-24 16:38:34 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:38:34 --> Model "User_model" initialized
INFO - 2025-05-24 16:38:34 --> Final output sent to browser
DEBUG - 2025-05-24 16:38:34 --> Total execution time: 0.0731
INFO - 2025-05-24 16:41:27 --> Config Class Initialized
INFO - 2025-05-24 16:41:27 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:41:27 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:41:27 --> Utf8 Class Initialized
INFO - 2025-05-24 16:41:27 --> URI Class Initialized
INFO - 2025-05-24 16:41:27 --> Router Class Initialized
INFO - 2025-05-24 16:41:27 --> Output Class Initialized
INFO - 2025-05-24 16:41:27 --> Security Class Initialized
DEBUG - 2025-05-24 16:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:41:27 --> Input Class Initialized
INFO - 2025-05-24 16:41:27 --> Language Class Initialized
INFO - 2025-05-24 16:41:27 --> Loader Class Initialized
INFO - 2025-05-24 16:41:27 --> Helper loaded: url_helper
INFO - 2025-05-24 16:41:27 --> Helper loaded: form_helper
INFO - 2025-05-24 16:41:27 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:41:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:41:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:41:27 --> Controller Class Initialized
INFO - 2025-05-24 16:41:27 --> Model "Progress_model" initialized
INFO - 2025-05-24 16:41:27 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:41:27 --> Model "User_model" initialized
INFO - 2025-05-24 16:41:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 16:41:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 16:41:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-24 16:41:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 16:41:27 --> Final output sent to browser
DEBUG - 2025-05-24 16:41:27 --> Total execution time: 0.0623
INFO - 2025-05-24 16:41:28 --> Config Class Initialized
INFO - 2025-05-24 16:41:28 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:41:28 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:41:28 --> Utf8 Class Initialized
INFO - 2025-05-24 16:41:28 --> URI Class Initialized
INFO - 2025-05-24 16:41:28 --> Router Class Initialized
INFO - 2025-05-24 16:41:28 --> Output Class Initialized
INFO - 2025-05-24 16:41:28 --> Security Class Initialized
DEBUG - 2025-05-24 16:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:41:28 --> Input Class Initialized
INFO - 2025-05-24 16:41:28 --> Language Class Initialized
INFO - 2025-05-24 16:41:28 --> Loader Class Initialized
INFO - 2025-05-24 16:41:28 --> Helper loaded: url_helper
INFO - 2025-05-24 16:41:28 --> Helper loaded: form_helper
INFO - 2025-05-24 16:41:28 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:41:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:41:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:41:28 --> Controller Class Initialized
INFO - 2025-05-24 16:41:28 --> Model "Progress_model" initialized
INFO - 2025-05-24 16:41:28 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:41:28 --> Model "User_model" initialized
INFO - 2025-05-24 16:41:28 --> Final output sent to browser
DEBUG - 2025-05-24 16:41:28 --> Total execution time: 0.0917
INFO - 2025-05-24 16:41:39 --> Config Class Initialized
INFO - 2025-05-24 16:41:39 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:41:39 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:41:39 --> Utf8 Class Initialized
INFO - 2025-05-24 16:41:39 --> URI Class Initialized
INFO - 2025-05-24 16:41:39 --> Router Class Initialized
INFO - 2025-05-24 16:41:39 --> Output Class Initialized
INFO - 2025-05-24 16:41:39 --> Security Class Initialized
DEBUG - 2025-05-24 16:41:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:41:39 --> Input Class Initialized
INFO - 2025-05-24 16:41:39 --> Language Class Initialized
INFO - 2025-05-24 16:41:39 --> Loader Class Initialized
INFO - 2025-05-24 16:41:39 --> Helper loaded: url_helper
INFO - 2025-05-24 16:41:39 --> Helper loaded: form_helper
INFO - 2025-05-24 16:41:39 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:41:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:41:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:41:39 --> Controller Class Initialized
INFO - 2025-05-24 16:41:39 --> Model "Progress_model" initialized
INFO - 2025-05-24 16:41:39 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:41:39 --> Model "User_model" initialized
INFO - 2025-05-24 16:41:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 16:41:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 16:41:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-24 16:41:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 16:41:39 --> Final output sent to browser
DEBUG - 2025-05-24 16:41:39 --> Total execution time: 0.0736
INFO - 2025-05-24 16:41:39 --> Config Class Initialized
INFO - 2025-05-24 16:41:39 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:41:39 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:41:39 --> Utf8 Class Initialized
INFO - 2025-05-24 16:41:39 --> URI Class Initialized
INFO - 2025-05-24 16:41:39 --> Router Class Initialized
INFO - 2025-05-24 16:41:39 --> Output Class Initialized
INFO - 2025-05-24 16:41:39 --> Security Class Initialized
DEBUG - 2025-05-24 16:41:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:41:39 --> Input Class Initialized
INFO - 2025-05-24 16:41:39 --> Language Class Initialized
INFO - 2025-05-24 16:41:39 --> Loader Class Initialized
INFO - 2025-05-24 16:41:40 --> Helper loaded: url_helper
INFO - 2025-05-24 16:41:40 --> Helper loaded: form_helper
INFO - 2025-05-24 16:41:40 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:41:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:41:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:41:40 --> Controller Class Initialized
INFO - 2025-05-24 16:41:40 --> Model "Progress_model" initialized
INFO - 2025-05-24 16:41:40 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:41:40 --> Model "User_model" initialized
INFO - 2025-05-24 16:41:40 --> Final output sent to browser
DEBUG - 2025-05-24 16:41:40 --> Total execution time: 0.0826
INFO - 2025-05-24 16:41:42 --> Config Class Initialized
INFO - 2025-05-24 16:41:42 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:41:42 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:41:42 --> Utf8 Class Initialized
INFO - 2025-05-24 16:41:42 --> URI Class Initialized
INFO - 2025-05-24 16:41:42 --> Router Class Initialized
INFO - 2025-05-24 16:41:42 --> Output Class Initialized
INFO - 2025-05-24 16:41:42 --> Security Class Initialized
DEBUG - 2025-05-24 16:41:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:41:42 --> Input Class Initialized
INFO - 2025-05-24 16:41:42 --> Language Class Initialized
INFO - 2025-05-24 16:41:42 --> Loader Class Initialized
INFO - 2025-05-24 16:41:42 --> Helper loaded: url_helper
INFO - 2025-05-24 16:41:42 --> Helper loaded: form_helper
INFO - 2025-05-24 16:41:42 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:41:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:41:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:41:42 --> Controller Class Initialized
INFO - 2025-05-24 16:41:42 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:41:42 --> Model "User_model" initialized
INFO - 2025-05-24 16:41:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 16:41:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 16:41:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-05-24 16:41:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 16:41:42 --> Final output sent to browser
DEBUG - 2025-05-24 16:41:42 --> Total execution time: 0.0776
INFO - 2025-05-24 16:41:46 --> Config Class Initialized
INFO - 2025-05-24 16:41:46 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:41:46 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:41:46 --> Utf8 Class Initialized
INFO - 2025-05-24 16:41:46 --> URI Class Initialized
INFO - 2025-05-24 16:41:46 --> Router Class Initialized
INFO - 2025-05-24 16:41:46 --> Output Class Initialized
INFO - 2025-05-24 16:41:46 --> Security Class Initialized
DEBUG - 2025-05-24 16:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:41:46 --> Input Class Initialized
INFO - 2025-05-24 16:41:46 --> Language Class Initialized
INFO - 2025-05-24 16:41:46 --> Loader Class Initialized
INFO - 2025-05-24 16:41:46 --> Helper loaded: url_helper
INFO - 2025-05-24 16:41:46 --> Helper loaded: form_helper
INFO - 2025-05-24 16:41:46 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:41:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:41:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:41:46 --> Controller Class Initialized
INFO - 2025-05-24 16:41:46 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:41:46 --> Model "User_model" initialized
INFO - 2025-05-24 16:41:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 16:41:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 16:41:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-05-24 16:41:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 16:41:46 --> Final output sent to browser
DEBUG - 2025-05-24 16:41:46 --> Total execution time: 0.0953
INFO - 2025-05-24 16:41:48 --> Config Class Initialized
INFO - 2025-05-24 16:41:48 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:41:48 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:41:48 --> Utf8 Class Initialized
INFO - 2025-05-24 16:41:48 --> URI Class Initialized
INFO - 2025-05-24 16:41:48 --> Router Class Initialized
INFO - 2025-05-24 16:41:48 --> Output Class Initialized
INFO - 2025-05-24 16:41:48 --> Security Class Initialized
DEBUG - 2025-05-24 16:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:41:48 --> Input Class Initialized
INFO - 2025-05-24 16:41:48 --> Language Class Initialized
INFO - 2025-05-24 16:41:48 --> Loader Class Initialized
INFO - 2025-05-24 16:41:48 --> Helper loaded: url_helper
INFO - 2025-05-24 16:41:48 --> Helper loaded: form_helper
INFO - 2025-05-24 16:41:48 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:41:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:41:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:41:48 --> Controller Class Initialized
INFO - 2025-05-24 16:41:48 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:41:48 --> Model "User_model" initialized
INFO - 2025-05-24 16:41:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 16:41:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 16:41:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/menu.php
INFO - 2025-05-24 16:41:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 16:41:48 --> Final output sent to browser
DEBUG - 2025-05-24 16:41:48 --> Total execution time: 0.0662
INFO - 2025-05-24 16:41:49 --> Config Class Initialized
INFO - 2025-05-24 16:41:49 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:41:49 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:41:49 --> Utf8 Class Initialized
INFO - 2025-05-24 16:41:49 --> URI Class Initialized
INFO - 2025-05-24 16:41:49 --> Router Class Initialized
INFO - 2025-05-24 16:41:49 --> Output Class Initialized
INFO - 2025-05-24 16:41:49 --> Security Class Initialized
DEBUG - 2025-05-24 16:41:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:41:49 --> Input Class Initialized
INFO - 2025-05-24 16:41:49 --> Language Class Initialized
INFO - 2025-05-24 16:41:49 --> Loader Class Initialized
INFO - 2025-05-24 16:41:49 --> Helper loaded: url_helper
INFO - 2025-05-24 16:41:49 --> Helper loaded: form_helper
INFO - 2025-05-24 16:41:49 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:41:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:41:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:41:49 --> Controller Class Initialized
INFO - 2025-05-24 16:41:49 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:41:49 --> Model "User_model" initialized
INFO - 2025-05-24 16:41:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 16:41:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 16:41:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/start.php
INFO - 2025-05-24 16:41:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 16:41:49 --> Final output sent to browser
DEBUG - 2025-05-24 16:41:49 --> Total execution time: 0.0702
INFO - 2025-05-24 16:41:57 --> Config Class Initialized
INFO - 2025-05-24 16:41:57 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:41:57 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:41:57 --> Utf8 Class Initialized
INFO - 2025-05-24 16:41:57 --> URI Class Initialized
INFO - 2025-05-24 16:41:57 --> Router Class Initialized
INFO - 2025-05-24 16:41:57 --> Output Class Initialized
INFO - 2025-05-24 16:41:57 --> Security Class Initialized
DEBUG - 2025-05-24 16:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:41:57 --> Input Class Initialized
INFO - 2025-05-24 16:41:57 --> Language Class Initialized
INFO - 2025-05-24 16:41:57 --> Loader Class Initialized
INFO - 2025-05-24 16:41:57 --> Helper loaded: url_helper
INFO - 2025-05-24 16:41:57 --> Helper loaded: form_helper
INFO - 2025-05-24 16:41:57 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:41:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:41:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:41:57 --> Controller Class Initialized
INFO - 2025-05-24 16:41:57 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:41:57 --> Model "User_model" initialized
INFO - 2025-05-24 16:41:57 --> Final output sent to browser
DEBUG - 2025-05-24 16:41:57 --> Total execution time: 0.0899
INFO - 2025-05-24 16:42:00 --> Config Class Initialized
INFO - 2025-05-24 16:42:00 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:42:00 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:42:00 --> Utf8 Class Initialized
INFO - 2025-05-24 16:42:00 --> URI Class Initialized
INFO - 2025-05-24 16:42:00 --> Router Class Initialized
INFO - 2025-05-24 16:42:00 --> Output Class Initialized
INFO - 2025-05-24 16:42:00 --> Security Class Initialized
DEBUG - 2025-05-24 16:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:42:00 --> Input Class Initialized
INFO - 2025-05-24 16:42:00 --> Language Class Initialized
INFO - 2025-05-24 16:42:00 --> Loader Class Initialized
INFO - 2025-05-24 16:42:00 --> Helper loaded: url_helper
INFO - 2025-05-24 16:42:00 --> Helper loaded: form_helper
INFO - 2025-05-24 16:42:00 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:42:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:42:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:42:00 --> Controller Class Initialized
INFO - 2025-05-24 16:42:00 --> Model "Progress_model" initialized
INFO - 2025-05-24 16:42:00 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:42:00 --> Model "User_model" initialized
INFO - 2025-05-24 16:42:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 16:42:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 16:42:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-24 16:42:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 16:42:00 --> Final output sent to browser
DEBUG - 2025-05-24 16:42:00 --> Total execution time: 0.0962
INFO - 2025-05-24 16:42:01 --> Config Class Initialized
INFO - 2025-05-24 16:42:01 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:42:01 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:42:01 --> Utf8 Class Initialized
INFO - 2025-05-24 16:42:01 --> URI Class Initialized
INFO - 2025-05-24 16:42:01 --> Router Class Initialized
INFO - 2025-05-24 16:42:01 --> Output Class Initialized
INFO - 2025-05-24 16:42:01 --> Security Class Initialized
DEBUG - 2025-05-24 16:42:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:42:01 --> Input Class Initialized
INFO - 2025-05-24 16:42:01 --> Language Class Initialized
INFO - 2025-05-24 16:42:01 --> Loader Class Initialized
INFO - 2025-05-24 16:42:01 --> Helper loaded: url_helper
INFO - 2025-05-24 16:42:01 --> Helper loaded: form_helper
INFO - 2025-05-24 16:42:01 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:42:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:42:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:42:01 --> Controller Class Initialized
INFO - 2025-05-24 16:42:01 --> Model "Progress_model" initialized
INFO - 2025-05-24 16:42:01 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:42:01 --> Model "User_model" initialized
INFO - 2025-05-24 16:42:01 --> Final output sent to browser
DEBUG - 2025-05-24 16:42:01 --> Total execution time: 0.0709
INFO - 2025-05-24 16:42:03 --> Config Class Initialized
INFO - 2025-05-24 16:42:03 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:42:03 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:42:03 --> Utf8 Class Initialized
INFO - 2025-05-24 16:42:03 --> URI Class Initialized
INFO - 2025-05-24 16:42:03 --> Router Class Initialized
INFO - 2025-05-24 16:42:03 --> Output Class Initialized
INFO - 2025-05-24 16:42:03 --> Security Class Initialized
DEBUG - 2025-05-24 16:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:42:03 --> Input Class Initialized
INFO - 2025-05-24 16:42:03 --> Language Class Initialized
INFO - 2025-05-24 16:42:03 --> Loader Class Initialized
INFO - 2025-05-24 16:42:03 --> Helper loaded: url_helper
INFO - 2025-05-24 16:42:03 --> Helper loaded: form_helper
INFO - 2025-05-24 16:42:03 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:42:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:42:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:42:03 --> Controller Class Initialized
INFO - 2025-05-24 16:42:03 --> Model "Progress_model" initialized
INFO - 2025-05-24 16:42:03 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:42:03 --> Model "User_model" initialized
INFO - 2025-05-24 16:42:03 --> Final output sent to browser
DEBUG - 2025-05-24 16:42:03 --> Total execution time: 0.0757
INFO - 2025-05-24 16:42:07 --> Config Class Initialized
INFO - 2025-05-24 16:42:07 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:42:07 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:42:07 --> Utf8 Class Initialized
INFO - 2025-05-24 16:42:07 --> URI Class Initialized
INFO - 2025-05-24 16:42:07 --> Router Class Initialized
INFO - 2025-05-24 16:42:07 --> Output Class Initialized
INFO - 2025-05-24 16:42:07 --> Security Class Initialized
DEBUG - 2025-05-24 16:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:42:07 --> Input Class Initialized
INFO - 2025-05-24 16:42:07 --> Language Class Initialized
INFO - 2025-05-24 16:42:08 --> Loader Class Initialized
INFO - 2025-05-24 16:42:08 --> Helper loaded: url_helper
INFO - 2025-05-24 16:42:08 --> Helper loaded: form_helper
INFO - 2025-05-24 16:42:08 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:42:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:42:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:42:08 --> Controller Class Initialized
INFO - 2025-05-24 16:42:08 --> Model "User_model" initialized
INFO - 2025-05-24 16:42:08 --> Config Class Initialized
INFO - 2025-05-24 16:42:08 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:42:08 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:42:08 --> Utf8 Class Initialized
INFO - 2025-05-24 16:42:08 --> URI Class Initialized
INFO - 2025-05-24 16:42:08 --> Router Class Initialized
INFO - 2025-05-24 16:42:08 --> Output Class Initialized
INFO - 2025-05-24 16:42:08 --> Security Class Initialized
DEBUG - 2025-05-24 16:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:42:08 --> Input Class Initialized
INFO - 2025-05-24 16:42:08 --> Language Class Initialized
INFO - 2025-05-24 16:42:08 --> Loader Class Initialized
INFO - 2025-05-24 16:42:08 --> Helper loaded: url_helper
INFO - 2025-05-24 16:42:08 --> Helper loaded: form_helper
INFO - 2025-05-24 16:42:08 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:42:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:42:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:42:08 --> Controller Class Initialized
INFO - 2025-05-24 16:42:08 --> Model "User_model" initialized
INFO - 2025-05-24 16:42:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-24 16:42:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-24 16:42:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-24 16:42:08 --> Final output sent to browser
DEBUG - 2025-05-24 16:42:08 --> Total execution time: 0.0650
INFO - 2025-05-24 16:42:09 --> Config Class Initialized
INFO - 2025-05-24 16:42:09 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:42:09 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:42:09 --> Utf8 Class Initialized
INFO - 2025-05-24 16:42:09 --> URI Class Initialized
INFO - 2025-05-24 16:42:09 --> Router Class Initialized
INFO - 2025-05-24 16:42:09 --> Output Class Initialized
INFO - 2025-05-24 16:42:09 --> Security Class Initialized
DEBUG - 2025-05-24 16:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:42:09 --> Input Class Initialized
INFO - 2025-05-24 16:42:09 --> Language Class Initialized
INFO - 2025-05-24 16:42:09 --> Loader Class Initialized
INFO - 2025-05-24 16:42:09 --> Helper loaded: url_helper
INFO - 2025-05-24 16:42:09 --> Helper loaded: form_helper
INFO - 2025-05-24 16:42:09 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:42:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:42:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:42:10 --> Controller Class Initialized
INFO - 2025-05-24 16:42:10 --> Model "User_model" initialized
INFO - 2025-05-24 16:42:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-24 16:42:10 --> Final output sent to browser
DEBUG - 2025-05-24 16:42:10 --> Total execution time: 0.0863
INFO - 2025-05-24 16:42:27 --> Config Class Initialized
INFO - 2025-05-24 16:42:27 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:42:27 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:42:27 --> Utf8 Class Initialized
INFO - 2025-05-24 16:42:27 --> URI Class Initialized
INFO - 2025-05-24 16:42:27 --> Router Class Initialized
INFO - 2025-05-24 16:42:27 --> Output Class Initialized
INFO - 2025-05-24 16:42:27 --> Security Class Initialized
DEBUG - 2025-05-24 16:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:42:27 --> Input Class Initialized
INFO - 2025-05-24 16:42:27 --> Language Class Initialized
INFO - 2025-05-24 16:42:27 --> Loader Class Initialized
INFO - 2025-05-24 16:42:27 --> Helper loaded: url_helper
INFO - 2025-05-24 16:42:27 --> Helper loaded: form_helper
INFO - 2025-05-24 16:42:27 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:42:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:42:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:42:27 --> Controller Class Initialized
INFO - 2025-05-24 16:42:27 --> Model "User_model" initialized
INFO - 2025-05-24 16:42:27 --> Config Class Initialized
INFO - 2025-05-24 16:42:27 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:42:27 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:42:27 --> Utf8 Class Initialized
INFO - 2025-05-24 16:42:27 --> URI Class Initialized
INFO - 2025-05-24 16:42:27 --> Router Class Initialized
INFO - 2025-05-24 16:42:27 --> Output Class Initialized
INFO - 2025-05-24 16:42:27 --> Security Class Initialized
DEBUG - 2025-05-24 16:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:42:27 --> Input Class Initialized
INFO - 2025-05-24 16:42:27 --> Language Class Initialized
INFO - 2025-05-24 16:42:27 --> Loader Class Initialized
INFO - 2025-05-24 16:42:27 --> Helper loaded: url_helper
INFO - 2025-05-24 16:42:27 --> Helper loaded: form_helper
INFO - 2025-05-24 16:42:27 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:42:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:42:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:42:27 --> Controller Class Initialized
INFO - 2025-05-24 16:42:27 --> Model "User_model" initialized
INFO - 2025-05-24 16:42:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-24 16:42:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-24 16:42:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-24 16:42:27 --> Final output sent to browser
DEBUG - 2025-05-24 16:42:27 --> Total execution time: 0.0636
INFO - 2025-05-24 16:42:30 --> Config Class Initialized
INFO - 2025-05-24 16:42:30 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:42:30 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:42:30 --> Utf8 Class Initialized
INFO - 2025-05-24 16:42:30 --> URI Class Initialized
INFO - 2025-05-24 16:42:30 --> Router Class Initialized
INFO - 2025-05-24 16:42:30 --> Output Class Initialized
INFO - 2025-05-24 16:42:30 --> Security Class Initialized
DEBUG - 2025-05-24 16:42:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:42:30 --> Input Class Initialized
INFO - 2025-05-24 16:42:30 --> Language Class Initialized
INFO - 2025-05-24 16:42:30 --> Loader Class Initialized
INFO - 2025-05-24 16:42:30 --> Helper loaded: url_helper
INFO - 2025-05-24 16:42:30 --> Helper loaded: form_helper
INFO - 2025-05-24 16:42:30 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:42:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:42:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:42:30 --> Controller Class Initialized
INFO - 2025-05-24 16:42:30 --> Model "User_model" initialized
INFO - 2025-05-24 16:42:30 --> Model "Workout_model" initialized
INFO - 2025-05-24 16:42:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 16:42:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 16:42:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-24 16:42:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 16:42:30 --> Final output sent to browser
DEBUG - 2025-05-24 16:42:30 --> Total execution time: 0.0995
INFO - 2025-05-24 16:42:32 --> Config Class Initialized
INFO - 2025-05-24 16:42:32 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:42:32 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:42:32 --> Utf8 Class Initialized
INFO - 2025-05-24 16:42:32 --> URI Class Initialized
INFO - 2025-05-24 16:42:32 --> Router Class Initialized
INFO - 2025-05-24 16:42:32 --> Output Class Initialized
INFO - 2025-05-24 16:42:32 --> Security Class Initialized
DEBUG - 2025-05-24 16:42:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:42:32 --> Input Class Initialized
INFO - 2025-05-24 16:42:32 --> Language Class Initialized
INFO - 2025-05-24 16:42:32 --> Loader Class Initialized
INFO - 2025-05-24 16:42:32 --> Helper loaded: url_helper
INFO - 2025-05-24 16:42:32 --> Helper loaded: form_helper
INFO - 2025-05-24 16:42:32 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:42:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:42:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:42:32 --> Controller Class Initialized
INFO - 2025-05-24 16:42:32 --> Model "Progress_model" initialized
INFO - 2025-05-24 16:42:32 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:42:32 --> Model "User_model" initialized
INFO - 2025-05-24 16:42:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 16:42:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 16:42:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-24 16:42:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 16:42:32 --> Final output sent to browser
DEBUG - 2025-05-24 16:42:32 --> Total execution time: 0.0857
INFO - 2025-05-24 16:42:32 --> Config Class Initialized
INFO - 2025-05-24 16:42:32 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:42:32 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:42:32 --> Utf8 Class Initialized
INFO - 2025-05-24 16:42:32 --> URI Class Initialized
INFO - 2025-05-24 16:42:32 --> Router Class Initialized
INFO - 2025-05-24 16:42:32 --> Output Class Initialized
INFO - 2025-05-24 16:42:32 --> Security Class Initialized
DEBUG - 2025-05-24 16:42:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:42:32 --> Input Class Initialized
INFO - 2025-05-24 16:42:32 --> Language Class Initialized
INFO - 2025-05-24 16:42:32 --> Loader Class Initialized
INFO - 2025-05-24 16:42:32 --> Helper loaded: url_helper
INFO - 2025-05-24 16:42:32 --> Helper loaded: form_helper
INFO - 2025-05-24 16:42:32 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:42:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:42:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:42:32 --> Controller Class Initialized
INFO - 2025-05-24 16:42:32 --> Model "Progress_model" initialized
INFO - 2025-05-24 16:42:32 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:42:32 --> Model "User_model" initialized
INFO - 2025-05-24 16:42:32 --> Final output sent to browser
DEBUG - 2025-05-24 16:42:32 --> Total execution time: 0.0634
INFO - 2025-05-24 16:42:35 --> Config Class Initialized
INFO - 2025-05-24 16:42:35 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:42:35 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:42:35 --> Utf8 Class Initialized
INFO - 2025-05-24 16:42:35 --> URI Class Initialized
INFO - 2025-05-24 16:42:35 --> Router Class Initialized
INFO - 2025-05-24 16:42:35 --> Output Class Initialized
INFO - 2025-05-24 16:42:35 --> Security Class Initialized
DEBUG - 2025-05-24 16:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:42:35 --> Input Class Initialized
INFO - 2025-05-24 16:42:35 --> Language Class Initialized
INFO - 2025-05-24 16:42:35 --> Loader Class Initialized
INFO - 2025-05-24 16:42:35 --> Helper loaded: url_helper
INFO - 2025-05-24 16:42:35 --> Helper loaded: form_helper
INFO - 2025-05-24 16:42:35 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:42:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:42:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:42:35 --> Controller Class Initialized
INFO - 2025-05-24 16:42:35 --> Model "User_model" initialized
INFO - 2025-05-24 16:42:35 --> Model "Workout_model" initialized
INFO - 2025-05-24 16:42:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 16:42:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 16:42:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-24 16:42:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 16:42:35 --> Final output sent to browser
DEBUG - 2025-05-24 16:42:35 --> Total execution time: 0.0849
INFO - 2025-05-24 16:42:41 --> Config Class Initialized
INFO - 2025-05-24 16:42:41 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:42:41 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:42:41 --> Utf8 Class Initialized
INFO - 2025-05-24 16:42:41 --> URI Class Initialized
INFO - 2025-05-24 16:42:41 --> Router Class Initialized
INFO - 2025-05-24 16:42:41 --> Output Class Initialized
INFO - 2025-05-24 16:42:41 --> Security Class Initialized
DEBUG - 2025-05-24 16:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:42:41 --> Input Class Initialized
INFO - 2025-05-24 16:42:41 --> Language Class Initialized
INFO - 2025-05-24 16:42:41 --> Loader Class Initialized
INFO - 2025-05-24 16:42:41 --> Helper loaded: url_helper
INFO - 2025-05-24 16:42:41 --> Helper loaded: form_helper
INFO - 2025-05-24 16:42:41 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:42:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:42:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:42:41 --> Controller Class Initialized
INFO - 2025-05-24 16:42:41 --> Model "User_model" initialized
INFO - 2025-05-24 16:42:41 --> Model "Community_model" initialized
INFO - 2025-05-24 16:42:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 16:42:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 16:42:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/community.php
INFO - 2025-05-24 16:42:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 16:42:41 --> Final output sent to browser
DEBUG - 2025-05-24 16:42:41 --> Total execution time: 0.1672
INFO - 2025-05-24 16:42:50 --> Config Class Initialized
INFO - 2025-05-24 16:42:50 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:42:50 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:42:50 --> Utf8 Class Initialized
INFO - 2025-05-24 16:42:50 --> URI Class Initialized
INFO - 2025-05-24 16:42:50 --> Router Class Initialized
INFO - 2025-05-24 16:42:50 --> Output Class Initialized
INFO - 2025-05-24 16:42:50 --> Security Class Initialized
DEBUG - 2025-05-24 16:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:42:50 --> Input Class Initialized
INFO - 2025-05-24 16:42:50 --> Language Class Initialized
INFO - 2025-05-24 16:42:51 --> Loader Class Initialized
INFO - 2025-05-24 16:42:51 --> Helper loaded: url_helper
INFO - 2025-05-24 16:42:51 --> Helper loaded: form_helper
INFO - 2025-05-24 16:42:51 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:42:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:42:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:42:51 --> Controller Class Initialized
INFO - 2025-05-24 16:42:51 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:42:51 --> Model "User_model" initialized
INFO - 2025-05-24 16:42:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 16:42:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 16:42:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-05-24 16:42:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 16:42:51 --> Final output sent to browser
DEBUG - 2025-05-24 16:42:51 --> Total execution time: 0.0916
INFO - 2025-05-24 16:42:53 --> Config Class Initialized
INFO - 2025-05-24 16:42:53 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:42:53 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:42:53 --> Utf8 Class Initialized
INFO - 2025-05-24 16:42:53 --> URI Class Initialized
INFO - 2025-05-24 16:42:53 --> Router Class Initialized
INFO - 2025-05-24 16:42:53 --> Output Class Initialized
INFO - 2025-05-24 16:42:53 --> Security Class Initialized
DEBUG - 2025-05-24 16:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:42:53 --> Input Class Initialized
INFO - 2025-05-24 16:42:53 --> Language Class Initialized
INFO - 2025-05-24 16:42:53 --> Loader Class Initialized
INFO - 2025-05-24 16:42:53 --> Helper loaded: url_helper
INFO - 2025-05-24 16:42:53 --> Helper loaded: form_helper
INFO - 2025-05-24 16:42:53 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:42:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:42:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:42:53 --> Controller Class Initialized
INFO - 2025-05-24 16:42:53 --> Model "Progress_model" initialized
INFO - 2025-05-24 16:42:53 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:42:53 --> Model "User_model" initialized
INFO - 2025-05-24 16:42:53 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 16:42:53 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 16:42:53 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-24 16:42:53 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 16:42:53 --> Final output sent to browser
DEBUG - 2025-05-24 16:42:53 --> Total execution time: 0.0873
INFO - 2025-05-24 16:42:53 --> Config Class Initialized
INFO - 2025-05-24 16:42:53 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:42:53 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:42:53 --> Utf8 Class Initialized
INFO - 2025-05-24 16:42:53 --> URI Class Initialized
INFO - 2025-05-24 16:42:53 --> Router Class Initialized
INFO - 2025-05-24 16:42:53 --> Output Class Initialized
INFO - 2025-05-24 16:42:53 --> Security Class Initialized
DEBUG - 2025-05-24 16:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:42:53 --> Input Class Initialized
INFO - 2025-05-24 16:42:53 --> Language Class Initialized
INFO - 2025-05-24 16:42:53 --> Loader Class Initialized
INFO - 2025-05-24 16:42:53 --> Helper loaded: url_helper
INFO - 2025-05-24 16:42:53 --> Helper loaded: form_helper
INFO - 2025-05-24 16:42:53 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:42:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:42:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:42:53 --> Controller Class Initialized
INFO - 2025-05-24 16:42:53 --> Model "Progress_model" initialized
INFO - 2025-05-24 16:42:53 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 16:42:53 --> Model "User_model" initialized
INFO - 2025-05-24 16:42:53 --> Final output sent to browser
DEBUG - 2025-05-24 16:42:53 --> Total execution time: 0.0702
INFO - 2025-05-24 16:42:54 --> Config Class Initialized
INFO - 2025-05-24 16:42:54 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:42:54 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:42:54 --> Utf8 Class Initialized
INFO - 2025-05-24 16:42:54 --> URI Class Initialized
INFO - 2025-05-24 16:42:54 --> Router Class Initialized
INFO - 2025-05-24 16:42:54 --> Output Class Initialized
INFO - 2025-05-24 16:42:54 --> Security Class Initialized
DEBUG - 2025-05-24 16:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:42:54 --> Input Class Initialized
INFO - 2025-05-24 16:42:54 --> Language Class Initialized
INFO - 2025-05-24 16:42:54 --> Loader Class Initialized
INFO - 2025-05-24 16:42:54 --> Helper loaded: url_helper
INFO - 2025-05-24 16:42:54 --> Helper loaded: form_helper
INFO - 2025-05-24 16:42:54 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:42:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:42:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:42:54 --> Controller Class Initialized
INFO - 2025-05-24 16:42:54 --> Model "User_model" initialized
INFO - 2025-05-24 16:42:54 --> Model "Workout_model" initialized
INFO - 2025-05-24 16:42:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 16:42:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 16:42:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-24 16:42:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 16:42:54 --> Final output sent to browser
DEBUG - 2025-05-24 16:42:54 --> Total execution time: 0.0900
INFO - 2025-05-24 16:42:55 --> Config Class Initialized
INFO - 2025-05-24 16:42:55 --> Hooks Class Initialized
DEBUG - 2025-05-24 16:42:55 --> UTF-8 Support Enabled
INFO - 2025-05-24 16:42:55 --> Utf8 Class Initialized
INFO - 2025-05-24 16:42:55 --> URI Class Initialized
INFO - 2025-05-24 16:42:55 --> Router Class Initialized
INFO - 2025-05-24 16:42:55 --> Output Class Initialized
INFO - 2025-05-24 16:42:55 --> Security Class Initialized
DEBUG - 2025-05-24 16:42:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 16:42:55 --> Input Class Initialized
INFO - 2025-05-24 16:42:55 --> Language Class Initialized
INFO - 2025-05-24 16:42:55 --> Loader Class Initialized
INFO - 2025-05-24 16:42:55 --> Helper loaded: url_helper
INFO - 2025-05-24 16:42:55 --> Helper loaded: form_helper
INFO - 2025-05-24 16:42:55 --> Database Driver Class Initialized
DEBUG - 2025-05-24 16:42:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 16:42:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 16:42:55 --> Controller Class Initialized
INFO - 2025-05-24 16:42:55 --> Model "User_model" initialized
INFO - 2025-05-24 16:42:55 --> Model "Workout_model" initialized
INFO - 2025-05-24 16:42:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 16:42:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 16:42:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-24 16:42:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 16:42:55 --> Final output sent to browser
DEBUG - 2025-05-24 16:42:55 --> Total execution time: 0.0723
INFO - 2025-05-24 17:01:13 --> Config Class Initialized
INFO - 2025-05-24 17:01:13 --> Hooks Class Initialized
DEBUG - 2025-05-24 17:01:13 --> UTF-8 Support Enabled
INFO - 2025-05-24 17:01:13 --> Utf8 Class Initialized
INFO - 2025-05-24 17:01:13 --> URI Class Initialized
INFO - 2025-05-24 17:01:13 --> Router Class Initialized
INFO - 2025-05-24 17:01:13 --> Output Class Initialized
INFO - 2025-05-24 17:01:13 --> Security Class Initialized
DEBUG - 2025-05-24 17:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 17:01:13 --> Input Class Initialized
INFO - 2025-05-24 17:01:13 --> Language Class Initialized
INFO - 2025-05-24 17:01:13 --> Loader Class Initialized
INFO - 2025-05-24 17:01:13 --> Helper loaded: url_helper
INFO - 2025-05-24 17:01:13 --> Helper loaded: form_helper
INFO - 2025-05-24 17:01:13 --> Database Driver Class Initialized
DEBUG - 2025-05-24 17:01:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 17:01:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 17:01:13 --> Controller Class Initialized
INFO - 2025-05-24 17:01:13 --> Model "User_model" initialized
INFO - 2025-05-24 17:01:13 --> Model "Workout_model" initialized
INFO - 2025-05-24 17:01:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 17:01:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 17:01:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-24 17:01:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 17:01:13 --> Final output sent to browser
DEBUG - 2025-05-24 17:01:13 --> Total execution time: 0.1106
INFO - 2025-05-24 17:01:14 --> Config Class Initialized
INFO - 2025-05-24 17:01:14 --> Hooks Class Initialized
DEBUG - 2025-05-24 17:01:14 --> UTF-8 Support Enabled
INFO - 2025-05-24 17:01:14 --> Utf8 Class Initialized
INFO - 2025-05-24 17:01:14 --> URI Class Initialized
INFO - 2025-05-24 17:01:14 --> Router Class Initialized
INFO - 2025-05-24 17:01:14 --> Output Class Initialized
INFO - 2025-05-24 17:01:14 --> Security Class Initialized
DEBUG - 2025-05-24 17:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 17:01:14 --> Input Class Initialized
INFO - 2025-05-24 17:01:14 --> Language Class Initialized
ERROR - 2025-05-24 17:01:14 --> 404 Page Not Found: Progress/get_weekly_summary
INFO - 2025-05-24 17:01:21 --> Config Class Initialized
INFO - 2025-05-24 17:01:21 --> Hooks Class Initialized
DEBUG - 2025-05-24 17:01:21 --> UTF-8 Support Enabled
INFO - 2025-05-24 17:01:21 --> Utf8 Class Initialized
INFO - 2025-05-24 17:01:21 --> URI Class Initialized
INFO - 2025-05-24 17:01:21 --> Router Class Initialized
INFO - 2025-05-24 17:01:21 --> Output Class Initialized
INFO - 2025-05-24 17:01:21 --> Security Class Initialized
DEBUG - 2025-05-24 17:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 17:01:21 --> Input Class Initialized
INFO - 2025-05-24 17:01:21 --> Language Class Initialized
INFO - 2025-05-24 17:01:21 --> Loader Class Initialized
INFO - 2025-05-24 17:01:21 --> Helper loaded: url_helper
INFO - 2025-05-24 17:01:21 --> Helper loaded: form_helper
INFO - 2025-05-24 17:01:21 --> Database Driver Class Initialized
DEBUG - 2025-05-24 17:01:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 17:01:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 17:01:21 --> Controller Class Initialized
INFO - 2025-05-24 17:01:21 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 17:01:21 --> Model "User_model" initialized
INFO - 2025-05-24 17:01:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 17:01:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 17:01:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-05-24 17:01:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 17:01:21 --> Final output sent to browser
DEBUG - 2025-05-24 17:01:21 --> Total execution time: 0.0942
INFO - 2025-05-24 17:01:24 --> Config Class Initialized
INFO - 2025-05-24 17:01:24 --> Hooks Class Initialized
DEBUG - 2025-05-24 17:01:24 --> UTF-8 Support Enabled
INFO - 2025-05-24 17:01:24 --> Utf8 Class Initialized
INFO - 2025-05-24 17:01:24 --> URI Class Initialized
INFO - 2025-05-24 17:01:24 --> Router Class Initialized
INFO - 2025-05-24 17:01:24 --> Output Class Initialized
INFO - 2025-05-24 17:01:24 --> Security Class Initialized
DEBUG - 2025-05-24 17:01:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 17:01:24 --> Input Class Initialized
INFO - 2025-05-24 17:01:24 --> Language Class Initialized
INFO - 2025-05-24 17:01:24 --> Loader Class Initialized
INFO - 2025-05-24 17:01:24 --> Helper loaded: url_helper
INFO - 2025-05-24 17:01:24 --> Helper loaded: form_helper
INFO - 2025-05-24 17:01:24 --> Database Driver Class Initialized
DEBUG - 2025-05-24 17:01:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 17:01:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 17:01:24 --> Controller Class Initialized
INFO - 2025-05-24 17:01:24 --> Model "Progress_model" initialized
INFO - 2025-05-24 17:01:24 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 17:01:24 --> Model "User_model" initialized
INFO - 2025-05-24 17:01:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 17:01:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 17:01:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-24 17:01:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 17:01:24 --> Final output sent to browser
DEBUG - 2025-05-24 17:01:24 --> Total execution time: 0.0838
INFO - 2025-05-24 17:01:24 --> Config Class Initialized
INFO - 2025-05-24 17:01:24 --> Hooks Class Initialized
DEBUG - 2025-05-24 17:01:24 --> UTF-8 Support Enabled
INFO - 2025-05-24 17:01:24 --> Utf8 Class Initialized
INFO - 2025-05-24 17:01:24 --> URI Class Initialized
INFO - 2025-05-24 17:01:24 --> Router Class Initialized
INFO - 2025-05-24 17:01:24 --> Output Class Initialized
INFO - 2025-05-24 17:01:24 --> Security Class Initialized
DEBUG - 2025-05-24 17:01:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 17:01:24 --> Input Class Initialized
INFO - 2025-05-24 17:01:24 --> Language Class Initialized
INFO - 2025-05-24 17:01:24 --> Loader Class Initialized
INFO - 2025-05-24 17:01:24 --> Helper loaded: url_helper
INFO - 2025-05-24 17:01:24 --> Helper loaded: form_helper
INFO - 2025-05-24 17:01:24 --> Database Driver Class Initialized
DEBUG - 2025-05-24 17:01:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 17:01:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 17:01:24 --> Controller Class Initialized
INFO - 2025-05-24 17:01:24 --> Model "Progress_model" initialized
INFO - 2025-05-24 17:01:24 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 17:01:24 --> Model "User_model" initialized
INFO - 2025-05-24 17:01:24 --> Final output sent to browser
DEBUG - 2025-05-24 17:01:24 --> Total execution time: 0.0674
INFO - 2025-05-24 17:01:35 --> Config Class Initialized
INFO - 2025-05-24 17:01:35 --> Hooks Class Initialized
DEBUG - 2025-05-24 17:01:35 --> UTF-8 Support Enabled
INFO - 2025-05-24 17:01:35 --> Utf8 Class Initialized
INFO - 2025-05-24 17:01:35 --> URI Class Initialized
INFO - 2025-05-24 17:01:35 --> Router Class Initialized
INFO - 2025-05-24 17:01:35 --> Output Class Initialized
INFO - 2025-05-24 17:01:35 --> Security Class Initialized
DEBUG - 2025-05-24 17:01:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 17:01:35 --> Input Class Initialized
INFO - 2025-05-24 17:01:35 --> Language Class Initialized
INFO - 2025-05-24 17:01:35 --> Loader Class Initialized
INFO - 2025-05-24 17:01:35 --> Helper loaded: url_helper
INFO - 2025-05-24 17:01:35 --> Helper loaded: form_helper
INFO - 2025-05-24 17:01:35 --> Database Driver Class Initialized
DEBUG - 2025-05-24 17:01:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 17:01:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 17:01:35 --> Controller Class Initialized
INFO - 2025-05-24 17:01:35 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 17:01:35 --> Model "User_model" initialized
INFO - 2025-05-24 17:01:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 17:01:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 17:01:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-05-24 17:01:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 17:01:35 --> Final output sent to browser
DEBUG - 2025-05-24 17:01:35 --> Total execution time: 0.0813
INFO - 2025-05-24 17:01:38 --> Config Class Initialized
INFO - 2025-05-24 17:01:38 --> Hooks Class Initialized
DEBUG - 2025-05-24 17:01:38 --> UTF-8 Support Enabled
INFO - 2025-05-24 17:01:38 --> Utf8 Class Initialized
INFO - 2025-05-24 17:01:38 --> URI Class Initialized
INFO - 2025-05-24 17:01:38 --> Router Class Initialized
INFO - 2025-05-24 17:01:38 --> Output Class Initialized
INFO - 2025-05-24 17:01:38 --> Security Class Initialized
DEBUG - 2025-05-24 17:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 17:01:38 --> Input Class Initialized
INFO - 2025-05-24 17:01:38 --> Language Class Initialized
INFO - 2025-05-24 17:01:38 --> Loader Class Initialized
INFO - 2025-05-24 17:01:38 --> Helper loaded: url_helper
INFO - 2025-05-24 17:01:38 --> Helper loaded: form_helper
INFO - 2025-05-24 17:01:38 --> Database Driver Class Initialized
DEBUG - 2025-05-24 17:01:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 17:01:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 17:01:38 --> Controller Class Initialized
INFO - 2025-05-24 17:01:38 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 17:01:38 --> Model "User_model" initialized
INFO - 2025-05-24 17:01:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 17:01:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 17:01:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/level.php
INFO - 2025-05-24 17:01:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 17:01:38 --> Final output sent to browser
DEBUG - 2025-05-24 17:01:38 --> Total execution time: 0.0686
INFO - 2025-05-24 17:01:39 --> Config Class Initialized
INFO - 2025-05-24 17:01:39 --> Hooks Class Initialized
DEBUG - 2025-05-24 17:01:39 --> UTF-8 Support Enabled
INFO - 2025-05-24 17:01:39 --> Utf8 Class Initialized
INFO - 2025-05-24 17:01:39 --> URI Class Initialized
INFO - 2025-05-24 17:01:39 --> Router Class Initialized
INFO - 2025-05-24 17:01:39 --> Output Class Initialized
INFO - 2025-05-24 17:01:39 --> Security Class Initialized
DEBUG - 2025-05-24 17:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 17:01:39 --> Input Class Initialized
INFO - 2025-05-24 17:01:39 --> Language Class Initialized
INFO - 2025-05-24 17:01:39 --> Loader Class Initialized
INFO - 2025-05-24 17:01:39 --> Helper loaded: url_helper
INFO - 2025-05-24 17:01:39 --> Helper loaded: form_helper
INFO - 2025-05-24 17:01:39 --> Database Driver Class Initialized
DEBUG - 2025-05-24 17:01:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 17:01:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 17:01:39 --> Controller Class Initialized
INFO - 2025-05-24 17:01:39 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 17:01:39 --> Model "User_model" initialized
INFO - 2025-05-24 17:01:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 17:01:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 17:01:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/menu.php
INFO - 2025-05-24 17:01:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 17:01:39 --> Final output sent to browser
DEBUG - 2025-05-24 17:01:39 --> Total execution time: 0.0719
INFO - 2025-05-24 17:01:41 --> Config Class Initialized
INFO - 2025-05-24 17:01:41 --> Hooks Class Initialized
DEBUG - 2025-05-24 17:01:41 --> UTF-8 Support Enabled
INFO - 2025-05-24 17:01:41 --> Utf8 Class Initialized
INFO - 2025-05-24 17:01:41 --> URI Class Initialized
INFO - 2025-05-24 17:01:41 --> Router Class Initialized
INFO - 2025-05-24 17:01:41 --> Output Class Initialized
INFO - 2025-05-24 17:01:41 --> Security Class Initialized
DEBUG - 2025-05-24 17:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 17:01:41 --> Input Class Initialized
INFO - 2025-05-24 17:01:41 --> Language Class Initialized
INFO - 2025-05-24 17:01:41 --> Loader Class Initialized
INFO - 2025-05-24 17:01:41 --> Helper loaded: url_helper
INFO - 2025-05-24 17:01:41 --> Helper loaded: form_helper
INFO - 2025-05-24 17:01:41 --> Database Driver Class Initialized
DEBUG - 2025-05-24 17:01:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 17:01:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 17:01:41 --> Controller Class Initialized
INFO - 2025-05-24 17:01:41 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 17:01:41 --> Model "User_model" initialized
INFO - 2025-05-24 17:01:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 17:01:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 17:01:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/start.php
INFO - 2025-05-24 17:01:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 17:01:41 --> Final output sent to browser
DEBUG - 2025-05-24 17:01:41 --> Total execution time: 0.0929
INFO - 2025-05-24 17:01:48 --> Config Class Initialized
INFO - 2025-05-24 17:01:48 --> Hooks Class Initialized
DEBUG - 2025-05-24 17:01:48 --> UTF-8 Support Enabled
INFO - 2025-05-24 17:01:48 --> Utf8 Class Initialized
INFO - 2025-05-24 17:01:48 --> URI Class Initialized
INFO - 2025-05-24 17:01:48 --> Router Class Initialized
INFO - 2025-05-24 17:01:48 --> Output Class Initialized
INFO - 2025-05-24 17:01:48 --> Security Class Initialized
DEBUG - 2025-05-24 17:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 17:01:48 --> Input Class Initialized
INFO - 2025-05-24 17:01:48 --> Language Class Initialized
INFO - 2025-05-24 17:01:48 --> Loader Class Initialized
INFO - 2025-05-24 17:01:48 --> Helper loaded: url_helper
INFO - 2025-05-24 17:01:48 --> Helper loaded: form_helper
INFO - 2025-05-24 17:01:48 --> Database Driver Class Initialized
DEBUG - 2025-05-24 17:01:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 17:01:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 17:01:48 --> Controller Class Initialized
INFO - 2025-05-24 17:01:48 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 17:01:48 --> Model "User_model" initialized
INFO - 2025-05-24 17:01:48 --> Final output sent to browser
DEBUG - 2025-05-24 17:01:48 --> Total execution time: 0.0691
INFO - 2025-05-24 17:01:50 --> Config Class Initialized
INFO - 2025-05-24 17:01:50 --> Hooks Class Initialized
DEBUG - 2025-05-24 17:01:50 --> UTF-8 Support Enabled
INFO - 2025-05-24 17:01:50 --> Utf8 Class Initialized
INFO - 2025-05-24 17:01:50 --> URI Class Initialized
INFO - 2025-05-24 17:01:50 --> Router Class Initialized
INFO - 2025-05-24 17:01:50 --> Output Class Initialized
INFO - 2025-05-24 17:01:50 --> Security Class Initialized
DEBUG - 2025-05-24 17:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 17:01:50 --> Input Class Initialized
INFO - 2025-05-24 17:01:50 --> Language Class Initialized
INFO - 2025-05-24 17:01:50 --> Loader Class Initialized
INFO - 2025-05-24 17:01:50 --> Helper loaded: url_helper
INFO - 2025-05-24 17:01:50 --> Helper loaded: form_helper
INFO - 2025-05-24 17:01:50 --> Database Driver Class Initialized
DEBUG - 2025-05-24 17:01:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 17:01:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 17:01:50 --> Controller Class Initialized
INFO - 2025-05-24 17:01:50 --> Model "Progress_model" initialized
INFO - 2025-05-24 17:01:50 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 17:01:50 --> Model "User_model" initialized
INFO - 2025-05-24 17:01:50 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 17:01:50 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 17:01:50 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-24 17:01:50 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 17:01:50 --> Final output sent to browser
DEBUG - 2025-05-24 17:01:50 --> Total execution time: 0.0939
INFO - 2025-05-24 17:01:51 --> Config Class Initialized
INFO - 2025-05-24 17:01:51 --> Hooks Class Initialized
DEBUG - 2025-05-24 17:01:51 --> UTF-8 Support Enabled
INFO - 2025-05-24 17:01:51 --> Utf8 Class Initialized
INFO - 2025-05-24 17:01:51 --> URI Class Initialized
INFO - 2025-05-24 17:01:51 --> Router Class Initialized
INFO - 2025-05-24 17:01:51 --> Output Class Initialized
INFO - 2025-05-24 17:01:51 --> Security Class Initialized
DEBUG - 2025-05-24 17:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 17:01:51 --> Input Class Initialized
INFO - 2025-05-24 17:01:51 --> Language Class Initialized
INFO - 2025-05-24 17:01:51 --> Loader Class Initialized
INFO - 2025-05-24 17:01:51 --> Helper loaded: url_helper
INFO - 2025-05-24 17:01:51 --> Helper loaded: form_helper
INFO - 2025-05-24 17:01:51 --> Database Driver Class Initialized
DEBUG - 2025-05-24 17:01:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 17:01:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 17:01:51 --> Controller Class Initialized
INFO - 2025-05-24 17:01:51 --> Model "Progress_model" initialized
INFO - 2025-05-24 17:01:51 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 17:01:51 --> Model "User_model" initialized
INFO - 2025-05-24 17:01:51 --> Final output sent to browser
DEBUG - 2025-05-24 17:01:51 --> Total execution time: 0.0817
INFO - 2025-05-24 17:01:56 --> Config Class Initialized
INFO - 2025-05-24 17:01:56 --> Hooks Class Initialized
DEBUG - 2025-05-24 17:01:56 --> UTF-8 Support Enabled
INFO - 2025-05-24 17:01:56 --> Utf8 Class Initialized
INFO - 2025-05-24 17:01:56 --> URI Class Initialized
INFO - 2025-05-24 17:01:56 --> Router Class Initialized
INFO - 2025-05-24 17:01:56 --> Output Class Initialized
INFO - 2025-05-24 17:01:56 --> Security Class Initialized
DEBUG - 2025-05-24 17:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 17:01:56 --> Input Class Initialized
INFO - 2025-05-24 17:01:56 --> Language Class Initialized
INFO - 2025-05-24 17:01:56 --> Loader Class Initialized
INFO - 2025-05-24 17:01:56 --> Helper loaded: url_helper
INFO - 2025-05-24 17:01:56 --> Helper loaded: form_helper
INFO - 2025-05-24 17:01:56 --> Database Driver Class Initialized
DEBUG - 2025-05-24 17:01:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 17:01:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 17:01:56 --> Controller Class Initialized
INFO - 2025-05-24 17:01:56 --> Model "User_model" initialized
INFO - 2025-05-24 17:01:56 --> Model "Workout_model" initialized
INFO - 2025-05-24 17:01:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 17:01:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 17:01:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-24 17:01:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 17:01:56 --> Final output sent to browser
DEBUG - 2025-05-24 17:01:56 --> Total execution time: 0.0916
INFO - 2025-05-24 17:01:57 --> Config Class Initialized
INFO - 2025-05-24 17:01:57 --> Hooks Class Initialized
DEBUG - 2025-05-24 17:01:57 --> UTF-8 Support Enabled
INFO - 2025-05-24 17:01:57 --> Utf8 Class Initialized
INFO - 2025-05-24 17:01:57 --> URI Class Initialized
INFO - 2025-05-24 17:01:57 --> Router Class Initialized
INFO - 2025-05-24 17:01:57 --> Output Class Initialized
INFO - 2025-05-24 17:01:57 --> Security Class Initialized
DEBUG - 2025-05-24 17:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 17:01:57 --> Input Class Initialized
INFO - 2025-05-24 17:01:57 --> Language Class Initialized
ERROR - 2025-05-24 17:01:57 --> 404 Page Not Found: Progress/get_weekly_summary
INFO - 2025-05-24 17:02:23 --> Config Class Initialized
INFO - 2025-05-24 17:02:23 --> Hooks Class Initialized
DEBUG - 2025-05-24 17:02:23 --> UTF-8 Support Enabled
INFO - 2025-05-24 17:02:23 --> Utf8 Class Initialized
INFO - 2025-05-24 17:02:23 --> URI Class Initialized
INFO - 2025-05-24 17:02:23 --> Router Class Initialized
INFO - 2025-05-24 17:02:23 --> Output Class Initialized
INFO - 2025-05-24 17:02:23 --> Security Class Initialized
DEBUG - 2025-05-24 17:02:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 17:02:23 --> Input Class Initialized
INFO - 2025-05-24 17:02:23 --> Language Class Initialized
INFO - 2025-05-24 17:02:23 --> Loader Class Initialized
INFO - 2025-05-24 17:02:23 --> Helper loaded: url_helper
INFO - 2025-05-24 17:02:23 --> Helper loaded: form_helper
INFO - 2025-05-24 17:02:23 --> Database Driver Class Initialized
DEBUG - 2025-05-24 17:02:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 17:02:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 17:02:23 --> Controller Class Initialized
INFO - 2025-05-24 17:02:23 --> Model "User_model" initialized
INFO - 2025-05-24 17:02:23 --> Model "Workout_model" initialized
INFO - 2025-05-24 17:02:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 17:02:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 17:02:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-24 17:02:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 17:02:23 --> Final output sent to browser
DEBUG - 2025-05-24 17:02:23 --> Total execution time: 0.0816
INFO - 2025-05-24 17:02:23 --> Config Class Initialized
INFO - 2025-05-24 17:02:23 --> Hooks Class Initialized
DEBUG - 2025-05-24 17:02:23 --> UTF-8 Support Enabled
INFO - 2025-05-24 17:02:23 --> Utf8 Class Initialized
INFO - 2025-05-24 17:02:23 --> URI Class Initialized
INFO - 2025-05-24 17:02:23 --> Router Class Initialized
INFO - 2025-05-24 17:02:23 --> Output Class Initialized
INFO - 2025-05-24 17:02:23 --> Security Class Initialized
DEBUG - 2025-05-24 17:02:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 17:02:23 --> Input Class Initialized
INFO - 2025-05-24 17:02:23 --> Language Class Initialized
ERROR - 2025-05-24 17:02:23 --> 404 Page Not Found: Progress/get_weekly_summary
INFO - 2025-05-24 17:03:18 --> Config Class Initialized
INFO - 2025-05-24 17:03:18 --> Hooks Class Initialized
DEBUG - 2025-05-24 17:03:18 --> UTF-8 Support Enabled
INFO - 2025-05-24 17:03:18 --> Utf8 Class Initialized
INFO - 2025-05-24 17:03:18 --> URI Class Initialized
INFO - 2025-05-24 17:03:19 --> Router Class Initialized
INFO - 2025-05-24 17:03:19 --> Output Class Initialized
INFO - 2025-05-24 17:03:19 --> Security Class Initialized
DEBUG - 2025-05-24 17:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 17:03:19 --> Input Class Initialized
INFO - 2025-05-24 17:03:19 --> Language Class Initialized
INFO - 2025-05-24 17:03:19 --> Loader Class Initialized
INFO - 2025-05-24 17:03:19 --> Helper loaded: url_helper
INFO - 2025-05-24 17:03:19 --> Helper loaded: form_helper
INFO - 2025-05-24 17:03:19 --> Database Driver Class Initialized
DEBUG - 2025-05-24 17:03:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 17:03:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 17:03:19 --> Controller Class Initialized
INFO - 2025-05-24 17:03:19 --> Model "User_model" initialized
INFO - 2025-05-24 17:03:19 --> Model "Workout_model" initialized
INFO - 2025-05-24 17:03:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 17:03:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 17:03:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-24 17:03:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 17:03:19 --> Final output sent to browser
DEBUG - 2025-05-24 17:03:19 --> Total execution time: 0.1007
INFO - 2025-05-24 17:03:19 --> Config Class Initialized
INFO - 2025-05-24 17:03:19 --> Hooks Class Initialized
DEBUG - 2025-05-24 17:03:19 --> UTF-8 Support Enabled
INFO - 2025-05-24 17:03:19 --> Utf8 Class Initialized
INFO - 2025-05-24 17:03:19 --> URI Class Initialized
INFO - 2025-05-24 17:03:19 --> Router Class Initialized
INFO - 2025-05-24 17:03:19 --> Output Class Initialized
INFO - 2025-05-24 17:03:19 --> Security Class Initialized
DEBUG - 2025-05-24 17:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 17:03:19 --> Input Class Initialized
INFO - 2025-05-24 17:03:19 --> Language Class Initialized
ERROR - 2025-05-24 17:03:19 --> 404 Page Not Found: Progress/get_weekly_summary
INFO - 2025-05-24 17:04:17 --> Config Class Initialized
INFO - 2025-05-24 17:04:17 --> Hooks Class Initialized
DEBUG - 2025-05-24 17:04:17 --> UTF-8 Support Enabled
INFO - 2025-05-24 17:04:17 --> Utf8 Class Initialized
INFO - 2025-05-24 17:04:17 --> URI Class Initialized
INFO - 2025-05-24 17:04:17 --> Router Class Initialized
INFO - 2025-05-24 17:04:17 --> Output Class Initialized
INFO - 2025-05-24 17:04:17 --> Security Class Initialized
DEBUG - 2025-05-24 17:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 17:04:17 --> Input Class Initialized
INFO - 2025-05-24 17:04:17 --> Language Class Initialized
INFO - 2025-05-24 17:04:17 --> Loader Class Initialized
INFO - 2025-05-24 17:04:17 --> Helper loaded: url_helper
INFO - 2025-05-24 17:04:17 --> Helper loaded: form_helper
INFO - 2025-05-24 17:04:17 --> Database Driver Class Initialized
DEBUG - 2025-05-24 17:04:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 17:04:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 17:04:17 --> Controller Class Initialized
INFO - 2025-05-24 17:04:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\beta.php
INFO - 2025-05-24 17:04:17 --> Final output sent to browser
DEBUG - 2025-05-24 17:04:17 --> Total execution time: 0.1350
INFO - 2025-05-24 17:04:17 --> Config Class Initialized
INFO - 2025-05-24 17:04:17 --> Hooks Class Initialized
DEBUG - 2025-05-24 17:04:17 --> UTF-8 Support Enabled
INFO - 2025-05-24 17:04:17 --> Utf8 Class Initialized
INFO - 2025-05-24 17:04:17 --> URI Class Initialized
INFO - 2025-05-24 17:04:17 --> Router Class Initialized
INFO - 2025-05-24 17:04:17 --> Output Class Initialized
INFO - 2025-05-24 17:04:17 --> Security Class Initialized
DEBUG - 2025-05-24 17:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 17:04:17 --> Input Class Initialized
INFO - 2025-05-24 17:04:17 --> Language Class Initialized
ERROR - 2025-05-24 17:04:17 --> 404 Page Not Found: Progress/get_weekly_summary
INFO - 2025-05-24 17:06:34 --> Config Class Initialized
INFO - 2025-05-24 17:06:34 --> Hooks Class Initialized
DEBUG - 2025-05-24 17:06:34 --> UTF-8 Support Enabled
INFO - 2025-05-24 17:06:34 --> Utf8 Class Initialized
INFO - 2025-05-24 17:06:34 --> URI Class Initialized
INFO - 2025-05-24 17:06:34 --> Router Class Initialized
INFO - 2025-05-24 17:06:34 --> Output Class Initialized
INFO - 2025-05-24 17:06:34 --> Security Class Initialized
DEBUG - 2025-05-24 17:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 17:06:34 --> Input Class Initialized
INFO - 2025-05-24 17:06:34 --> Language Class Initialized
INFO - 2025-05-24 17:06:34 --> Loader Class Initialized
INFO - 2025-05-24 17:06:34 --> Helper loaded: url_helper
INFO - 2025-05-24 17:06:34 --> Helper loaded: form_helper
INFO - 2025-05-24 17:06:34 --> Database Driver Class Initialized
DEBUG - 2025-05-24 17:06:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 17:06:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 17:06:34 --> Controller Class Initialized
INFO - 2025-05-24 17:06:34 --> Model "User_model" initialized
INFO - 2025-05-24 17:06:34 --> Model "Workout_model" initialized
INFO - 2025-05-24 17:06:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 17:06:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 17:06:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-24 17:06:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 17:06:34 --> Final output sent to browser
DEBUG - 2025-05-24 17:06:34 --> Total execution time: 0.0841
INFO - 2025-05-24 17:07:30 --> Config Class Initialized
INFO - 2025-05-24 17:07:30 --> Hooks Class Initialized
DEBUG - 2025-05-24 17:07:30 --> UTF-8 Support Enabled
INFO - 2025-05-24 17:07:30 --> Utf8 Class Initialized
INFO - 2025-05-24 17:07:30 --> URI Class Initialized
INFO - 2025-05-24 17:07:30 --> Router Class Initialized
INFO - 2025-05-24 17:07:30 --> Output Class Initialized
INFO - 2025-05-24 17:07:30 --> Security Class Initialized
DEBUG - 2025-05-24 17:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 17:07:30 --> Input Class Initialized
INFO - 2025-05-24 17:07:30 --> Language Class Initialized
INFO - 2025-05-24 17:07:30 --> Loader Class Initialized
INFO - 2025-05-24 17:07:30 --> Helper loaded: url_helper
INFO - 2025-05-24 17:07:30 --> Helper loaded: form_helper
INFO - 2025-05-24 17:07:30 --> Database Driver Class Initialized
DEBUG - 2025-05-24 17:07:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 17:07:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 17:07:30 --> Controller Class Initialized
INFO - 2025-05-24 17:07:30 --> Model "Progress_model" initialized
INFO - 2025-05-24 17:07:30 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 17:07:30 --> Model "User_model" initialized
INFO - 2025-05-24 17:07:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 17:07:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 17:07:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-24 17:07:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 17:07:30 --> Final output sent to browser
DEBUG - 2025-05-24 17:07:30 --> Total execution time: 0.0930
INFO - 2025-05-24 17:07:31 --> Config Class Initialized
INFO - 2025-05-24 17:07:31 --> Hooks Class Initialized
DEBUG - 2025-05-24 17:07:31 --> UTF-8 Support Enabled
INFO - 2025-05-24 17:07:31 --> Utf8 Class Initialized
INFO - 2025-05-24 17:07:31 --> URI Class Initialized
INFO - 2025-05-24 17:07:31 --> Router Class Initialized
INFO - 2025-05-24 17:07:31 --> Output Class Initialized
INFO - 2025-05-24 17:07:31 --> Security Class Initialized
DEBUG - 2025-05-24 17:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 17:07:31 --> Input Class Initialized
INFO - 2025-05-24 17:07:31 --> Language Class Initialized
INFO - 2025-05-24 17:07:31 --> Loader Class Initialized
INFO - 2025-05-24 17:07:31 --> Helper loaded: url_helper
INFO - 2025-05-24 17:07:31 --> Helper loaded: form_helper
INFO - 2025-05-24 17:07:31 --> Database Driver Class Initialized
DEBUG - 2025-05-24 17:07:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 17:07:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 17:07:31 --> Controller Class Initialized
INFO - 2025-05-24 17:07:31 --> Model "Progress_model" initialized
INFO - 2025-05-24 17:07:31 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 17:07:31 --> Model "User_model" initialized
INFO - 2025-05-24 17:07:31 --> Final output sent to browser
DEBUG - 2025-05-24 17:07:31 --> Total execution time: 0.0915
INFO - 2025-05-24 17:07:34 --> Config Class Initialized
INFO - 2025-05-24 17:07:34 --> Hooks Class Initialized
DEBUG - 2025-05-24 17:07:34 --> UTF-8 Support Enabled
INFO - 2025-05-24 17:07:34 --> Utf8 Class Initialized
INFO - 2025-05-24 17:07:34 --> URI Class Initialized
INFO - 2025-05-24 17:07:34 --> Router Class Initialized
INFO - 2025-05-24 17:07:35 --> Output Class Initialized
INFO - 2025-05-24 17:07:35 --> Security Class Initialized
DEBUG - 2025-05-24 17:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 17:07:35 --> Input Class Initialized
INFO - 2025-05-24 17:07:35 --> Language Class Initialized
INFO - 2025-05-24 17:07:35 --> Loader Class Initialized
INFO - 2025-05-24 17:07:35 --> Helper loaded: url_helper
INFO - 2025-05-24 17:07:35 --> Helper loaded: form_helper
INFO - 2025-05-24 17:07:35 --> Database Driver Class Initialized
DEBUG - 2025-05-24 17:07:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 17:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 17:07:35 --> Controller Class Initialized
INFO - 2025-05-24 17:07:35 --> Model "User_model" initialized
INFO - 2025-05-24 17:07:35 --> Model "Workout_model" initialized
INFO - 2025-05-24 17:07:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 17:07:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 17:07:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-24 17:07:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 17:07:35 --> Final output sent to browser
DEBUG - 2025-05-24 17:07:35 --> Total execution time: 0.0819
INFO - 2025-05-24 17:07:35 --> Config Class Initialized
INFO - 2025-05-24 17:07:35 --> Hooks Class Initialized
DEBUG - 2025-05-24 17:07:35 --> UTF-8 Support Enabled
INFO - 2025-05-24 17:07:35 --> Utf8 Class Initialized
INFO - 2025-05-24 17:07:35 --> URI Class Initialized
INFO - 2025-05-24 17:07:35 --> Router Class Initialized
INFO - 2025-05-24 17:07:35 --> Output Class Initialized
INFO - 2025-05-24 17:07:35 --> Security Class Initialized
DEBUG - 2025-05-24 17:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 17:07:35 --> Input Class Initialized
INFO - 2025-05-24 17:07:35 --> Language Class Initialized
ERROR - 2025-05-24 17:07:35 --> 404 Page Not Found: Progress/get_weekly_summary
INFO - 2025-05-24 17:10:26 --> Config Class Initialized
INFO - 2025-05-24 17:10:26 --> Hooks Class Initialized
DEBUG - 2025-05-24 17:10:26 --> UTF-8 Support Enabled
INFO - 2025-05-24 17:10:26 --> Utf8 Class Initialized
INFO - 2025-05-24 17:10:27 --> URI Class Initialized
INFO - 2025-05-24 17:10:27 --> Router Class Initialized
INFO - 2025-05-24 17:10:27 --> Output Class Initialized
INFO - 2025-05-24 17:10:27 --> Security Class Initialized
DEBUG - 2025-05-24 17:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 17:10:27 --> Input Class Initialized
INFO - 2025-05-24 17:10:27 --> Language Class Initialized
INFO - 2025-05-24 17:10:27 --> Loader Class Initialized
INFO - 2025-05-24 17:10:27 --> Helper loaded: url_helper
INFO - 2025-05-24 17:10:27 --> Helper loaded: form_helper
INFO - 2025-05-24 17:10:27 --> Database Driver Class Initialized
DEBUG - 2025-05-24 17:10:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 17:10:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 17:10:27 --> Controller Class Initialized
INFO - 2025-05-24 17:10:27 --> Model "User_model" initialized
INFO - 2025-05-24 17:10:27 --> Model "Workout_model" initialized
INFO - 2025-05-24 17:10:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 17:10:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 17:10:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-24 17:10:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 17:10:27 --> Final output sent to browser
DEBUG - 2025-05-24 17:10:27 --> Total execution time: 0.1525
INFO - 2025-05-24 17:10:27 --> Config Class Initialized
INFO - 2025-05-24 17:10:27 --> Hooks Class Initialized
DEBUG - 2025-05-24 17:10:27 --> UTF-8 Support Enabled
INFO - 2025-05-24 17:10:27 --> Utf8 Class Initialized
INFO - 2025-05-24 17:10:27 --> URI Class Initialized
INFO - 2025-05-24 17:10:27 --> Router Class Initialized
INFO - 2025-05-24 17:10:27 --> Output Class Initialized
INFO - 2025-05-24 17:10:27 --> Security Class Initialized
DEBUG - 2025-05-24 17:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 17:10:27 --> Input Class Initialized
INFO - 2025-05-24 17:10:27 --> Language Class Initialized
INFO - 2025-05-24 17:10:27 --> Loader Class Initialized
INFO - 2025-05-24 17:10:27 --> Helper loaded: url_helper
INFO - 2025-05-24 17:10:27 --> Helper loaded: form_helper
INFO - 2025-05-24 17:10:27 --> Database Driver Class Initialized
DEBUG - 2025-05-24 17:10:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 17:10:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 17:10:27 --> Controller Class Initialized
INFO - 2025-05-24 17:10:27 --> Model "User_model" initialized
INFO - 2025-05-24 17:10:27 --> Model "Workout_model" initialized
ERROR - 2025-05-24 17:10:27 --> Severity: Warning --> Undefined property: Dashboard::$Progress_model C:\laragon\www\Project\fitnessrecord\application\controllers\Dashboard.php 57
ERROR - 2025-05-24 17:10:27 --> Severity: error --> Exception: Call to a member function get_weekly_summary_by_user() on null C:\laragon\www\Project\fitnessrecord\application\controllers\Dashboard.php 57
INFO - 2025-05-24 17:10:40 --> Config Class Initialized
INFO - 2025-05-24 17:10:40 --> Hooks Class Initialized
DEBUG - 2025-05-24 17:10:40 --> UTF-8 Support Enabled
INFO - 2025-05-24 17:10:40 --> Utf8 Class Initialized
INFO - 2025-05-24 17:10:40 --> URI Class Initialized
INFO - 2025-05-24 17:10:40 --> Router Class Initialized
INFO - 2025-05-24 17:10:40 --> Output Class Initialized
INFO - 2025-05-24 17:10:40 --> Security Class Initialized
DEBUG - 2025-05-24 17:10:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 17:10:40 --> Input Class Initialized
INFO - 2025-05-24 17:10:40 --> Language Class Initialized
INFO - 2025-05-24 17:10:40 --> Loader Class Initialized
INFO - 2025-05-24 17:10:40 --> Helper loaded: url_helper
INFO - 2025-05-24 17:10:40 --> Helper loaded: form_helper
INFO - 2025-05-24 17:10:40 --> Database Driver Class Initialized
DEBUG - 2025-05-24 17:10:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 17:10:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 17:10:40 --> Controller Class Initialized
INFO - 2025-05-24 17:10:40 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 17:10:40 --> Model "User_model" initialized
INFO - 2025-05-24 17:10:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 17:10:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 17:10:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-05-24 17:10:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 17:10:40 --> Final output sent to browser
DEBUG - 2025-05-24 17:10:40 --> Total execution time: 0.0825
INFO - 2025-05-24 17:10:42 --> Config Class Initialized
INFO - 2025-05-24 17:10:42 --> Hooks Class Initialized
DEBUG - 2025-05-24 17:10:42 --> UTF-8 Support Enabled
INFO - 2025-05-24 17:10:42 --> Utf8 Class Initialized
INFO - 2025-05-24 17:10:42 --> URI Class Initialized
INFO - 2025-05-24 17:10:42 --> Router Class Initialized
INFO - 2025-05-24 17:10:42 --> Output Class Initialized
INFO - 2025-05-24 17:10:42 --> Security Class Initialized
DEBUG - 2025-05-24 17:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 17:10:42 --> Input Class Initialized
INFO - 2025-05-24 17:10:42 --> Language Class Initialized
INFO - 2025-05-24 17:10:42 --> Loader Class Initialized
INFO - 2025-05-24 17:10:42 --> Helper loaded: url_helper
INFO - 2025-05-24 17:10:42 --> Helper loaded: form_helper
INFO - 2025-05-24 17:10:42 --> Database Driver Class Initialized
DEBUG - 2025-05-24 17:10:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 17:10:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 17:10:42 --> Controller Class Initialized
INFO - 2025-05-24 17:10:42 --> Model "Progress_model" initialized
INFO - 2025-05-24 17:10:42 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 17:10:42 --> Model "User_model" initialized
INFO - 2025-05-24 17:10:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 17:10:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 17:10:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-24 17:10:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 17:10:42 --> Final output sent to browser
DEBUG - 2025-05-24 17:10:42 --> Total execution time: 0.0715
INFO - 2025-05-24 17:10:43 --> Config Class Initialized
INFO - 2025-05-24 17:10:43 --> Hooks Class Initialized
DEBUG - 2025-05-24 17:10:43 --> UTF-8 Support Enabled
INFO - 2025-05-24 17:10:43 --> Utf8 Class Initialized
INFO - 2025-05-24 17:10:43 --> URI Class Initialized
INFO - 2025-05-24 17:10:43 --> Router Class Initialized
INFO - 2025-05-24 17:10:43 --> Output Class Initialized
INFO - 2025-05-24 17:10:43 --> Security Class Initialized
DEBUG - 2025-05-24 17:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 17:10:43 --> Input Class Initialized
INFO - 2025-05-24 17:10:43 --> Language Class Initialized
INFO - 2025-05-24 17:10:43 --> Loader Class Initialized
INFO - 2025-05-24 17:10:43 --> Helper loaded: url_helper
INFO - 2025-05-24 17:10:43 --> Helper loaded: form_helper
INFO - 2025-05-24 17:10:43 --> Database Driver Class Initialized
DEBUG - 2025-05-24 17:10:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 17:10:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 17:10:43 --> Controller Class Initialized
INFO - 2025-05-24 17:10:43 --> Model "Progress_model" initialized
INFO - 2025-05-24 17:10:43 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 17:10:43 --> Model "User_model" initialized
INFO - 2025-05-24 17:10:43 --> Final output sent to browser
DEBUG - 2025-05-24 17:10:43 --> Total execution time: 0.0882
INFO - 2025-05-24 17:10:46 --> Config Class Initialized
INFO - 2025-05-24 17:10:46 --> Hooks Class Initialized
DEBUG - 2025-05-24 17:10:46 --> UTF-8 Support Enabled
INFO - 2025-05-24 17:10:46 --> Utf8 Class Initialized
INFO - 2025-05-24 17:10:46 --> URI Class Initialized
INFO - 2025-05-24 17:10:46 --> Router Class Initialized
INFO - 2025-05-24 17:10:46 --> Output Class Initialized
INFO - 2025-05-24 17:10:46 --> Security Class Initialized
DEBUG - 2025-05-24 17:10:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 17:10:46 --> Input Class Initialized
INFO - 2025-05-24 17:10:46 --> Language Class Initialized
INFO - 2025-05-24 17:10:46 --> Loader Class Initialized
INFO - 2025-05-24 17:10:46 --> Helper loaded: url_helper
INFO - 2025-05-24 17:10:46 --> Helper loaded: form_helper
INFO - 2025-05-24 17:10:46 --> Database Driver Class Initialized
DEBUG - 2025-05-24 17:10:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 17:10:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 17:10:46 --> Controller Class Initialized
INFO - 2025-05-24 17:10:46 --> Model "User_model" initialized
INFO - 2025-05-24 17:10:46 --> Model "Workout_model" initialized
INFO - 2025-05-24 17:10:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 17:10:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 17:10:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-24 17:10:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 17:10:46 --> Final output sent to browser
DEBUG - 2025-05-24 17:10:46 --> Total execution time: 0.0886
INFO - 2025-05-24 17:10:48 --> Config Class Initialized
INFO - 2025-05-24 17:10:48 --> Hooks Class Initialized
DEBUG - 2025-05-24 17:10:48 --> UTF-8 Support Enabled
INFO - 2025-05-24 17:10:48 --> Utf8 Class Initialized
INFO - 2025-05-24 17:10:48 --> URI Class Initialized
INFO - 2025-05-24 17:10:48 --> Router Class Initialized
INFO - 2025-05-24 17:10:48 --> Output Class Initialized
INFO - 2025-05-24 17:10:48 --> Security Class Initialized
DEBUG - 2025-05-24 17:10:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 17:10:48 --> Input Class Initialized
INFO - 2025-05-24 17:10:48 --> Language Class Initialized
INFO - 2025-05-24 17:10:48 --> Loader Class Initialized
INFO - 2025-05-24 17:10:48 --> Helper loaded: url_helper
INFO - 2025-05-24 17:10:48 --> Helper loaded: form_helper
INFO - 2025-05-24 17:10:48 --> Database Driver Class Initialized
DEBUG - 2025-05-24 17:10:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 17:10:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 17:10:48 --> Controller Class Initialized
INFO - 2025-05-24 17:10:48 --> Model "User_model" initialized
INFO - 2025-05-24 17:10:48 --> Model "Workout_model" initialized
INFO - 2025-05-24 17:10:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 17:10:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 17:10:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-24 17:10:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 17:10:48 --> Final output sent to browser
DEBUG - 2025-05-24 17:10:48 --> Total execution time: 0.0882
INFO - 2025-05-24 17:10:48 --> Config Class Initialized
INFO - 2025-05-24 17:10:48 --> Hooks Class Initialized
DEBUG - 2025-05-24 17:10:48 --> UTF-8 Support Enabled
INFO - 2025-05-24 17:10:48 --> Utf8 Class Initialized
INFO - 2025-05-24 17:10:48 --> URI Class Initialized
INFO - 2025-05-24 17:10:48 --> Router Class Initialized
INFO - 2025-05-24 17:10:48 --> Output Class Initialized
INFO - 2025-05-24 17:10:48 --> Security Class Initialized
DEBUG - 2025-05-24 17:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 17:10:49 --> Input Class Initialized
INFO - 2025-05-24 17:10:49 --> Language Class Initialized
INFO - 2025-05-24 17:10:49 --> Loader Class Initialized
INFO - 2025-05-24 17:10:49 --> Helper loaded: url_helper
INFO - 2025-05-24 17:10:49 --> Helper loaded: form_helper
INFO - 2025-05-24 17:10:49 --> Database Driver Class Initialized
DEBUG - 2025-05-24 17:10:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 17:10:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 17:10:49 --> Controller Class Initialized
INFO - 2025-05-24 17:10:49 --> Model "User_model" initialized
INFO - 2025-05-24 17:10:49 --> Model "Workout_model" initialized
ERROR - 2025-05-24 17:10:49 --> Severity: Warning --> Undefined property: Dashboard::$Progress_model C:\laragon\www\Project\fitnessrecord\application\controllers\Dashboard.php 57
ERROR - 2025-05-24 17:10:49 --> Severity: error --> Exception: Call to a member function get_weekly_summary_by_user() on null C:\laragon\www\Project\fitnessrecord\application\controllers\Dashboard.php 57
INFO - 2025-05-24 17:14:56 --> Config Class Initialized
INFO - 2025-05-24 17:14:56 --> Hooks Class Initialized
DEBUG - 2025-05-24 17:14:56 --> UTF-8 Support Enabled
INFO - 2025-05-24 17:14:56 --> Utf8 Class Initialized
INFO - 2025-05-24 17:14:56 --> URI Class Initialized
INFO - 2025-05-24 17:14:56 --> Router Class Initialized
INFO - 2025-05-24 17:14:56 --> Output Class Initialized
INFO - 2025-05-24 17:14:56 --> Security Class Initialized
DEBUG - 2025-05-24 17:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 17:14:56 --> Input Class Initialized
INFO - 2025-05-24 17:14:56 --> Language Class Initialized
INFO - 2025-05-24 17:14:56 --> Loader Class Initialized
INFO - 2025-05-24 17:14:56 --> Helper loaded: url_helper
INFO - 2025-05-24 17:14:56 --> Helper loaded: form_helper
INFO - 2025-05-24 17:14:56 --> Database Driver Class Initialized
DEBUG - 2025-05-24 17:14:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 17:14:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 17:14:56 --> Controller Class Initialized
INFO - 2025-05-24 17:14:56 --> Model "User_model" initialized
INFO - 2025-05-24 17:14:56 --> Model "Workout_model" initialized
INFO - 2025-05-24 17:14:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 17:14:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 17:14:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-24 17:14:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 17:14:56 --> Final output sent to browser
DEBUG - 2025-05-24 17:14:56 --> Total execution time: 0.0814
INFO - 2025-05-24 17:14:57 --> Config Class Initialized
INFO - 2025-05-24 17:14:57 --> Hooks Class Initialized
DEBUG - 2025-05-24 17:14:57 --> UTF-8 Support Enabled
INFO - 2025-05-24 17:14:57 --> Utf8 Class Initialized
INFO - 2025-05-24 17:14:57 --> URI Class Initialized
INFO - 2025-05-24 17:14:57 --> Router Class Initialized
INFO - 2025-05-24 17:14:57 --> Output Class Initialized
INFO - 2025-05-24 17:14:57 --> Security Class Initialized
DEBUG - 2025-05-24 17:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 17:14:57 --> Input Class Initialized
INFO - 2025-05-24 17:14:57 --> Language Class Initialized
ERROR - 2025-05-24 17:14:57 --> 404 Page Not Found: Progress/get_weekly_summary
INFO - 2025-05-24 17:17:34 --> Config Class Initialized
INFO - 2025-05-24 17:17:34 --> Hooks Class Initialized
DEBUG - 2025-05-24 17:17:34 --> UTF-8 Support Enabled
INFO - 2025-05-24 17:17:34 --> Utf8 Class Initialized
INFO - 2025-05-24 17:17:34 --> URI Class Initialized
INFO - 2025-05-24 17:17:34 --> Router Class Initialized
INFO - 2025-05-24 17:17:34 --> Output Class Initialized
INFO - 2025-05-24 17:17:34 --> Security Class Initialized
DEBUG - 2025-05-24 17:17:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 17:17:34 --> Input Class Initialized
INFO - 2025-05-24 17:17:34 --> Language Class Initialized
INFO - 2025-05-24 17:17:34 --> Loader Class Initialized
INFO - 2025-05-24 17:17:34 --> Helper loaded: url_helper
INFO - 2025-05-24 17:17:34 --> Helper loaded: form_helper
INFO - 2025-05-24 17:17:34 --> Database Driver Class Initialized
DEBUG - 2025-05-24 17:17:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 17:17:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 17:17:34 --> Controller Class Initialized
INFO - 2025-05-24 17:17:34 --> Model "User_model" initialized
INFO - 2025-05-24 17:17:34 --> Model "Workout_model" initialized
INFO - 2025-05-24 17:17:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 17:17:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 17:17:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-24 17:17:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 17:17:34 --> Final output sent to browser
DEBUG - 2025-05-24 17:17:34 --> Total execution time: 0.0842
INFO - 2025-05-24 17:17:35 --> Config Class Initialized
INFO - 2025-05-24 17:17:35 --> Hooks Class Initialized
DEBUG - 2025-05-24 17:17:35 --> UTF-8 Support Enabled
INFO - 2025-05-24 17:17:35 --> Utf8 Class Initialized
INFO - 2025-05-24 17:17:35 --> URI Class Initialized
INFO - 2025-05-24 17:17:35 --> Router Class Initialized
INFO - 2025-05-24 17:17:35 --> Output Class Initialized
INFO - 2025-05-24 17:17:35 --> Security Class Initialized
DEBUG - 2025-05-24 17:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 17:17:35 --> Input Class Initialized
INFO - 2025-05-24 17:17:35 --> Language Class Initialized
INFO - 2025-05-24 17:17:35 --> Loader Class Initialized
INFO - 2025-05-24 17:17:35 --> Helper loaded: url_helper
INFO - 2025-05-24 17:17:35 --> Helper loaded: form_helper
INFO - 2025-05-24 17:17:35 --> Database Driver Class Initialized
DEBUG - 2025-05-24 17:17:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 17:17:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 17:17:35 --> Controller Class Initialized
INFO - 2025-05-24 17:17:35 --> Model "User_model" initialized
INFO - 2025-05-24 17:17:35 --> Model "Workout_model" initialized
ERROR - 2025-05-24 17:17:35 --> Severity: Warning --> Undefined property: Dashboard::$Progress_model C:\laragon\www\Project\fitnessrecord\application\controllers\Dashboard.php 57
ERROR - 2025-05-24 17:17:35 --> Severity: error --> Exception: Call to a member function get_weekly_summary_by_user() on null C:\laragon\www\Project\fitnessrecord\application\controllers\Dashboard.php 57
INFO - 2025-05-24 17:26:06 --> Config Class Initialized
INFO - 2025-05-24 17:26:06 --> Hooks Class Initialized
DEBUG - 2025-05-24 17:26:06 --> UTF-8 Support Enabled
INFO - 2025-05-24 17:26:06 --> Utf8 Class Initialized
INFO - 2025-05-24 17:26:06 --> URI Class Initialized
INFO - 2025-05-24 17:26:06 --> Router Class Initialized
INFO - 2025-05-24 17:26:06 --> Output Class Initialized
INFO - 2025-05-24 17:26:06 --> Security Class Initialized
DEBUG - 2025-05-24 17:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 17:26:06 --> Input Class Initialized
INFO - 2025-05-24 17:26:06 --> Language Class Initialized
INFO - 2025-05-24 17:26:06 --> Loader Class Initialized
INFO - 2025-05-24 17:26:06 --> Helper loaded: url_helper
INFO - 2025-05-24 17:26:06 --> Helper loaded: form_helper
INFO - 2025-05-24 17:26:06 --> Database Driver Class Initialized
DEBUG - 2025-05-24 17:26:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 17:26:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 17:26:06 --> Controller Class Initialized
INFO - 2025-05-24 17:26:06 --> Model "User_model" initialized
INFO - 2025-05-24 17:26:06 --> Model "Workout_model" initialized
INFO - 2025-05-24 17:26:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 17:26:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 17:26:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-24 17:26:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 17:26:06 --> Final output sent to browser
DEBUG - 2025-05-24 17:26:06 --> Total execution time: 0.0797
INFO - 2025-05-24 17:26:06 --> Config Class Initialized
INFO - 2025-05-24 17:26:06 --> Hooks Class Initialized
DEBUG - 2025-05-24 17:26:06 --> UTF-8 Support Enabled
INFO - 2025-05-24 17:26:06 --> Utf8 Class Initialized
INFO - 2025-05-24 17:26:06 --> URI Class Initialized
INFO - 2025-05-24 17:26:06 --> Router Class Initialized
INFO - 2025-05-24 17:26:06 --> Output Class Initialized
INFO - 2025-05-24 17:26:06 --> Security Class Initialized
DEBUG - 2025-05-24 17:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 17:26:06 --> Input Class Initialized
INFO - 2025-05-24 17:26:06 --> Language Class Initialized
ERROR - 2025-05-24 17:26:06 --> 404 Page Not Found: Dashboard/get_weekly_summary
INFO - 2025-05-24 17:26:31 --> Config Class Initialized
INFO - 2025-05-24 17:26:31 --> Hooks Class Initialized
DEBUG - 2025-05-24 17:26:31 --> UTF-8 Support Enabled
INFO - 2025-05-24 17:26:31 --> Utf8 Class Initialized
INFO - 2025-05-24 17:26:31 --> URI Class Initialized
INFO - 2025-05-24 17:26:31 --> Router Class Initialized
INFO - 2025-05-24 17:26:31 --> Output Class Initialized
INFO - 2025-05-24 17:26:31 --> Security Class Initialized
DEBUG - 2025-05-24 17:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 17:26:31 --> Input Class Initialized
INFO - 2025-05-24 17:26:31 --> Language Class Initialized
INFO - 2025-05-24 17:26:31 --> Loader Class Initialized
INFO - 2025-05-24 17:26:31 --> Helper loaded: url_helper
INFO - 2025-05-24 17:26:31 --> Helper loaded: form_helper
INFO - 2025-05-24 17:26:31 --> Database Driver Class Initialized
DEBUG - 2025-05-24 17:26:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 17:26:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 17:26:31 --> Controller Class Initialized
INFO - 2025-05-24 17:26:31 --> Model "User_model" initialized
INFO - 2025-05-24 17:26:31 --> Model "Workout_model" initialized
INFO - 2025-05-24 17:26:31 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 17:26:31 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 17:26:31 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-24 17:26:31 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 17:26:31 --> Final output sent to browser
DEBUG - 2025-05-24 17:26:31 --> Total execution time: 0.0859
INFO - 2025-05-24 17:28:22 --> Config Class Initialized
INFO - 2025-05-24 17:28:22 --> Hooks Class Initialized
DEBUG - 2025-05-24 17:28:22 --> UTF-8 Support Enabled
INFO - 2025-05-24 17:28:22 --> Utf8 Class Initialized
INFO - 2025-05-24 17:28:22 --> URI Class Initialized
INFO - 2025-05-24 17:28:22 --> Router Class Initialized
INFO - 2025-05-24 17:28:22 --> Output Class Initialized
INFO - 2025-05-24 17:28:22 --> Security Class Initialized
DEBUG - 2025-05-24 17:28:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 17:28:22 --> Input Class Initialized
INFO - 2025-05-24 17:28:22 --> Language Class Initialized
INFO - 2025-05-24 17:28:22 --> Loader Class Initialized
INFO - 2025-05-24 17:28:22 --> Helper loaded: url_helper
INFO - 2025-05-24 17:28:22 --> Helper loaded: form_helper
INFO - 2025-05-24 17:28:22 --> Database Driver Class Initialized
DEBUG - 2025-05-24 17:28:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 17:28:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 17:28:22 --> Controller Class Initialized
INFO - 2025-05-24 17:28:22 --> Model "User_model" initialized
INFO - 2025-05-24 17:28:22 --> Model "Workout_model" initialized
INFO - 2025-05-24 17:28:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 17:28:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
ERROR - 2025-05-24 17:28:22 --> Severity: Warning --> Undefined variable $labels C:\laragon\www\Project\fitnessrecord\application\views\dashboard\dashboard.php 139
ERROR - 2025-05-24 17:28:22 --> Severity: Warning --> Undefined variable $latihan C:\laragon\www\Project\fitnessrecord\application\views\dashboard\dashboard.php 140
ERROR - 2025-05-24 17:28:22 --> Severity: Warning --> Undefined variable $kalori C:\laragon\www\Project\fitnessrecord\application\views\dashboard\dashboard.php 141
INFO - 2025-05-24 17:28:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-24 17:28:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 17:28:22 --> Final output sent to browser
DEBUG - 2025-05-24 17:28:22 --> Total execution time: 0.0975
INFO - 2025-05-24 17:30:25 --> Config Class Initialized
INFO - 2025-05-24 17:30:25 --> Hooks Class Initialized
DEBUG - 2025-05-24 17:30:25 --> UTF-8 Support Enabled
INFO - 2025-05-24 17:30:25 --> Utf8 Class Initialized
INFO - 2025-05-24 17:30:25 --> URI Class Initialized
INFO - 2025-05-24 17:30:25 --> Router Class Initialized
INFO - 2025-05-24 17:30:25 --> Output Class Initialized
INFO - 2025-05-24 17:30:25 --> Security Class Initialized
DEBUG - 2025-05-24 17:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 17:30:25 --> Input Class Initialized
INFO - 2025-05-24 17:30:25 --> Language Class Initialized
INFO - 2025-05-24 17:30:25 --> Loader Class Initialized
INFO - 2025-05-24 17:30:25 --> Helper loaded: url_helper
INFO - 2025-05-24 17:30:25 --> Helper loaded: form_helper
INFO - 2025-05-24 17:30:25 --> Database Driver Class Initialized
DEBUG - 2025-05-24 17:30:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 17:30:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 17:30:25 --> Controller Class Initialized
INFO - 2025-05-24 17:30:25 --> Model "User_model" initialized
INFO - 2025-05-24 17:30:25 --> Model "Workout_model" initialized
INFO - 2025-05-24 17:30:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 17:30:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
ERROR - 2025-05-24 17:30:25 --> Severity: Warning --> Undefined variable $labels C:\laragon\www\Project\fitnessrecord\application\views\dashboard\dashboard.php 139
ERROR - 2025-05-24 17:30:25 --> Severity: Warning --> Undefined variable $latihan C:\laragon\www\Project\fitnessrecord\application\views\dashboard\dashboard.php 140
ERROR - 2025-05-24 17:30:25 --> Severity: Warning --> Undefined variable $kalori C:\laragon\www\Project\fitnessrecord\application\views\dashboard\dashboard.php 141
INFO - 2025-05-24 17:30:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-24 17:30:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 17:30:25 --> Final output sent to browser
DEBUG - 2025-05-24 17:30:25 --> Total execution time: 0.0956
INFO - 2025-05-24 17:30:29 --> Config Class Initialized
INFO - 2025-05-24 17:30:29 --> Hooks Class Initialized
DEBUG - 2025-05-24 17:30:29 --> UTF-8 Support Enabled
INFO - 2025-05-24 17:30:29 --> Utf8 Class Initialized
INFO - 2025-05-24 17:30:29 --> URI Class Initialized
INFO - 2025-05-24 17:30:29 --> Router Class Initialized
INFO - 2025-05-24 17:30:29 --> Output Class Initialized
INFO - 2025-05-24 17:30:29 --> Security Class Initialized
DEBUG - 2025-05-24 17:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 17:30:29 --> Input Class Initialized
INFO - 2025-05-24 17:30:29 --> Language Class Initialized
INFO - 2025-05-24 17:30:29 --> Loader Class Initialized
INFO - 2025-05-24 17:30:29 --> Helper loaded: url_helper
INFO - 2025-05-24 17:30:29 --> Helper loaded: form_helper
INFO - 2025-05-24 17:30:29 --> Database Driver Class Initialized
DEBUG - 2025-05-24 17:30:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 17:30:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 17:30:29 --> Controller Class Initialized
INFO - 2025-05-24 17:30:29 --> Model "Progress_model" initialized
INFO - 2025-05-24 17:30:29 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 17:30:29 --> Model "User_model" initialized
INFO - 2025-05-24 17:30:29 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 17:30:29 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-24 17:30:29 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/progress_view.php
INFO - 2025-05-24 17:30:29 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 17:30:29 --> Final output sent to browser
DEBUG - 2025-05-24 17:30:29 --> Total execution time: 0.0668
INFO - 2025-05-24 17:30:30 --> Config Class Initialized
INFO - 2025-05-24 17:30:30 --> Hooks Class Initialized
DEBUG - 2025-05-24 17:30:30 --> UTF-8 Support Enabled
INFO - 2025-05-24 17:30:30 --> Utf8 Class Initialized
INFO - 2025-05-24 17:30:30 --> URI Class Initialized
INFO - 2025-05-24 17:30:30 --> Router Class Initialized
INFO - 2025-05-24 17:30:30 --> Output Class Initialized
INFO - 2025-05-24 17:30:30 --> Security Class Initialized
DEBUG - 2025-05-24 17:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 17:30:30 --> Input Class Initialized
INFO - 2025-05-24 17:30:30 --> Language Class Initialized
INFO - 2025-05-24 17:30:30 --> Loader Class Initialized
INFO - 2025-05-24 17:30:30 --> Helper loaded: url_helper
INFO - 2025-05-24 17:30:30 --> Helper loaded: form_helper
INFO - 2025-05-24 17:30:30 --> Database Driver Class Initialized
DEBUG - 2025-05-24 17:30:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 17:30:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 17:30:30 --> Controller Class Initialized
INFO - 2025-05-24 17:30:30 --> Model "Progress_model" initialized
INFO - 2025-05-24 17:30:30 --> Model "Olahraga_model" initialized
INFO - 2025-05-24 17:30:30 --> Model "User_model" initialized
INFO - 2025-05-24 17:30:30 --> Final output sent to browser
DEBUG - 2025-05-24 17:30:30 --> Total execution time: 0.0678
INFO - 2025-05-24 17:30:33 --> Config Class Initialized
INFO - 2025-05-24 17:30:33 --> Hooks Class Initialized
DEBUG - 2025-05-24 17:30:33 --> UTF-8 Support Enabled
INFO - 2025-05-24 17:30:33 --> Utf8 Class Initialized
INFO - 2025-05-24 17:30:33 --> URI Class Initialized
INFO - 2025-05-24 17:30:33 --> Router Class Initialized
INFO - 2025-05-24 17:30:33 --> Output Class Initialized
INFO - 2025-05-24 17:30:33 --> Security Class Initialized
DEBUG - 2025-05-24 17:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 17:30:33 --> Input Class Initialized
INFO - 2025-05-24 17:30:33 --> Language Class Initialized
INFO - 2025-05-24 17:30:33 --> Loader Class Initialized
INFO - 2025-05-24 17:30:33 --> Helper loaded: url_helper
INFO - 2025-05-24 17:30:33 --> Helper loaded: form_helper
INFO - 2025-05-24 17:30:34 --> Database Driver Class Initialized
DEBUG - 2025-05-24 17:30:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 17:30:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 17:30:34 --> Controller Class Initialized
INFO - 2025-05-24 17:30:34 --> Model "User_model" initialized
INFO - 2025-05-24 17:30:34 --> Model "Workout_model" initialized
INFO - 2025-05-24 17:30:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 17:30:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
ERROR - 2025-05-24 17:30:34 --> Severity: Warning --> Undefined variable $labels C:\laragon\www\Project\fitnessrecord\application\views\dashboard\dashboard.php 139
ERROR - 2025-05-24 17:30:34 --> Severity: Warning --> Undefined variable $latihan C:\laragon\www\Project\fitnessrecord\application\views\dashboard\dashboard.php 140
ERROR - 2025-05-24 17:30:34 --> Severity: Warning --> Undefined variable $kalori C:\laragon\www\Project\fitnessrecord\application\views\dashboard\dashboard.php 141
INFO - 2025-05-24 17:30:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-24 17:30:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 17:30:34 --> Final output sent to browser
DEBUG - 2025-05-24 17:30:34 --> Total execution time: 0.0880
INFO - 2025-05-24 17:32:28 --> Config Class Initialized
INFO - 2025-05-24 17:32:28 --> Hooks Class Initialized
DEBUG - 2025-05-24 17:32:28 --> UTF-8 Support Enabled
INFO - 2025-05-24 17:32:28 --> Utf8 Class Initialized
INFO - 2025-05-24 17:32:28 --> URI Class Initialized
INFO - 2025-05-24 17:32:28 --> Router Class Initialized
INFO - 2025-05-24 17:32:28 --> Output Class Initialized
INFO - 2025-05-24 17:32:28 --> Security Class Initialized
DEBUG - 2025-05-24 17:32:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 17:32:28 --> Input Class Initialized
INFO - 2025-05-24 17:32:28 --> Language Class Initialized
INFO - 2025-05-24 17:32:28 --> Loader Class Initialized
INFO - 2025-05-24 17:32:28 --> Helper loaded: url_helper
INFO - 2025-05-24 17:32:28 --> Helper loaded: form_helper
INFO - 2025-05-24 17:32:28 --> Database Driver Class Initialized
DEBUG - 2025-05-24 17:32:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 17:32:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 17:32:28 --> Controller Class Initialized
INFO - 2025-05-24 17:32:28 --> Model "User_model" initialized
INFO - 2025-05-24 17:32:28 --> Model "Workout_model" initialized
INFO - 2025-05-24 17:32:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 17:32:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
ERROR - 2025-05-24 17:32:28 --> Severity: Warning --> Undefined variable $labels C:\laragon\www\Project\fitnessrecord\application\views\dashboard\dashboard.php 139
ERROR - 2025-05-24 17:32:28 --> Severity: Warning --> Undefined variable $latihan C:\laragon\www\Project\fitnessrecord\application\views\dashboard\dashboard.php 140
ERROR - 2025-05-24 17:32:28 --> Severity: Warning --> Undefined variable $kalori C:\laragon\www\Project\fitnessrecord\application\views\dashboard\dashboard.php 141
INFO - 2025-05-24 17:32:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-24 17:32:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 17:32:28 --> Final output sent to browser
DEBUG - 2025-05-24 17:32:28 --> Total execution time: 0.0985
INFO - 2025-05-24 17:34:38 --> Config Class Initialized
INFO - 2025-05-24 17:34:38 --> Hooks Class Initialized
DEBUG - 2025-05-24 17:34:38 --> UTF-8 Support Enabled
INFO - 2025-05-24 17:34:38 --> Utf8 Class Initialized
INFO - 2025-05-24 17:34:38 --> URI Class Initialized
INFO - 2025-05-24 17:34:38 --> Router Class Initialized
INFO - 2025-05-24 17:34:38 --> Output Class Initialized
INFO - 2025-05-24 17:34:38 --> Security Class Initialized
DEBUG - 2025-05-24 17:34:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-24 17:34:38 --> Input Class Initialized
INFO - 2025-05-24 17:34:38 --> Language Class Initialized
INFO - 2025-05-24 17:34:38 --> Loader Class Initialized
INFO - 2025-05-24 17:34:38 --> Helper loaded: url_helper
INFO - 2025-05-24 17:34:38 --> Helper loaded: form_helper
INFO - 2025-05-24 17:34:38 --> Database Driver Class Initialized
DEBUG - 2025-05-24 17:34:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-24 17:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-24 17:34:38 --> Controller Class Initialized
INFO - 2025-05-24 17:34:38 --> Model "User_model" initialized
INFO - 2025-05-24 17:34:38 --> Model "Workout_model" initialized
INFO - 2025-05-24 17:34:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-24 17:34:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
ERROR - 2025-05-24 17:34:38 --> Severity: Warning --> Undefined variable $labels C:\laragon\www\Project\fitnessrecord\application\views\dashboard\dashboard.php 135
ERROR - 2025-05-24 17:34:38 --> Severity: Warning --> Undefined variable $latihan C:\laragon\www\Project\fitnessrecord\application\views\dashboard\dashboard.php 136
ERROR - 2025-05-24 17:34:38 --> Severity: Warning --> Undefined variable $kalori C:\laragon\www\Project\fitnessrecord\application\views\dashboard\dashboard.php 137
INFO - 2025-05-24 17:34:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-24 17:34:38 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-24 17:34:38 --> Final output sent to browser
DEBUG - 2025-05-24 17:34:38 --> Total execution time: 0.0923
