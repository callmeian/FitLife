<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-05-10 14:56:53 --> Config Class Initialized
INFO - 2025-05-10 14:56:53 --> Hooks Class Initialized
DEBUG - 2025-05-10 14:56:53 --> UTF-8 Support Enabled
INFO - 2025-05-10 14:56:53 --> Utf8 Class Initialized
INFO - 2025-05-10 14:56:53 --> URI Class Initialized
INFO - 2025-05-10 14:56:53 --> Router Class Initialized
INFO - 2025-05-10 14:56:53 --> Output Class Initialized
INFO - 2025-05-10 14:56:53 --> Security Class Initialized
DEBUG - 2025-05-10 14:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 14:56:53 --> Input Class Initialized
INFO - 2025-05-10 14:56:53 --> Language Class Initialized
INFO - 2025-05-10 14:56:53 --> Loader Class Initialized
INFO - 2025-05-10 14:56:53 --> Helper loaded: url_helper
INFO - 2025-05-10 14:56:53 --> Helper loaded: form_helper
INFO - 2025-05-10 14:56:53 --> Database Driver Class Initialized
DEBUG - 2025-05-10 14:56:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 14:56:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 14:56:53 --> Controller Class Initialized
INFO - 2025-05-10 14:56:53 --> Model "Workout_model" initialized
INFO - 2025-05-10 14:56:53 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-10 14:56:53 --> Final output sent to browser
DEBUG - 2025-05-10 14:56:53 --> Total execution time: 0.0927
INFO - 2025-05-10 14:56:54 --> Config Class Initialized
INFO - 2025-05-10 14:56:54 --> Hooks Class Initialized
DEBUG - 2025-05-10 14:56:54 --> UTF-8 Support Enabled
INFO - 2025-05-10 14:56:54 --> Utf8 Class Initialized
INFO - 2025-05-10 14:56:54 --> URI Class Initialized
INFO - 2025-05-10 14:56:54 --> Router Class Initialized
INFO - 2025-05-10 14:56:54 --> Output Class Initialized
INFO - 2025-05-10 14:56:54 --> Security Class Initialized
DEBUG - 2025-05-10 14:56:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 14:56:54 --> Input Class Initialized
INFO - 2025-05-10 14:56:54 --> Language Class Initialized
INFO - 2025-05-10 14:56:54 --> Loader Class Initialized
INFO - 2025-05-10 14:56:54 --> Helper loaded: url_helper
INFO - 2025-05-10 14:56:54 --> Helper loaded: form_helper
INFO - 2025-05-10 14:56:54 --> Database Driver Class Initialized
DEBUG - 2025-05-10 14:56:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 14:56:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 14:56:54 --> Controller Class Initialized
INFO - 2025-05-10 14:56:54 --> Model "Workout_model" initialized
INFO - 2025-05-10 14:56:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-10 14:56:54 --> Final output sent to browser
DEBUG - 2025-05-10 14:56:54 --> Total execution time: 0.0794
INFO - 2025-05-10 14:56:56 --> Config Class Initialized
INFO - 2025-05-10 14:56:56 --> Hooks Class Initialized
DEBUG - 2025-05-10 14:56:56 --> UTF-8 Support Enabled
INFO - 2025-05-10 14:56:56 --> Utf8 Class Initialized
INFO - 2025-05-10 14:56:56 --> URI Class Initialized
INFO - 2025-05-10 14:56:56 --> Router Class Initialized
INFO - 2025-05-10 14:56:56 --> Output Class Initialized
INFO - 2025-05-10 14:56:56 --> Security Class Initialized
DEBUG - 2025-05-10 14:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 14:56:56 --> Input Class Initialized
INFO - 2025-05-10 14:56:56 --> Language Class Initialized
INFO - 2025-05-10 14:56:56 --> Loader Class Initialized
INFO - 2025-05-10 14:56:56 --> Helper loaded: url_helper
INFO - 2025-05-10 14:56:56 --> Helper loaded: form_helper
INFO - 2025-05-10 14:56:56 --> Database Driver Class Initialized
DEBUG - 2025-05-10 14:56:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 14:56:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 14:56:56 --> Controller Class Initialized
INFO - 2025-05-10 14:56:56 --> Model "Workout_model" initialized
INFO - 2025-05-10 14:56:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/start.php
INFO - 2025-05-10 14:56:56 --> Final output sent to browser
DEBUG - 2025-05-10 14:56:56 --> Total execution time: 0.0819
INFO - 2025-05-10 14:57:01 --> Config Class Initialized
INFO - 2025-05-10 14:57:01 --> Hooks Class Initialized
DEBUG - 2025-05-10 14:57:01 --> UTF-8 Support Enabled
INFO - 2025-05-10 14:57:01 --> Utf8 Class Initialized
INFO - 2025-05-10 14:57:01 --> URI Class Initialized
INFO - 2025-05-10 14:57:01 --> Router Class Initialized
INFO - 2025-05-10 14:57:01 --> Output Class Initialized
INFO - 2025-05-10 14:57:01 --> Security Class Initialized
DEBUG - 2025-05-10 14:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 14:57:01 --> Input Class Initialized
INFO - 2025-05-10 14:57:01 --> Language Class Initialized
INFO - 2025-05-10 14:57:01 --> Loader Class Initialized
INFO - 2025-05-10 14:57:01 --> Helper loaded: url_helper
INFO - 2025-05-10 14:57:01 --> Helper loaded: form_helper
INFO - 2025-05-10 14:57:01 --> Database Driver Class Initialized
DEBUG - 2025-05-10 14:57:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 14:57:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 14:57:01 --> Controller Class Initialized
INFO - 2025-05-10 14:57:01 --> Model "Workout_model" initialized
ERROR - 2025-05-10 14:57:01 --> Query error: Unknown column 'level' in 'field list' - Invalid query: INSERT INTO `workout_records` (`user_id`, `schedule_id`, `activity`, `level`, `duration_minutes`, `start_time`, `end_time`) VALUES ('1', '6', 'Pull Up', 'Pemula', '1', '2025-05-10 14:56:56', '2025-05-10 14:57:01')
INFO - 2025-05-10 14:57:01 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-10 14:57:47 --> Config Class Initialized
INFO - 2025-05-10 14:57:47 --> Hooks Class Initialized
DEBUG - 2025-05-10 14:57:47 --> UTF-8 Support Enabled
INFO - 2025-05-10 14:57:47 --> Utf8 Class Initialized
INFO - 2025-05-10 14:57:47 --> URI Class Initialized
INFO - 2025-05-10 14:57:47 --> Router Class Initialized
INFO - 2025-05-10 14:57:47 --> Output Class Initialized
INFO - 2025-05-10 14:57:47 --> Security Class Initialized
DEBUG - 2025-05-10 14:57:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 14:57:47 --> Input Class Initialized
INFO - 2025-05-10 14:57:47 --> Language Class Initialized
INFO - 2025-05-10 14:57:47 --> Loader Class Initialized
INFO - 2025-05-10 14:57:47 --> Helper loaded: url_helper
INFO - 2025-05-10 14:57:47 --> Helper loaded: form_helper
INFO - 2025-05-10 14:57:47 --> Database Driver Class Initialized
DEBUG - 2025-05-10 14:57:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 14:57:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 14:57:47 --> Controller Class Initialized
INFO - 2025-05-10 14:57:47 --> Model "Workout_model" initialized
INFO - 2025-05-10 14:57:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/add.php
INFO - 2025-05-10 14:57:47 --> Final output sent to browser
DEBUG - 2025-05-10 14:57:47 --> Total execution time: 0.0679
INFO - 2025-05-10 14:57:59 --> Config Class Initialized
INFO - 2025-05-10 14:57:59 --> Hooks Class Initialized
DEBUG - 2025-05-10 14:57:59 --> UTF-8 Support Enabled
INFO - 2025-05-10 14:57:59 --> Utf8 Class Initialized
INFO - 2025-05-10 14:57:59 --> URI Class Initialized
INFO - 2025-05-10 14:57:59 --> Router Class Initialized
INFO - 2025-05-10 14:57:59 --> Output Class Initialized
INFO - 2025-05-10 14:57:59 --> Security Class Initialized
DEBUG - 2025-05-10 14:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 14:57:59 --> Input Class Initialized
INFO - 2025-05-10 14:57:59 --> Language Class Initialized
INFO - 2025-05-10 14:57:59 --> Loader Class Initialized
INFO - 2025-05-10 14:57:59 --> Helper loaded: url_helper
INFO - 2025-05-10 14:57:59 --> Helper loaded: form_helper
INFO - 2025-05-10 14:57:59 --> Database Driver Class Initialized
DEBUG - 2025-05-10 14:57:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 14:57:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 14:57:59 --> Controller Class Initialized
INFO - 2025-05-10 14:57:59 --> Model "Workout_model" initialized
INFO - 2025-05-10 14:57:59 --> Config Class Initialized
INFO - 2025-05-10 14:57:59 --> Hooks Class Initialized
DEBUG - 2025-05-10 14:57:59 --> UTF-8 Support Enabled
INFO - 2025-05-10 14:57:59 --> Utf8 Class Initialized
INFO - 2025-05-10 14:57:59 --> URI Class Initialized
INFO - 2025-05-10 14:57:59 --> Router Class Initialized
INFO - 2025-05-10 14:57:59 --> Output Class Initialized
INFO - 2025-05-10 14:57:59 --> Security Class Initialized
DEBUG - 2025-05-10 14:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 14:57:59 --> Input Class Initialized
INFO - 2025-05-10 14:57:59 --> Language Class Initialized
INFO - 2025-05-10 14:57:59 --> Loader Class Initialized
INFO - 2025-05-10 14:57:59 --> Helper loaded: url_helper
INFO - 2025-05-10 14:57:59 --> Helper loaded: form_helper
INFO - 2025-05-10 14:57:59 --> Database Driver Class Initialized
DEBUG - 2025-05-10 14:57:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 14:57:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 14:57:59 --> Controller Class Initialized
INFO - 2025-05-10 14:57:59 --> Model "Workout_model" initialized
INFO - 2025-05-10 14:57:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-10 14:57:59 --> Final output sent to browser
DEBUG - 2025-05-10 14:57:59 --> Total execution time: 0.0829
INFO - 2025-05-10 14:58:02 --> Config Class Initialized
INFO - 2025-05-10 14:58:02 --> Hooks Class Initialized
DEBUG - 2025-05-10 14:58:02 --> UTF-8 Support Enabled
INFO - 2025-05-10 14:58:02 --> Utf8 Class Initialized
INFO - 2025-05-10 14:58:02 --> URI Class Initialized
INFO - 2025-05-10 14:58:02 --> Router Class Initialized
INFO - 2025-05-10 14:58:02 --> Output Class Initialized
INFO - 2025-05-10 14:58:02 --> Security Class Initialized
DEBUG - 2025-05-10 14:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 14:58:02 --> Input Class Initialized
INFO - 2025-05-10 14:58:02 --> Language Class Initialized
INFO - 2025-05-10 14:58:02 --> Loader Class Initialized
INFO - 2025-05-10 14:58:02 --> Helper loaded: url_helper
INFO - 2025-05-10 14:58:02 --> Helper loaded: form_helper
INFO - 2025-05-10 14:58:02 --> Database Driver Class Initialized
DEBUG - 2025-05-10 14:58:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 14:58:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 14:58:02 --> Controller Class Initialized
INFO - 2025-05-10 14:58:02 --> Model "Workout_model" initialized
INFO - 2025-05-10 14:58:02 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/start.php
INFO - 2025-05-10 14:58:02 --> Final output sent to browser
DEBUG - 2025-05-10 14:58:02 --> Total execution time: 0.0697
INFO - 2025-05-10 14:58:08 --> Config Class Initialized
INFO - 2025-05-10 14:58:08 --> Hooks Class Initialized
DEBUG - 2025-05-10 14:58:08 --> UTF-8 Support Enabled
INFO - 2025-05-10 14:58:08 --> Utf8 Class Initialized
INFO - 2025-05-10 14:58:08 --> URI Class Initialized
INFO - 2025-05-10 14:58:08 --> Router Class Initialized
INFO - 2025-05-10 14:58:08 --> Output Class Initialized
INFO - 2025-05-10 14:58:08 --> Security Class Initialized
DEBUG - 2025-05-10 14:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 14:58:08 --> Input Class Initialized
INFO - 2025-05-10 14:58:08 --> Language Class Initialized
INFO - 2025-05-10 14:58:08 --> Loader Class Initialized
INFO - 2025-05-10 14:58:08 --> Helper loaded: url_helper
INFO - 2025-05-10 14:58:08 --> Helper loaded: form_helper
INFO - 2025-05-10 14:58:08 --> Database Driver Class Initialized
DEBUG - 2025-05-10 14:58:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 14:58:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 14:58:08 --> Controller Class Initialized
INFO - 2025-05-10 14:58:08 --> Model "Workout_model" initialized
ERROR - 2025-05-10 14:58:08 --> Query error: Unknown column 'level' in 'field list' - Invalid query: INSERT INTO `workout_records` (`user_id`, `schedule_id`, `activity`, `level`, `duration_minutes`, `start_time`, `end_time`) VALUES ('1', '7', 'Jogging', 'Pemula', '1', '2025-05-10 14:58:02', '2025-05-10 14:58:08')
INFO - 2025-05-10 14:58:08 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-10 15:07:13 --> Config Class Initialized
INFO - 2025-05-10 15:07:13 --> Hooks Class Initialized
DEBUG - 2025-05-10 15:07:13 --> UTF-8 Support Enabled
INFO - 2025-05-10 15:07:13 --> Utf8 Class Initialized
INFO - 2025-05-10 15:07:13 --> URI Class Initialized
INFO - 2025-05-10 15:07:13 --> Router Class Initialized
INFO - 2025-05-10 15:07:13 --> Output Class Initialized
INFO - 2025-05-10 15:07:13 --> Security Class Initialized
DEBUG - 2025-05-10 15:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 15:07:13 --> Input Class Initialized
INFO - 2025-05-10 15:07:13 --> Language Class Initialized
INFO - 2025-05-10 15:07:13 --> Loader Class Initialized
INFO - 2025-05-10 15:07:13 --> Helper loaded: url_helper
INFO - 2025-05-10 15:07:13 --> Helper loaded: form_helper
INFO - 2025-05-10 15:07:13 --> Database Driver Class Initialized
DEBUG - 2025-05-10 15:07:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 15:07:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 15:07:13 --> Controller Class Initialized
INFO - 2025-05-10 15:07:13 --> Model "Workout_model" initialized
INFO - 2025-05-10 15:07:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/start.php
INFO - 2025-05-10 15:07:13 --> Final output sent to browser
DEBUG - 2025-05-10 15:07:13 --> Total execution time: 0.0880
INFO - 2025-05-10 15:07:17 --> Config Class Initialized
INFO - 2025-05-10 15:07:17 --> Hooks Class Initialized
DEBUG - 2025-05-10 15:07:17 --> UTF-8 Support Enabled
INFO - 2025-05-10 15:07:17 --> Utf8 Class Initialized
INFO - 2025-05-10 15:07:17 --> URI Class Initialized
INFO - 2025-05-10 15:07:17 --> Router Class Initialized
INFO - 2025-05-10 15:07:17 --> Output Class Initialized
INFO - 2025-05-10 15:07:17 --> Security Class Initialized
DEBUG - 2025-05-10 15:07:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 15:07:17 --> Input Class Initialized
INFO - 2025-05-10 15:07:17 --> Language Class Initialized
INFO - 2025-05-10 15:07:17 --> Loader Class Initialized
INFO - 2025-05-10 15:07:17 --> Helper loaded: url_helper
INFO - 2025-05-10 15:07:17 --> Helper loaded: form_helper
INFO - 2025-05-10 15:07:17 --> Database Driver Class Initialized
DEBUG - 2025-05-10 15:07:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 15:07:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 15:07:17 --> Controller Class Initialized
INFO - 2025-05-10 15:07:17 --> Model "Workout_model" initialized
INFO - 2025-05-10 15:07:17 --> Final output sent to browser
DEBUG - 2025-05-10 15:07:17 --> Total execution time: 0.0759
INFO - 2025-05-10 15:07:19 --> Config Class Initialized
INFO - 2025-05-10 15:07:19 --> Hooks Class Initialized
DEBUG - 2025-05-10 15:07:19 --> UTF-8 Support Enabled
INFO - 2025-05-10 15:07:19 --> Utf8 Class Initialized
INFO - 2025-05-10 15:07:19 --> URI Class Initialized
INFO - 2025-05-10 15:07:19 --> Router Class Initialized
INFO - 2025-05-10 15:07:19 --> Output Class Initialized
INFO - 2025-05-10 15:07:19 --> Security Class Initialized
DEBUG - 2025-05-10 15:07:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 15:07:19 --> Input Class Initialized
INFO - 2025-05-10 15:07:19 --> Language Class Initialized
INFO - 2025-05-10 15:07:19 --> Loader Class Initialized
INFO - 2025-05-10 15:07:19 --> Helper loaded: url_helper
INFO - 2025-05-10 15:07:19 --> Helper loaded: form_helper
INFO - 2025-05-10 15:07:19 --> Database Driver Class Initialized
DEBUG - 2025-05-10 15:07:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 15:07:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 15:07:19 --> Controller Class Initialized
INFO - 2025-05-10 15:07:19 --> Model "Workout_model" initialized
INFO - 2025-05-10 15:07:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-10 15:07:19 --> Final output sent to browser
DEBUG - 2025-05-10 15:07:19 --> Total execution time: 0.0765
INFO - 2025-05-10 15:07:21 --> Config Class Initialized
INFO - 2025-05-10 15:07:21 --> Hooks Class Initialized
DEBUG - 2025-05-10 15:07:21 --> UTF-8 Support Enabled
INFO - 2025-05-10 15:07:21 --> Utf8 Class Initialized
INFO - 2025-05-10 15:07:21 --> URI Class Initialized
INFO - 2025-05-10 15:07:21 --> Router Class Initialized
INFO - 2025-05-10 15:07:21 --> Output Class Initialized
INFO - 2025-05-10 15:07:21 --> Security Class Initialized
DEBUG - 2025-05-10 15:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 15:07:21 --> Input Class Initialized
INFO - 2025-05-10 15:07:21 --> Language Class Initialized
INFO - 2025-05-10 15:07:21 --> Loader Class Initialized
INFO - 2025-05-10 15:07:21 --> Helper loaded: url_helper
INFO - 2025-05-10 15:07:21 --> Helper loaded: form_helper
INFO - 2025-05-10 15:07:21 --> Database Driver Class Initialized
DEBUG - 2025-05-10 15:07:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 15:07:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 15:07:21 --> Controller Class Initialized
INFO - 2025-05-10 15:07:21 --> Model "Workout_model" initialized
INFO - 2025-05-10 15:07:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-10 15:07:21 --> Final output sent to browser
DEBUG - 2025-05-10 15:07:21 --> Total execution time: 0.0728
INFO - 2025-05-10 15:07:22 --> Config Class Initialized
INFO - 2025-05-10 15:07:22 --> Hooks Class Initialized
DEBUG - 2025-05-10 15:07:22 --> UTF-8 Support Enabled
INFO - 2025-05-10 15:07:22 --> Utf8 Class Initialized
INFO - 2025-05-10 15:07:22 --> URI Class Initialized
INFO - 2025-05-10 15:07:22 --> Router Class Initialized
INFO - 2025-05-10 15:07:22 --> Output Class Initialized
INFO - 2025-05-10 15:07:22 --> Security Class Initialized
DEBUG - 2025-05-10 15:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 15:07:22 --> Input Class Initialized
INFO - 2025-05-10 15:07:22 --> Language Class Initialized
INFO - 2025-05-10 15:07:22 --> Loader Class Initialized
INFO - 2025-05-10 15:07:22 --> Helper loaded: url_helper
INFO - 2025-05-10 15:07:22 --> Helper loaded: form_helper
INFO - 2025-05-10 15:07:22 --> Database Driver Class Initialized
DEBUG - 2025-05-10 15:07:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 15:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 15:07:22 --> Controller Class Initialized
INFO - 2025-05-10 15:07:22 --> Model "Workout_model" initialized
INFO - 2025-05-10 15:07:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-10 15:07:22 --> Final output sent to browser
DEBUG - 2025-05-10 15:07:22 --> Total execution time: 0.0659
INFO - 2025-05-10 15:07:22 --> Config Class Initialized
INFO - 2025-05-10 15:07:22 --> Hooks Class Initialized
DEBUG - 2025-05-10 15:07:23 --> UTF-8 Support Enabled
INFO - 2025-05-10 15:07:23 --> Utf8 Class Initialized
INFO - 2025-05-10 15:07:23 --> URI Class Initialized
INFO - 2025-05-10 15:07:23 --> Router Class Initialized
INFO - 2025-05-10 15:07:23 --> Output Class Initialized
INFO - 2025-05-10 15:07:23 --> Security Class Initialized
DEBUG - 2025-05-10 15:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 15:07:23 --> Input Class Initialized
INFO - 2025-05-10 15:07:23 --> Language Class Initialized
INFO - 2025-05-10 15:07:23 --> Loader Class Initialized
INFO - 2025-05-10 15:07:23 --> Helper loaded: url_helper
INFO - 2025-05-10 15:07:23 --> Helper loaded: form_helper
INFO - 2025-05-10 15:07:23 --> Database Driver Class Initialized
DEBUG - 2025-05-10 15:07:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 15:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 15:07:23 --> Controller Class Initialized
INFO - 2025-05-10 15:07:23 --> Model "Workout_model" initialized
INFO - 2025-05-10 15:07:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-10 15:07:23 --> Final output sent to browser
DEBUG - 2025-05-10 15:07:23 --> Total execution time: 0.0636
INFO - 2025-05-10 15:07:23 --> Config Class Initialized
INFO - 2025-05-10 15:07:23 --> Hooks Class Initialized
DEBUG - 2025-05-10 15:07:23 --> UTF-8 Support Enabled
INFO - 2025-05-10 15:07:23 --> Utf8 Class Initialized
INFO - 2025-05-10 15:07:23 --> URI Class Initialized
INFO - 2025-05-10 15:07:23 --> Router Class Initialized
INFO - 2025-05-10 15:07:23 --> Output Class Initialized
INFO - 2025-05-10 15:07:23 --> Security Class Initialized
DEBUG - 2025-05-10 15:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 15:07:23 --> Input Class Initialized
INFO - 2025-05-10 15:07:23 --> Language Class Initialized
INFO - 2025-05-10 15:07:23 --> Loader Class Initialized
INFO - 2025-05-10 15:07:23 --> Helper loaded: url_helper
INFO - 2025-05-10 15:07:23 --> Helper loaded: form_helper
INFO - 2025-05-10 15:07:23 --> Database Driver Class Initialized
DEBUG - 2025-05-10 15:07:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 15:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 15:07:23 --> Controller Class Initialized
INFO - 2025-05-10 15:07:23 --> Model "Workout_model" initialized
INFO - 2025-05-10 15:07:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-10 15:07:23 --> Final output sent to browser
DEBUG - 2025-05-10 15:07:23 --> Total execution time: 0.0795
INFO - 2025-05-10 15:07:24 --> Config Class Initialized
INFO - 2025-05-10 15:07:24 --> Hooks Class Initialized
DEBUG - 2025-05-10 15:07:24 --> UTF-8 Support Enabled
INFO - 2025-05-10 15:07:24 --> Utf8 Class Initialized
INFO - 2025-05-10 15:07:24 --> URI Class Initialized
INFO - 2025-05-10 15:07:24 --> Router Class Initialized
INFO - 2025-05-10 15:07:24 --> Output Class Initialized
INFO - 2025-05-10 15:07:24 --> Security Class Initialized
DEBUG - 2025-05-10 15:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 15:07:24 --> Input Class Initialized
INFO - 2025-05-10 15:07:24 --> Language Class Initialized
INFO - 2025-05-10 15:07:24 --> Loader Class Initialized
INFO - 2025-05-10 15:07:24 --> Helper loaded: url_helper
INFO - 2025-05-10 15:07:24 --> Helper loaded: form_helper
INFO - 2025-05-10 15:07:24 --> Database Driver Class Initialized
DEBUG - 2025-05-10 15:07:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 15:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 15:07:24 --> Controller Class Initialized
INFO - 2025-05-10 15:07:24 --> Model "Workout_model" initialized
INFO - 2025-05-10 15:07:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-10 15:07:24 --> Final output sent to browser
DEBUG - 2025-05-10 15:07:24 --> Total execution time: 0.0692
INFO - 2025-05-10 15:07:24 --> Config Class Initialized
INFO - 2025-05-10 15:07:24 --> Hooks Class Initialized
DEBUG - 2025-05-10 15:07:24 --> UTF-8 Support Enabled
INFO - 2025-05-10 15:07:24 --> Utf8 Class Initialized
INFO - 2025-05-10 15:07:24 --> URI Class Initialized
INFO - 2025-05-10 15:07:24 --> Router Class Initialized
INFO - 2025-05-10 15:07:24 --> Output Class Initialized
INFO - 2025-05-10 15:07:24 --> Security Class Initialized
DEBUG - 2025-05-10 15:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 15:07:24 --> Input Class Initialized
INFO - 2025-05-10 15:07:24 --> Language Class Initialized
INFO - 2025-05-10 15:07:24 --> Loader Class Initialized
INFO - 2025-05-10 15:07:24 --> Helper loaded: url_helper
INFO - 2025-05-10 15:07:24 --> Helper loaded: form_helper
INFO - 2025-05-10 15:07:24 --> Database Driver Class Initialized
DEBUG - 2025-05-10 15:07:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 15:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 15:07:24 --> Controller Class Initialized
INFO - 2025-05-10 15:07:24 --> Model "Workout_model" initialized
INFO - 2025-05-10 15:07:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-10 15:07:24 --> Final output sent to browser
DEBUG - 2025-05-10 15:07:24 --> Total execution time: 0.0883
INFO - 2025-05-10 15:07:24 --> Config Class Initialized
INFO - 2025-05-10 15:07:24 --> Hooks Class Initialized
DEBUG - 2025-05-10 15:07:24 --> UTF-8 Support Enabled
INFO - 2025-05-10 15:07:24 --> Utf8 Class Initialized
INFO - 2025-05-10 15:07:24 --> URI Class Initialized
INFO - 2025-05-10 15:07:24 --> Router Class Initialized
INFO - 2025-05-10 15:07:24 --> Output Class Initialized
INFO - 2025-05-10 15:07:24 --> Security Class Initialized
DEBUG - 2025-05-10 15:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 15:07:24 --> Input Class Initialized
INFO - 2025-05-10 15:07:24 --> Language Class Initialized
INFO - 2025-05-10 15:07:24 --> Loader Class Initialized
INFO - 2025-05-10 15:07:24 --> Helper loaded: url_helper
INFO - 2025-05-10 15:07:24 --> Helper loaded: form_helper
INFO - 2025-05-10 15:07:24 --> Database Driver Class Initialized
DEBUG - 2025-05-10 15:07:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 15:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 15:07:24 --> Controller Class Initialized
INFO - 2025-05-10 15:07:24 --> Model "Workout_model" initialized
INFO - 2025-05-10 15:07:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-10 15:07:24 --> Final output sent to browser
DEBUG - 2025-05-10 15:07:24 --> Total execution time: 0.0773
INFO - 2025-05-10 15:07:24 --> Config Class Initialized
INFO - 2025-05-10 15:07:24 --> Hooks Class Initialized
DEBUG - 2025-05-10 15:07:24 --> UTF-8 Support Enabled
INFO - 2025-05-10 15:07:24 --> Utf8 Class Initialized
INFO - 2025-05-10 15:07:24 --> URI Class Initialized
INFO - 2025-05-10 15:07:24 --> Router Class Initialized
INFO - 2025-05-10 15:07:24 --> Output Class Initialized
INFO - 2025-05-10 15:07:24 --> Security Class Initialized
DEBUG - 2025-05-10 15:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 15:07:24 --> Input Class Initialized
INFO - 2025-05-10 15:07:24 --> Language Class Initialized
INFO - 2025-05-10 15:07:24 --> Loader Class Initialized
INFO - 2025-05-10 15:07:24 --> Helper loaded: url_helper
INFO - 2025-05-10 15:07:24 --> Helper loaded: form_helper
INFO - 2025-05-10 15:07:24 --> Database Driver Class Initialized
DEBUG - 2025-05-10 15:07:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 15:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 15:07:24 --> Controller Class Initialized
INFO - 2025-05-10 15:07:24 --> Model "Workout_model" initialized
INFO - 2025-05-10 15:07:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-10 15:07:24 --> Final output sent to browser
DEBUG - 2025-05-10 15:07:24 --> Total execution time: 0.0680
INFO - 2025-05-10 15:07:24 --> Config Class Initialized
INFO - 2025-05-10 15:07:24 --> Hooks Class Initialized
DEBUG - 2025-05-10 15:07:24 --> UTF-8 Support Enabled
INFO - 2025-05-10 15:07:24 --> Utf8 Class Initialized
INFO - 2025-05-10 15:07:24 --> URI Class Initialized
INFO - 2025-05-10 15:07:24 --> Router Class Initialized
INFO - 2025-05-10 15:07:24 --> Output Class Initialized
INFO - 2025-05-10 15:07:24 --> Security Class Initialized
DEBUG - 2025-05-10 15:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 15:07:24 --> Input Class Initialized
INFO - 2025-05-10 15:07:24 --> Language Class Initialized
INFO - 2025-05-10 15:07:24 --> Loader Class Initialized
INFO - 2025-05-10 15:07:24 --> Helper loaded: url_helper
INFO - 2025-05-10 15:07:24 --> Helper loaded: form_helper
INFO - 2025-05-10 15:07:24 --> Database Driver Class Initialized
DEBUG - 2025-05-10 15:07:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 15:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 15:07:24 --> Controller Class Initialized
INFO - 2025-05-10 15:07:24 --> Model "Workout_model" initialized
INFO - 2025-05-10 15:07:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-10 15:07:24 --> Final output sent to browser
DEBUG - 2025-05-10 15:07:24 --> Total execution time: 0.0653
INFO - 2025-05-10 15:07:24 --> Config Class Initialized
INFO - 2025-05-10 15:07:24 --> Hooks Class Initialized
DEBUG - 2025-05-10 15:07:24 --> UTF-8 Support Enabled
INFO - 2025-05-10 15:07:24 --> Utf8 Class Initialized
INFO - 2025-05-10 15:07:24 --> URI Class Initialized
INFO - 2025-05-10 15:07:24 --> Router Class Initialized
INFO - 2025-05-10 15:07:24 --> Output Class Initialized
INFO - 2025-05-10 15:07:24 --> Security Class Initialized
DEBUG - 2025-05-10 15:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 15:07:24 --> Input Class Initialized
INFO - 2025-05-10 15:07:24 --> Language Class Initialized
INFO - 2025-05-10 15:07:24 --> Loader Class Initialized
INFO - 2025-05-10 15:07:24 --> Helper loaded: url_helper
INFO - 2025-05-10 15:07:24 --> Helper loaded: form_helper
INFO - 2025-05-10 15:07:25 --> Database Driver Class Initialized
DEBUG - 2025-05-10 15:07:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 15:07:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 15:07:25 --> Controller Class Initialized
INFO - 2025-05-10 15:07:25 --> Model "Workout_model" initialized
INFO - 2025-05-10 15:07:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-10 15:07:25 --> Final output sent to browser
DEBUG - 2025-05-10 15:07:25 --> Total execution time: 0.0683
INFO - 2025-05-10 15:07:25 --> Config Class Initialized
INFO - 2025-05-10 15:07:25 --> Hooks Class Initialized
DEBUG - 2025-05-10 15:07:25 --> UTF-8 Support Enabled
INFO - 2025-05-10 15:07:25 --> Utf8 Class Initialized
INFO - 2025-05-10 15:07:25 --> URI Class Initialized
INFO - 2025-05-10 15:07:25 --> Router Class Initialized
INFO - 2025-05-10 15:07:25 --> Output Class Initialized
INFO - 2025-05-10 15:07:25 --> Security Class Initialized
DEBUG - 2025-05-10 15:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 15:07:25 --> Input Class Initialized
INFO - 2025-05-10 15:07:25 --> Language Class Initialized
INFO - 2025-05-10 15:07:25 --> Loader Class Initialized
INFO - 2025-05-10 15:07:25 --> Helper loaded: url_helper
INFO - 2025-05-10 15:07:25 --> Helper loaded: form_helper
INFO - 2025-05-10 15:07:25 --> Database Driver Class Initialized
DEBUG - 2025-05-10 15:07:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 15:07:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 15:07:25 --> Controller Class Initialized
INFO - 2025-05-10 15:07:25 --> Model "Workout_model" initialized
INFO - 2025-05-10 15:07:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-10 15:07:25 --> Final output sent to browser
DEBUG - 2025-05-10 15:07:25 --> Total execution time: 0.0671
INFO - 2025-05-10 15:07:25 --> Config Class Initialized
INFO - 2025-05-10 15:07:25 --> Hooks Class Initialized
DEBUG - 2025-05-10 15:07:25 --> UTF-8 Support Enabled
INFO - 2025-05-10 15:07:25 --> Utf8 Class Initialized
INFO - 2025-05-10 15:07:25 --> URI Class Initialized
INFO - 2025-05-10 15:07:25 --> Router Class Initialized
INFO - 2025-05-10 15:07:25 --> Output Class Initialized
INFO - 2025-05-10 15:07:25 --> Security Class Initialized
DEBUG - 2025-05-10 15:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 15:07:25 --> Input Class Initialized
INFO - 2025-05-10 15:07:25 --> Language Class Initialized
INFO - 2025-05-10 15:07:25 --> Loader Class Initialized
INFO - 2025-05-10 15:07:25 --> Helper loaded: url_helper
INFO - 2025-05-10 15:07:25 --> Helper loaded: form_helper
INFO - 2025-05-10 15:07:25 --> Database Driver Class Initialized
DEBUG - 2025-05-10 15:07:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 15:07:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 15:07:25 --> Controller Class Initialized
INFO - 2025-05-10 15:07:25 --> Model "Workout_model" initialized
INFO - 2025-05-10 15:07:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-10 15:07:25 --> Final output sent to browser
DEBUG - 2025-05-10 15:07:25 --> Total execution time: 0.0829
INFO - 2025-05-10 15:07:25 --> Config Class Initialized
INFO - 2025-05-10 15:07:25 --> Hooks Class Initialized
DEBUG - 2025-05-10 15:07:25 --> UTF-8 Support Enabled
INFO - 2025-05-10 15:07:25 --> Utf8 Class Initialized
INFO - 2025-05-10 15:07:25 --> URI Class Initialized
INFO - 2025-05-10 15:07:25 --> Router Class Initialized
INFO - 2025-05-10 15:07:25 --> Output Class Initialized
INFO - 2025-05-10 15:07:25 --> Security Class Initialized
DEBUG - 2025-05-10 15:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 15:07:25 --> Input Class Initialized
INFO - 2025-05-10 15:07:25 --> Language Class Initialized
INFO - 2025-05-10 15:07:25 --> Loader Class Initialized
INFO - 2025-05-10 15:07:25 --> Helper loaded: url_helper
INFO - 2025-05-10 15:07:25 --> Helper loaded: form_helper
INFO - 2025-05-10 15:07:25 --> Database Driver Class Initialized
DEBUG - 2025-05-10 15:07:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 15:07:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 15:07:25 --> Controller Class Initialized
INFO - 2025-05-10 15:07:25 --> Model "Workout_model" initialized
INFO - 2025-05-10 15:07:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-10 15:07:25 --> Final output sent to browser
DEBUG - 2025-05-10 15:07:25 --> Total execution time: 0.0602
INFO - 2025-05-10 15:07:26 --> Config Class Initialized
INFO - 2025-05-10 15:07:26 --> Hooks Class Initialized
DEBUG - 2025-05-10 15:07:26 --> UTF-8 Support Enabled
INFO - 2025-05-10 15:07:26 --> Utf8 Class Initialized
INFO - 2025-05-10 15:07:26 --> URI Class Initialized
INFO - 2025-05-10 15:07:26 --> Router Class Initialized
INFO - 2025-05-10 15:07:26 --> Output Class Initialized
INFO - 2025-05-10 15:07:26 --> Security Class Initialized
DEBUG - 2025-05-10 15:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 15:07:26 --> Input Class Initialized
INFO - 2025-05-10 15:07:26 --> Language Class Initialized
INFO - 2025-05-10 15:07:26 --> Loader Class Initialized
INFO - 2025-05-10 15:07:26 --> Helper loaded: url_helper
INFO - 2025-05-10 15:07:26 --> Helper loaded: form_helper
INFO - 2025-05-10 15:07:26 --> Database Driver Class Initialized
DEBUG - 2025-05-10 15:07:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 15:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 15:07:26 --> Controller Class Initialized
INFO - 2025-05-10 15:07:26 --> Model "Workout_model" initialized
INFO - 2025-05-10 15:07:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-10 15:07:26 --> Final output sent to browser
DEBUG - 2025-05-10 15:07:26 --> Total execution time: 0.0641
INFO - 2025-05-10 15:07:26 --> Config Class Initialized
INFO - 2025-05-10 15:07:26 --> Hooks Class Initialized
DEBUG - 2025-05-10 15:07:26 --> UTF-8 Support Enabled
INFO - 2025-05-10 15:07:26 --> Utf8 Class Initialized
INFO - 2025-05-10 15:07:26 --> URI Class Initialized
INFO - 2025-05-10 15:07:26 --> Router Class Initialized
INFO - 2025-05-10 15:07:26 --> Output Class Initialized
INFO - 2025-05-10 15:07:26 --> Security Class Initialized
DEBUG - 2025-05-10 15:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 15:07:26 --> Input Class Initialized
INFO - 2025-05-10 15:07:26 --> Language Class Initialized
INFO - 2025-05-10 15:07:26 --> Loader Class Initialized
INFO - 2025-05-10 15:07:26 --> Helper loaded: url_helper
INFO - 2025-05-10 15:07:26 --> Helper loaded: form_helper
INFO - 2025-05-10 15:07:26 --> Database Driver Class Initialized
DEBUG - 2025-05-10 15:07:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 15:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 15:07:26 --> Controller Class Initialized
INFO - 2025-05-10 15:07:26 --> Model "Workout_model" initialized
INFO - 2025-05-10 15:07:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-10 15:07:26 --> Final output sent to browser
DEBUG - 2025-05-10 15:07:26 --> Total execution time: 0.0710
INFO - 2025-05-10 15:07:31 --> Config Class Initialized
INFO - 2025-05-10 15:07:31 --> Hooks Class Initialized
DEBUG - 2025-05-10 15:07:31 --> UTF-8 Support Enabled
INFO - 2025-05-10 15:07:31 --> Utf8 Class Initialized
INFO - 2025-05-10 15:07:31 --> URI Class Initialized
INFO - 2025-05-10 15:07:31 --> Router Class Initialized
INFO - 2025-05-10 15:07:31 --> Output Class Initialized
INFO - 2025-05-10 15:07:31 --> Security Class Initialized
DEBUG - 2025-05-10 15:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 15:07:31 --> Input Class Initialized
INFO - 2025-05-10 15:07:31 --> Language Class Initialized
INFO - 2025-05-10 15:07:31 --> Loader Class Initialized
INFO - 2025-05-10 15:07:31 --> Helper loaded: url_helper
INFO - 2025-05-10 15:07:31 --> Helper loaded: form_helper
INFO - 2025-05-10 15:07:31 --> Database Driver Class Initialized
DEBUG - 2025-05-10 15:07:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 15:07:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 15:07:31 --> Controller Class Initialized
INFO - 2025-05-10 15:07:31 --> Model "Workout_model" initialized
INFO - 2025-05-10 15:07:31 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/start.php
INFO - 2025-05-10 15:07:31 --> Final output sent to browser
DEBUG - 2025-05-10 15:07:31 --> Total execution time: 0.0693
INFO - 2025-05-10 15:07:38 --> Config Class Initialized
INFO - 2025-05-10 15:07:38 --> Hooks Class Initialized
DEBUG - 2025-05-10 15:07:38 --> UTF-8 Support Enabled
INFO - 2025-05-10 15:07:38 --> Utf8 Class Initialized
INFO - 2025-05-10 15:07:38 --> URI Class Initialized
INFO - 2025-05-10 15:07:38 --> Router Class Initialized
INFO - 2025-05-10 15:07:38 --> Output Class Initialized
INFO - 2025-05-10 15:07:38 --> Security Class Initialized
DEBUG - 2025-05-10 15:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 15:07:38 --> Input Class Initialized
INFO - 2025-05-10 15:07:38 --> Language Class Initialized
INFO - 2025-05-10 15:07:38 --> Loader Class Initialized
INFO - 2025-05-10 15:07:38 --> Helper loaded: url_helper
INFO - 2025-05-10 15:07:38 --> Helper loaded: form_helper
INFO - 2025-05-10 15:07:38 --> Database Driver Class Initialized
DEBUG - 2025-05-10 15:07:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 15:07:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 15:07:38 --> Controller Class Initialized
INFO - 2025-05-10 15:07:38 --> Model "Workout_model" initialized
INFO - 2025-05-10 15:07:38 --> Final output sent to browser
DEBUG - 2025-05-10 15:07:38 --> Total execution time: 0.0716
INFO - 2025-05-10 15:07:42 --> Config Class Initialized
INFO - 2025-05-10 15:07:42 --> Hooks Class Initialized
DEBUG - 2025-05-10 15:07:42 --> UTF-8 Support Enabled
INFO - 2025-05-10 15:07:42 --> Utf8 Class Initialized
INFO - 2025-05-10 15:07:42 --> URI Class Initialized
INFO - 2025-05-10 15:07:42 --> Router Class Initialized
INFO - 2025-05-10 15:07:42 --> Output Class Initialized
INFO - 2025-05-10 15:07:42 --> Security Class Initialized
DEBUG - 2025-05-10 15:07:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 15:07:42 --> Input Class Initialized
INFO - 2025-05-10 15:07:42 --> Language Class Initialized
INFO - 2025-05-10 15:07:42 --> Loader Class Initialized
INFO - 2025-05-10 15:07:42 --> Helper loaded: url_helper
INFO - 2025-05-10 15:07:42 --> Helper loaded: form_helper
INFO - 2025-05-10 15:07:42 --> Database Driver Class Initialized
DEBUG - 2025-05-10 15:07:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 15:07:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 15:07:42 --> Controller Class Initialized
INFO - 2025-05-10 15:07:42 --> Model "Workout_model" initialized
INFO - 2025-05-10 15:07:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-10 15:07:42 --> Final output sent to browser
DEBUG - 2025-05-10 15:07:42 --> Total execution time: 0.0662
INFO - 2025-05-10 15:18:13 --> Config Class Initialized
INFO - 2025-05-10 15:18:13 --> Hooks Class Initialized
DEBUG - 2025-05-10 15:18:13 --> UTF-8 Support Enabled
INFO - 2025-05-10 15:18:13 --> Utf8 Class Initialized
INFO - 2025-05-10 15:18:13 --> URI Class Initialized
INFO - 2025-05-10 15:18:13 --> Router Class Initialized
INFO - 2025-05-10 15:18:13 --> Output Class Initialized
INFO - 2025-05-10 15:18:13 --> Security Class Initialized
DEBUG - 2025-05-10 15:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 15:18:13 --> Input Class Initialized
INFO - 2025-05-10 15:18:13 --> Language Class Initialized
INFO - 2025-05-10 15:18:13 --> Loader Class Initialized
INFO - 2025-05-10 15:18:13 --> Helper loaded: url_helper
INFO - 2025-05-10 15:18:13 --> Helper loaded: form_helper
INFO - 2025-05-10 15:18:13 --> Database Driver Class Initialized
DEBUG - 2025-05-10 15:18:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 15:18:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 15:18:13 --> Controller Class Initialized
INFO - 2025-05-10 15:18:13 --> Model "Workout_model" initialized
INFO - 2025-05-10 15:18:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-10 15:18:13 --> Final output sent to browser
DEBUG - 2025-05-10 15:18:13 --> Total execution time: 0.0821
INFO - 2025-05-10 15:18:15 --> Config Class Initialized
INFO - 2025-05-10 15:18:15 --> Hooks Class Initialized
DEBUG - 2025-05-10 15:18:16 --> UTF-8 Support Enabled
INFO - 2025-05-10 15:18:16 --> Utf8 Class Initialized
INFO - 2025-05-10 15:18:16 --> URI Class Initialized
INFO - 2025-05-10 15:18:16 --> Router Class Initialized
INFO - 2025-05-10 15:18:16 --> Output Class Initialized
INFO - 2025-05-10 15:18:16 --> Security Class Initialized
DEBUG - 2025-05-10 15:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 15:18:16 --> Input Class Initialized
INFO - 2025-05-10 15:18:16 --> Language Class Initialized
INFO - 2025-05-10 15:18:16 --> Loader Class Initialized
INFO - 2025-05-10 15:18:16 --> Helper loaded: url_helper
INFO - 2025-05-10 15:18:16 --> Helper loaded: form_helper
INFO - 2025-05-10 15:18:16 --> Database Driver Class Initialized
DEBUG - 2025-05-10 15:18:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 15:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 15:18:16 --> Controller Class Initialized
INFO - 2025-05-10 15:18:16 --> Model "Workout_model" initialized
INFO - 2025-05-10 15:18:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-10 15:18:16 --> Final output sent to browser
DEBUG - 2025-05-10 15:18:16 --> Total execution time: 0.0734
INFO - 2025-05-10 15:18:16 --> Config Class Initialized
INFO - 2025-05-10 15:18:16 --> Hooks Class Initialized
DEBUG - 2025-05-10 15:18:16 --> UTF-8 Support Enabled
INFO - 2025-05-10 15:18:16 --> Utf8 Class Initialized
INFO - 2025-05-10 15:18:16 --> URI Class Initialized
INFO - 2025-05-10 15:18:16 --> Router Class Initialized
INFO - 2025-05-10 15:18:16 --> Output Class Initialized
INFO - 2025-05-10 15:18:16 --> Security Class Initialized
DEBUG - 2025-05-10 15:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 15:18:16 --> Input Class Initialized
INFO - 2025-05-10 15:18:16 --> Language Class Initialized
INFO - 2025-05-10 15:18:16 --> Loader Class Initialized
INFO - 2025-05-10 15:18:16 --> Helper loaded: url_helper
INFO - 2025-05-10 15:18:16 --> Helper loaded: form_helper
INFO - 2025-05-10 15:18:16 --> Database Driver Class Initialized
DEBUG - 2025-05-10 15:18:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 15:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 15:18:16 --> Controller Class Initialized
INFO - 2025-05-10 15:18:16 --> Model "Workout_model" initialized
INFO - 2025-05-10 15:18:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-10 15:18:16 --> Final output sent to browser
DEBUG - 2025-05-10 15:18:16 --> Total execution time: 0.0713
INFO - 2025-05-10 15:18:20 --> Config Class Initialized
INFO - 2025-05-10 15:18:20 --> Hooks Class Initialized
DEBUG - 2025-05-10 15:18:20 --> UTF-8 Support Enabled
INFO - 2025-05-10 15:18:20 --> Utf8 Class Initialized
INFO - 2025-05-10 15:18:20 --> URI Class Initialized
INFO - 2025-05-10 15:18:20 --> Router Class Initialized
INFO - 2025-05-10 15:18:20 --> Output Class Initialized
INFO - 2025-05-10 15:18:20 --> Security Class Initialized
DEBUG - 2025-05-10 15:18:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 15:18:20 --> Input Class Initialized
INFO - 2025-05-10 15:18:20 --> Language Class Initialized
INFO - 2025-05-10 15:18:20 --> Loader Class Initialized
INFO - 2025-05-10 15:18:20 --> Helper loaded: url_helper
INFO - 2025-05-10 15:18:20 --> Helper loaded: form_helper
INFO - 2025-05-10 15:18:20 --> Database Driver Class Initialized
DEBUG - 2025-05-10 15:18:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 15:18:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 15:18:20 --> Controller Class Initialized
INFO - 2025-05-10 15:18:20 --> Model "Workout_model" initialized
INFO - 2025-05-10 15:18:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/start.php
INFO - 2025-05-10 15:18:20 --> Final output sent to browser
DEBUG - 2025-05-10 15:18:20 --> Total execution time: 0.0864
INFO - 2025-05-10 15:18:25 --> Config Class Initialized
INFO - 2025-05-10 15:18:25 --> Hooks Class Initialized
DEBUG - 2025-05-10 15:18:25 --> UTF-8 Support Enabled
INFO - 2025-05-10 15:18:25 --> Utf8 Class Initialized
INFO - 2025-05-10 15:18:25 --> URI Class Initialized
INFO - 2025-05-10 15:18:25 --> Router Class Initialized
INFO - 2025-05-10 15:18:25 --> Output Class Initialized
INFO - 2025-05-10 15:18:25 --> Security Class Initialized
DEBUG - 2025-05-10 15:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 15:18:25 --> Input Class Initialized
INFO - 2025-05-10 15:18:25 --> Language Class Initialized
INFO - 2025-05-10 15:18:25 --> Loader Class Initialized
INFO - 2025-05-10 15:18:25 --> Helper loaded: url_helper
INFO - 2025-05-10 15:18:25 --> Helper loaded: form_helper
INFO - 2025-05-10 15:18:25 --> Database Driver Class Initialized
DEBUG - 2025-05-10 15:18:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 15:18:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 15:18:25 --> Controller Class Initialized
INFO - 2025-05-10 15:18:25 --> Model "Workout_model" initialized
INFO - 2025-05-10 15:18:25 --> Final output sent to browser
DEBUG - 2025-05-10 15:18:25 --> Total execution time: 0.0817
INFO - 2025-05-10 15:18:29 --> Config Class Initialized
INFO - 2025-05-10 15:18:29 --> Hooks Class Initialized
DEBUG - 2025-05-10 15:18:29 --> UTF-8 Support Enabled
INFO - 2025-05-10 15:18:29 --> Utf8 Class Initialized
INFO - 2025-05-10 15:18:29 --> URI Class Initialized
INFO - 2025-05-10 15:18:29 --> Router Class Initialized
INFO - 2025-05-10 15:18:29 --> Output Class Initialized
INFO - 2025-05-10 15:18:29 --> Security Class Initialized
DEBUG - 2025-05-10 15:18:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 15:18:29 --> Input Class Initialized
INFO - 2025-05-10 15:18:29 --> Language Class Initialized
INFO - 2025-05-10 15:18:29 --> Loader Class Initialized
INFO - 2025-05-10 15:18:29 --> Helper loaded: url_helper
INFO - 2025-05-10 15:18:29 --> Helper loaded: form_helper
INFO - 2025-05-10 15:18:29 --> Database Driver Class Initialized
DEBUG - 2025-05-10 15:18:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 15:18:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 15:18:29 --> Controller Class Initialized
INFO - 2025-05-10 15:18:29 --> Model "Workout_model" initialized
INFO - 2025-05-10 15:18:29 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-10 15:18:29 --> Final output sent to browser
DEBUG - 2025-05-10 15:18:29 --> Total execution time: 0.0663
INFO - 2025-05-10 15:22:21 --> Config Class Initialized
INFO - 2025-05-10 15:22:21 --> Hooks Class Initialized
DEBUG - 2025-05-10 15:22:21 --> UTF-8 Support Enabled
INFO - 2025-05-10 15:22:21 --> Utf8 Class Initialized
INFO - 2025-05-10 15:22:21 --> URI Class Initialized
INFO - 2025-05-10 15:22:21 --> Router Class Initialized
INFO - 2025-05-10 15:22:21 --> Output Class Initialized
INFO - 2025-05-10 15:22:21 --> Security Class Initialized
DEBUG - 2025-05-10 15:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 15:22:21 --> Input Class Initialized
INFO - 2025-05-10 15:22:21 --> Language Class Initialized
INFO - 2025-05-10 15:22:21 --> Loader Class Initialized
INFO - 2025-05-10 15:22:21 --> Helper loaded: url_helper
INFO - 2025-05-10 15:22:21 --> Helper loaded: form_helper
INFO - 2025-05-10 15:22:21 --> Database Driver Class Initialized
DEBUG - 2025-05-10 15:22:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 15:22:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 15:22:21 --> Controller Class Initialized
INFO - 2025-05-10 15:22:21 --> Model "Workout_model" initialized
INFO - 2025-05-10 15:22:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-10 15:22:21 --> Final output sent to browser
DEBUG - 2025-05-10 15:22:21 --> Total execution time: 0.0737
INFO - 2025-05-10 15:22:24 --> Config Class Initialized
INFO - 2025-05-10 15:22:24 --> Hooks Class Initialized
DEBUG - 2025-05-10 15:22:24 --> UTF-8 Support Enabled
INFO - 2025-05-10 15:22:24 --> Utf8 Class Initialized
INFO - 2025-05-10 15:22:24 --> URI Class Initialized
INFO - 2025-05-10 15:22:24 --> Router Class Initialized
INFO - 2025-05-10 15:22:24 --> Output Class Initialized
INFO - 2025-05-10 15:22:24 --> Security Class Initialized
DEBUG - 2025-05-10 15:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 15:22:24 --> Input Class Initialized
INFO - 2025-05-10 15:22:24 --> Language Class Initialized
INFO - 2025-05-10 15:22:24 --> Loader Class Initialized
INFO - 2025-05-10 15:22:24 --> Helper loaded: url_helper
INFO - 2025-05-10 15:22:24 --> Helper loaded: form_helper
INFO - 2025-05-10 15:22:24 --> Database Driver Class Initialized
DEBUG - 2025-05-10 15:22:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 15:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 15:22:24 --> Controller Class Initialized
INFO - 2025-05-10 15:22:24 --> Model "Workout_model" initialized
INFO - 2025-05-10 15:22:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/start.php
INFO - 2025-05-10 15:22:24 --> Final output sent to browser
DEBUG - 2025-05-10 15:22:24 --> Total execution time: 0.0792
INFO - 2025-05-10 15:22:33 --> Config Class Initialized
INFO - 2025-05-10 15:22:33 --> Hooks Class Initialized
DEBUG - 2025-05-10 15:22:33 --> UTF-8 Support Enabled
INFO - 2025-05-10 15:22:33 --> Utf8 Class Initialized
INFO - 2025-05-10 15:22:33 --> URI Class Initialized
INFO - 2025-05-10 15:22:33 --> Router Class Initialized
INFO - 2025-05-10 15:22:33 --> Output Class Initialized
INFO - 2025-05-10 15:22:33 --> Security Class Initialized
DEBUG - 2025-05-10 15:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 15:22:33 --> Input Class Initialized
INFO - 2025-05-10 15:22:33 --> Language Class Initialized
INFO - 2025-05-10 15:22:33 --> Loader Class Initialized
INFO - 2025-05-10 15:22:33 --> Helper loaded: url_helper
INFO - 2025-05-10 15:22:33 --> Helper loaded: form_helper
INFO - 2025-05-10 15:22:33 --> Database Driver Class Initialized
DEBUG - 2025-05-10 15:22:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 15:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 15:22:33 --> Controller Class Initialized
INFO - 2025-05-10 15:22:33 --> Model "Workout_model" initialized
INFO - 2025-05-10 15:22:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-10 15:22:33 --> Final output sent to browser
DEBUG - 2025-05-10 15:22:33 --> Total execution time: 0.0811
INFO - 2025-05-10 15:22:34 --> Config Class Initialized
INFO - 2025-05-10 15:22:34 --> Hooks Class Initialized
DEBUG - 2025-05-10 15:22:34 --> UTF-8 Support Enabled
INFO - 2025-05-10 15:22:34 --> Utf8 Class Initialized
INFO - 2025-05-10 15:22:34 --> URI Class Initialized
INFO - 2025-05-10 15:22:34 --> Router Class Initialized
INFO - 2025-05-10 15:22:34 --> Output Class Initialized
INFO - 2025-05-10 15:22:34 --> Security Class Initialized
DEBUG - 2025-05-10 15:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 15:22:34 --> Input Class Initialized
INFO - 2025-05-10 15:22:34 --> Language Class Initialized
INFO - 2025-05-10 15:22:34 --> Loader Class Initialized
INFO - 2025-05-10 15:22:34 --> Helper loaded: url_helper
INFO - 2025-05-10 15:22:34 --> Helper loaded: form_helper
INFO - 2025-05-10 15:22:34 --> Database Driver Class Initialized
DEBUG - 2025-05-10 15:22:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 15:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 15:22:34 --> Controller Class Initialized
INFO - 2025-05-10 15:22:34 --> Model "Workout_model" initialized
INFO - 2025-05-10 15:22:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\workout/index.php
INFO - 2025-05-10 15:22:34 --> Final output sent to browser
DEBUG - 2025-05-10 15:22:34 --> Total execution time: 0.0796
INFO - 2025-05-10 15:24:44 --> Config Class Initialized
INFO - 2025-05-10 15:24:44 --> Hooks Class Initialized
DEBUG - 2025-05-10 15:24:44 --> UTF-8 Support Enabled
INFO - 2025-05-10 15:24:44 --> Utf8 Class Initialized
INFO - 2025-05-10 15:24:44 --> URI Class Initialized
DEBUG - 2025-05-10 15:24:44 --> No URI present. Default controller set.
INFO - 2025-05-10 15:24:44 --> Router Class Initialized
INFO - 2025-05-10 15:24:44 --> Output Class Initialized
INFO - 2025-05-10 15:24:44 --> Security Class Initialized
DEBUG - 2025-05-10 15:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 15:24:44 --> Input Class Initialized
INFO - 2025-05-10 15:24:44 --> Language Class Initialized
INFO - 2025-05-10 15:24:44 --> Loader Class Initialized
INFO - 2025-05-10 15:24:44 --> Helper loaded: url_helper
INFO - 2025-05-10 15:24:44 --> Helper loaded: form_helper
INFO - 2025-05-10 15:24:44 --> Database Driver Class Initialized
DEBUG - 2025-05-10 15:24:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 15:24:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 15:24:44 --> Controller Class Initialized
INFO - 2025-05-10 15:24:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-10 15:24:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-10 15:24:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-10 15:24:44 --> Final output sent to browser
DEBUG - 2025-05-10 15:24:44 --> Total execution time: 0.3704
INFO - 2025-05-10 15:55:59 --> Config Class Initialized
INFO - 2025-05-10 15:55:59 --> Hooks Class Initialized
DEBUG - 2025-05-10 15:55:59 --> UTF-8 Support Enabled
INFO - 2025-05-10 15:55:59 --> Utf8 Class Initialized
INFO - 2025-05-10 15:55:59 --> URI Class Initialized
INFO - 2025-05-10 15:55:59 --> Router Class Initialized
INFO - 2025-05-10 15:55:59 --> Output Class Initialized
INFO - 2025-05-10 15:55:59 --> Security Class Initialized
DEBUG - 2025-05-10 15:55:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 15:55:59 --> Input Class Initialized
INFO - 2025-05-10 15:55:59 --> Language Class Initialized
INFO - 2025-05-10 15:55:59 --> Loader Class Initialized
INFO - 2025-05-10 15:55:59 --> Helper loaded: url_helper
INFO - 2025-05-10 15:55:59 --> Helper loaded: form_helper
INFO - 2025-05-10 15:55:59 --> Database Driver Class Initialized
DEBUG - 2025-05-10 15:55:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 15:55:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 15:55:59 --> Controller Class Initialized
INFO - 2025-05-10 15:55:59 --> Model "User_model" initialized
INFO - 2025-05-10 15:55:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-10 15:55:59 --> Final output sent to browser
DEBUG - 2025-05-10 15:55:59 --> Total execution time: 0.0997
INFO - 2025-05-10 15:57:13 --> Config Class Initialized
INFO - 2025-05-10 15:57:13 --> Hooks Class Initialized
DEBUG - 2025-05-10 15:57:13 --> UTF-8 Support Enabled
INFO - 2025-05-10 15:57:13 --> Utf8 Class Initialized
INFO - 2025-05-10 15:57:13 --> URI Class Initialized
INFO - 2025-05-10 15:57:13 --> Router Class Initialized
INFO - 2025-05-10 15:57:13 --> Output Class Initialized
INFO - 2025-05-10 15:57:13 --> Security Class Initialized
DEBUG - 2025-05-10 15:57:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 15:57:13 --> Input Class Initialized
INFO - 2025-05-10 15:57:13 --> Language Class Initialized
INFO - 2025-05-10 15:57:13 --> Loader Class Initialized
INFO - 2025-05-10 15:57:13 --> Helper loaded: url_helper
INFO - 2025-05-10 15:57:13 --> Helper loaded: form_helper
INFO - 2025-05-10 15:57:13 --> Database Driver Class Initialized
DEBUG - 2025-05-10 15:57:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 15:57:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 15:57:13 --> Controller Class Initialized
INFO - 2025-05-10 15:57:13 --> Model "User_model" initialized
INFO - 2025-05-10 15:57:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-10 15:57:13 --> Final output sent to browser
DEBUG - 2025-05-10 15:57:13 --> Total execution time: 0.0691
INFO - 2025-05-10 15:58:17 --> Config Class Initialized
INFO - 2025-05-10 15:58:17 --> Hooks Class Initialized
DEBUG - 2025-05-10 15:58:17 --> UTF-8 Support Enabled
INFO - 2025-05-10 15:58:17 --> Utf8 Class Initialized
INFO - 2025-05-10 15:58:17 --> URI Class Initialized
INFO - 2025-05-10 15:58:17 --> Router Class Initialized
INFO - 2025-05-10 15:58:17 --> Output Class Initialized
INFO - 2025-05-10 15:58:17 --> Security Class Initialized
DEBUG - 2025-05-10 15:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 15:58:17 --> Input Class Initialized
INFO - 2025-05-10 15:58:17 --> Language Class Initialized
INFO - 2025-05-10 15:58:17 --> Loader Class Initialized
INFO - 2025-05-10 15:58:17 --> Helper loaded: url_helper
INFO - 2025-05-10 15:58:17 --> Helper loaded: form_helper
INFO - 2025-05-10 15:58:17 --> Database Driver Class Initialized
DEBUG - 2025-05-10 15:58:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 15:58:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 15:58:17 --> Controller Class Initialized
INFO - 2025-05-10 15:58:17 --> Model "User_model" initialized
INFO - 2025-05-10 15:58:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-10 15:58:17 --> Final output sent to browser
DEBUG - 2025-05-10 15:58:17 --> Total execution time: 0.0747
INFO - 2025-05-10 16:01:16 --> Config Class Initialized
INFO - 2025-05-10 16:01:16 --> Hooks Class Initialized
DEBUG - 2025-05-10 16:01:16 --> UTF-8 Support Enabled
INFO - 2025-05-10 16:01:16 --> Utf8 Class Initialized
INFO - 2025-05-10 16:01:16 --> URI Class Initialized
INFO - 2025-05-10 16:01:16 --> Router Class Initialized
INFO - 2025-05-10 16:01:16 --> Output Class Initialized
INFO - 2025-05-10 16:01:16 --> Security Class Initialized
DEBUG - 2025-05-10 16:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 16:01:16 --> Input Class Initialized
INFO - 2025-05-10 16:01:16 --> Language Class Initialized
INFO - 2025-05-10 16:01:16 --> Loader Class Initialized
INFO - 2025-05-10 16:01:16 --> Helper loaded: url_helper
INFO - 2025-05-10 16:01:16 --> Helper loaded: form_helper
INFO - 2025-05-10 16:01:16 --> Database Driver Class Initialized
DEBUG - 2025-05-10 16:01:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 16:01:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 16:01:16 --> Controller Class Initialized
INFO - 2025-05-10 16:01:16 --> Model "User_model" initialized
INFO - 2025-05-10 16:01:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-10 16:01:16 --> Final output sent to browser
DEBUG - 2025-05-10 16:01:16 --> Total execution time: 0.0698
INFO - 2025-05-10 16:02:08 --> Config Class Initialized
INFO - 2025-05-10 16:02:08 --> Hooks Class Initialized
DEBUG - 2025-05-10 16:02:08 --> UTF-8 Support Enabled
INFO - 2025-05-10 16:02:08 --> Utf8 Class Initialized
INFO - 2025-05-10 16:02:08 --> URI Class Initialized
INFO - 2025-05-10 16:02:08 --> Router Class Initialized
INFO - 2025-05-10 16:02:08 --> Output Class Initialized
INFO - 2025-05-10 16:02:08 --> Security Class Initialized
DEBUG - 2025-05-10 16:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 16:02:08 --> Input Class Initialized
INFO - 2025-05-10 16:02:08 --> Language Class Initialized
INFO - 2025-05-10 16:02:08 --> Loader Class Initialized
INFO - 2025-05-10 16:02:08 --> Helper loaded: url_helper
INFO - 2025-05-10 16:02:08 --> Helper loaded: form_helper
INFO - 2025-05-10 16:02:08 --> Database Driver Class Initialized
DEBUG - 2025-05-10 16:02:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 16:02:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 16:02:08 --> Controller Class Initialized
INFO - 2025-05-10 16:02:08 --> Model "User_model" initialized
INFO - 2025-05-10 16:02:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-10 16:02:08 --> Final output sent to browser
DEBUG - 2025-05-10 16:02:08 --> Total execution time: 0.0865
INFO - 2025-05-10 16:04:36 --> Config Class Initialized
INFO - 2025-05-10 16:04:36 --> Hooks Class Initialized
DEBUG - 2025-05-10 16:04:36 --> UTF-8 Support Enabled
INFO - 2025-05-10 16:04:36 --> Utf8 Class Initialized
INFO - 2025-05-10 16:04:36 --> URI Class Initialized
INFO - 2025-05-10 16:04:36 --> Router Class Initialized
INFO - 2025-05-10 16:04:36 --> Output Class Initialized
INFO - 2025-05-10 16:04:36 --> Security Class Initialized
DEBUG - 2025-05-10 16:04:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 16:04:36 --> Input Class Initialized
INFO - 2025-05-10 16:04:36 --> Language Class Initialized
INFO - 2025-05-10 16:04:36 --> Loader Class Initialized
INFO - 2025-05-10 16:04:36 --> Helper loaded: url_helper
INFO - 2025-05-10 16:04:36 --> Helper loaded: form_helper
INFO - 2025-05-10 16:04:36 --> Database Driver Class Initialized
DEBUG - 2025-05-10 16:04:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 16:04:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 16:04:36 --> Controller Class Initialized
INFO - 2025-05-10 16:04:36 --> Model "User_model" initialized
INFO - 2025-05-10 16:04:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-10 16:04:36 --> Final output sent to browser
DEBUG - 2025-05-10 16:04:36 --> Total execution time: 0.0713
INFO - 2025-05-10 16:06:12 --> Config Class Initialized
INFO - 2025-05-10 16:06:12 --> Hooks Class Initialized
DEBUG - 2025-05-10 16:06:12 --> UTF-8 Support Enabled
INFO - 2025-05-10 16:06:12 --> Utf8 Class Initialized
INFO - 2025-05-10 16:06:12 --> URI Class Initialized
INFO - 2025-05-10 16:06:12 --> Router Class Initialized
INFO - 2025-05-10 16:06:12 --> Output Class Initialized
INFO - 2025-05-10 16:06:12 --> Security Class Initialized
DEBUG - 2025-05-10 16:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 16:06:12 --> Input Class Initialized
INFO - 2025-05-10 16:06:12 --> Language Class Initialized
INFO - 2025-05-10 16:06:12 --> Loader Class Initialized
INFO - 2025-05-10 16:06:12 --> Helper loaded: url_helper
INFO - 2025-05-10 16:06:12 --> Helper loaded: form_helper
INFO - 2025-05-10 16:06:12 --> Database Driver Class Initialized
DEBUG - 2025-05-10 16:06:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 16:06:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 16:06:12 --> Controller Class Initialized
INFO - 2025-05-10 16:06:12 --> Model "User_model" initialized
INFO - 2025-05-10 16:06:12 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-10 16:06:12 --> Final output sent to browser
DEBUG - 2025-05-10 16:06:12 --> Total execution time: 0.0894
INFO - 2025-05-10 16:15:31 --> Config Class Initialized
INFO - 2025-05-10 16:15:31 --> Hooks Class Initialized
DEBUG - 2025-05-10 16:15:31 --> UTF-8 Support Enabled
INFO - 2025-05-10 16:15:31 --> Utf8 Class Initialized
INFO - 2025-05-10 16:15:31 --> URI Class Initialized
INFO - 2025-05-10 16:15:31 --> Router Class Initialized
INFO - 2025-05-10 16:15:31 --> Output Class Initialized
INFO - 2025-05-10 16:15:31 --> Security Class Initialized
DEBUG - 2025-05-10 16:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 16:15:31 --> Input Class Initialized
INFO - 2025-05-10 16:15:31 --> Language Class Initialized
INFO - 2025-05-10 16:15:31 --> Loader Class Initialized
INFO - 2025-05-10 16:15:31 --> Helper loaded: url_helper
INFO - 2025-05-10 16:15:31 --> Helper loaded: form_helper
INFO - 2025-05-10 16:15:31 --> Database Driver Class Initialized
DEBUG - 2025-05-10 16:15:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 16:15:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 16:15:31 --> Controller Class Initialized
INFO - 2025-05-10 16:15:31 --> Model "User_model" initialized
INFO - 2025-05-10 16:15:31 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-10 16:15:31 --> Final output sent to browser
DEBUG - 2025-05-10 16:15:31 --> Total execution time: 0.1098
INFO - 2025-05-10 16:15:31 --> Config Class Initialized
INFO - 2025-05-10 16:15:31 --> Hooks Class Initialized
DEBUG - 2025-05-10 16:15:31 --> UTF-8 Support Enabled
INFO - 2025-05-10 16:15:31 --> Utf8 Class Initialized
INFO - 2025-05-10 16:15:31 --> URI Class Initialized
INFO - 2025-05-10 16:15:31 --> Config Class Initialized
INFO - 2025-05-10 16:15:31 --> Router Class Initialized
INFO - 2025-05-10 16:15:31 --> Hooks Class Initialized
INFO - 2025-05-10 16:15:31 --> Output Class Initialized
DEBUG - 2025-05-10 16:15:31 --> UTF-8 Support Enabled
INFO - 2025-05-10 16:15:31 --> Utf8 Class Initialized
INFO - 2025-05-10 16:15:31 --> Security Class Initialized
INFO - 2025-05-10 16:15:31 --> URI Class Initialized
DEBUG - 2025-05-10 16:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 16:15:31 --> Input Class Initialized
INFO - 2025-05-10 16:15:31 --> Language Class Initialized
INFO - 2025-05-10 16:15:31 --> Router Class Initialized
ERROR - 2025-05-10 16:15:31 --> 404 Page Not Found: Auth/assets
INFO - 2025-05-10 16:15:31 --> Output Class Initialized
INFO - 2025-05-10 16:15:31 --> Security Class Initialized
DEBUG - 2025-05-10 16:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 16:15:31 --> Input Class Initialized
INFO - 2025-05-10 16:15:31 --> Language Class Initialized
ERROR - 2025-05-10 16:15:31 --> 404 Page Not Found: Auth/assets
INFO - 2025-05-10 16:18:26 --> Config Class Initialized
INFO - 2025-05-10 16:18:26 --> Hooks Class Initialized
DEBUG - 2025-05-10 16:18:26 --> UTF-8 Support Enabled
INFO - 2025-05-10 16:18:26 --> Utf8 Class Initialized
INFO - 2025-05-10 16:18:26 --> URI Class Initialized
INFO - 2025-05-10 16:18:26 --> Router Class Initialized
INFO - 2025-05-10 16:18:26 --> Output Class Initialized
INFO - 2025-05-10 16:18:26 --> Security Class Initialized
DEBUG - 2025-05-10 16:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 16:18:26 --> Input Class Initialized
INFO - 2025-05-10 16:18:26 --> Language Class Initialized
INFO - 2025-05-10 16:18:26 --> Loader Class Initialized
INFO - 2025-05-10 16:18:26 --> Helper loaded: url_helper
INFO - 2025-05-10 16:18:26 --> Helper loaded: form_helper
INFO - 2025-05-10 16:18:26 --> Database Driver Class Initialized
DEBUG - 2025-05-10 16:18:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 16:18:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 16:18:26 --> Controller Class Initialized
INFO - 2025-05-10 16:18:26 --> Model "User_model" initialized
INFO - 2025-05-10 16:18:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-10 16:18:26 --> Final output sent to browser
DEBUG - 2025-05-10 16:18:26 --> Total execution time: 0.0808
INFO - 2025-05-10 16:18:26 --> Config Class Initialized
INFO - 2025-05-10 16:18:26 --> Hooks Class Initialized
DEBUG - 2025-05-10 16:18:26 --> UTF-8 Support Enabled
INFO - 2025-05-10 16:18:26 --> Utf8 Class Initialized
INFO - 2025-05-10 16:18:26 --> URI Class Initialized
INFO - 2025-05-10 16:18:26 --> Router Class Initialized
INFO - 2025-05-10 16:18:26 --> Output Class Initialized
INFO - 2025-05-10 16:18:26 --> Security Class Initialized
DEBUG - 2025-05-10 16:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 16:18:26 --> Input Class Initialized
INFO - 2025-05-10 16:18:26 --> Language Class Initialized
ERROR - 2025-05-10 16:18:26 --> 404 Page Not Found: Auth/assets
INFO - 2025-05-10 16:18:27 --> Config Class Initialized
INFO - 2025-05-10 16:18:27 --> Hooks Class Initialized
DEBUG - 2025-05-10 16:18:27 --> UTF-8 Support Enabled
INFO - 2025-05-10 16:18:27 --> Utf8 Class Initialized
INFO - 2025-05-10 16:18:27 --> URI Class Initialized
INFO - 2025-05-10 16:18:27 --> Router Class Initialized
INFO - 2025-05-10 16:18:27 --> Output Class Initialized
INFO - 2025-05-10 16:18:27 --> Security Class Initialized
DEBUG - 2025-05-10 16:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 16:18:27 --> Input Class Initialized
INFO - 2025-05-10 16:18:27 --> Language Class Initialized
ERROR - 2025-05-10 16:18:27 --> 404 Page Not Found: Auth/assets
INFO - 2025-05-10 16:19:11 --> Config Class Initialized
INFO - 2025-05-10 16:19:11 --> Hooks Class Initialized
DEBUG - 2025-05-10 16:19:11 --> UTF-8 Support Enabled
INFO - 2025-05-10 16:19:11 --> Utf8 Class Initialized
INFO - 2025-05-10 16:19:11 --> URI Class Initialized
INFO - 2025-05-10 16:19:11 --> Router Class Initialized
INFO - 2025-05-10 16:19:11 --> Output Class Initialized
INFO - 2025-05-10 16:19:11 --> Security Class Initialized
DEBUG - 2025-05-10 16:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 16:19:11 --> Input Class Initialized
INFO - 2025-05-10 16:19:11 --> Language Class Initialized
INFO - 2025-05-10 16:19:11 --> Loader Class Initialized
INFO - 2025-05-10 16:19:11 --> Helper loaded: url_helper
INFO - 2025-05-10 16:19:11 --> Helper loaded: form_helper
INFO - 2025-05-10 16:19:11 --> Database Driver Class Initialized
DEBUG - 2025-05-10 16:19:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 16:19:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 16:19:11 --> Controller Class Initialized
INFO - 2025-05-10 16:19:11 --> Model "User_model" initialized
INFO - 2025-05-10 16:19:11 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-10 16:19:11 --> Final output sent to browser
DEBUG - 2025-05-10 16:19:11 --> Total execution time: 0.0729
INFO - 2025-05-10 16:19:11 --> Config Class Initialized
INFO - 2025-05-10 16:19:11 --> Hooks Class Initialized
DEBUG - 2025-05-10 16:19:11 --> UTF-8 Support Enabled
INFO - 2025-05-10 16:19:11 --> Utf8 Class Initialized
INFO - 2025-05-10 16:19:11 --> URI Class Initialized
INFO - 2025-05-10 16:19:11 --> Router Class Initialized
INFO - 2025-05-10 16:19:11 --> Output Class Initialized
INFO - 2025-05-10 16:19:11 --> Security Class Initialized
DEBUG - 2025-05-10 16:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 16:19:11 --> Input Class Initialized
INFO - 2025-05-10 16:19:11 --> Language Class Initialized
ERROR - 2025-05-10 16:19:11 --> 404 Page Not Found: Auth/assets
INFO - 2025-05-10 16:20:10 --> Config Class Initialized
INFO - 2025-05-10 16:20:10 --> Hooks Class Initialized
DEBUG - 2025-05-10 16:20:10 --> UTF-8 Support Enabled
INFO - 2025-05-10 16:20:10 --> Utf8 Class Initialized
INFO - 2025-05-10 16:20:10 --> URI Class Initialized
INFO - 2025-05-10 16:20:10 --> Router Class Initialized
INFO - 2025-05-10 16:20:10 --> Output Class Initialized
INFO - 2025-05-10 16:20:10 --> Security Class Initialized
DEBUG - 2025-05-10 16:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 16:20:10 --> Input Class Initialized
INFO - 2025-05-10 16:20:10 --> Language Class Initialized
INFO - 2025-05-10 16:20:10 --> Loader Class Initialized
INFO - 2025-05-10 16:20:10 --> Helper loaded: url_helper
INFO - 2025-05-10 16:20:10 --> Helper loaded: form_helper
INFO - 2025-05-10 16:20:10 --> Database Driver Class Initialized
DEBUG - 2025-05-10 16:20:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 16:20:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 16:20:10 --> Controller Class Initialized
INFO - 2025-05-10 16:20:10 --> Model "User_model" initialized
INFO - 2025-05-10 16:20:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-10 16:20:10 --> Final output sent to browser
DEBUG - 2025-05-10 16:20:10 --> Total execution time: 0.0766
INFO - 2025-05-10 16:21:05 --> Config Class Initialized
INFO - 2025-05-10 16:21:05 --> Hooks Class Initialized
DEBUG - 2025-05-10 16:21:05 --> UTF-8 Support Enabled
INFO - 2025-05-10 16:21:05 --> Utf8 Class Initialized
INFO - 2025-05-10 16:21:05 --> URI Class Initialized
INFO - 2025-05-10 16:21:05 --> Router Class Initialized
INFO - 2025-05-10 16:21:05 --> Output Class Initialized
INFO - 2025-05-10 16:21:05 --> Security Class Initialized
DEBUG - 2025-05-10 16:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 16:21:05 --> Input Class Initialized
INFO - 2025-05-10 16:21:05 --> Language Class Initialized
INFO - 2025-05-10 16:21:05 --> Loader Class Initialized
INFO - 2025-05-10 16:21:05 --> Helper loaded: url_helper
INFO - 2025-05-10 16:21:05 --> Helper loaded: form_helper
INFO - 2025-05-10 16:21:05 --> Database Driver Class Initialized
DEBUG - 2025-05-10 16:21:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 16:21:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 16:21:05 --> Controller Class Initialized
INFO - 2025-05-10 16:21:05 --> Model "User_model" initialized
INFO - 2025-05-10 16:21:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-10 16:21:05 --> Final output sent to browser
DEBUG - 2025-05-10 16:21:05 --> Total execution time: 0.0910
INFO - 2025-05-10 16:21:20 --> Config Class Initialized
INFO - 2025-05-10 16:21:20 --> Hooks Class Initialized
DEBUG - 2025-05-10 16:21:20 --> UTF-8 Support Enabled
INFO - 2025-05-10 16:21:20 --> Utf8 Class Initialized
INFO - 2025-05-10 16:21:20 --> URI Class Initialized
INFO - 2025-05-10 16:21:20 --> Router Class Initialized
INFO - 2025-05-10 16:21:20 --> Output Class Initialized
INFO - 2025-05-10 16:21:20 --> Security Class Initialized
DEBUG - 2025-05-10 16:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 16:21:20 --> Input Class Initialized
INFO - 2025-05-10 16:21:20 --> Language Class Initialized
INFO - 2025-05-10 16:21:20 --> Loader Class Initialized
INFO - 2025-05-10 16:21:20 --> Helper loaded: url_helper
INFO - 2025-05-10 16:21:20 --> Helper loaded: form_helper
INFO - 2025-05-10 16:21:20 --> Database Driver Class Initialized
DEBUG - 2025-05-10 16:21:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 16:21:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 16:21:20 --> Controller Class Initialized
INFO - 2025-05-10 16:21:20 --> Model "User_model" initialized
INFO - 2025-05-10 16:21:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-10 16:21:20 --> Final output sent to browser
DEBUG - 2025-05-10 16:21:20 --> Total execution time: 0.0818
INFO - 2025-05-10 16:21:43 --> Config Class Initialized
INFO - 2025-05-10 16:21:43 --> Hooks Class Initialized
DEBUG - 2025-05-10 16:21:43 --> UTF-8 Support Enabled
INFO - 2025-05-10 16:21:43 --> Utf8 Class Initialized
INFO - 2025-05-10 16:21:43 --> URI Class Initialized
INFO - 2025-05-10 16:21:43 --> Router Class Initialized
INFO - 2025-05-10 16:21:43 --> Output Class Initialized
INFO - 2025-05-10 16:21:43 --> Security Class Initialized
DEBUG - 2025-05-10 16:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 16:21:43 --> Input Class Initialized
INFO - 2025-05-10 16:21:43 --> Language Class Initialized
INFO - 2025-05-10 16:21:43 --> Loader Class Initialized
INFO - 2025-05-10 16:21:43 --> Helper loaded: url_helper
INFO - 2025-05-10 16:21:43 --> Helper loaded: form_helper
INFO - 2025-05-10 16:21:43 --> Database Driver Class Initialized
DEBUG - 2025-05-10 16:21:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 16:21:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 16:21:43 --> Controller Class Initialized
INFO - 2025-05-10 16:21:43 --> Model "User_model" initialized
INFO - 2025-05-10 16:21:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-10 16:21:43 --> Final output sent to browser
DEBUG - 2025-05-10 16:21:43 --> Total execution time: 0.0794
INFO - 2025-05-10 16:21:45 --> Config Class Initialized
INFO - 2025-05-10 16:21:45 --> Hooks Class Initialized
DEBUG - 2025-05-10 16:21:45 --> UTF-8 Support Enabled
INFO - 2025-05-10 16:21:45 --> Utf8 Class Initialized
INFO - 2025-05-10 16:21:45 --> URI Class Initialized
INFO - 2025-05-10 16:21:45 --> Router Class Initialized
INFO - 2025-05-10 16:21:45 --> Output Class Initialized
INFO - 2025-05-10 16:21:45 --> Security Class Initialized
DEBUG - 2025-05-10 16:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 16:21:45 --> Input Class Initialized
INFO - 2025-05-10 16:21:45 --> Language Class Initialized
INFO - 2025-05-10 16:21:45 --> Loader Class Initialized
INFO - 2025-05-10 16:21:45 --> Helper loaded: url_helper
INFO - 2025-05-10 16:21:45 --> Helper loaded: form_helper
INFO - 2025-05-10 16:21:45 --> Database Driver Class Initialized
DEBUG - 2025-05-10 16:21:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 16:21:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 16:21:45 --> Controller Class Initialized
INFO - 2025-05-10 16:21:45 --> Model "User_model" initialized
INFO - 2025-05-10 16:21:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-10 16:21:45 --> Final output sent to browser
DEBUG - 2025-05-10 16:21:45 --> Total execution time: 0.0808
INFO - 2025-05-10 16:21:58 --> Config Class Initialized
INFO - 2025-05-10 16:21:58 --> Hooks Class Initialized
DEBUG - 2025-05-10 16:21:58 --> UTF-8 Support Enabled
INFO - 2025-05-10 16:21:58 --> Utf8 Class Initialized
INFO - 2025-05-10 16:21:58 --> URI Class Initialized
INFO - 2025-05-10 16:21:58 --> Router Class Initialized
INFO - 2025-05-10 16:21:58 --> Output Class Initialized
INFO - 2025-05-10 16:21:58 --> Security Class Initialized
DEBUG - 2025-05-10 16:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 16:21:58 --> Input Class Initialized
INFO - 2025-05-10 16:21:58 --> Language Class Initialized
INFO - 2025-05-10 16:21:58 --> Loader Class Initialized
INFO - 2025-05-10 16:21:58 --> Helper loaded: url_helper
INFO - 2025-05-10 16:21:58 --> Helper loaded: form_helper
INFO - 2025-05-10 16:21:58 --> Database Driver Class Initialized
DEBUG - 2025-05-10 16:21:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 16:21:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 16:21:58 --> Controller Class Initialized
INFO - 2025-05-10 16:21:58 --> Model "User_model" initialized
INFO - 2025-05-10 16:21:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-10 16:21:58 --> Final output sent to browser
DEBUG - 2025-05-10 16:21:58 --> Total execution time: 0.0734
INFO - 2025-05-10 16:21:59 --> Config Class Initialized
INFO - 2025-05-10 16:21:59 --> Hooks Class Initialized
DEBUG - 2025-05-10 16:21:59 --> UTF-8 Support Enabled
INFO - 2025-05-10 16:21:59 --> Utf8 Class Initialized
INFO - 2025-05-10 16:21:59 --> URI Class Initialized
INFO - 2025-05-10 16:21:59 --> Router Class Initialized
INFO - 2025-05-10 16:21:59 --> Output Class Initialized
INFO - 2025-05-10 16:21:59 --> Security Class Initialized
DEBUG - 2025-05-10 16:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 16:21:59 --> Input Class Initialized
INFO - 2025-05-10 16:21:59 --> Language Class Initialized
INFO - 2025-05-10 16:21:59 --> Loader Class Initialized
INFO - 2025-05-10 16:21:59 --> Helper loaded: url_helper
INFO - 2025-05-10 16:21:59 --> Helper loaded: form_helper
INFO - 2025-05-10 16:21:59 --> Database Driver Class Initialized
DEBUG - 2025-05-10 16:21:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 16:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 16:21:59 --> Controller Class Initialized
INFO - 2025-05-10 16:21:59 --> Model "User_model" initialized
INFO - 2025-05-10 16:21:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-10 16:21:59 --> Final output sent to browser
DEBUG - 2025-05-10 16:21:59 --> Total execution time: 0.0711
INFO - 2025-05-10 16:22:10 --> Config Class Initialized
INFO - 2025-05-10 16:22:10 --> Hooks Class Initialized
DEBUG - 2025-05-10 16:22:10 --> UTF-8 Support Enabled
INFO - 2025-05-10 16:22:10 --> Utf8 Class Initialized
INFO - 2025-05-10 16:22:10 --> URI Class Initialized
INFO - 2025-05-10 16:22:10 --> Router Class Initialized
INFO - 2025-05-10 16:22:10 --> Output Class Initialized
INFO - 2025-05-10 16:22:10 --> Security Class Initialized
DEBUG - 2025-05-10 16:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 16:22:10 --> Input Class Initialized
INFO - 2025-05-10 16:22:10 --> Language Class Initialized
INFO - 2025-05-10 16:22:10 --> Loader Class Initialized
INFO - 2025-05-10 16:22:10 --> Helper loaded: url_helper
INFO - 2025-05-10 16:22:10 --> Helper loaded: form_helper
INFO - 2025-05-10 16:22:10 --> Database Driver Class Initialized
DEBUG - 2025-05-10 16:22:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 16:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 16:22:10 --> Controller Class Initialized
INFO - 2025-05-10 16:22:10 --> Model "User_model" initialized
INFO - 2025-05-10 16:22:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-10 16:22:10 --> Final output sent to browser
DEBUG - 2025-05-10 16:22:10 --> Total execution time: 0.0805
INFO - 2025-05-10 16:47:58 --> Config Class Initialized
INFO - 2025-05-10 16:47:58 --> Hooks Class Initialized
DEBUG - 2025-05-10 16:47:58 --> UTF-8 Support Enabled
INFO - 2025-05-10 16:47:58 --> Utf8 Class Initialized
INFO - 2025-05-10 16:47:58 --> URI Class Initialized
INFO - 2025-05-10 16:47:58 --> Router Class Initialized
INFO - 2025-05-10 16:47:58 --> Output Class Initialized
INFO - 2025-05-10 16:47:58 --> Security Class Initialized
DEBUG - 2025-05-10 16:47:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 16:47:58 --> Input Class Initialized
INFO - 2025-05-10 16:47:58 --> Language Class Initialized
INFO - 2025-05-10 16:47:58 --> Loader Class Initialized
INFO - 2025-05-10 16:47:58 --> Helper loaded: url_helper
INFO - 2025-05-10 16:47:58 --> Helper loaded: form_helper
INFO - 2025-05-10 16:47:58 --> Database Driver Class Initialized
DEBUG - 2025-05-10 16:47:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 16:47:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 16:47:58 --> Controller Class Initialized
INFO - 2025-05-10 16:47:58 --> Model "User_model" initialized
INFO - 2025-05-10 16:47:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-10 16:47:58 --> Final output sent to browser
DEBUG - 2025-05-10 16:47:58 --> Total execution time: 0.0725
INFO - 2025-05-10 16:47:58 --> Config Class Initialized
INFO - 2025-05-10 16:47:58 --> Hooks Class Initialized
DEBUG - 2025-05-10 16:47:58 --> UTF-8 Support Enabled
INFO - 2025-05-10 16:47:58 --> Utf8 Class Initialized
INFO - 2025-05-10 16:47:58 --> URI Class Initialized
INFO - 2025-05-10 16:47:58 --> Router Class Initialized
INFO - 2025-05-10 16:47:58 --> Output Class Initialized
INFO - 2025-05-10 16:47:58 --> Security Class Initialized
DEBUG - 2025-05-10 16:47:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 16:47:58 --> Input Class Initialized
INFO - 2025-05-10 16:47:58 --> Language Class Initialized
ERROR - 2025-05-10 16:47:58 --> 404 Page Not Found: Auth/assets
INFO - 2025-05-10 16:49:06 --> Config Class Initialized
INFO - 2025-05-10 16:49:06 --> Hooks Class Initialized
DEBUG - 2025-05-10 16:49:06 --> UTF-8 Support Enabled
INFO - 2025-05-10 16:49:06 --> Utf8 Class Initialized
INFO - 2025-05-10 16:49:06 --> URI Class Initialized
INFO - 2025-05-10 16:49:06 --> Router Class Initialized
INFO - 2025-05-10 16:49:06 --> Output Class Initialized
INFO - 2025-05-10 16:49:06 --> Security Class Initialized
DEBUG - 2025-05-10 16:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 16:49:06 --> Input Class Initialized
INFO - 2025-05-10 16:49:06 --> Language Class Initialized
INFO - 2025-05-10 16:49:06 --> Loader Class Initialized
INFO - 2025-05-10 16:49:06 --> Helper loaded: url_helper
INFO - 2025-05-10 16:49:06 --> Helper loaded: form_helper
INFO - 2025-05-10 16:49:06 --> Database Driver Class Initialized
DEBUG - 2025-05-10 16:49:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 16:49:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 16:49:06 --> Controller Class Initialized
INFO - 2025-05-10 16:49:06 --> Model "User_model" initialized
INFO - 2025-05-10 16:49:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-10 16:49:06 --> Final output sent to browser
DEBUG - 2025-05-10 16:49:06 --> Total execution time: 0.0910
INFO - 2025-05-10 16:49:06 --> Config Class Initialized
INFO - 2025-05-10 16:49:06 --> Hooks Class Initialized
DEBUG - 2025-05-10 16:49:06 --> UTF-8 Support Enabled
INFO - 2025-05-10 16:49:06 --> Utf8 Class Initialized
INFO - 2025-05-10 16:49:06 --> URI Class Initialized
INFO - 2025-05-10 16:49:06 --> Router Class Initialized
INFO - 2025-05-10 16:49:06 --> Output Class Initialized
INFO - 2025-05-10 16:49:06 --> Security Class Initialized
DEBUG - 2025-05-10 16:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 16:49:06 --> Input Class Initialized
INFO - 2025-05-10 16:49:06 --> Language Class Initialized
ERROR - 2025-05-10 16:49:06 --> 404 Page Not Found: Auth/assets
INFO - 2025-05-10 16:49:48 --> Config Class Initialized
INFO - 2025-05-10 16:49:48 --> Hooks Class Initialized
DEBUG - 2025-05-10 16:49:48 --> UTF-8 Support Enabled
INFO - 2025-05-10 16:49:48 --> Utf8 Class Initialized
INFO - 2025-05-10 16:49:48 --> URI Class Initialized
INFO - 2025-05-10 16:49:48 --> Router Class Initialized
INFO - 2025-05-10 16:49:48 --> Output Class Initialized
INFO - 2025-05-10 16:49:48 --> Security Class Initialized
DEBUG - 2025-05-10 16:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 16:49:48 --> Input Class Initialized
INFO - 2025-05-10 16:49:48 --> Language Class Initialized
INFO - 2025-05-10 16:49:48 --> Loader Class Initialized
INFO - 2025-05-10 16:49:48 --> Helper loaded: url_helper
INFO - 2025-05-10 16:49:48 --> Helper loaded: form_helper
INFO - 2025-05-10 16:49:49 --> Database Driver Class Initialized
DEBUG - 2025-05-10 16:49:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 16:49:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 16:49:49 --> Controller Class Initialized
INFO - 2025-05-10 16:49:49 --> Model "User_model" initialized
INFO - 2025-05-10 16:49:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-10 16:49:49 --> Final output sent to browser
DEBUG - 2025-05-10 16:49:49 --> Total execution time: 0.0774
INFO - 2025-05-10 16:49:49 --> Config Class Initialized
INFO - 2025-05-10 16:49:49 --> Hooks Class Initialized
DEBUG - 2025-05-10 16:49:49 --> UTF-8 Support Enabled
INFO - 2025-05-10 16:49:49 --> Utf8 Class Initialized
INFO - 2025-05-10 16:49:49 --> URI Class Initialized
INFO - 2025-05-10 16:49:49 --> Router Class Initialized
INFO - 2025-05-10 16:49:49 --> Output Class Initialized
INFO - 2025-05-10 16:49:49 --> Security Class Initialized
DEBUG - 2025-05-10 16:49:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 16:49:49 --> Input Class Initialized
INFO - 2025-05-10 16:49:49 --> Language Class Initialized
ERROR - 2025-05-10 16:49:49 --> 404 Page Not Found: Auth/assets
INFO - 2025-05-10 16:50:50 --> Config Class Initialized
INFO - 2025-05-10 16:50:50 --> Hooks Class Initialized
DEBUG - 2025-05-10 16:50:50 --> UTF-8 Support Enabled
INFO - 2025-05-10 16:50:50 --> Utf8 Class Initialized
INFO - 2025-05-10 16:50:50 --> URI Class Initialized
INFO - 2025-05-10 16:50:50 --> Router Class Initialized
INFO - 2025-05-10 16:50:50 --> Output Class Initialized
INFO - 2025-05-10 16:50:50 --> Security Class Initialized
DEBUG - 2025-05-10 16:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 16:50:50 --> Input Class Initialized
INFO - 2025-05-10 16:50:50 --> Language Class Initialized
INFO - 2025-05-10 16:50:50 --> Loader Class Initialized
INFO - 2025-05-10 16:50:50 --> Helper loaded: url_helper
INFO - 2025-05-10 16:50:50 --> Helper loaded: form_helper
INFO - 2025-05-10 16:50:50 --> Database Driver Class Initialized
DEBUG - 2025-05-10 16:50:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 16:50:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 16:50:50 --> Controller Class Initialized
INFO - 2025-05-10 16:50:50 --> Model "User_model" initialized
INFO - 2025-05-10 16:50:50 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-10 16:50:50 --> Final output sent to browser
DEBUG - 2025-05-10 16:50:50 --> Total execution time: 0.0733
INFO - 2025-05-10 16:50:50 --> Config Class Initialized
INFO - 2025-05-10 16:50:50 --> Hooks Class Initialized
DEBUG - 2025-05-10 16:50:50 --> UTF-8 Support Enabled
INFO - 2025-05-10 16:50:50 --> Utf8 Class Initialized
INFO - 2025-05-10 16:50:50 --> URI Class Initialized
INFO - 2025-05-10 16:50:50 --> Router Class Initialized
INFO - 2025-05-10 16:50:50 --> Output Class Initialized
INFO - 2025-05-10 16:50:50 --> Security Class Initialized
DEBUG - 2025-05-10 16:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 16:50:50 --> Input Class Initialized
INFO - 2025-05-10 16:50:50 --> Language Class Initialized
ERROR - 2025-05-10 16:50:50 --> 404 Page Not Found: Auth/assets
INFO - 2025-05-10 16:50:51 --> Config Class Initialized
INFO - 2025-05-10 16:50:51 --> Hooks Class Initialized
DEBUG - 2025-05-10 16:50:51 --> UTF-8 Support Enabled
INFO - 2025-05-10 16:50:51 --> Utf8 Class Initialized
INFO - 2025-05-10 16:50:51 --> URI Class Initialized
INFO - 2025-05-10 16:50:51 --> Router Class Initialized
INFO - 2025-05-10 16:50:51 --> Output Class Initialized
INFO - 2025-05-10 16:50:51 --> Security Class Initialized
DEBUG - 2025-05-10 16:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 16:50:51 --> Input Class Initialized
INFO - 2025-05-10 16:50:51 --> Language Class Initialized
INFO - 2025-05-10 16:50:51 --> Loader Class Initialized
INFO - 2025-05-10 16:50:51 --> Helper loaded: url_helper
INFO - 2025-05-10 16:50:51 --> Helper loaded: form_helper
INFO - 2025-05-10 16:50:51 --> Database Driver Class Initialized
DEBUG - 2025-05-10 16:50:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 16:50:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 16:50:51 --> Controller Class Initialized
INFO - 2025-05-10 16:50:51 --> Model "User_model" initialized
INFO - 2025-05-10 16:50:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-10 16:50:51 --> Final output sent to browser
DEBUG - 2025-05-10 16:50:51 --> Total execution time: 0.0673
INFO - 2025-05-10 16:50:51 --> Config Class Initialized
INFO - 2025-05-10 16:50:51 --> Hooks Class Initialized
DEBUG - 2025-05-10 16:50:51 --> UTF-8 Support Enabled
INFO - 2025-05-10 16:50:51 --> Utf8 Class Initialized
INFO - 2025-05-10 16:50:51 --> URI Class Initialized
INFO - 2025-05-10 16:50:51 --> Router Class Initialized
INFO - 2025-05-10 16:50:51 --> Output Class Initialized
INFO - 2025-05-10 16:50:51 --> Security Class Initialized
DEBUG - 2025-05-10 16:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 16:50:51 --> Input Class Initialized
INFO - 2025-05-10 16:50:51 --> Language Class Initialized
ERROR - 2025-05-10 16:50:51 --> 404 Page Not Found: Auth/assets
INFO - 2025-05-10 16:50:51 --> Config Class Initialized
INFO - 2025-05-10 16:50:51 --> Hooks Class Initialized
DEBUG - 2025-05-10 16:50:51 --> UTF-8 Support Enabled
INFO - 2025-05-10 16:50:51 --> Utf8 Class Initialized
INFO - 2025-05-10 16:50:51 --> URI Class Initialized
INFO - 2025-05-10 16:50:51 --> Router Class Initialized
INFO - 2025-05-10 16:50:51 --> Output Class Initialized
INFO - 2025-05-10 16:50:51 --> Security Class Initialized
DEBUG - 2025-05-10 16:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 16:50:51 --> Input Class Initialized
INFO - 2025-05-10 16:50:51 --> Language Class Initialized
INFO - 2025-05-10 16:50:51 --> Loader Class Initialized
INFO - 2025-05-10 16:50:51 --> Helper loaded: url_helper
INFO - 2025-05-10 16:50:51 --> Helper loaded: form_helper
INFO - 2025-05-10 16:50:51 --> Database Driver Class Initialized
DEBUG - 2025-05-10 16:50:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 16:50:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 16:50:51 --> Controller Class Initialized
INFO - 2025-05-10 16:50:51 --> Model "User_model" initialized
INFO - 2025-05-10 16:50:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-10 16:50:51 --> Final output sent to browser
DEBUG - 2025-05-10 16:50:51 --> Total execution time: 0.0838
INFO - 2025-05-10 16:50:51 --> Config Class Initialized
INFO - 2025-05-10 16:50:51 --> Hooks Class Initialized
DEBUG - 2025-05-10 16:50:51 --> UTF-8 Support Enabled
INFO - 2025-05-10 16:50:51 --> Utf8 Class Initialized
INFO - 2025-05-10 16:50:51 --> URI Class Initialized
INFO - 2025-05-10 16:50:51 --> Router Class Initialized
INFO - 2025-05-10 16:50:51 --> Output Class Initialized
INFO - 2025-05-10 16:50:51 --> Security Class Initialized
DEBUG - 2025-05-10 16:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 16:50:51 --> Input Class Initialized
INFO - 2025-05-10 16:50:51 --> Language Class Initialized
ERROR - 2025-05-10 16:50:51 --> 404 Page Not Found: Auth/assets
INFO - 2025-05-10 16:50:51 --> Config Class Initialized
INFO - 2025-05-10 16:50:51 --> Hooks Class Initialized
DEBUG - 2025-05-10 16:50:51 --> UTF-8 Support Enabled
INFO - 2025-05-10 16:50:51 --> Utf8 Class Initialized
INFO - 2025-05-10 16:50:51 --> URI Class Initialized
INFO - 2025-05-10 16:50:51 --> Router Class Initialized
INFO - 2025-05-10 16:50:51 --> Output Class Initialized
INFO - 2025-05-10 16:50:51 --> Security Class Initialized
DEBUG - 2025-05-10 16:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 16:50:51 --> Input Class Initialized
INFO - 2025-05-10 16:50:51 --> Language Class Initialized
INFO - 2025-05-10 16:50:51 --> Loader Class Initialized
INFO - 2025-05-10 16:50:51 --> Helper loaded: url_helper
INFO - 2025-05-10 16:50:51 --> Helper loaded: form_helper
INFO - 2025-05-10 16:50:51 --> Database Driver Class Initialized
DEBUG - 2025-05-10 16:50:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 16:50:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 16:50:51 --> Controller Class Initialized
INFO - 2025-05-10 16:50:51 --> Model "User_model" initialized
INFO - 2025-05-10 16:50:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-10 16:50:51 --> Final output sent to browser
DEBUG - 2025-05-10 16:50:51 --> Total execution time: 0.0741
INFO - 2025-05-10 16:50:52 --> Config Class Initialized
INFO - 2025-05-10 16:50:52 --> Hooks Class Initialized
DEBUG - 2025-05-10 16:50:52 --> UTF-8 Support Enabled
INFO - 2025-05-10 16:50:52 --> Utf8 Class Initialized
INFO - 2025-05-10 16:50:52 --> URI Class Initialized
INFO - 2025-05-10 16:50:52 --> Router Class Initialized
INFO - 2025-05-10 16:50:52 --> Output Class Initialized
INFO - 2025-05-10 16:50:52 --> Security Class Initialized
DEBUG - 2025-05-10 16:50:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 16:50:52 --> Input Class Initialized
INFO - 2025-05-10 16:50:52 --> Language Class Initialized
ERROR - 2025-05-10 16:50:52 --> 404 Page Not Found: Auth/assets
INFO - 2025-05-10 16:52:31 --> Config Class Initialized
INFO - 2025-05-10 16:52:31 --> Hooks Class Initialized
DEBUG - 2025-05-10 16:52:31 --> UTF-8 Support Enabled
INFO - 2025-05-10 16:52:31 --> Utf8 Class Initialized
INFO - 2025-05-10 16:52:31 --> URI Class Initialized
INFO - 2025-05-10 16:52:31 --> Router Class Initialized
INFO - 2025-05-10 16:52:31 --> Output Class Initialized
INFO - 2025-05-10 16:52:31 --> Security Class Initialized
DEBUG - 2025-05-10 16:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 16:52:31 --> Input Class Initialized
INFO - 2025-05-10 16:52:31 --> Language Class Initialized
INFO - 2025-05-10 16:52:31 --> Loader Class Initialized
INFO - 2025-05-10 16:52:31 --> Helper loaded: url_helper
INFO - 2025-05-10 16:52:31 --> Helper loaded: form_helper
INFO - 2025-05-10 16:52:31 --> Database Driver Class Initialized
DEBUG - 2025-05-10 16:52:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 16:52:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 16:52:31 --> Controller Class Initialized
INFO - 2025-05-10 16:52:31 --> Model "User_model" initialized
INFO - 2025-05-10 16:52:31 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-10 16:52:31 --> Final output sent to browser
DEBUG - 2025-05-10 16:52:31 --> Total execution time: 0.0768
INFO - 2025-05-10 16:52:31 --> Config Class Initialized
INFO - 2025-05-10 16:52:31 --> Hooks Class Initialized
DEBUG - 2025-05-10 16:52:32 --> UTF-8 Support Enabled
INFO - 2025-05-10 16:52:32 --> Utf8 Class Initialized
INFO - 2025-05-10 16:52:32 --> URI Class Initialized
INFO - 2025-05-10 16:52:32 --> Router Class Initialized
INFO - 2025-05-10 16:52:32 --> Output Class Initialized
INFO - 2025-05-10 16:52:32 --> Security Class Initialized
DEBUG - 2025-05-10 16:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 16:52:32 --> Input Class Initialized
INFO - 2025-05-10 16:52:32 --> Language Class Initialized
ERROR - 2025-05-10 16:52:32 --> 404 Page Not Found: Auth/assets
INFO - 2025-05-10 16:52:51 --> Config Class Initialized
INFO - 2025-05-10 16:52:51 --> Hooks Class Initialized
DEBUG - 2025-05-10 16:52:51 --> UTF-8 Support Enabled
INFO - 2025-05-10 16:52:51 --> Utf8 Class Initialized
INFO - 2025-05-10 16:52:51 --> URI Class Initialized
INFO - 2025-05-10 16:52:51 --> Router Class Initialized
INFO - 2025-05-10 16:52:51 --> Output Class Initialized
INFO - 2025-05-10 16:52:51 --> Security Class Initialized
DEBUG - 2025-05-10 16:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 16:52:51 --> Input Class Initialized
INFO - 2025-05-10 16:52:51 --> Language Class Initialized
INFO - 2025-05-10 16:52:51 --> Loader Class Initialized
INFO - 2025-05-10 16:52:51 --> Helper loaded: url_helper
INFO - 2025-05-10 16:52:51 --> Helper loaded: form_helper
INFO - 2025-05-10 16:52:51 --> Database Driver Class Initialized
DEBUG - 2025-05-10 16:52:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 16:52:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 16:52:51 --> Controller Class Initialized
INFO - 2025-05-10 16:52:51 --> Model "User_model" initialized
INFO - 2025-05-10 16:52:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-10 16:52:51 --> Final output sent to browser
DEBUG - 2025-05-10 16:52:51 --> Total execution time: 0.0672
INFO - 2025-05-10 16:52:51 --> Config Class Initialized
INFO - 2025-05-10 16:52:51 --> Hooks Class Initialized
DEBUG - 2025-05-10 16:52:51 --> UTF-8 Support Enabled
INFO - 2025-05-10 16:52:51 --> Utf8 Class Initialized
INFO - 2025-05-10 16:52:51 --> URI Class Initialized
INFO - 2025-05-10 16:52:51 --> Router Class Initialized
INFO - 2025-05-10 16:52:51 --> Output Class Initialized
INFO - 2025-05-10 16:52:51 --> Security Class Initialized
DEBUG - 2025-05-10 16:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 16:52:51 --> Input Class Initialized
INFO - 2025-05-10 16:52:51 --> Language Class Initialized
ERROR - 2025-05-10 16:52:51 --> 404 Page Not Found: Auth/assets
INFO - 2025-05-10 16:52:52 --> Config Class Initialized
INFO - 2025-05-10 16:52:52 --> Hooks Class Initialized
DEBUG - 2025-05-10 16:52:52 --> UTF-8 Support Enabled
INFO - 2025-05-10 16:52:52 --> Utf8 Class Initialized
INFO - 2025-05-10 16:52:52 --> URI Class Initialized
INFO - 2025-05-10 16:52:52 --> Router Class Initialized
INFO - 2025-05-10 16:52:52 --> Output Class Initialized
INFO - 2025-05-10 16:52:52 --> Security Class Initialized
DEBUG - 2025-05-10 16:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 16:52:52 --> Input Class Initialized
INFO - 2025-05-10 16:52:52 --> Language Class Initialized
INFO - 2025-05-10 16:52:52 --> Loader Class Initialized
INFO - 2025-05-10 16:52:52 --> Helper loaded: url_helper
INFO - 2025-05-10 16:52:52 --> Helper loaded: form_helper
INFO - 2025-05-10 16:52:52 --> Database Driver Class Initialized
DEBUG - 2025-05-10 16:52:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 16:52:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 16:52:52 --> Controller Class Initialized
INFO - 2025-05-10 16:52:52 --> Model "User_model" initialized
INFO - 2025-05-10 16:52:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-10 16:52:52 --> Final output sent to browser
DEBUG - 2025-05-10 16:52:52 --> Total execution time: 0.0636
INFO - 2025-05-10 16:52:52 --> Config Class Initialized
INFO - 2025-05-10 16:52:52 --> Hooks Class Initialized
DEBUG - 2025-05-10 16:52:52 --> UTF-8 Support Enabled
INFO - 2025-05-10 16:52:52 --> Utf8 Class Initialized
INFO - 2025-05-10 16:52:52 --> URI Class Initialized
INFO - 2025-05-10 16:52:52 --> Router Class Initialized
INFO - 2025-05-10 16:52:52 --> Output Class Initialized
INFO - 2025-05-10 16:52:52 --> Security Class Initialized
DEBUG - 2025-05-10 16:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 16:52:52 --> Input Class Initialized
INFO - 2025-05-10 16:52:52 --> Language Class Initialized
ERROR - 2025-05-10 16:52:52 --> 404 Page Not Found: Auth/assets
INFO - 2025-05-10 16:52:52 --> Config Class Initialized
INFO - 2025-05-10 16:52:52 --> Hooks Class Initialized
DEBUG - 2025-05-10 16:52:52 --> UTF-8 Support Enabled
INFO - 2025-05-10 16:52:52 --> Utf8 Class Initialized
INFO - 2025-05-10 16:52:52 --> URI Class Initialized
INFO - 2025-05-10 16:52:52 --> Router Class Initialized
INFO - 2025-05-10 16:52:52 --> Output Class Initialized
INFO - 2025-05-10 16:52:52 --> Security Class Initialized
DEBUG - 2025-05-10 16:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 16:52:52 --> Input Class Initialized
INFO - 2025-05-10 16:52:52 --> Language Class Initialized
INFO - 2025-05-10 16:52:52 --> Loader Class Initialized
INFO - 2025-05-10 16:52:52 --> Helper loaded: url_helper
INFO - 2025-05-10 16:52:52 --> Helper loaded: form_helper
INFO - 2025-05-10 16:52:52 --> Database Driver Class Initialized
DEBUG - 2025-05-10 16:52:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 16:52:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 16:52:52 --> Controller Class Initialized
INFO - 2025-05-10 16:52:52 --> Model "User_model" initialized
INFO - 2025-05-10 16:52:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-10 16:52:52 --> Final output sent to browser
DEBUG - 2025-05-10 16:52:52 --> Total execution time: 0.0677
INFO - 2025-05-10 16:52:53 --> Config Class Initialized
INFO - 2025-05-10 16:52:53 --> Hooks Class Initialized
DEBUG - 2025-05-10 16:52:53 --> UTF-8 Support Enabled
INFO - 2025-05-10 16:52:53 --> Utf8 Class Initialized
INFO - 2025-05-10 16:52:53 --> URI Class Initialized
INFO - 2025-05-10 16:52:53 --> Router Class Initialized
INFO - 2025-05-10 16:52:53 --> Output Class Initialized
INFO - 2025-05-10 16:52:53 --> Security Class Initialized
DEBUG - 2025-05-10 16:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 16:52:53 --> Input Class Initialized
INFO - 2025-05-10 16:52:53 --> Language Class Initialized
ERROR - 2025-05-10 16:52:53 --> 404 Page Not Found: Auth/assets
INFO - 2025-05-10 16:52:53 --> Config Class Initialized
INFO - 2025-05-10 16:52:53 --> Hooks Class Initialized
DEBUG - 2025-05-10 16:52:53 --> UTF-8 Support Enabled
INFO - 2025-05-10 16:52:53 --> Utf8 Class Initialized
INFO - 2025-05-10 16:52:53 --> URI Class Initialized
INFO - 2025-05-10 16:52:53 --> Router Class Initialized
INFO - 2025-05-10 16:52:53 --> Output Class Initialized
INFO - 2025-05-10 16:52:53 --> Security Class Initialized
DEBUG - 2025-05-10 16:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 16:52:53 --> Input Class Initialized
INFO - 2025-05-10 16:52:53 --> Language Class Initialized
INFO - 2025-05-10 16:52:53 --> Loader Class Initialized
INFO - 2025-05-10 16:52:53 --> Helper loaded: url_helper
INFO - 2025-05-10 16:52:53 --> Helper loaded: form_helper
INFO - 2025-05-10 16:52:53 --> Database Driver Class Initialized
DEBUG - 2025-05-10 16:52:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 16:52:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 16:52:53 --> Controller Class Initialized
INFO - 2025-05-10 16:52:53 --> Model "User_model" initialized
INFO - 2025-05-10 16:52:53 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-10 16:52:53 --> Final output sent to browser
DEBUG - 2025-05-10 16:52:53 --> Total execution time: 0.0723
INFO - 2025-05-10 16:52:53 --> Config Class Initialized
INFO - 2025-05-10 16:52:53 --> Hooks Class Initialized
DEBUG - 2025-05-10 16:52:53 --> UTF-8 Support Enabled
INFO - 2025-05-10 16:52:53 --> Utf8 Class Initialized
INFO - 2025-05-10 16:52:53 --> URI Class Initialized
INFO - 2025-05-10 16:52:53 --> Router Class Initialized
INFO - 2025-05-10 16:52:53 --> Output Class Initialized
INFO - 2025-05-10 16:52:53 --> Security Class Initialized
DEBUG - 2025-05-10 16:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 16:52:53 --> Input Class Initialized
INFO - 2025-05-10 16:52:53 --> Language Class Initialized
ERROR - 2025-05-10 16:52:53 --> 404 Page Not Found: Auth/assets
INFO - 2025-05-10 16:52:53 --> Config Class Initialized
INFO - 2025-05-10 16:52:53 --> Hooks Class Initialized
DEBUG - 2025-05-10 16:52:53 --> UTF-8 Support Enabled
INFO - 2025-05-10 16:52:53 --> Utf8 Class Initialized
INFO - 2025-05-10 16:52:53 --> URI Class Initialized
INFO - 2025-05-10 16:52:53 --> Router Class Initialized
INFO - 2025-05-10 16:52:53 --> Output Class Initialized
INFO - 2025-05-10 16:52:53 --> Security Class Initialized
DEBUG - 2025-05-10 16:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 16:52:53 --> Input Class Initialized
INFO - 2025-05-10 16:52:53 --> Language Class Initialized
INFO - 2025-05-10 16:52:53 --> Loader Class Initialized
INFO - 2025-05-10 16:52:53 --> Helper loaded: url_helper
INFO - 2025-05-10 16:52:53 --> Helper loaded: form_helper
INFO - 2025-05-10 16:52:53 --> Database Driver Class Initialized
DEBUG - 2025-05-10 16:52:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 16:52:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 16:52:53 --> Controller Class Initialized
INFO - 2025-05-10 16:52:53 --> Model "User_model" initialized
INFO - 2025-05-10 16:52:53 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-10 16:52:53 --> Final output sent to browser
DEBUG - 2025-05-10 16:52:53 --> Total execution time: 0.0771
INFO - 2025-05-10 16:52:53 --> Config Class Initialized
INFO - 2025-05-10 16:52:53 --> Hooks Class Initialized
DEBUG - 2025-05-10 16:52:53 --> UTF-8 Support Enabled
INFO - 2025-05-10 16:52:53 --> Utf8 Class Initialized
INFO - 2025-05-10 16:52:53 --> URI Class Initialized
INFO - 2025-05-10 16:52:53 --> Router Class Initialized
INFO - 2025-05-10 16:52:53 --> Output Class Initialized
INFO - 2025-05-10 16:52:53 --> Security Class Initialized
DEBUG - 2025-05-10 16:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 16:52:53 --> Input Class Initialized
INFO - 2025-05-10 16:52:53 --> Language Class Initialized
ERROR - 2025-05-10 16:52:53 --> 404 Page Not Found: Auth/assets
INFO - 2025-05-10 16:53:03 --> Config Class Initialized
INFO - 2025-05-10 16:53:03 --> Hooks Class Initialized
DEBUG - 2025-05-10 16:53:03 --> UTF-8 Support Enabled
INFO - 2025-05-10 16:53:03 --> Utf8 Class Initialized
INFO - 2025-05-10 16:53:03 --> URI Class Initialized
INFO - 2025-05-10 16:53:03 --> Router Class Initialized
INFO - 2025-05-10 16:53:03 --> Output Class Initialized
INFO - 2025-05-10 16:53:03 --> Security Class Initialized
DEBUG - 2025-05-10 16:53:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 16:53:03 --> Input Class Initialized
INFO - 2025-05-10 16:53:03 --> Language Class Initialized
INFO - 2025-05-10 16:53:03 --> Loader Class Initialized
INFO - 2025-05-10 16:53:03 --> Helper loaded: url_helper
INFO - 2025-05-10 16:53:03 --> Helper loaded: form_helper
INFO - 2025-05-10 16:53:03 --> Database Driver Class Initialized
DEBUG - 2025-05-10 16:53:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 16:53:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 16:53:03 --> Controller Class Initialized
INFO - 2025-05-10 16:53:03 --> Model "User_model" initialized
INFO - 2025-05-10 16:53:03 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-10 16:53:03 --> Final output sent to browser
DEBUG - 2025-05-10 16:53:03 --> Total execution time: 0.0740
INFO - 2025-05-10 16:53:04 --> Config Class Initialized
INFO - 2025-05-10 16:53:04 --> Hooks Class Initialized
DEBUG - 2025-05-10 16:53:04 --> UTF-8 Support Enabled
INFO - 2025-05-10 16:53:04 --> Utf8 Class Initialized
INFO - 2025-05-10 16:53:04 --> URI Class Initialized
INFO - 2025-05-10 16:53:04 --> Router Class Initialized
INFO - 2025-05-10 16:53:04 --> Output Class Initialized
INFO - 2025-05-10 16:53:04 --> Security Class Initialized
DEBUG - 2025-05-10 16:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 16:53:04 --> Input Class Initialized
INFO - 2025-05-10 16:53:04 --> Language Class Initialized
ERROR - 2025-05-10 16:53:04 --> 404 Page Not Found: Auth/assets
INFO - 2025-05-10 17:15:10 --> Config Class Initialized
INFO - 2025-05-10 17:15:10 --> Hooks Class Initialized
DEBUG - 2025-05-10 17:15:10 --> UTF-8 Support Enabled
INFO - 2025-05-10 17:15:10 --> Utf8 Class Initialized
INFO - 2025-05-10 17:15:10 --> URI Class Initialized
INFO - 2025-05-10 17:15:10 --> Router Class Initialized
INFO - 2025-05-10 17:15:10 --> Output Class Initialized
INFO - 2025-05-10 17:15:10 --> Security Class Initialized
DEBUG - 2025-05-10 17:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 17:15:10 --> Input Class Initialized
INFO - 2025-05-10 17:15:10 --> Language Class Initialized
INFO - 2025-05-10 17:15:10 --> Loader Class Initialized
INFO - 2025-05-10 17:15:10 --> Helper loaded: url_helper
INFO - 2025-05-10 17:15:10 --> Helper loaded: form_helper
INFO - 2025-05-10 17:15:10 --> Database Driver Class Initialized
DEBUG - 2025-05-10 17:15:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 17:15:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 17:15:10 --> Controller Class Initialized
INFO - 2025-05-10 17:15:10 --> Model "User_model" initialized
INFO - 2025-05-10 17:15:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-10 17:15:10 --> Final output sent to browser
DEBUG - 2025-05-10 17:15:10 --> Total execution time: 0.0637
INFO - 2025-05-10 17:19:40 --> Config Class Initialized
INFO - 2025-05-10 17:19:40 --> Hooks Class Initialized
DEBUG - 2025-05-10 17:19:40 --> UTF-8 Support Enabled
INFO - 2025-05-10 17:19:40 --> Utf8 Class Initialized
INFO - 2025-05-10 17:19:40 --> URI Class Initialized
INFO - 2025-05-10 17:19:40 --> Router Class Initialized
INFO - 2025-05-10 17:19:40 --> Output Class Initialized
INFO - 2025-05-10 17:19:40 --> Security Class Initialized
DEBUG - 2025-05-10 17:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 17:19:40 --> Input Class Initialized
INFO - 2025-05-10 17:19:40 --> Language Class Initialized
INFO - 2025-05-10 17:19:40 --> Loader Class Initialized
INFO - 2025-05-10 17:19:40 --> Helper loaded: url_helper
INFO - 2025-05-10 17:19:40 --> Helper loaded: form_helper
INFO - 2025-05-10 17:19:40 --> Database Driver Class Initialized
DEBUG - 2025-05-10 17:19:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 17:19:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 17:19:40 --> Controller Class Initialized
INFO - 2025-05-10 17:19:40 --> Model "User_model" initialized
INFO - 2025-05-10 17:19:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-10 17:19:40 --> Final output sent to browser
DEBUG - 2025-05-10 17:19:40 --> Total execution time: 0.0843
INFO - 2025-05-10 17:20:20 --> Config Class Initialized
INFO - 2025-05-10 17:20:20 --> Hooks Class Initialized
DEBUG - 2025-05-10 17:20:20 --> UTF-8 Support Enabled
INFO - 2025-05-10 17:20:20 --> Utf8 Class Initialized
INFO - 2025-05-10 17:20:20 --> URI Class Initialized
DEBUG - 2025-05-10 17:20:20 --> No URI present. Default controller set.
INFO - 2025-05-10 17:20:20 --> Router Class Initialized
INFO - 2025-05-10 17:20:20 --> Output Class Initialized
INFO - 2025-05-10 17:20:20 --> Security Class Initialized
DEBUG - 2025-05-10 17:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 17:20:20 --> Input Class Initialized
INFO - 2025-05-10 17:20:20 --> Language Class Initialized
INFO - 2025-05-10 17:20:20 --> Loader Class Initialized
INFO - 2025-05-10 17:20:20 --> Helper loaded: url_helper
INFO - 2025-05-10 17:20:20 --> Helper loaded: form_helper
INFO - 2025-05-10 17:20:20 --> Database Driver Class Initialized
DEBUG - 2025-05-10 17:20:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 17:20:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 17:20:20 --> Controller Class Initialized
INFO - 2025-05-10 17:20:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-10 17:20:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-10 17:20:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-10 17:20:20 --> Final output sent to browser
DEBUG - 2025-05-10 17:20:20 --> Total execution time: 0.0746
INFO - 2025-05-10 17:21:18 --> Config Class Initialized
INFO - 2025-05-10 17:21:18 --> Hooks Class Initialized
DEBUG - 2025-05-10 17:21:18 --> UTF-8 Support Enabled
INFO - 2025-05-10 17:21:18 --> Utf8 Class Initialized
INFO - 2025-05-10 17:21:18 --> URI Class Initialized
INFO - 2025-05-10 17:21:18 --> Router Class Initialized
INFO - 2025-05-10 17:21:18 --> Output Class Initialized
INFO - 2025-05-10 17:21:18 --> Security Class Initialized
DEBUG - 2025-05-10 17:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 17:21:18 --> Input Class Initialized
INFO - 2025-05-10 17:21:18 --> Language Class Initialized
INFO - 2025-05-10 17:21:18 --> Loader Class Initialized
INFO - 2025-05-10 17:21:18 --> Helper loaded: url_helper
INFO - 2025-05-10 17:21:18 --> Helper loaded: form_helper
INFO - 2025-05-10 17:21:18 --> Database Driver Class Initialized
DEBUG - 2025-05-10 17:21:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 17:21:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 17:21:18 --> Controller Class Initialized
INFO - 2025-05-10 17:21:18 --> Model "User_model" initialized
INFO - 2025-05-10 17:21:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-10 17:21:18 --> Final output sent to browser
DEBUG - 2025-05-10 17:21:18 --> Total execution time: 0.0898
INFO - 2025-05-10 17:21:18 --> Config Class Initialized
INFO - 2025-05-10 17:21:18 --> Hooks Class Initialized
DEBUG - 2025-05-10 17:21:18 --> UTF-8 Support Enabled
INFO - 2025-05-10 17:21:18 --> Utf8 Class Initialized
INFO - 2025-05-10 17:21:18 --> URI Class Initialized
INFO - 2025-05-10 17:21:18 --> Router Class Initialized
INFO - 2025-05-10 17:21:18 --> Output Class Initialized
INFO - 2025-05-10 17:21:18 --> Security Class Initialized
DEBUG - 2025-05-10 17:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 17:21:18 --> Input Class Initialized
INFO - 2025-05-10 17:21:18 --> Language Class Initialized
ERROR - 2025-05-10 17:21:18 --> 404 Page Not Found: Auth/assets
INFO - 2025-05-10 17:23:47 --> Config Class Initialized
INFO - 2025-05-10 17:23:47 --> Hooks Class Initialized
DEBUG - 2025-05-10 17:23:47 --> UTF-8 Support Enabled
INFO - 2025-05-10 17:23:47 --> Utf8 Class Initialized
INFO - 2025-05-10 17:23:47 --> URI Class Initialized
INFO - 2025-05-10 17:23:47 --> Router Class Initialized
INFO - 2025-05-10 17:23:47 --> Output Class Initialized
INFO - 2025-05-10 17:23:47 --> Security Class Initialized
DEBUG - 2025-05-10 17:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 17:23:47 --> Input Class Initialized
INFO - 2025-05-10 17:23:47 --> Language Class Initialized
INFO - 2025-05-10 17:23:47 --> Loader Class Initialized
INFO - 2025-05-10 17:23:47 --> Helper loaded: url_helper
INFO - 2025-05-10 17:23:47 --> Helper loaded: form_helper
INFO - 2025-05-10 17:23:47 --> Database Driver Class Initialized
DEBUG - 2025-05-10 17:23:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 17:23:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 17:23:47 --> Controller Class Initialized
INFO - 2025-05-10 17:23:47 --> Model "User_model" initialized
INFO - 2025-05-10 17:23:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-10 17:23:47 --> Final output sent to browser
DEBUG - 2025-05-10 17:23:47 --> Total execution time: 0.0719
INFO - 2025-05-10 17:23:47 --> Config Class Initialized
INFO - 2025-05-10 17:23:47 --> Hooks Class Initialized
DEBUG - 2025-05-10 17:23:47 --> UTF-8 Support Enabled
INFO - 2025-05-10 17:23:47 --> Utf8 Class Initialized
INFO - 2025-05-10 17:23:47 --> URI Class Initialized
INFO - 2025-05-10 17:23:47 --> Router Class Initialized
INFO - 2025-05-10 17:23:47 --> Output Class Initialized
INFO - 2025-05-10 17:23:47 --> Security Class Initialized
DEBUG - 2025-05-10 17:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 17:23:47 --> Input Class Initialized
INFO - 2025-05-10 17:23:47 --> Language Class Initialized
ERROR - 2025-05-10 17:23:47 --> 404 Page Not Found: Auth/assets
INFO - 2025-05-10 17:24:37 --> Config Class Initialized
INFO - 2025-05-10 17:24:37 --> Hooks Class Initialized
DEBUG - 2025-05-10 17:24:37 --> UTF-8 Support Enabled
INFO - 2025-05-10 17:24:37 --> Utf8 Class Initialized
INFO - 2025-05-10 17:24:37 --> URI Class Initialized
INFO - 2025-05-10 17:24:37 --> Router Class Initialized
INFO - 2025-05-10 17:24:37 --> Output Class Initialized
INFO - 2025-05-10 17:24:37 --> Security Class Initialized
DEBUG - 2025-05-10 17:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 17:24:37 --> Input Class Initialized
INFO - 2025-05-10 17:24:37 --> Language Class Initialized
INFO - 2025-05-10 17:24:37 --> Loader Class Initialized
INFO - 2025-05-10 17:24:37 --> Helper loaded: url_helper
INFO - 2025-05-10 17:24:37 --> Helper loaded: form_helper
INFO - 2025-05-10 17:24:37 --> Database Driver Class Initialized
DEBUG - 2025-05-10 17:24:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 17:24:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 17:24:37 --> Controller Class Initialized
INFO - 2025-05-10 17:24:37 --> Model "User_model" initialized
INFO - 2025-05-10 17:24:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-10 17:24:37 --> Final output sent to browser
DEBUG - 2025-05-10 17:24:37 --> Total execution time: 0.0764
INFO - 2025-05-10 17:24:37 --> Config Class Initialized
INFO - 2025-05-10 17:24:37 --> Hooks Class Initialized
DEBUG - 2025-05-10 17:24:37 --> UTF-8 Support Enabled
INFO - 2025-05-10 17:24:37 --> Utf8 Class Initialized
INFO - 2025-05-10 17:24:37 --> URI Class Initialized
INFO - 2025-05-10 17:24:37 --> Router Class Initialized
INFO - 2025-05-10 17:24:37 --> Output Class Initialized
INFO - 2025-05-10 17:24:37 --> Security Class Initialized
DEBUG - 2025-05-10 17:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 17:24:37 --> Input Class Initialized
INFO - 2025-05-10 17:24:37 --> Language Class Initialized
ERROR - 2025-05-10 17:24:37 --> 404 Page Not Found: Auth/assets
INFO - 2025-05-10 17:24:40 --> Config Class Initialized
INFO - 2025-05-10 17:24:40 --> Hooks Class Initialized
DEBUG - 2025-05-10 17:24:40 --> UTF-8 Support Enabled
INFO - 2025-05-10 17:24:40 --> Utf8 Class Initialized
INFO - 2025-05-10 17:24:40 --> URI Class Initialized
INFO - 2025-05-10 17:24:40 --> Router Class Initialized
INFO - 2025-05-10 17:24:40 --> Output Class Initialized
INFO - 2025-05-10 17:24:40 --> Security Class Initialized
DEBUG - 2025-05-10 17:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 17:24:40 --> Input Class Initialized
INFO - 2025-05-10 17:24:40 --> Language Class Initialized
INFO - 2025-05-10 17:24:40 --> Loader Class Initialized
INFO - 2025-05-10 17:24:40 --> Helper loaded: url_helper
INFO - 2025-05-10 17:24:40 --> Helper loaded: form_helper
INFO - 2025-05-10 17:24:40 --> Database Driver Class Initialized
DEBUG - 2025-05-10 17:24:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 17:24:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 17:24:40 --> Controller Class Initialized
INFO - 2025-05-10 17:24:40 --> Model "User_model" initialized
INFO - 2025-05-10 17:24:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-10 17:24:40 --> Final output sent to browser
DEBUG - 2025-05-10 17:24:40 --> Total execution time: 0.0720
INFO - 2025-05-10 17:24:40 --> Config Class Initialized
INFO - 2025-05-10 17:24:40 --> Hooks Class Initialized
DEBUG - 2025-05-10 17:24:40 --> UTF-8 Support Enabled
INFO - 2025-05-10 17:24:40 --> Utf8 Class Initialized
INFO - 2025-05-10 17:24:40 --> URI Class Initialized
INFO - 2025-05-10 17:24:40 --> Router Class Initialized
INFO - 2025-05-10 17:24:40 --> Output Class Initialized
INFO - 2025-05-10 17:24:40 --> Security Class Initialized
DEBUG - 2025-05-10 17:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 17:24:40 --> Input Class Initialized
INFO - 2025-05-10 17:24:40 --> Language Class Initialized
ERROR - 2025-05-10 17:24:40 --> 404 Page Not Found: Auth/assets
INFO - 2025-05-10 17:24:52 --> Config Class Initialized
INFO - 2025-05-10 17:24:52 --> Hooks Class Initialized
DEBUG - 2025-05-10 17:24:52 --> UTF-8 Support Enabled
INFO - 2025-05-10 17:24:52 --> Utf8 Class Initialized
INFO - 2025-05-10 17:24:52 --> URI Class Initialized
INFO - 2025-05-10 17:24:52 --> Router Class Initialized
INFO - 2025-05-10 17:24:52 --> Output Class Initialized
INFO - 2025-05-10 17:24:52 --> Security Class Initialized
DEBUG - 2025-05-10 17:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 17:24:52 --> Input Class Initialized
INFO - 2025-05-10 17:24:52 --> Language Class Initialized
INFO - 2025-05-10 17:24:52 --> Loader Class Initialized
INFO - 2025-05-10 17:24:52 --> Helper loaded: url_helper
INFO - 2025-05-10 17:24:52 --> Helper loaded: form_helper
INFO - 2025-05-10 17:24:52 --> Database Driver Class Initialized
DEBUG - 2025-05-10 17:24:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 17:24:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 17:24:52 --> Controller Class Initialized
INFO - 2025-05-10 17:24:52 --> Model "User_model" initialized
INFO - 2025-05-10 17:24:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-10 17:24:52 --> Final output sent to browser
DEBUG - 2025-05-10 17:24:52 --> Total execution time: 0.0721
INFO - 2025-05-10 17:24:52 --> Config Class Initialized
INFO - 2025-05-10 17:24:52 --> Hooks Class Initialized
DEBUG - 2025-05-10 17:24:52 --> UTF-8 Support Enabled
INFO - 2025-05-10 17:24:52 --> Utf8 Class Initialized
INFO - 2025-05-10 17:24:52 --> URI Class Initialized
INFO - 2025-05-10 17:24:52 --> Router Class Initialized
INFO - 2025-05-10 17:24:52 --> Output Class Initialized
INFO - 2025-05-10 17:24:52 --> Security Class Initialized
DEBUG - 2025-05-10 17:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 17:24:52 --> Input Class Initialized
INFO - 2025-05-10 17:24:52 --> Language Class Initialized
ERROR - 2025-05-10 17:24:52 --> 404 Page Not Found: Auth/assets
INFO - 2025-05-10 17:26:56 --> Config Class Initialized
INFO - 2025-05-10 17:26:56 --> Hooks Class Initialized
DEBUG - 2025-05-10 17:26:56 --> UTF-8 Support Enabled
INFO - 2025-05-10 17:26:56 --> Utf8 Class Initialized
INFO - 2025-05-10 17:26:56 --> URI Class Initialized
INFO - 2025-05-10 17:26:56 --> Router Class Initialized
INFO - 2025-05-10 17:26:56 --> Output Class Initialized
INFO - 2025-05-10 17:26:56 --> Security Class Initialized
DEBUG - 2025-05-10 17:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 17:26:56 --> Input Class Initialized
INFO - 2025-05-10 17:26:56 --> Language Class Initialized
INFO - 2025-05-10 17:26:56 --> Loader Class Initialized
INFO - 2025-05-10 17:26:56 --> Helper loaded: url_helper
INFO - 2025-05-10 17:26:56 --> Helper loaded: form_helper
INFO - 2025-05-10 17:26:56 --> Database Driver Class Initialized
DEBUG - 2025-05-10 17:26:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 17:26:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 17:26:56 --> Controller Class Initialized
INFO - 2025-05-10 17:26:56 --> Model "User_model" initialized
INFO - 2025-05-10 17:26:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-10 17:26:56 --> Final output sent to browser
DEBUG - 2025-05-10 17:26:56 --> Total execution time: 0.0717
INFO - 2025-05-10 17:26:57 --> Config Class Initialized
INFO - 2025-05-10 17:26:57 --> Hooks Class Initialized
DEBUG - 2025-05-10 17:26:57 --> UTF-8 Support Enabled
INFO - 2025-05-10 17:26:57 --> Utf8 Class Initialized
INFO - 2025-05-10 17:26:57 --> URI Class Initialized
INFO - 2025-05-10 17:26:57 --> Router Class Initialized
INFO - 2025-05-10 17:26:57 --> Output Class Initialized
INFO - 2025-05-10 17:26:57 --> Security Class Initialized
DEBUG - 2025-05-10 17:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 17:26:57 --> Input Class Initialized
INFO - 2025-05-10 17:26:57 --> Language Class Initialized
ERROR - 2025-05-10 17:26:57 --> 404 Page Not Found: Auth/assets
INFO - 2025-05-10 17:26:58 --> Config Class Initialized
INFO - 2025-05-10 17:26:58 --> Hooks Class Initialized
DEBUG - 2025-05-10 17:26:58 --> UTF-8 Support Enabled
INFO - 2025-05-10 17:26:58 --> Utf8 Class Initialized
INFO - 2025-05-10 17:26:58 --> URI Class Initialized
INFO - 2025-05-10 17:26:58 --> Router Class Initialized
INFO - 2025-05-10 17:26:58 --> Output Class Initialized
INFO - 2025-05-10 17:26:58 --> Security Class Initialized
DEBUG - 2025-05-10 17:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 17:26:58 --> Input Class Initialized
INFO - 2025-05-10 17:26:58 --> Language Class Initialized
INFO - 2025-05-10 17:26:58 --> Loader Class Initialized
INFO - 2025-05-10 17:26:58 --> Helper loaded: url_helper
INFO - 2025-05-10 17:26:58 --> Helper loaded: form_helper
INFO - 2025-05-10 17:26:58 --> Database Driver Class Initialized
DEBUG - 2025-05-10 17:26:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 17:26:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 17:26:58 --> Controller Class Initialized
INFO - 2025-05-10 17:26:58 --> Model "User_model" initialized
INFO - 2025-05-10 17:26:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-10 17:26:58 --> Final output sent to browser
DEBUG - 2025-05-10 17:26:58 --> Total execution time: 0.0777
INFO - 2025-05-10 17:26:58 --> Config Class Initialized
INFO - 2025-05-10 17:26:58 --> Hooks Class Initialized
DEBUG - 2025-05-10 17:26:58 --> UTF-8 Support Enabled
INFO - 2025-05-10 17:26:58 --> Utf8 Class Initialized
INFO - 2025-05-10 17:26:58 --> URI Class Initialized
INFO - 2025-05-10 17:26:58 --> Router Class Initialized
INFO - 2025-05-10 17:26:58 --> Output Class Initialized
INFO - 2025-05-10 17:26:58 --> Security Class Initialized
DEBUG - 2025-05-10 17:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 17:26:58 --> Input Class Initialized
INFO - 2025-05-10 17:26:58 --> Language Class Initialized
ERROR - 2025-05-10 17:26:58 --> 404 Page Not Found: Auth/assets
INFO - 2025-05-10 17:27:19 --> Config Class Initialized
INFO - 2025-05-10 17:27:19 --> Hooks Class Initialized
DEBUG - 2025-05-10 17:27:19 --> UTF-8 Support Enabled
INFO - 2025-05-10 17:27:19 --> Utf8 Class Initialized
INFO - 2025-05-10 17:27:19 --> URI Class Initialized
INFO - 2025-05-10 17:27:19 --> Router Class Initialized
INFO - 2025-05-10 17:27:19 --> Output Class Initialized
INFO - 2025-05-10 17:27:19 --> Security Class Initialized
DEBUG - 2025-05-10 17:27:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 17:27:19 --> Input Class Initialized
INFO - 2025-05-10 17:27:19 --> Language Class Initialized
INFO - 2025-05-10 17:27:19 --> Loader Class Initialized
INFO - 2025-05-10 17:27:19 --> Helper loaded: url_helper
INFO - 2025-05-10 17:27:19 --> Helper loaded: form_helper
INFO - 2025-05-10 17:27:19 --> Database Driver Class Initialized
DEBUG - 2025-05-10 17:27:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 17:27:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 17:27:19 --> Controller Class Initialized
INFO - 2025-05-10 17:27:19 --> Model "User_model" initialized
INFO - 2025-05-10 17:27:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-10 17:27:19 --> Final output sent to browser
DEBUG - 2025-05-10 17:27:19 --> Total execution time: 0.0628
INFO - 2025-05-10 17:27:19 --> Config Class Initialized
INFO - 2025-05-10 17:27:19 --> Hooks Class Initialized
DEBUG - 2025-05-10 17:27:19 --> UTF-8 Support Enabled
INFO - 2025-05-10 17:27:19 --> Utf8 Class Initialized
INFO - 2025-05-10 17:27:19 --> URI Class Initialized
INFO - 2025-05-10 17:27:19 --> Router Class Initialized
INFO - 2025-05-10 17:27:19 --> Output Class Initialized
INFO - 2025-05-10 17:27:19 --> Security Class Initialized
DEBUG - 2025-05-10 17:27:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 17:27:19 --> Input Class Initialized
INFO - 2025-05-10 17:27:19 --> Language Class Initialized
ERROR - 2025-05-10 17:27:19 --> 404 Page Not Found: Auth/assets
INFO - 2025-05-10 17:28:20 --> Config Class Initialized
INFO - 2025-05-10 17:28:20 --> Hooks Class Initialized
DEBUG - 2025-05-10 17:28:20 --> UTF-8 Support Enabled
INFO - 2025-05-10 17:28:20 --> Utf8 Class Initialized
INFO - 2025-05-10 17:28:20 --> URI Class Initialized
INFO - 2025-05-10 17:28:20 --> Router Class Initialized
INFO - 2025-05-10 17:28:20 --> Output Class Initialized
INFO - 2025-05-10 17:28:20 --> Security Class Initialized
DEBUG - 2025-05-10 17:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 17:28:20 --> Input Class Initialized
INFO - 2025-05-10 17:28:20 --> Language Class Initialized
INFO - 2025-05-10 17:28:20 --> Loader Class Initialized
INFO - 2025-05-10 17:28:20 --> Helper loaded: url_helper
INFO - 2025-05-10 17:28:20 --> Helper loaded: form_helper
INFO - 2025-05-10 17:28:20 --> Database Driver Class Initialized
DEBUG - 2025-05-10 17:28:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 17:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 17:28:20 --> Controller Class Initialized
INFO - 2025-05-10 17:28:20 --> Model "User_model" initialized
INFO - 2025-05-10 17:28:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-10 17:28:20 --> Final output sent to browser
DEBUG - 2025-05-10 17:28:20 --> Total execution time: 0.0772
INFO - 2025-05-10 17:28:20 --> Config Class Initialized
INFO - 2025-05-10 17:28:20 --> Hooks Class Initialized
DEBUG - 2025-05-10 17:28:20 --> UTF-8 Support Enabled
INFO - 2025-05-10 17:28:20 --> Utf8 Class Initialized
INFO - 2025-05-10 17:28:20 --> URI Class Initialized
INFO - 2025-05-10 17:28:20 --> Router Class Initialized
INFO - 2025-05-10 17:28:20 --> Output Class Initialized
INFO - 2025-05-10 17:28:20 --> Security Class Initialized
DEBUG - 2025-05-10 17:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 17:28:20 --> Input Class Initialized
INFO - 2025-05-10 17:28:20 --> Language Class Initialized
ERROR - 2025-05-10 17:28:20 --> 404 Page Not Found: Auth/assets
INFO - 2025-05-10 17:35:48 --> Config Class Initialized
INFO - 2025-05-10 17:35:48 --> Hooks Class Initialized
DEBUG - 2025-05-10 17:35:48 --> UTF-8 Support Enabled
INFO - 2025-05-10 17:35:48 --> Utf8 Class Initialized
INFO - 2025-05-10 17:35:48 --> URI Class Initialized
INFO - 2025-05-10 17:35:48 --> Router Class Initialized
INFO - 2025-05-10 17:35:48 --> Output Class Initialized
INFO - 2025-05-10 17:35:48 --> Security Class Initialized
DEBUG - 2025-05-10 17:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 17:35:48 --> Input Class Initialized
INFO - 2025-05-10 17:35:48 --> Language Class Initialized
INFO - 2025-05-10 17:35:48 --> Loader Class Initialized
INFO - 2025-05-10 17:35:48 --> Helper loaded: url_helper
INFO - 2025-05-10 17:35:48 --> Helper loaded: form_helper
INFO - 2025-05-10 17:35:48 --> Database Driver Class Initialized
DEBUG - 2025-05-10 17:35:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 17:35:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 17:35:48 --> Controller Class Initialized
INFO - 2025-05-10 17:35:48 --> Model "User_model" initialized
INFO - 2025-05-10 17:35:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-10 17:35:48 --> Final output sent to browser
DEBUG - 2025-05-10 17:35:48 --> Total execution time: 0.0728
INFO - 2025-05-10 17:35:48 --> Config Class Initialized
INFO - 2025-05-10 17:35:48 --> Hooks Class Initialized
DEBUG - 2025-05-10 17:35:48 --> UTF-8 Support Enabled
INFO - 2025-05-10 17:35:48 --> Utf8 Class Initialized
INFO - 2025-05-10 17:35:48 --> URI Class Initialized
INFO - 2025-05-10 17:35:48 --> Router Class Initialized
INFO - 2025-05-10 17:35:48 --> Output Class Initialized
INFO - 2025-05-10 17:35:48 --> Security Class Initialized
DEBUG - 2025-05-10 17:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 17:35:48 --> Input Class Initialized
INFO - 2025-05-10 17:35:48 --> Language Class Initialized
ERROR - 2025-05-10 17:35:48 --> 404 Page Not Found: Auth/assets
INFO - 2025-05-10 17:36:22 --> Config Class Initialized
INFO - 2025-05-10 17:36:22 --> Hooks Class Initialized
DEBUG - 2025-05-10 17:36:22 --> UTF-8 Support Enabled
INFO - 2025-05-10 17:36:22 --> Utf8 Class Initialized
INFO - 2025-05-10 17:36:22 --> URI Class Initialized
INFO - 2025-05-10 17:36:22 --> Router Class Initialized
INFO - 2025-05-10 17:36:22 --> Output Class Initialized
INFO - 2025-05-10 17:36:22 --> Security Class Initialized
DEBUG - 2025-05-10 17:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 17:36:22 --> Input Class Initialized
INFO - 2025-05-10 17:36:22 --> Language Class Initialized
INFO - 2025-05-10 17:36:22 --> Loader Class Initialized
INFO - 2025-05-10 17:36:22 --> Helper loaded: url_helper
INFO - 2025-05-10 17:36:22 --> Helper loaded: form_helper
INFO - 2025-05-10 17:36:22 --> Database Driver Class Initialized
DEBUG - 2025-05-10 17:36:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 17:36:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 17:36:22 --> Controller Class Initialized
INFO - 2025-05-10 17:36:22 --> Model "User_model" initialized
INFO - 2025-05-10 17:36:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-10 17:36:22 --> Final output sent to browser
DEBUG - 2025-05-10 17:36:22 --> Total execution time: 0.0766
INFO - 2025-05-10 17:36:22 --> Config Class Initialized
INFO - 2025-05-10 17:36:22 --> Hooks Class Initialized
DEBUG - 2025-05-10 17:36:22 --> UTF-8 Support Enabled
INFO - 2025-05-10 17:36:22 --> Utf8 Class Initialized
INFO - 2025-05-10 17:36:22 --> URI Class Initialized
INFO - 2025-05-10 17:36:22 --> Router Class Initialized
INFO - 2025-05-10 17:36:22 --> Output Class Initialized
INFO - 2025-05-10 17:36:22 --> Security Class Initialized
DEBUG - 2025-05-10 17:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 17:36:22 --> Input Class Initialized
INFO - 2025-05-10 17:36:22 --> Language Class Initialized
ERROR - 2025-05-10 17:36:22 --> 404 Page Not Found: Auth/assets
INFO - 2025-05-10 17:36:40 --> Config Class Initialized
INFO - 2025-05-10 17:36:40 --> Hooks Class Initialized
DEBUG - 2025-05-10 17:36:40 --> UTF-8 Support Enabled
INFO - 2025-05-10 17:36:40 --> Utf8 Class Initialized
INFO - 2025-05-10 17:36:40 --> URI Class Initialized
INFO - 2025-05-10 17:36:40 --> Router Class Initialized
INFO - 2025-05-10 17:36:40 --> Output Class Initialized
INFO - 2025-05-10 17:36:40 --> Security Class Initialized
DEBUG - 2025-05-10 17:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 17:36:40 --> Input Class Initialized
INFO - 2025-05-10 17:36:40 --> Language Class Initialized
INFO - 2025-05-10 17:36:40 --> Loader Class Initialized
INFO - 2025-05-10 17:36:40 --> Helper loaded: url_helper
INFO - 2025-05-10 17:36:40 --> Helper loaded: form_helper
INFO - 2025-05-10 17:36:40 --> Database Driver Class Initialized
DEBUG - 2025-05-10 17:36:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 17:36:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 17:36:40 --> Controller Class Initialized
INFO - 2025-05-10 17:36:40 --> Model "User_model" initialized
INFO - 2025-05-10 17:36:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-10 17:36:40 --> Final output sent to browser
DEBUG - 2025-05-10 17:36:40 --> Total execution time: 0.0688
INFO - 2025-05-10 17:36:40 --> Config Class Initialized
INFO - 2025-05-10 17:36:40 --> Hooks Class Initialized
DEBUG - 2025-05-10 17:36:40 --> UTF-8 Support Enabled
INFO - 2025-05-10 17:36:40 --> Utf8 Class Initialized
INFO - 2025-05-10 17:36:40 --> URI Class Initialized
INFO - 2025-05-10 17:36:40 --> Router Class Initialized
INFO - 2025-05-10 17:36:40 --> Output Class Initialized
INFO - 2025-05-10 17:36:40 --> Security Class Initialized
DEBUG - 2025-05-10 17:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 17:36:40 --> Input Class Initialized
INFO - 2025-05-10 17:36:40 --> Language Class Initialized
ERROR - 2025-05-10 17:36:40 --> 404 Page Not Found: Auth/assets
INFO - 2025-05-10 17:36:50 --> Config Class Initialized
INFO - 2025-05-10 17:36:50 --> Hooks Class Initialized
DEBUG - 2025-05-10 17:36:50 --> UTF-8 Support Enabled
INFO - 2025-05-10 17:36:50 --> Utf8 Class Initialized
INFO - 2025-05-10 17:36:50 --> URI Class Initialized
INFO - 2025-05-10 17:36:50 --> Router Class Initialized
INFO - 2025-05-10 17:36:50 --> Output Class Initialized
INFO - 2025-05-10 17:36:50 --> Security Class Initialized
DEBUG - 2025-05-10 17:36:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 17:36:50 --> Input Class Initialized
INFO - 2025-05-10 17:36:50 --> Language Class Initialized
INFO - 2025-05-10 17:36:50 --> Loader Class Initialized
INFO - 2025-05-10 17:36:50 --> Helper loaded: url_helper
INFO - 2025-05-10 17:36:50 --> Helper loaded: form_helper
INFO - 2025-05-10 17:36:50 --> Database Driver Class Initialized
DEBUG - 2025-05-10 17:36:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 17:36:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 17:36:50 --> Controller Class Initialized
INFO - 2025-05-10 17:36:50 --> Model "User_model" initialized
INFO - 2025-05-10 17:36:50 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-10 17:36:50 --> Final output sent to browser
DEBUG - 2025-05-10 17:36:50 --> Total execution time: 0.0763
INFO - 2025-05-10 17:36:50 --> Config Class Initialized
INFO - 2025-05-10 17:36:50 --> Hooks Class Initialized
DEBUG - 2025-05-10 17:36:50 --> UTF-8 Support Enabled
INFO - 2025-05-10 17:36:50 --> Utf8 Class Initialized
INFO - 2025-05-10 17:36:50 --> URI Class Initialized
INFO - 2025-05-10 17:36:50 --> Router Class Initialized
INFO - 2025-05-10 17:36:50 --> Output Class Initialized
INFO - 2025-05-10 17:36:50 --> Security Class Initialized
DEBUG - 2025-05-10 17:36:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 17:36:50 --> Input Class Initialized
INFO - 2025-05-10 17:36:50 --> Language Class Initialized
ERROR - 2025-05-10 17:36:50 --> 404 Page Not Found: Auth/assets
INFO - 2025-05-10 17:36:51 --> Config Class Initialized
INFO - 2025-05-10 17:36:51 --> Hooks Class Initialized
DEBUG - 2025-05-10 17:36:51 --> UTF-8 Support Enabled
INFO - 2025-05-10 17:36:51 --> Utf8 Class Initialized
INFO - 2025-05-10 17:36:51 --> URI Class Initialized
INFO - 2025-05-10 17:36:51 --> Router Class Initialized
INFO - 2025-05-10 17:36:51 --> Output Class Initialized
INFO - 2025-05-10 17:36:51 --> Security Class Initialized
DEBUG - 2025-05-10 17:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 17:36:51 --> Input Class Initialized
INFO - 2025-05-10 17:36:51 --> Language Class Initialized
INFO - 2025-05-10 17:36:51 --> Loader Class Initialized
INFO - 2025-05-10 17:36:51 --> Helper loaded: url_helper
INFO - 2025-05-10 17:36:51 --> Helper loaded: form_helper
INFO - 2025-05-10 17:36:51 --> Database Driver Class Initialized
DEBUG - 2025-05-10 17:36:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 17:36:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 17:36:51 --> Controller Class Initialized
INFO - 2025-05-10 17:36:51 --> Model "User_model" initialized
INFO - 2025-05-10 17:36:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-10 17:36:51 --> Final output sent to browser
DEBUG - 2025-05-10 17:36:51 --> Total execution time: 0.0660
INFO - 2025-05-10 17:36:51 --> Config Class Initialized
INFO - 2025-05-10 17:36:51 --> Hooks Class Initialized
DEBUG - 2025-05-10 17:36:51 --> UTF-8 Support Enabled
INFO - 2025-05-10 17:36:51 --> Utf8 Class Initialized
INFO - 2025-05-10 17:36:51 --> URI Class Initialized
INFO - 2025-05-10 17:36:51 --> Router Class Initialized
INFO - 2025-05-10 17:36:51 --> Output Class Initialized
INFO - 2025-05-10 17:36:51 --> Security Class Initialized
DEBUG - 2025-05-10 17:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 17:36:51 --> Input Class Initialized
INFO - 2025-05-10 17:36:51 --> Language Class Initialized
ERROR - 2025-05-10 17:36:51 --> 404 Page Not Found: Auth/assets
INFO - 2025-05-10 17:36:59 --> Config Class Initialized
INFO - 2025-05-10 17:36:59 --> Hooks Class Initialized
DEBUG - 2025-05-10 17:36:59 --> UTF-8 Support Enabled
INFO - 2025-05-10 17:36:59 --> Utf8 Class Initialized
INFO - 2025-05-10 17:36:59 --> URI Class Initialized
INFO - 2025-05-10 17:36:59 --> Router Class Initialized
INFO - 2025-05-10 17:36:59 --> Output Class Initialized
INFO - 2025-05-10 17:36:59 --> Security Class Initialized
DEBUG - 2025-05-10 17:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 17:36:59 --> Input Class Initialized
INFO - 2025-05-10 17:36:59 --> Language Class Initialized
INFO - 2025-05-10 17:36:59 --> Loader Class Initialized
INFO - 2025-05-10 17:36:59 --> Helper loaded: url_helper
INFO - 2025-05-10 17:36:59 --> Helper loaded: form_helper
INFO - 2025-05-10 17:36:59 --> Database Driver Class Initialized
DEBUG - 2025-05-10 17:36:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 17:36:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 17:36:59 --> Controller Class Initialized
INFO - 2025-05-10 17:36:59 --> Model "User_model" initialized
INFO - 2025-05-10 17:36:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-10 17:36:59 --> Final output sent to browser
DEBUG - 2025-05-10 17:36:59 --> Total execution time: 0.0813
INFO - 2025-05-10 17:36:59 --> Config Class Initialized
INFO - 2025-05-10 17:36:59 --> Hooks Class Initialized
DEBUG - 2025-05-10 17:36:59 --> UTF-8 Support Enabled
INFO - 2025-05-10 17:36:59 --> Utf8 Class Initialized
INFO - 2025-05-10 17:36:59 --> URI Class Initialized
INFO - 2025-05-10 17:36:59 --> Router Class Initialized
INFO - 2025-05-10 17:36:59 --> Output Class Initialized
INFO - 2025-05-10 17:36:59 --> Security Class Initialized
DEBUG - 2025-05-10 17:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 17:36:59 --> Input Class Initialized
INFO - 2025-05-10 17:36:59 --> Language Class Initialized
ERROR - 2025-05-10 17:36:59 --> 404 Page Not Found: Auth/assets
INFO - 2025-05-10 17:39:15 --> Config Class Initialized
INFO - 2025-05-10 17:39:15 --> Hooks Class Initialized
DEBUG - 2025-05-10 17:39:15 --> UTF-8 Support Enabled
INFO - 2025-05-10 17:39:15 --> Utf8 Class Initialized
INFO - 2025-05-10 17:39:15 --> URI Class Initialized
DEBUG - 2025-05-10 17:39:15 --> No URI present. Default controller set.
INFO - 2025-05-10 17:39:15 --> Router Class Initialized
INFO - 2025-05-10 17:39:15 --> Output Class Initialized
INFO - 2025-05-10 17:39:15 --> Security Class Initialized
DEBUG - 2025-05-10 17:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 17:39:15 --> Input Class Initialized
INFO - 2025-05-10 17:39:15 --> Language Class Initialized
INFO - 2025-05-10 17:39:15 --> Loader Class Initialized
INFO - 2025-05-10 17:39:15 --> Helper loaded: url_helper
INFO - 2025-05-10 17:39:15 --> Helper loaded: form_helper
INFO - 2025-05-10 17:39:15 --> Database Driver Class Initialized
DEBUG - 2025-05-10 17:39:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 17:39:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 17:39:15 --> Controller Class Initialized
INFO - 2025-05-10 17:39:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-10 17:39:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-10 17:39:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-10 17:39:15 --> Final output sent to browser
DEBUG - 2025-05-10 17:39:15 --> Total execution time: 0.0758
INFO - 2025-05-10 17:46:54 --> Config Class Initialized
INFO - 2025-05-10 17:46:54 --> Hooks Class Initialized
DEBUG - 2025-05-10 17:46:54 --> UTF-8 Support Enabled
INFO - 2025-05-10 17:46:54 --> Utf8 Class Initialized
INFO - 2025-05-10 17:46:54 --> URI Class Initialized
INFO - 2025-05-10 17:46:54 --> Router Class Initialized
INFO - 2025-05-10 17:46:54 --> Output Class Initialized
INFO - 2025-05-10 17:46:54 --> Security Class Initialized
DEBUG - 2025-05-10 17:46:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 17:46:54 --> Input Class Initialized
INFO - 2025-05-10 17:46:54 --> Language Class Initialized
INFO - 2025-05-10 17:46:54 --> Loader Class Initialized
INFO - 2025-05-10 17:46:54 --> Helper loaded: url_helper
INFO - 2025-05-10 17:46:54 --> Helper loaded: form_helper
INFO - 2025-05-10 17:46:54 --> Database Driver Class Initialized
DEBUG - 2025-05-10 17:46:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 17:46:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 17:46:54 --> Controller Class Initialized
INFO - 2025-05-10 17:46:54 --> Model "User_model" initialized
INFO - 2025-05-10 17:46:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-10 17:46:54 --> Final output sent to browser
DEBUG - 2025-05-10 17:46:54 --> Total execution time: 0.1027
INFO - 2025-05-10 17:48:03 --> Config Class Initialized
INFO - 2025-05-10 17:48:03 --> Hooks Class Initialized
DEBUG - 2025-05-10 17:48:03 --> UTF-8 Support Enabled
INFO - 2025-05-10 17:48:03 --> Utf8 Class Initialized
INFO - 2025-05-10 17:48:03 --> URI Class Initialized
INFO - 2025-05-10 17:48:03 --> Router Class Initialized
INFO - 2025-05-10 17:48:03 --> Output Class Initialized
INFO - 2025-05-10 17:48:03 --> Security Class Initialized
DEBUG - 2025-05-10 17:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 17:48:03 --> Input Class Initialized
INFO - 2025-05-10 17:48:03 --> Language Class Initialized
INFO - 2025-05-10 17:48:03 --> Loader Class Initialized
INFO - 2025-05-10 17:48:03 --> Helper loaded: url_helper
INFO - 2025-05-10 17:48:03 --> Helper loaded: form_helper
INFO - 2025-05-10 17:48:03 --> Database Driver Class Initialized
DEBUG - 2025-05-10 17:48:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 17:48:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 17:48:04 --> Controller Class Initialized
INFO - 2025-05-10 17:48:04 --> Model "User_model" initialized
INFO - 2025-05-10 17:48:04 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-10 17:48:04 --> Final output sent to browser
DEBUG - 2025-05-10 17:48:04 --> Total execution time: 0.0786
INFO - 2025-05-10 17:51:35 --> Config Class Initialized
INFO - 2025-05-10 17:51:35 --> Hooks Class Initialized
DEBUG - 2025-05-10 17:51:35 --> UTF-8 Support Enabled
INFO - 2025-05-10 17:51:35 --> Utf8 Class Initialized
INFO - 2025-05-10 17:51:35 --> URI Class Initialized
INFO - 2025-05-10 17:51:35 --> Router Class Initialized
INFO - 2025-05-10 17:51:35 --> Output Class Initialized
INFO - 2025-05-10 17:51:35 --> Security Class Initialized
DEBUG - 2025-05-10 17:51:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 17:51:35 --> Input Class Initialized
INFO - 2025-05-10 17:51:35 --> Language Class Initialized
INFO - 2025-05-10 17:51:35 --> Loader Class Initialized
INFO - 2025-05-10 17:51:35 --> Helper loaded: url_helper
INFO - 2025-05-10 17:51:35 --> Helper loaded: form_helper
INFO - 2025-05-10 17:51:35 --> Database Driver Class Initialized
DEBUG - 2025-05-10 17:51:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 17:51:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 17:51:35 --> Controller Class Initialized
INFO - 2025-05-10 17:51:35 --> Model "User_model" initialized
INFO - 2025-05-10 17:51:35 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-10 17:51:35 --> Final output sent to browser
DEBUG - 2025-05-10 17:51:35 --> Total execution time: 0.1089
INFO - 2025-05-10 17:55:45 --> Config Class Initialized
INFO - 2025-05-10 17:55:45 --> Hooks Class Initialized
DEBUG - 2025-05-10 17:55:45 --> UTF-8 Support Enabled
INFO - 2025-05-10 17:55:45 --> Utf8 Class Initialized
INFO - 2025-05-10 17:55:45 --> URI Class Initialized
INFO - 2025-05-10 17:55:45 --> Router Class Initialized
INFO - 2025-05-10 17:55:45 --> Output Class Initialized
INFO - 2025-05-10 17:55:45 --> Security Class Initialized
DEBUG - 2025-05-10 17:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 17:55:45 --> Input Class Initialized
INFO - 2025-05-10 17:55:45 --> Language Class Initialized
INFO - 2025-05-10 17:55:45 --> Loader Class Initialized
INFO - 2025-05-10 17:55:45 --> Helper loaded: url_helper
INFO - 2025-05-10 17:55:45 --> Helper loaded: form_helper
INFO - 2025-05-10 17:55:45 --> Database Driver Class Initialized
DEBUG - 2025-05-10 17:55:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 17:55:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 17:55:45 --> Controller Class Initialized
INFO - 2025-05-10 17:55:45 --> Model "User_model" initialized
INFO - 2025-05-10 17:55:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-10 17:55:45 --> Final output sent to browser
DEBUG - 2025-05-10 17:55:45 --> Total execution time: 0.0991
INFO - 2025-05-10 17:55:59 --> Config Class Initialized
INFO - 2025-05-10 17:55:59 --> Hooks Class Initialized
DEBUG - 2025-05-10 17:55:59 --> UTF-8 Support Enabled
INFO - 2025-05-10 17:55:59 --> Utf8 Class Initialized
INFO - 2025-05-10 17:55:59 --> URI Class Initialized
INFO - 2025-05-10 17:55:59 --> Router Class Initialized
INFO - 2025-05-10 17:55:59 --> Output Class Initialized
INFO - 2025-05-10 17:55:59 --> Security Class Initialized
DEBUG - 2025-05-10 17:55:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 17:55:59 --> Input Class Initialized
INFO - 2025-05-10 17:55:59 --> Language Class Initialized
INFO - 2025-05-10 17:55:59 --> Loader Class Initialized
INFO - 2025-05-10 17:55:59 --> Helper loaded: url_helper
INFO - 2025-05-10 17:55:59 --> Helper loaded: form_helper
INFO - 2025-05-10 17:55:59 --> Database Driver Class Initialized
DEBUG - 2025-05-10 17:55:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 17:55:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 17:55:59 --> Controller Class Initialized
INFO - 2025-05-10 17:55:59 --> Model "User_model" initialized
INFO - 2025-05-10 17:56:00 --> Config Class Initialized
INFO - 2025-05-10 17:56:00 --> Hooks Class Initialized
DEBUG - 2025-05-10 17:56:00 --> UTF-8 Support Enabled
INFO - 2025-05-10 17:56:00 --> Utf8 Class Initialized
INFO - 2025-05-10 17:56:00 --> URI Class Initialized
INFO - 2025-05-10 17:56:00 --> Router Class Initialized
INFO - 2025-05-10 17:56:00 --> Output Class Initialized
INFO - 2025-05-10 17:56:00 --> Security Class Initialized
DEBUG - 2025-05-10 17:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-10 17:56:00 --> Input Class Initialized
INFO - 2025-05-10 17:56:00 --> Language Class Initialized
INFO - 2025-05-10 17:56:00 --> Loader Class Initialized
INFO - 2025-05-10 17:56:00 --> Helper loaded: url_helper
INFO - 2025-05-10 17:56:00 --> Helper loaded: form_helper
INFO - 2025-05-10 17:56:00 --> Database Driver Class Initialized
DEBUG - 2025-05-10 17:56:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-10 17:56:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-10 17:56:00 --> Controller Class Initialized
INFO - 2025-05-10 17:56:00 --> Model "User_model" initialized
INFO - 2025-05-10 17:56:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard.php
INFO - 2025-05-10 17:56:00 --> Final output sent to browser
DEBUG - 2025-05-10 17:56:00 --> Total execution time: 0.0720
