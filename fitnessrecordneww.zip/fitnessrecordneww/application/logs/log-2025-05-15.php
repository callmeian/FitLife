<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-05-15 12:48:11 --> Config Class Initialized
INFO - 2025-05-15 12:48:11 --> Hooks Class Initialized
DEBUG - 2025-05-15 12:48:11 --> UTF-8 Support Enabled
INFO - 2025-05-15 12:48:11 --> Utf8 Class Initialized
INFO - 2025-05-15 12:48:11 --> URI Class Initialized
DEBUG - 2025-05-15 12:48:11 --> No URI present. Default controller set.
INFO - 2025-05-15 12:48:11 --> Router Class Initialized
INFO - 2025-05-15 12:48:11 --> Output Class Initialized
INFO - 2025-05-15 12:48:11 --> Security Class Initialized
DEBUG - 2025-05-15 12:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 12:48:11 --> Input Class Initialized
INFO - 2025-05-15 12:48:11 --> Language Class Initialized
INFO - 2025-05-15 12:48:11 --> Loader Class Initialized
INFO - 2025-05-15 12:48:11 --> Helper loaded: url_helper
INFO - 2025-05-15 12:48:11 --> Helper loaded: form_helper
INFO - 2025-05-15 12:48:11 --> Database Driver Class Initialized
DEBUG - 2025-05-15 12:48:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 12:48:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 12:48:11 --> Controller Class Initialized
INFO - 2025-05-15 12:48:11 --> Model "User_model" initialized
INFO - 2025-05-15 12:48:11 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-15 12:48:11 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-15 12:48:11 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-15 12:48:11 --> Final output sent to browser
DEBUG - 2025-05-15 12:48:11 --> Total execution time: 0.1422
INFO - 2025-05-15 12:48:13 --> Config Class Initialized
INFO - 2025-05-15 12:48:13 --> Hooks Class Initialized
DEBUG - 2025-05-15 12:48:13 --> UTF-8 Support Enabled
INFO - 2025-05-15 12:48:13 --> Utf8 Class Initialized
INFO - 2025-05-15 12:48:13 --> URI Class Initialized
INFO - 2025-05-15 12:48:13 --> Router Class Initialized
INFO - 2025-05-15 12:48:13 --> Output Class Initialized
INFO - 2025-05-15 12:48:13 --> Security Class Initialized
DEBUG - 2025-05-15 12:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 12:48:13 --> Input Class Initialized
INFO - 2025-05-15 12:48:13 --> Language Class Initialized
INFO - 2025-05-15 12:48:13 --> Loader Class Initialized
INFO - 2025-05-15 12:48:13 --> Helper loaded: url_helper
INFO - 2025-05-15 12:48:13 --> Helper loaded: form_helper
INFO - 2025-05-15 12:48:13 --> Database Driver Class Initialized
DEBUG - 2025-05-15 12:48:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 12:48:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 12:48:13 --> Controller Class Initialized
INFO - 2025-05-15 12:48:13 --> Model "User_model" initialized
INFO - 2025-05-15 12:48:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-15 12:48:13 --> Final output sent to browser
DEBUG - 2025-05-15 12:48:13 --> Total execution time: 0.0748
INFO - 2025-05-15 12:48:20 --> Config Class Initialized
INFO - 2025-05-15 12:48:20 --> Hooks Class Initialized
DEBUG - 2025-05-15 12:48:20 --> UTF-8 Support Enabled
INFO - 2025-05-15 12:48:20 --> Utf8 Class Initialized
INFO - 2025-05-15 12:48:20 --> URI Class Initialized
INFO - 2025-05-15 12:48:20 --> Router Class Initialized
INFO - 2025-05-15 12:48:20 --> Output Class Initialized
INFO - 2025-05-15 12:48:20 --> Security Class Initialized
DEBUG - 2025-05-15 12:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 12:48:20 --> Input Class Initialized
INFO - 2025-05-15 12:48:20 --> Language Class Initialized
INFO - 2025-05-15 12:48:20 --> Loader Class Initialized
INFO - 2025-05-15 12:48:20 --> Helper loaded: url_helper
INFO - 2025-05-15 12:48:20 --> Helper loaded: form_helper
INFO - 2025-05-15 12:48:20 --> Database Driver Class Initialized
DEBUG - 2025-05-15 12:48:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 12:48:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 12:48:20 --> Controller Class Initialized
INFO - 2025-05-15 12:48:20 --> Model "User_model" initialized
INFO - 2025-05-15 12:48:20 --> Config Class Initialized
INFO - 2025-05-15 12:48:20 --> Hooks Class Initialized
DEBUG - 2025-05-15 12:48:20 --> UTF-8 Support Enabled
INFO - 2025-05-15 12:48:20 --> Utf8 Class Initialized
INFO - 2025-05-15 12:48:20 --> URI Class Initialized
INFO - 2025-05-15 12:48:20 --> Router Class Initialized
INFO - 2025-05-15 12:48:20 --> Output Class Initialized
INFO - 2025-05-15 12:48:20 --> Security Class Initialized
DEBUG - 2025-05-15 12:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 12:48:20 --> Input Class Initialized
INFO - 2025-05-15 12:48:20 --> Language Class Initialized
INFO - 2025-05-15 12:48:20 --> Loader Class Initialized
INFO - 2025-05-15 12:48:20 --> Helper loaded: url_helper
INFO - 2025-05-15 12:48:20 --> Helper loaded: form_helper
INFO - 2025-05-15 12:48:20 --> Database Driver Class Initialized
DEBUG - 2025-05-15 12:48:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 12:48:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 12:48:20 --> Controller Class Initialized
INFO - 2025-05-15 12:48:20 --> Model "User_model" initialized
INFO - 2025-05-15 12:48:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-15 12:48:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-15 12:48:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-15 12:48:20 --> Final output sent to browser
DEBUG - 2025-05-15 12:48:20 --> Total execution time: 0.0888
INFO - 2025-05-15 12:48:22 --> Config Class Initialized
INFO - 2025-05-15 12:48:22 --> Hooks Class Initialized
DEBUG - 2025-05-15 12:48:22 --> UTF-8 Support Enabled
INFO - 2025-05-15 12:48:22 --> Utf8 Class Initialized
INFO - 2025-05-15 12:48:22 --> URI Class Initialized
INFO - 2025-05-15 12:48:22 --> Router Class Initialized
INFO - 2025-05-15 12:48:22 --> Output Class Initialized
INFO - 2025-05-15 12:48:22 --> Security Class Initialized
DEBUG - 2025-05-15 12:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 12:48:22 --> Input Class Initialized
INFO - 2025-05-15 12:48:22 --> Language Class Initialized
INFO - 2025-05-15 12:48:22 --> Loader Class Initialized
INFO - 2025-05-15 12:48:22 --> Helper loaded: url_helper
INFO - 2025-05-15 12:48:22 --> Helper loaded: form_helper
INFO - 2025-05-15 12:48:22 --> Database Driver Class Initialized
DEBUG - 2025-05-15 12:48:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 12:48:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 12:48:22 --> Controller Class Initialized
INFO - 2025-05-15 12:48:22 --> Model "User_model" initialized
INFO - 2025-05-15 12:48:22 --> Model "Workout_model" initialized
INFO - 2025-05-15 12:48:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 12:48:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 12:48:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-15 12:48:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 12:48:22 --> Final output sent to browser
DEBUG - 2025-05-15 12:48:22 --> Total execution time: 0.0864
INFO - 2025-05-15 12:48:25 --> Config Class Initialized
INFO - 2025-05-15 12:48:25 --> Hooks Class Initialized
DEBUG - 2025-05-15 12:48:25 --> UTF-8 Support Enabled
INFO - 2025-05-15 12:48:25 --> Utf8 Class Initialized
INFO - 2025-05-15 12:48:25 --> URI Class Initialized
INFO - 2025-05-15 12:48:25 --> Router Class Initialized
INFO - 2025-05-15 12:48:25 --> Output Class Initialized
INFO - 2025-05-15 12:48:25 --> Security Class Initialized
DEBUG - 2025-05-15 12:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 12:48:25 --> Input Class Initialized
INFO - 2025-05-15 12:48:25 --> Language Class Initialized
INFO - 2025-05-15 12:48:25 --> Loader Class Initialized
INFO - 2025-05-15 12:48:25 --> Helper loaded: url_helper
INFO - 2025-05-15 12:48:25 --> Helper loaded: form_helper
INFO - 2025-05-15 12:48:25 --> Database Driver Class Initialized
DEBUG - 2025-05-15 12:48:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 12:48:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 12:48:25 --> Controller Class Initialized
INFO - 2025-05-15 12:48:25 --> Model "User_model" initialized
INFO - 2025-05-15 12:48:25 --> Model "Workout_model" initialized
INFO - 2025-05-15 12:48:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 12:48:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 12:48:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-15 12:48:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 12:48:25 --> Final output sent to browser
DEBUG - 2025-05-15 12:48:25 --> Total execution time: 0.0825
INFO - 2025-05-15 12:48:30 --> Config Class Initialized
INFO - 2025-05-15 12:48:30 --> Hooks Class Initialized
DEBUG - 2025-05-15 12:48:30 --> UTF-8 Support Enabled
INFO - 2025-05-15 12:48:30 --> Utf8 Class Initialized
INFO - 2025-05-15 12:48:30 --> URI Class Initialized
INFO - 2025-05-15 12:48:30 --> Router Class Initialized
INFO - 2025-05-15 12:48:30 --> Output Class Initialized
INFO - 2025-05-15 12:48:30 --> Security Class Initialized
DEBUG - 2025-05-15 12:48:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 12:48:30 --> Input Class Initialized
INFO - 2025-05-15 12:48:30 --> Language Class Initialized
INFO - 2025-05-15 12:48:30 --> Loader Class Initialized
INFO - 2025-05-15 12:48:30 --> Helper loaded: url_helper
INFO - 2025-05-15 12:48:30 --> Helper loaded: form_helper
INFO - 2025-05-15 12:48:30 --> Database Driver Class Initialized
DEBUG - 2025-05-15 12:48:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 12:48:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 12:48:30 --> Controller Class Initialized
INFO - 2025-05-15 12:48:30 --> Model "User_model" initialized
INFO - 2025-05-15 12:48:30 --> Model "Workout_model" initialized
INFO - 2025-05-15 12:48:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 12:48:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 12:48:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-15 12:48:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 12:48:30 --> Final output sent to browser
DEBUG - 2025-05-15 12:48:30 --> Total execution time: 0.0883
INFO - 2025-05-15 12:48:41 --> Config Class Initialized
INFO - 2025-05-15 12:48:41 --> Hooks Class Initialized
DEBUG - 2025-05-15 12:48:41 --> UTF-8 Support Enabled
INFO - 2025-05-15 12:48:41 --> Utf8 Class Initialized
INFO - 2025-05-15 12:48:41 --> URI Class Initialized
INFO - 2025-05-15 12:48:41 --> Router Class Initialized
INFO - 2025-05-15 12:48:41 --> Output Class Initialized
INFO - 2025-05-15 12:48:41 --> Security Class Initialized
DEBUG - 2025-05-15 12:48:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 12:48:41 --> Input Class Initialized
INFO - 2025-05-15 12:48:41 --> Language Class Initialized
INFO - 2025-05-15 12:48:41 --> Loader Class Initialized
INFO - 2025-05-15 12:48:41 --> Helper loaded: url_helper
INFO - 2025-05-15 12:48:41 --> Helper loaded: form_helper
INFO - 2025-05-15 12:48:41 --> Database Driver Class Initialized
DEBUG - 2025-05-15 12:48:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 12:48:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 12:48:41 --> Controller Class Initialized
INFO - 2025-05-15 12:48:41 --> Model "User_model" initialized
INFO - 2025-05-15 12:48:41 --> Model "Workout_model" initialized
INFO - 2025-05-15 12:48:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 12:48:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 12:48:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-15 12:48:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 12:48:41 --> Final output sent to browser
DEBUG - 2025-05-15 12:48:41 --> Total execution time: 0.0709
INFO - 2025-05-15 12:51:04 --> Config Class Initialized
INFO - 2025-05-15 12:51:04 --> Hooks Class Initialized
DEBUG - 2025-05-15 12:51:04 --> UTF-8 Support Enabled
INFO - 2025-05-15 12:51:04 --> Utf8 Class Initialized
INFO - 2025-05-15 12:51:04 --> URI Class Initialized
INFO - 2025-05-15 12:51:04 --> Router Class Initialized
INFO - 2025-05-15 12:51:04 --> Output Class Initialized
INFO - 2025-05-15 12:51:04 --> Security Class Initialized
DEBUG - 2025-05-15 12:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 12:51:04 --> Input Class Initialized
INFO - 2025-05-15 12:51:04 --> Language Class Initialized
INFO - 2025-05-15 12:51:04 --> Loader Class Initialized
INFO - 2025-05-15 12:51:04 --> Helper loaded: url_helper
INFO - 2025-05-15 12:51:04 --> Helper loaded: form_helper
INFO - 2025-05-15 12:51:04 --> Database Driver Class Initialized
DEBUG - 2025-05-15 12:51:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 12:51:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 12:51:04 --> Controller Class Initialized
INFO - 2025-05-15 12:51:04 --> Model "Workout_model" initialized
INFO - 2025-05-15 12:51:04 --> Model "User_model" initialized
INFO - 2025-05-15 12:51:04 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 12:51:04 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 12:51:04 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-15 12:51:04 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 12:51:04 --> Final output sent to browser
DEBUG - 2025-05-15 12:51:04 --> Total execution time: 0.0895
INFO - 2025-05-15 13:17:30 --> Config Class Initialized
INFO - 2025-05-15 13:17:30 --> Hooks Class Initialized
DEBUG - 2025-05-15 13:17:30 --> UTF-8 Support Enabled
INFO - 2025-05-15 13:17:30 --> Utf8 Class Initialized
INFO - 2025-05-15 13:17:30 --> URI Class Initialized
INFO - 2025-05-15 13:17:30 --> Router Class Initialized
INFO - 2025-05-15 13:17:30 --> Output Class Initialized
INFO - 2025-05-15 13:17:30 --> Security Class Initialized
DEBUG - 2025-05-15 13:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 13:17:30 --> Input Class Initialized
INFO - 2025-05-15 13:17:30 --> Language Class Initialized
ERROR - 2025-05-15 13:17:31 --> 404 Page Not Found: Beta/calender
INFO - 2025-05-15 13:17:43 --> Config Class Initialized
INFO - 2025-05-15 13:17:43 --> Hooks Class Initialized
DEBUG - 2025-05-15 13:17:43 --> UTF-8 Support Enabled
INFO - 2025-05-15 13:17:43 --> Utf8 Class Initialized
INFO - 2025-05-15 13:17:43 --> URI Class Initialized
INFO - 2025-05-15 13:17:43 --> Router Class Initialized
INFO - 2025-05-15 13:17:43 --> Output Class Initialized
INFO - 2025-05-15 13:17:43 --> Security Class Initialized
DEBUG - 2025-05-15 13:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 13:17:43 --> Input Class Initialized
INFO - 2025-05-15 13:17:43 --> Language Class Initialized
INFO - 2025-05-15 13:17:43 --> Loader Class Initialized
INFO - 2025-05-15 13:17:43 --> Helper loaded: url_helper
INFO - 2025-05-15 13:17:43 --> Helper loaded: form_helper
INFO - 2025-05-15 13:17:44 --> Database Driver Class Initialized
DEBUG - 2025-05-15 13:17:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 13:17:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 13:17:44 --> Controller Class Initialized
INFO - 2025-05-15 13:17:44 --> Model "Beta_model" initialized
INFO - 2025-05-15 13:17:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\beta.php
INFO - 2025-05-15 13:17:44 --> Final output sent to browser
DEBUG - 2025-05-15 13:17:44 --> Total execution time: 0.7818
INFO - 2025-05-15 13:17:49 --> Config Class Initialized
INFO - 2025-05-15 13:17:49 --> Hooks Class Initialized
DEBUG - 2025-05-15 13:17:49 --> UTF-8 Support Enabled
INFO - 2025-05-15 13:17:49 --> Utf8 Class Initialized
INFO - 2025-05-15 13:17:49 --> URI Class Initialized
INFO - 2025-05-15 13:17:49 --> Router Class Initialized
INFO - 2025-05-15 13:17:49 --> Output Class Initialized
INFO - 2025-05-15 13:17:49 --> Security Class Initialized
DEBUG - 2025-05-15 13:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 13:17:49 --> Input Class Initialized
INFO - 2025-05-15 13:17:49 --> Language Class Initialized
ERROR - 2025-05-15 13:17:49 --> 404 Page Not Found: Workout/get_workout_detail
INFO - 2025-05-15 13:17:50 --> Config Class Initialized
INFO - 2025-05-15 13:17:50 --> Hooks Class Initialized
DEBUG - 2025-05-15 13:17:50 --> UTF-8 Support Enabled
INFO - 2025-05-15 13:17:50 --> Utf8 Class Initialized
INFO - 2025-05-15 13:17:50 --> URI Class Initialized
INFO - 2025-05-15 13:17:50 --> Router Class Initialized
INFO - 2025-05-15 13:17:50 --> Output Class Initialized
INFO - 2025-05-15 13:17:50 --> Security Class Initialized
DEBUG - 2025-05-15 13:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 13:17:50 --> Input Class Initialized
INFO - 2025-05-15 13:17:50 --> Language Class Initialized
ERROR - 2025-05-15 13:17:50 --> 404 Page Not Found: Workout/get_workout_detail
INFO - 2025-05-15 13:17:51 --> Config Class Initialized
INFO - 2025-05-15 13:17:51 --> Hooks Class Initialized
DEBUG - 2025-05-15 13:17:51 --> UTF-8 Support Enabled
INFO - 2025-05-15 13:17:51 --> Utf8 Class Initialized
INFO - 2025-05-15 13:17:51 --> URI Class Initialized
INFO - 2025-05-15 13:17:51 --> Router Class Initialized
INFO - 2025-05-15 13:17:51 --> Output Class Initialized
INFO - 2025-05-15 13:17:51 --> Security Class Initialized
DEBUG - 2025-05-15 13:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 13:17:51 --> Input Class Initialized
INFO - 2025-05-15 13:17:51 --> Language Class Initialized
ERROR - 2025-05-15 13:17:51 --> 404 Page Not Found: Workout/get_workout_detail
INFO - 2025-05-15 13:17:51 --> Config Class Initialized
INFO - 2025-05-15 13:17:51 --> Hooks Class Initialized
DEBUG - 2025-05-15 13:17:51 --> UTF-8 Support Enabled
INFO - 2025-05-15 13:17:51 --> Utf8 Class Initialized
INFO - 2025-05-15 13:17:51 --> URI Class Initialized
INFO - 2025-05-15 13:17:51 --> Router Class Initialized
INFO - 2025-05-15 13:17:51 --> Output Class Initialized
INFO - 2025-05-15 13:17:51 --> Security Class Initialized
DEBUG - 2025-05-15 13:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 13:17:51 --> Input Class Initialized
INFO - 2025-05-15 13:17:51 --> Language Class Initialized
ERROR - 2025-05-15 13:17:51 --> 404 Page Not Found: Workout/get_workout_detail
INFO - 2025-05-15 13:21:15 --> Config Class Initialized
INFO - 2025-05-15 13:21:15 --> Hooks Class Initialized
DEBUG - 2025-05-15 13:21:15 --> UTF-8 Support Enabled
INFO - 2025-05-15 13:21:15 --> Utf8 Class Initialized
INFO - 2025-05-15 13:21:15 --> URI Class Initialized
INFO - 2025-05-15 13:21:15 --> Router Class Initialized
INFO - 2025-05-15 13:21:16 --> Output Class Initialized
INFO - 2025-05-15 13:21:16 --> Security Class Initialized
DEBUG - 2025-05-15 13:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 13:21:16 --> Input Class Initialized
INFO - 2025-05-15 13:21:16 --> Language Class Initialized
INFO - 2025-05-15 13:21:16 --> Loader Class Initialized
INFO - 2025-05-15 13:21:16 --> Helper loaded: url_helper
INFO - 2025-05-15 13:21:16 --> Helper loaded: form_helper
INFO - 2025-05-15 13:21:16 --> Database Driver Class Initialized
DEBUG - 2025-05-15 13:21:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 13:21:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 13:21:16 --> Controller Class Initialized
INFO - 2025-05-15 13:21:16 --> Model "Beta_model" initialized
ERROR - 2025-05-15 13:21:16 --> Severity: Warning --> Undefined variable $schedule C:\laragon\www\Project\fitnessrecord\application\views\beta.php 51
ERROR - 2025-05-15 13:21:16 --> Severity: Warning --> Attempt to read property "id" on null C:\laragon\www\Project\fitnessrecord\application\views\beta.php 51
INFO - 2025-05-15 13:21:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\beta.php
INFO - 2025-05-15 13:21:16 --> Final output sent to browser
DEBUG - 2025-05-15 13:21:16 --> Total execution time: 0.1181
INFO - 2025-05-15 13:22:18 --> Config Class Initialized
INFO - 2025-05-15 13:22:18 --> Hooks Class Initialized
DEBUG - 2025-05-15 13:22:18 --> UTF-8 Support Enabled
INFO - 2025-05-15 13:22:18 --> Utf8 Class Initialized
INFO - 2025-05-15 13:22:18 --> URI Class Initialized
INFO - 2025-05-15 13:22:18 --> Router Class Initialized
INFO - 2025-05-15 13:22:18 --> Output Class Initialized
INFO - 2025-05-15 13:22:18 --> Security Class Initialized
DEBUG - 2025-05-15 13:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 13:22:18 --> Input Class Initialized
INFO - 2025-05-15 13:22:18 --> Language Class Initialized
INFO - 2025-05-15 13:22:18 --> Loader Class Initialized
INFO - 2025-05-15 13:22:18 --> Helper loaded: url_helper
INFO - 2025-05-15 13:22:18 --> Helper loaded: form_helper
INFO - 2025-05-15 13:22:18 --> Database Driver Class Initialized
DEBUG - 2025-05-15 13:22:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 13:22:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 13:22:18 --> Controller Class Initialized
INFO - 2025-05-15 13:22:18 --> Model "Beta_model" initialized
INFO - 2025-05-15 13:22:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\beta.php
INFO - 2025-05-15 13:22:18 --> Final output sent to browser
DEBUG - 2025-05-15 13:22:18 --> Total execution time: 0.0769
INFO - 2025-05-15 13:47:22 --> Config Class Initialized
INFO - 2025-05-15 13:47:22 --> Hooks Class Initialized
DEBUG - 2025-05-15 13:47:22 --> UTF-8 Support Enabled
INFO - 2025-05-15 13:47:22 --> Utf8 Class Initialized
INFO - 2025-05-15 13:47:22 --> URI Class Initialized
INFO - 2025-05-15 13:47:22 --> Router Class Initialized
INFO - 2025-05-15 13:47:22 --> Output Class Initialized
INFO - 2025-05-15 13:47:22 --> Security Class Initialized
DEBUG - 2025-05-15 13:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 13:47:22 --> Input Class Initialized
INFO - 2025-05-15 13:47:22 --> Language Class Initialized
INFO - 2025-05-15 13:47:22 --> Loader Class Initialized
INFO - 2025-05-15 13:47:22 --> Helper loaded: url_helper
INFO - 2025-05-15 13:47:22 --> Helper loaded: form_helper
INFO - 2025-05-15 13:47:22 --> Database Driver Class Initialized
DEBUG - 2025-05-15 13:47:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 13:47:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 13:47:22 --> Controller Class Initialized
INFO - 2025-05-15 13:47:22 --> Model "Beta_model" initialized
INFO - 2025-05-15 13:47:22 --> Model "Schedule_model" initialized
INFO - 2025-05-15 13:47:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\beta.php
INFO - 2025-05-15 13:47:22 --> Final output sent to browser
DEBUG - 2025-05-15 13:47:22 --> Total execution time: 0.0804
INFO - 2025-05-15 13:47:27 --> Config Class Initialized
INFO - 2025-05-15 13:47:27 --> Hooks Class Initialized
DEBUG - 2025-05-15 13:47:27 --> UTF-8 Support Enabled
INFO - 2025-05-15 13:47:27 --> Utf8 Class Initialized
INFO - 2025-05-15 13:47:27 --> URI Class Initialized
INFO - 2025-05-15 13:47:27 --> Router Class Initialized
INFO - 2025-05-15 13:47:27 --> Output Class Initialized
INFO - 2025-05-15 13:47:27 --> Security Class Initialized
DEBUG - 2025-05-15 13:47:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 13:47:27 --> Input Class Initialized
INFO - 2025-05-15 13:47:27 --> Language Class Initialized
INFO - 2025-05-15 13:47:27 --> Loader Class Initialized
INFO - 2025-05-15 13:47:27 --> Helper loaded: url_helper
INFO - 2025-05-15 13:47:27 --> Helper loaded: form_helper
INFO - 2025-05-15 13:47:27 --> Database Driver Class Initialized
DEBUG - 2025-05-15 13:47:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 13:47:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 13:47:27 --> Controller Class Initialized
INFO - 2025-05-15 13:47:27 --> Model "Beta_model" initialized
INFO - 2025-05-15 13:47:27 --> Model "Schedule_model" initialized
INFO - 2025-05-15 13:47:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\beta.php
INFO - 2025-05-15 13:47:27 --> Final output sent to browser
DEBUG - 2025-05-15 13:47:27 --> Total execution time: 0.0805
INFO - 2025-05-15 13:47:28 --> Config Class Initialized
INFO - 2025-05-15 13:47:28 --> Hooks Class Initialized
DEBUG - 2025-05-15 13:47:28 --> UTF-8 Support Enabled
INFO - 2025-05-15 13:47:28 --> Utf8 Class Initialized
INFO - 2025-05-15 13:47:28 --> URI Class Initialized
INFO - 2025-05-15 13:47:28 --> Router Class Initialized
INFO - 2025-05-15 13:47:28 --> Output Class Initialized
INFO - 2025-05-15 13:47:28 --> Security Class Initialized
DEBUG - 2025-05-15 13:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 13:47:28 --> Input Class Initialized
INFO - 2025-05-15 13:47:28 --> Language Class Initialized
INFO - 2025-05-15 13:47:28 --> Loader Class Initialized
INFO - 2025-05-15 13:47:28 --> Helper loaded: url_helper
INFO - 2025-05-15 13:47:28 --> Helper loaded: form_helper
INFO - 2025-05-15 13:47:28 --> Database Driver Class Initialized
DEBUG - 2025-05-15 13:47:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 13:47:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 13:47:28 --> Controller Class Initialized
INFO - 2025-05-15 13:47:28 --> Model "Beta_model" initialized
INFO - 2025-05-15 13:47:28 --> Model "Schedule_model" initialized
INFO - 2025-05-15 13:47:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\beta.php
INFO - 2025-05-15 13:47:28 --> Final output sent to browser
DEBUG - 2025-05-15 13:47:28 --> Total execution time: 0.0732
INFO - 2025-05-15 13:47:29 --> Config Class Initialized
INFO - 2025-05-15 13:47:29 --> Hooks Class Initialized
DEBUG - 2025-05-15 13:47:29 --> UTF-8 Support Enabled
INFO - 2025-05-15 13:47:29 --> Utf8 Class Initialized
INFO - 2025-05-15 13:47:29 --> URI Class Initialized
INFO - 2025-05-15 13:47:29 --> Router Class Initialized
INFO - 2025-05-15 13:47:29 --> Output Class Initialized
INFO - 2025-05-15 13:47:29 --> Security Class Initialized
DEBUG - 2025-05-15 13:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 13:47:29 --> Input Class Initialized
INFO - 2025-05-15 13:47:29 --> Language Class Initialized
INFO - 2025-05-15 13:47:29 --> Loader Class Initialized
INFO - 2025-05-15 13:47:29 --> Helper loaded: url_helper
INFO - 2025-05-15 13:47:29 --> Helper loaded: form_helper
INFO - 2025-05-15 13:47:29 --> Database Driver Class Initialized
DEBUG - 2025-05-15 13:47:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 13:47:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 13:47:29 --> Controller Class Initialized
INFO - 2025-05-15 13:47:29 --> Model "Beta_model" initialized
INFO - 2025-05-15 13:47:29 --> Model "Schedule_model" initialized
INFO - 2025-05-15 13:47:29 --> Final output sent to browser
DEBUG - 2025-05-15 13:47:29 --> Total execution time: 0.0934
INFO - 2025-05-15 13:47:37 --> Config Class Initialized
INFO - 2025-05-15 13:47:37 --> Hooks Class Initialized
DEBUG - 2025-05-15 13:47:37 --> UTF-8 Support Enabled
INFO - 2025-05-15 13:47:37 --> Utf8 Class Initialized
INFO - 2025-05-15 13:47:37 --> URI Class Initialized
INFO - 2025-05-15 13:47:37 --> Router Class Initialized
INFO - 2025-05-15 13:47:37 --> Output Class Initialized
INFO - 2025-05-15 13:47:37 --> Security Class Initialized
DEBUG - 2025-05-15 13:47:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 13:47:37 --> Input Class Initialized
INFO - 2025-05-15 13:47:37 --> Language Class Initialized
INFO - 2025-05-15 13:47:37 --> Loader Class Initialized
INFO - 2025-05-15 13:47:37 --> Helper loaded: url_helper
INFO - 2025-05-15 13:47:37 --> Helper loaded: form_helper
INFO - 2025-05-15 13:47:37 --> Database Driver Class Initialized
DEBUG - 2025-05-15 13:47:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 13:47:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 13:47:37 --> Controller Class Initialized
INFO - 2025-05-15 13:47:37 --> Model "Beta_model" initialized
INFO - 2025-05-15 13:47:37 --> Model "Schedule_model" initialized
INFO - 2025-05-15 13:47:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\beta.php
INFO - 2025-05-15 13:47:37 --> Final output sent to browser
DEBUG - 2025-05-15 13:47:37 --> Total execution time: 0.0606
INFO - 2025-05-15 13:48:12 --> Config Class Initialized
INFO - 2025-05-15 13:48:12 --> Hooks Class Initialized
DEBUG - 2025-05-15 13:48:12 --> UTF-8 Support Enabled
INFO - 2025-05-15 13:48:12 --> Utf8 Class Initialized
INFO - 2025-05-15 13:48:12 --> URI Class Initialized
INFO - 2025-05-15 13:48:12 --> Router Class Initialized
INFO - 2025-05-15 13:48:12 --> Output Class Initialized
INFO - 2025-05-15 13:48:12 --> Security Class Initialized
DEBUG - 2025-05-15 13:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 13:48:12 --> Input Class Initialized
INFO - 2025-05-15 13:48:12 --> Language Class Initialized
INFO - 2025-05-15 13:48:12 --> Loader Class Initialized
INFO - 2025-05-15 13:48:12 --> Helper loaded: url_helper
INFO - 2025-05-15 13:48:12 --> Helper loaded: form_helper
INFO - 2025-05-15 13:48:12 --> Database Driver Class Initialized
DEBUG - 2025-05-15 13:48:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 13:48:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 13:48:12 --> Controller Class Initialized
INFO - 2025-05-15 13:48:12 --> Model "Beta_model" initialized
INFO - 2025-05-15 13:48:12 --> Model "Schedule_model" initialized
INFO - 2025-05-15 13:48:12 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\beta.php
INFO - 2025-05-15 13:48:12 --> Final output sent to browser
DEBUG - 2025-05-15 13:48:12 --> Total execution time: 0.0783
INFO - 2025-05-15 13:48:14 --> Config Class Initialized
INFO - 2025-05-15 13:48:14 --> Hooks Class Initialized
DEBUG - 2025-05-15 13:48:14 --> UTF-8 Support Enabled
INFO - 2025-05-15 13:48:14 --> Utf8 Class Initialized
INFO - 2025-05-15 13:48:14 --> URI Class Initialized
INFO - 2025-05-15 13:48:14 --> Router Class Initialized
INFO - 2025-05-15 13:48:14 --> Output Class Initialized
INFO - 2025-05-15 13:48:14 --> Security Class Initialized
DEBUG - 2025-05-15 13:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 13:48:14 --> Input Class Initialized
INFO - 2025-05-15 13:48:14 --> Language Class Initialized
INFO - 2025-05-15 13:48:14 --> Loader Class Initialized
INFO - 2025-05-15 13:48:14 --> Helper loaded: url_helper
INFO - 2025-05-15 13:48:14 --> Helper loaded: form_helper
INFO - 2025-05-15 13:48:14 --> Database Driver Class Initialized
DEBUG - 2025-05-15 13:48:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 13:48:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 13:48:14 --> Controller Class Initialized
INFO - 2025-05-15 13:48:14 --> Model "Beta_model" initialized
INFO - 2025-05-15 13:48:14 --> Model "Schedule_model" initialized
INFO - 2025-05-15 13:48:14 --> Final output sent to browser
DEBUG - 2025-05-15 13:48:14 --> Total execution time: 0.0508
INFO - 2025-05-15 13:48:16 --> Config Class Initialized
INFO - 2025-05-15 13:48:16 --> Hooks Class Initialized
DEBUG - 2025-05-15 13:48:16 --> UTF-8 Support Enabled
INFO - 2025-05-15 13:48:16 --> Utf8 Class Initialized
INFO - 2025-05-15 13:48:16 --> URI Class Initialized
INFO - 2025-05-15 13:48:16 --> Router Class Initialized
INFO - 2025-05-15 13:48:16 --> Output Class Initialized
INFO - 2025-05-15 13:48:16 --> Security Class Initialized
DEBUG - 2025-05-15 13:48:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 13:48:16 --> Input Class Initialized
INFO - 2025-05-15 13:48:16 --> Language Class Initialized
INFO - 2025-05-15 13:48:16 --> Loader Class Initialized
INFO - 2025-05-15 13:48:16 --> Helper loaded: url_helper
INFO - 2025-05-15 13:48:16 --> Helper loaded: form_helper
INFO - 2025-05-15 13:48:16 --> Database Driver Class Initialized
DEBUG - 2025-05-15 13:48:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 13:48:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 13:48:16 --> Controller Class Initialized
INFO - 2025-05-15 13:48:16 --> Model "Workout_model" initialized
INFO - 2025-05-15 13:48:16 --> Model "User_model" initialized
INFO - 2025-05-15 13:48:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 13:48:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 13:48:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-15 13:48:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 13:48:16 --> Final output sent to browser
DEBUG - 2025-05-15 13:48:16 --> Total execution time: 0.1651
INFO - 2025-05-15 13:48:19 --> Config Class Initialized
INFO - 2025-05-15 13:48:19 --> Hooks Class Initialized
DEBUG - 2025-05-15 13:48:19 --> UTF-8 Support Enabled
INFO - 2025-05-15 13:48:19 --> Utf8 Class Initialized
INFO - 2025-05-15 13:48:19 --> URI Class Initialized
INFO - 2025-05-15 13:48:19 --> Router Class Initialized
INFO - 2025-05-15 13:48:19 --> Output Class Initialized
INFO - 2025-05-15 13:48:19 --> Security Class Initialized
DEBUG - 2025-05-15 13:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 13:48:19 --> Input Class Initialized
INFO - 2025-05-15 13:48:19 --> Language Class Initialized
INFO - 2025-05-15 13:48:19 --> Loader Class Initialized
INFO - 2025-05-15 13:48:19 --> Helper loaded: url_helper
INFO - 2025-05-15 13:48:19 --> Helper loaded: form_helper
INFO - 2025-05-15 13:48:20 --> Database Driver Class Initialized
DEBUG - 2025-05-15 13:48:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 13:48:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 13:48:20 --> Controller Class Initialized
INFO - 2025-05-15 13:48:20 --> Model "Beta_model" initialized
INFO - 2025-05-15 13:48:20 --> Model "Schedule_model" initialized
INFO - 2025-05-15 13:48:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\beta.php
INFO - 2025-05-15 13:48:20 --> Final output sent to browser
DEBUG - 2025-05-15 13:48:20 --> Total execution time: 0.0631
INFO - 2025-05-15 13:48:45 --> Config Class Initialized
INFO - 2025-05-15 13:48:45 --> Hooks Class Initialized
DEBUG - 2025-05-15 13:48:45 --> UTF-8 Support Enabled
INFO - 2025-05-15 13:48:45 --> Utf8 Class Initialized
INFO - 2025-05-15 13:48:45 --> URI Class Initialized
INFO - 2025-05-15 13:48:45 --> Router Class Initialized
INFO - 2025-05-15 13:48:45 --> Output Class Initialized
INFO - 2025-05-15 13:48:45 --> Security Class Initialized
DEBUG - 2025-05-15 13:48:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 13:48:45 --> Input Class Initialized
INFO - 2025-05-15 13:48:45 --> Language Class Initialized
INFO - 2025-05-15 13:48:45 --> Loader Class Initialized
INFO - 2025-05-15 13:48:45 --> Helper loaded: url_helper
INFO - 2025-05-15 13:48:45 --> Helper loaded: form_helper
INFO - 2025-05-15 13:48:45 --> Database Driver Class Initialized
DEBUG - 2025-05-15 13:48:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 13:48:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 13:48:45 --> Controller Class Initialized
INFO - 2025-05-15 13:48:45 --> Model "Beta_model" initialized
INFO - 2025-05-15 13:48:45 --> Model "Schedule_model" initialized
INFO - 2025-05-15 13:48:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\beta.php
INFO - 2025-05-15 13:48:45 --> Final output sent to browser
DEBUG - 2025-05-15 13:48:45 --> Total execution time: 0.1910
INFO - 2025-05-15 13:48:45 --> Config Class Initialized
INFO - 2025-05-15 13:48:45 --> Hooks Class Initialized
DEBUG - 2025-05-15 13:48:46 --> UTF-8 Support Enabled
INFO - 2025-05-15 13:48:46 --> Utf8 Class Initialized
INFO - 2025-05-15 13:48:46 --> URI Class Initialized
INFO - 2025-05-15 13:48:46 --> Router Class Initialized
INFO - 2025-05-15 13:48:46 --> Output Class Initialized
INFO - 2025-05-15 13:48:46 --> Security Class Initialized
DEBUG - 2025-05-15 13:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 13:48:46 --> Input Class Initialized
INFO - 2025-05-15 13:48:46 --> Language Class Initialized
INFO - 2025-05-15 13:48:46 --> Loader Class Initialized
INFO - 2025-05-15 13:48:46 --> Helper loaded: url_helper
INFO - 2025-05-15 13:48:46 --> Helper loaded: form_helper
INFO - 2025-05-15 13:48:46 --> Database Driver Class Initialized
DEBUG - 2025-05-15 13:48:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 13:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 13:48:46 --> Controller Class Initialized
INFO - 2025-05-15 13:48:46 --> Model "Beta_model" initialized
INFO - 2025-05-15 13:48:46 --> Model "Schedule_model" initialized
INFO - 2025-05-15 13:48:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\beta.php
INFO - 2025-05-15 13:48:46 --> Final output sent to browser
DEBUG - 2025-05-15 13:48:46 --> Total execution time: 0.0716
INFO - 2025-05-15 13:48:46 --> Config Class Initialized
INFO - 2025-05-15 13:48:46 --> Hooks Class Initialized
DEBUG - 2025-05-15 13:48:46 --> UTF-8 Support Enabled
INFO - 2025-05-15 13:48:46 --> Utf8 Class Initialized
INFO - 2025-05-15 13:48:46 --> URI Class Initialized
INFO - 2025-05-15 13:48:46 --> Router Class Initialized
INFO - 2025-05-15 13:48:46 --> Output Class Initialized
INFO - 2025-05-15 13:48:46 --> Security Class Initialized
DEBUG - 2025-05-15 13:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 13:48:46 --> Input Class Initialized
INFO - 2025-05-15 13:48:46 --> Language Class Initialized
INFO - 2025-05-15 13:48:46 --> Loader Class Initialized
INFO - 2025-05-15 13:48:46 --> Helper loaded: url_helper
INFO - 2025-05-15 13:48:46 --> Helper loaded: form_helper
INFO - 2025-05-15 13:48:46 --> Database Driver Class Initialized
DEBUG - 2025-05-15 13:48:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 13:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 13:48:46 --> Controller Class Initialized
INFO - 2025-05-15 13:48:46 --> Model "Beta_model" initialized
INFO - 2025-05-15 13:48:46 --> Model "Schedule_model" initialized
INFO - 2025-05-15 13:48:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\beta.php
INFO - 2025-05-15 13:48:46 --> Final output sent to browser
DEBUG - 2025-05-15 13:48:46 --> Total execution time: 0.0694
INFO - 2025-05-15 13:48:46 --> Config Class Initialized
INFO - 2025-05-15 13:48:46 --> Hooks Class Initialized
DEBUG - 2025-05-15 13:48:46 --> UTF-8 Support Enabled
INFO - 2025-05-15 13:48:46 --> Utf8 Class Initialized
INFO - 2025-05-15 13:48:46 --> URI Class Initialized
INFO - 2025-05-15 13:48:46 --> Router Class Initialized
INFO - 2025-05-15 13:48:46 --> Output Class Initialized
INFO - 2025-05-15 13:48:46 --> Security Class Initialized
DEBUG - 2025-05-15 13:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 13:48:46 --> Input Class Initialized
INFO - 2025-05-15 13:48:46 --> Language Class Initialized
INFO - 2025-05-15 13:48:46 --> Loader Class Initialized
INFO - 2025-05-15 13:48:46 --> Helper loaded: url_helper
INFO - 2025-05-15 13:48:46 --> Helper loaded: form_helper
INFO - 2025-05-15 13:48:46 --> Database Driver Class Initialized
DEBUG - 2025-05-15 13:48:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 13:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 13:48:46 --> Controller Class Initialized
INFO - 2025-05-15 13:48:46 --> Model "Beta_model" initialized
INFO - 2025-05-15 13:48:46 --> Model "Schedule_model" initialized
INFO - 2025-05-15 13:48:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\beta.php
INFO - 2025-05-15 13:48:46 --> Final output sent to browser
DEBUG - 2025-05-15 13:48:46 --> Total execution time: 0.0607
INFO - 2025-05-15 13:48:46 --> Config Class Initialized
INFO - 2025-05-15 13:48:46 --> Hooks Class Initialized
DEBUG - 2025-05-15 13:48:46 --> UTF-8 Support Enabled
INFO - 2025-05-15 13:48:46 --> Utf8 Class Initialized
INFO - 2025-05-15 13:48:46 --> URI Class Initialized
INFO - 2025-05-15 13:48:46 --> Router Class Initialized
INFO - 2025-05-15 13:48:46 --> Output Class Initialized
INFO - 2025-05-15 13:48:46 --> Security Class Initialized
DEBUG - 2025-05-15 13:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 13:48:46 --> Input Class Initialized
INFO - 2025-05-15 13:48:46 --> Language Class Initialized
INFO - 2025-05-15 13:48:46 --> Loader Class Initialized
INFO - 2025-05-15 13:48:46 --> Helper loaded: url_helper
INFO - 2025-05-15 13:48:46 --> Helper loaded: form_helper
INFO - 2025-05-15 13:48:46 --> Database Driver Class Initialized
DEBUG - 2025-05-15 13:48:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 13:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 13:48:46 --> Controller Class Initialized
INFO - 2025-05-15 13:48:46 --> Model "Beta_model" initialized
INFO - 2025-05-15 13:48:46 --> Model "Schedule_model" initialized
INFO - 2025-05-15 13:48:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\beta.php
INFO - 2025-05-15 13:48:46 --> Final output sent to browser
DEBUG - 2025-05-15 13:48:46 --> Total execution time: 0.0852
INFO - 2025-05-15 13:48:46 --> Config Class Initialized
INFO - 2025-05-15 13:48:46 --> Hooks Class Initialized
DEBUG - 2025-05-15 13:48:46 --> UTF-8 Support Enabled
INFO - 2025-05-15 13:48:46 --> Utf8 Class Initialized
INFO - 2025-05-15 13:48:46 --> URI Class Initialized
INFO - 2025-05-15 13:48:46 --> Router Class Initialized
INFO - 2025-05-15 13:48:46 --> Output Class Initialized
INFO - 2025-05-15 13:48:46 --> Security Class Initialized
DEBUG - 2025-05-15 13:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 13:48:46 --> Input Class Initialized
INFO - 2025-05-15 13:48:46 --> Language Class Initialized
INFO - 2025-05-15 13:48:46 --> Loader Class Initialized
INFO - 2025-05-15 13:48:46 --> Helper loaded: url_helper
INFO - 2025-05-15 13:48:46 --> Helper loaded: form_helper
INFO - 2025-05-15 13:48:46 --> Database Driver Class Initialized
DEBUG - 2025-05-15 13:48:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 13:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 13:48:46 --> Controller Class Initialized
INFO - 2025-05-15 13:48:46 --> Model "Beta_model" initialized
INFO - 2025-05-15 13:48:46 --> Model "Schedule_model" initialized
INFO - 2025-05-15 13:48:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\beta.php
INFO - 2025-05-15 13:48:46 --> Final output sent to browser
DEBUG - 2025-05-15 13:48:46 --> Total execution time: 0.0866
INFO - 2025-05-15 13:48:46 --> Config Class Initialized
INFO - 2025-05-15 13:48:46 --> Hooks Class Initialized
DEBUG - 2025-05-15 13:48:46 --> UTF-8 Support Enabled
INFO - 2025-05-15 13:48:46 --> Utf8 Class Initialized
INFO - 2025-05-15 13:48:46 --> URI Class Initialized
INFO - 2025-05-15 13:48:46 --> Router Class Initialized
INFO - 2025-05-15 13:48:46 --> Output Class Initialized
INFO - 2025-05-15 13:48:46 --> Security Class Initialized
DEBUG - 2025-05-15 13:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 13:48:46 --> Input Class Initialized
INFO - 2025-05-15 13:48:46 --> Language Class Initialized
INFO - 2025-05-15 13:48:46 --> Loader Class Initialized
INFO - 2025-05-15 13:48:46 --> Helper loaded: url_helper
INFO - 2025-05-15 13:48:46 --> Helper loaded: form_helper
INFO - 2025-05-15 13:48:46 --> Database Driver Class Initialized
DEBUG - 2025-05-15 13:48:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 13:48:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 13:48:47 --> Controller Class Initialized
INFO - 2025-05-15 13:48:47 --> Model "Beta_model" initialized
INFO - 2025-05-15 13:48:47 --> Model "Schedule_model" initialized
INFO - 2025-05-15 13:48:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\beta.php
INFO - 2025-05-15 13:48:47 --> Final output sent to browser
DEBUG - 2025-05-15 13:48:47 --> Total execution time: 0.1056
INFO - 2025-05-15 13:48:47 --> Config Class Initialized
INFO - 2025-05-15 13:48:47 --> Hooks Class Initialized
DEBUG - 2025-05-15 13:48:47 --> UTF-8 Support Enabled
INFO - 2025-05-15 13:48:47 --> Utf8 Class Initialized
INFO - 2025-05-15 13:48:47 --> URI Class Initialized
INFO - 2025-05-15 13:48:47 --> Router Class Initialized
INFO - 2025-05-15 13:48:47 --> Output Class Initialized
INFO - 2025-05-15 13:48:47 --> Security Class Initialized
DEBUG - 2025-05-15 13:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 13:48:47 --> Input Class Initialized
INFO - 2025-05-15 13:48:47 --> Language Class Initialized
INFO - 2025-05-15 13:48:47 --> Loader Class Initialized
INFO - 2025-05-15 13:48:47 --> Helper loaded: url_helper
INFO - 2025-05-15 13:48:47 --> Helper loaded: form_helper
INFO - 2025-05-15 13:48:47 --> Database Driver Class Initialized
DEBUG - 2025-05-15 13:48:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 13:48:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 13:48:47 --> Controller Class Initialized
INFO - 2025-05-15 13:48:47 --> Model "Beta_model" initialized
INFO - 2025-05-15 13:48:47 --> Model "Schedule_model" initialized
INFO - 2025-05-15 13:48:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\beta.php
INFO - 2025-05-15 13:48:47 --> Final output sent to browser
DEBUG - 2025-05-15 13:48:47 --> Total execution time: 0.0686
INFO - 2025-05-15 13:48:47 --> Config Class Initialized
INFO - 2025-05-15 13:48:47 --> Hooks Class Initialized
DEBUG - 2025-05-15 13:48:47 --> UTF-8 Support Enabled
INFO - 2025-05-15 13:48:47 --> Utf8 Class Initialized
INFO - 2025-05-15 13:48:47 --> URI Class Initialized
INFO - 2025-05-15 13:48:47 --> Router Class Initialized
INFO - 2025-05-15 13:48:47 --> Output Class Initialized
INFO - 2025-05-15 13:48:47 --> Security Class Initialized
DEBUG - 2025-05-15 13:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 13:48:47 --> Input Class Initialized
INFO - 2025-05-15 13:48:47 --> Language Class Initialized
INFO - 2025-05-15 13:48:47 --> Loader Class Initialized
INFO - 2025-05-15 13:48:47 --> Helper loaded: url_helper
INFO - 2025-05-15 13:48:47 --> Helper loaded: form_helper
INFO - 2025-05-15 13:48:47 --> Database Driver Class Initialized
DEBUG - 2025-05-15 13:48:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 13:48:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 13:48:47 --> Controller Class Initialized
INFO - 2025-05-15 13:48:47 --> Model "Beta_model" initialized
INFO - 2025-05-15 13:48:47 --> Model "Schedule_model" initialized
INFO - 2025-05-15 13:48:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\beta.php
INFO - 2025-05-15 13:48:47 --> Final output sent to browser
DEBUG - 2025-05-15 13:48:47 --> Total execution time: 0.0708
INFO - 2025-05-15 13:48:47 --> Config Class Initialized
INFO - 2025-05-15 13:48:47 --> Hooks Class Initialized
DEBUG - 2025-05-15 13:48:47 --> UTF-8 Support Enabled
INFO - 2025-05-15 13:48:47 --> Utf8 Class Initialized
INFO - 2025-05-15 13:48:47 --> URI Class Initialized
INFO - 2025-05-15 13:48:47 --> Router Class Initialized
INFO - 2025-05-15 13:48:47 --> Output Class Initialized
INFO - 2025-05-15 13:48:47 --> Security Class Initialized
DEBUG - 2025-05-15 13:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 13:48:47 --> Input Class Initialized
INFO - 2025-05-15 13:48:47 --> Language Class Initialized
INFO - 2025-05-15 13:48:47 --> Loader Class Initialized
INFO - 2025-05-15 13:48:47 --> Helper loaded: url_helper
INFO - 2025-05-15 13:48:47 --> Helper loaded: form_helper
INFO - 2025-05-15 13:48:47 --> Database Driver Class Initialized
DEBUG - 2025-05-15 13:48:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 13:48:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 13:48:47 --> Controller Class Initialized
INFO - 2025-05-15 13:48:47 --> Model "Beta_model" initialized
INFO - 2025-05-15 13:48:47 --> Model "Schedule_model" initialized
INFO - 2025-05-15 13:48:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\beta.php
INFO - 2025-05-15 13:48:47 --> Final output sent to browser
DEBUG - 2025-05-15 13:48:47 --> Total execution time: 0.0518
INFO - 2025-05-15 13:48:54 --> Config Class Initialized
INFO - 2025-05-15 13:48:54 --> Hooks Class Initialized
DEBUG - 2025-05-15 13:48:54 --> UTF-8 Support Enabled
INFO - 2025-05-15 13:48:54 --> Utf8 Class Initialized
INFO - 2025-05-15 13:48:54 --> URI Class Initialized
INFO - 2025-05-15 13:48:54 --> Router Class Initialized
INFO - 2025-05-15 13:48:54 --> Output Class Initialized
INFO - 2025-05-15 13:48:54 --> Security Class Initialized
DEBUG - 2025-05-15 13:48:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 13:48:54 --> Input Class Initialized
INFO - 2025-05-15 13:48:54 --> Language Class Initialized
ERROR - 2025-05-15 13:48:54 --> 404 Page Not Found: Beta/start
INFO - 2025-05-15 13:52:05 --> Config Class Initialized
INFO - 2025-05-15 13:52:05 --> Hooks Class Initialized
DEBUG - 2025-05-15 13:52:05 --> UTF-8 Support Enabled
INFO - 2025-05-15 13:52:05 --> Utf8 Class Initialized
INFO - 2025-05-15 13:52:05 --> URI Class Initialized
INFO - 2025-05-15 13:52:05 --> Router Class Initialized
INFO - 2025-05-15 13:52:05 --> Output Class Initialized
INFO - 2025-05-15 13:52:05 --> Security Class Initialized
DEBUG - 2025-05-15 13:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 13:52:05 --> Input Class Initialized
INFO - 2025-05-15 13:52:05 --> Language Class Initialized
INFO - 2025-05-15 13:52:05 --> Loader Class Initialized
INFO - 2025-05-15 13:52:05 --> Helper loaded: url_helper
INFO - 2025-05-15 13:52:05 --> Helper loaded: form_helper
INFO - 2025-05-15 13:52:05 --> Database Driver Class Initialized
DEBUG - 2025-05-15 13:52:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 13:52:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 13:52:05 --> Controller Class Initialized
INFO - 2025-05-15 13:52:05 --> Model "Beta_model" initialized
INFO - 2025-05-15 13:52:05 --> Model "Schedule_model" initialized
ERROR - 2025-05-15 13:52:05 --> Severity: error --> Exception: Too few arguments to function Beta::start(), 0 passed in C:\laragon\www\Project\fitnessrecord\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\Project\fitnessrecord\application\controllers\Beta.php 76
INFO - 2025-05-15 13:52:07 --> Config Class Initialized
INFO - 2025-05-15 13:52:07 --> Hooks Class Initialized
DEBUG - 2025-05-15 13:52:07 --> UTF-8 Support Enabled
INFO - 2025-05-15 13:52:07 --> Utf8 Class Initialized
INFO - 2025-05-15 13:52:07 --> URI Class Initialized
INFO - 2025-05-15 13:52:07 --> Router Class Initialized
INFO - 2025-05-15 13:52:07 --> Output Class Initialized
INFO - 2025-05-15 13:52:07 --> Security Class Initialized
DEBUG - 2025-05-15 13:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 13:52:07 --> Input Class Initialized
INFO - 2025-05-15 13:52:07 --> Language Class Initialized
INFO - 2025-05-15 13:52:07 --> Loader Class Initialized
INFO - 2025-05-15 13:52:07 --> Helper loaded: url_helper
INFO - 2025-05-15 13:52:07 --> Helper loaded: form_helper
INFO - 2025-05-15 13:52:07 --> Database Driver Class Initialized
DEBUG - 2025-05-15 13:52:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 13:52:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 13:52:07 --> Controller Class Initialized
INFO - 2025-05-15 13:52:07 --> Model "Beta_model" initialized
INFO - 2025-05-15 13:52:07 --> Model "Schedule_model" initialized
INFO - 2025-05-15 13:52:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\beta.php
INFO - 2025-05-15 13:52:07 --> Final output sent to browser
DEBUG - 2025-05-15 13:52:07 --> Total execution time: 0.0551
INFO - 2025-05-15 13:52:09 --> Config Class Initialized
INFO - 2025-05-15 13:52:09 --> Hooks Class Initialized
DEBUG - 2025-05-15 13:52:09 --> UTF-8 Support Enabled
INFO - 2025-05-15 13:52:09 --> Utf8 Class Initialized
INFO - 2025-05-15 13:52:09 --> URI Class Initialized
INFO - 2025-05-15 13:52:09 --> Router Class Initialized
INFO - 2025-05-15 13:52:09 --> Output Class Initialized
INFO - 2025-05-15 13:52:09 --> Security Class Initialized
DEBUG - 2025-05-15 13:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 13:52:09 --> Input Class Initialized
INFO - 2025-05-15 13:52:09 --> Language Class Initialized
INFO - 2025-05-15 13:52:09 --> Loader Class Initialized
INFO - 2025-05-15 13:52:09 --> Helper loaded: url_helper
INFO - 2025-05-15 13:52:09 --> Helper loaded: form_helper
INFO - 2025-05-15 13:52:09 --> Database Driver Class Initialized
DEBUG - 2025-05-15 13:52:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 13:52:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 13:52:09 --> Controller Class Initialized
INFO - 2025-05-15 13:52:09 --> Model "Beta_model" initialized
INFO - 2025-05-15 13:52:09 --> Model "Schedule_model" initialized
INFO - 2025-05-15 13:52:09 --> Final output sent to browser
DEBUG - 2025-05-15 13:52:09 --> Total execution time: 0.0585
INFO - 2025-05-15 13:52:11 --> Config Class Initialized
INFO - 2025-05-15 13:52:11 --> Hooks Class Initialized
DEBUG - 2025-05-15 13:52:11 --> UTF-8 Support Enabled
INFO - 2025-05-15 13:52:11 --> Utf8 Class Initialized
INFO - 2025-05-15 13:52:11 --> URI Class Initialized
INFO - 2025-05-15 13:52:11 --> Router Class Initialized
INFO - 2025-05-15 13:52:11 --> Output Class Initialized
INFO - 2025-05-15 13:52:11 --> Security Class Initialized
DEBUG - 2025-05-15 13:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 13:52:11 --> Input Class Initialized
INFO - 2025-05-15 13:52:11 --> Language Class Initialized
INFO - 2025-05-15 13:52:11 --> Loader Class Initialized
INFO - 2025-05-15 13:52:11 --> Helper loaded: url_helper
INFO - 2025-05-15 13:52:11 --> Helper loaded: form_helper
INFO - 2025-05-15 13:52:11 --> Database Driver Class Initialized
DEBUG - 2025-05-15 13:52:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 13:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 13:52:11 --> Controller Class Initialized
INFO - 2025-05-15 13:52:11 --> Model "Beta_model" initialized
INFO - 2025-05-15 13:52:11 --> Model "Schedule_model" initialized
INFO - 2025-05-15 13:52:11 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\beta.php
INFO - 2025-05-15 13:52:11 --> Final output sent to browser
DEBUG - 2025-05-15 13:52:11 --> Total execution time: 0.0771
INFO - 2025-05-15 13:53:57 --> Config Class Initialized
INFO - 2025-05-15 13:53:57 --> Hooks Class Initialized
DEBUG - 2025-05-15 13:53:57 --> UTF-8 Support Enabled
INFO - 2025-05-15 13:53:57 --> Utf8 Class Initialized
INFO - 2025-05-15 13:53:57 --> URI Class Initialized
DEBUG - 2025-05-15 13:53:57 --> No URI present. Default controller set.
INFO - 2025-05-15 13:53:57 --> Router Class Initialized
INFO - 2025-05-15 13:53:57 --> Output Class Initialized
INFO - 2025-05-15 13:53:57 --> Security Class Initialized
DEBUG - 2025-05-15 13:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 13:53:57 --> Input Class Initialized
INFO - 2025-05-15 13:53:57 --> Language Class Initialized
INFO - 2025-05-15 13:53:57 --> Loader Class Initialized
INFO - 2025-05-15 13:53:57 --> Helper loaded: url_helper
INFO - 2025-05-15 13:53:57 --> Helper loaded: form_helper
INFO - 2025-05-15 13:53:57 --> Database Driver Class Initialized
DEBUG - 2025-05-15 13:53:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 13:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 13:53:57 --> Controller Class Initialized
INFO - 2025-05-15 13:53:57 --> Model "User_model" initialized
INFO - 2025-05-15 13:53:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-15 13:53:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-15 13:53:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-15 13:53:57 --> Final output sent to browser
DEBUG - 2025-05-15 13:53:57 --> Total execution time: 0.2637
INFO - 2025-05-15 13:53:59 --> Config Class Initialized
INFO - 2025-05-15 13:53:59 --> Hooks Class Initialized
DEBUG - 2025-05-15 13:53:59 --> UTF-8 Support Enabled
INFO - 2025-05-15 13:53:59 --> Utf8 Class Initialized
INFO - 2025-05-15 13:53:59 --> URI Class Initialized
INFO - 2025-05-15 13:53:59 --> Router Class Initialized
INFO - 2025-05-15 13:53:59 --> Output Class Initialized
INFO - 2025-05-15 13:53:59 --> Security Class Initialized
DEBUG - 2025-05-15 13:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 13:53:59 --> Input Class Initialized
INFO - 2025-05-15 13:53:59 --> Language Class Initialized
INFO - 2025-05-15 13:53:59 --> Loader Class Initialized
INFO - 2025-05-15 13:53:59 --> Helper loaded: url_helper
INFO - 2025-05-15 13:53:59 --> Helper loaded: form_helper
INFO - 2025-05-15 13:53:59 --> Database Driver Class Initialized
DEBUG - 2025-05-15 13:53:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 13:53:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 13:53:59 --> Controller Class Initialized
INFO - 2025-05-15 13:53:59 --> Model "User_model" initialized
INFO - 2025-05-15 13:53:59 --> Model "Workout_model" initialized
INFO - 2025-05-15 13:53:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 13:53:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 13:53:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-15 13:53:59 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 13:53:59 --> Final output sent to browser
DEBUG - 2025-05-15 13:53:59 --> Total execution time: 0.1282
INFO - 2025-05-15 13:56:45 --> Config Class Initialized
INFO - 2025-05-15 13:56:45 --> Hooks Class Initialized
DEBUG - 2025-05-15 13:56:45 --> UTF-8 Support Enabled
INFO - 2025-05-15 13:56:45 --> Utf8 Class Initialized
INFO - 2025-05-15 13:56:45 --> URI Class Initialized
INFO - 2025-05-15 13:56:45 --> Router Class Initialized
INFO - 2025-05-15 13:56:45 --> Output Class Initialized
INFO - 2025-05-15 13:56:45 --> Security Class Initialized
DEBUG - 2025-05-15 13:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 13:56:45 --> Input Class Initialized
INFO - 2025-05-15 13:56:45 --> Language Class Initialized
INFO - 2025-05-15 13:56:45 --> Loader Class Initialized
INFO - 2025-05-15 13:56:45 --> Helper loaded: url_helper
INFO - 2025-05-15 13:56:45 --> Helper loaded: form_helper
INFO - 2025-05-15 13:56:45 --> Database Driver Class Initialized
DEBUG - 2025-05-15 13:56:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 13:56:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 13:56:45 --> Controller Class Initialized
INFO - 2025-05-15 13:56:45 --> Model "Workout_model" initialized
INFO - 2025-05-15 13:56:45 --> Model "User_model" initialized
INFO - 2025-05-15 13:56:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 13:56:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 13:56:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-15 13:56:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 13:56:45 --> Final output sent to browser
DEBUG - 2025-05-15 13:56:45 --> Total execution time: 0.0709
INFO - 2025-05-15 14:09:16 --> Config Class Initialized
INFO - 2025-05-15 14:09:16 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:09:16 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:09:16 --> Utf8 Class Initialized
INFO - 2025-05-15 14:09:16 --> URI Class Initialized
INFO - 2025-05-15 14:09:16 --> Router Class Initialized
INFO - 2025-05-15 14:09:16 --> Output Class Initialized
INFO - 2025-05-15 14:09:16 --> Security Class Initialized
DEBUG - 2025-05-15 14:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:09:16 --> Input Class Initialized
INFO - 2025-05-15 14:09:16 --> Language Class Initialized
INFO - 2025-05-15 14:09:16 --> Loader Class Initialized
INFO - 2025-05-15 14:09:16 --> Helper loaded: url_helper
INFO - 2025-05-15 14:09:16 --> Helper loaded: form_helper
INFO - 2025-05-15 14:09:16 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:09:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:09:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:09:16 --> Controller Class Initialized
INFO - 2025-05-15 14:09:16 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:09:16 --> Model "User_model" initialized
INFO - 2025-05-15 14:09:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 14:09:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 14:09:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-15 14:09:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 14:09:16 --> Final output sent to browser
DEBUG - 2025-05-15 14:09:16 --> Total execution time: 0.0688
INFO - 2025-05-15 14:09:17 --> Config Class Initialized
INFO - 2025-05-15 14:09:17 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:09:17 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:09:17 --> Utf8 Class Initialized
INFO - 2025-05-15 14:09:17 --> URI Class Initialized
INFO - 2025-05-15 14:09:17 --> Router Class Initialized
INFO - 2025-05-15 14:09:17 --> Output Class Initialized
INFO - 2025-05-15 14:09:17 --> Security Class Initialized
DEBUG - 2025-05-15 14:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:09:17 --> Input Class Initialized
INFO - 2025-05-15 14:09:17 --> Language Class Initialized
INFO - 2025-05-15 14:09:17 --> Loader Class Initialized
INFO - 2025-05-15 14:09:17 --> Helper loaded: url_helper
INFO - 2025-05-15 14:09:17 --> Helper loaded: form_helper
INFO - 2025-05-15 14:09:17 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:09:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:09:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:09:17 --> Controller Class Initialized
INFO - 2025-05-15 14:09:17 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:09:17 --> Model "User_model" initialized
ERROR - 2025-05-15 14:09:17 --> Query error: Table 'fitnessrec.jadwal_fitness' doesn't exist - Invalid query: SELECT `tanggal`
FROM `jadwal_fitness`
WHERE `status` = 'selesai'
INFO - 2025-05-15 14:09:17 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-15 14:09:20 --> Config Class Initialized
INFO - 2025-05-15 14:09:20 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:09:20 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:09:20 --> Utf8 Class Initialized
INFO - 2025-05-15 14:09:20 --> URI Class Initialized
INFO - 2025-05-15 14:09:20 --> Router Class Initialized
INFO - 2025-05-15 14:09:20 --> Output Class Initialized
INFO - 2025-05-15 14:09:20 --> Security Class Initialized
DEBUG - 2025-05-15 14:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:09:20 --> Input Class Initialized
INFO - 2025-05-15 14:09:20 --> Language Class Initialized
INFO - 2025-05-15 14:09:20 --> Loader Class Initialized
INFO - 2025-05-15 14:09:20 --> Helper loaded: url_helper
INFO - 2025-05-15 14:09:20 --> Helper loaded: form_helper
INFO - 2025-05-15 14:09:20 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:09:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:09:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:09:20 --> Controller Class Initialized
INFO - 2025-05-15 14:09:20 --> Model "User_model" initialized
INFO - 2025-05-15 14:09:20 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:09:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 14:09:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 14:09:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-15 14:09:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 14:09:20 --> Final output sent to browser
DEBUG - 2025-05-15 14:09:20 --> Total execution time: 0.0817
INFO - 2025-05-15 14:09:23 --> Config Class Initialized
INFO - 2025-05-15 14:09:23 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:09:23 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:09:23 --> Utf8 Class Initialized
INFO - 2025-05-15 14:09:23 --> URI Class Initialized
INFO - 2025-05-15 14:09:23 --> Router Class Initialized
INFO - 2025-05-15 14:09:23 --> Output Class Initialized
INFO - 2025-05-15 14:09:23 --> Security Class Initialized
DEBUG - 2025-05-15 14:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:09:23 --> Input Class Initialized
INFO - 2025-05-15 14:09:23 --> Language Class Initialized
INFO - 2025-05-15 14:09:23 --> Loader Class Initialized
INFO - 2025-05-15 14:09:23 --> Helper loaded: url_helper
INFO - 2025-05-15 14:09:23 --> Helper loaded: form_helper
INFO - 2025-05-15 14:09:23 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:09:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:09:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:09:23 --> Controller Class Initialized
INFO - 2025-05-15 14:09:23 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:09:23 --> Model "User_model" initialized
INFO - 2025-05-15 14:09:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 14:09:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 14:09:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-15 14:09:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 14:09:23 --> Final output sent to browser
DEBUG - 2025-05-15 14:09:23 --> Total execution time: 0.0605
INFO - 2025-05-15 14:09:23 --> Config Class Initialized
INFO - 2025-05-15 14:09:23 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:09:23 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:09:23 --> Utf8 Class Initialized
INFO - 2025-05-15 14:09:23 --> URI Class Initialized
INFO - 2025-05-15 14:09:23 --> Router Class Initialized
INFO - 2025-05-15 14:09:23 --> Output Class Initialized
INFO - 2025-05-15 14:09:23 --> Security Class Initialized
DEBUG - 2025-05-15 14:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:09:23 --> Input Class Initialized
INFO - 2025-05-15 14:09:23 --> Language Class Initialized
INFO - 2025-05-15 14:09:23 --> Loader Class Initialized
INFO - 2025-05-15 14:09:23 --> Helper loaded: url_helper
INFO - 2025-05-15 14:09:23 --> Helper loaded: form_helper
INFO - 2025-05-15 14:09:23 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:09:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:09:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:09:23 --> Controller Class Initialized
INFO - 2025-05-15 14:09:23 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:09:23 --> Model "User_model" initialized
ERROR - 2025-05-15 14:09:23 --> Query error: Table 'fitnessrec.jadwal_fitness' doesn't exist - Invalid query: SELECT `tanggal`
FROM `jadwal_fitness`
WHERE `status` = 'selesai'
INFO - 2025-05-15 14:09:23 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-15 14:09:28 --> Config Class Initialized
INFO - 2025-05-15 14:09:28 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:09:28 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:09:28 --> Utf8 Class Initialized
INFO - 2025-05-15 14:09:28 --> URI Class Initialized
INFO - 2025-05-15 14:09:28 --> Router Class Initialized
INFO - 2025-05-15 14:09:28 --> Output Class Initialized
INFO - 2025-05-15 14:09:28 --> Security Class Initialized
DEBUG - 2025-05-15 14:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:09:28 --> Input Class Initialized
INFO - 2025-05-15 14:09:28 --> Language Class Initialized
INFO - 2025-05-15 14:09:28 --> Loader Class Initialized
INFO - 2025-05-15 14:09:28 --> Helper loaded: url_helper
INFO - 2025-05-15 14:09:28 --> Helper loaded: form_helper
INFO - 2025-05-15 14:09:28 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:09:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:09:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:09:28 --> Controller Class Initialized
INFO - 2025-05-15 14:09:28 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:09:28 --> Model "User_model" initialized
ERROR - 2025-05-15 14:09:28 --> Query error: Table 'fitnessrec.jadwal_fitness' doesn't exist - Invalid query: SELECT *
FROM `jadwal_fitness`
WHERE `tanggal` = '2025-05-15'
INFO - 2025-05-15 14:09:28 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-15 14:09:29 --> Config Class Initialized
INFO - 2025-05-15 14:09:29 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:09:29 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:09:29 --> Utf8 Class Initialized
INFO - 2025-05-15 14:09:29 --> URI Class Initialized
INFO - 2025-05-15 14:09:29 --> Router Class Initialized
INFO - 2025-05-15 14:09:29 --> Output Class Initialized
INFO - 2025-05-15 14:09:29 --> Security Class Initialized
DEBUG - 2025-05-15 14:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:09:29 --> Input Class Initialized
INFO - 2025-05-15 14:09:29 --> Language Class Initialized
INFO - 2025-05-15 14:09:29 --> Loader Class Initialized
INFO - 2025-05-15 14:09:29 --> Helper loaded: url_helper
INFO - 2025-05-15 14:09:29 --> Helper loaded: form_helper
INFO - 2025-05-15 14:09:29 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:09:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:09:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:09:29 --> Controller Class Initialized
INFO - 2025-05-15 14:09:29 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:09:29 --> Model "User_model" initialized
ERROR - 2025-05-15 14:09:29 --> Query error: Table 'fitnessrec.jadwal_fitness' doesn't exist - Invalid query: SELECT *
FROM `jadwal_fitness`
WHERE `tanggal` = '2025-05-15'
INFO - 2025-05-15 14:09:29 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-15 14:09:29 --> Config Class Initialized
INFO - 2025-05-15 14:09:29 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:09:29 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:09:29 --> Utf8 Class Initialized
INFO - 2025-05-15 14:09:29 --> URI Class Initialized
INFO - 2025-05-15 14:09:29 --> Router Class Initialized
INFO - 2025-05-15 14:09:29 --> Output Class Initialized
INFO - 2025-05-15 14:09:29 --> Security Class Initialized
DEBUG - 2025-05-15 14:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:09:29 --> Input Class Initialized
INFO - 2025-05-15 14:09:29 --> Language Class Initialized
INFO - 2025-05-15 14:09:29 --> Loader Class Initialized
INFO - 2025-05-15 14:09:29 --> Helper loaded: url_helper
INFO - 2025-05-15 14:09:29 --> Helper loaded: form_helper
INFO - 2025-05-15 14:09:29 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:09:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:09:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:09:29 --> Controller Class Initialized
INFO - 2025-05-15 14:09:29 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:09:29 --> Model "User_model" initialized
ERROR - 2025-05-15 14:09:29 --> Query error: Table 'fitnessrec.jadwal_fitness' doesn't exist - Invalid query: SELECT *
FROM `jadwal_fitness`
WHERE `tanggal` = '2025-05-15'
INFO - 2025-05-15 14:09:29 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-15 14:09:29 --> Config Class Initialized
INFO - 2025-05-15 14:09:29 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:09:29 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:09:29 --> Utf8 Class Initialized
INFO - 2025-05-15 14:09:29 --> URI Class Initialized
INFO - 2025-05-15 14:09:29 --> Router Class Initialized
INFO - 2025-05-15 14:09:29 --> Output Class Initialized
INFO - 2025-05-15 14:09:29 --> Security Class Initialized
DEBUG - 2025-05-15 14:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:09:29 --> Input Class Initialized
INFO - 2025-05-15 14:09:29 --> Language Class Initialized
INFO - 2025-05-15 14:09:29 --> Loader Class Initialized
INFO - 2025-05-15 14:09:29 --> Helper loaded: url_helper
INFO - 2025-05-15 14:09:29 --> Helper loaded: form_helper
INFO - 2025-05-15 14:09:29 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:09:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:09:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:09:29 --> Controller Class Initialized
INFO - 2025-05-15 14:09:29 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:09:29 --> Model "User_model" initialized
ERROR - 2025-05-15 14:09:29 --> Query error: Table 'fitnessrec.jadwal_fitness' doesn't exist - Invalid query: SELECT *
FROM `jadwal_fitness`
WHERE `tanggal` = '2025-05-08'
INFO - 2025-05-15 14:09:29 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-15 14:29:15 --> Config Class Initialized
INFO - 2025-05-15 14:29:15 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:29:15 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:29:15 --> Utf8 Class Initialized
INFO - 2025-05-15 14:29:15 --> URI Class Initialized
INFO - 2025-05-15 14:29:15 --> Router Class Initialized
INFO - 2025-05-15 14:29:15 --> Output Class Initialized
INFO - 2025-05-15 14:29:15 --> Security Class Initialized
DEBUG - 2025-05-15 14:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:29:15 --> Input Class Initialized
INFO - 2025-05-15 14:29:15 --> Language Class Initialized
INFO - 2025-05-15 14:29:15 --> Loader Class Initialized
INFO - 2025-05-15 14:29:15 --> Helper loaded: url_helper
INFO - 2025-05-15 14:29:15 --> Helper loaded: form_helper
INFO - 2025-05-15 14:29:15 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:29:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:29:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:29:15 --> Controller Class Initialized
INFO - 2025-05-15 14:29:15 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:29:15 --> Model "User_model" initialized
INFO - 2025-05-15 14:29:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 14:29:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 14:29:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-15 14:29:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 14:29:15 --> Final output sent to browser
DEBUG - 2025-05-15 14:29:15 --> Total execution time: 0.0743
INFO - 2025-05-15 14:29:15 --> Config Class Initialized
INFO - 2025-05-15 14:29:15 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:29:15 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:29:15 --> Utf8 Class Initialized
INFO - 2025-05-15 14:29:15 --> URI Class Initialized
INFO - 2025-05-15 14:29:15 --> Router Class Initialized
INFO - 2025-05-15 14:29:15 --> Output Class Initialized
INFO - 2025-05-15 14:29:15 --> Security Class Initialized
DEBUG - 2025-05-15 14:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:29:15 --> Input Class Initialized
INFO - 2025-05-15 14:29:15 --> Language Class Initialized
INFO - 2025-05-15 14:29:15 --> Loader Class Initialized
INFO - 2025-05-15 14:29:15 --> Helper loaded: url_helper
INFO - 2025-05-15 14:29:15 --> Helper loaded: form_helper
INFO - 2025-05-15 14:29:15 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:29:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:29:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:29:15 --> Controller Class Initialized
INFO - 2025-05-15 14:29:15 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:29:15 --> Model "User_model" initialized
ERROR - 2025-05-15 14:29:15 --> Query error: Table 'fitnessrec.jadwal_fitness' doesn't exist - Invalid query: SELECT `tanggal`
FROM `jadwal_fitness`
WHERE `status` = 'selesai'
INFO - 2025-05-15 14:29:15 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-15 14:29:18 --> Config Class Initialized
INFO - 2025-05-15 14:29:18 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:29:18 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:29:18 --> Utf8 Class Initialized
INFO - 2025-05-15 14:29:18 --> URI Class Initialized
INFO - 2025-05-15 14:29:18 --> Router Class Initialized
INFO - 2025-05-15 14:29:18 --> Output Class Initialized
INFO - 2025-05-15 14:29:18 --> Security Class Initialized
DEBUG - 2025-05-15 14:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:29:18 --> Input Class Initialized
INFO - 2025-05-15 14:29:18 --> Language Class Initialized
INFO - 2025-05-15 14:29:18 --> Loader Class Initialized
INFO - 2025-05-15 14:29:18 --> Helper loaded: url_helper
INFO - 2025-05-15 14:29:18 --> Helper loaded: form_helper
INFO - 2025-05-15 14:29:18 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:29:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:29:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:29:18 --> Controller Class Initialized
INFO - 2025-05-15 14:29:18 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:29:18 --> Model "User_model" initialized
ERROR - 2025-05-15 14:29:18 --> Query error: Table 'fitnessrec.jadwal_fitness' doesn't exist - Invalid query: SELECT *
FROM `jadwal_fitness`
WHERE `tanggal` = '2025-05-15'
INFO - 2025-05-15 14:29:18 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-15 14:29:19 --> Config Class Initialized
INFO - 2025-05-15 14:29:19 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:29:19 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:29:19 --> Utf8 Class Initialized
INFO - 2025-05-15 14:29:19 --> URI Class Initialized
INFO - 2025-05-15 14:29:19 --> Router Class Initialized
INFO - 2025-05-15 14:29:19 --> Output Class Initialized
INFO - 2025-05-15 14:29:19 --> Security Class Initialized
DEBUG - 2025-05-15 14:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:29:19 --> Input Class Initialized
INFO - 2025-05-15 14:29:19 --> Language Class Initialized
INFO - 2025-05-15 14:29:19 --> Loader Class Initialized
INFO - 2025-05-15 14:29:19 --> Helper loaded: url_helper
INFO - 2025-05-15 14:29:19 --> Helper loaded: form_helper
INFO - 2025-05-15 14:29:19 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:29:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:29:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:29:19 --> Controller Class Initialized
INFO - 2025-05-15 14:29:19 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:29:19 --> Model "User_model" initialized
ERROR - 2025-05-15 14:29:19 --> Query error: Table 'fitnessrec.jadwal_fitness' doesn't exist - Invalid query: SELECT *
FROM `jadwal_fitness`
WHERE `tanggal` = '2025-05-15'
INFO - 2025-05-15 14:29:19 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-15 14:29:19 --> Config Class Initialized
INFO - 2025-05-15 14:29:19 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:29:19 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:29:19 --> Utf8 Class Initialized
INFO - 2025-05-15 14:29:19 --> URI Class Initialized
INFO - 2025-05-15 14:29:19 --> Router Class Initialized
INFO - 2025-05-15 14:29:19 --> Output Class Initialized
INFO - 2025-05-15 14:29:19 --> Security Class Initialized
DEBUG - 2025-05-15 14:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:29:19 --> Input Class Initialized
INFO - 2025-05-15 14:29:19 --> Language Class Initialized
INFO - 2025-05-15 14:29:19 --> Loader Class Initialized
INFO - 2025-05-15 14:29:19 --> Helper loaded: url_helper
INFO - 2025-05-15 14:29:19 --> Helper loaded: form_helper
INFO - 2025-05-15 14:29:19 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:29:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:29:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:29:19 --> Controller Class Initialized
INFO - 2025-05-15 14:29:19 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:29:19 --> Model "User_model" initialized
ERROR - 2025-05-15 14:29:19 --> Query error: Table 'fitnessrec.jadwal_fitness' doesn't exist - Invalid query: SELECT *
FROM `jadwal_fitness`
WHERE `tanggal` = '2025-05-15'
INFO - 2025-05-15 14:29:19 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-15 14:29:23 --> Config Class Initialized
INFO - 2025-05-15 14:29:23 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:29:23 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:29:23 --> Utf8 Class Initialized
INFO - 2025-05-15 14:29:23 --> URI Class Initialized
INFO - 2025-05-15 14:29:23 --> Router Class Initialized
INFO - 2025-05-15 14:29:23 --> Output Class Initialized
INFO - 2025-05-15 14:29:23 --> Security Class Initialized
DEBUG - 2025-05-15 14:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:29:23 --> Input Class Initialized
INFO - 2025-05-15 14:29:23 --> Language Class Initialized
INFO - 2025-05-15 14:29:23 --> Loader Class Initialized
INFO - 2025-05-15 14:29:23 --> Helper loaded: url_helper
INFO - 2025-05-15 14:29:23 --> Helper loaded: form_helper
INFO - 2025-05-15 14:29:23 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:29:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:29:23 --> Controller Class Initialized
INFO - 2025-05-15 14:29:23 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:29:23 --> Model "User_model" initialized
ERROR - 2025-05-15 14:29:23 --> Query error: Table 'fitnessrec.jadwal_fitness' doesn't exist - Invalid query: SELECT `tanggal`
FROM `jadwal_fitness`
WHERE `status` = 'selesai'
INFO - 2025-05-15 14:29:23 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-15 14:29:26 --> Config Class Initialized
INFO - 2025-05-15 14:29:26 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:29:26 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:29:26 --> Utf8 Class Initialized
INFO - 2025-05-15 14:29:26 --> URI Class Initialized
INFO - 2025-05-15 14:29:26 --> Router Class Initialized
INFO - 2025-05-15 14:29:26 --> Output Class Initialized
INFO - 2025-05-15 14:29:26 --> Security Class Initialized
DEBUG - 2025-05-15 14:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:29:26 --> Input Class Initialized
INFO - 2025-05-15 14:29:26 --> Language Class Initialized
INFO - 2025-05-15 14:29:26 --> Loader Class Initialized
INFO - 2025-05-15 14:29:26 --> Helper loaded: url_helper
INFO - 2025-05-15 14:29:26 --> Helper loaded: form_helper
INFO - 2025-05-15 14:29:26 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:29:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:29:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:29:26 --> Controller Class Initialized
INFO - 2025-05-15 14:29:26 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:29:26 --> Model "User_model" initialized
ERROR - 2025-05-15 14:29:26 --> Query error: Table 'fitnessrec.jadwal_fitness' doesn't exist - Invalid query: SELECT `tanggal`
FROM `jadwal_fitness`
WHERE `status` = 'selesai'
INFO - 2025-05-15 14:29:26 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-15 14:29:56 --> Config Class Initialized
INFO - 2025-05-15 14:29:56 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:29:56 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:29:56 --> Utf8 Class Initialized
INFO - 2025-05-15 14:29:56 --> URI Class Initialized
INFO - 2025-05-15 14:29:56 --> Router Class Initialized
INFO - 2025-05-15 14:29:56 --> Output Class Initialized
INFO - 2025-05-15 14:29:56 --> Security Class Initialized
DEBUG - 2025-05-15 14:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:29:56 --> Input Class Initialized
INFO - 2025-05-15 14:29:56 --> Language Class Initialized
INFO - 2025-05-15 14:29:56 --> Loader Class Initialized
INFO - 2025-05-15 14:29:56 --> Helper loaded: url_helper
INFO - 2025-05-15 14:29:56 --> Helper loaded: form_helper
INFO - 2025-05-15 14:29:56 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:29:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:29:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:29:56 --> Controller Class Initialized
INFO - 2025-05-15 14:29:56 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:29:56 --> Model "User_model" initialized
INFO - 2025-05-15 14:29:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 14:29:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 14:29:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-15 14:29:56 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 14:29:56 --> Final output sent to browser
DEBUG - 2025-05-15 14:29:56 --> Total execution time: 0.0727
INFO - 2025-05-15 14:29:56 --> Config Class Initialized
INFO - 2025-05-15 14:29:56 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:29:56 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:29:56 --> Utf8 Class Initialized
INFO - 2025-05-15 14:29:56 --> URI Class Initialized
INFO - 2025-05-15 14:29:56 --> Router Class Initialized
INFO - 2025-05-15 14:29:56 --> Output Class Initialized
INFO - 2025-05-15 14:29:56 --> Security Class Initialized
DEBUG - 2025-05-15 14:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:29:56 --> Input Class Initialized
INFO - 2025-05-15 14:29:56 --> Language Class Initialized
INFO - 2025-05-15 14:29:56 --> Loader Class Initialized
INFO - 2025-05-15 14:29:56 --> Helper loaded: url_helper
INFO - 2025-05-15 14:29:56 --> Helper loaded: form_helper
INFO - 2025-05-15 14:29:56 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:29:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:29:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:29:56 --> Controller Class Initialized
INFO - 2025-05-15 14:29:56 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:29:56 --> Model "User_model" initialized
ERROR - 2025-05-15 14:29:56 --> Query error: Table 'fitnessrec.jadwal_fitness' doesn't exist - Invalid query: SELECT `tanggal`
FROM `jadwal_fitness`
WHERE `status` = 'selesai'
INFO - 2025-05-15 14:29:56 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-15 14:30:02 --> Config Class Initialized
INFO - 2025-05-15 14:30:02 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:30:02 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:30:02 --> Utf8 Class Initialized
INFO - 2025-05-15 14:30:02 --> URI Class Initialized
INFO - 2025-05-15 14:30:02 --> Router Class Initialized
INFO - 2025-05-15 14:30:02 --> Output Class Initialized
INFO - 2025-05-15 14:30:02 --> Security Class Initialized
DEBUG - 2025-05-15 14:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:30:02 --> Input Class Initialized
INFO - 2025-05-15 14:30:02 --> Language Class Initialized
INFO - 2025-05-15 14:30:02 --> Loader Class Initialized
INFO - 2025-05-15 14:30:02 --> Helper loaded: url_helper
INFO - 2025-05-15 14:30:02 --> Helper loaded: form_helper
INFO - 2025-05-15 14:30:02 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:30:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:30:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:30:02 --> Controller Class Initialized
INFO - 2025-05-15 14:30:02 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:30:02 --> Model "User_model" initialized
ERROR - 2025-05-15 14:30:02 --> Query error: Table 'fitnessrec.jadwal_fitness' doesn't exist - Invalid query: SELECT *
FROM `jadwal_fitness`
WHERE `tanggal` = '2025-05-15'
INFO - 2025-05-15 14:30:02 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-15 14:30:03 --> Config Class Initialized
INFO - 2025-05-15 14:30:03 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:30:03 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:30:03 --> Utf8 Class Initialized
INFO - 2025-05-15 14:30:03 --> URI Class Initialized
INFO - 2025-05-15 14:30:03 --> Router Class Initialized
INFO - 2025-05-15 14:30:03 --> Output Class Initialized
INFO - 2025-05-15 14:30:03 --> Security Class Initialized
DEBUG - 2025-05-15 14:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:30:03 --> Input Class Initialized
INFO - 2025-05-15 14:30:03 --> Language Class Initialized
INFO - 2025-05-15 14:30:03 --> Loader Class Initialized
INFO - 2025-05-15 14:30:03 --> Helper loaded: url_helper
INFO - 2025-05-15 14:30:03 --> Helper loaded: form_helper
INFO - 2025-05-15 14:30:03 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:30:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:30:03 --> Controller Class Initialized
INFO - 2025-05-15 14:30:03 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:30:03 --> Model "User_model" initialized
ERROR - 2025-05-15 14:30:03 --> Query error: Table 'fitnessrec.jadwal_fitness' doesn't exist - Invalid query: SELECT *
FROM `jadwal_fitness`
WHERE `tanggal` = '2025-05-15'
INFO - 2025-05-15 14:30:03 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-15 14:30:03 --> Config Class Initialized
INFO - 2025-05-15 14:30:03 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:30:03 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:30:03 --> Utf8 Class Initialized
INFO - 2025-05-15 14:30:03 --> URI Class Initialized
INFO - 2025-05-15 14:30:03 --> Router Class Initialized
INFO - 2025-05-15 14:30:03 --> Output Class Initialized
INFO - 2025-05-15 14:30:03 --> Security Class Initialized
DEBUG - 2025-05-15 14:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:30:03 --> Input Class Initialized
INFO - 2025-05-15 14:30:03 --> Language Class Initialized
INFO - 2025-05-15 14:30:03 --> Loader Class Initialized
INFO - 2025-05-15 14:30:03 --> Helper loaded: url_helper
INFO - 2025-05-15 14:30:03 --> Helper loaded: form_helper
INFO - 2025-05-15 14:30:03 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:30:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:30:03 --> Controller Class Initialized
INFO - 2025-05-15 14:30:03 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:30:03 --> Model "User_model" initialized
ERROR - 2025-05-15 14:30:03 --> Query error: Table 'fitnessrec.jadwal_fitness' doesn't exist - Invalid query: SELECT *
FROM `jadwal_fitness`
WHERE `tanggal` = '2025-05-15'
INFO - 2025-05-15 14:30:03 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-15 14:30:03 --> Config Class Initialized
INFO - 2025-05-15 14:30:03 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:30:03 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:30:03 --> Utf8 Class Initialized
INFO - 2025-05-15 14:30:03 --> URI Class Initialized
INFO - 2025-05-15 14:30:03 --> Router Class Initialized
INFO - 2025-05-15 14:30:03 --> Output Class Initialized
INFO - 2025-05-15 14:30:03 --> Security Class Initialized
DEBUG - 2025-05-15 14:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:30:03 --> Input Class Initialized
INFO - 2025-05-15 14:30:03 --> Language Class Initialized
INFO - 2025-05-15 14:30:03 --> Loader Class Initialized
INFO - 2025-05-15 14:30:03 --> Helper loaded: url_helper
INFO - 2025-05-15 14:30:03 --> Helper loaded: form_helper
INFO - 2025-05-15 14:30:03 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:30:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:30:03 --> Controller Class Initialized
INFO - 2025-05-15 14:30:03 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:30:03 --> Model "User_model" initialized
ERROR - 2025-05-15 14:30:03 --> Query error: Table 'fitnessrec.jadwal_fitness' doesn't exist - Invalid query: SELECT *
FROM `jadwal_fitness`
WHERE `tanggal` = '2025-05-15'
INFO - 2025-05-15 14:30:03 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-15 14:30:03 --> Config Class Initialized
INFO - 2025-05-15 14:30:03 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:30:03 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:30:03 --> Utf8 Class Initialized
INFO - 2025-05-15 14:30:03 --> URI Class Initialized
INFO - 2025-05-15 14:30:03 --> Router Class Initialized
INFO - 2025-05-15 14:30:03 --> Output Class Initialized
INFO - 2025-05-15 14:30:03 --> Security Class Initialized
DEBUG - 2025-05-15 14:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:30:03 --> Input Class Initialized
INFO - 2025-05-15 14:30:03 --> Language Class Initialized
INFO - 2025-05-15 14:30:03 --> Loader Class Initialized
INFO - 2025-05-15 14:30:03 --> Helper loaded: url_helper
INFO - 2025-05-15 14:30:03 --> Helper loaded: form_helper
INFO - 2025-05-15 14:30:03 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:30:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:30:03 --> Controller Class Initialized
INFO - 2025-05-15 14:30:03 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:30:03 --> Model "User_model" initialized
ERROR - 2025-05-15 14:30:03 --> Query error: Table 'fitnessrec.jadwal_fitness' doesn't exist - Invalid query: SELECT *
FROM `jadwal_fitness`
WHERE `tanggal` = '2025-05-15'
INFO - 2025-05-15 14:30:03 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-15 14:30:03 --> Config Class Initialized
INFO - 2025-05-15 14:30:03 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:30:03 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:30:03 --> Utf8 Class Initialized
INFO - 2025-05-15 14:30:03 --> URI Class Initialized
INFO - 2025-05-15 14:30:03 --> Router Class Initialized
INFO - 2025-05-15 14:30:03 --> Output Class Initialized
INFO - 2025-05-15 14:30:03 --> Security Class Initialized
DEBUG - 2025-05-15 14:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:30:03 --> Input Class Initialized
INFO - 2025-05-15 14:30:03 --> Language Class Initialized
INFO - 2025-05-15 14:30:03 --> Loader Class Initialized
INFO - 2025-05-15 14:30:03 --> Helper loaded: url_helper
INFO - 2025-05-15 14:30:03 --> Helper loaded: form_helper
INFO - 2025-05-15 14:30:03 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:30:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:30:03 --> Controller Class Initialized
INFO - 2025-05-15 14:30:03 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:30:03 --> Model "User_model" initialized
ERROR - 2025-05-15 14:30:03 --> Query error: Table 'fitnessrec.jadwal_fitness' doesn't exist - Invalid query: SELECT *
FROM `jadwal_fitness`
WHERE `tanggal` = '2025-05-15'
INFO - 2025-05-15 14:30:03 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-15 14:30:05 --> Config Class Initialized
INFO - 2025-05-15 14:30:05 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:30:05 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:30:05 --> Utf8 Class Initialized
INFO - 2025-05-15 14:30:05 --> URI Class Initialized
INFO - 2025-05-15 14:30:05 --> Router Class Initialized
INFO - 2025-05-15 14:30:05 --> Output Class Initialized
INFO - 2025-05-15 14:30:05 --> Security Class Initialized
DEBUG - 2025-05-15 14:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:30:05 --> Input Class Initialized
INFO - 2025-05-15 14:30:05 --> Language Class Initialized
INFO - 2025-05-15 14:30:05 --> Loader Class Initialized
INFO - 2025-05-15 14:30:05 --> Helper loaded: url_helper
INFO - 2025-05-15 14:30:05 --> Helper loaded: form_helper
INFO - 2025-05-15 14:30:05 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:30:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:30:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:30:05 --> Controller Class Initialized
INFO - 2025-05-15 14:30:05 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:30:05 --> Model "User_model" initialized
ERROR - 2025-05-15 14:30:05 --> Query error: Table 'fitnessrec.jadwal_fitness' doesn't exist - Invalid query: SELECT *
FROM `jadwal_fitness`
WHERE `tanggal` = '2025-05-15'
INFO - 2025-05-15 14:30:05 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-15 14:30:05 --> Config Class Initialized
INFO - 2025-05-15 14:30:05 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:30:05 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:30:05 --> Utf8 Class Initialized
INFO - 2025-05-15 14:30:05 --> URI Class Initialized
INFO - 2025-05-15 14:30:05 --> Router Class Initialized
INFO - 2025-05-15 14:30:05 --> Output Class Initialized
INFO - 2025-05-15 14:30:05 --> Security Class Initialized
DEBUG - 2025-05-15 14:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:30:05 --> Input Class Initialized
INFO - 2025-05-15 14:30:05 --> Language Class Initialized
INFO - 2025-05-15 14:30:05 --> Loader Class Initialized
INFO - 2025-05-15 14:30:05 --> Helper loaded: url_helper
INFO - 2025-05-15 14:30:05 --> Helper loaded: form_helper
INFO - 2025-05-15 14:30:05 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:30:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:30:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:30:05 --> Controller Class Initialized
INFO - 2025-05-15 14:30:06 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:30:06 --> Model "User_model" initialized
ERROR - 2025-05-15 14:30:06 --> Query error: Table 'fitnessrec.jadwal_fitness' doesn't exist - Invalid query: SELECT *
FROM `jadwal_fitness`
WHERE `tanggal` = '2025-05-15'
INFO - 2025-05-15 14:30:06 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-15 14:30:07 --> Config Class Initialized
INFO - 2025-05-15 14:30:07 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:30:07 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:30:07 --> Utf8 Class Initialized
INFO - 2025-05-15 14:30:07 --> URI Class Initialized
INFO - 2025-05-15 14:30:07 --> Router Class Initialized
INFO - 2025-05-15 14:30:07 --> Output Class Initialized
INFO - 2025-05-15 14:30:07 --> Security Class Initialized
DEBUG - 2025-05-15 14:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:30:07 --> Input Class Initialized
INFO - 2025-05-15 14:30:07 --> Language Class Initialized
INFO - 2025-05-15 14:30:07 --> Loader Class Initialized
INFO - 2025-05-15 14:30:07 --> Helper loaded: url_helper
INFO - 2025-05-15 14:30:07 --> Helper loaded: form_helper
INFO - 2025-05-15 14:30:07 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:30:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:30:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:30:07 --> Controller Class Initialized
INFO - 2025-05-15 14:30:07 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:30:07 --> Model "User_model" initialized
ERROR - 2025-05-15 14:30:07 --> Query error: Table 'fitnessrec.jadwal_fitness' doesn't exist - Invalid query: SELECT `tanggal`
FROM `jadwal_fitness`
WHERE `status` = 'selesai'
INFO - 2025-05-15 14:30:07 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-15 14:30:10 --> Config Class Initialized
INFO - 2025-05-15 14:30:10 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:30:10 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:30:10 --> Utf8 Class Initialized
INFO - 2025-05-15 14:30:10 --> URI Class Initialized
INFO - 2025-05-15 14:30:10 --> Router Class Initialized
INFO - 2025-05-15 14:30:10 --> Output Class Initialized
INFO - 2025-05-15 14:30:10 --> Security Class Initialized
DEBUG - 2025-05-15 14:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:30:10 --> Input Class Initialized
INFO - 2025-05-15 14:30:10 --> Language Class Initialized
INFO - 2025-05-15 14:30:10 --> Loader Class Initialized
INFO - 2025-05-15 14:30:10 --> Helper loaded: url_helper
INFO - 2025-05-15 14:30:10 --> Helper loaded: form_helper
INFO - 2025-05-15 14:30:10 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:30:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:30:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:30:10 --> Controller Class Initialized
INFO - 2025-05-15 14:30:10 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:30:10 --> Model "User_model" initialized
ERROR - 2025-05-15 14:30:10 --> Query error: Table 'fitnessrec.jadwal_fitness' doesn't exist - Invalid query: SELECT `tanggal`
FROM `jadwal_fitness`
WHERE `status` = 'selesai'
INFO - 2025-05-15 14:30:10 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-15 14:30:57 --> Config Class Initialized
INFO - 2025-05-15 14:30:57 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:30:57 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:30:57 --> Utf8 Class Initialized
INFO - 2025-05-15 14:30:57 --> URI Class Initialized
INFO - 2025-05-15 14:30:57 --> Router Class Initialized
INFO - 2025-05-15 14:30:57 --> Output Class Initialized
INFO - 2025-05-15 14:30:57 --> Security Class Initialized
DEBUG - 2025-05-15 14:30:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:30:57 --> Input Class Initialized
INFO - 2025-05-15 14:30:57 --> Language Class Initialized
INFO - 2025-05-15 14:30:57 --> Loader Class Initialized
INFO - 2025-05-15 14:30:57 --> Helper loaded: url_helper
INFO - 2025-05-15 14:30:57 --> Helper loaded: form_helper
INFO - 2025-05-15 14:30:57 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:30:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:30:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:30:57 --> Controller Class Initialized
INFO - 2025-05-15 14:30:57 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:30:57 --> Model "User_model" initialized
INFO - 2025-05-15 14:30:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 14:30:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 14:30:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-15 14:30:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 14:30:57 --> Final output sent to browser
DEBUG - 2025-05-15 14:30:57 --> Total execution time: 0.0691
INFO - 2025-05-15 14:30:58 --> Config Class Initialized
INFO - 2025-05-15 14:30:58 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:30:58 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:30:58 --> Utf8 Class Initialized
INFO - 2025-05-15 14:30:58 --> URI Class Initialized
INFO - 2025-05-15 14:30:58 --> Router Class Initialized
INFO - 2025-05-15 14:30:58 --> Output Class Initialized
INFO - 2025-05-15 14:30:58 --> Security Class Initialized
DEBUG - 2025-05-15 14:30:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:30:58 --> Input Class Initialized
INFO - 2025-05-15 14:30:58 --> Language Class Initialized
INFO - 2025-05-15 14:30:58 --> Loader Class Initialized
INFO - 2025-05-15 14:30:58 --> Helper loaded: url_helper
INFO - 2025-05-15 14:30:58 --> Helper loaded: form_helper
INFO - 2025-05-15 14:30:58 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:30:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:30:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:30:58 --> Controller Class Initialized
INFO - 2025-05-15 14:30:58 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:30:58 --> Model "User_model" initialized
ERROR - 2025-05-15 14:30:58 --> Query error: Table 'fitnessrec.jadwal_fitness' doesn't exist - Invalid query: SELECT `tanggal`
FROM `jadwal_fitness`
WHERE `status` = 'selesai'
INFO - 2025-05-15 14:30:58 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-15 14:31:02 --> Config Class Initialized
INFO - 2025-05-15 14:31:02 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:31:02 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:31:02 --> Utf8 Class Initialized
INFO - 2025-05-15 14:31:02 --> URI Class Initialized
INFO - 2025-05-15 14:31:02 --> Router Class Initialized
INFO - 2025-05-15 14:31:02 --> Output Class Initialized
INFO - 2025-05-15 14:31:02 --> Security Class Initialized
DEBUG - 2025-05-15 14:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:31:02 --> Input Class Initialized
INFO - 2025-05-15 14:31:02 --> Language Class Initialized
INFO - 2025-05-15 14:31:02 --> Loader Class Initialized
INFO - 2025-05-15 14:31:02 --> Helper loaded: url_helper
INFO - 2025-05-15 14:31:02 --> Helper loaded: form_helper
INFO - 2025-05-15 14:31:02 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:31:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:31:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:31:02 --> Controller Class Initialized
INFO - 2025-05-15 14:31:02 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:31:02 --> Model "User_model" initialized
ERROR - 2025-05-15 14:31:02 --> Query error: Table 'fitnessrec.jadwal_fitness' doesn't exist - Invalid query: INSERT INTO `jadwal_fitness` (`tanggal`, `kegiatan`, `status`) VALUES ('', 'Workout rutin', 'proses')
INFO - 2025-05-15 14:31:02 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-15 14:31:03 --> Config Class Initialized
INFO - 2025-05-15 14:31:03 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:31:03 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:31:03 --> Utf8 Class Initialized
INFO - 2025-05-15 14:31:03 --> URI Class Initialized
INFO - 2025-05-15 14:31:03 --> Router Class Initialized
INFO - 2025-05-15 14:31:03 --> Output Class Initialized
INFO - 2025-05-15 14:31:03 --> Security Class Initialized
DEBUG - 2025-05-15 14:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:31:03 --> Input Class Initialized
INFO - 2025-05-15 14:31:03 --> Language Class Initialized
INFO - 2025-05-15 14:31:03 --> Loader Class Initialized
INFO - 2025-05-15 14:31:03 --> Helper loaded: url_helper
INFO - 2025-05-15 14:31:03 --> Helper loaded: form_helper
INFO - 2025-05-15 14:31:03 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:31:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:31:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:31:03 --> Controller Class Initialized
INFO - 2025-05-15 14:31:03 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:31:03 --> Model "User_model" initialized
ERROR - 2025-05-15 14:31:03 --> Query error: Table 'fitnessrec.jadwal_fitness' doesn't exist - Invalid query: INSERT INTO `jadwal_fitness` (`tanggal`, `kegiatan`, `status`) VALUES ('', 'Workout rutin', 'proses')
INFO - 2025-05-15 14:31:03 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-15 14:31:03 --> Config Class Initialized
INFO - 2025-05-15 14:31:03 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:31:03 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:31:03 --> Utf8 Class Initialized
INFO - 2025-05-15 14:31:03 --> URI Class Initialized
INFO - 2025-05-15 14:31:03 --> Router Class Initialized
INFO - 2025-05-15 14:31:03 --> Output Class Initialized
INFO - 2025-05-15 14:31:03 --> Security Class Initialized
DEBUG - 2025-05-15 14:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:31:03 --> Input Class Initialized
INFO - 2025-05-15 14:31:03 --> Language Class Initialized
INFO - 2025-05-15 14:31:03 --> Loader Class Initialized
INFO - 2025-05-15 14:31:03 --> Helper loaded: url_helper
INFO - 2025-05-15 14:31:03 --> Helper loaded: form_helper
INFO - 2025-05-15 14:31:03 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:31:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:31:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:31:03 --> Controller Class Initialized
INFO - 2025-05-15 14:31:03 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:31:03 --> Model "User_model" initialized
ERROR - 2025-05-15 14:31:03 --> Query error: Table 'fitnessrec.jadwal_fitness' doesn't exist - Invalid query: INSERT INTO `jadwal_fitness` (`tanggal`, `kegiatan`, `status`) VALUES ('', 'Workout rutin', 'proses')
INFO - 2025-05-15 14:31:03 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-15 14:31:03 --> Config Class Initialized
INFO - 2025-05-15 14:31:03 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:31:03 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:31:03 --> Utf8 Class Initialized
INFO - 2025-05-15 14:31:03 --> URI Class Initialized
INFO - 2025-05-15 14:31:03 --> Router Class Initialized
INFO - 2025-05-15 14:31:03 --> Output Class Initialized
INFO - 2025-05-15 14:31:03 --> Security Class Initialized
DEBUG - 2025-05-15 14:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:31:03 --> Input Class Initialized
INFO - 2025-05-15 14:31:03 --> Language Class Initialized
INFO - 2025-05-15 14:31:03 --> Loader Class Initialized
INFO - 2025-05-15 14:31:03 --> Helper loaded: url_helper
INFO - 2025-05-15 14:31:03 --> Helper loaded: form_helper
INFO - 2025-05-15 14:31:03 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:31:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:31:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:31:03 --> Controller Class Initialized
INFO - 2025-05-15 14:31:03 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:31:03 --> Model "User_model" initialized
ERROR - 2025-05-15 14:31:03 --> Query error: Table 'fitnessrec.jadwal_fitness' doesn't exist - Invalid query: INSERT INTO `jadwal_fitness` (`tanggal`, `kegiatan`, `status`) VALUES ('', 'Workout rutin', 'proses')
INFO - 2025-05-15 14:31:03 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-15 14:31:03 --> Config Class Initialized
INFO - 2025-05-15 14:31:03 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:31:03 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:31:03 --> Utf8 Class Initialized
INFO - 2025-05-15 14:31:03 --> URI Class Initialized
INFO - 2025-05-15 14:31:03 --> Router Class Initialized
INFO - 2025-05-15 14:31:03 --> Output Class Initialized
INFO - 2025-05-15 14:31:03 --> Security Class Initialized
DEBUG - 2025-05-15 14:31:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:31:03 --> Input Class Initialized
INFO - 2025-05-15 14:31:03 --> Language Class Initialized
INFO - 2025-05-15 14:31:03 --> Loader Class Initialized
INFO - 2025-05-15 14:31:03 --> Helper loaded: url_helper
INFO - 2025-05-15 14:31:03 --> Helper loaded: form_helper
INFO - 2025-05-15 14:31:03 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:31:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:31:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:31:03 --> Controller Class Initialized
INFO - 2025-05-15 14:31:03 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:31:03 --> Model "User_model" initialized
ERROR - 2025-05-15 14:31:03 --> Query error: Table 'fitnessrec.jadwal_fitness' doesn't exist - Invalid query: INSERT INTO `jadwal_fitness` (`tanggal`, `kegiatan`, `status`) VALUES ('', 'Workout rutin', 'proses')
INFO - 2025-05-15 14:31:03 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-15 14:31:04 --> Config Class Initialized
INFO - 2025-05-15 14:31:04 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:31:04 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:31:04 --> Utf8 Class Initialized
INFO - 2025-05-15 14:31:04 --> URI Class Initialized
INFO - 2025-05-15 14:31:04 --> Router Class Initialized
INFO - 2025-05-15 14:31:04 --> Output Class Initialized
INFO - 2025-05-15 14:31:04 --> Security Class Initialized
DEBUG - 2025-05-15 14:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:31:04 --> Input Class Initialized
INFO - 2025-05-15 14:31:04 --> Language Class Initialized
INFO - 2025-05-15 14:31:04 --> Loader Class Initialized
INFO - 2025-05-15 14:31:04 --> Helper loaded: url_helper
INFO - 2025-05-15 14:31:04 --> Helper loaded: form_helper
INFO - 2025-05-15 14:31:04 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:31:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:31:04 --> Controller Class Initialized
INFO - 2025-05-15 14:31:04 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:31:04 --> Model "User_model" initialized
ERROR - 2025-05-15 14:31:04 --> Query error: Table 'fitnessrec.jadwal_fitness' doesn't exist - Invalid query: INSERT INTO `jadwal_fitness` (`tanggal`, `kegiatan`, `status`) VALUES ('', 'Workout rutin', 'proses')
INFO - 2025-05-15 14:31:04 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-15 14:31:05 --> Config Class Initialized
INFO - 2025-05-15 14:31:05 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:31:05 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:31:05 --> Utf8 Class Initialized
INFO - 2025-05-15 14:31:05 --> URI Class Initialized
INFO - 2025-05-15 14:31:05 --> Router Class Initialized
INFO - 2025-05-15 14:31:05 --> Output Class Initialized
INFO - 2025-05-15 14:31:05 --> Security Class Initialized
DEBUG - 2025-05-15 14:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:31:05 --> Input Class Initialized
INFO - 2025-05-15 14:31:05 --> Language Class Initialized
INFO - 2025-05-15 14:31:05 --> Loader Class Initialized
INFO - 2025-05-15 14:31:05 --> Helper loaded: url_helper
INFO - 2025-05-15 14:31:05 --> Helper loaded: form_helper
INFO - 2025-05-15 14:31:05 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:31:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:31:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:31:05 --> Controller Class Initialized
INFO - 2025-05-15 14:31:05 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:31:05 --> Model "User_model" initialized
ERROR - 2025-05-15 14:31:05 --> Query error: Table 'fitnessrec.jadwal_fitness' doesn't exist - Invalid query: INSERT INTO `jadwal_fitness` (`tanggal`, `kegiatan`, `status`) VALUES ('', 'Workout rutin', 'proses')
INFO - 2025-05-15 14:31:05 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-15 14:31:05 --> Config Class Initialized
INFO - 2025-05-15 14:31:05 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:31:05 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:31:05 --> Utf8 Class Initialized
INFO - 2025-05-15 14:31:05 --> URI Class Initialized
INFO - 2025-05-15 14:31:05 --> Router Class Initialized
INFO - 2025-05-15 14:31:05 --> Output Class Initialized
INFO - 2025-05-15 14:31:05 --> Security Class Initialized
DEBUG - 2025-05-15 14:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:31:05 --> Input Class Initialized
INFO - 2025-05-15 14:31:05 --> Language Class Initialized
INFO - 2025-05-15 14:31:05 --> Loader Class Initialized
INFO - 2025-05-15 14:31:05 --> Helper loaded: url_helper
INFO - 2025-05-15 14:31:05 --> Helper loaded: form_helper
INFO - 2025-05-15 14:31:05 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:31:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:31:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:31:05 --> Controller Class Initialized
INFO - 2025-05-15 14:31:05 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:31:05 --> Model "User_model" initialized
ERROR - 2025-05-15 14:31:05 --> Query error: Table 'fitnessrec.jadwal_fitness' doesn't exist - Invalid query: INSERT INTO `jadwal_fitness` (`tanggal`, `kegiatan`, `status`) VALUES ('', 'Workout rutin', 'proses')
INFO - 2025-05-15 14:31:05 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-15 14:31:05 --> Config Class Initialized
INFO - 2025-05-15 14:31:05 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:31:05 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:31:05 --> Utf8 Class Initialized
INFO - 2025-05-15 14:31:05 --> URI Class Initialized
INFO - 2025-05-15 14:31:05 --> Router Class Initialized
INFO - 2025-05-15 14:31:05 --> Output Class Initialized
INFO - 2025-05-15 14:31:05 --> Security Class Initialized
DEBUG - 2025-05-15 14:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:31:05 --> Input Class Initialized
INFO - 2025-05-15 14:31:05 --> Language Class Initialized
INFO - 2025-05-15 14:31:05 --> Loader Class Initialized
INFO - 2025-05-15 14:31:05 --> Helper loaded: url_helper
INFO - 2025-05-15 14:31:05 --> Helper loaded: form_helper
INFO - 2025-05-15 14:31:05 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:31:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:31:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:31:05 --> Controller Class Initialized
INFO - 2025-05-15 14:31:05 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:31:05 --> Model "User_model" initialized
ERROR - 2025-05-15 14:31:05 --> Query error: Table 'fitnessrec.jadwal_fitness' doesn't exist - Invalid query: INSERT INTO `jadwal_fitness` (`tanggal`, `kegiatan`, `status`) VALUES ('', 'Workout rutin', 'proses')
INFO - 2025-05-15 14:31:05 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-15 14:31:05 --> Config Class Initialized
INFO - 2025-05-15 14:31:05 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:31:05 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:31:05 --> Utf8 Class Initialized
INFO - 2025-05-15 14:31:05 --> URI Class Initialized
INFO - 2025-05-15 14:31:05 --> Router Class Initialized
INFO - 2025-05-15 14:31:05 --> Output Class Initialized
INFO - 2025-05-15 14:31:05 --> Security Class Initialized
DEBUG - 2025-05-15 14:31:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:31:05 --> Input Class Initialized
INFO - 2025-05-15 14:31:05 --> Language Class Initialized
INFO - 2025-05-15 14:31:05 --> Loader Class Initialized
INFO - 2025-05-15 14:31:05 --> Helper loaded: url_helper
INFO - 2025-05-15 14:31:05 --> Helper loaded: form_helper
INFO - 2025-05-15 14:31:05 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:31:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:31:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:31:05 --> Controller Class Initialized
INFO - 2025-05-15 14:31:05 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:31:05 --> Model "User_model" initialized
ERROR - 2025-05-15 14:31:05 --> Query error: Table 'fitnessrec.jadwal_fitness' doesn't exist - Invalid query: INSERT INTO `jadwal_fitness` (`tanggal`, `kegiatan`, `status`) VALUES ('', 'Workout rutin', 'proses')
INFO - 2025-05-15 14:31:05 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-15 14:31:17 --> Config Class Initialized
INFO - 2025-05-15 14:31:17 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:31:17 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:31:17 --> Utf8 Class Initialized
INFO - 2025-05-15 14:31:17 --> URI Class Initialized
INFO - 2025-05-15 14:31:17 --> Router Class Initialized
INFO - 2025-05-15 14:31:17 --> Output Class Initialized
INFO - 2025-05-15 14:31:17 --> Security Class Initialized
DEBUG - 2025-05-15 14:31:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:31:17 --> Input Class Initialized
INFO - 2025-05-15 14:31:17 --> Language Class Initialized
INFO - 2025-05-15 14:31:17 --> Loader Class Initialized
INFO - 2025-05-15 14:31:17 --> Helper loaded: url_helper
INFO - 2025-05-15 14:31:17 --> Helper loaded: form_helper
INFO - 2025-05-15 14:31:17 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:31:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:31:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:31:17 --> Controller Class Initialized
INFO - 2025-05-15 14:31:17 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:31:17 --> Model "User_model" initialized
ERROR - 2025-05-15 14:31:17 --> Query error: Table 'fitnessrec.jadwal_fitness' doesn't exist - Invalid query: SELECT *
FROM `jadwal_fitness`
WHERE `tanggal` = '2025-05-15'
INFO - 2025-05-15 14:31:17 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-15 14:31:18 --> Config Class Initialized
INFO - 2025-05-15 14:31:18 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:31:18 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:31:18 --> Utf8 Class Initialized
INFO - 2025-05-15 14:31:18 --> URI Class Initialized
INFO - 2025-05-15 14:31:18 --> Router Class Initialized
INFO - 2025-05-15 14:31:18 --> Output Class Initialized
INFO - 2025-05-15 14:31:18 --> Security Class Initialized
DEBUG - 2025-05-15 14:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:31:18 --> Input Class Initialized
INFO - 2025-05-15 14:31:18 --> Language Class Initialized
INFO - 2025-05-15 14:31:18 --> Loader Class Initialized
INFO - 2025-05-15 14:31:18 --> Helper loaded: url_helper
INFO - 2025-05-15 14:31:18 --> Helper loaded: form_helper
INFO - 2025-05-15 14:31:18 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:31:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:31:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:31:18 --> Controller Class Initialized
INFO - 2025-05-15 14:31:18 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:31:18 --> Model "User_model" initialized
ERROR - 2025-05-15 14:31:18 --> Query error: Table 'fitnessrec.jadwal_fitness' doesn't exist - Invalid query: SELECT *
FROM `jadwal_fitness`
WHERE `tanggal` = '2025-05-15'
INFO - 2025-05-15 14:31:18 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-15 14:31:18 --> Config Class Initialized
INFO - 2025-05-15 14:31:18 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:31:18 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:31:18 --> Utf8 Class Initialized
INFO - 2025-05-15 14:31:18 --> URI Class Initialized
INFO - 2025-05-15 14:31:18 --> Router Class Initialized
INFO - 2025-05-15 14:31:18 --> Output Class Initialized
INFO - 2025-05-15 14:31:18 --> Security Class Initialized
DEBUG - 2025-05-15 14:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:31:18 --> Input Class Initialized
INFO - 2025-05-15 14:31:18 --> Language Class Initialized
INFO - 2025-05-15 14:31:18 --> Loader Class Initialized
INFO - 2025-05-15 14:31:18 --> Helper loaded: url_helper
INFO - 2025-05-15 14:31:18 --> Helper loaded: form_helper
INFO - 2025-05-15 14:31:18 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:31:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:31:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:31:18 --> Controller Class Initialized
INFO - 2025-05-15 14:31:18 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:31:18 --> Model "User_model" initialized
ERROR - 2025-05-15 14:31:18 --> Query error: Table 'fitnessrec.jadwal_fitness' doesn't exist - Invalid query: SELECT *
FROM `jadwal_fitness`
WHERE `tanggal` = '2025-05-15'
INFO - 2025-05-15 14:31:18 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-15 14:31:18 --> Config Class Initialized
INFO - 2025-05-15 14:31:18 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:31:18 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:31:18 --> Utf8 Class Initialized
INFO - 2025-05-15 14:31:18 --> URI Class Initialized
INFO - 2025-05-15 14:31:18 --> Router Class Initialized
INFO - 2025-05-15 14:31:18 --> Output Class Initialized
INFO - 2025-05-15 14:31:18 --> Security Class Initialized
DEBUG - 2025-05-15 14:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:31:18 --> Input Class Initialized
INFO - 2025-05-15 14:31:18 --> Language Class Initialized
INFO - 2025-05-15 14:31:18 --> Loader Class Initialized
INFO - 2025-05-15 14:31:18 --> Helper loaded: url_helper
INFO - 2025-05-15 14:31:18 --> Helper loaded: form_helper
INFO - 2025-05-15 14:31:18 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:31:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:31:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:31:18 --> Controller Class Initialized
INFO - 2025-05-15 14:31:18 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:31:18 --> Model "User_model" initialized
ERROR - 2025-05-15 14:31:18 --> Query error: Table 'fitnessrec.jadwal_fitness' doesn't exist - Invalid query: SELECT *
FROM `jadwal_fitness`
WHERE `tanggal` = '2025-05-15'
INFO - 2025-05-15 14:31:18 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-15 14:31:18 --> Config Class Initialized
INFO - 2025-05-15 14:31:18 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:31:18 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:31:18 --> Utf8 Class Initialized
INFO - 2025-05-15 14:31:18 --> URI Class Initialized
INFO - 2025-05-15 14:31:18 --> Router Class Initialized
INFO - 2025-05-15 14:31:18 --> Output Class Initialized
INFO - 2025-05-15 14:31:18 --> Security Class Initialized
DEBUG - 2025-05-15 14:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:31:18 --> Input Class Initialized
INFO - 2025-05-15 14:31:18 --> Language Class Initialized
INFO - 2025-05-15 14:31:18 --> Loader Class Initialized
INFO - 2025-05-15 14:31:18 --> Helper loaded: url_helper
INFO - 2025-05-15 14:31:18 --> Helper loaded: form_helper
INFO - 2025-05-15 14:31:18 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:31:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:31:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:31:18 --> Controller Class Initialized
INFO - 2025-05-15 14:31:18 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:31:18 --> Model "User_model" initialized
ERROR - 2025-05-15 14:31:18 --> Query error: Table 'fitnessrec.jadwal_fitness' doesn't exist - Invalid query: SELECT *
FROM `jadwal_fitness`
WHERE `tanggal` = '2025-05-15'
INFO - 2025-05-15 14:31:18 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-15 14:31:20 --> Config Class Initialized
INFO - 2025-05-15 14:31:20 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:31:20 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:31:20 --> Utf8 Class Initialized
INFO - 2025-05-15 14:31:20 --> URI Class Initialized
INFO - 2025-05-15 14:31:20 --> Router Class Initialized
INFO - 2025-05-15 14:31:20 --> Output Class Initialized
INFO - 2025-05-15 14:31:20 --> Security Class Initialized
DEBUG - 2025-05-15 14:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:31:20 --> Input Class Initialized
INFO - 2025-05-15 14:31:20 --> Language Class Initialized
INFO - 2025-05-15 14:31:20 --> Loader Class Initialized
INFO - 2025-05-15 14:31:20 --> Helper loaded: url_helper
INFO - 2025-05-15 14:31:20 --> Helper loaded: form_helper
INFO - 2025-05-15 14:31:20 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:31:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:31:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:31:20 --> Controller Class Initialized
INFO - 2025-05-15 14:31:20 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:31:20 --> Model "User_model" initialized
ERROR - 2025-05-15 14:31:20 --> Query error: Table 'fitnessrec.jadwal_fitness' doesn't exist - Invalid query: INSERT INTO `jadwal_fitness` (`tanggal`, `kegiatan`, `status`) VALUES ('2025-05-15', 'Workout rutin', 'proses')
INFO - 2025-05-15 14:31:20 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-15 14:32:17 --> Config Class Initialized
INFO - 2025-05-15 14:32:17 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:32:17 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:32:17 --> Utf8 Class Initialized
INFO - 2025-05-15 14:32:17 --> URI Class Initialized
INFO - 2025-05-15 14:32:17 --> Router Class Initialized
INFO - 2025-05-15 14:32:17 --> Output Class Initialized
INFO - 2025-05-15 14:32:17 --> Security Class Initialized
DEBUG - 2025-05-15 14:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:32:17 --> Input Class Initialized
INFO - 2025-05-15 14:32:17 --> Language Class Initialized
INFO - 2025-05-15 14:32:17 --> Loader Class Initialized
INFO - 2025-05-15 14:32:17 --> Helper loaded: url_helper
INFO - 2025-05-15 14:32:17 --> Helper loaded: form_helper
INFO - 2025-05-15 14:32:17 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:32:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:32:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:32:17 --> Controller Class Initialized
INFO - 2025-05-15 14:32:17 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:32:17 --> Model "User_model" initialized
INFO - 2025-05-15 14:32:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 14:32:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 14:32:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-15 14:32:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 14:32:17 --> Final output sent to browser
DEBUG - 2025-05-15 14:32:17 --> Total execution time: 0.0637
INFO - 2025-05-15 14:32:17 --> Config Class Initialized
INFO - 2025-05-15 14:32:17 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:32:17 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:32:17 --> Utf8 Class Initialized
INFO - 2025-05-15 14:32:17 --> URI Class Initialized
INFO - 2025-05-15 14:32:17 --> Router Class Initialized
INFO - 2025-05-15 14:32:17 --> Output Class Initialized
INFO - 2025-05-15 14:32:17 --> Security Class Initialized
DEBUG - 2025-05-15 14:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:32:17 --> Input Class Initialized
INFO - 2025-05-15 14:32:17 --> Language Class Initialized
INFO - 2025-05-15 14:32:17 --> Loader Class Initialized
INFO - 2025-05-15 14:32:17 --> Helper loaded: url_helper
INFO - 2025-05-15 14:32:17 --> Helper loaded: form_helper
INFO - 2025-05-15 14:32:17 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:32:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:32:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:32:17 --> Controller Class Initialized
INFO - 2025-05-15 14:32:17 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:32:17 --> Model "User_model" initialized
ERROR - 2025-05-15 14:32:17 --> Query error: Table 'fitnessrec.jadwal_fitness' doesn't exist - Invalid query: SELECT `tanggal`
FROM `jadwal_fitness`
WHERE `status` = 'selesai'
INFO - 2025-05-15 14:32:17 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-15 14:32:21 --> Config Class Initialized
INFO - 2025-05-15 14:32:21 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:32:21 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:32:21 --> Utf8 Class Initialized
INFO - 2025-05-15 14:32:21 --> URI Class Initialized
INFO - 2025-05-15 14:32:21 --> Router Class Initialized
INFO - 2025-05-15 14:32:21 --> Output Class Initialized
INFO - 2025-05-15 14:32:21 --> Security Class Initialized
DEBUG - 2025-05-15 14:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:32:21 --> Input Class Initialized
INFO - 2025-05-15 14:32:21 --> Language Class Initialized
INFO - 2025-05-15 14:32:21 --> Loader Class Initialized
INFO - 2025-05-15 14:32:21 --> Helper loaded: url_helper
INFO - 2025-05-15 14:32:21 --> Helper loaded: form_helper
INFO - 2025-05-15 14:32:21 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:32:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:32:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:32:21 --> Controller Class Initialized
INFO - 2025-05-15 14:32:21 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:32:21 --> Model "User_model" initialized
ERROR - 2025-05-15 14:32:21 --> Query error: Table 'fitnessrec.jadwal_fitness' doesn't exist - Invalid query: INSERT INTO `jadwal_fitness` (`tanggal`, `kegiatan`, `status`) VALUES ('', 'Workout rutin', 'proses')
INFO - 2025-05-15 14:32:21 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-15 14:32:22 --> Config Class Initialized
INFO - 2025-05-15 14:32:22 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:32:22 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:32:22 --> Utf8 Class Initialized
INFO - 2025-05-15 14:32:22 --> URI Class Initialized
INFO - 2025-05-15 14:32:22 --> Router Class Initialized
INFO - 2025-05-15 14:32:22 --> Output Class Initialized
INFO - 2025-05-15 14:32:22 --> Security Class Initialized
DEBUG - 2025-05-15 14:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:32:22 --> Input Class Initialized
INFO - 2025-05-15 14:32:22 --> Language Class Initialized
INFO - 2025-05-15 14:32:22 --> Loader Class Initialized
INFO - 2025-05-15 14:32:22 --> Helper loaded: url_helper
INFO - 2025-05-15 14:32:22 --> Helper loaded: form_helper
INFO - 2025-05-15 14:32:22 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:32:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:32:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:32:22 --> Controller Class Initialized
INFO - 2025-05-15 14:32:22 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:32:22 --> Model "User_model" initialized
ERROR - 2025-05-15 14:32:22 --> Query error: Table 'fitnessrec.jadwal_fitness' doesn't exist - Invalid query: SELECT *
FROM `jadwal_fitness`
WHERE `tanggal` = '2025-05-15'
INFO - 2025-05-15 14:32:22 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-15 14:32:22 --> Config Class Initialized
INFO - 2025-05-15 14:32:22 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:32:22 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:32:22 --> Utf8 Class Initialized
INFO - 2025-05-15 14:32:22 --> URI Class Initialized
INFO - 2025-05-15 14:32:22 --> Router Class Initialized
INFO - 2025-05-15 14:32:22 --> Output Class Initialized
INFO - 2025-05-15 14:32:22 --> Security Class Initialized
DEBUG - 2025-05-15 14:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:32:22 --> Input Class Initialized
INFO - 2025-05-15 14:32:22 --> Language Class Initialized
INFO - 2025-05-15 14:32:22 --> Loader Class Initialized
INFO - 2025-05-15 14:32:22 --> Helper loaded: url_helper
INFO - 2025-05-15 14:32:22 --> Helper loaded: form_helper
INFO - 2025-05-15 14:32:22 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:32:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:32:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:32:22 --> Controller Class Initialized
INFO - 2025-05-15 14:32:22 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:32:22 --> Model "User_model" initialized
ERROR - 2025-05-15 14:32:22 --> Query error: Table 'fitnessrec.jadwal_fitness' doesn't exist - Invalid query: SELECT *
FROM `jadwal_fitness`
WHERE `tanggal` = '2025-05-15'
INFO - 2025-05-15 14:32:22 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-15 14:32:24 --> Config Class Initialized
INFO - 2025-05-15 14:32:24 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:32:24 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:32:24 --> Utf8 Class Initialized
INFO - 2025-05-15 14:32:24 --> URI Class Initialized
INFO - 2025-05-15 14:32:24 --> Router Class Initialized
INFO - 2025-05-15 14:32:24 --> Output Class Initialized
INFO - 2025-05-15 14:32:24 --> Security Class Initialized
DEBUG - 2025-05-15 14:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:32:24 --> Input Class Initialized
INFO - 2025-05-15 14:32:24 --> Language Class Initialized
INFO - 2025-05-15 14:32:24 --> Loader Class Initialized
INFO - 2025-05-15 14:32:24 --> Helper loaded: url_helper
INFO - 2025-05-15 14:32:24 --> Helper loaded: form_helper
INFO - 2025-05-15 14:32:24 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:32:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:32:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:32:24 --> Controller Class Initialized
INFO - 2025-05-15 14:32:24 --> Model "User_model" initialized
INFO - 2025-05-15 14:32:24 --> Config Class Initialized
INFO - 2025-05-15 14:32:24 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:32:24 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:32:24 --> Utf8 Class Initialized
INFO - 2025-05-15 14:32:24 --> URI Class Initialized
INFO - 2025-05-15 14:32:24 --> Router Class Initialized
INFO - 2025-05-15 14:32:24 --> Output Class Initialized
INFO - 2025-05-15 14:32:24 --> Security Class Initialized
DEBUG - 2025-05-15 14:32:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:32:24 --> Input Class Initialized
INFO - 2025-05-15 14:32:24 --> Language Class Initialized
INFO - 2025-05-15 14:32:24 --> Loader Class Initialized
INFO - 2025-05-15 14:32:24 --> Helper loaded: url_helper
INFO - 2025-05-15 14:32:24 --> Helper loaded: form_helper
INFO - 2025-05-15 14:32:24 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:32:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:32:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:32:24 --> Controller Class Initialized
INFO - 2025-05-15 14:32:24 --> Model "User_model" initialized
INFO - 2025-05-15 14:32:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-15 14:32:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-15 14:32:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-15 14:32:24 --> Final output sent to browser
DEBUG - 2025-05-15 14:32:24 --> Total execution time: 0.0741
INFO - 2025-05-15 14:32:26 --> Config Class Initialized
INFO - 2025-05-15 14:32:26 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:32:26 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:32:26 --> Utf8 Class Initialized
INFO - 2025-05-15 14:32:26 --> URI Class Initialized
INFO - 2025-05-15 14:32:26 --> Router Class Initialized
INFO - 2025-05-15 14:32:26 --> Output Class Initialized
INFO - 2025-05-15 14:32:26 --> Security Class Initialized
DEBUG - 2025-05-15 14:32:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:32:26 --> Input Class Initialized
INFO - 2025-05-15 14:32:26 --> Language Class Initialized
INFO - 2025-05-15 14:32:26 --> Loader Class Initialized
INFO - 2025-05-15 14:32:26 --> Helper loaded: url_helper
INFO - 2025-05-15 14:32:26 --> Helper loaded: form_helper
INFO - 2025-05-15 14:32:26 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:32:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:32:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:32:26 --> Controller Class Initialized
INFO - 2025-05-15 14:32:26 --> Model "User_model" initialized
INFO - 2025-05-15 14:32:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\auth/login.php
INFO - 2025-05-15 14:32:26 --> Final output sent to browser
DEBUG - 2025-05-15 14:32:26 --> Total execution time: 0.0999
INFO - 2025-05-15 14:32:44 --> Config Class Initialized
INFO - 2025-05-15 14:32:44 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:32:44 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:32:44 --> Utf8 Class Initialized
INFO - 2025-05-15 14:32:44 --> URI Class Initialized
INFO - 2025-05-15 14:32:44 --> Router Class Initialized
INFO - 2025-05-15 14:32:44 --> Output Class Initialized
INFO - 2025-05-15 14:32:44 --> Security Class Initialized
DEBUG - 2025-05-15 14:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:32:44 --> Input Class Initialized
INFO - 2025-05-15 14:32:44 --> Language Class Initialized
INFO - 2025-05-15 14:32:44 --> Loader Class Initialized
INFO - 2025-05-15 14:32:44 --> Helper loaded: url_helper
INFO - 2025-05-15 14:32:44 --> Helper loaded: form_helper
INFO - 2025-05-15 14:32:44 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:32:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:32:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:32:44 --> Controller Class Initialized
INFO - 2025-05-15 14:32:44 --> Model "User_model" initialized
INFO - 2025-05-15 14:32:44 --> Config Class Initialized
INFO - 2025-05-15 14:32:44 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:32:44 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:32:44 --> Utf8 Class Initialized
INFO - 2025-05-15 14:32:44 --> URI Class Initialized
INFO - 2025-05-15 14:32:44 --> Router Class Initialized
INFO - 2025-05-15 14:32:44 --> Output Class Initialized
INFO - 2025-05-15 14:32:44 --> Security Class Initialized
DEBUG - 2025-05-15 14:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:32:44 --> Input Class Initialized
INFO - 2025-05-15 14:32:44 --> Language Class Initialized
INFO - 2025-05-15 14:32:44 --> Loader Class Initialized
INFO - 2025-05-15 14:32:44 --> Helper loaded: url_helper
INFO - 2025-05-15 14:32:44 --> Helper loaded: form_helper
INFO - 2025-05-15 14:32:44 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:32:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:32:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:32:44 --> Controller Class Initialized
INFO - 2025-05-15 14:32:44 --> Model "User_model" initialized
INFO - 2025-05-15 14:32:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/header.php
INFO - 2025-05-15 14:32:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/home.php
INFO - 2025-05-15 14:32:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\landing_page/layout/footer.php
INFO - 2025-05-15 14:32:44 --> Final output sent to browser
DEBUG - 2025-05-15 14:32:44 --> Total execution time: 0.0717
INFO - 2025-05-15 14:32:47 --> Config Class Initialized
INFO - 2025-05-15 14:32:47 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:32:47 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:32:47 --> Utf8 Class Initialized
INFO - 2025-05-15 14:32:47 --> URI Class Initialized
INFO - 2025-05-15 14:32:47 --> Router Class Initialized
INFO - 2025-05-15 14:32:47 --> Output Class Initialized
INFO - 2025-05-15 14:32:47 --> Security Class Initialized
DEBUG - 2025-05-15 14:32:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:32:47 --> Input Class Initialized
INFO - 2025-05-15 14:32:47 --> Language Class Initialized
INFO - 2025-05-15 14:32:47 --> Loader Class Initialized
INFO - 2025-05-15 14:32:47 --> Helper loaded: url_helper
INFO - 2025-05-15 14:32:47 --> Helper loaded: form_helper
INFO - 2025-05-15 14:32:47 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:32:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:32:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:32:47 --> Controller Class Initialized
INFO - 2025-05-15 14:32:47 --> Model "User_model" initialized
INFO - 2025-05-15 14:32:47 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:32:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 14:32:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 14:32:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-15 14:32:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 14:32:47 --> Final output sent to browser
DEBUG - 2025-05-15 14:32:47 --> Total execution time: 0.0725
INFO - 2025-05-15 14:32:48 --> Config Class Initialized
INFO - 2025-05-15 14:32:48 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:32:48 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:32:48 --> Utf8 Class Initialized
INFO - 2025-05-15 14:32:48 --> URI Class Initialized
INFO - 2025-05-15 14:32:48 --> Router Class Initialized
INFO - 2025-05-15 14:32:48 --> Output Class Initialized
INFO - 2025-05-15 14:32:48 --> Security Class Initialized
DEBUG - 2025-05-15 14:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:32:48 --> Input Class Initialized
INFO - 2025-05-15 14:32:48 --> Language Class Initialized
INFO - 2025-05-15 14:32:48 --> Loader Class Initialized
INFO - 2025-05-15 14:32:48 --> Helper loaded: url_helper
INFO - 2025-05-15 14:32:48 --> Helper loaded: form_helper
INFO - 2025-05-15 14:32:48 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:32:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:32:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:32:48 --> Controller Class Initialized
INFO - 2025-05-15 14:32:48 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:32:48 --> Model "User_model" initialized
INFO - 2025-05-15 14:32:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 14:32:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 14:32:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-15 14:32:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 14:32:48 --> Final output sent to browser
DEBUG - 2025-05-15 14:32:48 --> Total execution time: 0.0617
INFO - 2025-05-15 14:32:49 --> Config Class Initialized
INFO - 2025-05-15 14:32:49 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:32:49 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:32:49 --> Utf8 Class Initialized
INFO - 2025-05-15 14:32:49 --> URI Class Initialized
INFO - 2025-05-15 14:32:49 --> Router Class Initialized
INFO - 2025-05-15 14:32:49 --> Output Class Initialized
INFO - 2025-05-15 14:32:49 --> Security Class Initialized
DEBUG - 2025-05-15 14:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:32:49 --> Input Class Initialized
INFO - 2025-05-15 14:32:49 --> Language Class Initialized
INFO - 2025-05-15 14:32:49 --> Loader Class Initialized
INFO - 2025-05-15 14:32:49 --> Helper loaded: url_helper
INFO - 2025-05-15 14:32:49 --> Helper loaded: form_helper
INFO - 2025-05-15 14:32:49 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:32:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:32:49 --> Controller Class Initialized
INFO - 2025-05-15 14:32:49 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:32:49 --> Model "User_model" initialized
ERROR - 2025-05-15 14:32:49 --> Query error: Table 'fitnessrec.jadwal_fitness' doesn't exist - Invalid query: SELECT `tanggal`
FROM `jadwal_fitness`
WHERE `status` = 'selesai'
INFO - 2025-05-15 14:32:49 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-15 14:38:36 --> Config Class Initialized
INFO - 2025-05-15 14:38:36 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:38:36 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:38:36 --> Utf8 Class Initialized
INFO - 2025-05-15 14:38:36 --> URI Class Initialized
INFO - 2025-05-15 14:38:36 --> Router Class Initialized
INFO - 2025-05-15 14:38:36 --> Output Class Initialized
INFO - 2025-05-15 14:38:36 --> Security Class Initialized
DEBUG - 2025-05-15 14:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:38:36 --> Input Class Initialized
INFO - 2025-05-15 14:38:36 --> Language Class Initialized
INFO - 2025-05-15 14:38:36 --> Loader Class Initialized
INFO - 2025-05-15 14:38:36 --> Helper loaded: url_helper
INFO - 2025-05-15 14:38:36 --> Helper loaded: form_helper
INFO - 2025-05-15 14:38:36 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:38:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:38:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:38:36 --> Controller Class Initialized
INFO - 2025-05-15 14:38:36 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:38:36 --> Model "User_model" initialized
INFO - 2025-05-15 14:38:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 14:38:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 14:38:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-15 14:38:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 14:38:36 --> Final output sent to browser
DEBUG - 2025-05-15 14:38:36 --> Total execution time: 0.0714
INFO - 2025-05-15 14:38:36 --> Config Class Initialized
INFO - 2025-05-15 14:38:36 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:38:36 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:38:36 --> Utf8 Class Initialized
INFO - 2025-05-15 14:38:36 --> URI Class Initialized
INFO - 2025-05-15 14:38:36 --> Router Class Initialized
INFO - 2025-05-15 14:38:36 --> Output Class Initialized
INFO - 2025-05-15 14:38:36 --> Security Class Initialized
DEBUG - 2025-05-15 14:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:38:36 --> Input Class Initialized
INFO - 2025-05-15 14:38:36 --> Language Class Initialized
INFO - 2025-05-15 14:38:36 --> Loader Class Initialized
INFO - 2025-05-15 14:38:36 --> Helper loaded: url_helper
INFO - 2025-05-15 14:38:36 --> Helper loaded: form_helper
INFO - 2025-05-15 14:38:36 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:38:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:38:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:38:36 --> Controller Class Initialized
INFO - 2025-05-15 14:38:36 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:38:36 --> Model "User_model" initialized
ERROR - 2025-05-15 14:38:36 --> Query error: Table 'fitnessrec.jadwal_fitness' doesn't exist - Invalid query: SELECT `tanggal`
FROM `jadwal_fitness`
WHERE `status` = 'selesai'
INFO - 2025-05-15 14:38:36 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-15 14:38:40 --> Config Class Initialized
INFO - 2025-05-15 14:38:40 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:38:40 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:38:40 --> Utf8 Class Initialized
INFO - 2025-05-15 14:38:40 --> URI Class Initialized
INFO - 2025-05-15 14:38:40 --> Router Class Initialized
INFO - 2025-05-15 14:38:40 --> Output Class Initialized
INFO - 2025-05-15 14:38:40 --> Security Class Initialized
DEBUG - 2025-05-15 14:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:38:40 --> Input Class Initialized
INFO - 2025-05-15 14:38:40 --> Language Class Initialized
INFO - 2025-05-15 14:38:40 --> Loader Class Initialized
INFO - 2025-05-15 14:38:40 --> Helper loaded: url_helper
INFO - 2025-05-15 14:38:40 --> Helper loaded: form_helper
INFO - 2025-05-15 14:38:40 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:38:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:38:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:38:40 --> Controller Class Initialized
INFO - 2025-05-15 14:38:40 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:38:40 --> Model "User_model" initialized
ERROR - 2025-05-15 14:38:40 --> Query error: Table 'fitnessrec.jadwal_fitness' doesn't exist - Invalid query: SELECT *
FROM `jadwal_fitness`
WHERE `tanggal` = '2025-05-15'
INFO - 2025-05-15 14:38:40 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-15 14:38:41 --> Config Class Initialized
INFO - 2025-05-15 14:38:41 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:38:41 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:38:41 --> Utf8 Class Initialized
INFO - 2025-05-15 14:38:41 --> URI Class Initialized
INFO - 2025-05-15 14:38:41 --> Router Class Initialized
INFO - 2025-05-15 14:38:41 --> Output Class Initialized
INFO - 2025-05-15 14:38:41 --> Security Class Initialized
DEBUG - 2025-05-15 14:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:38:41 --> Input Class Initialized
INFO - 2025-05-15 14:38:41 --> Language Class Initialized
INFO - 2025-05-15 14:38:41 --> Loader Class Initialized
INFO - 2025-05-15 14:38:41 --> Helper loaded: url_helper
INFO - 2025-05-15 14:38:41 --> Helper loaded: form_helper
INFO - 2025-05-15 14:38:41 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:38:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:38:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:38:41 --> Controller Class Initialized
INFO - 2025-05-15 14:38:41 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:38:41 --> Model "User_model" initialized
ERROR - 2025-05-15 14:38:41 --> Query error: Table 'fitnessrec.jadwal_fitness' doesn't exist - Invalid query: SELECT *
FROM `jadwal_fitness`
WHERE `tanggal` = '2025-05-15'
INFO - 2025-05-15 14:38:41 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-15 14:38:41 --> Config Class Initialized
INFO - 2025-05-15 14:38:41 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:38:41 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:38:41 --> Utf8 Class Initialized
INFO - 2025-05-15 14:38:41 --> URI Class Initialized
INFO - 2025-05-15 14:38:41 --> Router Class Initialized
INFO - 2025-05-15 14:38:41 --> Output Class Initialized
INFO - 2025-05-15 14:38:41 --> Security Class Initialized
DEBUG - 2025-05-15 14:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:38:41 --> Input Class Initialized
INFO - 2025-05-15 14:38:41 --> Language Class Initialized
INFO - 2025-05-15 14:38:41 --> Loader Class Initialized
INFO - 2025-05-15 14:38:41 --> Helper loaded: url_helper
INFO - 2025-05-15 14:38:41 --> Helper loaded: form_helper
INFO - 2025-05-15 14:38:41 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:38:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:38:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:38:41 --> Controller Class Initialized
INFO - 2025-05-15 14:38:41 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:38:41 --> Model "User_model" initialized
ERROR - 2025-05-15 14:38:41 --> Query error: Table 'fitnessrec.jadwal_fitness' doesn't exist - Invalid query: SELECT *
FROM `jadwal_fitness`
WHERE `tanggal` = '2025-05-15'
INFO - 2025-05-15 14:38:41 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-15 14:38:43 --> Config Class Initialized
INFO - 2025-05-15 14:38:43 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:38:43 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:38:43 --> Utf8 Class Initialized
INFO - 2025-05-15 14:38:43 --> URI Class Initialized
INFO - 2025-05-15 14:38:43 --> Router Class Initialized
INFO - 2025-05-15 14:38:43 --> Output Class Initialized
INFO - 2025-05-15 14:38:43 --> Security Class Initialized
DEBUG - 2025-05-15 14:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:38:43 --> Input Class Initialized
INFO - 2025-05-15 14:38:43 --> Language Class Initialized
INFO - 2025-05-15 14:38:43 --> Loader Class Initialized
INFO - 2025-05-15 14:38:43 --> Helper loaded: url_helper
INFO - 2025-05-15 14:38:43 --> Helper loaded: form_helper
INFO - 2025-05-15 14:38:43 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:38:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:38:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:38:43 --> Controller Class Initialized
INFO - 2025-05-15 14:38:43 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:38:43 --> Model "User_model" initialized
ERROR - 2025-05-15 14:38:43 --> Query error: Table 'fitnessrec.jadwal_fitness' doesn't exist - Invalid query: SELECT *
FROM `jadwal_fitness`
WHERE `tanggal` = '2025-05-15'
INFO - 2025-05-15 14:38:43 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-15 14:38:43 --> Config Class Initialized
INFO - 2025-05-15 14:38:43 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:38:43 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:38:43 --> Utf8 Class Initialized
INFO - 2025-05-15 14:38:43 --> URI Class Initialized
INFO - 2025-05-15 14:38:43 --> Router Class Initialized
INFO - 2025-05-15 14:38:43 --> Output Class Initialized
INFO - 2025-05-15 14:38:43 --> Security Class Initialized
DEBUG - 2025-05-15 14:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:38:43 --> Input Class Initialized
INFO - 2025-05-15 14:38:43 --> Language Class Initialized
INFO - 2025-05-15 14:38:43 --> Loader Class Initialized
INFO - 2025-05-15 14:38:43 --> Helper loaded: url_helper
INFO - 2025-05-15 14:38:43 --> Helper loaded: form_helper
INFO - 2025-05-15 14:38:43 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:38:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:38:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:38:43 --> Controller Class Initialized
INFO - 2025-05-15 14:38:43 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:38:43 --> Model "User_model" initialized
ERROR - 2025-05-15 14:38:43 --> Query error: Table 'fitnessrec.jadwal_fitness' doesn't exist - Invalid query: SELECT *
FROM `jadwal_fitness`
WHERE `tanggal` = '2025-05-15'
INFO - 2025-05-15 14:38:43 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-15 14:38:43 --> Config Class Initialized
INFO - 2025-05-15 14:38:43 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:38:43 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:38:43 --> Utf8 Class Initialized
INFO - 2025-05-15 14:38:43 --> URI Class Initialized
INFO - 2025-05-15 14:38:43 --> Router Class Initialized
INFO - 2025-05-15 14:38:43 --> Output Class Initialized
INFO - 2025-05-15 14:38:43 --> Security Class Initialized
DEBUG - 2025-05-15 14:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:38:43 --> Input Class Initialized
INFO - 2025-05-15 14:38:43 --> Language Class Initialized
INFO - 2025-05-15 14:38:43 --> Loader Class Initialized
INFO - 2025-05-15 14:38:43 --> Helper loaded: url_helper
INFO - 2025-05-15 14:38:43 --> Helper loaded: form_helper
INFO - 2025-05-15 14:38:44 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:38:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:38:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:38:44 --> Controller Class Initialized
INFO - 2025-05-15 14:38:44 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:38:44 --> Model "User_model" initialized
ERROR - 2025-05-15 14:38:44 --> Query error: Table 'fitnessrec.jadwal_fitness' doesn't exist - Invalid query: SELECT *
FROM `jadwal_fitness`
WHERE `tanggal` = '2025-05-15'
INFO - 2025-05-15 14:38:44 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-15 14:38:46 --> Config Class Initialized
INFO - 2025-05-15 14:38:46 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:38:46 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:38:46 --> Utf8 Class Initialized
INFO - 2025-05-15 14:38:46 --> URI Class Initialized
INFO - 2025-05-15 14:38:46 --> Router Class Initialized
INFO - 2025-05-15 14:38:46 --> Output Class Initialized
INFO - 2025-05-15 14:38:46 --> Security Class Initialized
DEBUG - 2025-05-15 14:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:38:46 --> Input Class Initialized
INFO - 2025-05-15 14:38:46 --> Language Class Initialized
INFO - 2025-05-15 14:38:46 --> Loader Class Initialized
INFO - 2025-05-15 14:38:46 --> Helper loaded: url_helper
INFO - 2025-05-15 14:38:46 --> Helper loaded: form_helper
INFO - 2025-05-15 14:38:46 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:38:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:38:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:38:46 --> Controller Class Initialized
INFO - 2025-05-15 14:38:46 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:38:46 --> Model "User_model" initialized
ERROR - 2025-05-15 14:38:46 --> Query error: Table 'fitnessrec.jadwal_fitness' doesn't exist - Invalid query: SELECT *
FROM `jadwal_fitness`
WHERE `tanggal` = '2025-05-15'
INFO - 2025-05-15 14:38:46 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-15 14:38:48 --> Config Class Initialized
INFO - 2025-05-15 14:38:48 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:38:48 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:38:48 --> Utf8 Class Initialized
INFO - 2025-05-15 14:38:48 --> URI Class Initialized
INFO - 2025-05-15 14:38:48 --> Router Class Initialized
INFO - 2025-05-15 14:38:48 --> Output Class Initialized
INFO - 2025-05-15 14:38:48 --> Security Class Initialized
DEBUG - 2025-05-15 14:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:38:48 --> Input Class Initialized
INFO - 2025-05-15 14:38:48 --> Language Class Initialized
INFO - 2025-05-15 14:38:48 --> Loader Class Initialized
INFO - 2025-05-15 14:38:48 --> Helper loaded: url_helper
INFO - 2025-05-15 14:38:48 --> Helper loaded: form_helper
INFO - 2025-05-15 14:38:48 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:38:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:38:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:38:48 --> Controller Class Initialized
INFO - 2025-05-15 14:38:48 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:38:48 --> Model "User_model" initialized
ERROR - 2025-05-15 14:38:48 --> Query error: Table 'fitnessrec.jadwal_fitness' doesn't exist - Invalid query: SELECT *
FROM `jadwal_fitness`
WHERE `tanggal` = '2025-05-15'
INFO - 2025-05-15 14:38:48 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-15 14:38:49 --> Config Class Initialized
INFO - 2025-05-15 14:38:49 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:38:49 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:38:49 --> Utf8 Class Initialized
INFO - 2025-05-15 14:38:49 --> URI Class Initialized
INFO - 2025-05-15 14:38:49 --> Router Class Initialized
INFO - 2025-05-15 14:38:49 --> Output Class Initialized
INFO - 2025-05-15 14:38:49 --> Security Class Initialized
DEBUG - 2025-05-15 14:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:38:49 --> Input Class Initialized
INFO - 2025-05-15 14:38:49 --> Language Class Initialized
INFO - 2025-05-15 14:38:49 --> Loader Class Initialized
INFO - 2025-05-15 14:38:49 --> Helper loaded: url_helper
INFO - 2025-05-15 14:38:49 --> Helper loaded: form_helper
INFO - 2025-05-15 14:38:49 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:38:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:38:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:38:49 --> Controller Class Initialized
INFO - 2025-05-15 14:38:49 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:38:49 --> Model "User_model" initialized
ERROR - 2025-05-15 14:38:49 --> Query error: Table 'fitnessrec.jadwal_fitness' doesn't exist - Invalid query: SELECT *
FROM `jadwal_fitness`
WHERE `tanggal` = '2025-05-15'
INFO - 2025-05-15 14:38:49 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-15 14:38:49 --> Config Class Initialized
INFO - 2025-05-15 14:38:49 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:38:49 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:38:49 --> Utf8 Class Initialized
INFO - 2025-05-15 14:38:49 --> URI Class Initialized
INFO - 2025-05-15 14:38:49 --> Router Class Initialized
INFO - 2025-05-15 14:38:49 --> Output Class Initialized
INFO - 2025-05-15 14:38:49 --> Security Class Initialized
DEBUG - 2025-05-15 14:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:38:49 --> Input Class Initialized
INFO - 2025-05-15 14:38:49 --> Language Class Initialized
INFO - 2025-05-15 14:38:49 --> Loader Class Initialized
INFO - 2025-05-15 14:38:49 --> Helper loaded: url_helper
INFO - 2025-05-15 14:38:49 --> Helper loaded: form_helper
INFO - 2025-05-15 14:38:49 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:38:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:38:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:38:49 --> Controller Class Initialized
INFO - 2025-05-15 14:38:49 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:38:49 --> Model "User_model" initialized
ERROR - 2025-05-15 14:38:49 --> Query error: Table 'fitnessrec.jadwal_fitness' doesn't exist - Invalid query: SELECT *
FROM `jadwal_fitness`
WHERE `tanggal` = '2025-05-15'
INFO - 2025-05-15 14:38:49 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-15 14:38:51 --> Config Class Initialized
INFO - 2025-05-15 14:38:51 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:38:51 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:38:51 --> Utf8 Class Initialized
INFO - 2025-05-15 14:38:51 --> URI Class Initialized
INFO - 2025-05-15 14:38:51 --> Router Class Initialized
INFO - 2025-05-15 14:38:51 --> Output Class Initialized
INFO - 2025-05-15 14:38:51 --> Security Class Initialized
DEBUG - 2025-05-15 14:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:38:51 --> Input Class Initialized
INFO - 2025-05-15 14:38:51 --> Language Class Initialized
INFO - 2025-05-15 14:38:51 --> Loader Class Initialized
INFO - 2025-05-15 14:38:51 --> Helper loaded: url_helper
INFO - 2025-05-15 14:38:51 --> Helper loaded: form_helper
INFO - 2025-05-15 14:38:51 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:38:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:38:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:38:51 --> Controller Class Initialized
INFO - 2025-05-15 14:38:51 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:38:51 --> Model "User_model" initialized
ERROR - 2025-05-15 14:38:51 --> Query error: Table 'fitnessrec.jadwal_fitness' doesn't exist - Invalid query: SELECT *
FROM `jadwal_fitness`
WHERE `tanggal` = '2025-05-15'
INFO - 2025-05-15 14:38:51 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-15 14:39:07 --> Config Class Initialized
INFO - 2025-05-15 14:39:07 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:39:07 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:39:07 --> Utf8 Class Initialized
INFO - 2025-05-15 14:39:07 --> URI Class Initialized
INFO - 2025-05-15 14:39:07 --> Router Class Initialized
INFO - 2025-05-15 14:39:07 --> Output Class Initialized
INFO - 2025-05-15 14:39:07 --> Security Class Initialized
DEBUG - 2025-05-15 14:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:39:07 --> Input Class Initialized
INFO - 2025-05-15 14:39:07 --> Language Class Initialized
INFO - 2025-05-15 14:39:07 --> Loader Class Initialized
INFO - 2025-05-15 14:39:07 --> Helper loaded: url_helper
INFO - 2025-05-15 14:39:07 --> Helper loaded: form_helper
INFO - 2025-05-15 14:39:07 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:39:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:39:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:39:07 --> Controller Class Initialized
INFO - 2025-05-15 14:39:07 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:39:07 --> Model "User_model" initialized
INFO - 2025-05-15 14:39:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 14:39:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 14:39:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-15 14:39:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 14:39:07 --> Final output sent to browser
DEBUG - 2025-05-15 14:39:07 --> Total execution time: 0.0685
INFO - 2025-05-15 14:39:08 --> Config Class Initialized
INFO - 2025-05-15 14:39:08 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:39:08 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:39:08 --> Utf8 Class Initialized
INFO - 2025-05-15 14:39:08 --> URI Class Initialized
INFO - 2025-05-15 14:39:08 --> Router Class Initialized
INFO - 2025-05-15 14:39:08 --> Output Class Initialized
INFO - 2025-05-15 14:39:08 --> Security Class Initialized
DEBUG - 2025-05-15 14:39:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:39:08 --> Input Class Initialized
INFO - 2025-05-15 14:39:08 --> Language Class Initialized
INFO - 2025-05-15 14:39:08 --> Loader Class Initialized
INFO - 2025-05-15 14:39:08 --> Helper loaded: url_helper
INFO - 2025-05-15 14:39:08 --> Helper loaded: form_helper
INFO - 2025-05-15 14:39:08 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:39:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:39:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:39:08 --> Controller Class Initialized
INFO - 2025-05-15 14:39:08 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:39:08 --> Model "User_model" initialized
ERROR - 2025-05-15 14:39:08 --> Query error: Table 'fitnessrec.jadwal_fitness' doesn't exist - Invalid query: SELECT `tanggal`
FROM `jadwal_fitness`
WHERE `status` = 'selesai'
INFO - 2025-05-15 14:39:08 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-15 14:39:11 --> Config Class Initialized
INFO - 2025-05-15 14:39:11 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:39:11 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:39:11 --> Utf8 Class Initialized
INFO - 2025-05-15 14:39:11 --> URI Class Initialized
INFO - 2025-05-15 14:39:11 --> Router Class Initialized
INFO - 2025-05-15 14:39:11 --> Output Class Initialized
INFO - 2025-05-15 14:39:11 --> Security Class Initialized
DEBUG - 2025-05-15 14:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:39:11 --> Input Class Initialized
INFO - 2025-05-15 14:39:11 --> Language Class Initialized
INFO - 2025-05-15 14:39:11 --> Loader Class Initialized
INFO - 2025-05-15 14:39:11 --> Helper loaded: url_helper
INFO - 2025-05-15 14:39:11 --> Helper loaded: form_helper
INFO - 2025-05-15 14:39:11 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:39:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:39:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:39:11 --> Controller Class Initialized
INFO - 2025-05-15 14:39:11 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:39:11 --> Model "User_model" initialized
ERROR - 2025-05-15 14:39:11 --> Query error: Table 'fitnessrec.jadwal_fitness' doesn't exist - Invalid query: SELECT *
FROM `jadwal_fitness`
WHERE `tanggal` = '2025-05-15'
INFO - 2025-05-15 14:39:11 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-15 14:39:12 --> Config Class Initialized
INFO - 2025-05-15 14:39:12 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:39:12 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:39:12 --> Utf8 Class Initialized
INFO - 2025-05-15 14:39:12 --> URI Class Initialized
INFO - 2025-05-15 14:39:12 --> Router Class Initialized
INFO - 2025-05-15 14:39:12 --> Output Class Initialized
INFO - 2025-05-15 14:39:12 --> Security Class Initialized
DEBUG - 2025-05-15 14:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:39:12 --> Input Class Initialized
INFO - 2025-05-15 14:39:12 --> Language Class Initialized
INFO - 2025-05-15 14:39:12 --> Loader Class Initialized
INFO - 2025-05-15 14:39:12 --> Helper loaded: url_helper
INFO - 2025-05-15 14:39:12 --> Helper loaded: form_helper
INFO - 2025-05-15 14:39:12 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:39:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:39:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:39:12 --> Controller Class Initialized
INFO - 2025-05-15 14:39:12 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:39:12 --> Model "User_model" initialized
ERROR - 2025-05-15 14:39:12 --> Query error: Table 'fitnessrec.jadwal_fitness' doesn't exist - Invalid query: SELECT *
FROM `jadwal_fitness`
WHERE `tanggal` = '2025-05-15'
INFO - 2025-05-15 14:39:12 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-15 14:39:12 --> Config Class Initialized
INFO - 2025-05-15 14:39:12 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:39:12 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:39:12 --> Utf8 Class Initialized
INFO - 2025-05-15 14:39:12 --> URI Class Initialized
INFO - 2025-05-15 14:39:12 --> Router Class Initialized
INFO - 2025-05-15 14:39:12 --> Output Class Initialized
INFO - 2025-05-15 14:39:12 --> Security Class Initialized
DEBUG - 2025-05-15 14:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:39:12 --> Input Class Initialized
INFO - 2025-05-15 14:39:12 --> Language Class Initialized
INFO - 2025-05-15 14:39:12 --> Loader Class Initialized
INFO - 2025-05-15 14:39:12 --> Helper loaded: url_helper
INFO - 2025-05-15 14:39:12 --> Helper loaded: form_helper
INFO - 2025-05-15 14:39:12 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:39:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:39:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:39:12 --> Controller Class Initialized
INFO - 2025-05-15 14:39:12 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:39:12 --> Model "User_model" initialized
ERROR - 2025-05-15 14:39:12 --> Query error: Table 'fitnessrec.jadwal_fitness' doesn't exist - Invalid query: SELECT *
FROM `jadwal_fitness`
WHERE `tanggal` = '2025-05-15'
INFO - 2025-05-15 14:39:13 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-15 14:39:13 --> Config Class Initialized
INFO - 2025-05-15 14:39:13 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:39:13 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:39:13 --> Utf8 Class Initialized
INFO - 2025-05-15 14:39:13 --> URI Class Initialized
INFO - 2025-05-15 14:39:13 --> Router Class Initialized
INFO - 2025-05-15 14:39:13 --> Output Class Initialized
INFO - 2025-05-15 14:39:13 --> Security Class Initialized
DEBUG - 2025-05-15 14:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:39:13 --> Input Class Initialized
INFO - 2025-05-15 14:39:13 --> Language Class Initialized
INFO - 2025-05-15 14:39:13 --> Loader Class Initialized
INFO - 2025-05-15 14:39:13 --> Helper loaded: url_helper
INFO - 2025-05-15 14:39:13 --> Helper loaded: form_helper
INFO - 2025-05-15 14:39:13 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:39:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:39:13 --> Controller Class Initialized
INFO - 2025-05-15 14:39:13 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:39:13 --> Model "User_model" initialized
ERROR - 2025-05-15 14:39:13 --> Query error: Table 'fitnessrec.jadwal_fitness' doesn't exist - Invalid query: SELECT *
FROM `jadwal_fitness`
WHERE `tanggal` = '2025-05-15'
INFO - 2025-05-15 14:39:13 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-15 14:39:13 --> Config Class Initialized
INFO - 2025-05-15 14:39:13 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:39:13 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:39:13 --> Utf8 Class Initialized
INFO - 2025-05-15 14:39:13 --> URI Class Initialized
INFO - 2025-05-15 14:39:13 --> Router Class Initialized
INFO - 2025-05-15 14:39:13 --> Output Class Initialized
INFO - 2025-05-15 14:39:13 --> Security Class Initialized
DEBUG - 2025-05-15 14:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:39:13 --> Input Class Initialized
INFO - 2025-05-15 14:39:13 --> Language Class Initialized
INFO - 2025-05-15 14:39:13 --> Loader Class Initialized
INFO - 2025-05-15 14:39:13 --> Helper loaded: url_helper
INFO - 2025-05-15 14:39:13 --> Helper loaded: form_helper
INFO - 2025-05-15 14:39:13 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:39:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:39:13 --> Controller Class Initialized
INFO - 2025-05-15 14:39:13 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:39:13 --> Model "User_model" initialized
ERROR - 2025-05-15 14:39:13 --> Query error: Table 'fitnessrec.jadwal_fitness' doesn't exist - Invalid query: SELECT *
FROM `jadwal_fitness`
WHERE `tanggal` = '2025-05-15'
INFO - 2025-05-15 14:39:13 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-15 14:39:14 --> Config Class Initialized
INFO - 2025-05-15 14:39:14 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:39:14 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:39:14 --> Utf8 Class Initialized
INFO - 2025-05-15 14:39:14 --> URI Class Initialized
INFO - 2025-05-15 14:39:14 --> Router Class Initialized
INFO - 2025-05-15 14:39:14 --> Output Class Initialized
INFO - 2025-05-15 14:39:14 --> Security Class Initialized
DEBUG - 2025-05-15 14:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:39:14 --> Input Class Initialized
INFO - 2025-05-15 14:39:14 --> Language Class Initialized
INFO - 2025-05-15 14:39:14 --> Loader Class Initialized
INFO - 2025-05-15 14:39:14 --> Helper loaded: url_helper
INFO - 2025-05-15 14:39:14 --> Helper loaded: form_helper
INFO - 2025-05-15 14:39:14 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:39:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:39:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:39:14 --> Controller Class Initialized
INFO - 2025-05-15 14:39:14 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:39:14 --> Model "User_model" initialized
ERROR - 2025-05-15 14:39:14 --> Query error: Table 'fitnessrec.jadwal_fitness' doesn't exist - Invalid query: SELECT *
FROM `jadwal_fitness`
WHERE `tanggal` = '2025-05-15'
INFO - 2025-05-15 14:39:14 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-15 14:39:14 --> Config Class Initialized
INFO - 2025-05-15 14:39:14 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:39:14 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:39:14 --> Utf8 Class Initialized
INFO - 2025-05-15 14:39:14 --> URI Class Initialized
INFO - 2025-05-15 14:39:14 --> Router Class Initialized
INFO - 2025-05-15 14:39:14 --> Output Class Initialized
INFO - 2025-05-15 14:39:14 --> Security Class Initialized
DEBUG - 2025-05-15 14:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:39:14 --> Input Class Initialized
INFO - 2025-05-15 14:39:14 --> Language Class Initialized
INFO - 2025-05-15 14:39:14 --> Loader Class Initialized
INFO - 2025-05-15 14:39:14 --> Helper loaded: url_helper
INFO - 2025-05-15 14:39:14 --> Helper loaded: form_helper
INFO - 2025-05-15 14:39:14 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:39:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:39:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:39:14 --> Controller Class Initialized
INFO - 2025-05-15 14:39:14 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:39:14 --> Model "User_model" initialized
ERROR - 2025-05-15 14:39:14 --> Query error: Table 'fitnessrec.jadwal_fitness' doesn't exist - Invalid query: SELECT *
FROM `jadwal_fitness`
WHERE `tanggal` = '2025-05-15'
INFO - 2025-05-15 14:39:14 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-15 14:39:15 --> Config Class Initialized
INFO - 2025-05-15 14:39:15 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:39:15 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:39:15 --> Utf8 Class Initialized
INFO - 2025-05-15 14:39:15 --> URI Class Initialized
INFO - 2025-05-15 14:39:15 --> Router Class Initialized
INFO - 2025-05-15 14:39:15 --> Output Class Initialized
INFO - 2025-05-15 14:39:15 --> Security Class Initialized
DEBUG - 2025-05-15 14:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:39:15 --> Input Class Initialized
INFO - 2025-05-15 14:39:15 --> Language Class Initialized
INFO - 2025-05-15 14:39:15 --> Loader Class Initialized
INFO - 2025-05-15 14:39:15 --> Helper loaded: url_helper
INFO - 2025-05-15 14:39:15 --> Helper loaded: form_helper
INFO - 2025-05-15 14:39:15 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:39:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:39:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:39:15 --> Controller Class Initialized
INFO - 2025-05-15 14:39:15 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:39:15 --> Model "User_model" initialized
ERROR - 2025-05-15 14:39:15 --> Query error: Table 'fitnessrec.jadwal_fitness' doesn't exist - Invalid query: SELECT *
FROM `jadwal_fitness`
WHERE `tanggal` = '2025-05-15'
INFO - 2025-05-15 14:39:15 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-15 14:43:18 --> Config Class Initialized
INFO - 2025-05-15 14:43:18 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:43:18 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:43:18 --> Utf8 Class Initialized
INFO - 2025-05-15 14:43:18 --> URI Class Initialized
INFO - 2025-05-15 14:43:18 --> Router Class Initialized
INFO - 2025-05-15 14:43:18 --> Output Class Initialized
INFO - 2025-05-15 14:43:18 --> Security Class Initialized
DEBUG - 2025-05-15 14:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:43:18 --> Input Class Initialized
INFO - 2025-05-15 14:43:18 --> Language Class Initialized
INFO - 2025-05-15 14:43:18 --> Loader Class Initialized
INFO - 2025-05-15 14:43:18 --> Helper loaded: url_helper
INFO - 2025-05-15 14:43:18 --> Helper loaded: form_helper
INFO - 2025-05-15 14:43:18 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:43:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:43:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:43:18 --> Controller Class Initialized
INFO - 2025-05-15 14:43:18 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:43:18 --> Model "User_model" initialized
INFO - 2025-05-15 14:43:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 14:43:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 14:43:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-15 14:43:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 14:43:18 --> Final output sent to browser
DEBUG - 2025-05-15 14:43:18 --> Total execution time: 0.0620
INFO - 2025-05-15 14:43:18 --> Config Class Initialized
INFO - 2025-05-15 14:43:18 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:43:18 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:43:18 --> Utf8 Class Initialized
INFO - 2025-05-15 14:43:18 --> URI Class Initialized
INFO - 2025-05-15 14:43:18 --> Router Class Initialized
INFO - 2025-05-15 14:43:18 --> Output Class Initialized
INFO - 2025-05-15 14:43:18 --> Security Class Initialized
DEBUG - 2025-05-15 14:43:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:43:18 --> Input Class Initialized
INFO - 2025-05-15 14:43:18 --> Language Class Initialized
INFO - 2025-05-15 14:43:18 --> Loader Class Initialized
INFO - 2025-05-15 14:43:18 --> Helper loaded: url_helper
INFO - 2025-05-15 14:43:18 --> Helper loaded: form_helper
INFO - 2025-05-15 14:43:18 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:43:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:43:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:43:18 --> Controller Class Initialized
INFO - 2025-05-15 14:43:18 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:43:18 --> Model "User_model" initialized
ERROR - 2025-05-15 14:43:18 --> Query error: Table 'fitnessrec.jadwal_fitness' doesn't exist - Invalid query: SELECT `tanggal`
FROM `jadwal_fitness`
WHERE `status` = 'selesai'
INFO - 2025-05-15 14:43:18 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-15 14:43:21 --> Config Class Initialized
INFO - 2025-05-15 14:43:21 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:43:21 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:43:21 --> Utf8 Class Initialized
INFO - 2025-05-15 14:43:21 --> URI Class Initialized
INFO - 2025-05-15 14:43:21 --> Config Class Initialized
INFO - 2025-05-15 14:43:21 --> Hooks Class Initialized
INFO - 2025-05-15 14:43:21 --> Router Class Initialized
DEBUG - 2025-05-15 14:43:21 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:43:21 --> Output Class Initialized
INFO - 2025-05-15 14:43:21 --> Utf8 Class Initialized
INFO - 2025-05-15 14:43:21 --> Security Class Initialized
INFO - 2025-05-15 14:43:21 --> URI Class Initialized
DEBUG - 2025-05-15 14:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:43:21 --> Input Class Initialized
INFO - 2025-05-15 14:43:21 --> Router Class Initialized
INFO - 2025-05-15 14:43:21 --> Language Class Initialized
INFO - 2025-05-15 14:43:21 --> Output Class Initialized
INFO - 2025-05-15 14:43:21 --> Security Class Initialized
INFO - 2025-05-15 14:43:21 --> Loader Class Initialized
DEBUG - 2025-05-15 14:43:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:43:21 --> Input Class Initialized
INFO - 2025-05-15 14:43:21 --> Helper loaded: url_helper
INFO - 2025-05-15 14:43:21 --> Language Class Initialized
INFO - 2025-05-15 14:43:21 --> Helper loaded: form_helper
INFO - 2025-05-15 14:43:21 --> Loader Class Initialized
INFO - 2025-05-15 14:43:21 --> Helper loaded: url_helper
INFO - 2025-05-15 14:43:21 --> Helper loaded: form_helper
INFO - 2025-05-15 14:43:21 --> Database Driver Class Initialized
INFO - 2025-05-15 14:43:21 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:43:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:43:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:43:21 --> Controller Class Initialized
INFO - 2025-05-15 14:43:21 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:43:21 --> Model "User_model" initialized
DEBUG - 2025-05-15 14:43:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2025-05-15 14:43:21 --> Severity: error --> Exception: Too few arguments to function Workout::start(), 0 passed in C:\laragon\www\Project\fitnessrecord\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\Project\fitnessrecord\application\controllers\Workout.php 77
INFO - 2025-05-15 14:43:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:43:21 --> Controller Class Initialized
INFO - 2025-05-15 14:43:21 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:43:21 --> Model "User_model" initialized
ERROR - 2025-05-15 14:43:21 --> Query error: Table 'fitnessrec.jadwal_fitness' doesn't exist - Invalid query: SELECT *
FROM `jadwal_fitness`
WHERE `tanggal` = '2025-05-15'
INFO - 2025-05-15 14:43:21 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-15 14:43:29 --> Config Class Initialized
INFO - 2025-05-15 14:43:29 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:43:29 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:43:29 --> Utf8 Class Initialized
INFO - 2025-05-15 14:43:29 --> URI Class Initialized
INFO - 2025-05-15 14:43:29 --> Router Class Initialized
INFO - 2025-05-15 14:43:29 --> Output Class Initialized
INFO - 2025-05-15 14:43:29 --> Security Class Initialized
DEBUG - 2025-05-15 14:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:43:29 --> Input Class Initialized
INFO - 2025-05-15 14:43:29 --> Language Class Initialized
INFO - 2025-05-15 14:43:29 --> Loader Class Initialized
INFO - 2025-05-15 14:43:29 --> Helper loaded: url_helper
INFO - 2025-05-15 14:43:29 --> Helper loaded: form_helper
INFO - 2025-05-15 14:43:29 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:43:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:43:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:43:29 --> Controller Class Initialized
INFO - 2025-05-15 14:43:29 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:43:29 --> Model "User_model" initialized
INFO - 2025-05-15 14:43:29 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 14:43:29 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 14:43:29 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-15 14:43:29 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 14:43:29 --> Final output sent to browser
DEBUG - 2025-05-15 14:43:29 --> Total execution time: 0.0780
INFO - 2025-05-15 14:43:29 --> Config Class Initialized
INFO - 2025-05-15 14:43:29 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:43:29 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:43:29 --> Utf8 Class Initialized
INFO - 2025-05-15 14:43:29 --> URI Class Initialized
INFO - 2025-05-15 14:43:29 --> Router Class Initialized
INFO - 2025-05-15 14:43:29 --> Output Class Initialized
INFO - 2025-05-15 14:43:29 --> Security Class Initialized
DEBUG - 2025-05-15 14:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:43:29 --> Input Class Initialized
INFO - 2025-05-15 14:43:29 --> Language Class Initialized
INFO - 2025-05-15 14:43:29 --> Loader Class Initialized
INFO - 2025-05-15 14:43:29 --> Helper loaded: url_helper
INFO - 2025-05-15 14:43:29 --> Helper loaded: form_helper
INFO - 2025-05-15 14:43:29 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:43:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:43:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:43:29 --> Controller Class Initialized
INFO - 2025-05-15 14:43:29 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:43:29 --> Model "User_model" initialized
ERROR - 2025-05-15 14:43:29 --> Query error: Table 'fitnessrec.jadwal_fitness' doesn't exist - Invalid query: SELECT `tanggal`
FROM `jadwal_fitness`
WHERE `status` = 'selesai'
INFO - 2025-05-15 14:43:29 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-15 14:45:13 --> Config Class Initialized
INFO - 2025-05-15 14:45:13 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:45:13 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:45:13 --> Utf8 Class Initialized
INFO - 2025-05-15 14:45:13 --> URI Class Initialized
INFO - 2025-05-15 14:45:13 --> Router Class Initialized
INFO - 2025-05-15 14:45:13 --> Output Class Initialized
INFO - 2025-05-15 14:45:13 --> Security Class Initialized
DEBUG - 2025-05-15 14:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:45:13 --> Input Class Initialized
INFO - 2025-05-15 14:45:13 --> Language Class Initialized
INFO - 2025-05-15 14:45:13 --> Loader Class Initialized
INFO - 2025-05-15 14:45:13 --> Helper loaded: url_helper
INFO - 2025-05-15 14:45:13 --> Helper loaded: form_helper
INFO - 2025-05-15 14:45:13 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:45:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:45:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:45:13 --> Controller Class Initialized
INFO - 2025-05-15 14:45:13 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:45:13 --> Model "User_model" initialized
INFO - 2025-05-15 14:45:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 14:45:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 14:45:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-15 14:45:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 14:45:13 --> Final output sent to browser
DEBUG - 2025-05-15 14:45:13 --> Total execution time: 0.0819
INFO - 2025-05-15 14:45:13 --> Config Class Initialized
INFO - 2025-05-15 14:45:13 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:45:13 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:45:13 --> Utf8 Class Initialized
INFO - 2025-05-15 14:45:13 --> URI Class Initialized
INFO - 2025-05-15 14:45:13 --> Router Class Initialized
INFO - 2025-05-15 14:45:13 --> Output Class Initialized
INFO - 2025-05-15 14:45:13 --> Security Class Initialized
DEBUG - 2025-05-15 14:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:45:13 --> Input Class Initialized
INFO - 2025-05-15 14:45:13 --> Language Class Initialized
INFO - 2025-05-15 14:45:13 --> Loader Class Initialized
INFO - 2025-05-15 14:45:13 --> Helper loaded: url_helper
INFO - 2025-05-15 14:45:13 --> Helper loaded: form_helper
INFO - 2025-05-15 14:45:13 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:45:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:45:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:45:13 --> Controller Class Initialized
INFO - 2025-05-15 14:45:13 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:45:13 --> Model "User_model" initialized
ERROR - 2025-05-15 14:45:13 --> Query error: Table 'fitnessrec.jadwal_fitness' doesn't exist - Invalid query: SELECT `tanggal`
FROM `jadwal_fitness`
WHERE `status` = 'selesai'
INFO - 2025-05-15 14:45:13 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-15 14:45:16 --> Config Class Initialized
INFO - 2025-05-15 14:45:16 --> Hooks Class Initialized
INFO - 2025-05-15 14:45:16 --> Config Class Initialized
INFO - 2025-05-15 14:45:16 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:45:16 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:45:16 --> Utf8 Class Initialized
DEBUG - 2025-05-15 14:45:16 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:45:16 --> URI Class Initialized
INFO - 2025-05-15 14:45:16 --> Utf8 Class Initialized
INFO - 2025-05-15 14:45:16 --> URI Class Initialized
INFO - 2025-05-15 14:45:16 --> Router Class Initialized
INFO - 2025-05-15 14:45:16 --> Router Class Initialized
INFO - 2025-05-15 14:45:16 --> Output Class Initialized
INFO - 2025-05-15 14:45:16 --> Output Class Initialized
INFO - 2025-05-15 14:45:16 --> Security Class Initialized
INFO - 2025-05-15 14:45:16 --> Security Class Initialized
DEBUG - 2025-05-15 14:45:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2025-05-15 14:45:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:45:16 --> Input Class Initialized
INFO - 2025-05-15 14:45:16 --> Input Class Initialized
INFO - 2025-05-15 14:45:16 --> Language Class Initialized
INFO - 2025-05-15 14:45:16 --> Language Class Initialized
INFO - 2025-05-15 14:45:16 --> Loader Class Initialized
INFO - 2025-05-15 14:45:16 --> Loader Class Initialized
INFO - 2025-05-15 14:45:16 --> Helper loaded: url_helper
INFO - 2025-05-15 14:45:16 --> Helper loaded: url_helper
INFO - 2025-05-15 14:45:16 --> Helper loaded: form_helper
INFO - 2025-05-15 14:45:16 --> Helper loaded: form_helper
INFO - 2025-05-15 14:45:16 --> Database Driver Class Initialized
INFO - 2025-05-15 14:45:16 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:45:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2025-05-15 14:45:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:45:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:45:16 --> Controller Class Initialized
INFO - 2025-05-15 14:45:16 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:45:16 --> Model "User_model" initialized
ERROR - 2025-05-15 14:45:16 --> Severity: error --> Exception: Too few arguments to function Workout::start(), 0 passed in C:\laragon\www\Project\fitnessrecord\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\Project\fitnessrecord\application\controllers\Workout.php 77
INFO - 2025-05-15 14:45:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:45:16 --> Controller Class Initialized
INFO - 2025-05-15 14:45:16 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:45:16 --> Model "User_model" initialized
ERROR - 2025-05-15 14:45:16 --> Query error: Table 'fitnessrec.jadwal_fitness' doesn't exist - Invalid query: SELECT *
FROM `jadwal_fitness`
WHERE `tanggal` = '2025-05-15'
INFO - 2025-05-15 14:45:16 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-15 14:52:17 --> Config Class Initialized
INFO - 2025-05-15 14:52:17 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:52:17 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:52:17 --> Utf8 Class Initialized
INFO - 2025-05-15 14:52:17 --> URI Class Initialized
INFO - 2025-05-15 14:52:17 --> Router Class Initialized
INFO - 2025-05-15 14:52:17 --> Output Class Initialized
INFO - 2025-05-15 14:52:17 --> Security Class Initialized
DEBUG - 2025-05-15 14:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:52:17 --> Input Class Initialized
INFO - 2025-05-15 14:52:17 --> Language Class Initialized
INFO - 2025-05-15 14:52:17 --> Loader Class Initialized
INFO - 2025-05-15 14:52:17 --> Helper loaded: url_helper
INFO - 2025-05-15 14:52:17 --> Helper loaded: form_helper
INFO - 2025-05-15 14:52:17 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:52:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:52:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:52:17 --> Controller Class Initialized
INFO - 2025-05-15 14:52:17 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:52:17 --> Model "User_model" initialized
ERROR - 2025-05-15 14:52:17 --> Severity: error --> Exception: Too few arguments to function Workout::start(), 0 passed in C:\laragon\www\Project\fitnessrecord\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\Project\fitnessrecord\application\controllers\Workout.php 77
INFO - 2025-05-15 14:52:18 --> Config Class Initialized
INFO - 2025-05-15 14:52:18 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:52:18 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:52:18 --> Utf8 Class Initialized
INFO - 2025-05-15 14:52:18 --> URI Class Initialized
INFO - 2025-05-15 14:52:18 --> Router Class Initialized
INFO - 2025-05-15 14:52:18 --> Output Class Initialized
INFO - 2025-05-15 14:52:18 --> Security Class Initialized
DEBUG - 2025-05-15 14:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:52:18 --> Input Class Initialized
INFO - 2025-05-15 14:52:18 --> Language Class Initialized
INFO - 2025-05-15 14:52:18 --> Loader Class Initialized
INFO - 2025-05-15 14:52:18 --> Helper loaded: url_helper
INFO - 2025-05-15 14:52:18 --> Helper loaded: form_helper
INFO - 2025-05-15 14:52:18 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:52:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:52:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:52:18 --> Controller Class Initialized
INFO - 2025-05-15 14:52:18 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:52:18 --> Model "User_model" initialized
INFO - 2025-05-15 14:52:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 14:52:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 14:52:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-15 14:52:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 14:52:19 --> Final output sent to browser
DEBUG - 2025-05-15 14:52:19 --> Total execution time: 0.0701
INFO - 2025-05-15 14:52:19 --> Config Class Initialized
INFO - 2025-05-15 14:52:19 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:52:19 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:52:19 --> Utf8 Class Initialized
INFO - 2025-05-15 14:52:19 --> URI Class Initialized
INFO - 2025-05-15 14:52:19 --> Router Class Initialized
INFO - 2025-05-15 14:52:19 --> Output Class Initialized
INFO - 2025-05-15 14:52:19 --> Security Class Initialized
DEBUG - 2025-05-15 14:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:52:19 --> Input Class Initialized
INFO - 2025-05-15 14:52:19 --> Language Class Initialized
INFO - 2025-05-15 14:52:19 --> Loader Class Initialized
INFO - 2025-05-15 14:52:19 --> Helper loaded: url_helper
INFO - 2025-05-15 14:52:19 --> Helper loaded: form_helper
INFO - 2025-05-15 14:52:19 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:52:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:52:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:52:19 --> Controller Class Initialized
INFO - 2025-05-15 14:52:19 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:52:19 --> Model "User_model" initialized
ERROR - 2025-05-15 14:52:19 --> Query error: Table 'fitnessrec.jadwal_fitness' doesn't exist - Invalid query: SELECT `tanggal`
FROM `jadwal_fitness`
WHERE `status` = 'selesai'
INFO - 2025-05-15 14:52:19 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-15 14:55:00 --> Config Class Initialized
INFO - 2025-05-15 14:55:00 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:55:00 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:55:00 --> Utf8 Class Initialized
INFO - 2025-05-15 14:55:00 --> URI Class Initialized
INFO - 2025-05-15 14:55:00 --> Router Class Initialized
INFO - 2025-05-15 14:55:00 --> Output Class Initialized
INFO - 2025-05-15 14:55:00 --> Security Class Initialized
DEBUG - 2025-05-15 14:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:55:00 --> Input Class Initialized
INFO - 2025-05-15 14:55:00 --> Language Class Initialized
INFO - 2025-05-15 14:55:00 --> Loader Class Initialized
INFO - 2025-05-15 14:55:00 --> Helper loaded: url_helper
INFO - 2025-05-15 14:55:00 --> Helper loaded: form_helper
INFO - 2025-05-15 14:55:00 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:55:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:55:00 --> Controller Class Initialized
INFO - 2025-05-15 14:55:00 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:55:00 --> Model "User_model" initialized
INFO - 2025-05-15 14:55:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 14:55:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 14:55:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-15 14:55:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 14:55:00 --> Final output sent to browser
DEBUG - 2025-05-15 14:55:00 --> Total execution time: 0.0883
INFO - 2025-05-15 14:55:04 --> Config Class Initialized
INFO - 2025-05-15 14:55:04 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:55:04 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:55:04 --> Utf8 Class Initialized
INFO - 2025-05-15 14:55:04 --> URI Class Initialized
INFO - 2025-05-15 14:55:04 --> Router Class Initialized
INFO - 2025-05-15 14:55:04 --> Output Class Initialized
INFO - 2025-05-15 14:55:04 --> Security Class Initialized
DEBUG - 2025-05-15 14:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:55:04 --> Input Class Initialized
INFO - 2025-05-15 14:55:04 --> Language Class Initialized
INFO - 2025-05-15 14:55:04 --> Loader Class Initialized
INFO - 2025-05-15 14:55:04 --> Helper loaded: url_helper
INFO - 2025-05-15 14:55:04 --> Helper loaded: form_helper
INFO - 2025-05-15 14:55:04 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:55:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:55:04 --> Controller Class Initialized
INFO - 2025-05-15 14:55:04 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:55:04 --> Model "User_model" initialized
INFO - 2025-05-15 14:55:04 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/start.php
INFO - 2025-05-15 14:55:04 --> Final output sent to browser
DEBUG - 2025-05-15 14:55:04 --> Total execution time: 0.0614
INFO - 2025-05-15 14:55:08 --> Config Class Initialized
INFO - 2025-05-15 14:55:08 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:55:08 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:55:08 --> Utf8 Class Initialized
INFO - 2025-05-15 14:55:08 --> URI Class Initialized
INFO - 2025-05-15 14:55:08 --> Router Class Initialized
INFO - 2025-05-15 14:55:08 --> Output Class Initialized
INFO - 2025-05-15 14:55:08 --> Security Class Initialized
DEBUG - 2025-05-15 14:55:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:55:08 --> Input Class Initialized
INFO - 2025-05-15 14:55:08 --> Language Class Initialized
INFO - 2025-05-15 14:55:08 --> Loader Class Initialized
INFO - 2025-05-15 14:55:08 --> Helper loaded: url_helper
INFO - 2025-05-15 14:55:08 --> Helper loaded: form_helper
INFO - 2025-05-15 14:55:08 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:55:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:55:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:55:08 --> Controller Class Initialized
INFO - 2025-05-15 14:55:08 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:55:08 --> Model "User_model" initialized
INFO - 2025-05-15 14:55:08 --> Final output sent to browser
DEBUG - 2025-05-15 14:55:08 --> Total execution time: 0.0666
INFO - 2025-05-15 14:55:08 --> Config Class Initialized
INFO - 2025-05-15 14:55:08 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:55:08 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:55:08 --> Utf8 Class Initialized
INFO - 2025-05-15 14:55:08 --> URI Class Initialized
INFO - 2025-05-15 14:55:08 --> Router Class Initialized
INFO - 2025-05-15 14:55:08 --> Output Class Initialized
INFO - 2025-05-15 14:55:08 --> Security Class Initialized
DEBUG - 2025-05-15 14:55:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:55:08 --> Input Class Initialized
INFO - 2025-05-15 14:55:08 --> Language Class Initialized
INFO - 2025-05-15 14:55:08 --> Loader Class Initialized
INFO - 2025-05-15 14:55:08 --> Helper loaded: url_helper
INFO - 2025-05-15 14:55:08 --> Helper loaded: form_helper
INFO - 2025-05-15 14:55:08 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:55:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:55:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:55:08 --> Controller Class Initialized
INFO - 2025-05-15 14:55:08 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:55:08 --> Model "User_model" initialized
INFO - 2025-05-15 14:55:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 14:55:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 14:55:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-15 14:55:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 14:55:08 --> Final output sent to browser
DEBUG - 2025-05-15 14:55:08 --> Total execution time: 0.0691
INFO - 2025-05-15 14:55:14 --> Config Class Initialized
INFO - 2025-05-15 14:55:14 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:55:14 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:55:14 --> Utf8 Class Initialized
INFO - 2025-05-15 14:55:14 --> URI Class Initialized
INFO - 2025-05-15 14:55:14 --> Router Class Initialized
INFO - 2025-05-15 14:55:14 --> Output Class Initialized
INFO - 2025-05-15 14:55:14 --> Security Class Initialized
DEBUG - 2025-05-15 14:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:55:14 --> Input Class Initialized
INFO - 2025-05-15 14:55:14 --> Language Class Initialized
INFO - 2025-05-15 14:55:14 --> Loader Class Initialized
INFO - 2025-05-15 14:55:14 --> Helper loaded: url_helper
INFO - 2025-05-15 14:55:14 --> Helper loaded: form_helper
INFO - 2025-05-15 14:55:14 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:55:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:55:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:55:15 --> Controller Class Initialized
INFO - 2025-05-15 14:55:15 --> Model "User_model" initialized
INFO - 2025-05-15 14:55:15 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:55:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 14:55:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 14:55:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-15 14:55:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 14:55:15 --> Final output sent to browser
DEBUG - 2025-05-15 14:55:15 --> Total execution time: 0.0871
INFO - 2025-05-15 14:55:44 --> Config Class Initialized
INFO - 2025-05-15 14:55:44 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:55:44 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:55:44 --> Utf8 Class Initialized
INFO - 2025-05-15 14:55:44 --> URI Class Initialized
INFO - 2025-05-15 14:55:44 --> Router Class Initialized
INFO - 2025-05-15 14:55:44 --> Output Class Initialized
INFO - 2025-05-15 14:55:44 --> Security Class Initialized
DEBUG - 2025-05-15 14:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:55:44 --> Input Class Initialized
INFO - 2025-05-15 14:55:44 --> Language Class Initialized
INFO - 2025-05-15 14:55:44 --> Loader Class Initialized
INFO - 2025-05-15 14:55:44 --> Helper loaded: url_helper
INFO - 2025-05-15 14:55:44 --> Helper loaded: form_helper
INFO - 2025-05-15 14:55:44 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:55:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:55:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:55:44 --> Controller Class Initialized
INFO - 2025-05-15 14:55:44 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:55:44 --> Model "User_model" initialized
INFO - 2025-05-15 14:55:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 14:55:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 14:55:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-15 14:55:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 14:55:44 --> Final output sent to browser
DEBUG - 2025-05-15 14:55:44 --> Total execution time: 0.0796
INFO - 2025-05-15 14:56:28 --> Config Class Initialized
INFO - 2025-05-15 14:56:28 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:56:28 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:56:28 --> Utf8 Class Initialized
INFO - 2025-05-15 14:56:28 --> URI Class Initialized
INFO - 2025-05-15 14:56:28 --> Router Class Initialized
INFO - 2025-05-15 14:56:28 --> Output Class Initialized
INFO - 2025-05-15 14:56:28 --> Security Class Initialized
DEBUG - 2025-05-15 14:56:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:56:28 --> Input Class Initialized
INFO - 2025-05-15 14:56:28 --> Language Class Initialized
INFO - 2025-05-15 14:56:28 --> Loader Class Initialized
INFO - 2025-05-15 14:56:28 --> Helper loaded: url_helper
INFO - 2025-05-15 14:56:28 --> Helper loaded: form_helper
INFO - 2025-05-15 14:56:28 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:56:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:56:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:56:28 --> Controller Class Initialized
INFO - 2025-05-15 14:56:28 --> Model "User_model" initialized
INFO - 2025-05-15 14:56:28 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:56:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 14:56:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 14:56:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-15 14:56:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 14:56:28 --> Final output sent to browser
DEBUG - 2025-05-15 14:56:28 --> Total execution time: 0.1040
INFO - 2025-05-15 14:59:22 --> Config Class Initialized
INFO - 2025-05-15 14:59:22 --> Hooks Class Initialized
DEBUG - 2025-05-15 14:59:22 --> UTF-8 Support Enabled
INFO - 2025-05-15 14:59:22 --> Utf8 Class Initialized
INFO - 2025-05-15 14:59:22 --> URI Class Initialized
INFO - 2025-05-15 14:59:22 --> Router Class Initialized
INFO - 2025-05-15 14:59:22 --> Output Class Initialized
INFO - 2025-05-15 14:59:22 --> Security Class Initialized
DEBUG - 2025-05-15 14:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 14:59:22 --> Input Class Initialized
INFO - 2025-05-15 14:59:22 --> Language Class Initialized
INFO - 2025-05-15 14:59:22 --> Loader Class Initialized
INFO - 2025-05-15 14:59:22 --> Helper loaded: url_helper
INFO - 2025-05-15 14:59:22 --> Helper loaded: form_helper
INFO - 2025-05-15 14:59:22 --> Database Driver Class Initialized
DEBUG - 2025-05-15 14:59:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 14:59:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 14:59:22 --> Controller Class Initialized
INFO - 2025-05-15 14:59:22 --> Model "User_model" initialized
INFO - 2025-05-15 14:59:22 --> Model "Workout_model" initialized
INFO - 2025-05-15 14:59:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 14:59:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 14:59:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-15 14:59:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 14:59:22 --> Final output sent to browser
DEBUG - 2025-05-15 14:59:22 --> Total execution time: 0.0707
INFO - 2025-05-15 15:02:00 --> Config Class Initialized
INFO - 2025-05-15 15:02:00 --> Hooks Class Initialized
DEBUG - 2025-05-15 15:02:00 --> UTF-8 Support Enabled
INFO - 2025-05-15 15:02:00 --> Utf8 Class Initialized
INFO - 2025-05-15 15:02:00 --> URI Class Initialized
INFO - 2025-05-15 15:02:00 --> Router Class Initialized
INFO - 2025-05-15 15:02:00 --> Output Class Initialized
INFO - 2025-05-15 15:02:00 --> Security Class Initialized
DEBUG - 2025-05-15 15:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 15:02:00 --> Input Class Initialized
INFO - 2025-05-15 15:02:00 --> Language Class Initialized
INFO - 2025-05-15 15:02:00 --> Loader Class Initialized
INFO - 2025-05-15 15:02:00 --> Helper loaded: url_helper
INFO - 2025-05-15 15:02:00 --> Helper loaded: form_helper
INFO - 2025-05-15 15:02:00 --> Database Driver Class Initialized
DEBUG - 2025-05-15 15:02:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 15:02:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 15:02:00 --> Controller Class Initialized
INFO - 2025-05-15 15:02:00 --> Model "Workout_model" initialized
INFO - 2025-05-15 15:02:00 --> Model "User_model" initialized
INFO - 2025-05-15 15:02:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 15:02:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 15:02:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-15 15:02:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 15:02:00 --> Final output sent to browser
DEBUG - 2025-05-15 15:02:00 --> Total execution time: 0.0792
INFO - 2025-05-15 15:09:36 --> Config Class Initialized
INFO - 2025-05-15 15:09:36 --> Hooks Class Initialized
DEBUG - 2025-05-15 15:09:36 --> UTF-8 Support Enabled
INFO - 2025-05-15 15:09:36 --> Utf8 Class Initialized
INFO - 2025-05-15 15:09:36 --> URI Class Initialized
INFO - 2025-05-15 15:09:36 --> Router Class Initialized
INFO - 2025-05-15 15:09:36 --> Output Class Initialized
INFO - 2025-05-15 15:09:36 --> Security Class Initialized
DEBUG - 2025-05-15 15:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 15:09:36 --> Input Class Initialized
INFO - 2025-05-15 15:09:36 --> Language Class Initialized
INFO - 2025-05-15 15:09:36 --> Loader Class Initialized
INFO - 2025-05-15 15:09:36 --> Helper loaded: url_helper
INFO - 2025-05-15 15:09:36 --> Helper loaded: form_helper
INFO - 2025-05-15 15:09:36 --> Database Driver Class Initialized
DEBUG - 2025-05-15 15:09:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 15:09:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 15:09:36 --> Controller Class Initialized
INFO - 2025-05-15 15:09:36 --> Model "Workout_model" initialized
INFO - 2025-05-15 15:09:36 --> Model "User_model" initialized
INFO - 2025-05-15 15:09:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 15:09:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 15:09:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-15 15:09:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 15:09:36 --> Final output sent to browser
DEBUG - 2025-05-15 15:09:36 --> Total execution time: 0.0872
INFO - 2025-05-15 15:09:38 --> Config Class Initialized
INFO - 2025-05-15 15:09:38 --> Hooks Class Initialized
DEBUG - 2025-05-15 15:09:38 --> UTF-8 Support Enabled
INFO - 2025-05-15 15:09:38 --> Utf8 Class Initialized
INFO - 2025-05-15 15:09:38 --> URI Class Initialized
INFO - 2025-05-15 15:09:38 --> Router Class Initialized
INFO - 2025-05-15 15:09:38 --> Output Class Initialized
INFO - 2025-05-15 15:09:38 --> Security Class Initialized
DEBUG - 2025-05-15 15:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 15:09:38 --> Input Class Initialized
INFO - 2025-05-15 15:09:38 --> Language Class Initialized
INFO - 2025-05-15 15:09:38 --> Loader Class Initialized
INFO - 2025-05-15 15:09:38 --> Helper loaded: url_helper
INFO - 2025-05-15 15:09:38 --> Helper loaded: form_helper
INFO - 2025-05-15 15:09:38 --> Database Driver Class Initialized
DEBUG - 2025-05-15 15:09:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 15:09:38 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 15:09:38 --> Controller Class Initialized
INFO - 2025-05-15 15:09:38 --> Model "Workout_model" initialized
INFO - 2025-05-15 15:09:38 --> Model "User_model" initialized
ERROR - 2025-05-15 15:09:38 --> Query error: Unknown column 'schedule_date' in 'field list' - Invalid query: INSERT INTO `workout_records` (`user_id`, `activity`, `schedule_date`, `notes`, `level`) VALUES ('2', 'Cardio', '2025-05-16', '', 'High')
INFO - 2025-05-15 15:09:38 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-15 15:09:44 --> Config Class Initialized
INFO - 2025-05-15 15:09:44 --> Hooks Class Initialized
DEBUG - 2025-05-15 15:09:44 --> UTF-8 Support Enabled
INFO - 2025-05-15 15:09:44 --> Utf8 Class Initialized
INFO - 2025-05-15 15:09:44 --> URI Class Initialized
INFO - 2025-05-15 15:09:44 --> Router Class Initialized
INFO - 2025-05-15 15:09:44 --> Output Class Initialized
INFO - 2025-05-15 15:09:44 --> Security Class Initialized
DEBUG - 2025-05-15 15:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 15:09:44 --> Input Class Initialized
INFO - 2025-05-15 15:09:44 --> Language Class Initialized
INFO - 2025-05-15 15:09:44 --> Loader Class Initialized
INFO - 2025-05-15 15:09:44 --> Helper loaded: url_helper
INFO - 2025-05-15 15:09:44 --> Helper loaded: form_helper
INFO - 2025-05-15 15:09:44 --> Database Driver Class Initialized
DEBUG - 2025-05-15 15:09:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 15:09:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 15:09:44 --> Controller Class Initialized
INFO - 2025-05-15 15:09:44 --> Model "Workout_model" initialized
INFO - 2025-05-15 15:09:44 --> Model "User_model" initialized
INFO - 2025-05-15 15:09:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 15:09:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 15:09:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-15 15:09:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 15:09:44 --> Final output sent to browser
DEBUG - 2025-05-15 15:09:44 --> Total execution time: 0.0928
INFO - 2025-05-15 15:10:26 --> Config Class Initialized
INFO - 2025-05-15 15:10:26 --> Hooks Class Initialized
DEBUG - 2025-05-15 15:10:26 --> UTF-8 Support Enabled
INFO - 2025-05-15 15:10:26 --> Utf8 Class Initialized
INFO - 2025-05-15 15:10:26 --> URI Class Initialized
INFO - 2025-05-15 15:10:26 --> Router Class Initialized
INFO - 2025-05-15 15:10:26 --> Output Class Initialized
INFO - 2025-05-15 15:10:26 --> Security Class Initialized
DEBUG - 2025-05-15 15:10:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 15:10:26 --> Input Class Initialized
INFO - 2025-05-15 15:10:26 --> Language Class Initialized
INFO - 2025-05-15 15:10:26 --> Loader Class Initialized
INFO - 2025-05-15 15:10:26 --> Helper loaded: url_helper
INFO - 2025-05-15 15:10:26 --> Helper loaded: form_helper
INFO - 2025-05-15 15:10:26 --> Database Driver Class Initialized
DEBUG - 2025-05-15 15:10:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 15:10:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 15:10:26 --> Controller Class Initialized
INFO - 2025-05-15 15:10:26 --> Model "Workout_model" initialized
INFO - 2025-05-15 15:10:26 --> Model "User_model" initialized
ERROR - 2025-05-15 15:10:26 --> Query error: Unknown column 'schedule_date' in 'field list' - Invalid query: INSERT INTO `workout_records` (`user_id`, `activity`, `schedule_date`, `notes`, `level`) VALUES ('2', 'Cardio', '2025-05-16', '', 'High')
INFO - 2025-05-15 15:10:26 --> Language file loaded: language/english/db_lang.php
INFO - 2025-05-15 15:14:12 --> Config Class Initialized
INFO - 2025-05-15 15:14:12 --> Hooks Class Initialized
DEBUG - 2025-05-15 15:14:12 --> UTF-8 Support Enabled
INFO - 2025-05-15 15:14:12 --> Utf8 Class Initialized
INFO - 2025-05-15 15:14:12 --> URI Class Initialized
INFO - 2025-05-15 15:14:12 --> Router Class Initialized
INFO - 2025-05-15 15:14:12 --> Output Class Initialized
INFO - 2025-05-15 15:14:12 --> Security Class Initialized
DEBUG - 2025-05-15 15:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 15:14:12 --> Input Class Initialized
INFO - 2025-05-15 15:14:12 --> Language Class Initialized
INFO - 2025-05-15 15:14:12 --> Loader Class Initialized
INFO - 2025-05-15 15:14:12 --> Helper loaded: url_helper
INFO - 2025-05-15 15:14:12 --> Helper loaded: form_helper
INFO - 2025-05-15 15:14:12 --> Database Driver Class Initialized
DEBUG - 2025-05-15 15:14:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 15:14:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 15:14:12 --> Controller Class Initialized
INFO - 2025-05-15 15:14:12 --> Model "Workout_model" initialized
INFO - 2025-05-15 15:14:12 --> Model "User_model" initialized
INFO - 2025-05-15 15:14:12 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 15:14:12 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 15:14:12 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-15 15:14:12 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 15:14:12 --> Final output sent to browser
DEBUG - 2025-05-15 15:14:12 --> Total execution time: 0.0916
INFO - 2025-05-15 15:14:14 --> Config Class Initialized
INFO - 2025-05-15 15:14:14 --> Hooks Class Initialized
DEBUG - 2025-05-15 15:14:14 --> UTF-8 Support Enabled
INFO - 2025-05-15 15:14:14 --> Utf8 Class Initialized
INFO - 2025-05-15 15:14:14 --> URI Class Initialized
INFO - 2025-05-15 15:14:14 --> Router Class Initialized
INFO - 2025-05-15 15:14:14 --> Output Class Initialized
INFO - 2025-05-15 15:14:14 --> Security Class Initialized
DEBUG - 2025-05-15 15:14:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 15:14:14 --> Input Class Initialized
INFO - 2025-05-15 15:14:14 --> Language Class Initialized
INFO - 2025-05-15 15:14:14 --> Loader Class Initialized
INFO - 2025-05-15 15:14:14 --> Helper loaded: url_helper
INFO - 2025-05-15 15:14:14 --> Helper loaded: form_helper
INFO - 2025-05-15 15:14:14 --> Database Driver Class Initialized
DEBUG - 2025-05-15 15:14:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 15:14:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 15:14:14 --> Controller Class Initialized
INFO - 2025-05-15 15:14:14 --> Model "Workout_model" initialized
INFO - 2025-05-15 15:14:14 --> Model "User_model" initialized
INFO - 2025-05-15 15:14:14 --> Config Class Initialized
INFO - 2025-05-15 15:14:14 --> Hooks Class Initialized
DEBUG - 2025-05-15 15:14:14 --> UTF-8 Support Enabled
INFO - 2025-05-15 15:14:14 --> Utf8 Class Initialized
INFO - 2025-05-15 15:14:14 --> URI Class Initialized
INFO - 2025-05-15 15:14:14 --> Router Class Initialized
INFO - 2025-05-15 15:14:14 --> Output Class Initialized
INFO - 2025-05-15 15:14:14 --> Security Class Initialized
DEBUG - 2025-05-15 15:14:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 15:14:14 --> Input Class Initialized
INFO - 2025-05-15 15:14:14 --> Language Class Initialized
INFO - 2025-05-15 15:14:14 --> Loader Class Initialized
INFO - 2025-05-15 15:14:14 --> Helper loaded: url_helper
INFO - 2025-05-15 15:14:14 --> Helper loaded: form_helper
INFO - 2025-05-15 15:14:14 --> Database Driver Class Initialized
DEBUG - 2025-05-15 15:14:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 15:14:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 15:14:14 --> Controller Class Initialized
INFO - 2025-05-15 15:14:14 --> Model "Workout_model" initialized
INFO - 2025-05-15 15:14:14 --> Model "User_model" initialized
INFO - 2025-05-15 15:14:14 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 15:14:14 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 15:14:14 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-15 15:14:14 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 15:14:14 --> Final output sent to browser
DEBUG - 2025-05-15 15:14:14 --> Total execution time: 0.0628
INFO - 2025-05-15 15:14:46 --> Config Class Initialized
INFO - 2025-05-15 15:14:46 --> Hooks Class Initialized
DEBUG - 2025-05-15 15:14:46 --> UTF-8 Support Enabled
INFO - 2025-05-15 15:14:46 --> Utf8 Class Initialized
INFO - 2025-05-15 15:14:46 --> URI Class Initialized
INFO - 2025-05-15 15:14:46 --> Router Class Initialized
INFO - 2025-05-15 15:14:46 --> Output Class Initialized
INFO - 2025-05-15 15:14:46 --> Security Class Initialized
DEBUG - 2025-05-15 15:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 15:14:46 --> Input Class Initialized
INFO - 2025-05-15 15:14:46 --> Language Class Initialized
INFO - 2025-05-15 15:14:46 --> Loader Class Initialized
INFO - 2025-05-15 15:14:46 --> Helper loaded: url_helper
INFO - 2025-05-15 15:14:46 --> Helper loaded: form_helper
INFO - 2025-05-15 15:14:46 --> Database Driver Class Initialized
DEBUG - 2025-05-15 15:14:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 15:14:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 15:14:46 --> Controller Class Initialized
INFO - 2025-05-15 15:14:46 --> Model "Workout_model" initialized
INFO - 2025-05-15 15:14:46 --> Model "User_model" initialized
INFO - 2025-05-15 15:14:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/start.php
INFO - 2025-05-15 15:14:46 --> Final output sent to browser
DEBUG - 2025-05-15 15:14:46 --> Total execution time: 0.0714
INFO - 2025-05-15 15:14:49 --> Config Class Initialized
INFO - 2025-05-15 15:14:49 --> Hooks Class Initialized
DEBUG - 2025-05-15 15:14:49 --> UTF-8 Support Enabled
INFO - 2025-05-15 15:14:49 --> Utf8 Class Initialized
INFO - 2025-05-15 15:14:49 --> URI Class Initialized
INFO - 2025-05-15 15:14:49 --> Router Class Initialized
INFO - 2025-05-15 15:14:49 --> Output Class Initialized
INFO - 2025-05-15 15:14:49 --> Security Class Initialized
DEBUG - 2025-05-15 15:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 15:14:49 --> Input Class Initialized
INFO - 2025-05-15 15:14:49 --> Language Class Initialized
INFO - 2025-05-15 15:14:50 --> Loader Class Initialized
INFO - 2025-05-15 15:14:50 --> Helper loaded: url_helper
INFO - 2025-05-15 15:14:50 --> Helper loaded: form_helper
INFO - 2025-05-15 15:14:50 --> Database Driver Class Initialized
DEBUG - 2025-05-15 15:14:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 15:14:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 15:14:50 --> Controller Class Initialized
INFO - 2025-05-15 15:14:50 --> Model "Workout_model" initialized
INFO - 2025-05-15 15:14:50 --> Model "User_model" initialized
INFO - 2025-05-15 15:14:50 --> Final output sent to browser
DEBUG - 2025-05-15 15:14:50 --> Total execution time: 0.0778
INFO - 2025-05-15 15:14:50 --> Config Class Initialized
INFO - 2025-05-15 15:14:50 --> Hooks Class Initialized
DEBUG - 2025-05-15 15:14:50 --> UTF-8 Support Enabled
INFO - 2025-05-15 15:14:50 --> Utf8 Class Initialized
INFO - 2025-05-15 15:14:50 --> URI Class Initialized
INFO - 2025-05-15 15:14:50 --> Router Class Initialized
INFO - 2025-05-15 15:14:50 --> Output Class Initialized
INFO - 2025-05-15 15:14:50 --> Security Class Initialized
DEBUG - 2025-05-15 15:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 15:14:50 --> Input Class Initialized
INFO - 2025-05-15 15:14:50 --> Language Class Initialized
INFO - 2025-05-15 15:14:50 --> Loader Class Initialized
INFO - 2025-05-15 15:14:50 --> Helper loaded: url_helper
INFO - 2025-05-15 15:14:50 --> Helper loaded: form_helper
INFO - 2025-05-15 15:14:50 --> Database Driver Class Initialized
DEBUG - 2025-05-15 15:14:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 15:14:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 15:14:50 --> Controller Class Initialized
INFO - 2025-05-15 15:14:50 --> Model "Workout_model" initialized
INFO - 2025-05-15 15:14:50 --> Model "User_model" initialized
INFO - 2025-05-15 15:14:50 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 15:14:50 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 15:14:50 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-15 15:14:50 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 15:14:50 --> Final output sent to browser
DEBUG - 2025-05-15 15:14:50 --> Total execution time: 0.0793
INFO - 2025-05-15 15:14:58 --> Config Class Initialized
INFO - 2025-05-15 15:14:58 --> Hooks Class Initialized
DEBUG - 2025-05-15 15:14:58 --> UTF-8 Support Enabled
INFO - 2025-05-15 15:14:58 --> Utf8 Class Initialized
INFO - 2025-05-15 15:14:58 --> URI Class Initialized
INFO - 2025-05-15 15:14:58 --> Router Class Initialized
INFO - 2025-05-15 15:14:58 --> Output Class Initialized
INFO - 2025-05-15 15:14:58 --> Security Class Initialized
DEBUG - 2025-05-15 15:14:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 15:14:58 --> Input Class Initialized
INFO - 2025-05-15 15:14:58 --> Language Class Initialized
INFO - 2025-05-15 15:14:58 --> Loader Class Initialized
INFO - 2025-05-15 15:14:58 --> Helper loaded: url_helper
INFO - 2025-05-15 15:14:58 --> Helper loaded: form_helper
INFO - 2025-05-15 15:14:58 --> Database Driver Class Initialized
DEBUG - 2025-05-15 15:14:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 15:14:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 15:14:58 --> Controller Class Initialized
INFO - 2025-05-15 15:14:58 --> Model "Workout_model" initialized
INFO - 2025-05-15 15:14:58 --> Model "User_model" initialized
INFO - 2025-05-15 15:14:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/start.php
INFO - 2025-05-15 15:14:58 --> Final output sent to browser
DEBUG - 2025-05-15 15:14:58 --> Total execution time: 0.0901
INFO - 2025-05-15 15:15:02 --> Config Class Initialized
INFO - 2025-05-15 15:15:02 --> Hooks Class Initialized
DEBUG - 2025-05-15 15:15:02 --> UTF-8 Support Enabled
INFO - 2025-05-15 15:15:02 --> Utf8 Class Initialized
INFO - 2025-05-15 15:15:02 --> URI Class Initialized
INFO - 2025-05-15 15:15:02 --> Router Class Initialized
INFO - 2025-05-15 15:15:02 --> Output Class Initialized
INFO - 2025-05-15 15:15:02 --> Security Class Initialized
DEBUG - 2025-05-15 15:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 15:15:02 --> Input Class Initialized
INFO - 2025-05-15 15:15:02 --> Language Class Initialized
INFO - 2025-05-15 15:15:02 --> Loader Class Initialized
INFO - 2025-05-15 15:15:02 --> Helper loaded: url_helper
INFO - 2025-05-15 15:15:02 --> Helper loaded: form_helper
INFO - 2025-05-15 15:15:02 --> Database Driver Class Initialized
DEBUG - 2025-05-15 15:15:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 15:15:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 15:15:02 --> Controller Class Initialized
INFO - 2025-05-15 15:15:02 --> Model "Workout_model" initialized
INFO - 2025-05-15 15:15:02 --> Model "User_model" initialized
INFO - 2025-05-15 15:15:02 --> Final output sent to browser
DEBUG - 2025-05-15 15:15:02 --> Total execution time: 0.0650
INFO - 2025-05-15 15:15:02 --> Config Class Initialized
INFO - 2025-05-15 15:15:02 --> Hooks Class Initialized
DEBUG - 2025-05-15 15:15:02 --> UTF-8 Support Enabled
INFO - 2025-05-15 15:15:02 --> Utf8 Class Initialized
INFO - 2025-05-15 15:15:02 --> URI Class Initialized
INFO - 2025-05-15 15:15:02 --> Router Class Initialized
INFO - 2025-05-15 15:15:02 --> Output Class Initialized
INFO - 2025-05-15 15:15:02 --> Security Class Initialized
DEBUG - 2025-05-15 15:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 15:15:02 --> Input Class Initialized
INFO - 2025-05-15 15:15:02 --> Language Class Initialized
INFO - 2025-05-15 15:15:02 --> Loader Class Initialized
INFO - 2025-05-15 15:15:02 --> Helper loaded: url_helper
INFO - 2025-05-15 15:15:02 --> Helper loaded: form_helper
INFO - 2025-05-15 15:15:02 --> Database Driver Class Initialized
DEBUG - 2025-05-15 15:15:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 15:15:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 15:15:02 --> Controller Class Initialized
INFO - 2025-05-15 15:15:02 --> Model "Workout_model" initialized
INFO - 2025-05-15 15:15:02 --> Model "User_model" initialized
INFO - 2025-05-15 15:15:02 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 15:15:02 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 15:15:02 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-15 15:15:02 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 15:15:02 --> Final output sent to browser
DEBUG - 2025-05-15 15:15:02 --> Total execution time: 0.0640
INFO - 2025-05-15 15:15:24 --> Config Class Initialized
INFO - 2025-05-15 15:15:24 --> Hooks Class Initialized
DEBUG - 2025-05-15 15:15:24 --> UTF-8 Support Enabled
INFO - 2025-05-15 15:15:24 --> Utf8 Class Initialized
INFO - 2025-05-15 15:15:24 --> URI Class Initialized
INFO - 2025-05-15 15:15:24 --> Router Class Initialized
INFO - 2025-05-15 15:15:24 --> Output Class Initialized
INFO - 2025-05-15 15:15:24 --> Security Class Initialized
DEBUG - 2025-05-15 15:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 15:15:24 --> Input Class Initialized
INFO - 2025-05-15 15:15:24 --> Language Class Initialized
INFO - 2025-05-15 15:15:24 --> Loader Class Initialized
INFO - 2025-05-15 15:15:24 --> Helper loaded: url_helper
INFO - 2025-05-15 15:15:24 --> Helper loaded: form_helper
INFO - 2025-05-15 15:15:24 --> Database Driver Class Initialized
DEBUG - 2025-05-15 15:15:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 15:15:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 15:15:24 --> Controller Class Initialized
INFO - 2025-05-15 15:15:24 --> Model "Workout_model" initialized
INFO - 2025-05-15 15:15:24 --> Model "User_model" initialized
INFO - 2025-05-15 15:15:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/start.php
INFO - 2025-05-15 15:15:24 --> Final output sent to browser
DEBUG - 2025-05-15 15:15:24 --> Total execution time: 0.0592
INFO - 2025-05-15 15:15:27 --> Config Class Initialized
INFO - 2025-05-15 15:15:27 --> Hooks Class Initialized
DEBUG - 2025-05-15 15:15:27 --> UTF-8 Support Enabled
INFO - 2025-05-15 15:15:27 --> Utf8 Class Initialized
INFO - 2025-05-15 15:15:27 --> URI Class Initialized
INFO - 2025-05-15 15:15:27 --> Router Class Initialized
INFO - 2025-05-15 15:15:27 --> Output Class Initialized
INFO - 2025-05-15 15:15:27 --> Security Class Initialized
DEBUG - 2025-05-15 15:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 15:15:27 --> Input Class Initialized
INFO - 2025-05-15 15:15:27 --> Language Class Initialized
INFO - 2025-05-15 15:15:27 --> Loader Class Initialized
INFO - 2025-05-15 15:15:27 --> Helper loaded: url_helper
INFO - 2025-05-15 15:15:27 --> Helper loaded: form_helper
INFO - 2025-05-15 15:15:27 --> Database Driver Class Initialized
DEBUG - 2025-05-15 15:15:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 15:15:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 15:15:27 --> Controller Class Initialized
INFO - 2025-05-15 15:15:27 --> Model "Workout_model" initialized
INFO - 2025-05-15 15:15:27 --> Model "User_model" initialized
INFO - 2025-05-15 15:15:27 --> Final output sent to browser
DEBUG - 2025-05-15 15:15:27 --> Total execution time: 0.0884
INFO - 2025-05-15 15:15:27 --> Config Class Initialized
INFO - 2025-05-15 15:15:27 --> Hooks Class Initialized
DEBUG - 2025-05-15 15:15:27 --> UTF-8 Support Enabled
INFO - 2025-05-15 15:15:27 --> Utf8 Class Initialized
INFO - 2025-05-15 15:15:27 --> URI Class Initialized
INFO - 2025-05-15 15:15:27 --> Router Class Initialized
INFO - 2025-05-15 15:15:27 --> Output Class Initialized
INFO - 2025-05-15 15:15:27 --> Security Class Initialized
DEBUG - 2025-05-15 15:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 15:15:27 --> Input Class Initialized
INFO - 2025-05-15 15:15:27 --> Language Class Initialized
INFO - 2025-05-15 15:15:27 --> Loader Class Initialized
INFO - 2025-05-15 15:15:27 --> Helper loaded: url_helper
INFO - 2025-05-15 15:15:27 --> Helper loaded: form_helper
INFO - 2025-05-15 15:15:27 --> Database Driver Class Initialized
DEBUG - 2025-05-15 15:15:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 15:15:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 15:15:27 --> Controller Class Initialized
INFO - 2025-05-15 15:15:27 --> Model "Workout_model" initialized
INFO - 2025-05-15 15:15:27 --> Model "User_model" initialized
INFO - 2025-05-15 15:15:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 15:15:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 15:15:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-15 15:15:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 15:15:27 --> Final output sent to browser
DEBUG - 2025-05-15 15:15:27 --> Total execution time: 0.0594
INFO - 2025-05-15 15:15:49 --> Config Class Initialized
INFO - 2025-05-15 15:15:49 --> Hooks Class Initialized
DEBUG - 2025-05-15 15:15:49 --> UTF-8 Support Enabled
INFO - 2025-05-15 15:15:49 --> Utf8 Class Initialized
INFO - 2025-05-15 15:15:49 --> URI Class Initialized
INFO - 2025-05-15 15:15:49 --> Router Class Initialized
INFO - 2025-05-15 15:15:49 --> Output Class Initialized
INFO - 2025-05-15 15:15:49 --> Security Class Initialized
DEBUG - 2025-05-15 15:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 15:15:49 --> Input Class Initialized
INFO - 2025-05-15 15:15:49 --> Language Class Initialized
INFO - 2025-05-15 15:15:49 --> Loader Class Initialized
INFO - 2025-05-15 15:15:49 --> Helper loaded: url_helper
INFO - 2025-05-15 15:15:49 --> Helper loaded: form_helper
INFO - 2025-05-15 15:15:49 --> Database Driver Class Initialized
DEBUG - 2025-05-15 15:15:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 15:15:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 15:15:49 --> Controller Class Initialized
INFO - 2025-05-15 15:15:49 --> Model "Workout_model" initialized
INFO - 2025-05-15 15:15:49 --> Model "User_model" initialized
INFO - 2025-05-15 15:15:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 15:15:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 15:15:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-15 15:15:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 15:15:49 --> Final output sent to browser
DEBUG - 2025-05-15 15:15:49 --> Total execution time: 0.0615
INFO - 2025-05-15 15:16:16 --> Config Class Initialized
INFO - 2025-05-15 15:16:16 --> Hooks Class Initialized
DEBUG - 2025-05-15 15:16:16 --> UTF-8 Support Enabled
INFO - 2025-05-15 15:16:16 --> Utf8 Class Initialized
INFO - 2025-05-15 15:16:16 --> URI Class Initialized
INFO - 2025-05-15 15:16:16 --> Router Class Initialized
INFO - 2025-05-15 15:16:16 --> Output Class Initialized
INFO - 2025-05-15 15:16:16 --> Security Class Initialized
DEBUG - 2025-05-15 15:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 15:16:16 --> Input Class Initialized
INFO - 2025-05-15 15:16:16 --> Language Class Initialized
INFO - 2025-05-15 15:16:16 --> Loader Class Initialized
INFO - 2025-05-15 15:16:16 --> Helper loaded: url_helper
INFO - 2025-05-15 15:16:16 --> Helper loaded: form_helper
INFO - 2025-05-15 15:16:16 --> Database Driver Class Initialized
DEBUG - 2025-05-15 15:16:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 15:16:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 15:16:16 --> Controller Class Initialized
INFO - 2025-05-15 15:16:16 --> Model "Workout_model" initialized
INFO - 2025-05-15 15:16:16 --> Model "User_model" initialized
INFO - 2025-05-15 15:16:16 --> Config Class Initialized
INFO - 2025-05-15 15:16:16 --> Hooks Class Initialized
DEBUG - 2025-05-15 15:16:16 --> UTF-8 Support Enabled
INFO - 2025-05-15 15:16:16 --> Utf8 Class Initialized
INFO - 2025-05-15 15:16:16 --> URI Class Initialized
INFO - 2025-05-15 15:16:16 --> Router Class Initialized
INFO - 2025-05-15 15:16:16 --> Output Class Initialized
INFO - 2025-05-15 15:16:16 --> Security Class Initialized
DEBUG - 2025-05-15 15:16:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 15:16:16 --> Input Class Initialized
INFO - 2025-05-15 15:16:16 --> Language Class Initialized
INFO - 2025-05-15 15:16:16 --> Loader Class Initialized
INFO - 2025-05-15 15:16:16 --> Helper loaded: url_helper
INFO - 2025-05-15 15:16:16 --> Helper loaded: form_helper
INFO - 2025-05-15 15:16:16 --> Database Driver Class Initialized
DEBUG - 2025-05-15 15:16:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 15:16:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 15:16:16 --> Controller Class Initialized
INFO - 2025-05-15 15:16:16 --> Model "Workout_model" initialized
INFO - 2025-05-15 15:16:16 --> Model "User_model" initialized
INFO - 2025-05-15 15:16:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 15:16:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 15:16:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-15 15:16:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 15:16:16 --> Final output sent to browser
DEBUG - 2025-05-15 15:16:16 --> Total execution time: 0.0818
INFO - 2025-05-15 15:20:47 --> Config Class Initialized
INFO - 2025-05-15 15:20:47 --> Hooks Class Initialized
DEBUG - 2025-05-15 15:20:47 --> UTF-8 Support Enabled
INFO - 2025-05-15 15:20:47 --> Utf8 Class Initialized
INFO - 2025-05-15 15:20:47 --> URI Class Initialized
INFO - 2025-05-15 15:20:47 --> Router Class Initialized
INFO - 2025-05-15 15:20:47 --> Output Class Initialized
INFO - 2025-05-15 15:20:47 --> Security Class Initialized
DEBUG - 2025-05-15 15:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 15:20:47 --> Input Class Initialized
INFO - 2025-05-15 15:20:47 --> Language Class Initialized
INFO - 2025-05-15 15:20:47 --> Loader Class Initialized
INFO - 2025-05-15 15:20:47 --> Helper loaded: url_helper
INFO - 2025-05-15 15:20:47 --> Helper loaded: form_helper
INFO - 2025-05-15 15:20:47 --> Database Driver Class Initialized
DEBUG - 2025-05-15 15:20:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 15:20:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 15:20:47 --> Controller Class Initialized
INFO - 2025-05-15 15:20:47 --> Model "User_model" initialized
INFO - 2025-05-15 15:20:47 --> Model "Workout_model" initialized
INFO - 2025-05-15 15:20:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 15:20:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 15:20:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-15 15:20:47 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 15:20:47 --> Final output sent to browser
DEBUG - 2025-05-15 15:20:47 --> Total execution time: 0.0685
INFO - 2025-05-15 15:21:57 --> Config Class Initialized
INFO - 2025-05-15 15:21:57 --> Hooks Class Initialized
DEBUG - 2025-05-15 15:21:57 --> UTF-8 Support Enabled
INFO - 2025-05-15 15:21:57 --> Utf8 Class Initialized
INFO - 2025-05-15 15:21:57 --> URI Class Initialized
INFO - 2025-05-15 15:21:57 --> Router Class Initialized
INFO - 2025-05-15 15:21:57 --> Output Class Initialized
INFO - 2025-05-15 15:21:57 --> Security Class Initialized
DEBUG - 2025-05-15 15:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 15:21:57 --> Input Class Initialized
INFO - 2025-05-15 15:21:57 --> Language Class Initialized
INFO - 2025-05-15 15:21:57 --> Loader Class Initialized
INFO - 2025-05-15 15:21:57 --> Helper loaded: url_helper
INFO - 2025-05-15 15:21:57 --> Helper loaded: form_helper
INFO - 2025-05-15 15:21:57 --> Database Driver Class Initialized
DEBUG - 2025-05-15 15:21:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 15:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 15:21:57 --> Controller Class Initialized
INFO - 2025-05-15 15:21:57 --> Model "User_model" initialized
INFO - 2025-05-15 15:21:57 --> Model "Workout_model" initialized
INFO - 2025-05-15 15:21:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 15:21:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 15:21:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-15 15:21:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 15:21:57 --> Final output sent to browser
DEBUG - 2025-05-15 15:21:57 --> Total execution time: 0.0791
INFO - 2025-05-15 15:21:58 --> Config Class Initialized
INFO - 2025-05-15 15:21:58 --> Hooks Class Initialized
DEBUG - 2025-05-15 15:21:58 --> UTF-8 Support Enabled
INFO - 2025-05-15 15:21:58 --> Utf8 Class Initialized
INFO - 2025-05-15 15:21:58 --> URI Class Initialized
INFO - 2025-05-15 15:21:58 --> Router Class Initialized
INFO - 2025-05-15 15:21:58 --> Output Class Initialized
INFO - 2025-05-15 15:21:58 --> Security Class Initialized
DEBUG - 2025-05-15 15:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 15:21:58 --> Input Class Initialized
INFO - 2025-05-15 15:21:58 --> Language Class Initialized
ERROR - 2025-05-15 15:21:58 --> 404 Page Not Found: Workout/olahraga
INFO - 2025-05-15 15:34:50 --> Config Class Initialized
INFO - 2025-05-15 15:34:50 --> Hooks Class Initialized
DEBUG - 2025-05-15 15:34:50 --> UTF-8 Support Enabled
INFO - 2025-05-15 15:34:50 --> Utf8 Class Initialized
INFO - 2025-05-15 15:34:50 --> URI Class Initialized
INFO - 2025-05-15 15:34:50 --> Router Class Initialized
INFO - 2025-05-15 15:34:50 --> Output Class Initialized
INFO - 2025-05-15 15:34:50 --> Security Class Initialized
DEBUG - 2025-05-15 15:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 15:34:50 --> Input Class Initialized
INFO - 2025-05-15 15:34:50 --> Language Class Initialized
INFO - 2025-05-15 15:34:50 --> Loader Class Initialized
INFO - 2025-05-15 15:34:50 --> Helper loaded: url_helper
INFO - 2025-05-15 15:34:50 --> Helper loaded: form_helper
INFO - 2025-05-15 15:34:50 --> Database Driver Class Initialized
DEBUG - 2025-05-15 15:34:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 15:34:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 15:34:50 --> Controller Class Initialized
INFO - 2025-05-15 15:34:50 --> Model "Workout_model" initialized
INFO - 2025-05-15 15:34:50 --> Model "User_model" initialized
ERROR - 2025-05-15 15:34:50 --> Severity: Warning --> Undefined variable $user C:\laragon\www\Project\fitnessrecord\application\views\dashboard\layout\header.php 40
ERROR - 2025-05-15 15:34:50 --> Severity: Warning --> Attempt to read property "name" on null C:\laragon\www\Project\fitnessrecord\application\views\dashboard\layout\header.php 40
INFO - 2025-05-15 15:34:50 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
ERROR - 2025-05-15 15:34:50 --> Severity: Warning --> Undefined variable $user C:\laragon\www\Project\fitnessrecord\application\views\dashboard\layout\sidebar.php 69
ERROR - 2025-05-15 15:34:50 --> Severity: Warning --> Attempt to read property "name" on null C:\laragon\www\Project\fitnessrecord\application\views\dashboard\layout\sidebar.php 69
INFO - 2025-05-15 15:34:50 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 15:34:50 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga.php
INFO - 2025-05-15 15:34:50 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 15:34:50 --> Final output sent to browser
DEBUG - 2025-05-15 15:34:50 --> Total execution time: 0.0884
INFO - 2025-05-15 15:35:34 --> Config Class Initialized
INFO - 2025-05-15 15:35:34 --> Hooks Class Initialized
DEBUG - 2025-05-15 15:35:34 --> UTF-8 Support Enabled
INFO - 2025-05-15 15:35:34 --> Utf8 Class Initialized
INFO - 2025-05-15 15:35:34 --> URI Class Initialized
INFO - 2025-05-15 15:35:34 --> Router Class Initialized
INFO - 2025-05-15 15:35:34 --> Output Class Initialized
INFO - 2025-05-15 15:35:34 --> Security Class Initialized
DEBUG - 2025-05-15 15:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 15:35:34 --> Input Class Initialized
INFO - 2025-05-15 15:35:34 --> Language Class Initialized
INFO - 2025-05-15 15:35:34 --> Loader Class Initialized
INFO - 2025-05-15 15:35:34 --> Helper loaded: url_helper
INFO - 2025-05-15 15:35:34 --> Helper loaded: form_helper
INFO - 2025-05-15 15:35:34 --> Database Driver Class Initialized
DEBUG - 2025-05-15 15:35:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 15:35:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 15:35:34 --> Controller Class Initialized
INFO - 2025-05-15 15:35:34 --> Model "Workout_model" initialized
INFO - 2025-05-15 15:35:34 --> Model "User_model" initialized
INFO - 2025-05-15 15:35:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 15:35:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 15:35:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga.php
INFO - 2025-05-15 15:35:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 15:35:34 --> Final output sent to browser
DEBUG - 2025-05-15 15:35:34 --> Total execution time: 0.0669
INFO - 2025-05-15 15:36:44 --> Config Class Initialized
INFO - 2025-05-15 15:36:44 --> Hooks Class Initialized
DEBUG - 2025-05-15 15:36:44 --> UTF-8 Support Enabled
INFO - 2025-05-15 15:36:44 --> Utf8 Class Initialized
INFO - 2025-05-15 15:36:44 --> URI Class Initialized
INFO - 2025-05-15 15:36:44 --> Router Class Initialized
INFO - 2025-05-15 15:36:44 --> Output Class Initialized
INFO - 2025-05-15 15:36:44 --> Security Class Initialized
DEBUG - 2025-05-15 15:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 15:36:44 --> Input Class Initialized
INFO - 2025-05-15 15:36:44 --> Language Class Initialized
INFO - 2025-05-15 15:36:44 --> Loader Class Initialized
INFO - 2025-05-15 15:36:44 --> Helper loaded: url_helper
INFO - 2025-05-15 15:36:44 --> Helper loaded: form_helper
INFO - 2025-05-15 15:36:44 --> Database Driver Class Initialized
DEBUG - 2025-05-15 15:36:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 15:36:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 15:36:44 --> Controller Class Initialized
INFO - 2025-05-15 15:36:44 --> Model "Workout_model" initialized
INFO - 2025-05-15 15:36:44 --> Model "User_model" initialized
INFO - 2025-05-15 15:36:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 15:36:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 15:36:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga.php
INFO - 2025-05-15 15:36:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 15:36:44 --> Final output sent to browser
DEBUG - 2025-05-15 15:36:44 --> Total execution time: 0.0693
INFO - 2025-05-15 15:37:33 --> Config Class Initialized
INFO - 2025-05-15 15:37:33 --> Hooks Class Initialized
DEBUG - 2025-05-15 15:37:33 --> UTF-8 Support Enabled
INFO - 2025-05-15 15:37:33 --> Utf8 Class Initialized
INFO - 2025-05-15 15:37:33 --> URI Class Initialized
INFO - 2025-05-15 15:37:33 --> Router Class Initialized
INFO - 2025-05-15 15:37:33 --> Output Class Initialized
INFO - 2025-05-15 15:37:33 --> Security Class Initialized
DEBUG - 2025-05-15 15:37:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 15:37:33 --> Input Class Initialized
INFO - 2025-05-15 15:37:33 --> Language Class Initialized
INFO - 2025-05-15 15:37:33 --> Loader Class Initialized
INFO - 2025-05-15 15:37:33 --> Helper loaded: url_helper
INFO - 2025-05-15 15:37:33 --> Helper loaded: form_helper
INFO - 2025-05-15 15:37:33 --> Database Driver Class Initialized
DEBUG - 2025-05-15 15:37:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 15:37:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 15:37:33 --> Controller Class Initialized
INFO - 2025-05-15 15:37:33 --> Model "Workout_model" initialized
INFO - 2025-05-15 15:37:33 --> Model "User_model" initialized
INFO - 2025-05-15 15:37:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 15:37:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 15:37:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga.php
INFO - 2025-05-15 15:37:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 15:37:33 --> Final output sent to browser
DEBUG - 2025-05-15 15:37:33 --> Total execution time: 0.0832
INFO - 2025-05-15 15:39:32 --> Config Class Initialized
INFO - 2025-05-15 15:39:32 --> Hooks Class Initialized
DEBUG - 2025-05-15 15:39:32 --> UTF-8 Support Enabled
INFO - 2025-05-15 15:39:32 --> Utf8 Class Initialized
INFO - 2025-05-15 15:39:32 --> URI Class Initialized
INFO - 2025-05-15 15:39:32 --> Router Class Initialized
INFO - 2025-05-15 15:39:32 --> Output Class Initialized
INFO - 2025-05-15 15:39:32 --> Security Class Initialized
DEBUG - 2025-05-15 15:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 15:39:32 --> Input Class Initialized
INFO - 2025-05-15 15:39:32 --> Language Class Initialized
INFO - 2025-05-15 15:39:32 --> Loader Class Initialized
INFO - 2025-05-15 15:39:32 --> Helper loaded: url_helper
INFO - 2025-05-15 15:39:32 --> Helper loaded: form_helper
INFO - 2025-05-15 15:39:32 --> Database Driver Class Initialized
DEBUG - 2025-05-15 15:39:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 15:39:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 15:39:32 --> Controller Class Initialized
INFO - 2025-05-15 15:39:32 --> Model "Workout_model" initialized
INFO - 2025-05-15 15:39:32 --> Model "User_model" initialized
INFO - 2025-05-15 15:39:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 15:39:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 15:39:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga.php
INFO - 2025-05-15 15:39:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 15:39:32 --> Final output sent to browser
DEBUG - 2025-05-15 15:39:32 --> Total execution time: 0.0837
INFO - 2025-05-15 15:43:28 --> Config Class Initialized
INFO - 2025-05-15 15:43:28 --> Hooks Class Initialized
DEBUG - 2025-05-15 15:43:28 --> UTF-8 Support Enabled
INFO - 2025-05-15 15:43:28 --> Utf8 Class Initialized
INFO - 2025-05-15 15:43:28 --> URI Class Initialized
INFO - 2025-05-15 15:43:28 --> Router Class Initialized
INFO - 2025-05-15 15:43:28 --> Output Class Initialized
INFO - 2025-05-15 15:43:28 --> Security Class Initialized
DEBUG - 2025-05-15 15:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 15:43:28 --> Input Class Initialized
INFO - 2025-05-15 15:43:28 --> Language Class Initialized
INFO - 2025-05-15 15:43:28 --> Loader Class Initialized
INFO - 2025-05-15 15:43:28 --> Helper loaded: url_helper
INFO - 2025-05-15 15:43:28 --> Helper loaded: form_helper
INFO - 2025-05-15 15:43:28 --> Database Driver Class Initialized
DEBUG - 2025-05-15 15:43:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 15:43:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 15:43:28 --> Controller Class Initialized
INFO - 2025-05-15 15:43:28 --> Model "Workout_model" initialized
INFO - 2025-05-15 15:43:28 --> Model "User_model" initialized
INFO - 2025-05-15 15:43:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 15:43:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 15:43:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga.php
INFO - 2025-05-15 15:43:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 15:43:28 --> Final output sent to browser
DEBUG - 2025-05-15 15:43:28 --> Total execution time: 0.1129
INFO - 2025-05-15 15:44:37 --> Config Class Initialized
INFO - 2025-05-15 15:44:37 --> Hooks Class Initialized
DEBUG - 2025-05-15 15:44:37 --> UTF-8 Support Enabled
INFO - 2025-05-15 15:44:37 --> Utf8 Class Initialized
INFO - 2025-05-15 15:44:37 --> URI Class Initialized
INFO - 2025-05-15 15:44:37 --> Router Class Initialized
INFO - 2025-05-15 15:44:37 --> Output Class Initialized
INFO - 2025-05-15 15:44:37 --> Security Class Initialized
DEBUG - 2025-05-15 15:44:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 15:44:37 --> Input Class Initialized
INFO - 2025-05-15 15:44:37 --> Language Class Initialized
INFO - 2025-05-15 15:44:37 --> Loader Class Initialized
INFO - 2025-05-15 15:44:37 --> Helper loaded: url_helper
INFO - 2025-05-15 15:44:37 --> Helper loaded: form_helper
INFO - 2025-05-15 15:44:37 --> Database Driver Class Initialized
DEBUG - 2025-05-15 15:44:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 15:44:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 15:44:37 --> Controller Class Initialized
INFO - 2025-05-15 15:44:37 --> Model "Workout_model" initialized
INFO - 2025-05-15 15:44:37 --> Model "User_model" initialized
INFO - 2025-05-15 15:44:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 15:44:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 15:44:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga.php
INFO - 2025-05-15 15:44:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 15:44:37 --> Final output sent to browser
DEBUG - 2025-05-15 15:44:37 --> Total execution time: 0.0662
INFO - 2025-05-15 15:48:49 --> Config Class Initialized
INFO - 2025-05-15 15:48:49 --> Hooks Class Initialized
DEBUG - 2025-05-15 15:48:49 --> UTF-8 Support Enabled
INFO - 2025-05-15 15:48:49 --> Utf8 Class Initialized
INFO - 2025-05-15 15:48:49 --> URI Class Initialized
INFO - 2025-05-15 15:48:49 --> Router Class Initialized
INFO - 2025-05-15 15:48:49 --> Output Class Initialized
INFO - 2025-05-15 15:48:49 --> Security Class Initialized
DEBUG - 2025-05-15 15:48:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 15:48:49 --> Input Class Initialized
INFO - 2025-05-15 15:48:49 --> Language Class Initialized
INFO - 2025-05-15 15:48:49 --> Loader Class Initialized
INFO - 2025-05-15 15:48:49 --> Helper loaded: url_helper
INFO - 2025-05-15 15:48:49 --> Helper loaded: form_helper
INFO - 2025-05-15 15:48:49 --> Database Driver Class Initialized
DEBUG - 2025-05-15 15:48:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 15:48:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 15:48:49 --> Controller Class Initialized
INFO - 2025-05-15 15:48:49 --> Model "Workout_model" initialized
INFO - 2025-05-15 15:48:49 --> Model "User_model" initialized
INFO - 2025-05-15 15:48:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 15:48:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 15:48:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga.php
INFO - 2025-05-15 15:48:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 15:48:49 --> Final output sent to browser
DEBUG - 2025-05-15 15:48:49 --> Total execution time: 0.0777
INFO - 2025-05-15 15:49:32 --> Config Class Initialized
INFO - 2025-05-15 15:49:32 --> Hooks Class Initialized
DEBUG - 2025-05-15 15:49:32 --> UTF-8 Support Enabled
INFO - 2025-05-15 15:49:32 --> Utf8 Class Initialized
INFO - 2025-05-15 15:49:32 --> URI Class Initialized
INFO - 2025-05-15 15:49:32 --> Router Class Initialized
INFO - 2025-05-15 15:49:32 --> Output Class Initialized
INFO - 2025-05-15 15:49:32 --> Security Class Initialized
DEBUG - 2025-05-15 15:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 15:49:32 --> Input Class Initialized
INFO - 2025-05-15 15:49:32 --> Language Class Initialized
INFO - 2025-05-15 15:49:32 --> Loader Class Initialized
INFO - 2025-05-15 15:49:32 --> Helper loaded: url_helper
INFO - 2025-05-15 15:49:32 --> Helper loaded: form_helper
INFO - 2025-05-15 15:49:32 --> Database Driver Class Initialized
DEBUG - 2025-05-15 15:49:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 15:49:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 15:49:32 --> Controller Class Initialized
INFO - 2025-05-15 15:49:32 --> Model "Workout_model" initialized
INFO - 2025-05-15 15:49:32 --> Model "User_model" initialized
INFO - 2025-05-15 15:49:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 15:49:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 15:49:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga.php
INFO - 2025-05-15 15:49:32 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 15:49:32 --> Final output sent to browser
DEBUG - 2025-05-15 15:49:32 --> Total execution time: 0.0714
INFO - 2025-05-15 15:50:09 --> Config Class Initialized
INFO - 2025-05-15 15:50:09 --> Hooks Class Initialized
DEBUG - 2025-05-15 15:50:09 --> UTF-8 Support Enabled
INFO - 2025-05-15 15:50:09 --> Utf8 Class Initialized
INFO - 2025-05-15 15:50:09 --> URI Class Initialized
INFO - 2025-05-15 15:50:09 --> Router Class Initialized
INFO - 2025-05-15 15:50:09 --> Output Class Initialized
INFO - 2025-05-15 15:50:09 --> Security Class Initialized
DEBUG - 2025-05-15 15:50:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 15:50:09 --> Input Class Initialized
INFO - 2025-05-15 15:50:09 --> Language Class Initialized
INFO - 2025-05-15 15:50:09 --> Loader Class Initialized
INFO - 2025-05-15 15:50:09 --> Helper loaded: url_helper
INFO - 2025-05-15 15:50:09 --> Helper loaded: form_helper
INFO - 2025-05-15 15:50:09 --> Database Driver Class Initialized
DEBUG - 2025-05-15 15:50:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 15:50:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 15:50:09 --> Controller Class Initialized
INFO - 2025-05-15 15:50:09 --> Model "Workout_model" initialized
INFO - 2025-05-15 15:50:09 --> Model "User_model" initialized
INFO - 2025-05-15 15:50:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 15:50:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 15:50:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga.php
INFO - 2025-05-15 15:50:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 15:50:09 --> Final output sent to browser
DEBUG - 2025-05-15 15:50:09 --> Total execution time: 0.0624
INFO - 2025-05-15 15:53:53 --> Config Class Initialized
INFO - 2025-05-15 15:53:53 --> Hooks Class Initialized
DEBUG - 2025-05-15 15:53:53 --> UTF-8 Support Enabled
INFO - 2025-05-15 15:53:53 --> Utf8 Class Initialized
INFO - 2025-05-15 15:53:53 --> URI Class Initialized
INFO - 2025-05-15 15:53:53 --> Router Class Initialized
INFO - 2025-05-15 15:53:53 --> Output Class Initialized
INFO - 2025-05-15 15:53:53 --> Security Class Initialized
DEBUG - 2025-05-15 15:53:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 15:53:53 --> Input Class Initialized
INFO - 2025-05-15 15:53:53 --> Language Class Initialized
INFO - 2025-05-15 15:53:53 --> Loader Class Initialized
INFO - 2025-05-15 15:53:53 --> Helper loaded: url_helper
INFO - 2025-05-15 15:53:53 --> Helper loaded: form_helper
INFO - 2025-05-15 15:53:53 --> Database Driver Class Initialized
DEBUG - 2025-05-15 15:53:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 15:53:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 15:53:53 --> Controller Class Initialized
INFO - 2025-05-15 15:53:53 --> Model "Workout_model" initialized
INFO - 2025-05-15 15:53:53 --> Model "User_model" initialized
INFO - 2025-05-15 15:53:53 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 15:53:53 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 15:53:53 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga.php
INFO - 2025-05-15 15:53:53 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 15:53:53 --> Final output sent to browser
DEBUG - 2025-05-15 15:53:53 --> Total execution time: 0.0801
INFO - 2025-05-15 15:57:05 --> Config Class Initialized
INFO - 2025-05-15 15:57:05 --> Hooks Class Initialized
DEBUG - 2025-05-15 15:57:05 --> UTF-8 Support Enabled
INFO - 2025-05-15 15:57:05 --> Utf8 Class Initialized
INFO - 2025-05-15 15:57:05 --> URI Class Initialized
INFO - 2025-05-15 15:57:05 --> Router Class Initialized
INFO - 2025-05-15 15:57:05 --> Output Class Initialized
INFO - 2025-05-15 15:57:05 --> Security Class Initialized
DEBUG - 2025-05-15 15:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 15:57:05 --> Input Class Initialized
INFO - 2025-05-15 15:57:05 --> Language Class Initialized
INFO - 2025-05-15 15:57:05 --> Loader Class Initialized
INFO - 2025-05-15 15:57:05 --> Helper loaded: url_helper
INFO - 2025-05-15 15:57:05 --> Helper loaded: form_helper
INFO - 2025-05-15 15:57:05 --> Database Driver Class Initialized
DEBUG - 2025-05-15 15:57:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 15:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 15:57:05 --> Controller Class Initialized
INFO - 2025-05-15 15:57:05 --> Model "Workout_model" initialized
INFO - 2025-05-15 15:57:05 --> Model "User_model" initialized
INFO - 2025-05-15 15:57:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 15:57:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 15:57:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga.php
INFO - 2025-05-15 15:57:05 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 15:57:05 --> Final output sent to browser
DEBUG - 2025-05-15 15:57:05 --> Total execution time: 0.0675
INFO - 2025-05-15 15:57:39 --> Config Class Initialized
INFO - 2025-05-15 15:57:39 --> Hooks Class Initialized
DEBUG - 2025-05-15 15:57:39 --> UTF-8 Support Enabled
INFO - 2025-05-15 15:57:39 --> Utf8 Class Initialized
INFO - 2025-05-15 15:57:39 --> URI Class Initialized
INFO - 2025-05-15 15:57:39 --> Router Class Initialized
INFO - 2025-05-15 15:57:39 --> Output Class Initialized
INFO - 2025-05-15 15:57:39 --> Security Class Initialized
DEBUG - 2025-05-15 15:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 15:57:39 --> Input Class Initialized
INFO - 2025-05-15 15:57:39 --> Language Class Initialized
INFO - 2025-05-15 15:57:39 --> Loader Class Initialized
INFO - 2025-05-15 15:57:39 --> Helper loaded: url_helper
INFO - 2025-05-15 15:57:39 --> Helper loaded: form_helper
INFO - 2025-05-15 15:57:39 --> Database Driver Class Initialized
DEBUG - 2025-05-15 15:57:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 15:57:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 15:57:39 --> Controller Class Initialized
INFO - 2025-05-15 15:57:39 --> Model "Workout_model" initialized
INFO - 2025-05-15 15:57:39 --> Model "User_model" initialized
INFO - 2025-05-15 15:57:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 15:57:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 15:57:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga.php
INFO - 2025-05-15 15:57:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 15:57:39 --> Final output sent to browser
DEBUG - 2025-05-15 15:57:39 --> Total execution time: 0.0800
INFO - 2025-05-15 16:03:17 --> Config Class Initialized
INFO - 2025-05-15 16:03:17 --> Hooks Class Initialized
DEBUG - 2025-05-15 16:03:17 --> UTF-8 Support Enabled
INFO - 2025-05-15 16:03:17 --> Utf8 Class Initialized
INFO - 2025-05-15 16:03:17 --> URI Class Initialized
INFO - 2025-05-15 16:03:17 --> Router Class Initialized
INFO - 2025-05-15 16:03:17 --> Output Class Initialized
INFO - 2025-05-15 16:03:17 --> Security Class Initialized
DEBUG - 2025-05-15 16:03:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 16:03:17 --> Input Class Initialized
INFO - 2025-05-15 16:03:17 --> Language Class Initialized
INFO - 2025-05-15 16:03:17 --> Loader Class Initialized
INFO - 2025-05-15 16:03:17 --> Helper loaded: url_helper
INFO - 2025-05-15 16:03:17 --> Helper loaded: form_helper
INFO - 2025-05-15 16:03:17 --> Database Driver Class Initialized
DEBUG - 2025-05-15 16:03:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 16:03:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 16:03:17 --> Controller Class Initialized
INFO - 2025-05-15 16:03:17 --> Model "Workout_model" initialized
INFO - 2025-05-15 16:03:17 --> Model "User_model" initialized
INFO - 2025-05-15 16:03:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 16:03:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 16:03:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga.php
INFO - 2025-05-15 16:03:17 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 16:03:17 --> Final output sent to browser
DEBUG - 2025-05-15 16:03:17 --> Total execution time: 0.0894
INFO - 2025-05-15 16:03:30 --> Config Class Initialized
INFO - 2025-05-15 16:03:30 --> Hooks Class Initialized
DEBUG - 2025-05-15 16:03:30 --> UTF-8 Support Enabled
INFO - 2025-05-15 16:03:30 --> Utf8 Class Initialized
INFO - 2025-05-15 16:03:30 --> URI Class Initialized
INFO - 2025-05-15 16:03:30 --> Router Class Initialized
INFO - 2025-05-15 16:03:30 --> Output Class Initialized
INFO - 2025-05-15 16:03:30 --> Security Class Initialized
DEBUG - 2025-05-15 16:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 16:03:30 --> Input Class Initialized
INFO - 2025-05-15 16:03:30 --> Language Class Initialized
INFO - 2025-05-15 16:03:30 --> Loader Class Initialized
INFO - 2025-05-15 16:03:30 --> Helper loaded: url_helper
INFO - 2025-05-15 16:03:30 --> Helper loaded: form_helper
INFO - 2025-05-15 16:03:30 --> Database Driver Class Initialized
DEBUG - 2025-05-15 16:03:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 16:03:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 16:03:30 --> Controller Class Initialized
INFO - 2025-05-15 16:03:30 --> Model "Workout_model" initialized
INFO - 2025-05-15 16:03:30 --> Model "User_model" initialized
INFO - 2025-05-15 16:03:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 16:03:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 16:03:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga.php
INFO - 2025-05-15 16:03:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 16:03:30 --> Final output sent to browser
DEBUG - 2025-05-15 16:03:30 --> Total execution time: 0.0620
INFO - 2025-05-15 16:04:46 --> Config Class Initialized
INFO - 2025-05-15 16:04:46 --> Hooks Class Initialized
DEBUG - 2025-05-15 16:04:46 --> UTF-8 Support Enabled
INFO - 2025-05-15 16:04:46 --> Utf8 Class Initialized
INFO - 2025-05-15 16:04:46 --> URI Class Initialized
INFO - 2025-05-15 16:04:46 --> Router Class Initialized
INFO - 2025-05-15 16:04:46 --> Output Class Initialized
INFO - 2025-05-15 16:04:46 --> Security Class Initialized
DEBUG - 2025-05-15 16:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 16:04:46 --> Input Class Initialized
INFO - 2025-05-15 16:04:46 --> Language Class Initialized
INFO - 2025-05-15 16:04:46 --> Loader Class Initialized
INFO - 2025-05-15 16:04:46 --> Helper loaded: url_helper
INFO - 2025-05-15 16:04:46 --> Helper loaded: form_helper
INFO - 2025-05-15 16:04:46 --> Database Driver Class Initialized
DEBUG - 2025-05-15 16:04:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 16:04:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 16:04:46 --> Controller Class Initialized
INFO - 2025-05-15 16:04:46 --> Model "Workout_model" initialized
INFO - 2025-05-15 16:04:46 --> Model "User_model" initialized
INFO - 2025-05-15 16:04:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 16:04:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 16:04:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga.php
INFO - 2025-05-15 16:04:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 16:04:46 --> Final output sent to browser
DEBUG - 2025-05-15 16:04:46 --> Total execution time: 0.0750
INFO - 2025-05-15 16:15:26 --> Config Class Initialized
INFO - 2025-05-15 16:15:26 --> Hooks Class Initialized
DEBUG - 2025-05-15 16:15:26 --> UTF-8 Support Enabled
INFO - 2025-05-15 16:15:26 --> Utf8 Class Initialized
INFO - 2025-05-15 16:15:26 --> URI Class Initialized
INFO - 2025-05-15 16:15:26 --> Router Class Initialized
INFO - 2025-05-15 16:15:26 --> Output Class Initialized
INFO - 2025-05-15 16:15:26 --> Security Class Initialized
DEBUG - 2025-05-15 16:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 16:15:26 --> Input Class Initialized
INFO - 2025-05-15 16:15:26 --> Language Class Initialized
INFO - 2025-05-15 16:15:26 --> Loader Class Initialized
INFO - 2025-05-15 16:15:26 --> Helper loaded: url_helper
INFO - 2025-05-15 16:15:26 --> Helper loaded: form_helper
INFO - 2025-05-15 16:15:26 --> Database Driver Class Initialized
DEBUG - 2025-05-15 16:15:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 16:15:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 16:15:26 --> Controller Class Initialized
INFO - 2025-05-15 16:15:26 --> Model "Workout_model" initialized
INFO - 2025-05-15 16:15:26 --> Model "User_model" initialized
INFO - 2025-05-15 16:15:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 16:15:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 16:15:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga.php
INFO - 2025-05-15 16:15:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 16:15:26 --> Final output sent to browser
DEBUG - 2025-05-15 16:15:26 --> Total execution time: 0.0808
INFO - 2025-05-15 16:16:07 --> Config Class Initialized
INFO - 2025-05-15 16:16:07 --> Hooks Class Initialized
DEBUG - 2025-05-15 16:16:07 --> UTF-8 Support Enabled
INFO - 2025-05-15 16:16:07 --> Utf8 Class Initialized
INFO - 2025-05-15 16:16:07 --> URI Class Initialized
INFO - 2025-05-15 16:16:07 --> Router Class Initialized
INFO - 2025-05-15 16:16:07 --> Output Class Initialized
INFO - 2025-05-15 16:16:07 --> Security Class Initialized
DEBUG - 2025-05-15 16:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 16:16:07 --> Input Class Initialized
INFO - 2025-05-15 16:16:07 --> Language Class Initialized
INFO - 2025-05-15 16:16:07 --> Loader Class Initialized
INFO - 2025-05-15 16:16:07 --> Helper loaded: url_helper
INFO - 2025-05-15 16:16:07 --> Helper loaded: form_helper
INFO - 2025-05-15 16:16:07 --> Database Driver Class Initialized
DEBUG - 2025-05-15 16:16:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 16:16:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 16:16:07 --> Controller Class Initialized
INFO - 2025-05-15 16:16:07 --> Model "Workout_model" initialized
INFO - 2025-05-15 16:16:07 --> Model "User_model" initialized
INFO - 2025-05-15 16:16:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 16:16:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 16:16:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga.php
INFO - 2025-05-15 16:16:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 16:16:07 --> Final output sent to browser
DEBUG - 2025-05-15 16:16:07 --> Total execution time: 0.0762
INFO - 2025-05-15 16:16:09 --> Config Class Initialized
INFO - 2025-05-15 16:16:09 --> Hooks Class Initialized
DEBUG - 2025-05-15 16:16:09 --> UTF-8 Support Enabled
INFO - 2025-05-15 16:16:09 --> Utf8 Class Initialized
INFO - 2025-05-15 16:16:09 --> URI Class Initialized
INFO - 2025-05-15 16:16:09 --> Router Class Initialized
INFO - 2025-05-15 16:16:09 --> Output Class Initialized
INFO - 2025-05-15 16:16:09 --> Security Class Initialized
DEBUG - 2025-05-15 16:16:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 16:16:09 --> Input Class Initialized
INFO - 2025-05-15 16:16:09 --> Language Class Initialized
INFO - 2025-05-15 16:16:09 --> Loader Class Initialized
INFO - 2025-05-15 16:16:09 --> Helper loaded: url_helper
INFO - 2025-05-15 16:16:09 --> Helper loaded: form_helper
INFO - 2025-05-15 16:16:09 --> Database Driver Class Initialized
DEBUG - 2025-05-15 16:16:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 16:16:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 16:16:09 --> Controller Class Initialized
INFO - 2025-05-15 16:16:09 --> Model "Workout_model" initialized
INFO - 2025-05-15 16:16:09 --> Model "User_model" initialized
INFO - 2025-05-15 16:16:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 16:16:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 16:16:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga.php
INFO - 2025-05-15 16:16:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 16:16:09 --> Final output sent to browser
DEBUG - 2025-05-15 16:16:09 --> Total execution time: 0.0693
INFO - 2025-05-15 16:16:10 --> Config Class Initialized
INFO - 2025-05-15 16:16:10 --> Hooks Class Initialized
DEBUG - 2025-05-15 16:16:10 --> UTF-8 Support Enabled
INFO - 2025-05-15 16:16:10 --> Utf8 Class Initialized
INFO - 2025-05-15 16:16:10 --> URI Class Initialized
INFO - 2025-05-15 16:16:10 --> Router Class Initialized
INFO - 2025-05-15 16:16:10 --> Output Class Initialized
INFO - 2025-05-15 16:16:10 --> Security Class Initialized
DEBUG - 2025-05-15 16:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 16:16:10 --> Input Class Initialized
INFO - 2025-05-15 16:16:10 --> Language Class Initialized
INFO - 2025-05-15 16:16:10 --> Loader Class Initialized
INFO - 2025-05-15 16:16:10 --> Helper loaded: url_helper
INFO - 2025-05-15 16:16:10 --> Helper loaded: form_helper
INFO - 2025-05-15 16:16:10 --> Database Driver Class Initialized
DEBUG - 2025-05-15 16:16:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 16:16:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 16:16:10 --> Controller Class Initialized
INFO - 2025-05-15 16:16:10 --> Model "Workout_model" initialized
INFO - 2025-05-15 16:16:10 --> Model "User_model" initialized
INFO - 2025-05-15 16:16:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 16:16:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 16:16:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga.php
INFO - 2025-05-15 16:16:10 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 16:16:10 --> Final output sent to browser
DEBUG - 2025-05-15 16:16:10 --> Total execution time: 0.0557
INFO - 2025-05-15 16:16:30 --> Config Class Initialized
INFO - 2025-05-15 16:16:30 --> Hooks Class Initialized
DEBUG - 2025-05-15 16:16:30 --> UTF-8 Support Enabled
INFO - 2025-05-15 16:16:30 --> Utf8 Class Initialized
INFO - 2025-05-15 16:16:30 --> URI Class Initialized
INFO - 2025-05-15 16:16:30 --> Router Class Initialized
INFO - 2025-05-15 16:16:30 --> Output Class Initialized
INFO - 2025-05-15 16:16:30 --> Security Class Initialized
DEBUG - 2025-05-15 16:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 16:16:30 --> Input Class Initialized
INFO - 2025-05-15 16:16:30 --> Language Class Initialized
INFO - 2025-05-15 16:16:30 --> Loader Class Initialized
INFO - 2025-05-15 16:16:30 --> Helper loaded: url_helper
INFO - 2025-05-15 16:16:30 --> Helper loaded: form_helper
INFO - 2025-05-15 16:16:30 --> Database Driver Class Initialized
DEBUG - 2025-05-15 16:16:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 16:16:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 16:16:30 --> Controller Class Initialized
INFO - 2025-05-15 16:16:30 --> Model "Workout_model" initialized
INFO - 2025-05-15 16:16:30 --> Model "User_model" initialized
INFO - 2025-05-15 16:16:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 16:16:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 16:16:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga.php
INFO - 2025-05-15 16:16:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 16:16:30 --> Final output sent to browser
DEBUG - 2025-05-15 16:16:30 --> Total execution time: 0.0911
INFO - 2025-05-15 16:19:54 --> Config Class Initialized
INFO - 2025-05-15 16:19:54 --> Hooks Class Initialized
DEBUG - 2025-05-15 16:19:54 --> UTF-8 Support Enabled
INFO - 2025-05-15 16:19:54 --> Utf8 Class Initialized
INFO - 2025-05-15 16:19:54 --> URI Class Initialized
INFO - 2025-05-15 16:19:54 --> Router Class Initialized
INFO - 2025-05-15 16:19:54 --> Output Class Initialized
INFO - 2025-05-15 16:19:54 --> Security Class Initialized
DEBUG - 2025-05-15 16:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 16:19:54 --> Input Class Initialized
INFO - 2025-05-15 16:19:54 --> Language Class Initialized
INFO - 2025-05-15 16:19:54 --> Loader Class Initialized
INFO - 2025-05-15 16:19:54 --> Helper loaded: url_helper
INFO - 2025-05-15 16:19:54 --> Helper loaded: form_helper
INFO - 2025-05-15 16:19:54 --> Database Driver Class Initialized
DEBUG - 2025-05-15 16:19:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 16:19:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 16:19:54 --> Controller Class Initialized
INFO - 2025-05-15 16:19:54 --> Model "Workout_model" initialized
INFO - 2025-05-15 16:19:54 --> Model "User_model" initialized
INFO - 2025-05-15 16:19:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 16:19:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 16:19:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga.php
INFO - 2025-05-15 16:19:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 16:19:54 --> Final output sent to browser
DEBUG - 2025-05-15 16:19:54 --> Total execution time: 0.0658
INFO - 2025-05-15 16:21:21 --> Config Class Initialized
INFO - 2025-05-15 16:21:21 --> Hooks Class Initialized
DEBUG - 2025-05-15 16:21:21 --> UTF-8 Support Enabled
INFO - 2025-05-15 16:21:21 --> Utf8 Class Initialized
INFO - 2025-05-15 16:21:21 --> URI Class Initialized
INFO - 2025-05-15 16:21:21 --> Router Class Initialized
INFO - 2025-05-15 16:21:21 --> Output Class Initialized
INFO - 2025-05-15 16:21:21 --> Security Class Initialized
DEBUG - 2025-05-15 16:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 16:21:21 --> Input Class Initialized
INFO - 2025-05-15 16:21:21 --> Language Class Initialized
INFO - 2025-05-15 16:21:21 --> Loader Class Initialized
INFO - 2025-05-15 16:21:21 --> Helper loaded: url_helper
INFO - 2025-05-15 16:21:21 --> Helper loaded: form_helper
INFO - 2025-05-15 16:21:21 --> Database Driver Class Initialized
DEBUG - 2025-05-15 16:21:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 16:21:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 16:21:21 --> Controller Class Initialized
INFO - 2025-05-15 16:21:21 --> Model "Workout_model" initialized
INFO - 2025-05-15 16:21:21 --> Model "User_model" initialized
INFO - 2025-05-15 16:21:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 16:21:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 16:21:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga.php
INFO - 2025-05-15 16:21:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 16:21:21 --> Final output sent to browser
DEBUG - 2025-05-15 16:21:21 --> Total execution time: 0.0843
INFO - 2025-05-15 16:21:46 --> Config Class Initialized
INFO - 2025-05-15 16:21:46 --> Hooks Class Initialized
DEBUG - 2025-05-15 16:21:46 --> UTF-8 Support Enabled
INFO - 2025-05-15 16:21:46 --> Utf8 Class Initialized
INFO - 2025-05-15 16:21:46 --> URI Class Initialized
INFO - 2025-05-15 16:21:46 --> Router Class Initialized
INFO - 2025-05-15 16:21:46 --> Output Class Initialized
INFO - 2025-05-15 16:21:46 --> Security Class Initialized
DEBUG - 2025-05-15 16:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 16:21:46 --> Input Class Initialized
INFO - 2025-05-15 16:21:46 --> Language Class Initialized
INFO - 2025-05-15 16:21:46 --> Loader Class Initialized
INFO - 2025-05-15 16:21:46 --> Helper loaded: url_helper
INFO - 2025-05-15 16:21:46 --> Helper loaded: form_helper
INFO - 2025-05-15 16:21:46 --> Database Driver Class Initialized
DEBUG - 2025-05-15 16:21:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 16:21:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 16:21:46 --> Controller Class Initialized
INFO - 2025-05-15 16:21:46 --> Model "Workout_model" initialized
INFO - 2025-05-15 16:21:46 --> Model "User_model" initialized
INFO - 2025-05-15 16:21:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 16:21:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 16:21:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga.php
INFO - 2025-05-15 16:21:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 16:21:46 --> Final output sent to browser
DEBUG - 2025-05-15 16:21:46 --> Total execution time: 0.0818
INFO - 2025-05-15 16:22:26 --> Config Class Initialized
INFO - 2025-05-15 16:22:26 --> Hooks Class Initialized
DEBUG - 2025-05-15 16:22:26 --> UTF-8 Support Enabled
INFO - 2025-05-15 16:22:26 --> Utf8 Class Initialized
INFO - 2025-05-15 16:22:26 --> URI Class Initialized
INFO - 2025-05-15 16:22:26 --> Router Class Initialized
INFO - 2025-05-15 16:22:26 --> Output Class Initialized
INFO - 2025-05-15 16:22:26 --> Security Class Initialized
DEBUG - 2025-05-15 16:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 16:22:26 --> Input Class Initialized
INFO - 2025-05-15 16:22:26 --> Language Class Initialized
INFO - 2025-05-15 16:22:26 --> Loader Class Initialized
INFO - 2025-05-15 16:22:26 --> Helper loaded: url_helper
INFO - 2025-05-15 16:22:26 --> Helper loaded: form_helper
INFO - 2025-05-15 16:22:26 --> Database Driver Class Initialized
DEBUG - 2025-05-15 16:22:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 16:22:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 16:22:26 --> Controller Class Initialized
INFO - 2025-05-15 16:22:26 --> Model "Workout_model" initialized
INFO - 2025-05-15 16:22:26 --> Model "User_model" initialized
INFO - 2025-05-15 16:22:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 16:22:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 16:22:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga.php
INFO - 2025-05-15 16:22:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 16:22:26 --> Final output sent to browser
DEBUG - 2025-05-15 16:22:26 --> Total execution time: 0.0818
INFO - 2025-05-15 16:23:22 --> Config Class Initialized
INFO - 2025-05-15 16:23:22 --> Hooks Class Initialized
DEBUG - 2025-05-15 16:23:22 --> UTF-8 Support Enabled
INFO - 2025-05-15 16:23:22 --> Utf8 Class Initialized
INFO - 2025-05-15 16:23:22 --> URI Class Initialized
INFO - 2025-05-15 16:23:22 --> Router Class Initialized
INFO - 2025-05-15 16:23:22 --> Output Class Initialized
INFO - 2025-05-15 16:23:22 --> Security Class Initialized
DEBUG - 2025-05-15 16:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 16:23:22 --> Input Class Initialized
INFO - 2025-05-15 16:23:22 --> Language Class Initialized
INFO - 2025-05-15 16:23:22 --> Loader Class Initialized
INFO - 2025-05-15 16:23:22 --> Helper loaded: url_helper
INFO - 2025-05-15 16:23:22 --> Helper loaded: form_helper
INFO - 2025-05-15 16:23:22 --> Database Driver Class Initialized
DEBUG - 2025-05-15 16:23:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 16:23:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 16:23:22 --> Controller Class Initialized
INFO - 2025-05-15 16:23:22 --> Model "Workout_model" initialized
INFO - 2025-05-15 16:23:22 --> Model "User_model" initialized
INFO - 2025-05-15 16:23:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 16:23:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 16:23:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga.php
INFO - 2025-05-15 16:23:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 16:23:22 --> Final output sent to browser
DEBUG - 2025-05-15 16:23:22 --> Total execution time: 0.0708
INFO - 2025-05-15 16:24:21 --> Config Class Initialized
INFO - 2025-05-15 16:24:21 --> Hooks Class Initialized
DEBUG - 2025-05-15 16:24:21 --> UTF-8 Support Enabled
INFO - 2025-05-15 16:24:21 --> Utf8 Class Initialized
INFO - 2025-05-15 16:24:21 --> URI Class Initialized
INFO - 2025-05-15 16:24:21 --> Router Class Initialized
INFO - 2025-05-15 16:24:21 --> Output Class Initialized
INFO - 2025-05-15 16:24:21 --> Security Class Initialized
DEBUG - 2025-05-15 16:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 16:24:21 --> Input Class Initialized
INFO - 2025-05-15 16:24:21 --> Language Class Initialized
INFO - 2025-05-15 16:24:21 --> Loader Class Initialized
INFO - 2025-05-15 16:24:21 --> Helper loaded: url_helper
INFO - 2025-05-15 16:24:21 --> Helper loaded: form_helper
INFO - 2025-05-15 16:24:21 --> Database Driver Class Initialized
DEBUG - 2025-05-15 16:24:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 16:24:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 16:24:21 --> Controller Class Initialized
INFO - 2025-05-15 16:24:21 --> Model "Workout_model" initialized
INFO - 2025-05-15 16:24:21 --> Model "User_model" initialized
INFO - 2025-05-15 16:24:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 16:24:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 16:24:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga.php
INFO - 2025-05-15 16:24:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 16:24:21 --> Final output sent to browser
DEBUG - 2025-05-15 16:24:21 --> Total execution time: 0.0829
INFO - 2025-05-15 16:28:20 --> Config Class Initialized
INFO - 2025-05-15 16:28:20 --> Hooks Class Initialized
DEBUG - 2025-05-15 16:28:20 --> UTF-8 Support Enabled
INFO - 2025-05-15 16:28:20 --> Utf8 Class Initialized
INFO - 2025-05-15 16:28:20 --> URI Class Initialized
INFO - 2025-05-15 16:28:20 --> Router Class Initialized
INFO - 2025-05-15 16:28:20 --> Output Class Initialized
INFO - 2025-05-15 16:28:20 --> Security Class Initialized
DEBUG - 2025-05-15 16:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 16:28:20 --> Input Class Initialized
INFO - 2025-05-15 16:28:20 --> Language Class Initialized
INFO - 2025-05-15 16:28:20 --> Loader Class Initialized
INFO - 2025-05-15 16:28:20 --> Helper loaded: url_helper
INFO - 2025-05-15 16:28:20 --> Helper loaded: form_helper
INFO - 2025-05-15 16:28:20 --> Database Driver Class Initialized
DEBUG - 2025-05-15 16:28:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 16:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 16:28:20 --> Controller Class Initialized
INFO - 2025-05-15 16:28:20 --> Model "Workout_model" initialized
INFO - 2025-05-15 16:28:20 --> Model "User_model" initialized
INFO - 2025-05-15 16:28:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 16:28:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 16:28:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga.php
INFO - 2025-05-15 16:28:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 16:28:20 --> Final output sent to browser
DEBUG - 2025-05-15 16:28:20 --> Total execution time: 0.0805
INFO - 2025-05-15 16:30:31 --> Config Class Initialized
INFO - 2025-05-15 16:30:31 --> Hooks Class Initialized
DEBUG - 2025-05-15 16:30:31 --> UTF-8 Support Enabled
INFO - 2025-05-15 16:30:31 --> Utf8 Class Initialized
INFO - 2025-05-15 16:30:31 --> URI Class Initialized
INFO - 2025-05-15 16:30:31 --> Router Class Initialized
INFO - 2025-05-15 16:30:31 --> Output Class Initialized
INFO - 2025-05-15 16:30:31 --> Security Class Initialized
DEBUG - 2025-05-15 16:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 16:30:31 --> Input Class Initialized
INFO - 2025-05-15 16:30:31 --> Language Class Initialized
INFO - 2025-05-15 16:30:31 --> Loader Class Initialized
INFO - 2025-05-15 16:30:31 --> Helper loaded: url_helper
INFO - 2025-05-15 16:30:31 --> Helper loaded: form_helper
INFO - 2025-05-15 16:30:31 --> Database Driver Class Initialized
DEBUG - 2025-05-15 16:30:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 16:30:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 16:30:31 --> Controller Class Initialized
INFO - 2025-05-15 16:30:31 --> Model "Workout_model" initialized
INFO - 2025-05-15 16:30:31 --> Model "User_model" initialized
INFO - 2025-05-15 16:30:31 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 16:30:31 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 16:30:31 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga.php
INFO - 2025-05-15 16:30:31 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 16:30:31 --> Final output sent to browser
DEBUG - 2025-05-15 16:30:31 --> Total execution time: 0.0614
INFO - 2025-05-15 16:41:00 --> Config Class Initialized
INFO - 2025-05-15 16:41:00 --> Hooks Class Initialized
DEBUG - 2025-05-15 16:41:00 --> UTF-8 Support Enabled
INFO - 2025-05-15 16:41:00 --> Utf8 Class Initialized
INFO - 2025-05-15 16:41:00 --> URI Class Initialized
INFO - 2025-05-15 16:41:00 --> Router Class Initialized
INFO - 2025-05-15 16:41:00 --> Output Class Initialized
INFO - 2025-05-15 16:41:00 --> Security Class Initialized
DEBUG - 2025-05-15 16:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 16:41:00 --> Input Class Initialized
INFO - 2025-05-15 16:41:00 --> Language Class Initialized
INFO - 2025-05-15 16:41:00 --> Loader Class Initialized
INFO - 2025-05-15 16:41:00 --> Helper loaded: url_helper
INFO - 2025-05-15 16:41:00 --> Helper loaded: form_helper
INFO - 2025-05-15 16:41:00 --> Database Driver Class Initialized
DEBUG - 2025-05-15 16:41:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 16:41:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 16:41:00 --> Controller Class Initialized
INFO - 2025-05-15 16:41:00 --> Model "Workout_model" initialized
INFO - 2025-05-15 16:41:00 --> Model "User_model" initialized
INFO - 2025-05-15 16:41:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 16:41:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 16:41:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga.php
INFO - 2025-05-15 16:41:00 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 16:41:00 --> Final output sent to browser
DEBUG - 2025-05-15 16:41:00 --> Total execution time: 0.0845
INFO - 2025-05-15 16:44:55 --> Config Class Initialized
INFO - 2025-05-15 16:44:55 --> Hooks Class Initialized
DEBUG - 2025-05-15 16:44:55 --> UTF-8 Support Enabled
INFO - 2025-05-15 16:44:55 --> Utf8 Class Initialized
INFO - 2025-05-15 16:44:55 --> URI Class Initialized
INFO - 2025-05-15 16:44:55 --> Router Class Initialized
INFO - 2025-05-15 16:44:55 --> Output Class Initialized
INFO - 2025-05-15 16:44:55 --> Security Class Initialized
DEBUG - 2025-05-15 16:44:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 16:44:55 --> Input Class Initialized
INFO - 2025-05-15 16:44:55 --> Language Class Initialized
INFO - 2025-05-15 16:44:55 --> Loader Class Initialized
INFO - 2025-05-15 16:44:55 --> Helper loaded: url_helper
INFO - 2025-05-15 16:44:55 --> Helper loaded: form_helper
INFO - 2025-05-15 16:44:55 --> Database Driver Class Initialized
DEBUG - 2025-05-15 16:44:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 16:44:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 16:44:55 --> Controller Class Initialized
INFO - 2025-05-15 16:44:55 --> Model "Workout_model" initialized
INFO - 2025-05-15 16:44:55 --> Model "User_model" initialized
INFO - 2025-05-15 16:44:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 16:44:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 16:44:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga.php
INFO - 2025-05-15 16:44:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 16:44:55 --> Final output sent to browser
DEBUG - 2025-05-15 16:44:55 --> Total execution time: 0.0847
INFO - 2025-05-15 16:46:11 --> Config Class Initialized
INFO - 2025-05-15 16:46:11 --> Hooks Class Initialized
DEBUG - 2025-05-15 16:46:11 --> UTF-8 Support Enabled
INFO - 2025-05-15 16:46:11 --> Utf8 Class Initialized
INFO - 2025-05-15 16:46:11 --> URI Class Initialized
INFO - 2025-05-15 16:46:11 --> Router Class Initialized
INFO - 2025-05-15 16:46:11 --> Output Class Initialized
INFO - 2025-05-15 16:46:11 --> Security Class Initialized
DEBUG - 2025-05-15 16:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 16:46:11 --> Input Class Initialized
INFO - 2025-05-15 16:46:11 --> Language Class Initialized
INFO - 2025-05-15 16:46:11 --> Loader Class Initialized
INFO - 2025-05-15 16:46:11 --> Helper loaded: url_helper
INFO - 2025-05-15 16:46:11 --> Helper loaded: form_helper
INFO - 2025-05-15 16:46:11 --> Database Driver Class Initialized
DEBUG - 2025-05-15 16:46:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 16:46:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 16:46:11 --> Controller Class Initialized
INFO - 2025-05-15 16:46:11 --> Model "Workout_model" initialized
INFO - 2025-05-15 16:46:11 --> Model "User_model" initialized
INFO - 2025-05-15 16:46:11 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 16:46:11 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 16:46:11 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga.php
INFO - 2025-05-15 16:46:11 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 16:46:11 --> Final output sent to browser
DEBUG - 2025-05-15 16:46:11 --> Total execution time: 0.0972
INFO - 2025-05-15 16:46:14 --> Config Class Initialized
INFO - 2025-05-15 16:46:14 --> Hooks Class Initialized
DEBUG - 2025-05-15 16:46:14 --> UTF-8 Support Enabled
INFO - 2025-05-15 16:46:14 --> Utf8 Class Initialized
INFO - 2025-05-15 16:46:14 --> URI Class Initialized
INFO - 2025-05-15 16:46:14 --> Router Class Initialized
INFO - 2025-05-15 16:46:14 --> Output Class Initialized
INFO - 2025-05-15 16:46:14 --> Security Class Initialized
DEBUG - 2025-05-15 16:46:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 16:46:14 --> Input Class Initialized
INFO - 2025-05-15 16:46:14 --> Language Class Initialized
INFO - 2025-05-15 16:46:14 --> Loader Class Initialized
INFO - 2025-05-15 16:46:14 --> Helper loaded: url_helper
INFO - 2025-05-15 16:46:14 --> Helper loaded: form_helper
INFO - 2025-05-15 16:46:14 --> Database Driver Class Initialized
DEBUG - 2025-05-15 16:46:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 16:46:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 16:46:14 --> Controller Class Initialized
INFO - 2025-05-15 16:46:14 --> Model "User_model" initialized
INFO - 2025-05-15 16:46:14 --> Model "Workout_model" initialized
INFO - 2025-05-15 16:46:14 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 16:46:14 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 16:46:14 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-15 16:46:14 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 16:46:14 --> Final output sent to browser
DEBUG - 2025-05-15 16:46:14 --> Total execution time: 0.1037
INFO - 2025-05-15 16:46:15 --> Config Class Initialized
INFO - 2025-05-15 16:46:15 --> Hooks Class Initialized
DEBUG - 2025-05-15 16:46:15 --> UTF-8 Support Enabled
INFO - 2025-05-15 16:46:15 --> Utf8 Class Initialized
INFO - 2025-05-15 16:46:15 --> URI Class Initialized
INFO - 2025-05-15 16:46:15 --> Router Class Initialized
INFO - 2025-05-15 16:46:15 --> Output Class Initialized
INFO - 2025-05-15 16:46:15 --> Security Class Initialized
DEBUG - 2025-05-15 16:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 16:46:15 --> Input Class Initialized
INFO - 2025-05-15 16:46:15 --> Language Class Initialized
INFO - 2025-05-15 16:46:15 --> Loader Class Initialized
INFO - 2025-05-15 16:46:15 --> Helper loaded: url_helper
INFO - 2025-05-15 16:46:15 --> Helper loaded: form_helper
INFO - 2025-05-15 16:46:15 --> Database Driver Class Initialized
DEBUG - 2025-05-15 16:46:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 16:46:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 16:46:15 --> Controller Class Initialized
INFO - 2025-05-15 16:46:15 --> Model "Workout_model" initialized
INFO - 2025-05-15 16:46:15 --> Model "User_model" initialized
INFO - 2025-05-15 16:46:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 16:46:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 16:46:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-15 16:46:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 16:46:15 --> Final output sent to browser
DEBUG - 2025-05-15 16:46:15 --> Total execution time: 0.0674
INFO - 2025-05-15 16:46:37 --> Config Class Initialized
INFO - 2025-05-15 16:46:37 --> Hooks Class Initialized
DEBUG - 2025-05-15 16:46:37 --> UTF-8 Support Enabled
INFO - 2025-05-15 16:46:37 --> Utf8 Class Initialized
INFO - 2025-05-15 16:46:37 --> URI Class Initialized
INFO - 2025-05-15 16:46:37 --> Router Class Initialized
INFO - 2025-05-15 16:46:37 --> Output Class Initialized
INFO - 2025-05-15 16:46:37 --> Security Class Initialized
DEBUG - 2025-05-15 16:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 16:46:37 --> Input Class Initialized
INFO - 2025-05-15 16:46:37 --> Language Class Initialized
INFO - 2025-05-15 16:46:37 --> Loader Class Initialized
INFO - 2025-05-15 16:46:37 --> Helper loaded: url_helper
INFO - 2025-05-15 16:46:37 --> Helper loaded: form_helper
INFO - 2025-05-15 16:46:37 --> Database Driver Class Initialized
DEBUG - 2025-05-15 16:46:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 16:46:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 16:46:37 --> Controller Class Initialized
INFO - 2025-05-15 16:46:37 --> Model "User_model" initialized
INFO - 2025-05-15 16:46:37 --> Model "Community_model" initialized
INFO - 2025-05-15 16:46:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 16:46:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 16:46:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/community.php
INFO - 2025-05-15 16:46:37 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 16:46:37 --> Final output sent to browser
DEBUG - 2025-05-15 16:46:37 --> Total execution time: 0.1404
INFO - 2025-05-15 16:46:39 --> Config Class Initialized
INFO - 2025-05-15 16:46:39 --> Hooks Class Initialized
DEBUG - 2025-05-15 16:46:39 --> UTF-8 Support Enabled
INFO - 2025-05-15 16:46:39 --> Utf8 Class Initialized
INFO - 2025-05-15 16:46:39 --> URI Class Initialized
INFO - 2025-05-15 16:46:39 --> Router Class Initialized
INFO - 2025-05-15 16:46:39 --> Output Class Initialized
INFO - 2025-05-15 16:46:39 --> Security Class Initialized
DEBUG - 2025-05-15 16:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 16:46:39 --> Input Class Initialized
INFO - 2025-05-15 16:46:39 --> Language Class Initialized
INFO - 2025-05-15 16:46:39 --> Loader Class Initialized
INFO - 2025-05-15 16:46:39 --> Helper loaded: url_helper
INFO - 2025-05-15 16:46:39 --> Helper loaded: form_helper
INFO - 2025-05-15 16:46:39 --> Database Driver Class Initialized
DEBUG - 2025-05-15 16:46:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 16:46:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 16:46:39 --> Controller Class Initialized
INFO - 2025-05-15 16:46:39 --> Model "Workout_model" initialized
INFO - 2025-05-15 16:46:39 --> Model "User_model" initialized
INFO - 2025-05-15 16:46:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 16:46:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 16:46:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga.php
INFO - 2025-05-15 16:46:39 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 16:46:39 --> Final output sent to browser
DEBUG - 2025-05-15 16:46:39 --> Total execution time: 0.0734
INFO - 2025-05-15 16:46:40 --> Config Class Initialized
INFO - 2025-05-15 16:46:40 --> Hooks Class Initialized
DEBUG - 2025-05-15 16:46:40 --> UTF-8 Support Enabled
INFO - 2025-05-15 16:46:40 --> Utf8 Class Initialized
INFO - 2025-05-15 16:46:40 --> URI Class Initialized
INFO - 2025-05-15 16:46:40 --> Router Class Initialized
INFO - 2025-05-15 16:46:40 --> Output Class Initialized
INFO - 2025-05-15 16:46:40 --> Security Class Initialized
DEBUG - 2025-05-15 16:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 16:46:40 --> Input Class Initialized
INFO - 2025-05-15 16:46:40 --> Language Class Initialized
INFO - 2025-05-15 16:46:40 --> Loader Class Initialized
INFO - 2025-05-15 16:46:40 --> Helper loaded: url_helper
INFO - 2025-05-15 16:46:40 --> Helper loaded: form_helper
INFO - 2025-05-15 16:46:41 --> Database Driver Class Initialized
DEBUG - 2025-05-15 16:46:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 16:46:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 16:46:41 --> Controller Class Initialized
INFO - 2025-05-15 16:46:41 --> Model "Workout_model" initialized
INFO - 2025-05-15 16:46:41 --> Model "User_model" initialized
INFO - 2025-05-15 16:46:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 16:46:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 16:46:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga.php
INFO - 2025-05-15 16:46:41 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 16:46:41 --> Final output sent to browser
DEBUG - 2025-05-15 16:46:41 --> Total execution time: 0.0762
INFO - 2025-05-15 16:46:42 --> Config Class Initialized
INFO - 2025-05-15 16:46:42 --> Hooks Class Initialized
DEBUG - 2025-05-15 16:46:42 --> UTF-8 Support Enabled
INFO - 2025-05-15 16:46:42 --> Utf8 Class Initialized
INFO - 2025-05-15 16:46:42 --> URI Class Initialized
INFO - 2025-05-15 16:46:42 --> Router Class Initialized
INFO - 2025-05-15 16:46:42 --> Output Class Initialized
INFO - 2025-05-15 16:46:42 --> Security Class Initialized
DEBUG - 2025-05-15 16:46:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 16:46:42 --> Input Class Initialized
INFO - 2025-05-15 16:46:42 --> Language Class Initialized
INFO - 2025-05-15 16:46:42 --> Loader Class Initialized
INFO - 2025-05-15 16:46:42 --> Helper loaded: url_helper
INFO - 2025-05-15 16:46:42 --> Helper loaded: form_helper
INFO - 2025-05-15 16:46:42 --> Database Driver Class Initialized
DEBUG - 2025-05-15 16:46:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 16:46:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 16:46:42 --> Controller Class Initialized
INFO - 2025-05-15 16:46:42 --> Model "Workout_model" initialized
INFO - 2025-05-15 16:46:42 --> Model "User_model" initialized
INFO - 2025-05-15 16:46:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 16:46:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 16:46:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga.php
INFO - 2025-05-15 16:46:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 16:46:42 --> Final output sent to browser
DEBUG - 2025-05-15 16:46:42 --> Total execution time: 0.0664
INFO - 2025-05-15 16:46:42 --> Config Class Initialized
INFO - 2025-05-15 16:46:42 --> Hooks Class Initialized
DEBUG - 2025-05-15 16:46:42 --> UTF-8 Support Enabled
INFO - 2025-05-15 16:46:42 --> Utf8 Class Initialized
INFO - 2025-05-15 16:46:42 --> URI Class Initialized
INFO - 2025-05-15 16:46:42 --> Router Class Initialized
INFO - 2025-05-15 16:46:42 --> Output Class Initialized
INFO - 2025-05-15 16:46:42 --> Security Class Initialized
DEBUG - 2025-05-15 16:46:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 16:46:42 --> Input Class Initialized
INFO - 2025-05-15 16:46:42 --> Language Class Initialized
INFO - 2025-05-15 16:46:43 --> Loader Class Initialized
INFO - 2025-05-15 16:46:43 --> Helper loaded: url_helper
INFO - 2025-05-15 16:46:43 --> Helper loaded: form_helper
INFO - 2025-05-15 16:46:43 --> Database Driver Class Initialized
DEBUG - 2025-05-15 16:46:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 16:46:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 16:46:43 --> Controller Class Initialized
INFO - 2025-05-15 16:46:43 --> Model "Workout_model" initialized
INFO - 2025-05-15 16:46:43 --> Model "User_model" initialized
INFO - 2025-05-15 16:46:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 16:46:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 16:46:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-15 16:46:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 16:46:43 --> Final output sent to browser
DEBUG - 2025-05-15 16:46:43 --> Total execution time: 0.0704
INFO - 2025-05-15 16:46:44 --> Config Class Initialized
INFO - 2025-05-15 16:46:44 --> Hooks Class Initialized
DEBUG - 2025-05-15 16:46:44 --> UTF-8 Support Enabled
INFO - 2025-05-15 16:46:44 --> Utf8 Class Initialized
INFO - 2025-05-15 16:46:44 --> URI Class Initialized
INFO - 2025-05-15 16:46:44 --> Router Class Initialized
INFO - 2025-05-15 16:46:44 --> Output Class Initialized
INFO - 2025-05-15 16:46:44 --> Security Class Initialized
DEBUG - 2025-05-15 16:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 16:46:44 --> Input Class Initialized
INFO - 2025-05-15 16:46:44 --> Language Class Initialized
INFO - 2025-05-15 16:46:44 --> Loader Class Initialized
INFO - 2025-05-15 16:46:44 --> Helper loaded: url_helper
INFO - 2025-05-15 16:46:44 --> Helper loaded: form_helper
INFO - 2025-05-15 16:46:44 --> Database Driver Class Initialized
DEBUG - 2025-05-15 16:46:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 16:46:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 16:46:44 --> Controller Class Initialized
INFO - 2025-05-15 16:46:44 --> Model "User_model" initialized
INFO - 2025-05-15 16:46:44 --> Model "Workout_model" initialized
INFO - 2025-05-15 16:46:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 16:46:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 16:46:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-15 16:46:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 16:46:44 --> Final output sent to browser
DEBUG - 2025-05-15 16:46:44 --> Total execution time: 0.0685
INFO - 2025-05-15 16:46:45 --> Config Class Initialized
INFO - 2025-05-15 16:46:45 --> Hooks Class Initialized
DEBUG - 2025-05-15 16:46:45 --> UTF-8 Support Enabled
INFO - 2025-05-15 16:46:45 --> Utf8 Class Initialized
INFO - 2025-05-15 16:46:45 --> URI Class Initialized
INFO - 2025-05-15 16:46:45 --> Router Class Initialized
INFO - 2025-05-15 16:46:45 --> Output Class Initialized
INFO - 2025-05-15 16:46:45 --> Security Class Initialized
DEBUG - 2025-05-15 16:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 16:46:45 --> Input Class Initialized
INFO - 2025-05-15 16:46:45 --> Language Class Initialized
INFO - 2025-05-15 16:46:45 --> Loader Class Initialized
INFO - 2025-05-15 16:46:45 --> Helper loaded: url_helper
INFO - 2025-05-15 16:46:45 --> Helper loaded: form_helper
INFO - 2025-05-15 16:46:45 --> Database Driver Class Initialized
DEBUG - 2025-05-15 16:46:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 16:46:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 16:46:45 --> Controller Class Initialized
INFO - 2025-05-15 16:46:45 --> Model "Workout_model" initialized
INFO - 2025-05-15 16:46:45 --> Model "User_model" initialized
INFO - 2025-05-15 16:46:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 16:46:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 16:46:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga.php
INFO - 2025-05-15 16:46:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 16:46:45 --> Final output sent to browser
DEBUG - 2025-05-15 16:46:45 --> Total execution time: 0.0706
INFO - 2025-05-15 16:48:09 --> Config Class Initialized
INFO - 2025-05-15 16:48:09 --> Hooks Class Initialized
DEBUG - 2025-05-15 16:48:09 --> UTF-8 Support Enabled
INFO - 2025-05-15 16:48:09 --> Utf8 Class Initialized
INFO - 2025-05-15 16:48:09 --> URI Class Initialized
INFO - 2025-05-15 16:48:09 --> Router Class Initialized
INFO - 2025-05-15 16:48:09 --> Output Class Initialized
INFO - 2025-05-15 16:48:09 --> Security Class Initialized
DEBUG - 2025-05-15 16:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 16:48:09 --> Input Class Initialized
INFO - 2025-05-15 16:48:09 --> Language Class Initialized
INFO - 2025-05-15 16:48:09 --> Loader Class Initialized
INFO - 2025-05-15 16:48:09 --> Helper loaded: url_helper
INFO - 2025-05-15 16:48:09 --> Helper loaded: form_helper
INFO - 2025-05-15 16:48:09 --> Database Driver Class Initialized
DEBUG - 2025-05-15 16:48:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 16:48:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 16:48:09 --> Controller Class Initialized
INFO - 2025-05-15 16:48:09 --> Model "Workout_model" initialized
INFO - 2025-05-15 16:48:09 --> Model "User_model" initialized
INFO - 2025-05-15 16:48:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 16:48:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 16:48:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga.php
INFO - 2025-05-15 16:48:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 16:48:09 --> Final output sent to browser
DEBUG - 2025-05-15 16:48:09 --> Total execution time: 0.0798
INFO - 2025-05-15 16:48:11 --> Config Class Initialized
INFO - 2025-05-15 16:48:11 --> Hooks Class Initialized
DEBUG - 2025-05-15 16:48:11 --> UTF-8 Support Enabled
INFO - 2025-05-15 16:48:11 --> Utf8 Class Initialized
INFO - 2025-05-15 16:48:11 --> URI Class Initialized
INFO - 2025-05-15 16:48:11 --> Router Class Initialized
INFO - 2025-05-15 16:48:11 --> Output Class Initialized
INFO - 2025-05-15 16:48:11 --> Security Class Initialized
DEBUG - 2025-05-15 16:48:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 16:48:11 --> Input Class Initialized
INFO - 2025-05-15 16:48:11 --> Language Class Initialized
INFO - 2025-05-15 16:48:11 --> Loader Class Initialized
INFO - 2025-05-15 16:48:11 --> Helper loaded: url_helper
INFO - 2025-05-15 16:48:11 --> Helper loaded: form_helper
INFO - 2025-05-15 16:48:11 --> Database Driver Class Initialized
DEBUG - 2025-05-15 16:48:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 16:48:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 16:48:11 --> Controller Class Initialized
INFO - 2025-05-15 16:48:11 --> Model "Workout_model" initialized
INFO - 2025-05-15 16:48:11 --> Model "User_model" initialized
INFO - 2025-05-15 16:48:11 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 16:48:11 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 16:48:11 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga.php
INFO - 2025-05-15 16:48:11 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 16:48:11 --> Final output sent to browser
DEBUG - 2025-05-15 16:48:11 --> Total execution time: 0.0621
INFO - 2025-05-15 16:48:13 --> Config Class Initialized
INFO - 2025-05-15 16:48:13 --> Hooks Class Initialized
DEBUG - 2025-05-15 16:48:13 --> UTF-8 Support Enabled
INFO - 2025-05-15 16:48:13 --> Utf8 Class Initialized
INFO - 2025-05-15 16:48:13 --> URI Class Initialized
INFO - 2025-05-15 16:48:13 --> Router Class Initialized
INFO - 2025-05-15 16:48:13 --> Output Class Initialized
INFO - 2025-05-15 16:48:13 --> Security Class Initialized
DEBUG - 2025-05-15 16:48:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 16:48:13 --> Input Class Initialized
INFO - 2025-05-15 16:48:13 --> Language Class Initialized
INFO - 2025-05-15 16:48:13 --> Loader Class Initialized
INFO - 2025-05-15 16:48:13 --> Helper loaded: url_helper
INFO - 2025-05-15 16:48:13 --> Helper loaded: form_helper
INFO - 2025-05-15 16:48:13 --> Database Driver Class Initialized
DEBUG - 2025-05-15 16:48:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 16:48:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 16:48:13 --> Controller Class Initialized
INFO - 2025-05-15 16:48:13 --> Model "Workout_model" initialized
INFO - 2025-05-15 16:48:13 --> Model "User_model" initialized
INFO - 2025-05-15 16:48:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 16:48:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 16:48:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga.php
INFO - 2025-05-15 16:48:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 16:48:13 --> Final output sent to browser
DEBUG - 2025-05-15 16:48:13 --> Total execution time: 0.0913
INFO - 2025-05-15 16:48:14 --> Config Class Initialized
INFO - 2025-05-15 16:48:14 --> Hooks Class Initialized
DEBUG - 2025-05-15 16:48:14 --> UTF-8 Support Enabled
INFO - 2025-05-15 16:48:14 --> Utf8 Class Initialized
INFO - 2025-05-15 16:48:14 --> URI Class Initialized
INFO - 2025-05-15 16:48:14 --> Router Class Initialized
INFO - 2025-05-15 16:48:14 --> Output Class Initialized
INFO - 2025-05-15 16:48:14 --> Security Class Initialized
DEBUG - 2025-05-15 16:48:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 16:48:14 --> Input Class Initialized
INFO - 2025-05-15 16:48:14 --> Language Class Initialized
INFO - 2025-05-15 16:48:14 --> Loader Class Initialized
INFO - 2025-05-15 16:48:14 --> Helper loaded: url_helper
INFO - 2025-05-15 16:48:14 --> Helper loaded: form_helper
INFO - 2025-05-15 16:48:14 --> Database Driver Class Initialized
DEBUG - 2025-05-15 16:48:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 16:48:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 16:48:14 --> Controller Class Initialized
INFO - 2025-05-15 16:48:14 --> Model "Workout_model" initialized
INFO - 2025-05-15 16:48:14 --> Model "User_model" initialized
INFO - 2025-05-15 16:48:14 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 16:48:14 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 16:48:14 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-15 16:48:14 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 16:48:14 --> Final output sent to browser
DEBUG - 2025-05-15 16:48:14 --> Total execution time: 0.0796
INFO - 2025-05-15 16:48:15 --> Config Class Initialized
INFO - 2025-05-15 16:48:15 --> Hooks Class Initialized
DEBUG - 2025-05-15 16:48:15 --> UTF-8 Support Enabled
INFO - 2025-05-15 16:48:15 --> Utf8 Class Initialized
INFO - 2025-05-15 16:48:15 --> URI Class Initialized
INFO - 2025-05-15 16:48:15 --> Router Class Initialized
INFO - 2025-05-15 16:48:15 --> Output Class Initialized
INFO - 2025-05-15 16:48:15 --> Security Class Initialized
DEBUG - 2025-05-15 16:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 16:48:15 --> Input Class Initialized
INFO - 2025-05-15 16:48:15 --> Language Class Initialized
INFO - 2025-05-15 16:48:15 --> Loader Class Initialized
INFO - 2025-05-15 16:48:15 --> Helper loaded: url_helper
INFO - 2025-05-15 16:48:15 --> Helper loaded: form_helper
INFO - 2025-05-15 16:48:15 --> Database Driver Class Initialized
DEBUG - 2025-05-15 16:48:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 16:48:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 16:48:15 --> Controller Class Initialized
INFO - 2025-05-15 16:48:15 --> Model "Workout_model" initialized
INFO - 2025-05-15 16:48:15 --> Model "User_model" initialized
INFO - 2025-05-15 16:48:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 16:48:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 16:48:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga.php
INFO - 2025-05-15 16:48:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 16:48:15 --> Final output sent to browser
DEBUG - 2025-05-15 16:48:15 --> Total execution time: 0.0699
INFO - 2025-05-15 16:49:08 --> Config Class Initialized
INFO - 2025-05-15 16:49:08 --> Hooks Class Initialized
DEBUG - 2025-05-15 16:49:08 --> UTF-8 Support Enabled
INFO - 2025-05-15 16:49:08 --> Utf8 Class Initialized
INFO - 2025-05-15 16:49:08 --> URI Class Initialized
INFO - 2025-05-15 16:49:08 --> Router Class Initialized
INFO - 2025-05-15 16:49:08 --> Output Class Initialized
INFO - 2025-05-15 16:49:08 --> Security Class Initialized
DEBUG - 2025-05-15 16:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 16:49:08 --> Input Class Initialized
INFO - 2025-05-15 16:49:08 --> Language Class Initialized
INFO - 2025-05-15 16:49:08 --> Loader Class Initialized
INFO - 2025-05-15 16:49:08 --> Helper loaded: url_helper
INFO - 2025-05-15 16:49:08 --> Helper loaded: form_helper
INFO - 2025-05-15 16:49:08 --> Database Driver Class Initialized
DEBUG - 2025-05-15 16:49:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 16:49:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 16:49:08 --> Controller Class Initialized
INFO - 2025-05-15 16:49:08 --> Model "Workout_model" initialized
INFO - 2025-05-15 16:49:08 --> Model "User_model" initialized
INFO - 2025-05-15 16:49:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 16:49:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 16:49:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga.php
INFO - 2025-05-15 16:49:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 16:49:08 --> Final output sent to browser
DEBUG - 2025-05-15 16:49:08 --> Total execution time: 0.0643
INFO - 2025-05-15 16:50:16 --> Config Class Initialized
INFO - 2025-05-15 16:50:16 --> Hooks Class Initialized
DEBUG - 2025-05-15 16:50:16 --> UTF-8 Support Enabled
INFO - 2025-05-15 16:50:16 --> Utf8 Class Initialized
INFO - 2025-05-15 16:50:16 --> URI Class Initialized
INFO - 2025-05-15 16:50:16 --> Router Class Initialized
INFO - 2025-05-15 16:50:16 --> Output Class Initialized
INFO - 2025-05-15 16:50:16 --> Security Class Initialized
DEBUG - 2025-05-15 16:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 16:50:16 --> Input Class Initialized
INFO - 2025-05-15 16:50:16 --> Language Class Initialized
INFO - 2025-05-15 16:50:16 --> Loader Class Initialized
INFO - 2025-05-15 16:50:16 --> Helper loaded: url_helper
INFO - 2025-05-15 16:50:16 --> Helper loaded: form_helper
INFO - 2025-05-15 16:50:16 --> Database Driver Class Initialized
DEBUG - 2025-05-15 16:50:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 16:50:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 16:50:16 --> Controller Class Initialized
INFO - 2025-05-15 16:50:16 --> Model "Workout_model" initialized
INFO - 2025-05-15 16:50:16 --> Model "User_model" initialized
INFO - 2025-05-15 16:50:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 16:50:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 16:50:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga.php
INFO - 2025-05-15 16:50:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 16:50:16 --> Final output sent to browser
DEBUG - 2025-05-15 16:50:16 --> Total execution time: 0.0737
INFO - 2025-05-15 16:50:18 --> Config Class Initialized
INFO - 2025-05-15 16:50:18 --> Hooks Class Initialized
DEBUG - 2025-05-15 16:50:18 --> UTF-8 Support Enabled
INFO - 2025-05-15 16:50:18 --> Utf8 Class Initialized
INFO - 2025-05-15 16:50:18 --> URI Class Initialized
INFO - 2025-05-15 16:50:18 --> Router Class Initialized
INFO - 2025-05-15 16:50:18 --> Output Class Initialized
INFO - 2025-05-15 16:50:18 --> Security Class Initialized
DEBUG - 2025-05-15 16:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 16:50:18 --> Input Class Initialized
INFO - 2025-05-15 16:50:18 --> Language Class Initialized
INFO - 2025-05-15 16:50:18 --> Loader Class Initialized
INFO - 2025-05-15 16:50:18 --> Helper loaded: url_helper
INFO - 2025-05-15 16:50:18 --> Helper loaded: form_helper
INFO - 2025-05-15 16:50:18 --> Database Driver Class Initialized
DEBUG - 2025-05-15 16:50:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 16:50:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 16:50:18 --> Controller Class Initialized
INFO - 2025-05-15 16:50:18 --> Model "User_model" initialized
INFO - 2025-05-15 16:50:18 --> Model "Workout_model" initialized
INFO - 2025-05-15 16:50:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 16:50:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 16:50:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-15 16:50:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 16:50:18 --> Final output sent to browser
DEBUG - 2025-05-15 16:50:18 --> Total execution time: 0.0680
INFO - 2025-05-15 16:50:19 --> Config Class Initialized
INFO - 2025-05-15 16:50:19 --> Hooks Class Initialized
DEBUG - 2025-05-15 16:50:19 --> UTF-8 Support Enabled
INFO - 2025-05-15 16:50:19 --> Utf8 Class Initialized
INFO - 2025-05-15 16:50:19 --> URI Class Initialized
INFO - 2025-05-15 16:50:19 --> Router Class Initialized
INFO - 2025-05-15 16:50:19 --> Output Class Initialized
INFO - 2025-05-15 16:50:19 --> Security Class Initialized
DEBUG - 2025-05-15 16:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 16:50:19 --> Input Class Initialized
INFO - 2025-05-15 16:50:19 --> Language Class Initialized
INFO - 2025-05-15 16:50:19 --> Loader Class Initialized
INFO - 2025-05-15 16:50:19 --> Helper loaded: url_helper
INFO - 2025-05-15 16:50:19 --> Helper loaded: form_helper
INFO - 2025-05-15 16:50:19 --> Database Driver Class Initialized
DEBUG - 2025-05-15 16:50:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 16:50:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 16:50:19 --> Controller Class Initialized
INFO - 2025-05-15 16:50:19 --> Model "Workout_model" initialized
INFO - 2025-05-15 16:50:19 --> Model "User_model" initialized
INFO - 2025-05-15 16:50:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 16:50:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 16:50:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga.php
INFO - 2025-05-15 16:50:19 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 16:50:19 --> Final output sent to browser
DEBUG - 2025-05-15 16:50:19 --> Total execution time: 0.0630
INFO - 2025-05-15 16:51:14 --> Config Class Initialized
INFO - 2025-05-15 16:51:14 --> Hooks Class Initialized
DEBUG - 2025-05-15 16:51:14 --> UTF-8 Support Enabled
INFO - 2025-05-15 16:51:14 --> Utf8 Class Initialized
INFO - 2025-05-15 16:51:14 --> URI Class Initialized
INFO - 2025-05-15 16:51:14 --> Router Class Initialized
INFO - 2025-05-15 16:51:14 --> Output Class Initialized
INFO - 2025-05-15 16:51:14 --> Security Class Initialized
DEBUG - 2025-05-15 16:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 16:51:14 --> Input Class Initialized
INFO - 2025-05-15 16:51:14 --> Language Class Initialized
INFO - 2025-05-15 16:51:14 --> Loader Class Initialized
INFO - 2025-05-15 16:51:14 --> Helper loaded: url_helper
INFO - 2025-05-15 16:51:14 --> Helper loaded: form_helper
INFO - 2025-05-15 16:51:14 --> Database Driver Class Initialized
DEBUG - 2025-05-15 16:51:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 16:51:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 16:51:14 --> Controller Class Initialized
INFO - 2025-05-15 16:51:14 --> Model "User_model" initialized
INFO - 2025-05-15 16:51:14 --> Model "Workout_model" initialized
INFO - 2025-05-15 16:51:14 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 16:51:14 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 16:51:14 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-15 16:51:14 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 16:51:14 --> Final output sent to browser
DEBUG - 2025-05-15 16:51:14 --> Total execution time: 0.0939
INFO - 2025-05-15 16:51:15 --> Config Class Initialized
INFO - 2025-05-15 16:51:15 --> Hooks Class Initialized
DEBUG - 2025-05-15 16:51:15 --> UTF-8 Support Enabled
INFO - 2025-05-15 16:51:15 --> Utf8 Class Initialized
INFO - 2025-05-15 16:51:15 --> URI Class Initialized
INFO - 2025-05-15 16:51:15 --> Router Class Initialized
INFO - 2025-05-15 16:51:15 --> Output Class Initialized
INFO - 2025-05-15 16:51:15 --> Security Class Initialized
DEBUG - 2025-05-15 16:51:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 16:51:15 --> Input Class Initialized
INFO - 2025-05-15 16:51:15 --> Language Class Initialized
INFO - 2025-05-15 16:51:15 --> Loader Class Initialized
INFO - 2025-05-15 16:51:15 --> Helper loaded: url_helper
INFO - 2025-05-15 16:51:15 --> Helper loaded: form_helper
INFO - 2025-05-15 16:51:15 --> Database Driver Class Initialized
DEBUG - 2025-05-15 16:51:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 16:51:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 16:51:15 --> Controller Class Initialized
INFO - 2025-05-15 16:51:15 --> Model "Workout_model" initialized
INFO - 2025-05-15 16:51:15 --> Model "User_model" initialized
INFO - 2025-05-15 16:51:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 16:51:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 16:51:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-15 16:51:15 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 16:51:15 --> Final output sent to browser
DEBUG - 2025-05-15 16:51:15 --> Total execution time: 0.0860
INFO - 2025-05-15 16:51:16 --> Config Class Initialized
INFO - 2025-05-15 16:51:16 --> Hooks Class Initialized
DEBUG - 2025-05-15 16:51:16 --> UTF-8 Support Enabled
INFO - 2025-05-15 16:51:16 --> Utf8 Class Initialized
INFO - 2025-05-15 16:51:16 --> URI Class Initialized
INFO - 2025-05-15 16:51:16 --> Router Class Initialized
INFO - 2025-05-15 16:51:16 --> Output Class Initialized
INFO - 2025-05-15 16:51:16 --> Security Class Initialized
DEBUG - 2025-05-15 16:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 16:51:16 --> Input Class Initialized
INFO - 2025-05-15 16:51:16 --> Language Class Initialized
INFO - 2025-05-15 16:51:16 --> Loader Class Initialized
INFO - 2025-05-15 16:51:16 --> Helper loaded: url_helper
INFO - 2025-05-15 16:51:16 --> Helper loaded: form_helper
INFO - 2025-05-15 16:51:16 --> Database Driver Class Initialized
DEBUG - 2025-05-15 16:51:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 16:51:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 16:51:16 --> Controller Class Initialized
INFO - 2025-05-15 16:51:16 --> Model "Workout_model" initialized
INFO - 2025-05-15 16:51:16 --> Model "User_model" initialized
INFO - 2025-05-15 16:51:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 16:51:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 16:51:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga.php
INFO - 2025-05-15 16:51:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 16:51:16 --> Final output sent to browser
DEBUG - 2025-05-15 16:51:16 --> Total execution time: 0.0541
INFO - 2025-05-15 16:51:20 --> Config Class Initialized
INFO - 2025-05-15 16:51:20 --> Hooks Class Initialized
DEBUG - 2025-05-15 16:51:20 --> UTF-8 Support Enabled
INFO - 2025-05-15 16:51:20 --> Utf8 Class Initialized
INFO - 2025-05-15 16:51:20 --> URI Class Initialized
INFO - 2025-05-15 16:51:20 --> Router Class Initialized
INFO - 2025-05-15 16:51:20 --> Output Class Initialized
INFO - 2025-05-15 16:51:20 --> Security Class Initialized
DEBUG - 2025-05-15 16:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 16:51:20 --> Input Class Initialized
INFO - 2025-05-15 16:51:20 --> Language Class Initialized
INFO - 2025-05-15 16:51:20 --> Loader Class Initialized
INFO - 2025-05-15 16:51:20 --> Helper loaded: url_helper
INFO - 2025-05-15 16:51:20 --> Helper loaded: form_helper
INFO - 2025-05-15 16:51:20 --> Database Driver Class Initialized
DEBUG - 2025-05-15 16:51:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 16:51:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 16:51:20 --> Controller Class Initialized
INFO - 2025-05-15 16:51:20 --> Model "User_model" initialized
INFO - 2025-05-15 16:51:20 --> Model "Community_model" initialized
INFO - 2025-05-15 16:51:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 16:51:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 16:51:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/community.php
INFO - 2025-05-15 16:51:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 16:51:20 --> Final output sent to browser
DEBUG - 2025-05-15 16:51:20 --> Total execution time: 0.0776
INFO - 2025-05-15 16:51:21 --> Config Class Initialized
INFO - 2025-05-15 16:51:21 --> Hooks Class Initialized
DEBUG - 2025-05-15 16:51:21 --> UTF-8 Support Enabled
INFO - 2025-05-15 16:51:21 --> Utf8 Class Initialized
INFO - 2025-05-15 16:51:21 --> URI Class Initialized
INFO - 2025-05-15 16:51:21 --> Router Class Initialized
INFO - 2025-05-15 16:51:21 --> Output Class Initialized
INFO - 2025-05-15 16:51:21 --> Security Class Initialized
DEBUG - 2025-05-15 16:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 16:51:21 --> Input Class Initialized
INFO - 2025-05-15 16:51:21 --> Language Class Initialized
INFO - 2025-05-15 16:51:21 --> Loader Class Initialized
INFO - 2025-05-15 16:51:21 --> Helper loaded: url_helper
INFO - 2025-05-15 16:51:21 --> Helper loaded: form_helper
INFO - 2025-05-15 16:51:21 --> Database Driver Class Initialized
DEBUG - 2025-05-15 16:51:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 16:51:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 16:51:21 --> Controller Class Initialized
INFO - 2025-05-15 16:51:21 --> Model "Workout_model" initialized
INFO - 2025-05-15 16:51:21 --> Model "User_model" initialized
INFO - 2025-05-15 16:51:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 16:51:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 16:51:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga.php
INFO - 2025-05-15 16:51:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 16:51:21 --> Final output sent to browser
DEBUG - 2025-05-15 16:51:21 --> Total execution time: 0.0764
INFO - 2025-05-15 16:51:46 --> Config Class Initialized
INFO - 2025-05-15 16:51:46 --> Hooks Class Initialized
DEBUG - 2025-05-15 16:51:46 --> UTF-8 Support Enabled
INFO - 2025-05-15 16:51:46 --> Utf8 Class Initialized
INFO - 2025-05-15 16:51:46 --> URI Class Initialized
INFO - 2025-05-15 16:51:46 --> Router Class Initialized
INFO - 2025-05-15 16:51:46 --> Output Class Initialized
INFO - 2025-05-15 16:51:46 --> Security Class Initialized
DEBUG - 2025-05-15 16:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 16:51:46 --> Input Class Initialized
INFO - 2025-05-15 16:51:46 --> Language Class Initialized
INFO - 2025-05-15 16:51:46 --> Loader Class Initialized
INFO - 2025-05-15 16:51:46 --> Helper loaded: url_helper
INFO - 2025-05-15 16:51:46 --> Helper loaded: form_helper
INFO - 2025-05-15 16:51:46 --> Database Driver Class Initialized
DEBUG - 2025-05-15 16:51:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 16:51:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 16:51:46 --> Controller Class Initialized
INFO - 2025-05-15 16:51:46 --> Model "User_model" initialized
INFO - 2025-05-15 16:51:46 --> Model "Workout_model" initialized
INFO - 2025-05-15 16:51:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 16:51:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 16:51:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-15 16:51:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 16:51:46 --> Final output sent to browser
DEBUG - 2025-05-15 16:51:46 --> Total execution time: 0.0784
INFO - 2025-05-15 16:51:48 --> Config Class Initialized
INFO - 2025-05-15 16:51:48 --> Hooks Class Initialized
DEBUG - 2025-05-15 16:51:48 --> UTF-8 Support Enabled
INFO - 2025-05-15 16:51:48 --> Utf8 Class Initialized
INFO - 2025-05-15 16:51:48 --> URI Class Initialized
INFO - 2025-05-15 16:51:48 --> Router Class Initialized
INFO - 2025-05-15 16:51:48 --> Output Class Initialized
INFO - 2025-05-15 16:51:48 --> Security Class Initialized
DEBUG - 2025-05-15 16:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 16:51:48 --> Input Class Initialized
INFO - 2025-05-15 16:51:48 --> Language Class Initialized
INFO - 2025-05-15 16:51:48 --> Loader Class Initialized
INFO - 2025-05-15 16:51:48 --> Helper loaded: url_helper
INFO - 2025-05-15 16:51:48 --> Helper loaded: form_helper
INFO - 2025-05-15 16:51:48 --> Database Driver Class Initialized
DEBUG - 2025-05-15 16:51:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 16:51:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 16:51:48 --> Controller Class Initialized
INFO - 2025-05-15 16:51:48 --> Model "Workout_model" initialized
INFO - 2025-05-15 16:51:48 --> Model "User_model" initialized
INFO - 2025-05-15 16:51:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 16:51:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 16:51:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-15 16:51:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 16:51:48 --> Final output sent to browser
DEBUG - 2025-05-15 16:51:48 --> Total execution time: 0.0695
INFO - 2025-05-15 16:51:49 --> Config Class Initialized
INFO - 2025-05-15 16:51:49 --> Hooks Class Initialized
DEBUG - 2025-05-15 16:51:49 --> UTF-8 Support Enabled
INFO - 2025-05-15 16:51:49 --> Utf8 Class Initialized
INFO - 2025-05-15 16:51:49 --> URI Class Initialized
INFO - 2025-05-15 16:51:49 --> Router Class Initialized
INFO - 2025-05-15 16:51:49 --> Output Class Initialized
INFO - 2025-05-15 16:51:49 --> Security Class Initialized
DEBUG - 2025-05-15 16:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 16:51:49 --> Input Class Initialized
INFO - 2025-05-15 16:51:49 --> Language Class Initialized
INFO - 2025-05-15 16:51:49 --> Loader Class Initialized
INFO - 2025-05-15 16:51:49 --> Helper loaded: url_helper
INFO - 2025-05-15 16:51:49 --> Helper loaded: form_helper
INFO - 2025-05-15 16:51:49 --> Database Driver Class Initialized
DEBUG - 2025-05-15 16:51:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 16:51:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 16:51:49 --> Controller Class Initialized
INFO - 2025-05-15 16:51:49 --> Model "User_model" initialized
INFO - 2025-05-15 16:51:49 --> Model "Workout_model" initialized
INFO - 2025-05-15 16:51:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 16:51:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 16:51:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-15 16:51:49 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 16:51:49 --> Final output sent to browser
DEBUG - 2025-05-15 16:51:49 --> Total execution time: 0.0527
INFO - 2025-05-15 16:51:51 --> Config Class Initialized
INFO - 2025-05-15 16:51:51 --> Hooks Class Initialized
DEBUG - 2025-05-15 16:51:51 --> UTF-8 Support Enabled
INFO - 2025-05-15 16:51:51 --> Utf8 Class Initialized
INFO - 2025-05-15 16:51:51 --> URI Class Initialized
INFO - 2025-05-15 16:51:51 --> Router Class Initialized
INFO - 2025-05-15 16:51:51 --> Output Class Initialized
INFO - 2025-05-15 16:51:51 --> Security Class Initialized
DEBUG - 2025-05-15 16:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 16:51:51 --> Input Class Initialized
INFO - 2025-05-15 16:51:51 --> Language Class Initialized
INFO - 2025-05-15 16:51:51 --> Loader Class Initialized
INFO - 2025-05-15 16:51:51 --> Helper loaded: url_helper
INFO - 2025-05-15 16:51:51 --> Helper loaded: form_helper
INFO - 2025-05-15 16:51:51 --> Database Driver Class Initialized
DEBUG - 2025-05-15 16:51:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 16:51:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 16:51:51 --> Controller Class Initialized
INFO - 2025-05-15 16:51:51 --> Model "User_model" initialized
INFO - 2025-05-15 16:51:51 --> Model "Workout_model" initialized
INFO - 2025-05-15 16:51:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 16:51:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 16:51:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-15 16:51:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 16:51:51 --> Final output sent to browser
DEBUG - 2025-05-15 16:51:51 --> Total execution time: 0.0649
INFO - 2025-05-15 16:51:52 --> Config Class Initialized
INFO - 2025-05-15 16:51:52 --> Hooks Class Initialized
DEBUG - 2025-05-15 16:51:52 --> UTF-8 Support Enabled
INFO - 2025-05-15 16:51:52 --> Utf8 Class Initialized
INFO - 2025-05-15 16:51:52 --> URI Class Initialized
INFO - 2025-05-15 16:51:52 --> Router Class Initialized
INFO - 2025-05-15 16:51:52 --> Output Class Initialized
INFO - 2025-05-15 16:51:52 --> Security Class Initialized
DEBUG - 2025-05-15 16:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 16:51:52 --> Input Class Initialized
INFO - 2025-05-15 16:51:52 --> Language Class Initialized
INFO - 2025-05-15 16:51:52 --> Loader Class Initialized
INFO - 2025-05-15 16:51:52 --> Helper loaded: url_helper
INFO - 2025-05-15 16:51:52 --> Helper loaded: form_helper
INFO - 2025-05-15 16:51:52 --> Database Driver Class Initialized
DEBUG - 2025-05-15 16:51:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 16:51:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 16:51:52 --> Controller Class Initialized
INFO - 2025-05-15 16:51:52 --> Model "Workout_model" initialized
INFO - 2025-05-15 16:51:52 --> Model "User_model" initialized
INFO - 2025-05-15 16:51:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 16:51:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 16:51:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-15 16:51:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 16:51:52 --> Final output sent to browser
DEBUG - 2025-05-15 16:51:52 --> Total execution time: 0.0611
INFO - 2025-05-15 16:51:54 --> Config Class Initialized
INFO - 2025-05-15 16:51:54 --> Hooks Class Initialized
DEBUG - 2025-05-15 16:51:54 --> UTF-8 Support Enabled
INFO - 2025-05-15 16:51:54 --> Utf8 Class Initialized
INFO - 2025-05-15 16:51:54 --> URI Class Initialized
INFO - 2025-05-15 16:51:54 --> Router Class Initialized
INFO - 2025-05-15 16:51:54 --> Output Class Initialized
INFO - 2025-05-15 16:51:54 --> Security Class Initialized
DEBUG - 2025-05-15 16:51:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 16:51:54 --> Input Class Initialized
INFO - 2025-05-15 16:51:54 --> Language Class Initialized
INFO - 2025-05-15 16:51:54 --> Loader Class Initialized
INFO - 2025-05-15 16:51:54 --> Helper loaded: url_helper
INFO - 2025-05-15 16:51:54 --> Helper loaded: form_helper
INFO - 2025-05-15 16:51:54 --> Database Driver Class Initialized
DEBUG - 2025-05-15 16:51:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 16:51:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 16:51:54 --> Controller Class Initialized
INFO - 2025-05-15 16:51:54 --> Model "User_model" initialized
INFO - 2025-05-15 16:51:54 --> Model "Workout_model" initialized
INFO - 2025-05-15 16:51:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 16:51:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 16:51:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-15 16:51:54 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 16:51:54 --> Final output sent to browser
DEBUG - 2025-05-15 16:51:54 --> Total execution time: 0.0752
INFO - 2025-05-15 16:54:55 --> Config Class Initialized
INFO - 2025-05-15 16:54:55 --> Hooks Class Initialized
DEBUG - 2025-05-15 16:54:55 --> UTF-8 Support Enabled
INFO - 2025-05-15 16:54:55 --> Utf8 Class Initialized
INFO - 2025-05-15 16:54:55 --> URI Class Initialized
INFO - 2025-05-15 16:54:55 --> Router Class Initialized
INFO - 2025-05-15 16:54:55 --> Output Class Initialized
INFO - 2025-05-15 16:54:55 --> Security Class Initialized
DEBUG - 2025-05-15 16:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 16:54:55 --> Input Class Initialized
INFO - 2025-05-15 16:54:55 --> Language Class Initialized
INFO - 2025-05-15 16:54:55 --> Loader Class Initialized
INFO - 2025-05-15 16:54:55 --> Helper loaded: url_helper
INFO - 2025-05-15 16:54:55 --> Helper loaded: form_helper
INFO - 2025-05-15 16:54:55 --> Database Driver Class Initialized
DEBUG - 2025-05-15 16:54:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 16:54:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 16:54:55 --> Controller Class Initialized
INFO - 2025-05-15 16:54:55 --> Model "User_model" initialized
INFO - 2025-05-15 16:54:55 --> Model "Workout_model" initialized
INFO - 2025-05-15 16:54:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 16:54:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 16:54:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-15 16:54:55 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 16:54:55 --> Final output sent to browser
DEBUG - 2025-05-15 16:54:55 --> Total execution time: 0.0939
INFO - 2025-05-15 16:54:57 --> Config Class Initialized
INFO - 2025-05-15 16:54:57 --> Hooks Class Initialized
DEBUG - 2025-05-15 16:54:57 --> UTF-8 Support Enabled
INFO - 2025-05-15 16:54:57 --> Utf8 Class Initialized
INFO - 2025-05-15 16:54:57 --> URI Class Initialized
INFO - 2025-05-15 16:54:57 --> Router Class Initialized
INFO - 2025-05-15 16:54:57 --> Output Class Initialized
INFO - 2025-05-15 16:54:57 --> Security Class Initialized
DEBUG - 2025-05-15 16:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 16:54:57 --> Input Class Initialized
INFO - 2025-05-15 16:54:57 --> Language Class Initialized
INFO - 2025-05-15 16:54:57 --> Loader Class Initialized
INFO - 2025-05-15 16:54:57 --> Helper loaded: url_helper
INFO - 2025-05-15 16:54:57 --> Helper loaded: form_helper
INFO - 2025-05-15 16:54:57 --> Database Driver Class Initialized
DEBUG - 2025-05-15 16:54:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 16:54:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 16:54:57 --> Controller Class Initialized
INFO - 2025-05-15 16:54:57 --> Model "Workout_model" initialized
INFO - 2025-05-15 16:54:57 --> Model "User_model" initialized
INFO - 2025-05-15 16:54:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 16:54:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 16:54:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-15 16:54:57 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 16:54:57 --> Final output sent to browser
DEBUG - 2025-05-15 16:54:57 --> Total execution time: 0.0819
INFO - 2025-05-15 16:54:58 --> Config Class Initialized
INFO - 2025-05-15 16:54:58 --> Hooks Class Initialized
DEBUG - 2025-05-15 16:54:58 --> UTF-8 Support Enabled
INFO - 2025-05-15 16:54:58 --> Utf8 Class Initialized
INFO - 2025-05-15 16:54:58 --> URI Class Initialized
INFO - 2025-05-15 16:54:58 --> Router Class Initialized
INFO - 2025-05-15 16:54:58 --> Output Class Initialized
INFO - 2025-05-15 16:54:58 --> Security Class Initialized
DEBUG - 2025-05-15 16:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 16:54:58 --> Input Class Initialized
INFO - 2025-05-15 16:54:58 --> Language Class Initialized
INFO - 2025-05-15 16:54:58 --> Loader Class Initialized
INFO - 2025-05-15 16:54:58 --> Helper loaded: url_helper
INFO - 2025-05-15 16:54:58 --> Helper loaded: form_helper
INFO - 2025-05-15 16:54:58 --> Database Driver Class Initialized
DEBUG - 2025-05-15 16:54:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 16:54:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 16:54:58 --> Controller Class Initialized
INFO - 2025-05-15 16:54:58 --> Model "Workout_model" initialized
INFO - 2025-05-15 16:54:58 --> Model "User_model" initialized
INFO - 2025-05-15 16:54:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 16:54:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 16:54:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga.php
INFO - 2025-05-15 16:54:58 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 16:54:58 --> Final output sent to browser
DEBUG - 2025-05-15 16:54:58 --> Total execution time: 0.0788
INFO - 2025-05-15 16:55:06 --> Config Class Initialized
INFO - 2025-05-15 16:55:06 --> Hooks Class Initialized
DEBUG - 2025-05-15 16:55:06 --> UTF-8 Support Enabled
INFO - 2025-05-15 16:55:06 --> Utf8 Class Initialized
INFO - 2025-05-15 16:55:06 --> URI Class Initialized
INFO - 2025-05-15 16:55:06 --> Router Class Initialized
INFO - 2025-05-15 16:55:06 --> Output Class Initialized
INFO - 2025-05-15 16:55:06 --> Security Class Initialized
DEBUG - 2025-05-15 16:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 16:55:06 --> Input Class Initialized
INFO - 2025-05-15 16:55:06 --> Language Class Initialized
INFO - 2025-05-15 16:55:06 --> Loader Class Initialized
INFO - 2025-05-15 16:55:06 --> Helper loaded: url_helper
INFO - 2025-05-15 16:55:06 --> Helper loaded: form_helper
INFO - 2025-05-15 16:55:06 --> Database Driver Class Initialized
DEBUG - 2025-05-15 16:55:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 16:55:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 16:55:06 --> Controller Class Initialized
INFO - 2025-05-15 16:55:06 --> Model "User_model" initialized
INFO - 2025-05-15 16:55:06 --> Model "Workout_model" initialized
INFO - 2025-05-15 16:55:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 16:55:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 16:55:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-15 16:55:06 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 16:55:06 --> Final output sent to browser
DEBUG - 2025-05-15 16:55:06 --> Total execution time: 0.0682
INFO - 2025-05-15 16:55:07 --> Config Class Initialized
INFO - 2025-05-15 16:55:07 --> Hooks Class Initialized
DEBUG - 2025-05-15 16:55:07 --> UTF-8 Support Enabled
INFO - 2025-05-15 16:55:07 --> Utf8 Class Initialized
INFO - 2025-05-15 16:55:07 --> URI Class Initialized
INFO - 2025-05-15 16:55:07 --> Router Class Initialized
INFO - 2025-05-15 16:55:07 --> Output Class Initialized
INFO - 2025-05-15 16:55:07 --> Security Class Initialized
DEBUG - 2025-05-15 16:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 16:55:07 --> Input Class Initialized
INFO - 2025-05-15 16:55:07 --> Language Class Initialized
INFO - 2025-05-15 16:55:07 --> Loader Class Initialized
INFO - 2025-05-15 16:55:07 --> Helper loaded: url_helper
INFO - 2025-05-15 16:55:07 --> Helper loaded: form_helper
INFO - 2025-05-15 16:55:07 --> Database Driver Class Initialized
DEBUG - 2025-05-15 16:55:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 16:55:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 16:55:07 --> Controller Class Initialized
INFO - 2025-05-15 16:55:07 --> Model "User_model" initialized
INFO - 2025-05-15 16:55:07 --> Model "Workout_model" initialized
INFO - 2025-05-15 16:55:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 16:55:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 16:55:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-15 16:55:07 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 16:55:07 --> Final output sent to browser
DEBUG - 2025-05-15 16:55:07 --> Total execution time: 0.0679
INFO - 2025-05-15 16:55:43 --> Config Class Initialized
INFO - 2025-05-15 16:55:43 --> Hooks Class Initialized
DEBUG - 2025-05-15 16:55:43 --> UTF-8 Support Enabled
INFO - 2025-05-15 16:55:43 --> Utf8 Class Initialized
INFO - 2025-05-15 16:55:43 --> URI Class Initialized
INFO - 2025-05-15 16:55:43 --> Router Class Initialized
INFO - 2025-05-15 16:55:43 --> Output Class Initialized
INFO - 2025-05-15 16:55:43 --> Security Class Initialized
DEBUG - 2025-05-15 16:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 16:55:43 --> Input Class Initialized
INFO - 2025-05-15 16:55:43 --> Language Class Initialized
INFO - 2025-05-15 16:55:43 --> Loader Class Initialized
INFO - 2025-05-15 16:55:43 --> Helper loaded: url_helper
INFO - 2025-05-15 16:55:43 --> Helper loaded: form_helper
INFO - 2025-05-15 16:55:43 --> Database Driver Class Initialized
DEBUG - 2025-05-15 16:55:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 16:55:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 16:55:43 --> Controller Class Initialized
INFO - 2025-05-15 16:55:43 --> Model "Workout_model" initialized
INFO - 2025-05-15 16:55:43 --> Model "User_model" initialized
INFO - 2025-05-15 16:55:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 16:55:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 16:55:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-15 16:55:43 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 16:55:43 --> Final output sent to browser
DEBUG - 2025-05-15 16:55:43 --> Total execution time: 0.0886
INFO - 2025-05-15 16:55:43 --> Config Class Initialized
INFO - 2025-05-15 16:55:43 --> Hooks Class Initialized
DEBUG - 2025-05-15 16:55:43 --> UTF-8 Support Enabled
INFO - 2025-05-15 16:55:43 --> Utf8 Class Initialized
INFO - 2025-05-15 16:55:43 --> URI Class Initialized
INFO - 2025-05-15 16:55:43 --> Router Class Initialized
INFO - 2025-05-15 16:55:43 --> Output Class Initialized
INFO - 2025-05-15 16:55:43 --> Security Class Initialized
DEBUG - 2025-05-15 16:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 16:55:43 --> Input Class Initialized
INFO - 2025-05-15 16:55:43 --> Language Class Initialized
INFO - 2025-05-15 16:55:44 --> Loader Class Initialized
INFO - 2025-05-15 16:55:44 --> Helper loaded: url_helper
INFO - 2025-05-15 16:55:44 --> Helper loaded: form_helper
INFO - 2025-05-15 16:55:44 --> Database Driver Class Initialized
DEBUG - 2025-05-15 16:55:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 16:55:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 16:55:44 --> Controller Class Initialized
INFO - 2025-05-15 16:55:44 --> Model "Workout_model" initialized
INFO - 2025-05-15 16:55:44 --> Model "User_model" initialized
INFO - 2025-05-15 16:55:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 16:55:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 16:55:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga.php
INFO - 2025-05-15 16:55:44 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 16:55:44 --> Final output sent to browser
DEBUG - 2025-05-15 16:55:44 --> Total execution time: 0.0733
INFO - 2025-05-15 16:55:46 --> Config Class Initialized
INFO - 2025-05-15 16:55:46 --> Hooks Class Initialized
DEBUG - 2025-05-15 16:55:46 --> UTF-8 Support Enabled
INFO - 2025-05-15 16:55:46 --> Utf8 Class Initialized
INFO - 2025-05-15 16:55:46 --> URI Class Initialized
INFO - 2025-05-15 16:55:46 --> Router Class Initialized
INFO - 2025-05-15 16:55:46 --> Output Class Initialized
INFO - 2025-05-15 16:55:46 --> Security Class Initialized
DEBUG - 2025-05-15 16:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 16:55:46 --> Input Class Initialized
INFO - 2025-05-15 16:55:46 --> Language Class Initialized
INFO - 2025-05-15 16:55:46 --> Loader Class Initialized
INFO - 2025-05-15 16:55:46 --> Helper loaded: url_helper
INFO - 2025-05-15 16:55:46 --> Helper loaded: form_helper
INFO - 2025-05-15 16:55:46 --> Database Driver Class Initialized
DEBUG - 2025-05-15 16:55:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 16:55:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 16:55:46 --> Controller Class Initialized
INFO - 2025-05-15 16:55:46 --> Model "Workout_model" initialized
INFO - 2025-05-15 16:55:46 --> Model "User_model" initialized
INFO - 2025-05-15 16:55:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 16:55:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 16:55:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga.php
INFO - 2025-05-15 16:55:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 16:55:46 --> Final output sent to browser
DEBUG - 2025-05-15 16:55:46 --> Total execution time: 0.0636
INFO - 2025-05-15 16:56:45 --> Config Class Initialized
INFO - 2025-05-15 16:56:45 --> Hooks Class Initialized
DEBUG - 2025-05-15 16:56:45 --> UTF-8 Support Enabled
INFO - 2025-05-15 16:56:45 --> Utf8 Class Initialized
INFO - 2025-05-15 16:56:45 --> URI Class Initialized
INFO - 2025-05-15 16:56:45 --> Router Class Initialized
INFO - 2025-05-15 16:56:45 --> Output Class Initialized
INFO - 2025-05-15 16:56:45 --> Security Class Initialized
DEBUG - 2025-05-15 16:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 16:56:45 --> Input Class Initialized
INFO - 2025-05-15 16:56:45 --> Language Class Initialized
INFO - 2025-05-15 16:56:45 --> Loader Class Initialized
INFO - 2025-05-15 16:56:45 --> Helper loaded: url_helper
INFO - 2025-05-15 16:56:45 --> Helper loaded: form_helper
INFO - 2025-05-15 16:56:45 --> Database Driver Class Initialized
DEBUG - 2025-05-15 16:56:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 16:56:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 16:56:45 --> Controller Class Initialized
INFO - 2025-05-15 16:56:45 --> Model "Workout_model" initialized
INFO - 2025-05-15 16:56:45 --> Model "User_model" initialized
INFO - 2025-05-15 16:56:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 16:56:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 16:56:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga.php
INFO - 2025-05-15 16:56:45 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 16:56:45 --> Final output sent to browser
DEBUG - 2025-05-15 16:56:45 --> Total execution time: 0.0684
INFO - 2025-05-15 16:56:46 --> Config Class Initialized
INFO - 2025-05-15 16:56:46 --> Hooks Class Initialized
DEBUG - 2025-05-15 16:56:46 --> UTF-8 Support Enabled
INFO - 2025-05-15 16:56:46 --> Utf8 Class Initialized
INFO - 2025-05-15 16:56:46 --> URI Class Initialized
INFO - 2025-05-15 16:56:46 --> Router Class Initialized
INFO - 2025-05-15 16:56:46 --> Output Class Initialized
INFO - 2025-05-15 16:56:46 --> Security Class Initialized
DEBUG - 2025-05-15 16:56:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 16:56:46 --> Input Class Initialized
INFO - 2025-05-15 16:56:46 --> Language Class Initialized
INFO - 2025-05-15 16:56:46 --> Loader Class Initialized
INFO - 2025-05-15 16:56:46 --> Helper loaded: url_helper
INFO - 2025-05-15 16:56:46 --> Helper loaded: form_helper
INFO - 2025-05-15 16:56:46 --> Database Driver Class Initialized
DEBUG - 2025-05-15 16:56:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 16:56:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 16:56:46 --> Controller Class Initialized
INFO - 2025-05-15 16:56:46 --> Model "Workout_model" initialized
INFO - 2025-05-15 16:56:46 --> Model "User_model" initialized
INFO - 2025-05-15 16:56:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 16:56:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 16:56:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga.php
INFO - 2025-05-15 16:56:46 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 16:56:46 --> Final output sent to browser
DEBUG - 2025-05-15 16:56:46 --> Total execution time: 0.0750
INFO - 2025-05-15 16:56:48 --> Config Class Initialized
INFO - 2025-05-15 16:56:48 --> Hooks Class Initialized
DEBUG - 2025-05-15 16:56:48 --> UTF-8 Support Enabled
INFO - 2025-05-15 16:56:48 --> Utf8 Class Initialized
INFO - 2025-05-15 16:56:48 --> URI Class Initialized
INFO - 2025-05-15 16:56:48 --> Router Class Initialized
INFO - 2025-05-15 16:56:48 --> Output Class Initialized
INFO - 2025-05-15 16:56:48 --> Security Class Initialized
DEBUG - 2025-05-15 16:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 16:56:48 --> Input Class Initialized
INFO - 2025-05-15 16:56:48 --> Language Class Initialized
INFO - 2025-05-15 16:56:48 --> Loader Class Initialized
INFO - 2025-05-15 16:56:48 --> Helper loaded: url_helper
INFO - 2025-05-15 16:56:48 --> Helper loaded: form_helper
INFO - 2025-05-15 16:56:48 --> Database Driver Class Initialized
DEBUG - 2025-05-15 16:56:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 16:56:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 16:56:48 --> Controller Class Initialized
INFO - 2025-05-15 16:56:48 --> Model "Workout_model" initialized
INFO - 2025-05-15 16:56:48 --> Model "User_model" initialized
INFO - 2025-05-15 16:56:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 16:56:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 16:56:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga.php
INFO - 2025-05-15 16:56:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 16:56:48 --> Final output sent to browser
DEBUG - 2025-05-15 16:56:48 --> Total execution time: 0.0742
INFO - 2025-05-15 16:57:07 --> Config Class Initialized
INFO - 2025-05-15 16:57:07 --> Hooks Class Initialized
DEBUG - 2025-05-15 16:57:07 --> UTF-8 Support Enabled
INFO - 2025-05-15 16:57:07 --> Utf8 Class Initialized
INFO - 2025-05-15 16:57:07 --> URI Class Initialized
INFO - 2025-05-15 16:57:07 --> Router Class Initialized
INFO - 2025-05-15 16:57:07 --> Output Class Initialized
INFO - 2025-05-15 16:57:07 --> Security Class Initialized
DEBUG - 2025-05-15 16:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 16:57:07 --> Input Class Initialized
INFO - 2025-05-15 16:57:07 --> Language Class Initialized
INFO - 2025-05-15 16:57:07 --> Loader Class Initialized
INFO - 2025-05-15 16:57:07 --> Helper loaded: url_helper
INFO - 2025-05-15 16:57:07 --> Helper loaded: form_helper
INFO - 2025-05-15 16:57:08 --> Database Driver Class Initialized
DEBUG - 2025-05-15 16:57:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 16:57:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 16:57:08 --> Controller Class Initialized
INFO - 2025-05-15 16:57:08 --> Model "Workout_model" initialized
INFO - 2025-05-15 16:57:08 --> Model "User_model" initialized
INFO - 2025-05-15 16:57:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 16:57:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 16:57:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga.php
INFO - 2025-05-15 16:57:08 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 16:57:08 --> Final output sent to browser
DEBUG - 2025-05-15 16:57:08 --> Total execution time: 0.0707
INFO - 2025-05-15 16:57:09 --> Config Class Initialized
INFO - 2025-05-15 16:57:09 --> Hooks Class Initialized
DEBUG - 2025-05-15 16:57:09 --> UTF-8 Support Enabled
INFO - 2025-05-15 16:57:09 --> Utf8 Class Initialized
INFO - 2025-05-15 16:57:09 --> URI Class Initialized
INFO - 2025-05-15 16:57:09 --> Router Class Initialized
INFO - 2025-05-15 16:57:09 --> Output Class Initialized
INFO - 2025-05-15 16:57:09 --> Security Class Initialized
DEBUG - 2025-05-15 16:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 16:57:09 --> Input Class Initialized
INFO - 2025-05-15 16:57:09 --> Language Class Initialized
INFO - 2025-05-15 16:57:09 --> Loader Class Initialized
INFO - 2025-05-15 16:57:09 --> Helper loaded: url_helper
INFO - 2025-05-15 16:57:09 --> Helper loaded: form_helper
INFO - 2025-05-15 16:57:09 --> Database Driver Class Initialized
DEBUG - 2025-05-15 16:57:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 16:57:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 16:57:09 --> Controller Class Initialized
INFO - 2025-05-15 16:57:09 --> Model "Workout_model" initialized
INFO - 2025-05-15 16:57:09 --> Model "User_model" initialized
INFO - 2025-05-15 16:57:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 16:57:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 16:57:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga.php
INFO - 2025-05-15 16:57:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 16:57:09 --> Final output sent to browser
DEBUG - 2025-05-15 16:57:09 --> Total execution time: 0.0665
INFO - 2025-05-15 16:57:23 --> Config Class Initialized
INFO - 2025-05-15 16:57:23 --> Hooks Class Initialized
DEBUG - 2025-05-15 16:57:23 --> UTF-8 Support Enabled
INFO - 2025-05-15 16:57:23 --> Utf8 Class Initialized
INFO - 2025-05-15 16:57:23 --> URI Class Initialized
INFO - 2025-05-15 16:57:23 --> Router Class Initialized
INFO - 2025-05-15 16:57:23 --> Output Class Initialized
INFO - 2025-05-15 16:57:23 --> Security Class Initialized
DEBUG - 2025-05-15 16:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 16:57:23 --> Input Class Initialized
INFO - 2025-05-15 16:57:23 --> Language Class Initialized
INFO - 2025-05-15 16:57:23 --> Loader Class Initialized
INFO - 2025-05-15 16:57:23 --> Helper loaded: url_helper
INFO - 2025-05-15 16:57:23 --> Helper loaded: form_helper
INFO - 2025-05-15 16:57:23 --> Database Driver Class Initialized
DEBUG - 2025-05-15 16:57:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 16:57:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 16:57:23 --> Controller Class Initialized
INFO - 2025-05-15 16:57:23 --> Model "Workout_model" initialized
INFO - 2025-05-15 16:57:23 --> Model "User_model" initialized
INFO - 2025-05-15 16:57:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 16:57:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 16:57:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga.php
INFO - 2025-05-15 16:57:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 16:57:23 --> Final output sent to browser
DEBUG - 2025-05-15 16:57:23 --> Total execution time: 0.0781
INFO - 2025-05-15 16:57:24 --> Config Class Initialized
INFO - 2025-05-15 16:57:24 --> Hooks Class Initialized
DEBUG - 2025-05-15 16:57:24 --> UTF-8 Support Enabled
INFO - 2025-05-15 16:57:24 --> Utf8 Class Initialized
INFO - 2025-05-15 16:57:24 --> URI Class Initialized
INFO - 2025-05-15 16:57:24 --> Router Class Initialized
INFO - 2025-05-15 16:57:24 --> Output Class Initialized
INFO - 2025-05-15 16:57:24 --> Security Class Initialized
DEBUG - 2025-05-15 16:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 16:57:24 --> Input Class Initialized
INFO - 2025-05-15 16:57:24 --> Language Class Initialized
INFO - 2025-05-15 16:57:24 --> Loader Class Initialized
INFO - 2025-05-15 16:57:24 --> Helper loaded: url_helper
INFO - 2025-05-15 16:57:24 --> Helper loaded: form_helper
INFO - 2025-05-15 16:57:24 --> Database Driver Class Initialized
DEBUG - 2025-05-15 16:57:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 16:57:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 16:57:24 --> Controller Class Initialized
INFO - 2025-05-15 16:57:24 --> Model "User_model" initialized
INFO - 2025-05-15 16:57:24 --> Model "Workout_model" initialized
INFO - 2025-05-15 16:57:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 16:57:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 16:57:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-15 16:57:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 16:57:24 --> Final output sent to browser
DEBUG - 2025-05-15 16:57:24 --> Total execution time: 0.0954
INFO - 2025-05-15 16:57:25 --> Config Class Initialized
INFO - 2025-05-15 16:57:25 --> Hooks Class Initialized
DEBUG - 2025-05-15 16:57:25 --> UTF-8 Support Enabled
INFO - 2025-05-15 16:57:25 --> Utf8 Class Initialized
INFO - 2025-05-15 16:57:25 --> URI Class Initialized
INFO - 2025-05-15 16:57:25 --> Router Class Initialized
INFO - 2025-05-15 16:57:25 --> Output Class Initialized
INFO - 2025-05-15 16:57:25 --> Security Class Initialized
DEBUG - 2025-05-15 16:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 16:57:25 --> Input Class Initialized
INFO - 2025-05-15 16:57:25 --> Language Class Initialized
INFO - 2025-05-15 16:57:25 --> Loader Class Initialized
INFO - 2025-05-15 16:57:25 --> Helper loaded: url_helper
INFO - 2025-05-15 16:57:25 --> Helper loaded: form_helper
INFO - 2025-05-15 16:57:25 --> Database Driver Class Initialized
DEBUG - 2025-05-15 16:57:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 16:57:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 16:57:25 --> Controller Class Initialized
INFO - 2025-05-15 16:57:25 --> Model "User_model" initialized
INFO - 2025-05-15 16:57:25 --> Model "Workout_model" initialized
INFO - 2025-05-15 16:57:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 16:57:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 16:57:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-15 16:57:25 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 16:57:25 --> Final output sent to browser
DEBUG - 2025-05-15 16:57:25 --> Total execution time: 0.0719
INFO - 2025-05-15 16:57:26 --> Config Class Initialized
INFO - 2025-05-15 16:57:26 --> Hooks Class Initialized
DEBUG - 2025-05-15 16:57:26 --> UTF-8 Support Enabled
INFO - 2025-05-15 16:57:26 --> Utf8 Class Initialized
INFO - 2025-05-15 16:57:26 --> URI Class Initialized
INFO - 2025-05-15 16:57:26 --> Router Class Initialized
INFO - 2025-05-15 16:57:26 --> Output Class Initialized
INFO - 2025-05-15 16:57:26 --> Security Class Initialized
DEBUG - 2025-05-15 16:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 16:57:26 --> Input Class Initialized
INFO - 2025-05-15 16:57:26 --> Language Class Initialized
INFO - 2025-05-15 16:57:26 --> Loader Class Initialized
INFO - 2025-05-15 16:57:26 --> Helper loaded: url_helper
INFO - 2025-05-15 16:57:26 --> Helper loaded: form_helper
INFO - 2025-05-15 16:57:26 --> Database Driver Class Initialized
DEBUG - 2025-05-15 16:57:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 16:57:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 16:57:26 --> Controller Class Initialized
INFO - 2025-05-15 16:57:26 --> Model "Workout_model" initialized
INFO - 2025-05-15 16:57:26 --> Model "User_model" initialized
INFO - 2025-05-15 16:57:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 16:57:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 16:57:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-15 16:57:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 16:57:26 --> Final output sent to browser
DEBUG - 2025-05-15 16:57:26 --> Total execution time: 0.0754
INFO - 2025-05-15 16:57:27 --> Config Class Initialized
INFO - 2025-05-15 16:57:27 --> Hooks Class Initialized
DEBUG - 2025-05-15 16:57:27 --> UTF-8 Support Enabled
INFO - 2025-05-15 16:57:27 --> Utf8 Class Initialized
INFO - 2025-05-15 16:57:27 --> URI Class Initialized
INFO - 2025-05-15 16:57:27 --> Router Class Initialized
INFO - 2025-05-15 16:57:27 --> Output Class Initialized
INFO - 2025-05-15 16:57:27 --> Security Class Initialized
DEBUG - 2025-05-15 16:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 16:57:27 --> Input Class Initialized
INFO - 2025-05-15 16:57:27 --> Language Class Initialized
INFO - 2025-05-15 16:57:27 --> Loader Class Initialized
INFO - 2025-05-15 16:57:27 --> Helper loaded: url_helper
INFO - 2025-05-15 16:57:27 --> Helper loaded: form_helper
INFO - 2025-05-15 16:57:27 --> Database Driver Class Initialized
DEBUG - 2025-05-15 16:57:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 16:57:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 16:57:27 --> Controller Class Initialized
INFO - 2025-05-15 16:57:27 --> Model "Workout_model" initialized
INFO - 2025-05-15 16:57:27 --> Model "User_model" initialized
INFO - 2025-05-15 16:57:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 16:57:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 16:57:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga.php
INFO - 2025-05-15 16:57:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 16:57:27 --> Final output sent to browser
DEBUG - 2025-05-15 16:57:27 --> Total execution time: 0.0754
INFO - 2025-05-15 16:58:27 --> Config Class Initialized
INFO - 2025-05-15 16:58:27 --> Hooks Class Initialized
DEBUG - 2025-05-15 16:58:27 --> UTF-8 Support Enabled
INFO - 2025-05-15 16:58:27 --> Utf8 Class Initialized
INFO - 2025-05-15 16:58:27 --> URI Class Initialized
INFO - 2025-05-15 16:58:27 --> Router Class Initialized
INFO - 2025-05-15 16:58:27 --> Output Class Initialized
INFO - 2025-05-15 16:58:27 --> Security Class Initialized
DEBUG - 2025-05-15 16:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 16:58:27 --> Input Class Initialized
INFO - 2025-05-15 16:58:27 --> Language Class Initialized
INFO - 2025-05-15 16:58:27 --> Loader Class Initialized
INFO - 2025-05-15 16:58:27 --> Helper loaded: url_helper
INFO - 2025-05-15 16:58:27 --> Helper loaded: form_helper
INFO - 2025-05-15 16:58:27 --> Database Driver Class Initialized
DEBUG - 2025-05-15 16:58:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 16:58:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 16:58:27 --> Controller Class Initialized
INFO - 2025-05-15 16:58:27 --> Model "Workout_model" initialized
INFO - 2025-05-15 16:58:27 --> Model "User_model" initialized
INFO - 2025-05-15 16:58:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 16:58:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 16:58:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga.php
INFO - 2025-05-15 16:58:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 16:58:27 --> Final output sent to browser
DEBUG - 2025-05-15 16:58:27 --> Total execution time: 0.0795
INFO - 2025-05-15 16:58:28 --> Config Class Initialized
INFO - 2025-05-15 16:58:28 --> Hooks Class Initialized
DEBUG - 2025-05-15 16:58:28 --> UTF-8 Support Enabled
INFO - 2025-05-15 16:58:28 --> Utf8 Class Initialized
INFO - 2025-05-15 16:58:28 --> URI Class Initialized
INFO - 2025-05-15 16:58:28 --> Router Class Initialized
INFO - 2025-05-15 16:58:28 --> Output Class Initialized
INFO - 2025-05-15 16:58:28 --> Security Class Initialized
DEBUG - 2025-05-15 16:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 16:58:28 --> Input Class Initialized
INFO - 2025-05-15 16:58:28 --> Language Class Initialized
INFO - 2025-05-15 16:58:28 --> Loader Class Initialized
INFO - 2025-05-15 16:58:28 --> Helper loaded: url_helper
INFO - 2025-05-15 16:58:28 --> Helper loaded: form_helper
INFO - 2025-05-15 16:58:28 --> Database Driver Class Initialized
DEBUG - 2025-05-15 16:58:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 16:58:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 16:58:28 --> Controller Class Initialized
INFO - 2025-05-15 16:58:28 --> Model "Workout_model" initialized
INFO - 2025-05-15 16:58:28 --> Model "User_model" initialized
INFO - 2025-05-15 16:58:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 16:58:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 16:58:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-15 16:58:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 16:58:28 --> Final output sent to browser
DEBUG - 2025-05-15 16:58:28 --> Total execution time: 0.0606
INFO - 2025-05-15 16:58:30 --> Config Class Initialized
INFO - 2025-05-15 16:58:30 --> Hooks Class Initialized
DEBUG - 2025-05-15 16:58:30 --> UTF-8 Support Enabled
INFO - 2025-05-15 16:58:30 --> Utf8 Class Initialized
INFO - 2025-05-15 16:58:30 --> URI Class Initialized
INFO - 2025-05-15 16:58:30 --> Router Class Initialized
INFO - 2025-05-15 16:58:30 --> Output Class Initialized
INFO - 2025-05-15 16:58:30 --> Security Class Initialized
DEBUG - 2025-05-15 16:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 16:58:30 --> Input Class Initialized
INFO - 2025-05-15 16:58:30 --> Language Class Initialized
INFO - 2025-05-15 16:58:30 --> Loader Class Initialized
INFO - 2025-05-15 16:58:30 --> Helper loaded: url_helper
INFO - 2025-05-15 16:58:30 --> Helper loaded: form_helper
INFO - 2025-05-15 16:58:30 --> Database Driver Class Initialized
DEBUG - 2025-05-15 16:58:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 16:58:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 16:58:30 --> Controller Class Initialized
INFO - 2025-05-15 16:58:30 --> Model "Workout_model" initialized
INFO - 2025-05-15 16:58:30 --> Model "User_model" initialized
INFO - 2025-05-15 16:58:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 16:58:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 16:58:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga.php
INFO - 2025-05-15 16:58:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 16:58:30 --> Final output sent to browser
DEBUG - 2025-05-15 16:58:30 --> Total execution time: 0.0661
INFO - 2025-05-15 16:58:33 --> Config Class Initialized
INFO - 2025-05-15 16:58:33 --> Hooks Class Initialized
DEBUG - 2025-05-15 16:58:33 --> UTF-8 Support Enabled
INFO - 2025-05-15 16:58:33 --> Utf8 Class Initialized
INFO - 2025-05-15 16:58:33 --> URI Class Initialized
INFO - 2025-05-15 16:58:33 --> Router Class Initialized
INFO - 2025-05-15 16:58:33 --> Output Class Initialized
INFO - 2025-05-15 16:58:33 --> Security Class Initialized
DEBUG - 2025-05-15 16:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 16:58:33 --> Input Class Initialized
INFO - 2025-05-15 16:58:33 --> Language Class Initialized
INFO - 2025-05-15 16:58:33 --> Loader Class Initialized
INFO - 2025-05-15 16:58:33 --> Helper loaded: url_helper
INFO - 2025-05-15 16:58:33 --> Helper loaded: form_helper
INFO - 2025-05-15 16:58:33 --> Database Driver Class Initialized
DEBUG - 2025-05-15 16:58:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 16:58:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 16:58:33 --> Controller Class Initialized
INFO - 2025-05-15 16:58:33 --> Model "User_model" initialized
INFO - 2025-05-15 16:58:33 --> Model "Workout_model" initialized
INFO - 2025-05-15 16:58:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 16:58:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 16:58:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-15 16:58:33 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 16:58:33 --> Final output sent to browser
DEBUG - 2025-05-15 16:58:33 --> Total execution time: 0.0576
INFO - 2025-05-15 16:58:34 --> Config Class Initialized
INFO - 2025-05-15 16:58:34 --> Hooks Class Initialized
DEBUG - 2025-05-15 16:58:34 --> UTF-8 Support Enabled
INFO - 2025-05-15 16:58:34 --> Utf8 Class Initialized
INFO - 2025-05-15 16:58:34 --> URI Class Initialized
INFO - 2025-05-15 16:58:34 --> Router Class Initialized
INFO - 2025-05-15 16:58:34 --> Output Class Initialized
INFO - 2025-05-15 16:58:34 --> Security Class Initialized
DEBUG - 2025-05-15 16:58:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 16:58:34 --> Input Class Initialized
INFO - 2025-05-15 16:58:34 --> Language Class Initialized
INFO - 2025-05-15 16:58:34 --> Loader Class Initialized
INFO - 2025-05-15 16:58:34 --> Helper loaded: url_helper
INFO - 2025-05-15 16:58:34 --> Helper loaded: form_helper
INFO - 2025-05-15 16:58:34 --> Database Driver Class Initialized
DEBUG - 2025-05-15 16:58:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 16:58:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 16:58:34 --> Controller Class Initialized
INFO - 2025-05-15 16:58:34 --> Model "Workout_model" initialized
INFO - 2025-05-15 16:58:34 --> Model "User_model" initialized
INFO - 2025-05-15 16:58:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 16:58:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 16:58:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-15 16:58:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 16:58:34 --> Final output sent to browser
DEBUG - 2025-05-15 16:58:34 --> Total execution time: 0.0641
INFO - 2025-05-15 16:58:52 --> Config Class Initialized
INFO - 2025-05-15 16:58:52 --> Hooks Class Initialized
DEBUG - 2025-05-15 16:58:52 --> UTF-8 Support Enabled
INFO - 2025-05-15 16:58:52 --> Utf8 Class Initialized
INFO - 2025-05-15 16:58:52 --> URI Class Initialized
INFO - 2025-05-15 16:58:52 --> Router Class Initialized
INFO - 2025-05-15 16:58:52 --> Output Class Initialized
INFO - 2025-05-15 16:58:52 --> Security Class Initialized
DEBUG - 2025-05-15 16:58:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 16:58:52 --> Input Class Initialized
INFO - 2025-05-15 16:58:52 --> Language Class Initialized
INFO - 2025-05-15 16:58:52 --> Loader Class Initialized
INFO - 2025-05-15 16:58:52 --> Helper loaded: url_helper
INFO - 2025-05-15 16:58:52 --> Helper loaded: form_helper
INFO - 2025-05-15 16:58:52 --> Database Driver Class Initialized
DEBUG - 2025-05-15 16:58:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 16:58:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 16:58:52 --> Controller Class Initialized
INFO - 2025-05-15 16:58:52 --> Model "Workout_model" initialized
INFO - 2025-05-15 16:58:52 --> Model "User_model" initialized
INFO - 2025-05-15 16:58:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 16:58:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 16:58:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-15 16:58:52 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 16:58:52 --> Final output sent to browser
DEBUG - 2025-05-15 16:58:52 --> Total execution time: 0.0561
INFO - 2025-05-15 16:59:09 --> Config Class Initialized
INFO - 2025-05-15 16:59:09 --> Hooks Class Initialized
DEBUG - 2025-05-15 16:59:09 --> UTF-8 Support Enabled
INFO - 2025-05-15 16:59:09 --> Utf8 Class Initialized
INFO - 2025-05-15 16:59:09 --> URI Class Initialized
INFO - 2025-05-15 16:59:09 --> Router Class Initialized
INFO - 2025-05-15 16:59:09 --> Output Class Initialized
INFO - 2025-05-15 16:59:09 --> Security Class Initialized
DEBUG - 2025-05-15 16:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 16:59:09 --> Input Class Initialized
INFO - 2025-05-15 16:59:09 --> Language Class Initialized
INFO - 2025-05-15 16:59:09 --> Loader Class Initialized
INFO - 2025-05-15 16:59:09 --> Helper loaded: url_helper
INFO - 2025-05-15 16:59:09 --> Helper loaded: form_helper
INFO - 2025-05-15 16:59:09 --> Database Driver Class Initialized
DEBUG - 2025-05-15 16:59:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 16:59:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 16:59:09 --> Controller Class Initialized
INFO - 2025-05-15 16:59:09 --> Model "Workout_model" initialized
INFO - 2025-05-15 16:59:09 --> Model "User_model" initialized
INFO - 2025-05-15 16:59:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 16:59:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 16:59:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-15 16:59:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 16:59:09 --> Final output sent to browser
DEBUG - 2025-05-15 16:59:09 --> Total execution time: 0.0870
INFO - 2025-05-15 16:59:16 --> Config Class Initialized
INFO - 2025-05-15 16:59:16 --> Hooks Class Initialized
DEBUG - 2025-05-15 16:59:16 --> UTF-8 Support Enabled
INFO - 2025-05-15 16:59:16 --> Utf8 Class Initialized
INFO - 2025-05-15 16:59:16 --> URI Class Initialized
INFO - 2025-05-15 16:59:16 --> Router Class Initialized
INFO - 2025-05-15 16:59:16 --> Output Class Initialized
INFO - 2025-05-15 16:59:16 --> Security Class Initialized
DEBUG - 2025-05-15 16:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 16:59:16 --> Input Class Initialized
INFO - 2025-05-15 16:59:16 --> Language Class Initialized
INFO - 2025-05-15 16:59:16 --> Loader Class Initialized
INFO - 2025-05-15 16:59:16 --> Helper loaded: url_helper
INFO - 2025-05-15 16:59:16 --> Helper loaded: form_helper
INFO - 2025-05-15 16:59:16 --> Database Driver Class Initialized
DEBUG - 2025-05-15 16:59:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 16:59:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 16:59:16 --> Controller Class Initialized
INFO - 2025-05-15 16:59:16 --> Model "Workout_model" initialized
INFO - 2025-05-15 16:59:16 --> Model "User_model" initialized
INFO - 2025-05-15 16:59:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 16:59:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 16:59:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-15 16:59:16 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 16:59:16 --> Final output sent to browser
DEBUG - 2025-05-15 16:59:16 --> Total execution time: 0.0787
INFO - 2025-05-15 16:59:21 --> Config Class Initialized
INFO - 2025-05-15 16:59:21 --> Hooks Class Initialized
DEBUG - 2025-05-15 16:59:21 --> UTF-8 Support Enabled
INFO - 2025-05-15 16:59:21 --> Utf8 Class Initialized
INFO - 2025-05-15 16:59:21 --> URI Class Initialized
INFO - 2025-05-15 16:59:21 --> Router Class Initialized
INFO - 2025-05-15 16:59:21 --> Output Class Initialized
INFO - 2025-05-15 16:59:21 --> Security Class Initialized
DEBUG - 2025-05-15 16:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 16:59:21 --> Input Class Initialized
INFO - 2025-05-15 16:59:21 --> Language Class Initialized
INFO - 2025-05-15 16:59:21 --> Loader Class Initialized
INFO - 2025-05-15 16:59:21 --> Helper loaded: url_helper
INFO - 2025-05-15 16:59:21 --> Helper loaded: form_helper
INFO - 2025-05-15 16:59:21 --> Database Driver Class Initialized
DEBUG - 2025-05-15 16:59:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 16:59:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 16:59:21 --> Controller Class Initialized
INFO - 2025-05-15 16:59:21 --> Model "Workout_model" initialized
INFO - 2025-05-15 16:59:21 --> Model "User_model" initialized
INFO - 2025-05-15 16:59:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 16:59:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 16:59:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga.php
INFO - 2025-05-15 16:59:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 16:59:21 --> Final output sent to browser
DEBUG - 2025-05-15 16:59:21 --> Total execution time: 0.0788
INFO - 2025-05-15 16:59:51 --> Config Class Initialized
INFO - 2025-05-15 16:59:51 --> Hooks Class Initialized
DEBUG - 2025-05-15 16:59:51 --> UTF-8 Support Enabled
INFO - 2025-05-15 16:59:51 --> Utf8 Class Initialized
INFO - 2025-05-15 16:59:51 --> URI Class Initialized
INFO - 2025-05-15 16:59:51 --> Router Class Initialized
INFO - 2025-05-15 16:59:51 --> Output Class Initialized
INFO - 2025-05-15 16:59:51 --> Security Class Initialized
DEBUG - 2025-05-15 16:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 16:59:51 --> Input Class Initialized
INFO - 2025-05-15 16:59:51 --> Language Class Initialized
INFO - 2025-05-15 16:59:51 --> Loader Class Initialized
INFO - 2025-05-15 16:59:51 --> Helper loaded: url_helper
INFO - 2025-05-15 16:59:51 --> Helper loaded: form_helper
INFO - 2025-05-15 16:59:51 --> Database Driver Class Initialized
DEBUG - 2025-05-15 16:59:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 16:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 16:59:51 --> Controller Class Initialized
INFO - 2025-05-15 16:59:51 --> Model "Workout_model" initialized
INFO - 2025-05-15 16:59:51 --> Model "User_model" initialized
INFO - 2025-05-15 16:59:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 16:59:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 16:59:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga.php
INFO - 2025-05-15 16:59:51 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 16:59:51 --> Final output sent to browser
DEBUG - 2025-05-15 16:59:51 --> Total execution time: 0.0739
INFO - 2025-05-15 17:00:13 --> Config Class Initialized
INFO - 2025-05-15 17:00:13 --> Hooks Class Initialized
DEBUG - 2025-05-15 17:00:13 --> UTF-8 Support Enabled
INFO - 2025-05-15 17:00:13 --> Utf8 Class Initialized
INFO - 2025-05-15 17:00:13 --> URI Class Initialized
INFO - 2025-05-15 17:00:13 --> Router Class Initialized
INFO - 2025-05-15 17:00:13 --> Output Class Initialized
INFO - 2025-05-15 17:00:13 --> Security Class Initialized
DEBUG - 2025-05-15 17:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 17:00:13 --> Input Class Initialized
INFO - 2025-05-15 17:00:13 --> Language Class Initialized
INFO - 2025-05-15 17:00:13 --> Loader Class Initialized
INFO - 2025-05-15 17:00:13 --> Helper loaded: url_helper
INFO - 2025-05-15 17:00:13 --> Helper loaded: form_helper
INFO - 2025-05-15 17:00:13 --> Database Driver Class Initialized
DEBUG - 2025-05-15 17:00:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 17:00:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 17:00:13 --> Controller Class Initialized
INFO - 2025-05-15 17:00:13 --> Model "User_model" initialized
INFO - 2025-05-15 17:00:13 --> Model "Workout_model" initialized
INFO - 2025-05-15 17:00:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 17:00:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 17:00:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-15 17:00:13 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 17:00:13 --> Final output sent to browser
DEBUG - 2025-05-15 17:00:13 --> Total execution time: 0.0717
INFO - 2025-05-15 17:00:21 --> Config Class Initialized
INFO - 2025-05-15 17:00:21 --> Hooks Class Initialized
DEBUG - 2025-05-15 17:00:21 --> UTF-8 Support Enabled
INFO - 2025-05-15 17:00:21 --> Utf8 Class Initialized
INFO - 2025-05-15 17:00:21 --> URI Class Initialized
INFO - 2025-05-15 17:00:21 --> Router Class Initialized
INFO - 2025-05-15 17:00:21 --> Output Class Initialized
INFO - 2025-05-15 17:00:21 --> Security Class Initialized
DEBUG - 2025-05-15 17:00:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 17:00:21 --> Input Class Initialized
INFO - 2025-05-15 17:00:21 --> Language Class Initialized
INFO - 2025-05-15 17:00:21 --> Loader Class Initialized
INFO - 2025-05-15 17:00:21 --> Helper loaded: url_helper
INFO - 2025-05-15 17:00:21 --> Helper loaded: form_helper
INFO - 2025-05-15 17:00:21 --> Database Driver Class Initialized
DEBUG - 2025-05-15 17:00:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 17:00:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 17:00:21 --> Controller Class Initialized
INFO - 2025-05-15 17:00:21 --> Model "Workout_model" initialized
INFO - 2025-05-15 17:00:21 --> Model "User_model" initialized
INFO - 2025-05-15 17:00:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 17:00:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 17:00:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-15 17:00:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 17:00:21 --> Final output sent to browser
DEBUG - 2025-05-15 17:00:21 --> Total execution time: 0.0782
INFO - 2025-05-15 17:00:28 --> Config Class Initialized
INFO - 2025-05-15 17:00:28 --> Hooks Class Initialized
DEBUG - 2025-05-15 17:00:28 --> UTF-8 Support Enabled
INFO - 2025-05-15 17:00:28 --> Utf8 Class Initialized
INFO - 2025-05-15 17:00:28 --> URI Class Initialized
INFO - 2025-05-15 17:00:28 --> Router Class Initialized
INFO - 2025-05-15 17:00:28 --> Output Class Initialized
INFO - 2025-05-15 17:00:28 --> Security Class Initialized
DEBUG - 2025-05-15 17:00:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 17:00:28 --> Input Class Initialized
INFO - 2025-05-15 17:00:28 --> Language Class Initialized
INFO - 2025-05-15 17:00:28 --> Loader Class Initialized
INFO - 2025-05-15 17:00:28 --> Helper loaded: url_helper
INFO - 2025-05-15 17:00:28 --> Helper loaded: form_helper
INFO - 2025-05-15 17:00:28 --> Database Driver Class Initialized
DEBUG - 2025-05-15 17:00:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 17:00:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 17:00:28 --> Controller Class Initialized
INFO - 2025-05-15 17:00:28 --> Model "Workout_model" initialized
INFO - 2025-05-15 17:00:28 --> Model "User_model" initialized
INFO - 2025-05-15 17:00:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 17:00:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 17:00:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-15 17:00:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 17:00:28 --> Final output sent to browser
DEBUG - 2025-05-15 17:00:28 --> Total execution time: 0.0713
INFO - 2025-05-15 17:01:14 --> Config Class Initialized
INFO - 2025-05-15 17:01:14 --> Hooks Class Initialized
DEBUG - 2025-05-15 17:01:14 --> UTF-8 Support Enabled
INFO - 2025-05-15 17:01:14 --> Utf8 Class Initialized
INFO - 2025-05-15 17:01:14 --> URI Class Initialized
INFO - 2025-05-15 17:01:14 --> Router Class Initialized
INFO - 2025-05-15 17:01:14 --> Output Class Initialized
INFO - 2025-05-15 17:01:14 --> Security Class Initialized
DEBUG - 2025-05-15 17:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 17:01:14 --> Input Class Initialized
INFO - 2025-05-15 17:01:14 --> Language Class Initialized
INFO - 2025-05-15 17:01:14 --> Loader Class Initialized
INFO - 2025-05-15 17:01:14 --> Helper loaded: url_helper
INFO - 2025-05-15 17:01:14 --> Helper loaded: form_helper
INFO - 2025-05-15 17:01:14 --> Database Driver Class Initialized
DEBUG - 2025-05-15 17:01:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 17:01:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 17:01:14 --> Controller Class Initialized
INFO - 2025-05-15 17:01:14 --> Model "Workout_model" initialized
INFO - 2025-05-15 17:01:14 --> Model "User_model" initialized
INFO - 2025-05-15 17:01:14 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 17:01:14 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 17:01:14 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-15 17:01:14 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 17:01:14 --> Final output sent to browser
DEBUG - 2025-05-15 17:01:14 --> Total execution time: 0.0582
INFO - 2025-05-15 17:01:18 --> Config Class Initialized
INFO - 2025-05-15 17:01:18 --> Hooks Class Initialized
DEBUG - 2025-05-15 17:01:18 --> UTF-8 Support Enabled
INFO - 2025-05-15 17:01:18 --> Utf8 Class Initialized
INFO - 2025-05-15 17:01:18 --> URI Class Initialized
INFO - 2025-05-15 17:01:18 --> Router Class Initialized
INFO - 2025-05-15 17:01:18 --> Output Class Initialized
INFO - 2025-05-15 17:01:18 --> Security Class Initialized
DEBUG - 2025-05-15 17:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 17:01:18 --> Input Class Initialized
INFO - 2025-05-15 17:01:18 --> Language Class Initialized
INFO - 2025-05-15 17:01:18 --> Loader Class Initialized
INFO - 2025-05-15 17:01:18 --> Helper loaded: url_helper
INFO - 2025-05-15 17:01:18 --> Helper loaded: form_helper
INFO - 2025-05-15 17:01:18 --> Database Driver Class Initialized
DEBUG - 2025-05-15 17:01:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 17:01:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 17:01:18 --> Controller Class Initialized
INFO - 2025-05-15 17:01:18 --> Model "Workout_model" initialized
INFO - 2025-05-15 17:01:18 --> Model "User_model" initialized
INFO - 2025-05-15 17:01:18 --> Config Class Initialized
INFO - 2025-05-15 17:01:18 --> Hooks Class Initialized
DEBUG - 2025-05-15 17:01:18 --> UTF-8 Support Enabled
INFO - 2025-05-15 17:01:18 --> Utf8 Class Initialized
INFO - 2025-05-15 17:01:18 --> URI Class Initialized
INFO - 2025-05-15 17:01:18 --> Router Class Initialized
INFO - 2025-05-15 17:01:18 --> Output Class Initialized
INFO - 2025-05-15 17:01:18 --> Security Class Initialized
DEBUG - 2025-05-15 17:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 17:01:18 --> Input Class Initialized
INFO - 2025-05-15 17:01:18 --> Language Class Initialized
INFO - 2025-05-15 17:01:18 --> Loader Class Initialized
INFO - 2025-05-15 17:01:18 --> Helper loaded: url_helper
INFO - 2025-05-15 17:01:18 --> Helper loaded: form_helper
INFO - 2025-05-15 17:01:18 --> Database Driver Class Initialized
DEBUG - 2025-05-15 17:01:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 17:01:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 17:01:18 --> Controller Class Initialized
INFO - 2025-05-15 17:01:18 --> Model "Workout_model" initialized
INFO - 2025-05-15 17:01:18 --> Model "User_model" initialized
INFO - 2025-05-15 17:01:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 17:01:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 17:01:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-15 17:01:18 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 17:01:18 --> Final output sent to browser
DEBUG - 2025-05-15 17:01:18 --> Total execution time: 0.0563
INFO - 2025-05-15 17:01:20 --> Config Class Initialized
INFO - 2025-05-15 17:01:20 --> Hooks Class Initialized
DEBUG - 2025-05-15 17:01:20 --> UTF-8 Support Enabled
INFO - 2025-05-15 17:01:20 --> Utf8 Class Initialized
INFO - 2025-05-15 17:01:20 --> URI Class Initialized
INFO - 2025-05-15 17:01:20 --> Router Class Initialized
INFO - 2025-05-15 17:01:20 --> Output Class Initialized
INFO - 2025-05-15 17:01:20 --> Security Class Initialized
DEBUG - 2025-05-15 17:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 17:01:20 --> Input Class Initialized
INFO - 2025-05-15 17:01:20 --> Language Class Initialized
INFO - 2025-05-15 17:01:20 --> Loader Class Initialized
INFO - 2025-05-15 17:01:20 --> Helper loaded: url_helper
INFO - 2025-05-15 17:01:20 --> Helper loaded: form_helper
INFO - 2025-05-15 17:01:20 --> Database Driver Class Initialized
DEBUG - 2025-05-15 17:01:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 17:01:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 17:01:20 --> Controller Class Initialized
INFO - 2025-05-15 17:01:20 --> Model "User_model" initialized
INFO - 2025-05-15 17:01:20 --> Model "Workout_model" initialized
INFO - 2025-05-15 17:01:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 17:01:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 17:01:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-15 17:01:20 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 17:01:20 --> Final output sent to browser
DEBUG - 2025-05-15 17:01:20 --> Total execution time: 0.0799
INFO - 2025-05-15 17:01:21 --> Config Class Initialized
INFO - 2025-05-15 17:01:21 --> Hooks Class Initialized
DEBUG - 2025-05-15 17:01:21 --> UTF-8 Support Enabled
INFO - 2025-05-15 17:01:21 --> Utf8 Class Initialized
INFO - 2025-05-15 17:01:21 --> URI Class Initialized
INFO - 2025-05-15 17:01:21 --> Router Class Initialized
INFO - 2025-05-15 17:01:21 --> Output Class Initialized
INFO - 2025-05-15 17:01:21 --> Security Class Initialized
DEBUG - 2025-05-15 17:01:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 17:01:21 --> Input Class Initialized
INFO - 2025-05-15 17:01:21 --> Language Class Initialized
INFO - 2025-05-15 17:01:21 --> Loader Class Initialized
INFO - 2025-05-15 17:01:21 --> Helper loaded: url_helper
INFO - 2025-05-15 17:01:21 --> Helper loaded: form_helper
INFO - 2025-05-15 17:01:21 --> Database Driver Class Initialized
DEBUG - 2025-05-15 17:01:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 17:01:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 17:01:21 --> Controller Class Initialized
INFO - 2025-05-15 17:01:21 --> Model "User_model" initialized
INFO - 2025-05-15 17:01:21 --> Model "Workout_model" initialized
INFO - 2025-05-15 17:01:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 17:01:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 17:01:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-15 17:01:21 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 17:01:21 --> Final output sent to browser
DEBUG - 2025-05-15 17:01:21 --> Total execution time: 0.0634
INFO - 2025-05-15 17:01:22 --> Config Class Initialized
INFO - 2025-05-15 17:01:22 --> Hooks Class Initialized
DEBUG - 2025-05-15 17:01:22 --> UTF-8 Support Enabled
INFO - 2025-05-15 17:01:22 --> Utf8 Class Initialized
INFO - 2025-05-15 17:01:22 --> URI Class Initialized
INFO - 2025-05-15 17:01:22 --> Router Class Initialized
INFO - 2025-05-15 17:01:22 --> Output Class Initialized
INFO - 2025-05-15 17:01:22 --> Security Class Initialized
DEBUG - 2025-05-15 17:01:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 17:01:22 --> Input Class Initialized
INFO - 2025-05-15 17:01:22 --> Language Class Initialized
INFO - 2025-05-15 17:01:22 --> Loader Class Initialized
INFO - 2025-05-15 17:01:22 --> Helper loaded: url_helper
INFO - 2025-05-15 17:01:22 --> Helper loaded: form_helper
INFO - 2025-05-15 17:01:22 --> Database Driver Class Initialized
DEBUG - 2025-05-15 17:01:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 17:01:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 17:01:22 --> Controller Class Initialized
INFO - 2025-05-15 17:01:22 --> Model "Workout_model" initialized
INFO - 2025-05-15 17:01:22 --> Model "User_model" initialized
INFO - 2025-05-15 17:01:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 17:01:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 17:01:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-15 17:01:22 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 17:01:22 --> Final output sent to browser
DEBUG - 2025-05-15 17:01:22 --> Total execution time: 0.0605
INFO - 2025-05-15 17:01:23 --> Config Class Initialized
INFO - 2025-05-15 17:01:23 --> Hooks Class Initialized
DEBUG - 2025-05-15 17:01:23 --> UTF-8 Support Enabled
INFO - 2025-05-15 17:01:23 --> Utf8 Class Initialized
INFO - 2025-05-15 17:01:23 --> URI Class Initialized
INFO - 2025-05-15 17:01:23 --> Router Class Initialized
INFO - 2025-05-15 17:01:23 --> Output Class Initialized
INFO - 2025-05-15 17:01:23 --> Security Class Initialized
DEBUG - 2025-05-15 17:01:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 17:01:23 --> Input Class Initialized
INFO - 2025-05-15 17:01:23 --> Language Class Initialized
INFO - 2025-05-15 17:01:23 --> Loader Class Initialized
INFO - 2025-05-15 17:01:23 --> Helper loaded: url_helper
INFO - 2025-05-15 17:01:23 --> Helper loaded: form_helper
INFO - 2025-05-15 17:01:23 --> Database Driver Class Initialized
DEBUG - 2025-05-15 17:01:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 17:01:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 17:01:23 --> Controller Class Initialized
INFO - 2025-05-15 17:01:23 --> Model "Workout_model" initialized
INFO - 2025-05-15 17:01:23 --> Model "User_model" initialized
INFO - 2025-05-15 17:01:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 17:01:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 17:01:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga.php
INFO - 2025-05-15 17:01:23 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 17:01:23 --> Final output sent to browser
DEBUG - 2025-05-15 17:01:23 --> Total execution time: 0.0650
INFO - 2025-05-15 17:01:24 --> Config Class Initialized
INFO - 2025-05-15 17:01:24 --> Hooks Class Initialized
DEBUG - 2025-05-15 17:01:24 --> UTF-8 Support Enabled
INFO - 2025-05-15 17:01:24 --> Utf8 Class Initialized
INFO - 2025-05-15 17:01:24 --> URI Class Initialized
INFO - 2025-05-15 17:01:24 --> Router Class Initialized
INFO - 2025-05-15 17:01:24 --> Output Class Initialized
INFO - 2025-05-15 17:01:24 --> Security Class Initialized
DEBUG - 2025-05-15 17:01:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 17:01:24 --> Input Class Initialized
INFO - 2025-05-15 17:01:24 --> Language Class Initialized
INFO - 2025-05-15 17:01:24 --> Loader Class Initialized
INFO - 2025-05-15 17:01:24 --> Helper loaded: url_helper
INFO - 2025-05-15 17:01:24 --> Helper loaded: form_helper
INFO - 2025-05-15 17:01:24 --> Database Driver Class Initialized
DEBUG - 2025-05-15 17:01:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 17:01:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 17:01:24 --> Controller Class Initialized
INFO - 2025-05-15 17:01:24 --> Model "User_model" initialized
INFO - 2025-05-15 17:01:24 --> Model "Community_model" initialized
INFO - 2025-05-15 17:01:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 17:01:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 17:01:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/community.php
INFO - 2025-05-15 17:01:24 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 17:01:24 --> Final output sent to browser
DEBUG - 2025-05-15 17:01:24 --> Total execution time: 0.0646
INFO - 2025-05-15 17:01:26 --> Config Class Initialized
INFO - 2025-05-15 17:01:26 --> Hooks Class Initialized
DEBUG - 2025-05-15 17:01:26 --> UTF-8 Support Enabled
INFO - 2025-05-15 17:01:26 --> Utf8 Class Initialized
INFO - 2025-05-15 17:01:26 --> URI Class Initialized
INFO - 2025-05-15 17:01:26 --> Router Class Initialized
INFO - 2025-05-15 17:01:26 --> Output Class Initialized
INFO - 2025-05-15 17:01:26 --> Security Class Initialized
DEBUG - 2025-05-15 17:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 17:01:26 --> Input Class Initialized
INFO - 2025-05-15 17:01:26 --> Language Class Initialized
INFO - 2025-05-15 17:01:26 --> Loader Class Initialized
INFO - 2025-05-15 17:01:26 --> Helper loaded: url_helper
INFO - 2025-05-15 17:01:26 --> Helper loaded: form_helper
INFO - 2025-05-15 17:01:26 --> Database Driver Class Initialized
DEBUG - 2025-05-15 17:01:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 17:01:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 17:01:26 --> Controller Class Initialized
INFO - 2025-05-15 17:01:26 --> Model "User_model" initialized
INFO - 2025-05-15 17:01:26 --> Model "Workout_model" initialized
INFO - 2025-05-15 17:01:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 17:01:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 17:01:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/guide.php
INFO - 2025-05-15 17:01:26 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 17:01:26 --> Final output sent to browser
DEBUG - 2025-05-15 17:01:26 --> Total execution time: 0.0586
INFO - 2025-05-15 17:01:27 --> Config Class Initialized
INFO - 2025-05-15 17:01:27 --> Hooks Class Initialized
DEBUG - 2025-05-15 17:01:27 --> UTF-8 Support Enabled
INFO - 2025-05-15 17:01:27 --> Utf8 Class Initialized
INFO - 2025-05-15 17:01:27 --> URI Class Initialized
INFO - 2025-05-15 17:01:27 --> Router Class Initialized
INFO - 2025-05-15 17:01:27 --> Output Class Initialized
INFO - 2025-05-15 17:01:27 --> Security Class Initialized
DEBUG - 2025-05-15 17:01:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 17:01:27 --> Input Class Initialized
INFO - 2025-05-15 17:01:27 --> Language Class Initialized
INFO - 2025-05-15 17:01:27 --> Loader Class Initialized
INFO - 2025-05-15 17:01:27 --> Helper loaded: url_helper
INFO - 2025-05-15 17:01:27 --> Helper loaded: form_helper
INFO - 2025-05-15 17:01:27 --> Database Driver Class Initialized
DEBUG - 2025-05-15 17:01:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 17:01:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 17:01:27 --> Controller Class Initialized
INFO - 2025-05-15 17:01:27 --> Model "User_model" initialized
INFO - 2025-05-15 17:01:27 --> Model "Workout_model" initialized
INFO - 2025-05-15 17:01:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 17:01:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 17:01:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-15 17:01:27 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 17:01:27 --> Final output sent to browser
DEBUG - 2025-05-15 17:01:27 --> Total execution time: 0.0577
INFO - 2025-05-15 17:01:28 --> Config Class Initialized
INFO - 2025-05-15 17:01:28 --> Hooks Class Initialized
DEBUG - 2025-05-15 17:01:28 --> UTF-8 Support Enabled
INFO - 2025-05-15 17:01:28 --> Utf8 Class Initialized
INFO - 2025-05-15 17:01:28 --> URI Class Initialized
INFO - 2025-05-15 17:01:28 --> Router Class Initialized
INFO - 2025-05-15 17:01:28 --> Output Class Initialized
INFO - 2025-05-15 17:01:28 --> Security Class Initialized
DEBUG - 2025-05-15 17:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 17:01:28 --> Input Class Initialized
INFO - 2025-05-15 17:01:28 --> Language Class Initialized
INFO - 2025-05-15 17:01:28 --> Loader Class Initialized
INFO - 2025-05-15 17:01:28 --> Helper loaded: url_helper
INFO - 2025-05-15 17:01:28 --> Helper loaded: form_helper
INFO - 2025-05-15 17:01:28 --> Database Driver Class Initialized
DEBUG - 2025-05-15 17:01:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 17:01:28 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 17:01:28 --> Controller Class Initialized
INFO - 2025-05-15 17:01:28 --> Model "Workout_model" initialized
INFO - 2025-05-15 17:01:28 --> Model "User_model" initialized
INFO - 2025-05-15 17:01:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 17:01:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 17:01:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-15 17:01:28 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 17:01:28 --> Final output sent to browser
DEBUG - 2025-05-15 17:01:28 --> Total execution time: 0.0607
INFO - 2025-05-15 17:01:30 --> Config Class Initialized
INFO - 2025-05-15 17:01:30 --> Hooks Class Initialized
DEBUG - 2025-05-15 17:01:30 --> UTF-8 Support Enabled
INFO - 2025-05-15 17:01:30 --> Utf8 Class Initialized
INFO - 2025-05-15 17:01:30 --> URI Class Initialized
INFO - 2025-05-15 17:01:30 --> Router Class Initialized
INFO - 2025-05-15 17:01:30 --> Output Class Initialized
INFO - 2025-05-15 17:01:30 --> Security Class Initialized
DEBUG - 2025-05-15 17:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 17:01:30 --> Input Class Initialized
INFO - 2025-05-15 17:01:30 --> Language Class Initialized
INFO - 2025-05-15 17:01:30 --> Loader Class Initialized
INFO - 2025-05-15 17:01:30 --> Helper loaded: url_helper
INFO - 2025-05-15 17:01:30 --> Helper loaded: form_helper
INFO - 2025-05-15 17:01:30 --> Database Driver Class Initialized
DEBUG - 2025-05-15 17:01:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 17:01:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 17:01:30 --> Controller Class Initialized
INFO - 2025-05-15 17:01:30 --> Model "User_model" initialized
INFO - 2025-05-15 17:01:30 --> Model "Workout_model" initialized
INFO - 2025-05-15 17:01:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 17:01:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 17:01:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-15 17:01:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 17:01:30 --> Final output sent to browser
DEBUG - 2025-05-15 17:01:30 --> Total execution time: 0.0715
INFO - 2025-05-15 17:02:04 --> Config Class Initialized
INFO - 2025-05-15 17:02:04 --> Hooks Class Initialized
DEBUG - 2025-05-15 17:02:04 --> UTF-8 Support Enabled
INFO - 2025-05-15 17:02:04 --> Utf8 Class Initialized
INFO - 2025-05-15 17:02:04 --> URI Class Initialized
INFO - 2025-05-15 17:02:04 --> Router Class Initialized
INFO - 2025-05-15 17:02:04 --> Output Class Initialized
INFO - 2025-05-15 17:02:04 --> Security Class Initialized
DEBUG - 2025-05-15 17:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 17:02:04 --> Input Class Initialized
INFO - 2025-05-15 17:02:04 --> Language Class Initialized
INFO - 2025-05-15 17:02:04 --> Loader Class Initialized
INFO - 2025-05-15 17:02:04 --> Helper loaded: url_helper
INFO - 2025-05-15 17:02:04 --> Helper loaded: form_helper
INFO - 2025-05-15 17:02:04 --> Database Driver Class Initialized
DEBUG - 2025-05-15 17:02:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 17:02:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 17:02:04 --> Controller Class Initialized
INFO - 2025-05-15 17:02:04 --> Model "User_model" initialized
INFO - 2025-05-15 17:02:04 --> Model "Workout_model" initialized
INFO - 2025-05-15 17:02:04 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 17:02:04 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 17:02:04 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-15 17:02:04 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 17:02:04 --> Final output sent to browser
DEBUG - 2025-05-15 17:02:04 --> Total execution time: 0.0773
INFO - 2025-05-15 17:02:09 --> Config Class Initialized
INFO - 2025-05-15 17:02:09 --> Hooks Class Initialized
DEBUG - 2025-05-15 17:02:09 --> UTF-8 Support Enabled
INFO - 2025-05-15 17:02:09 --> Utf8 Class Initialized
INFO - 2025-05-15 17:02:09 --> URI Class Initialized
INFO - 2025-05-15 17:02:09 --> Router Class Initialized
INFO - 2025-05-15 17:02:09 --> Output Class Initialized
INFO - 2025-05-15 17:02:09 --> Security Class Initialized
DEBUG - 2025-05-15 17:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 17:02:09 --> Input Class Initialized
INFO - 2025-05-15 17:02:09 --> Language Class Initialized
INFO - 2025-05-15 17:02:09 --> Loader Class Initialized
INFO - 2025-05-15 17:02:09 --> Helper loaded: url_helper
INFO - 2025-05-15 17:02:09 --> Helper loaded: form_helper
INFO - 2025-05-15 17:02:09 --> Database Driver Class Initialized
DEBUG - 2025-05-15 17:02:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 17:02:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 17:02:09 --> Controller Class Initialized
INFO - 2025-05-15 17:02:09 --> Model "User_model" initialized
INFO - 2025-05-15 17:02:09 --> Model "Workout_model" initialized
INFO - 2025-05-15 17:02:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 17:02:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 17:02:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-15 17:02:09 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 17:02:09 --> Final output sent to browser
DEBUG - 2025-05-15 17:02:09 --> Total execution time: 0.0859
INFO - 2025-05-15 17:02:12 --> Config Class Initialized
INFO - 2025-05-15 17:02:12 --> Hooks Class Initialized
DEBUG - 2025-05-15 17:02:12 --> UTF-8 Support Enabled
INFO - 2025-05-15 17:02:12 --> Utf8 Class Initialized
INFO - 2025-05-15 17:02:12 --> URI Class Initialized
INFO - 2025-05-15 17:02:12 --> Router Class Initialized
INFO - 2025-05-15 17:02:12 --> Output Class Initialized
INFO - 2025-05-15 17:02:12 --> Security Class Initialized
DEBUG - 2025-05-15 17:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 17:02:12 --> Input Class Initialized
INFO - 2025-05-15 17:02:12 --> Language Class Initialized
INFO - 2025-05-15 17:02:12 --> Loader Class Initialized
INFO - 2025-05-15 17:02:12 --> Helper loaded: url_helper
INFO - 2025-05-15 17:02:12 --> Helper loaded: form_helper
INFO - 2025-05-15 17:02:12 --> Database Driver Class Initialized
DEBUG - 2025-05-15 17:02:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 17:02:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 17:02:12 --> Controller Class Initialized
INFO - 2025-05-15 17:02:12 --> Model "Workout_model" initialized
INFO - 2025-05-15 17:02:12 --> Model "User_model" initialized
INFO - 2025-05-15 17:02:12 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 17:02:12 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 17:02:12 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga.php
INFO - 2025-05-15 17:02:12 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 17:02:12 --> Final output sent to browser
DEBUG - 2025-05-15 17:02:12 --> Total execution time: 0.0680
INFO - 2025-05-15 17:02:31 --> Config Class Initialized
INFO - 2025-05-15 17:02:31 --> Hooks Class Initialized
DEBUG - 2025-05-15 17:02:31 --> UTF-8 Support Enabled
INFO - 2025-05-15 17:02:31 --> Utf8 Class Initialized
INFO - 2025-05-15 17:02:31 --> URI Class Initialized
INFO - 2025-05-15 17:02:31 --> Router Class Initialized
INFO - 2025-05-15 17:02:31 --> Output Class Initialized
INFO - 2025-05-15 17:02:31 --> Security Class Initialized
DEBUG - 2025-05-15 17:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 17:02:31 --> Input Class Initialized
INFO - 2025-05-15 17:02:31 --> Language Class Initialized
INFO - 2025-05-15 17:02:31 --> Loader Class Initialized
INFO - 2025-05-15 17:02:31 --> Helper loaded: url_helper
INFO - 2025-05-15 17:02:31 --> Helper loaded: form_helper
INFO - 2025-05-15 17:02:31 --> Database Driver Class Initialized
DEBUG - 2025-05-15 17:02:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 17:02:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 17:02:31 --> Controller Class Initialized
INFO - 2025-05-15 17:02:31 --> Model "Workout_model" initialized
INFO - 2025-05-15 17:02:31 --> Model "User_model" initialized
INFO - 2025-05-15 17:02:31 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 17:02:31 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 17:02:31 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga.php
INFO - 2025-05-15 17:02:31 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 17:02:31 --> Final output sent to browser
DEBUG - 2025-05-15 17:02:31 --> Total execution time: 0.0607
INFO - 2025-05-15 17:03:30 --> Config Class Initialized
INFO - 2025-05-15 17:03:30 --> Hooks Class Initialized
DEBUG - 2025-05-15 17:03:30 --> UTF-8 Support Enabled
INFO - 2025-05-15 17:03:30 --> Utf8 Class Initialized
INFO - 2025-05-15 17:03:30 --> URI Class Initialized
INFO - 2025-05-15 17:03:30 --> Router Class Initialized
INFO - 2025-05-15 17:03:30 --> Output Class Initialized
INFO - 2025-05-15 17:03:30 --> Security Class Initialized
DEBUG - 2025-05-15 17:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 17:03:30 --> Input Class Initialized
INFO - 2025-05-15 17:03:30 --> Language Class Initialized
INFO - 2025-05-15 17:03:30 --> Loader Class Initialized
INFO - 2025-05-15 17:03:30 --> Helper loaded: url_helper
INFO - 2025-05-15 17:03:30 --> Helper loaded: form_helper
INFO - 2025-05-15 17:03:30 --> Database Driver Class Initialized
DEBUG - 2025-05-15 17:03:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 17:03:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 17:03:30 --> Controller Class Initialized
INFO - 2025-05-15 17:03:30 --> Model "Workout_model" initialized
INFO - 2025-05-15 17:03:30 --> Model "User_model" initialized
INFO - 2025-05-15 17:03:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 17:03:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 17:03:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga.php
INFO - 2025-05-15 17:03:30 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 17:03:30 --> Final output sent to browser
DEBUG - 2025-05-15 17:03:30 --> Total execution time: 0.0777
INFO - 2025-05-15 17:03:34 --> Config Class Initialized
INFO - 2025-05-15 17:03:34 --> Hooks Class Initialized
DEBUG - 2025-05-15 17:03:34 --> UTF-8 Support Enabled
INFO - 2025-05-15 17:03:34 --> Utf8 Class Initialized
INFO - 2025-05-15 17:03:34 --> URI Class Initialized
INFO - 2025-05-15 17:03:34 --> Router Class Initialized
INFO - 2025-05-15 17:03:34 --> Output Class Initialized
INFO - 2025-05-15 17:03:34 --> Security Class Initialized
DEBUG - 2025-05-15 17:03:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 17:03:34 --> Input Class Initialized
INFO - 2025-05-15 17:03:34 --> Language Class Initialized
INFO - 2025-05-15 17:03:34 --> Loader Class Initialized
INFO - 2025-05-15 17:03:34 --> Helper loaded: url_helper
INFO - 2025-05-15 17:03:34 --> Helper loaded: form_helper
INFO - 2025-05-15 17:03:34 --> Database Driver Class Initialized
DEBUG - 2025-05-15 17:03:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 17:03:34 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 17:03:34 --> Controller Class Initialized
INFO - 2025-05-15 17:03:34 --> Model "Workout_model" initialized
INFO - 2025-05-15 17:03:34 --> Model "User_model" initialized
INFO - 2025-05-15 17:03:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 17:03:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 17:03:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga.php
INFO - 2025-05-15 17:03:34 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 17:03:34 --> Final output sent to browser
DEBUG - 2025-05-15 17:03:34 --> Total execution time: 0.0721
INFO - 2025-05-15 17:03:36 --> Config Class Initialized
INFO - 2025-05-15 17:03:36 --> Hooks Class Initialized
DEBUG - 2025-05-15 17:03:36 --> UTF-8 Support Enabled
INFO - 2025-05-15 17:03:36 --> Utf8 Class Initialized
INFO - 2025-05-15 17:03:36 --> URI Class Initialized
INFO - 2025-05-15 17:03:36 --> Router Class Initialized
INFO - 2025-05-15 17:03:36 --> Output Class Initialized
INFO - 2025-05-15 17:03:36 --> Security Class Initialized
DEBUG - 2025-05-15 17:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 17:03:36 --> Input Class Initialized
INFO - 2025-05-15 17:03:36 --> Language Class Initialized
INFO - 2025-05-15 17:03:36 --> Loader Class Initialized
INFO - 2025-05-15 17:03:36 --> Helper loaded: url_helper
INFO - 2025-05-15 17:03:36 --> Helper loaded: form_helper
INFO - 2025-05-15 17:03:36 --> Database Driver Class Initialized
DEBUG - 2025-05-15 17:03:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 17:03:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 17:03:36 --> Controller Class Initialized
INFO - 2025-05-15 17:03:36 --> Model "Workout_model" initialized
INFO - 2025-05-15 17:03:36 --> Model "User_model" initialized
INFO - 2025-05-15 17:03:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 17:03:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 17:03:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/jadwal_record.php
INFO - 2025-05-15 17:03:36 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 17:03:36 --> Final output sent to browser
DEBUG - 2025-05-15 17:03:36 --> Total execution time: 0.0597
INFO - 2025-05-15 17:03:40 --> Config Class Initialized
INFO - 2025-05-15 17:03:40 --> Hooks Class Initialized
DEBUG - 2025-05-15 17:03:40 --> UTF-8 Support Enabled
INFO - 2025-05-15 17:03:40 --> Utf8 Class Initialized
INFO - 2025-05-15 17:03:40 --> URI Class Initialized
INFO - 2025-05-15 17:03:40 --> Router Class Initialized
INFO - 2025-05-15 17:03:40 --> Output Class Initialized
INFO - 2025-05-15 17:03:40 --> Security Class Initialized
DEBUG - 2025-05-15 17:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 17:03:40 --> Input Class Initialized
INFO - 2025-05-15 17:03:40 --> Language Class Initialized
INFO - 2025-05-15 17:03:40 --> Loader Class Initialized
INFO - 2025-05-15 17:03:40 --> Helper loaded: url_helper
INFO - 2025-05-15 17:03:40 --> Helper loaded: form_helper
INFO - 2025-05-15 17:03:40 --> Database Driver Class Initialized
DEBUG - 2025-05-15 17:03:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 17:03:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 17:03:40 --> Controller Class Initialized
INFO - 2025-05-15 17:03:40 --> Model "Workout_model" initialized
INFO - 2025-05-15 17:03:40 --> Model "User_model" initialized
INFO - 2025-05-15 17:03:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 17:03:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 17:03:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/olahraga.php
INFO - 2025-05-15 17:03:40 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 17:03:40 --> Final output sent to browser
DEBUG - 2025-05-15 17:03:40 --> Total execution time: 0.0819
INFO - 2025-05-15 17:03:42 --> Config Class Initialized
INFO - 2025-05-15 17:03:42 --> Hooks Class Initialized
DEBUG - 2025-05-15 17:03:42 --> UTF-8 Support Enabled
INFO - 2025-05-15 17:03:42 --> Utf8 Class Initialized
INFO - 2025-05-15 17:03:42 --> URI Class Initialized
INFO - 2025-05-15 17:03:42 --> Router Class Initialized
INFO - 2025-05-15 17:03:42 --> Output Class Initialized
INFO - 2025-05-15 17:03:42 --> Security Class Initialized
DEBUG - 2025-05-15 17:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 17:03:42 --> Input Class Initialized
INFO - 2025-05-15 17:03:42 --> Language Class Initialized
INFO - 2025-05-15 17:03:42 --> Loader Class Initialized
INFO - 2025-05-15 17:03:42 --> Helper loaded: url_helper
INFO - 2025-05-15 17:03:42 --> Helper loaded: form_helper
INFO - 2025-05-15 17:03:42 --> Database Driver Class Initialized
DEBUG - 2025-05-15 17:03:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 17:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 17:03:42 --> Controller Class Initialized
INFO - 2025-05-15 17:03:42 --> Model "User_model" initialized
INFO - 2025-05-15 17:03:42 --> Model "Community_model" initialized
INFO - 2025-05-15 17:03:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 17:03:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 17:03:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/community.php
INFO - 2025-05-15 17:03:42 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 17:03:42 --> Final output sent to browser
DEBUG - 2025-05-15 17:03:42 --> Total execution time: 0.0831
INFO - 2025-05-15 17:03:48 --> Config Class Initialized
INFO - 2025-05-15 17:03:48 --> Hooks Class Initialized
DEBUG - 2025-05-15 17:03:48 --> UTF-8 Support Enabled
INFO - 2025-05-15 17:03:48 --> Utf8 Class Initialized
INFO - 2025-05-15 17:03:48 --> URI Class Initialized
INFO - 2025-05-15 17:03:48 --> Router Class Initialized
INFO - 2025-05-15 17:03:48 --> Output Class Initialized
INFO - 2025-05-15 17:03:48 --> Security Class Initialized
DEBUG - 2025-05-15 17:03:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 17:03:48 --> Input Class Initialized
INFO - 2025-05-15 17:03:48 --> Language Class Initialized
INFO - 2025-05-15 17:03:48 --> Loader Class Initialized
INFO - 2025-05-15 17:03:48 --> Helper loaded: url_helper
INFO - 2025-05-15 17:03:48 --> Helper loaded: form_helper
INFO - 2025-05-15 17:03:48 --> Database Driver Class Initialized
DEBUG - 2025-05-15 17:03:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 17:03:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 17:03:48 --> Controller Class Initialized
INFO - 2025-05-15 17:03:48 --> Model "User_model" initialized
INFO - 2025-05-15 17:03:48 --> Model "Workout_model" initialized
INFO - 2025-05-15 17:03:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 17:03:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 17:03:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-15 17:03:48 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 17:03:48 --> Final output sent to browser
DEBUG - 2025-05-15 17:03:48 --> Total execution time: 0.0603
INFO - 2025-05-15 17:03:53 --> Config Class Initialized
INFO - 2025-05-15 17:03:53 --> Hooks Class Initialized
DEBUG - 2025-05-15 17:03:53 --> UTF-8 Support Enabled
INFO - 2025-05-15 17:03:53 --> Utf8 Class Initialized
INFO - 2025-05-15 17:03:53 --> URI Class Initialized
INFO - 2025-05-15 17:03:53 --> Router Class Initialized
INFO - 2025-05-15 17:03:53 --> Output Class Initialized
INFO - 2025-05-15 17:03:53 --> Security Class Initialized
DEBUG - 2025-05-15 17:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-05-15 17:03:53 --> Input Class Initialized
INFO - 2025-05-15 17:03:53 --> Language Class Initialized
INFO - 2025-05-15 17:03:53 --> Loader Class Initialized
INFO - 2025-05-15 17:03:53 --> Helper loaded: url_helper
INFO - 2025-05-15 17:03:53 --> Helper loaded: form_helper
INFO - 2025-05-15 17:03:53 --> Database Driver Class Initialized
DEBUG - 2025-05-15 17:03:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-05-15 17:03:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-05-15 17:03:53 --> Controller Class Initialized
INFO - 2025-05-15 17:03:53 --> Model "User_model" initialized
INFO - 2025-05-15 17:03:53 --> Model "Workout_model" initialized
INFO - 2025-05-15 17:03:53 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/header.php
INFO - 2025-05-15 17:03:53 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/sidebar.php
INFO - 2025-05-15 17:03:53 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/dashboard.php
INFO - 2025-05-15 17:03:53 --> File loaded: C:\laragon\www\Project\fitnessrecord\application\views\dashboard/layout/footer.php
INFO - 2025-05-15 17:03:53 --> Final output sent to browser
DEBUG - 2025-05-15 17:03:53 --> Total execution time: 0.0899
