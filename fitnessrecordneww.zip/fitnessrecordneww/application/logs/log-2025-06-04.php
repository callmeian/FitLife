<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-06-04 05:05:50 --> Config Class Initialized
INFO - 2025-06-04 05:05:50 --> Hooks Class Initialized
DEBUG - 2025-06-04 05:05:50 --> UTF-8 Support Enabled
INFO - 2025-06-04 05:05:50 --> Utf8 Class Initialized
INFO - 2025-06-04 05:05:50 --> URI Class Initialized
DEBUG - 2025-06-04 05:05:50 --> No URI present. Default controller set.
INFO - 2025-06-04 05:05:50 --> Router Class Initialized
INFO - 2025-06-04 05:05:50 --> Output Class Initialized
INFO - 2025-06-04 05:05:51 --> Security Class Initialized
DEBUG - 2025-06-04 05:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-04 05:05:51 --> Input Class Initialized
INFO - 2025-06-04 05:05:51 --> Language Class Initialized
INFO - 2025-06-04 05:05:51 --> Loader Class Initialized
INFO - 2025-06-04 05:05:51 --> Helper loaded: url_helper
INFO - 2025-06-04 05:05:51 --> Helper loaded: form_helper
INFO - 2025-06-04 05:05:51 --> Database Driver Class Initialized
DEBUG - 2025-06-04 05:05:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-04 05:05:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-04 05:05:52 --> Controller Class Initialized
INFO - 2025-06-04 05:05:52 --> Model "User_model" initialized
INFO - 2025-06-04 05:05:52 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-06-04 05:05:52 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/home.php
INFO - 2025-06-04 05:05:52 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-06-04 05:05:52 --> Final output sent to browser
DEBUG - 2025-06-04 05:05:52 --> Total execution time: 2.4149
INFO - 2025-06-04 05:05:56 --> Config Class Initialized
INFO - 2025-06-04 05:05:56 --> Hooks Class Initialized
DEBUG - 2025-06-04 05:05:56 --> UTF-8 Support Enabled
INFO - 2025-06-04 05:05:56 --> Utf8 Class Initialized
INFO - 2025-06-04 05:05:56 --> URI Class Initialized
INFO - 2025-06-04 05:05:56 --> Router Class Initialized
INFO - 2025-06-04 05:05:56 --> Output Class Initialized
INFO - 2025-06-04 05:05:56 --> Security Class Initialized
DEBUG - 2025-06-04 05:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-04 05:05:56 --> Input Class Initialized
INFO - 2025-06-04 05:05:56 --> Language Class Initialized
INFO - 2025-06-04 05:05:56 --> Loader Class Initialized
INFO - 2025-06-04 05:05:56 --> Helper loaded: url_helper
INFO - 2025-06-04 05:05:56 --> Helper loaded: form_helper
INFO - 2025-06-04 05:05:56 --> Database Driver Class Initialized
DEBUG - 2025-06-04 05:05:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-04 05:05:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-04 05:05:56 --> Controller Class Initialized
INFO - 2025-06-04 05:05:56 --> Model "User_model" initialized
INFO - 2025-06-04 05:05:56 --> Form Validation Class Initialized
INFO - 2025-06-04 05:05:56 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\auth/login.php
INFO - 2025-06-04 05:05:56 --> Final output sent to browser
DEBUG - 2025-06-04 05:05:56 --> Total execution time: 0.3705
INFO - 2025-06-04 05:06:30 --> Config Class Initialized
INFO - 2025-06-04 05:06:30 --> Hooks Class Initialized
DEBUG - 2025-06-04 05:06:30 --> UTF-8 Support Enabled
INFO - 2025-06-04 05:06:30 --> Utf8 Class Initialized
INFO - 2025-06-04 05:06:30 --> URI Class Initialized
INFO - 2025-06-04 05:06:30 --> Router Class Initialized
INFO - 2025-06-04 05:06:30 --> Output Class Initialized
INFO - 2025-06-04 05:06:30 --> Security Class Initialized
DEBUG - 2025-06-04 05:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-04 05:06:30 --> Input Class Initialized
INFO - 2025-06-04 05:06:30 --> Language Class Initialized
INFO - 2025-06-04 05:06:30 --> Loader Class Initialized
INFO - 2025-06-04 05:06:30 --> Helper loaded: url_helper
INFO - 2025-06-04 05:06:30 --> Helper loaded: form_helper
INFO - 2025-06-04 05:06:30 --> Database Driver Class Initialized
DEBUG - 2025-06-04 05:06:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-04 05:06:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-04 05:06:30 --> Controller Class Initialized
INFO - 2025-06-04 05:06:30 --> Model "User_model" initialized
INFO - 2025-06-04 05:06:30 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-06-04 05:06:30 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/home.php
INFO - 2025-06-04 05:06:30 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-06-04 05:06:30 --> Final output sent to browser
DEBUG - 2025-06-04 05:06:30 --> Total execution time: 0.0768
INFO - 2025-06-04 05:06:33 --> Config Class Initialized
INFO - 2025-06-04 05:06:33 --> Hooks Class Initialized
DEBUG - 2025-06-04 05:06:33 --> UTF-8 Support Enabled
INFO - 2025-06-04 05:06:33 --> Utf8 Class Initialized
INFO - 2025-06-04 05:06:33 --> URI Class Initialized
INFO - 2025-06-04 05:06:33 --> Router Class Initialized
INFO - 2025-06-04 05:06:33 --> Output Class Initialized
INFO - 2025-06-04 05:06:33 --> Security Class Initialized
DEBUG - 2025-06-04 05:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-04 05:06:33 --> Input Class Initialized
INFO - 2025-06-04 05:06:33 --> Language Class Initialized
INFO - 2025-06-04 05:06:33 --> Loader Class Initialized
INFO - 2025-06-04 05:06:33 --> Helper loaded: url_helper
INFO - 2025-06-04 05:06:33 --> Helper loaded: form_helper
INFO - 2025-06-04 05:06:33 --> Database Driver Class Initialized
DEBUG - 2025-06-04 05:06:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-04 05:06:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-04 05:06:33 --> Controller Class Initialized
INFO - 2025-06-04 05:06:33 --> Model "User_model" initialized
INFO - 2025-06-04 05:06:33 --> Form Validation Class Initialized
INFO - 2025-06-04 05:06:33 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\auth/login.php
INFO - 2025-06-04 05:06:33 --> Final output sent to browser
DEBUG - 2025-06-04 05:06:33 --> Total execution time: 0.0939
INFO - 2025-06-04 05:06:42 --> Config Class Initialized
INFO - 2025-06-04 05:06:42 --> Hooks Class Initialized
DEBUG - 2025-06-04 05:06:42 --> UTF-8 Support Enabled
INFO - 2025-06-04 05:06:42 --> Utf8 Class Initialized
INFO - 2025-06-04 05:06:42 --> URI Class Initialized
INFO - 2025-06-04 05:06:42 --> Router Class Initialized
INFO - 2025-06-04 05:06:42 --> Output Class Initialized
INFO - 2025-06-04 05:06:42 --> Security Class Initialized
DEBUG - 2025-06-04 05:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-04 05:06:42 --> Input Class Initialized
INFO - 2025-06-04 05:06:42 --> Language Class Initialized
INFO - 2025-06-04 05:06:42 --> Loader Class Initialized
INFO - 2025-06-04 05:06:42 --> Helper loaded: url_helper
INFO - 2025-06-04 05:06:42 --> Helper loaded: form_helper
INFO - 2025-06-04 05:06:42 --> Database Driver Class Initialized
DEBUG - 2025-06-04 05:06:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-04 05:06:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-04 05:06:42 --> Controller Class Initialized
INFO - 2025-06-04 05:06:42 --> Model "User_model" initialized
INFO - 2025-06-04 05:06:42 --> Form Validation Class Initialized
DEBUG - 2025-06-04 05:06:42 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-06-04 05:06:42 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\auth/register.php
INFO - 2025-06-04 05:06:42 --> Final output sent to browser
DEBUG - 2025-06-04 05:06:42 --> Total execution time: 0.1510
INFO - 2025-06-04 05:10:47 --> Config Class Initialized
INFO - 2025-06-04 05:10:47 --> Hooks Class Initialized
DEBUG - 2025-06-04 05:10:47 --> UTF-8 Support Enabled
INFO - 2025-06-04 05:10:47 --> Utf8 Class Initialized
INFO - 2025-06-04 05:10:47 --> URI Class Initialized
INFO - 2025-06-04 05:10:47 --> Router Class Initialized
INFO - 2025-06-04 05:10:47 --> Output Class Initialized
INFO - 2025-06-04 05:10:47 --> Security Class Initialized
DEBUG - 2025-06-04 05:10:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-04 05:10:47 --> Input Class Initialized
INFO - 2025-06-04 05:10:47 --> Language Class Initialized
INFO - 2025-06-04 05:10:47 --> Loader Class Initialized
INFO - 2025-06-04 05:10:47 --> Helper loaded: url_helper
INFO - 2025-06-04 05:10:47 --> Helper loaded: form_helper
INFO - 2025-06-04 05:10:47 --> Database Driver Class Initialized
DEBUG - 2025-06-04 05:10:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-04 05:10:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-04 05:10:47 --> Controller Class Initialized
INFO - 2025-06-04 05:10:47 --> Model "User_model" initialized
INFO - 2025-06-04 05:10:47 --> Form Validation Class Initialized
INFO - 2025-06-04 05:10:47 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\auth/login.php
INFO - 2025-06-04 05:10:47 --> Final output sent to browser
DEBUG - 2025-06-04 05:10:47 --> Total execution time: 0.0798
INFO - 2025-06-04 05:30:04 --> Config Class Initialized
INFO - 2025-06-04 05:30:04 --> Hooks Class Initialized
DEBUG - 2025-06-04 05:30:04 --> UTF-8 Support Enabled
INFO - 2025-06-04 05:30:04 --> Utf8 Class Initialized
INFO - 2025-06-04 05:30:04 --> URI Class Initialized
INFO - 2025-06-04 05:30:04 --> Router Class Initialized
INFO - 2025-06-04 05:30:04 --> Output Class Initialized
INFO - 2025-06-04 05:30:04 --> Security Class Initialized
DEBUG - 2025-06-04 05:30:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-04 05:30:04 --> Input Class Initialized
INFO - 2025-06-04 05:30:04 --> Language Class Initialized
INFO - 2025-06-04 05:30:04 --> Loader Class Initialized
INFO - 2025-06-04 05:30:04 --> Helper loaded: url_helper
INFO - 2025-06-04 05:30:04 --> Helper loaded: form_helper
INFO - 2025-06-04 05:30:04 --> Database Driver Class Initialized
DEBUG - 2025-06-04 05:30:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-04 05:30:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-04 05:30:04 --> Controller Class Initialized
INFO - 2025-06-04 05:30:04 --> Model "User_model" initialized
INFO - 2025-06-04 05:30:04 --> Form Validation Class Initialized
INFO - 2025-06-04 05:30:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-06-04 05:30:05 --> Config Class Initialized
INFO - 2025-06-04 05:30:05 --> Hooks Class Initialized
DEBUG - 2025-06-04 05:30:05 --> UTF-8 Support Enabled
INFO - 2025-06-04 05:30:05 --> Utf8 Class Initialized
INFO - 2025-06-04 05:30:05 --> URI Class Initialized
INFO - 2025-06-04 05:30:05 --> Router Class Initialized
INFO - 2025-06-04 05:30:05 --> Output Class Initialized
INFO - 2025-06-04 05:30:05 --> Security Class Initialized
DEBUG - 2025-06-04 05:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-04 05:30:05 --> Input Class Initialized
INFO - 2025-06-04 05:30:05 --> Language Class Initialized
INFO - 2025-06-04 05:30:05 --> Loader Class Initialized
INFO - 2025-06-04 05:30:05 --> Helper loaded: url_helper
INFO - 2025-06-04 05:30:05 --> Helper loaded: form_helper
INFO - 2025-06-04 05:30:05 --> Database Driver Class Initialized
DEBUG - 2025-06-04 05:30:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-04 05:30:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-04 05:30:05 --> Controller Class Initialized
INFO - 2025-06-04 05:30:05 --> Model "User_model" initialized
INFO - 2025-06-04 05:30:05 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-06-04 05:30:05 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/home.php
INFO - 2025-06-04 05:30:05 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-06-04 05:30:05 --> Final output sent to browser
DEBUG - 2025-06-04 05:30:05 --> Total execution time: 0.0819
INFO - 2025-06-04 05:30:12 --> Config Class Initialized
INFO - 2025-06-04 05:30:12 --> Hooks Class Initialized
DEBUG - 2025-06-04 05:30:12 --> UTF-8 Support Enabled
INFO - 2025-06-04 05:30:12 --> Utf8 Class Initialized
INFO - 2025-06-04 05:30:12 --> URI Class Initialized
INFO - 2025-06-04 05:30:12 --> Router Class Initialized
INFO - 2025-06-04 05:30:12 --> Output Class Initialized
INFO - 2025-06-04 05:30:12 --> Security Class Initialized
DEBUG - 2025-06-04 05:30:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-04 05:30:12 --> Input Class Initialized
INFO - 2025-06-04 05:30:12 --> Language Class Initialized
INFO - 2025-06-04 05:30:12 --> Loader Class Initialized
INFO - 2025-06-04 05:30:12 --> Helper loaded: url_helper
INFO - 2025-06-04 05:30:12 --> Helper loaded: form_helper
INFO - 2025-06-04 05:30:12 --> Database Driver Class Initialized
DEBUG - 2025-06-04 05:30:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-04 05:30:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-04 05:30:13 --> Controller Class Initialized
INFO - 2025-06-04 05:30:13 --> Model "User_model" initialized
INFO - 2025-06-04 05:30:13 --> Model "Progress_model" initialized
INFO - 2025-06-04 05:30:13 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-04 05:30:13 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-04 05:30:13 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/dashboard.php
INFO - 2025-06-04 05:30:13 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-04 05:30:13 --> Final output sent to browser
DEBUG - 2025-06-04 05:30:13 --> Total execution time: 0.5784
INFO - 2025-06-04 05:30:16 --> Config Class Initialized
INFO - 2025-06-04 05:30:16 --> Hooks Class Initialized
DEBUG - 2025-06-04 05:30:16 --> UTF-8 Support Enabled
INFO - 2025-06-04 05:30:16 --> Utf8 Class Initialized
INFO - 2025-06-04 05:30:16 --> URI Class Initialized
INFO - 2025-06-04 05:30:16 --> Router Class Initialized
INFO - 2025-06-04 05:30:16 --> Output Class Initialized
INFO - 2025-06-04 05:30:16 --> Security Class Initialized
DEBUG - 2025-06-04 05:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-04 05:30:16 --> Input Class Initialized
INFO - 2025-06-04 05:30:16 --> Language Class Initialized
INFO - 2025-06-04 05:30:16 --> Loader Class Initialized
INFO - 2025-06-04 05:30:16 --> Helper loaded: url_helper
INFO - 2025-06-04 05:30:16 --> Helper loaded: form_helper
INFO - 2025-06-04 05:30:16 --> Database Driver Class Initialized
DEBUG - 2025-06-04 05:30:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-04 05:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-04 05:30:16 --> Controller Class Initialized
INFO - 2025-06-04 05:30:16 --> Model "User_model" initialized
INFO - 2025-06-04 05:30:16 --> Model "Progress_model" initialized
INFO - 2025-06-04 05:30:16 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-04 05:30:16 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-04 05:30:16 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/dashboard.php
INFO - 2025-06-04 05:30:16 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-04 05:30:16 --> Final output sent to browser
DEBUG - 2025-06-04 05:30:16 --> Total execution time: 0.0834
INFO - 2025-06-04 05:30:22 --> Config Class Initialized
INFO - 2025-06-04 05:30:22 --> Hooks Class Initialized
DEBUG - 2025-06-04 05:30:22 --> UTF-8 Support Enabled
INFO - 2025-06-04 05:30:22 --> Utf8 Class Initialized
INFO - 2025-06-04 05:30:22 --> URI Class Initialized
INFO - 2025-06-04 05:30:22 --> Router Class Initialized
INFO - 2025-06-04 05:30:22 --> Output Class Initialized
INFO - 2025-06-04 05:30:22 --> Security Class Initialized
DEBUG - 2025-06-04 05:30:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-04 05:30:22 --> Input Class Initialized
INFO - 2025-06-04 05:30:22 --> Language Class Initialized
INFO - 2025-06-04 05:30:22 --> Loader Class Initialized
INFO - 2025-06-04 05:30:22 --> Helper loaded: url_helper
INFO - 2025-06-04 05:30:22 --> Helper loaded: form_helper
INFO - 2025-06-04 05:30:22 --> Database Driver Class Initialized
DEBUG - 2025-06-04 05:30:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-04 05:30:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-04 05:30:22 --> Controller Class Initialized
INFO - 2025-06-04 05:30:22 --> Model "User_model" initialized
INFO - 2025-06-04 05:30:22 --> Model "Progress_model" initialized
INFO - 2025-06-04 05:30:22 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-04 05:30:22 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-04 05:30:22 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/guide.php
INFO - 2025-06-04 05:30:22 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-04 05:30:22 --> Final output sent to browser
DEBUG - 2025-06-04 05:30:22 --> Total execution time: 0.1145
INFO - 2025-06-04 05:30:23 --> Config Class Initialized
INFO - 2025-06-04 05:30:23 --> Hooks Class Initialized
DEBUG - 2025-06-04 05:30:23 --> UTF-8 Support Enabled
INFO - 2025-06-04 05:30:23 --> Utf8 Class Initialized
INFO - 2025-06-04 05:30:23 --> URI Class Initialized
INFO - 2025-06-04 05:30:23 --> Router Class Initialized
INFO - 2025-06-04 05:30:23 --> Output Class Initialized
INFO - 2025-06-04 05:30:23 --> Security Class Initialized
DEBUG - 2025-06-04 05:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-04 05:30:23 --> Input Class Initialized
INFO - 2025-06-04 05:30:23 --> Language Class Initialized
INFO - 2025-06-04 05:30:23 --> Loader Class Initialized
INFO - 2025-06-04 05:30:23 --> Helper loaded: url_helper
INFO - 2025-06-04 05:30:23 --> Helper loaded: form_helper
INFO - 2025-06-04 05:30:23 --> Database Driver Class Initialized
DEBUG - 2025-06-04 05:30:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-04 05:30:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-04 05:30:23 --> Controller Class Initialized
INFO - 2025-06-04 05:30:23 --> Model "User_model" initialized
INFO - 2025-06-04 05:30:23 --> Model "Progress_model" initialized
INFO - 2025-06-04 05:30:23 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-04 05:30:23 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-04 05:30:23 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/dashboard.php
INFO - 2025-06-04 05:30:23 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-04 05:30:23 --> Final output sent to browser
DEBUG - 2025-06-04 05:30:23 --> Total execution time: 0.0861
INFO - 2025-06-04 05:41:02 --> Config Class Initialized
INFO - 2025-06-04 05:41:02 --> Hooks Class Initialized
DEBUG - 2025-06-04 05:41:02 --> UTF-8 Support Enabled
INFO - 2025-06-04 05:41:02 --> Utf8 Class Initialized
INFO - 2025-06-04 05:41:02 --> URI Class Initialized
INFO - 2025-06-04 05:41:02 --> Router Class Initialized
INFO - 2025-06-04 05:41:02 --> Output Class Initialized
INFO - 2025-06-04 05:41:02 --> Security Class Initialized
DEBUG - 2025-06-04 05:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-04 05:41:02 --> Input Class Initialized
INFO - 2025-06-04 05:41:02 --> Language Class Initialized
INFO - 2025-06-04 05:41:02 --> Loader Class Initialized
INFO - 2025-06-04 05:41:02 --> Helper loaded: url_helper
INFO - 2025-06-04 05:41:02 --> Helper loaded: form_helper
INFO - 2025-06-04 05:41:02 --> Database Driver Class Initialized
DEBUG - 2025-06-04 05:41:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-04 05:41:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-04 05:41:02 --> Controller Class Initialized
INFO - 2025-06-04 05:41:02 --> Model "User_model" initialized
INFO - 2025-06-04 05:41:02 --> Model "Progress_model" initialized
INFO - 2025-06-04 05:41:02 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-04 05:41:02 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-04 05:41:02 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/guide.php
INFO - 2025-06-04 05:41:02 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-04 05:41:02 --> Final output sent to browser
DEBUG - 2025-06-04 05:41:02 --> Total execution time: 0.0865
INFO - 2025-06-04 05:41:04 --> Config Class Initialized
INFO - 2025-06-04 05:41:04 --> Hooks Class Initialized
DEBUG - 2025-06-04 05:41:04 --> UTF-8 Support Enabled
INFO - 2025-06-04 05:41:04 --> Utf8 Class Initialized
INFO - 2025-06-04 05:41:04 --> URI Class Initialized
INFO - 2025-06-04 05:41:04 --> Router Class Initialized
INFO - 2025-06-04 05:41:04 --> Output Class Initialized
INFO - 2025-06-04 05:41:04 --> Security Class Initialized
DEBUG - 2025-06-04 05:41:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-04 05:41:04 --> Input Class Initialized
INFO - 2025-06-04 05:41:04 --> Language Class Initialized
INFO - 2025-06-04 05:41:04 --> Loader Class Initialized
INFO - 2025-06-04 05:41:04 --> Helper loaded: url_helper
INFO - 2025-06-04 05:41:04 --> Helper loaded: form_helper
INFO - 2025-06-04 05:41:04 --> Database Driver Class Initialized
DEBUG - 2025-06-04 05:41:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-04 05:41:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-04 05:41:04 --> Controller Class Initialized
INFO - 2025-06-04 05:41:04 --> Model "User_model" initialized
INFO - 2025-06-04 05:41:04 --> Model "Progress_model" initialized
INFO - 2025-06-04 05:41:04 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-04 05:41:04 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-04 05:41:04 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/dashboard.php
INFO - 2025-06-04 05:41:04 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-04 05:41:04 --> Final output sent to browser
DEBUG - 2025-06-04 05:41:04 --> Total execution time: 0.0860
INFO - 2025-06-04 05:41:14 --> Config Class Initialized
INFO - 2025-06-04 05:41:14 --> Hooks Class Initialized
DEBUG - 2025-06-04 05:41:14 --> UTF-8 Support Enabled
INFO - 2025-06-04 05:41:14 --> Utf8 Class Initialized
INFO - 2025-06-04 05:41:14 --> URI Class Initialized
INFO - 2025-06-04 05:41:14 --> Router Class Initialized
INFO - 2025-06-04 05:41:14 --> Output Class Initialized
INFO - 2025-06-04 05:41:14 --> Security Class Initialized
DEBUG - 2025-06-04 05:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-04 05:41:14 --> Input Class Initialized
INFO - 2025-06-04 05:41:14 --> Language Class Initialized
INFO - 2025-06-04 05:41:14 --> Loader Class Initialized
INFO - 2025-06-04 05:41:14 --> Helper loaded: url_helper
INFO - 2025-06-04 05:41:14 --> Helper loaded: form_helper
INFO - 2025-06-04 05:41:14 --> Database Driver Class Initialized
DEBUG - 2025-06-04 05:41:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-04 05:41:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-04 05:41:14 --> Controller Class Initialized
INFO - 2025-06-04 05:41:14 --> Model "User_model" initialized
INFO - 2025-06-04 05:41:14 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-06-04 05:41:14 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/home.php
INFO - 2025-06-04 05:41:14 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-06-04 05:41:14 --> Final output sent to browser
DEBUG - 2025-06-04 05:41:14 --> Total execution time: 0.0834
INFO - 2025-06-04 07:14:40 --> Config Class Initialized
INFO - 2025-06-04 07:14:40 --> Hooks Class Initialized
DEBUG - 2025-06-04 07:14:40 --> UTF-8 Support Enabled
INFO - 2025-06-04 07:14:40 --> Utf8 Class Initialized
INFO - 2025-06-04 07:14:40 --> URI Class Initialized
INFO - 2025-06-04 07:14:40 --> Router Class Initialized
INFO - 2025-06-04 07:14:40 --> Output Class Initialized
INFO - 2025-06-04 07:14:40 --> Security Class Initialized
DEBUG - 2025-06-04 07:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-04 07:14:40 --> Input Class Initialized
INFO - 2025-06-04 07:14:40 --> Language Class Initialized
INFO - 2025-06-04 07:14:40 --> Loader Class Initialized
INFO - 2025-06-04 07:14:40 --> Helper loaded: url_helper
INFO - 2025-06-04 07:14:40 --> Helper loaded: form_helper
INFO - 2025-06-04 07:14:40 --> Database Driver Class Initialized
DEBUG - 2025-06-04 07:14:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-04 07:14:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-04 07:14:40 --> Controller Class Initialized
INFO - 2025-06-04 07:14:40 --> Model "User_model" initialized
INFO - 2025-06-04 07:14:40 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-06-04 07:14:40 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/home.php
INFO - 2025-06-04 07:14:40 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-06-04 07:14:40 --> Final output sent to browser
DEBUG - 2025-06-04 07:14:40 --> Total execution time: 0.0802
INFO - 2025-06-04 07:14:49 --> Config Class Initialized
INFO - 2025-06-04 07:14:49 --> Hooks Class Initialized
DEBUG - 2025-06-04 07:14:49 --> UTF-8 Support Enabled
INFO - 2025-06-04 07:14:49 --> Utf8 Class Initialized
INFO - 2025-06-04 07:14:49 --> URI Class Initialized
INFO - 2025-06-04 07:14:49 --> Router Class Initialized
INFO - 2025-06-04 07:14:49 --> Output Class Initialized
INFO - 2025-06-04 07:14:49 --> Security Class Initialized
DEBUG - 2025-06-04 07:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-04 07:14:49 --> Input Class Initialized
INFO - 2025-06-04 07:14:49 --> Language Class Initialized
INFO - 2025-06-04 07:14:49 --> Loader Class Initialized
INFO - 2025-06-04 07:14:49 --> Helper loaded: url_helper
INFO - 2025-06-04 07:14:49 --> Helper loaded: form_helper
INFO - 2025-06-04 07:14:49 --> Database Driver Class Initialized
DEBUG - 2025-06-04 07:14:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-04 07:14:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-04 07:14:49 --> Controller Class Initialized
INFO - 2025-06-04 07:14:49 --> Model "User_model" initialized
INFO - 2025-06-04 07:14:49 --> Form Validation Class Initialized
INFO - 2025-06-04 07:14:49 --> Config Class Initialized
INFO - 2025-06-04 07:14:49 --> Hooks Class Initialized
DEBUG - 2025-06-04 07:14:49 --> UTF-8 Support Enabled
INFO - 2025-06-04 07:14:49 --> Utf8 Class Initialized
INFO - 2025-06-04 07:14:49 --> URI Class Initialized
INFO - 2025-06-04 07:14:49 --> Router Class Initialized
INFO - 2025-06-04 07:14:49 --> Output Class Initialized
INFO - 2025-06-04 07:14:49 --> Security Class Initialized
DEBUG - 2025-06-04 07:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-04 07:14:49 --> Input Class Initialized
INFO - 2025-06-04 07:14:49 --> Language Class Initialized
INFO - 2025-06-04 07:14:49 --> Loader Class Initialized
INFO - 2025-06-04 07:14:49 --> Helper loaded: url_helper
INFO - 2025-06-04 07:14:49 --> Helper loaded: form_helper
INFO - 2025-06-04 07:14:49 --> Database Driver Class Initialized
DEBUG - 2025-06-04 07:14:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-04 07:14:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-04 07:14:49 --> Controller Class Initialized
INFO - 2025-06-04 07:14:49 --> Model "User_model" initialized
INFO - 2025-06-04 07:14:49 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-06-04 07:14:49 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/home.php
INFO - 2025-06-04 07:14:49 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-06-04 07:14:49 --> Final output sent to browser
DEBUG - 2025-06-04 07:14:49 --> Total execution time: 0.1084
INFO - 2025-06-04 07:15:03 --> Config Class Initialized
INFO - 2025-06-04 07:15:03 --> Hooks Class Initialized
DEBUG - 2025-06-04 07:15:03 --> UTF-8 Support Enabled
INFO - 2025-06-04 07:15:03 --> Utf8 Class Initialized
INFO - 2025-06-04 07:15:03 --> URI Class Initialized
INFO - 2025-06-04 07:15:03 --> Router Class Initialized
INFO - 2025-06-04 07:15:03 --> Output Class Initialized
INFO - 2025-06-04 07:15:03 --> Security Class Initialized
DEBUG - 2025-06-04 07:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-04 07:15:03 --> Input Class Initialized
INFO - 2025-06-04 07:15:03 --> Language Class Initialized
INFO - 2025-06-04 07:15:03 --> Loader Class Initialized
INFO - 2025-06-04 07:15:03 --> Helper loaded: url_helper
INFO - 2025-06-04 07:15:03 --> Helper loaded: form_helper
INFO - 2025-06-04 07:15:03 --> Database Driver Class Initialized
DEBUG - 2025-06-04 07:15:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-04 07:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-04 07:15:03 --> Controller Class Initialized
INFO - 2025-06-04 07:15:03 --> Model "User_model" initialized
INFO - 2025-06-04 07:15:03 --> Form Validation Class Initialized
INFO - 2025-06-04 07:15:03 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\auth/login.php
INFO - 2025-06-04 07:15:03 --> Final output sent to browser
DEBUG - 2025-06-04 07:15:03 --> Total execution time: 0.0913
INFO - 2025-06-04 07:15:05 --> Config Class Initialized
INFO - 2025-06-04 07:15:05 --> Hooks Class Initialized
DEBUG - 2025-06-04 07:15:05 --> UTF-8 Support Enabled
INFO - 2025-06-04 07:15:05 --> Utf8 Class Initialized
INFO - 2025-06-04 07:15:05 --> URI Class Initialized
INFO - 2025-06-04 07:15:05 --> Router Class Initialized
INFO - 2025-06-04 07:15:05 --> Output Class Initialized
INFO - 2025-06-04 07:15:05 --> Security Class Initialized
DEBUG - 2025-06-04 07:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-04 07:15:05 --> Input Class Initialized
INFO - 2025-06-04 07:15:05 --> Language Class Initialized
INFO - 2025-06-04 07:15:05 --> Loader Class Initialized
INFO - 2025-06-04 07:15:05 --> Helper loaded: url_helper
INFO - 2025-06-04 07:15:05 --> Helper loaded: form_helper
INFO - 2025-06-04 07:15:05 --> Database Driver Class Initialized
DEBUG - 2025-06-04 07:15:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-04 07:15:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-04 07:15:05 --> Controller Class Initialized
INFO - 2025-06-04 07:15:05 --> Model "User_model" initialized
INFO - 2025-06-04 07:15:05 --> Form Validation Class Initialized
DEBUG - 2025-06-04 07:15:05 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-06-04 07:15:05 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\auth/register.php
INFO - 2025-06-04 07:15:05 --> Final output sent to browser
DEBUG - 2025-06-04 07:15:05 --> Total execution time: 0.0809
INFO - 2025-06-04 07:15:19 --> Config Class Initialized
INFO - 2025-06-04 07:15:19 --> Hooks Class Initialized
DEBUG - 2025-06-04 07:15:19 --> UTF-8 Support Enabled
INFO - 2025-06-04 07:15:19 --> Utf8 Class Initialized
INFO - 2025-06-04 07:15:19 --> URI Class Initialized
INFO - 2025-06-04 07:15:19 --> Router Class Initialized
INFO - 2025-06-04 07:15:19 --> Output Class Initialized
INFO - 2025-06-04 07:15:19 --> Security Class Initialized
DEBUG - 2025-06-04 07:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-04 07:15:19 --> Input Class Initialized
INFO - 2025-06-04 07:15:19 --> Language Class Initialized
INFO - 2025-06-04 07:15:19 --> Loader Class Initialized
INFO - 2025-06-04 07:15:19 --> Helper loaded: url_helper
INFO - 2025-06-04 07:15:19 --> Helper loaded: form_helper
INFO - 2025-06-04 07:15:19 --> Database Driver Class Initialized
DEBUG - 2025-06-04 07:15:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-04 07:15:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-04 07:15:19 --> Controller Class Initialized
INFO - 2025-06-04 07:15:19 --> Model "User_model" initialized
INFO - 2025-06-04 07:15:19 --> Form Validation Class Initialized
DEBUG - 2025-06-04 07:15:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-06-04 07:15:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-06-04 07:15:19 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\auth/register.php
INFO - 2025-06-04 07:15:19 --> Final output sent to browser
DEBUG - 2025-06-04 07:15:19 --> Total execution time: 0.1000
INFO - 2025-06-04 07:15:58 --> Config Class Initialized
INFO - 2025-06-04 07:15:58 --> Hooks Class Initialized
DEBUG - 2025-06-04 07:15:58 --> UTF-8 Support Enabled
INFO - 2025-06-04 07:15:58 --> Utf8 Class Initialized
INFO - 2025-06-04 07:15:58 --> URI Class Initialized
INFO - 2025-06-04 07:15:58 --> Router Class Initialized
INFO - 2025-06-04 07:15:58 --> Output Class Initialized
INFO - 2025-06-04 07:15:58 --> Security Class Initialized
DEBUG - 2025-06-04 07:15:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-04 07:15:58 --> Input Class Initialized
INFO - 2025-06-04 07:15:58 --> Language Class Initialized
INFO - 2025-06-04 07:15:58 --> Loader Class Initialized
INFO - 2025-06-04 07:15:58 --> Helper loaded: url_helper
INFO - 2025-06-04 07:15:58 --> Helper loaded: form_helper
INFO - 2025-06-04 07:15:58 --> Database Driver Class Initialized
DEBUG - 2025-06-04 07:15:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-04 07:15:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-04 07:15:58 --> Controller Class Initialized
INFO - 2025-06-04 07:15:58 --> Model "User_model" initialized
INFO - 2025-06-04 07:15:58 --> Form Validation Class Initialized
DEBUG - 2025-06-04 07:15:58 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-06-04 07:15:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-06-04 07:15:58 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\auth/register.php
INFO - 2025-06-04 07:15:58 --> Final output sent to browser
DEBUG - 2025-06-04 07:15:58 --> Total execution time: 0.0894
INFO - 2025-06-04 07:16:13 --> Config Class Initialized
INFO - 2025-06-04 07:16:13 --> Hooks Class Initialized
DEBUG - 2025-06-04 07:16:13 --> UTF-8 Support Enabled
INFO - 2025-06-04 07:16:13 --> Utf8 Class Initialized
INFO - 2025-06-04 07:16:13 --> URI Class Initialized
INFO - 2025-06-04 07:16:13 --> Router Class Initialized
INFO - 2025-06-04 07:16:13 --> Output Class Initialized
INFO - 2025-06-04 07:16:13 --> Security Class Initialized
DEBUG - 2025-06-04 07:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-04 07:16:13 --> Input Class Initialized
INFO - 2025-06-04 07:16:13 --> Language Class Initialized
INFO - 2025-06-04 07:16:13 --> Loader Class Initialized
INFO - 2025-06-04 07:16:13 --> Helper loaded: url_helper
INFO - 2025-06-04 07:16:13 --> Helper loaded: form_helper
INFO - 2025-06-04 07:16:13 --> Database Driver Class Initialized
DEBUG - 2025-06-04 07:16:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-04 07:16:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-04 07:16:13 --> Controller Class Initialized
INFO - 2025-06-04 07:16:13 --> Model "User_model" initialized
INFO - 2025-06-04 07:16:13 --> Form Validation Class Initialized
DEBUG - 2025-06-04 07:16:13 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-06-04 07:16:13 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-06-04 07:16:13 --> Config Class Initialized
INFO - 2025-06-04 07:16:13 --> Hooks Class Initialized
DEBUG - 2025-06-04 07:16:13 --> UTF-8 Support Enabled
INFO - 2025-06-04 07:16:13 --> Utf8 Class Initialized
INFO - 2025-06-04 07:16:13 --> URI Class Initialized
INFO - 2025-06-04 07:16:13 --> Router Class Initialized
INFO - 2025-06-04 07:16:13 --> Output Class Initialized
INFO - 2025-06-04 07:16:13 --> Security Class Initialized
DEBUG - 2025-06-04 07:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-04 07:16:13 --> Input Class Initialized
INFO - 2025-06-04 07:16:13 --> Language Class Initialized
INFO - 2025-06-04 07:16:13 --> Loader Class Initialized
INFO - 2025-06-04 07:16:13 --> Helper loaded: url_helper
INFO - 2025-06-04 07:16:13 --> Helper loaded: form_helper
INFO - 2025-06-04 07:16:13 --> Database Driver Class Initialized
DEBUG - 2025-06-04 07:16:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-04 07:16:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-04 07:16:13 --> Controller Class Initialized
INFO - 2025-06-04 07:16:13 --> Model "User_model" initialized
INFO - 2025-06-04 07:16:13 --> Form Validation Class Initialized
INFO - 2025-06-04 07:16:13 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\auth/login.php
INFO - 2025-06-04 07:16:13 --> Final output sent to browser
DEBUG - 2025-06-04 07:16:13 --> Total execution time: 0.0823
INFO - 2025-06-04 07:16:24 --> Config Class Initialized
INFO - 2025-06-04 07:16:24 --> Hooks Class Initialized
DEBUG - 2025-06-04 07:16:24 --> UTF-8 Support Enabled
INFO - 2025-06-04 07:16:24 --> Utf8 Class Initialized
INFO - 2025-06-04 07:16:24 --> URI Class Initialized
INFO - 2025-06-04 07:16:24 --> Router Class Initialized
INFO - 2025-06-04 07:16:24 --> Output Class Initialized
INFO - 2025-06-04 07:16:24 --> Security Class Initialized
DEBUG - 2025-06-04 07:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-04 07:16:24 --> Input Class Initialized
INFO - 2025-06-04 07:16:24 --> Language Class Initialized
INFO - 2025-06-04 07:16:24 --> Loader Class Initialized
INFO - 2025-06-04 07:16:24 --> Helper loaded: url_helper
INFO - 2025-06-04 07:16:24 --> Helper loaded: form_helper
INFO - 2025-06-04 07:16:24 --> Database Driver Class Initialized
DEBUG - 2025-06-04 07:16:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-04 07:16:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-04 07:16:24 --> Controller Class Initialized
INFO - 2025-06-04 07:16:24 --> Model "User_model" initialized
INFO - 2025-06-04 07:16:24 --> Form Validation Class Initialized
INFO - 2025-06-04 07:16:24 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-06-04 07:16:24 --> Config Class Initialized
INFO - 2025-06-04 07:16:24 --> Hooks Class Initialized
DEBUG - 2025-06-04 07:16:24 --> UTF-8 Support Enabled
INFO - 2025-06-04 07:16:24 --> Utf8 Class Initialized
INFO - 2025-06-04 07:16:24 --> URI Class Initialized
INFO - 2025-06-04 07:16:24 --> Router Class Initialized
INFO - 2025-06-04 07:16:24 --> Output Class Initialized
INFO - 2025-06-04 07:16:24 --> Security Class Initialized
DEBUG - 2025-06-04 07:16:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-04 07:16:24 --> Input Class Initialized
INFO - 2025-06-04 07:16:24 --> Language Class Initialized
INFO - 2025-06-04 07:16:24 --> Loader Class Initialized
INFO - 2025-06-04 07:16:24 --> Helper loaded: url_helper
INFO - 2025-06-04 07:16:24 --> Helper loaded: form_helper
INFO - 2025-06-04 07:16:24 --> Database Driver Class Initialized
DEBUG - 2025-06-04 07:16:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-04 07:16:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-04 07:16:24 --> Controller Class Initialized
INFO - 2025-06-04 07:16:24 --> Model "User_model" initialized
INFO - 2025-06-04 07:16:24 --> Form Validation Class Initialized
INFO - 2025-06-04 07:16:24 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\auth/login.php
INFO - 2025-06-04 07:16:24 --> Final output sent to browser
DEBUG - 2025-06-04 07:16:24 --> Total execution time: 0.0738
INFO - 2025-06-04 07:16:33 --> Config Class Initialized
INFO - 2025-06-04 07:16:33 --> Hooks Class Initialized
DEBUG - 2025-06-04 07:16:33 --> UTF-8 Support Enabled
INFO - 2025-06-04 07:16:33 --> Utf8 Class Initialized
INFO - 2025-06-04 07:16:33 --> URI Class Initialized
INFO - 2025-06-04 07:16:33 --> Router Class Initialized
INFO - 2025-06-04 07:16:33 --> Output Class Initialized
INFO - 2025-06-04 07:16:33 --> Security Class Initialized
DEBUG - 2025-06-04 07:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-04 07:16:33 --> Input Class Initialized
INFO - 2025-06-04 07:16:33 --> Language Class Initialized
INFO - 2025-06-04 07:16:33 --> Loader Class Initialized
INFO - 2025-06-04 07:16:33 --> Helper loaded: url_helper
INFO - 2025-06-04 07:16:33 --> Helper loaded: form_helper
INFO - 2025-06-04 07:16:33 --> Database Driver Class Initialized
DEBUG - 2025-06-04 07:16:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-04 07:16:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-04 07:16:33 --> Controller Class Initialized
INFO - 2025-06-04 07:16:33 --> Model "User_model" initialized
INFO - 2025-06-04 07:16:33 --> Form Validation Class Initialized
INFO - 2025-06-04 07:16:33 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-06-04 07:16:33 --> Config Class Initialized
INFO - 2025-06-04 07:16:33 --> Hooks Class Initialized
DEBUG - 2025-06-04 07:16:33 --> UTF-8 Support Enabled
INFO - 2025-06-04 07:16:33 --> Utf8 Class Initialized
INFO - 2025-06-04 07:16:33 --> URI Class Initialized
INFO - 2025-06-04 07:16:33 --> Router Class Initialized
INFO - 2025-06-04 07:16:33 --> Output Class Initialized
INFO - 2025-06-04 07:16:33 --> Security Class Initialized
DEBUG - 2025-06-04 07:16:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-04 07:16:33 --> Input Class Initialized
INFO - 2025-06-04 07:16:33 --> Language Class Initialized
INFO - 2025-06-04 07:16:33 --> Loader Class Initialized
INFO - 2025-06-04 07:16:33 --> Helper loaded: url_helper
INFO - 2025-06-04 07:16:33 --> Helper loaded: form_helper
INFO - 2025-06-04 07:16:33 --> Database Driver Class Initialized
DEBUG - 2025-06-04 07:16:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-04 07:16:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-04 07:16:33 --> Controller Class Initialized
INFO - 2025-06-04 07:16:33 --> Model "User_model" initialized
INFO - 2025-06-04 07:16:33 --> Form Validation Class Initialized
INFO - 2025-06-04 07:16:33 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\auth/login.php
INFO - 2025-06-04 07:16:33 --> Final output sent to browser
DEBUG - 2025-06-04 07:16:33 --> Total execution time: 0.0767
INFO - 2025-06-04 07:16:41 --> Config Class Initialized
INFO - 2025-06-04 07:16:41 --> Hooks Class Initialized
DEBUG - 2025-06-04 07:16:41 --> UTF-8 Support Enabled
INFO - 2025-06-04 07:16:41 --> Utf8 Class Initialized
INFO - 2025-06-04 07:16:41 --> URI Class Initialized
INFO - 2025-06-04 07:16:41 --> Router Class Initialized
INFO - 2025-06-04 07:16:41 --> Output Class Initialized
INFO - 2025-06-04 07:16:41 --> Security Class Initialized
DEBUG - 2025-06-04 07:16:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-04 07:16:41 --> Input Class Initialized
INFO - 2025-06-04 07:16:41 --> Language Class Initialized
INFO - 2025-06-04 07:16:41 --> Loader Class Initialized
INFO - 2025-06-04 07:16:41 --> Helper loaded: url_helper
INFO - 2025-06-04 07:16:41 --> Helper loaded: form_helper
INFO - 2025-06-04 07:16:41 --> Database Driver Class Initialized
DEBUG - 2025-06-04 07:16:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-04 07:16:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-04 07:16:41 --> Controller Class Initialized
INFO - 2025-06-04 07:16:41 --> Model "User_model" initialized
INFO - 2025-06-04 07:16:41 --> Form Validation Class Initialized
INFO - 2025-06-04 07:16:41 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-06-04 07:16:41 --> Config Class Initialized
INFO - 2025-06-04 07:16:41 --> Hooks Class Initialized
DEBUG - 2025-06-04 07:16:41 --> UTF-8 Support Enabled
INFO - 2025-06-04 07:16:41 --> Utf8 Class Initialized
INFO - 2025-06-04 07:16:41 --> URI Class Initialized
INFO - 2025-06-04 07:16:41 --> Router Class Initialized
INFO - 2025-06-04 07:16:41 --> Output Class Initialized
INFO - 2025-06-04 07:16:41 --> Security Class Initialized
DEBUG - 2025-06-04 07:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-04 07:16:42 --> Input Class Initialized
INFO - 2025-06-04 07:16:42 --> Language Class Initialized
INFO - 2025-06-04 07:16:42 --> Loader Class Initialized
INFO - 2025-06-04 07:16:42 --> Helper loaded: url_helper
INFO - 2025-06-04 07:16:42 --> Helper loaded: form_helper
INFO - 2025-06-04 07:16:42 --> Database Driver Class Initialized
DEBUG - 2025-06-04 07:16:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-04 07:16:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-04 07:16:42 --> Controller Class Initialized
INFO - 2025-06-04 07:16:42 --> Model "User_model" initialized
INFO - 2025-06-04 07:16:42 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-06-04 07:16:42 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/home.php
INFO - 2025-06-04 07:16:42 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-06-04 07:16:42 --> Final output sent to browser
DEBUG - 2025-06-04 07:16:42 --> Total execution time: 0.1020
INFO - 2025-06-04 07:16:44 --> Config Class Initialized
INFO - 2025-06-04 07:16:44 --> Hooks Class Initialized
DEBUG - 2025-06-04 07:16:44 --> UTF-8 Support Enabled
INFO - 2025-06-04 07:16:44 --> Utf8 Class Initialized
INFO - 2025-06-04 07:16:44 --> URI Class Initialized
INFO - 2025-06-04 07:16:44 --> Router Class Initialized
INFO - 2025-06-04 07:16:44 --> Output Class Initialized
INFO - 2025-06-04 07:16:44 --> Security Class Initialized
DEBUG - 2025-06-04 07:16:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-04 07:16:44 --> Input Class Initialized
INFO - 2025-06-04 07:16:44 --> Language Class Initialized
INFO - 2025-06-04 07:16:44 --> Loader Class Initialized
INFO - 2025-06-04 07:16:44 --> Helper loaded: url_helper
INFO - 2025-06-04 07:16:44 --> Helper loaded: form_helper
INFO - 2025-06-04 07:16:44 --> Database Driver Class Initialized
DEBUG - 2025-06-04 07:16:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-04 07:16:44 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-04 07:16:44 --> Controller Class Initialized
INFO - 2025-06-04 07:16:44 --> Model "User_model" initialized
INFO - 2025-06-04 07:16:44 --> Model "Progress_model" initialized
INFO - 2025-06-04 07:16:44 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-04 07:16:44 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-04 07:16:44 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/dashboard.php
INFO - 2025-06-04 07:16:44 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-04 07:16:44 --> Final output sent to browser
DEBUG - 2025-06-04 07:16:44 --> Total execution time: 0.1066
INFO - 2025-06-04 07:16:55 --> Config Class Initialized
INFO - 2025-06-04 07:16:55 --> Hooks Class Initialized
DEBUG - 2025-06-04 07:16:55 --> UTF-8 Support Enabled
INFO - 2025-06-04 07:16:55 --> Utf8 Class Initialized
INFO - 2025-06-04 07:16:55 --> URI Class Initialized
INFO - 2025-06-04 07:16:55 --> Router Class Initialized
INFO - 2025-06-04 07:16:55 --> Output Class Initialized
INFO - 2025-06-04 07:16:55 --> Security Class Initialized
DEBUG - 2025-06-04 07:16:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-04 07:16:55 --> Input Class Initialized
INFO - 2025-06-04 07:16:55 --> Language Class Initialized
INFO - 2025-06-04 07:16:55 --> Loader Class Initialized
INFO - 2025-06-04 07:16:55 --> Helper loaded: url_helper
INFO - 2025-06-04 07:16:55 --> Helper loaded: form_helper
INFO - 2025-06-04 07:16:55 --> Database Driver Class Initialized
DEBUG - 2025-06-04 07:16:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-04 07:16:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-04 07:16:55 --> Controller Class Initialized
INFO - 2025-06-04 07:16:55 --> Model "User_model" initialized
INFO - 2025-06-04 07:16:55 --> Form Validation Class Initialized
INFO - 2025-06-04 07:16:55 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\auth/login.php
INFO - 2025-06-04 07:16:55 --> Final output sent to browser
DEBUG - 2025-06-04 07:16:55 --> Total execution time: 0.0744
INFO - 2025-06-04 07:21:16 --> Config Class Initialized
INFO - 2025-06-04 07:21:16 --> Hooks Class Initialized
DEBUG - 2025-06-04 07:21:16 --> UTF-8 Support Enabled
INFO - 2025-06-04 07:21:16 --> Utf8 Class Initialized
INFO - 2025-06-04 07:21:16 --> URI Class Initialized
INFO - 2025-06-04 07:21:16 --> Router Class Initialized
INFO - 2025-06-04 07:21:16 --> Output Class Initialized
INFO - 2025-06-04 07:21:16 --> Security Class Initialized
DEBUG - 2025-06-04 07:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-04 07:21:16 --> Input Class Initialized
INFO - 2025-06-04 07:21:16 --> Language Class Initialized
INFO - 2025-06-04 07:21:16 --> Loader Class Initialized
INFO - 2025-06-04 07:21:16 --> Helper loaded: url_helper
INFO - 2025-06-04 07:21:16 --> Helper loaded: form_helper
INFO - 2025-06-04 07:21:16 --> Database Driver Class Initialized
DEBUG - 2025-06-04 07:21:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-04 07:21:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-04 07:21:16 --> Controller Class Initialized
INFO - 2025-06-04 07:21:16 --> Model "User_model" initialized
INFO - 2025-06-04 07:21:16 --> Form Validation Class Initialized
INFO - 2025-06-04 07:21:16 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\auth/login.php
INFO - 2025-06-04 07:21:16 --> Final output sent to browser
DEBUG - 2025-06-04 07:21:16 --> Total execution time: 0.1031
INFO - 2025-06-04 07:21:19 --> Config Class Initialized
INFO - 2025-06-04 07:21:19 --> Hooks Class Initialized
DEBUG - 2025-06-04 07:21:19 --> UTF-8 Support Enabled
INFO - 2025-06-04 07:21:19 --> Utf8 Class Initialized
INFO - 2025-06-04 07:21:19 --> URI Class Initialized
INFO - 2025-06-04 07:21:19 --> Router Class Initialized
INFO - 2025-06-04 07:21:19 --> Output Class Initialized
INFO - 2025-06-04 07:21:19 --> Security Class Initialized
DEBUG - 2025-06-04 07:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-04 07:21:19 --> Input Class Initialized
INFO - 2025-06-04 07:21:19 --> Language Class Initialized
INFO - 2025-06-04 07:21:19 --> Loader Class Initialized
INFO - 2025-06-04 07:21:19 --> Helper loaded: url_helper
INFO - 2025-06-04 07:21:19 --> Helper loaded: form_helper
INFO - 2025-06-04 07:21:19 --> Database Driver Class Initialized
DEBUG - 2025-06-04 07:21:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-04 07:21:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-04 07:21:19 --> Controller Class Initialized
INFO - 2025-06-04 07:21:19 --> Model "User_model" initialized
INFO - 2025-06-04 07:21:19 --> Form Validation Class Initialized
DEBUG - 2025-06-04 07:21:19 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-06-04 07:21:19 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\auth/register.php
INFO - 2025-06-04 07:21:19 --> Final output sent to browser
DEBUG - 2025-06-04 07:21:19 --> Total execution time: 0.0789
INFO - 2025-06-04 07:21:35 --> Config Class Initialized
INFO - 2025-06-04 07:21:35 --> Hooks Class Initialized
DEBUG - 2025-06-04 07:21:35 --> UTF-8 Support Enabled
INFO - 2025-06-04 07:21:35 --> Utf8 Class Initialized
INFO - 2025-06-04 07:21:35 --> URI Class Initialized
INFO - 2025-06-04 07:21:35 --> Router Class Initialized
INFO - 2025-06-04 07:21:35 --> Output Class Initialized
INFO - 2025-06-04 07:21:35 --> Security Class Initialized
DEBUG - 2025-06-04 07:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-04 07:21:35 --> Input Class Initialized
INFO - 2025-06-04 07:21:35 --> Language Class Initialized
INFO - 2025-06-04 07:21:35 --> Loader Class Initialized
INFO - 2025-06-04 07:21:35 --> Helper loaded: url_helper
INFO - 2025-06-04 07:21:35 --> Helper loaded: form_helper
INFO - 2025-06-04 07:21:35 --> Database Driver Class Initialized
DEBUG - 2025-06-04 07:21:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-04 07:21:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-04 07:21:35 --> Controller Class Initialized
INFO - 2025-06-04 07:21:35 --> Model "User_model" initialized
INFO - 2025-06-04 07:21:35 --> Form Validation Class Initialized
DEBUG - 2025-06-04 07:21:35 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-06-04 07:21:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-06-04 07:21:35 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\auth/register.php
INFO - 2025-06-04 07:21:35 --> Final output sent to browser
DEBUG - 2025-06-04 07:21:35 --> Total execution time: 0.0799
INFO - 2025-06-04 07:21:43 --> Config Class Initialized
INFO - 2025-06-04 07:21:43 --> Hooks Class Initialized
DEBUG - 2025-06-04 07:21:43 --> UTF-8 Support Enabled
INFO - 2025-06-04 07:21:43 --> Utf8 Class Initialized
INFO - 2025-06-04 07:21:43 --> URI Class Initialized
INFO - 2025-06-04 07:21:43 --> Router Class Initialized
INFO - 2025-06-04 07:21:43 --> Output Class Initialized
INFO - 2025-06-04 07:21:43 --> Security Class Initialized
DEBUG - 2025-06-04 07:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-04 07:21:43 --> Input Class Initialized
INFO - 2025-06-04 07:21:43 --> Language Class Initialized
INFO - 2025-06-04 07:21:43 --> Loader Class Initialized
INFO - 2025-06-04 07:21:43 --> Helper loaded: url_helper
INFO - 2025-06-04 07:21:43 --> Helper loaded: form_helper
INFO - 2025-06-04 07:21:43 --> Database Driver Class Initialized
DEBUG - 2025-06-04 07:21:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-04 07:21:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-04 07:21:43 --> Controller Class Initialized
INFO - 2025-06-04 07:21:43 --> Model "User_model" initialized
INFO - 2025-06-04 07:21:43 --> Form Validation Class Initialized
INFO - 2025-06-04 07:21:43 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\auth/login.php
INFO - 2025-06-04 07:21:43 --> Final output sent to browser
DEBUG - 2025-06-04 07:21:43 --> Total execution time: 0.0733
