<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-06-03 03:46:51 --> Config Class Initialized
INFO - 2025-06-03 03:46:51 --> Hooks Class Initialized
DEBUG - 2025-06-03 03:46:52 --> UTF-8 Support Enabled
INFO - 2025-06-03 03:46:52 --> Utf8 Class Initialized
ERROR - 2025-06-03 03:46:52 --> Severity: 8192 --> Creation of dynamic property CI_URI::$config is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\URI.php 102
INFO - 2025-06-03 03:46:52 --> URI Class Initialized
ERROR - 2025-06-03 03:46:52 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\Router.php 128
DEBUG - 2025-06-03 03:46:52 --> No URI present. Default controller set.
INFO - 2025-06-03 03:46:52 --> Router Class Initialized
INFO - 2025-06-03 03:46:53 --> Output Class Initialized
INFO - 2025-06-03 03:46:53 --> Security Class Initialized
DEBUG - 2025-06-03 03:46:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 03:46:53 --> Input Class Initialized
INFO - 2025-06-03 03:46:53 --> Language Class Initialized
ERROR - 2025-06-03 03:46:53 --> Severity: 8192 --> Creation of dynamic property LandingPage::$benchmark is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\Controller.php 83
ERROR - 2025-06-03 03:46:53 --> Severity: 8192 --> Creation of dynamic property LandingPage::$hooks is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\Controller.php 83
ERROR - 2025-06-03 03:46:53 --> Severity: 8192 --> Creation of dynamic property LandingPage::$config is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\Controller.php 83
ERROR - 2025-06-03 03:46:53 --> Severity: 8192 --> Creation of dynamic property LandingPage::$log is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\Controller.php 83
ERROR - 2025-06-03 03:46:53 --> Severity: 8192 --> Creation of dynamic property LandingPage::$utf8 is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\Controller.php 83
ERROR - 2025-06-03 03:46:53 --> Severity: 8192 --> Creation of dynamic property LandingPage::$uri is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\Controller.php 83
ERROR - 2025-06-03 03:46:53 --> Severity: 8192 --> Creation of dynamic property LandingPage::$exceptions is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\Controller.php 83
ERROR - 2025-06-03 03:46:53 --> Severity: 8192 --> Creation of dynamic property LandingPage::$router is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\Controller.php 83
ERROR - 2025-06-03 03:46:53 --> Severity: 8192 --> Creation of dynamic property LandingPage::$output is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\Controller.php 83
ERROR - 2025-06-03 03:46:53 --> Severity: 8192 --> Creation of dynamic property LandingPage::$security is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\Controller.php 83
ERROR - 2025-06-03 03:46:53 --> Severity: 8192 --> Creation of dynamic property LandingPage::$input is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\Controller.php 83
ERROR - 2025-06-03 03:46:53 --> Severity: 8192 --> Creation of dynamic property LandingPage::$lang is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\Controller.php 83
INFO - 2025-06-03 03:46:54 --> Loader Class Initialized
INFO - 2025-06-03 03:46:54 --> Helper loaded: url_helper
INFO - 2025-06-03 03:46:54 --> Helper loaded: form_helper
ERROR - 2025-06-03 03:46:54 --> Severity: 8192 --> Creation of dynamic property LandingPage::$db is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\Loader.php 397
ERROR - 2025-06-03 03:46:55 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\fitnessrecordneww\system\database\DB_driver.php 372
INFO - 2025-06-03 03:46:55 --> Database Driver Class Initialized
ERROR - 2025-06-03 03:46:56 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\fitnessrecordneww\system\libraries\Session\Session.php 303
ERROR - 2025-06-03 03:46:56 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed after headers have already been sent C:\xampp\htdocs\fitnessrecordneww\system\libraries\Session\Session.php 328
ERROR - 2025-06-03 03:46:56 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\fitnessrecordneww\system\libraries\Session\Session.php 355
ERROR - 2025-06-03 03:46:56 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\fitnessrecordneww\system\libraries\Session\Session.php 365
ERROR - 2025-06-03 03:46:56 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\fitnessrecordneww\system\libraries\Session\Session.php 366
ERROR - 2025-06-03 03:46:56 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\fitnessrecordneww\system\libraries\Session\Session.php 367
ERROR - 2025-06-03 03:46:56 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\fitnessrecordneww\system\libraries\Session\Session.php 368
ERROR - 2025-06-03 03:46:56 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\fitnessrecordneww\system\libraries\Session\Session.php 426
DEBUG - 2025-06-03 03:46:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2025-06-03 03:46:56 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed after headers have already been sent C:\xampp\htdocs\fitnessrecordneww\system\libraries\Session\Session.php 110
ERROR - 2025-06-03 03:46:56 --> Severity: Warning --> session_start(): Session cannot be started after headers have already been sent C:\xampp\htdocs\fitnessrecordneww\system\libraries\Session\Session.php 137
INFO - 2025-06-03 03:46:56 --> Session: Class initialized using 'files' driver.
ERROR - 2025-06-03 03:46:56 --> Severity: 8192 --> Creation of dynamic property LandingPage::$session is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\Loader.php 1284
INFO - 2025-06-03 03:46:56 --> Controller Class Initialized
ERROR - 2025-06-03 03:46:57 --> Severity: 8192 --> Creation of dynamic property LandingPage::$User_model is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\Loader.php 359
INFO - 2025-06-03 03:46:57 --> Model "User_model" initialized
ERROR - 2025-06-03 03:46:58 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$load is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\Loader.php 932
ERROR - 2025-06-03 03:46:58 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$benchmark is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\Loader.php 932
ERROR - 2025-06-03 03:46:58 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$hooks is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\Loader.php 932
ERROR - 2025-06-03 03:46:58 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$config is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\Loader.php 932
ERROR - 2025-06-03 03:46:58 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$log is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\Loader.php 932
ERROR - 2025-06-03 03:46:58 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$utf8 is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\Loader.php 932
ERROR - 2025-06-03 03:46:58 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$uri is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\Loader.php 932
ERROR - 2025-06-03 03:46:58 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$exceptions is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\Loader.php 932
ERROR - 2025-06-03 03:46:58 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$router is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\Loader.php 932
ERROR - 2025-06-03 03:46:58 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$output is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\Loader.php 932
ERROR - 2025-06-03 03:46:58 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$security is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\Loader.php 932
ERROR - 2025-06-03 03:46:58 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$input is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\Loader.php 932
ERROR - 2025-06-03 03:46:58 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$lang is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\Loader.php 932
ERROR - 2025-06-03 03:46:58 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$db is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\Loader.php 932
ERROR - 2025-06-03 03:46:58 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$session is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\Loader.php 932
ERROR - 2025-06-03 03:46:58 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$User_model is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\Loader.php 932
INFO - 2025-06-03 03:47:00 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-06-03 03:47:01 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/home.php
INFO - 2025-06-03 03:47:01 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-06-03 03:47:01 --> Final output sent to browser
DEBUG - 2025-06-03 03:47:01 --> Total execution time: 10.4098
INFO - 2025-06-03 03:48:32 --> Config Class Initialized
INFO - 2025-06-03 03:48:32 --> Hooks Class Initialized
DEBUG - 2025-06-03 03:48:32 --> UTF-8 Support Enabled
INFO - 2025-06-03 03:48:32 --> Utf8 Class Initialized
INFO - 2025-06-03 03:48:33 --> URI Class Initialized
ERROR - 2025-06-03 03:48:33 --> Severity: 8192 --> Creation of dynamic property CI_Router::$uri is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\Router.php 128
DEBUG - 2025-06-03 03:48:33 --> No URI present. Default controller set.
INFO - 2025-06-03 03:48:33 --> Router Class Initialized
INFO - 2025-06-03 03:48:33 --> Output Class Initialized
INFO - 2025-06-03 03:48:33 --> Security Class Initialized
DEBUG - 2025-06-03 03:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 03:48:33 --> Input Class Initialized
INFO - 2025-06-03 03:48:33 --> Language Class Initialized
ERROR - 2025-06-03 03:48:33 --> Severity: 8192 --> Creation of dynamic property LandingPage::$benchmark is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\Controller.php 83
ERROR - 2025-06-03 03:48:33 --> Severity: 8192 --> Creation of dynamic property LandingPage::$hooks is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\Controller.php 83
ERROR - 2025-06-03 03:48:33 --> Severity: 8192 --> Creation of dynamic property LandingPage::$config is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\Controller.php 83
ERROR - 2025-06-03 03:48:33 --> Severity: 8192 --> Creation of dynamic property LandingPage::$log is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\Controller.php 83
ERROR - 2025-06-03 03:48:33 --> Severity: 8192 --> Creation of dynamic property LandingPage::$utf8 is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\Controller.php 83
ERROR - 2025-06-03 03:48:33 --> Severity: 8192 --> Creation of dynamic property LandingPage::$uri is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\Controller.php 83
ERROR - 2025-06-03 03:48:33 --> Severity: 8192 --> Creation of dynamic property LandingPage::$router is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\Controller.php 83
ERROR - 2025-06-03 03:48:33 --> Severity: 8192 --> Creation of dynamic property LandingPage::$exceptions is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\Controller.php 83
ERROR - 2025-06-03 03:48:33 --> Severity: 8192 --> Creation of dynamic property LandingPage::$output is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\Controller.php 83
ERROR - 2025-06-03 03:48:33 --> Severity: 8192 --> Creation of dynamic property LandingPage::$security is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\Controller.php 83
ERROR - 2025-06-03 03:48:33 --> Severity: 8192 --> Creation of dynamic property LandingPage::$input is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\Controller.php 83
ERROR - 2025-06-03 03:48:33 --> Severity: 8192 --> Creation of dynamic property LandingPage::$lang is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\Controller.php 83
INFO - 2025-06-03 03:48:33 --> Loader Class Initialized
INFO - 2025-06-03 03:48:33 --> Helper loaded: url_helper
INFO - 2025-06-03 03:48:33 --> Helper loaded: form_helper
ERROR - 2025-06-03 03:48:33 --> Severity: 8192 --> Creation of dynamic property LandingPage::$db is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\Loader.php 397
ERROR - 2025-06-03 03:48:33 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\fitnessrecordneww\system\database\DB_driver.php 372
INFO - 2025-06-03 03:48:33 --> Database Driver Class Initialized
ERROR - 2025-06-03 03:48:33 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\fitnessrecordneww\system\libraries\Session\Session.php 303
ERROR - 2025-06-03 03:48:33 --> Severity: Warning --> session_set_cookie_params(): Session cookie parameters cannot be changed after headers have already been sent C:\xampp\htdocs\fitnessrecordneww\system\libraries\Session\Session.php 328
ERROR - 2025-06-03 03:48:33 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\fitnessrecordneww\system\libraries\Session\Session.php 355
ERROR - 2025-06-03 03:48:33 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\fitnessrecordneww\system\libraries\Session\Session.php 365
ERROR - 2025-06-03 03:48:33 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\fitnessrecordneww\system\libraries\Session\Session.php 366
ERROR - 2025-06-03 03:48:33 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\fitnessrecordneww\system\libraries\Session\Session.php 367
ERROR - 2025-06-03 03:48:33 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\fitnessrecordneww\system\libraries\Session\Session.php 368
ERROR - 2025-06-03 03:48:33 --> Severity: Warning --> ini_set(): Session ini settings cannot be changed after headers have already been sent C:\xampp\htdocs\fitnessrecordneww\system\libraries\Session\Session.php 426
DEBUG - 2025-06-03 03:48:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
ERROR - 2025-06-03 03:48:33 --> Severity: Warning --> session_set_save_handler(): Session save handler cannot be changed after headers have already been sent C:\xampp\htdocs\fitnessrecordneww\system\libraries\Session\Session.php 110
ERROR - 2025-06-03 03:48:33 --> Severity: Warning --> session_start(): Session cannot be started after headers have already been sent C:\xampp\htdocs\fitnessrecordneww\system\libraries\Session\Session.php 137
INFO - 2025-06-03 03:48:33 --> Session: Class initialized using 'files' driver.
ERROR - 2025-06-03 03:48:33 --> Severity: 8192 --> Creation of dynamic property LandingPage::$session is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\Loader.php 1284
INFO - 2025-06-03 03:48:33 --> Controller Class Initialized
ERROR - 2025-06-03 03:48:33 --> Severity: 8192 --> Creation of dynamic property LandingPage::$User_model is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\Loader.php 359
INFO - 2025-06-03 03:48:33 --> Model "User_model" initialized
ERROR - 2025-06-03 03:48:33 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$load is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\Loader.php 932
ERROR - 2025-06-03 03:48:33 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$benchmark is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\Loader.php 932
ERROR - 2025-06-03 03:48:33 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$hooks is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\Loader.php 932
ERROR - 2025-06-03 03:48:33 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$config is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\Loader.php 932
ERROR - 2025-06-03 03:48:33 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$log is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\Loader.php 932
ERROR - 2025-06-03 03:48:33 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$utf8 is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\Loader.php 932
ERROR - 2025-06-03 03:48:33 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$uri is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\Loader.php 932
ERROR - 2025-06-03 03:48:33 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$router is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\Loader.php 932
ERROR - 2025-06-03 03:48:33 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$exceptions is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\Loader.php 932
ERROR - 2025-06-03 03:48:33 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$output is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\Loader.php 932
ERROR - 2025-06-03 03:48:33 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$security is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\Loader.php 932
ERROR - 2025-06-03 03:48:33 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$input is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\Loader.php 932
ERROR - 2025-06-03 03:48:33 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$lang is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\Loader.php 932
ERROR - 2025-06-03 03:48:33 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$db is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\Loader.php 932
ERROR - 2025-06-03 03:48:33 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$session is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\Loader.php 932
ERROR - 2025-06-03 03:48:33 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$User_model is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\Loader.php 932
INFO - 2025-06-03 03:48:33 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-06-03 03:48:33 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/home.php
INFO - 2025-06-03 03:48:33 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-06-03 03:48:33 --> Final output sent to browser
DEBUG - 2025-06-03 03:48:33 --> Total execution time: 0.3914
INFO - 2025-06-03 03:49:12 --> Config Class Initialized
INFO - 2025-06-03 03:49:12 --> Hooks Class Initialized
DEBUG - 2025-06-03 03:49:12 --> UTF-8 Support Enabled
INFO - 2025-06-03 03:49:12 --> Utf8 Class Initialized
INFO - 2025-06-03 03:49:12 --> URI Class Initialized
DEBUG - 2025-06-03 03:49:12 --> No URI present. Default controller set.
INFO - 2025-06-03 03:49:12 --> Router Class Initialized
INFO - 2025-06-03 03:49:12 --> Output Class Initialized
INFO - 2025-06-03 03:49:12 --> Security Class Initialized
DEBUG - 2025-06-03 03:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 03:49:12 --> Input Class Initialized
INFO - 2025-06-03 03:49:12 --> Language Class Initialized
INFO - 2025-06-03 03:49:12 --> Loader Class Initialized
INFO - 2025-06-03 03:49:12 --> Helper loaded: url_helper
INFO - 2025-06-03 03:49:12 --> Helper loaded: form_helper
ERROR - 2025-06-03 03:49:12 --> Severity: 8192 --> Creation of dynamic property CI_DB_mysqli_driver::$failover is deprecated C:\xampp\htdocs\fitnessrecordneww\system\database\DB_driver.php 372
INFO - 2025-06-03 03:49:12 --> Database Driver Class Initialized
DEBUG - 2025-06-03 03:49:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 03:49:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 03:49:12 --> Controller Class Initialized
INFO - 2025-06-03 03:49:12 --> Model "User_model" initialized
ERROR - 2025-06-03 03:49:12 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$load is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\Loader.php 932
ERROR - 2025-06-03 03:49:12 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$benchmark is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\Loader.php 932
ERROR - 2025-06-03 03:49:12 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$hooks is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\Loader.php 932
ERROR - 2025-06-03 03:49:12 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$config is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\Loader.php 932
ERROR - 2025-06-03 03:49:12 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$log is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\Loader.php 932
ERROR - 2025-06-03 03:49:12 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$utf8 is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\Loader.php 932
ERROR - 2025-06-03 03:49:12 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$uri is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\Loader.php 932
ERROR - 2025-06-03 03:49:12 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$router is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\Loader.php 932
ERROR - 2025-06-03 03:49:12 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$output is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\Loader.php 932
ERROR - 2025-06-03 03:49:12 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$security is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\Loader.php 932
ERROR - 2025-06-03 03:49:12 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$input is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\Loader.php 932
ERROR - 2025-06-03 03:49:12 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$lang is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\Loader.php 932
ERROR - 2025-06-03 03:49:12 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$db is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\Loader.php 932
ERROR - 2025-06-03 03:49:12 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$session is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\Loader.php 932
ERROR - 2025-06-03 03:49:12 --> Severity: 8192 --> Creation of dynamic property CI_Loader::$User_model is deprecated C:\xampp\htdocs\fitnessrecordneww\system\core\Loader.php 932
INFO - 2025-06-03 03:49:12 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-06-03 03:49:12 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/home.php
INFO - 2025-06-03 03:49:12 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-06-03 03:49:12 --> Final output sent to browser
DEBUG - 2025-06-03 03:49:12 --> Total execution time: 0.2475
INFO - 2025-06-03 03:49:56 --> Config Class Initialized
INFO - 2025-06-03 03:49:56 --> Hooks Class Initialized
DEBUG - 2025-06-03 03:49:56 --> UTF-8 Support Enabled
INFO - 2025-06-03 03:49:56 --> Utf8 Class Initialized
INFO - 2025-06-03 03:49:56 --> URI Class Initialized
DEBUG - 2025-06-03 03:49:56 --> No URI present. Default controller set.
INFO - 2025-06-03 03:49:56 --> Router Class Initialized
INFO - 2025-06-03 03:49:56 --> Output Class Initialized
INFO - 2025-06-03 03:49:56 --> Security Class Initialized
DEBUG - 2025-06-03 03:49:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 03:49:56 --> Input Class Initialized
INFO - 2025-06-03 03:49:56 --> Language Class Initialized
INFO - 2025-06-03 03:49:56 --> Loader Class Initialized
INFO - 2025-06-03 03:49:56 --> Helper loaded: url_helper
INFO - 2025-06-03 03:49:56 --> Helper loaded: form_helper
INFO - 2025-06-03 03:49:56 --> Database Driver Class Initialized
DEBUG - 2025-06-03 03:49:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 03:49:56 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 03:49:56 --> Controller Class Initialized
INFO - 2025-06-03 03:49:56 --> Model "User_model" initialized
INFO - 2025-06-03 03:49:56 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-06-03 03:49:56 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/home.php
INFO - 2025-06-03 03:49:56 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-06-03 03:49:56 --> Final output sent to browser
DEBUG - 2025-06-03 03:49:56 --> Total execution time: 0.2143
INFO - 2025-06-03 03:51:16 --> Config Class Initialized
INFO - 2025-06-03 03:51:16 --> Hooks Class Initialized
DEBUG - 2025-06-03 03:51:16 --> UTF-8 Support Enabled
INFO - 2025-06-03 03:51:16 --> Utf8 Class Initialized
INFO - 2025-06-03 03:51:16 --> URI Class Initialized
DEBUG - 2025-06-03 03:51:16 --> No URI present. Default controller set.
INFO - 2025-06-03 03:51:16 --> Router Class Initialized
INFO - 2025-06-03 03:51:16 --> Output Class Initialized
INFO - 2025-06-03 03:51:16 --> Security Class Initialized
DEBUG - 2025-06-03 03:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 03:51:16 --> Input Class Initialized
INFO - 2025-06-03 03:51:16 --> Language Class Initialized
INFO - 2025-06-03 03:51:16 --> Loader Class Initialized
INFO - 2025-06-03 03:51:16 --> Helper loaded: url_helper
INFO - 2025-06-03 03:51:16 --> Helper loaded: form_helper
INFO - 2025-06-03 03:51:16 --> Database Driver Class Initialized
DEBUG - 2025-06-03 03:51:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 03:51:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 03:51:16 --> Controller Class Initialized
INFO - 2025-06-03 03:51:16 --> Model "User_model" initialized
INFO - 2025-06-03 03:51:16 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-06-03 03:51:16 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/home.php
INFO - 2025-06-03 03:51:16 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-06-03 03:51:16 --> Final output sent to browser
DEBUG - 2025-06-03 03:51:16 --> Total execution time: 0.0960
INFO - 2025-06-03 03:51:18 --> Config Class Initialized
INFO - 2025-06-03 03:51:18 --> Hooks Class Initialized
DEBUG - 2025-06-03 03:51:18 --> UTF-8 Support Enabled
INFO - 2025-06-03 03:51:18 --> Utf8 Class Initialized
INFO - 2025-06-03 03:51:18 --> URI Class Initialized
INFO - 2025-06-03 03:51:18 --> Router Class Initialized
INFO - 2025-06-03 03:51:18 --> Output Class Initialized
INFO - 2025-06-03 03:51:18 --> Security Class Initialized
DEBUG - 2025-06-03 03:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 03:51:18 --> Input Class Initialized
INFO - 2025-06-03 03:51:18 --> Language Class Initialized
INFO - 2025-06-03 03:51:18 --> Loader Class Initialized
INFO - 2025-06-03 03:51:18 --> Helper loaded: url_helper
INFO - 2025-06-03 03:51:18 --> Helper loaded: form_helper
INFO - 2025-06-03 03:51:18 --> Database Driver Class Initialized
DEBUG - 2025-06-03 03:51:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 03:51:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 03:51:18 --> Controller Class Initialized
INFO - 2025-06-03 03:51:18 --> Model "User_model" initialized
INFO - 2025-06-03 03:51:18 --> Form Validation Class Initialized
INFO - 2025-06-03 03:51:18 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\auth/login.php
INFO - 2025-06-03 03:51:18 --> Final output sent to browser
DEBUG - 2025-06-03 03:51:18 --> Total execution time: 0.3767
INFO - 2025-06-03 03:52:13 --> Config Class Initialized
INFO - 2025-06-03 03:52:13 --> Hooks Class Initialized
DEBUG - 2025-06-03 03:52:13 --> UTF-8 Support Enabled
INFO - 2025-06-03 03:52:13 --> Utf8 Class Initialized
INFO - 2025-06-03 03:52:13 --> URI Class Initialized
INFO - 2025-06-03 03:52:13 --> Router Class Initialized
INFO - 2025-06-03 03:52:13 --> Output Class Initialized
INFO - 2025-06-03 03:52:13 --> Security Class Initialized
DEBUG - 2025-06-03 03:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 03:52:13 --> Input Class Initialized
INFO - 2025-06-03 03:52:13 --> Language Class Initialized
INFO - 2025-06-03 03:52:13 --> Loader Class Initialized
INFO - 2025-06-03 03:52:13 --> Helper loaded: url_helper
INFO - 2025-06-03 03:52:13 --> Helper loaded: form_helper
INFO - 2025-06-03 03:52:13 --> Database Driver Class Initialized
DEBUG - 2025-06-03 03:52:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 03:52:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 03:52:13 --> Controller Class Initialized
INFO - 2025-06-03 03:52:13 --> Model "User_model" initialized
INFO - 2025-06-03 03:52:13 --> Form Validation Class Initialized
INFO - 2025-06-03 03:52:13 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\auth/login.php
INFO - 2025-06-03 03:52:13 --> Final output sent to browser
DEBUG - 2025-06-03 03:52:13 --> Total execution time: 0.1042
INFO - 2025-06-03 03:52:16 --> Config Class Initialized
INFO - 2025-06-03 03:52:16 --> Hooks Class Initialized
DEBUG - 2025-06-03 03:52:16 --> UTF-8 Support Enabled
INFO - 2025-06-03 03:52:16 --> Utf8 Class Initialized
INFO - 2025-06-03 03:52:16 --> URI Class Initialized
INFO - 2025-06-03 03:52:16 --> Router Class Initialized
INFO - 2025-06-03 03:52:16 --> Output Class Initialized
INFO - 2025-06-03 03:52:16 --> Security Class Initialized
DEBUG - 2025-06-03 03:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 03:52:16 --> Input Class Initialized
INFO - 2025-06-03 03:52:16 --> Language Class Initialized
INFO - 2025-06-03 03:52:16 --> Loader Class Initialized
INFO - 2025-06-03 03:52:16 --> Helper loaded: url_helper
INFO - 2025-06-03 03:52:16 --> Helper loaded: form_helper
INFO - 2025-06-03 03:52:16 --> Database Driver Class Initialized
DEBUG - 2025-06-03 03:52:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 03:52:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 03:52:16 --> Controller Class Initialized
INFO - 2025-06-03 03:52:16 --> Model "User_model" initialized
INFO - 2025-06-03 03:52:16 --> Form Validation Class Initialized
INFO - 2025-06-03 03:52:16 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-06-03 03:52:16 --> Config Class Initialized
INFO - 2025-06-03 03:52:16 --> Hooks Class Initialized
DEBUG - 2025-06-03 03:52:16 --> UTF-8 Support Enabled
INFO - 2025-06-03 03:52:16 --> Utf8 Class Initialized
INFO - 2025-06-03 03:52:16 --> URI Class Initialized
INFO - 2025-06-03 03:52:16 --> Router Class Initialized
INFO - 2025-06-03 03:52:16 --> Output Class Initialized
INFO - 2025-06-03 03:52:16 --> Security Class Initialized
DEBUG - 2025-06-03 03:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 03:52:16 --> Input Class Initialized
INFO - 2025-06-03 03:52:16 --> Language Class Initialized
INFO - 2025-06-03 03:52:16 --> Loader Class Initialized
INFO - 2025-06-03 03:52:16 --> Helper loaded: url_helper
INFO - 2025-06-03 03:52:16 --> Helper loaded: form_helper
INFO - 2025-06-03 03:52:16 --> Database Driver Class Initialized
DEBUG - 2025-06-03 03:52:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 03:52:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 03:52:16 --> Controller Class Initialized
INFO - 2025-06-03 03:52:17 --> Model "User_model" initialized
INFO - 2025-06-03 03:52:17 --> Form Validation Class Initialized
INFO - 2025-06-03 03:52:17 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\auth/login.php
INFO - 2025-06-03 03:52:17 --> Final output sent to browser
DEBUG - 2025-06-03 03:52:17 --> Total execution time: 0.0930
INFO - 2025-06-03 03:52:22 --> Config Class Initialized
INFO - 2025-06-03 03:52:22 --> Hooks Class Initialized
DEBUG - 2025-06-03 03:52:22 --> UTF-8 Support Enabled
INFO - 2025-06-03 03:52:22 --> Utf8 Class Initialized
INFO - 2025-06-03 03:52:22 --> URI Class Initialized
INFO - 2025-06-03 03:52:22 --> Router Class Initialized
INFO - 2025-06-03 03:52:22 --> Output Class Initialized
INFO - 2025-06-03 03:52:22 --> Security Class Initialized
DEBUG - 2025-06-03 03:52:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 03:52:22 --> Input Class Initialized
INFO - 2025-06-03 03:52:22 --> Language Class Initialized
INFO - 2025-06-03 03:52:22 --> Loader Class Initialized
INFO - 2025-06-03 03:52:22 --> Helper loaded: url_helper
INFO - 2025-06-03 03:52:22 --> Helper loaded: form_helper
INFO - 2025-06-03 03:52:23 --> Database Driver Class Initialized
DEBUG - 2025-06-03 03:52:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 03:52:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 03:52:23 --> Controller Class Initialized
INFO - 2025-06-03 03:52:23 --> Model "User_model" initialized
INFO - 2025-06-03 03:52:23 --> Form Validation Class Initialized
INFO - 2025-06-03 03:52:23 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-06-03 03:52:23 --> Config Class Initialized
INFO - 2025-06-03 03:52:23 --> Hooks Class Initialized
DEBUG - 2025-06-03 03:52:23 --> UTF-8 Support Enabled
INFO - 2025-06-03 03:52:23 --> Utf8 Class Initialized
INFO - 2025-06-03 03:52:23 --> URI Class Initialized
INFO - 2025-06-03 03:52:23 --> Router Class Initialized
INFO - 2025-06-03 03:52:23 --> Output Class Initialized
INFO - 2025-06-03 03:52:23 --> Security Class Initialized
DEBUG - 2025-06-03 03:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 03:52:23 --> Input Class Initialized
INFO - 2025-06-03 03:52:23 --> Language Class Initialized
INFO - 2025-06-03 03:52:23 --> Loader Class Initialized
INFO - 2025-06-03 03:52:23 --> Helper loaded: url_helper
INFO - 2025-06-03 03:52:23 --> Helper loaded: form_helper
INFO - 2025-06-03 03:52:23 --> Database Driver Class Initialized
DEBUG - 2025-06-03 03:52:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 03:52:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 03:52:23 --> Controller Class Initialized
INFO - 2025-06-03 03:52:23 --> Model "User_model" initialized
INFO - 2025-06-03 03:52:23 --> Form Validation Class Initialized
INFO - 2025-06-03 03:52:23 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\auth/login.php
INFO - 2025-06-03 03:52:23 --> Final output sent to browser
DEBUG - 2025-06-03 03:52:23 --> Total execution time: 0.1330
INFO - 2025-06-03 03:52:29 --> Config Class Initialized
INFO - 2025-06-03 03:52:29 --> Hooks Class Initialized
DEBUG - 2025-06-03 03:52:29 --> UTF-8 Support Enabled
INFO - 2025-06-03 03:52:29 --> Utf8 Class Initialized
INFO - 2025-06-03 03:52:29 --> URI Class Initialized
INFO - 2025-06-03 03:52:29 --> Router Class Initialized
INFO - 2025-06-03 03:52:29 --> Output Class Initialized
INFO - 2025-06-03 03:52:29 --> Security Class Initialized
DEBUG - 2025-06-03 03:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 03:52:29 --> Input Class Initialized
INFO - 2025-06-03 03:52:29 --> Language Class Initialized
INFO - 2025-06-03 03:52:29 --> Loader Class Initialized
INFO - 2025-06-03 03:52:29 --> Helper loaded: url_helper
INFO - 2025-06-03 03:52:29 --> Helper loaded: form_helper
INFO - 2025-06-03 03:52:29 --> Database Driver Class Initialized
DEBUG - 2025-06-03 03:52:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 03:52:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 03:52:29 --> Controller Class Initialized
INFO - 2025-06-03 03:52:29 --> Model "User_model" initialized
INFO - 2025-06-03 03:52:29 --> Form Validation Class Initialized
INFO - 2025-06-03 03:52:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-06-03 03:52:29 --> Config Class Initialized
INFO - 2025-06-03 03:52:29 --> Hooks Class Initialized
DEBUG - 2025-06-03 03:52:29 --> UTF-8 Support Enabled
INFO - 2025-06-03 03:52:29 --> Utf8 Class Initialized
INFO - 2025-06-03 03:52:29 --> URI Class Initialized
INFO - 2025-06-03 03:52:29 --> Router Class Initialized
INFO - 2025-06-03 03:52:29 --> Output Class Initialized
INFO - 2025-06-03 03:52:29 --> Security Class Initialized
DEBUG - 2025-06-03 03:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 03:52:29 --> Input Class Initialized
INFO - 2025-06-03 03:52:29 --> Language Class Initialized
INFO - 2025-06-03 03:52:29 --> Loader Class Initialized
INFO - 2025-06-03 03:52:29 --> Helper loaded: url_helper
INFO - 2025-06-03 03:52:29 --> Helper loaded: form_helper
INFO - 2025-06-03 03:52:29 --> Database Driver Class Initialized
DEBUG - 2025-06-03 03:52:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 03:52:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 03:52:29 --> Controller Class Initialized
INFO - 2025-06-03 03:52:29 --> Model "User_model" initialized
INFO - 2025-06-03 03:52:29 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-06-03 03:52:29 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/home.php
INFO - 2025-06-03 03:52:29 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-06-03 03:52:29 --> Final output sent to browser
DEBUG - 2025-06-03 03:52:29 --> Total execution time: 0.0971
INFO - 2025-06-03 03:52:35 --> Config Class Initialized
INFO - 2025-06-03 03:52:35 --> Hooks Class Initialized
DEBUG - 2025-06-03 03:52:35 --> UTF-8 Support Enabled
INFO - 2025-06-03 03:52:35 --> Utf8 Class Initialized
INFO - 2025-06-03 03:52:35 --> URI Class Initialized
INFO - 2025-06-03 03:52:35 --> Router Class Initialized
INFO - 2025-06-03 03:52:35 --> Output Class Initialized
INFO - 2025-06-03 03:52:35 --> Security Class Initialized
DEBUG - 2025-06-03 03:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 03:52:35 --> Input Class Initialized
INFO - 2025-06-03 03:52:35 --> Language Class Initialized
INFO - 2025-06-03 03:52:35 --> Loader Class Initialized
INFO - 2025-06-03 03:52:35 --> Helper loaded: url_helper
INFO - 2025-06-03 03:52:35 --> Helper loaded: form_helper
INFO - 2025-06-03 03:52:35 --> Database Driver Class Initialized
DEBUG - 2025-06-03 03:52:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 03:52:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 03:52:35 --> Controller Class Initialized
INFO - 2025-06-03 03:52:35 --> Model "User_model" initialized
INFO - 2025-06-03 03:52:35 --> Model "Progress_model" initialized
INFO - 2025-06-03 03:52:35 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 03:52:35 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 03:52:36 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/dashboard.php
INFO - 2025-06-03 03:52:36 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 03:52:36 --> Final output sent to browser
DEBUG - 2025-06-03 03:52:36 --> Total execution time: 0.5006
INFO - 2025-06-03 03:52:43 --> Config Class Initialized
INFO - 2025-06-03 03:52:43 --> Hooks Class Initialized
DEBUG - 2025-06-03 03:52:43 --> UTF-8 Support Enabled
INFO - 2025-06-03 03:52:43 --> Utf8 Class Initialized
INFO - 2025-06-03 03:52:43 --> URI Class Initialized
INFO - 2025-06-03 03:52:43 --> Router Class Initialized
INFO - 2025-06-03 03:52:43 --> Output Class Initialized
INFO - 2025-06-03 03:52:43 --> Security Class Initialized
DEBUG - 2025-06-03 03:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 03:52:43 --> Input Class Initialized
INFO - 2025-06-03 03:52:43 --> Language Class Initialized
INFO - 2025-06-03 03:52:43 --> Loader Class Initialized
INFO - 2025-06-03 03:52:43 --> Helper loaded: url_helper
INFO - 2025-06-03 03:52:43 --> Helper loaded: form_helper
INFO - 2025-06-03 03:52:43 --> Database Driver Class Initialized
DEBUG - 2025-06-03 03:52:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 03:52:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 03:52:43 --> Controller Class Initialized
INFO - 2025-06-03 03:52:43 --> Model "User_model" initialized
INFO - 2025-06-03 03:52:43 --> Model "Progress_model" initialized
INFO - 2025-06-03 03:52:43 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 03:52:43 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 03:52:43 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/dashboard.php
INFO - 2025-06-03 03:52:43 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 03:52:43 --> Final output sent to browser
DEBUG - 2025-06-03 03:52:43 --> Total execution time: 0.1078
INFO - 2025-06-03 03:52:45 --> Config Class Initialized
INFO - 2025-06-03 03:52:45 --> Hooks Class Initialized
DEBUG - 2025-06-03 03:52:45 --> UTF-8 Support Enabled
INFO - 2025-06-03 03:52:45 --> Utf8 Class Initialized
INFO - 2025-06-03 03:52:45 --> URI Class Initialized
INFO - 2025-06-03 03:52:45 --> Router Class Initialized
INFO - 2025-06-03 03:52:45 --> Output Class Initialized
INFO - 2025-06-03 03:52:45 --> Security Class Initialized
DEBUG - 2025-06-03 03:52:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 03:52:45 --> Input Class Initialized
INFO - 2025-06-03 03:52:45 --> Language Class Initialized
INFO - 2025-06-03 03:52:45 --> Loader Class Initialized
INFO - 2025-06-03 03:52:45 --> Helper loaded: url_helper
INFO - 2025-06-03 03:52:45 --> Helper loaded: form_helper
INFO - 2025-06-03 03:52:45 --> Database Driver Class Initialized
DEBUG - 2025-06-03 03:52:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 03:52:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 03:52:45 --> Controller Class Initialized
INFO - 2025-06-03 03:52:45 --> Model "User_model" initialized
INFO - 2025-06-03 03:52:45 --> Model "Progress_model" initialized
INFO - 2025-06-03 03:52:45 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 03:52:45 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 03:52:46 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/guide.php
INFO - 2025-06-03 03:52:46 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 03:52:46 --> Final output sent to browser
DEBUG - 2025-06-03 03:52:46 --> Total execution time: 0.1308
INFO - 2025-06-03 03:52:51 --> Config Class Initialized
INFO - 2025-06-03 03:52:51 --> Hooks Class Initialized
DEBUG - 2025-06-03 03:52:51 --> UTF-8 Support Enabled
INFO - 2025-06-03 03:52:51 --> Utf8 Class Initialized
INFO - 2025-06-03 03:52:51 --> URI Class Initialized
INFO - 2025-06-03 03:52:51 --> Router Class Initialized
INFO - 2025-06-03 03:52:51 --> Output Class Initialized
INFO - 2025-06-03 03:52:51 --> Security Class Initialized
DEBUG - 2025-06-03 03:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 03:52:51 --> Input Class Initialized
INFO - 2025-06-03 03:52:51 --> Language Class Initialized
INFO - 2025-06-03 03:52:51 --> Loader Class Initialized
INFO - 2025-06-03 03:52:51 --> Helper loaded: url_helper
INFO - 2025-06-03 03:52:51 --> Helper loaded: form_helper
INFO - 2025-06-03 03:52:51 --> Database Driver Class Initialized
DEBUG - 2025-06-03 03:52:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 03:52:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 03:52:51 --> Controller Class Initialized
INFO - 2025-06-03 03:52:51 --> Model "Progress_model" initialized
INFO - 2025-06-03 03:52:51 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 03:52:51 --> Model "User_model" initialized
INFO - 2025-06-03 03:52:51 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 03:52:51 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 03:52:51 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/progress_view.php
INFO - 2025-06-03 03:52:51 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 03:52:51 --> Final output sent to browser
DEBUG - 2025-06-03 03:52:51 --> Total execution time: 0.2692
INFO - 2025-06-03 03:52:52 --> Config Class Initialized
INFO - 2025-06-03 03:52:52 --> Hooks Class Initialized
DEBUG - 2025-06-03 03:52:52 --> UTF-8 Support Enabled
INFO - 2025-06-03 03:52:52 --> Utf8 Class Initialized
INFO - 2025-06-03 03:52:52 --> URI Class Initialized
INFO - 2025-06-03 03:52:52 --> Router Class Initialized
INFO - 2025-06-03 03:52:52 --> Output Class Initialized
INFO - 2025-06-03 03:52:52 --> Security Class Initialized
DEBUG - 2025-06-03 03:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 03:52:52 --> Input Class Initialized
INFO - 2025-06-03 03:52:52 --> Language Class Initialized
INFO - 2025-06-03 03:52:52 --> Loader Class Initialized
INFO - 2025-06-03 03:52:52 --> Helper loaded: url_helper
INFO - 2025-06-03 03:52:52 --> Helper loaded: form_helper
INFO - 2025-06-03 03:52:52 --> Database Driver Class Initialized
DEBUG - 2025-06-03 03:52:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 03:52:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 03:52:52 --> Controller Class Initialized
INFO - 2025-06-03 03:52:52 --> Model "Progress_model" initialized
INFO - 2025-06-03 03:52:52 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 03:52:52 --> Model "User_model" initialized
INFO - 2025-06-03 03:52:52 --> Final output sent to browser
DEBUG - 2025-06-03 03:52:52 --> Total execution time: 0.1774
INFO - 2025-06-03 03:53:01 --> Config Class Initialized
INFO - 2025-06-03 03:53:01 --> Hooks Class Initialized
DEBUG - 2025-06-03 03:53:01 --> UTF-8 Support Enabled
INFO - 2025-06-03 03:53:01 --> Utf8 Class Initialized
INFO - 2025-06-03 03:53:01 --> URI Class Initialized
INFO - 2025-06-03 03:53:01 --> Router Class Initialized
INFO - 2025-06-03 03:53:01 --> Output Class Initialized
INFO - 2025-06-03 03:53:01 --> Security Class Initialized
DEBUG - 2025-06-03 03:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 03:53:01 --> Input Class Initialized
INFO - 2025-06-03 03:53:01 --> Language Class Initialized
INFO - 2025-06-03 03:53:01 --> Loader Class Initialized
INFO - 2025-06-03 03:53:01 --> Helper loaded: url_helper
INFO - 2025-06-03 03:53:01 --> Helper loaded: form_helper
INFO - 2025-06-03 03:53:01 --> Database Driver Class Initialized
DEBUG - 2025-06-03 03:53:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 03:53:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 03:53:01 --> Controller Class Initialized
INFO - 2025-06-03 03:53:01 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 03:53:01 --> Model "User_model" initialized
INFO - 2025-06-03 03:53:01 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 03:53:01 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 03:53:01 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-06-03 03:53:01 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 03:53:01 --> Final output sent to browser
DEBUG - 2025-06-03 03:53:01 --> Total execution time: 0.1709
INFO - 2025-06-03 03:53:05 --> Config Class Initialized
INFO - 2025-06-03 03:53:05 --> Hooks Class Initialized
DEBUG - 2025-06-03 03:53:05 --> UTF-8 Support Enabled
INFO - 2025-06-03 03:53:05 --> Utf8 Class Initialized
INFO - 2025-06-03 03:53:05 --> URI Class Initialized
INFO - 2025-06-03 03:53:05 --> Router Class Initialized
INFO - 2025-06-03 03:53:05 --> Output Class Initialized
INFO - 2025-06-03 03:53:05 --> Security Class Initialized
DEBUG - 2025-06-03 03:53:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 03:53:05 --> Input Class Initialized
INFO - 2025-06-03 03:53:05 --> Language Class Initialized
INFO - 2025-06-03 03:53:05 --> Loader Class Initialized
INFO - 2025-06-03 03:53:05 --> Helper loaded: url_helper
INFO - 2025-06-03 03:53:05 --> Helper loaded: form_helper
INFO - 2025-06-03 03:53:05 --> Database Driver Class Initialized
DEBUG - 2025-06-03 03:53:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 03:53:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 03:53:05 --> Controller Class Initialized
INFO - 2025-06-03 03:53:05 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 03:53:05 --> Model "User_model" initialized
INFO - 2025-06-03 03:53:05 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 03:53:05 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 03:53:05 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/level.php
INFO - 2025-06-03 03:53:05 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 03:53:05 --> Final output sent to browser
DEBUG - 2025-06-03 03:53:05 --> Total execution time: 0.1295
INFO - 2025-06-03 03:53:17 --> Config Class Initialized
INFO - 2025-06-03 03:53:17 --> Hooks Class Initialized
DEBUG - 2025-06-03 03:53:17 --> UTF-8 Support Enabled
INFO - 2025-06-03 03:53:17 --> Utf8 Class Initialized
INFO - 2025-06-03 03:53:17 --> URI Class Initialized
INFO - 2025-06-03 03:53:17 --> Router Class Initialized
INFO - 2025-06-03 03:53:17 --> Output Class Initialized
INFO - 2025-06-03 03:53:17 --> Security Class Initialized
DEBUG - 2025-06-03 03:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 03:53:17 --> Input Class Initialized
INFO - 2025-06-03 03:53:17 --> Language Class Initialized
INFO - 2025-06-03 03:53:17 --> Loader Class Initialized
INFO - 2025-06-03 03:53:17 --> Helper loaded: url_helper
INFO - 2025-06-03 03:53:17 --> Helper loaded: form_helper
INFO - 2025-06-03 03:53:17 --> Database Driver Class Initialized
DEBUG - 2025-06-03 03:53:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 03:53:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 03:53:17 --> Controller Class Initialized
INFO - 2025-06-03 03:53:17 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 03:53:17 --> Model "User_model" initialized
INFO - 2025-06-03 03:53:17 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 03:53:17 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 03:53:17 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-06-03 03:53:17 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 03:53:17 --> Final output sent to browser
DEBUG - 2025-06-03 03:53:17 --> Total execution time: 0.1633
INFO - 2025-06-03 03:53:20 --> Config Class Initialized
INFO - 2025-06-03 03:53:20 --> Hooks Class Initialized
DEBUG - 2025-06-03 03:53:20 --> UTF-8 Support Enabled
INFO - 2025-06-03 03:53:20 --> Utf8 Class Initialized
INFO - 2025-06-03 03:53:20 --> URI Class Initialized
INFO - 2025-06-03 03:53:20 --> Router Class Initialized
INFO - 2025-06-03 03:53:20 --> Output Class Initialized
INFO - 2025-06-03 03:53:20 --> Security Class Initialized
DEBUG - 2025-06-03 03:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 03:53:20 --> Input Class Initialized
INFO - 2025-06-03 03:53:20 --> Language Class Initialized
INFO - 2025-06-03 03:53:20 --> Loader Class Initialized
INFO - 2025-06-03 03:53:20 --> Helper loaded: url_helper
INFO - 2025-06-03 03:53:20 --> Helper loaded: form_helper
INFO - 2025-06-03 03:53:20 --> Database Driver Class Initialized
DEBUG - 2025-06-03 03:53:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 03:53:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 03:53:20 --> Controller Class Initialized
INFO - 2025-06-03 03:53:20 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 03:53:20 --> Model "User_model" initialized
INFO - 2025-06-03 03:53:20 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 03:53:20 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 03:53:21 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/start.php
INFO - 2025-06-03 03:53:21 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 03:53:21 --> Final output sent to browser
DEBUG - 2025-06-03 03:53:21 --> Total execution time: 0.2013
INFO - 2025-06-03 03:53:25 --> Config Class Initialized
INFO - 2025-06-03 03:53:25 --> Hooks Class Initialized
DEBUG - 2025-06-03 03:53:25 --> UTF-8 Support Enabled
INFO - 2025-06-03 03:53:25 --> Utf8 Class Initialized
INFO - 2025-06-03 03:53:25 --> URI Class Initialized
INFO - 2025-06-03 03:53:25 --> Router Class Initialized
INFO - 2025-06-03 03:53:25 --> Output Class Initialized
INFO - 2025-06-03 03:53:25 --> Security Class Initialized
DEBUG - 2025-06-03 03:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 03:53:25 --> Input Class Initialized
INFO - 2025-06-03 03:53:25 --> Language Class Initialized
INFO - 2025-06-03 03:53:25 --> Loader Class Initialized
INFO - 2025-06-03 03:53:25 --> Helper loaded: url_helper
INFO - 2025-06-03 03:53:25 --> Helper loaded: form_helper
INFO - 2025-06-03 03:53:26 --> Database Driver Class Initialized
DEBUG - 2025-06-03 03:53:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 03:53:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 03:53:26 --> Controller Class Initialized
INFO - 2025-06-03 03:53:26 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 03:53:26 --> Model "User_model" initialized
INFO - 2025-06-03 03:53:26 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 03:53:26 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 03:53:26 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/start.php
INFO - 2025-06-03 03:53:26 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 03:53:26 --> Final output sent to browser
DEBUG - 2025-06-03 03:53:26 --> Total execution time: 0.0981
INFO - 2025-06-03 03:53:58 --> Config Class Initialized
INFO - 2025-06-03 03:53:58 --> Hooks Class Initialized
DEBUG - 2025-06-03 03:53:58 --> UTF-8 Support Enabled
INFO - 2025-06-03 03:53:58 --> Utf8 Class Initialized
INFO - 2025-06-03 03:53:58 --> URI Class Initialized
INFO - 2025-06-03 03:53:58 --> Router Class Initialized
INFO - 2025-06-03 03:53:58 --> Output Class Initialized
INFO - 2025-06-03 03:53:58 --> Security Class Initialized
DEBUG - 2025-06-03 03:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 03:53:58 --> Input Class Initialized
INFO - 2025-06-03 03:53:58 --> Language Class Initialized
INFO - 2025-06-03 03:53:58 --> Loader Class Initialized
INFO - 2025-06-03 03:53:58 --> Helper loaded: url_helper
INFO - 2025-06-03 03:53:58 --> Helper loaded: form_helper
INFO - 2025-06-03 03:53:58 --> Database Driver Class Initialized
DEBUG - 2025-06-03 03:53:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 03:53:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 03:53:58 --> Controller Class Initialized
INFO - 2025-06-03 03:53:58 --> Model "User_model" initialized
INFO - 2025-06-03 03:53:58 --> Model "Community_model" initialized
INFO - 2025-06-03 03:53:58 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 03:53:58 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 03:53:58 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/community.php
INFO - 2025-06-03 03:53:58 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 03:53:58 --> Final output sent to browser
DEBUG - 2025-06-03 03:53:58 --> Total execution time: 0.4337
INFO - 2025-06-03 03:54:05 --> Config Class Initialized
INFO - 2025-06-03 03:54:05 --> Hooks Class Initialized
DEBUG - 2025-06-03 03:54:05 --> UTF-8 Support Enabled
INFO - 2025-06-03 03:54:05 --> Utf8 Class Initialized
INFO - 2025-06-03 03:54:05 --> URI Class Initialized
INFO - 2025-06-03 03:54:05 --> Router Class Initialized
INFO - 2025-06-03 03:54:05 --> Output Class Initialized
INFO - 2025-06-03 03:54:05 --> Security Class Initialized
DEBUG - 2025-06-03 03:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 03:54:05 --> Input Class Initialized
INFO - 2025-06-03 03:54:05 --> Language Class Initialized
INFO - 2025-06-03 03:54:05 --> Loader Class Initialized
INFO - 2025-06-03 03:54:05 --> Helper loaded: url_helper
INFO - 2025-06-03 03:54:05 --> Helper loaded: form_helper
INFO - 2025-06-03 03:54:05 --> Database Driver Class Initialized
DEBUG - 2025-06-03 03:54:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 03:54:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 03:54:05 --> Controller Class Initialized
INFO - 2025-06-03 03:54:05 --> Model "User_model" initialized
INFO - 2025-06-03 03:54:05 --> Model "Community_model" initialized
INFO - 2025-06-03 03:54:05 --> Config Class Initialized
INFO - 2025-06-03 03:54:05 --> Hooks Class Initialized
DEBUG - 2025-06-03 03:54:05 --> UTF-8 Support Enabled
INFO - 2025-06-03 03:54:05 --> Utf8 Class Initialized
INFO - 2025-06-03 03:54:05 --> URI Class Initialized
INFO - 2025-06-03 03:54:05 --> Router Class Initialized
INFO - 2025-06-03 03:54:05 --> Output Class Initialized
INFO - 2025-06-03 03:54:05 --> Security Class Initialized
DEBUG - 2025-06-03 03:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 03:54:05 --> Input Class Initialized
INFO - 2025-06-03 03:54:05 --> Language Class Initialized
INFO - 2025-06-03 03:54:05 --> Loader Class Initialized
INFO - 2025-06-03 03:54:05 --> Helper loaded: url_helper
INFO - 2025-06-03 03:54:05 --> Helper loaded: form_helper
INFO - 2025-06-03 03:54:05 --> Database Driver Class Initialized
DEBUG - 2025-06-03 03:54:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 03:54:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 03:54:05 --> Controller Class Initialized
INFO - 2025-06-03 03:54:05 --> Model "User_model" initialized
INFO - 2025-06-03 03:54:05 --> Model "Community_model" initialized
INFO - 2025-06-03 03:54:05 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 03:54:05 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 03:54:05 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/community.php
INFO - 2025-06-03 03:54:05 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 03:54:05 --> Final output sent to browser
DEBUG - 2025-06-03 03:54:05 --> Total execution time: 0.1068
INFO - 2025-06-03 03:54:10 --> Config Class Initialized
INFO - 2025-06-03 03:54:10 --> Hooks Class Initialized
DEBUG - 2025-06-03 03:54:10 --> UTF-8 Support Enabled
INFO - 2025-06-03 03:54:10 --> Utf8 Class Initialized
INFO - 2025-06-03 03:54:10 --> URI Class Initialized
INFO - 2025-06-03 03:54:10 --> Router Class Initialized
INFO - 2025-06-03 03:54:10 --> Output Class Initialized
INFO - 2025-06-03 03:54:10 --> Security Class Initialized
DEBUG - 2025-06-03 03:54:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 03:54:10 --> Input Class Initialized
INFO - 2025-06-03 03:54:10 --> Language Class Initialized
INFO - 2025-06-03 03:54:10 --> Loader Class Initialized
INFO - 2025-06-03 03:54:10 --> Helper loaded: url_helper
INFO - 2025-06-03 03:54:10 --> Helper loaded: form_helper
INFO - 2025-06-03 03:54:10 --> Database Driver Class Initialized
DEBUG - 2025-06-03 03:54:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 03:54:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 03:54:10 --> Controller Class Initialized
INFO - 2025-06-03 03:54:10 --> Model "User_model" initialized
INFO - 2025-06-03 03:54:10 --> Model "Progress_model" initialized
INFO - 2025-06-03 03:54:10 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 03:54:10 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 03:54:10 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/dashboard.php
INFO - 2025-06-03 03:54:10 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 03:54:10 --> Final output sent to browser
DEBUG - 2025-06-03 03:54:10 --> Total execution time: 0.1193
INFO - 2025-06-03 03:54:12 --> Config Class Initialized
INFO - 2025-06-03 03:54:12 --> Hooks Class Initialized
DEBUG - 2025-06-03 03:54:12 --> UTF-8 Support Enabled
INFO - 2025-06-03 03:54:12 --> Utf8 Class Initialized
INFO - 2025-06-03 03:54:12 --> URI Class Initialized
INFO - 2025-06-03 03:54:12 --> Router Class Initialized
INFO - 2025-06-03 03:54:12 --> Output Class Initialized
INFO - 2025-06-03 03:54:12 --> Security Class Initialized
DEBUG - 2025-06-03 03:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 03:54:12 --> Input Class Initialized
INFO - 2025-06-03 03:54:12 --> Language Class Initialized
INFO - 2025-06-03 03:54:12 --> Loader Class Initialized
INFO - 2025-06-03 03:54:12 --> Helper loaded: url_helper
INFO - 2025-06-03 03:54:12 --> Helper loaded: form_helper
INFO - 2025-06-03 03:54:12 --> Database Driver Class Initialized
DEBUG - 2025-06-03 03:54:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 03:54:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 03:54:12 --> Controller Class Initialized
INFO - 2025-06-03 03:54:12 --> Model "Progress_model" initialized
INFO - 2025-06-03 03:54:12 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 03:54:12 --> Model "User_model" initialized
INFO - 2025-06-03 03:54:12 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 03:54:12 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 03:54:12 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/progress_view.php
INFO - 2025-06-03 03:54:12 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 03:54:12 --> Final output sent to browser
DEBUG - 2025-06-03 03:54:12 --> Total execution time: 0.1083
INFO - 2025-06-03 03:54:13 --> Config Class Initialized
INFO - 2025-06-03 03:54:13 --> Hooks Class Initialized
DEBUG - 2025-06-03 03:54:13 --> UTF-8 Support Enabled
INFO - 2025-06-03 03:54:13 --> Utf8 Class Initialized
INFO - 2025-06-03 03:54:13 --> URI Class Initialized
INFO - 2025-06-03 03:54:13 --> Router Class Initialized
INFO - 2025-06-03 03:54:13 --> Output Class Initialized
INFO - 2025-06-03 03:54:13 --> Security Class Initialized
DEBUG - 2025-06-03 03:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 03:54:13 --> Input Class Initialized
INFO - 2025-06-03 03:54:13 --> Language Class Initialized
INFO - 2025-06-03 03:54:13 --> Loader Class Initialized
INFO - 2025-06-03 03:54:13 --> Helper loaded: url_helper
INFO - 2025-06-03 03:54:13 --> Helper loaded: form_helper
INFO - 2025-06-03 03:54:13 --> Database Driver Class Initialized
DEBUG - 2025-06-03 03:54:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 03:54:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 03:54:13 --> Controller Class Initialized
INFO - 2025-06-03 03:54:13 --> Model "Progress_model" initialized
INFO - 2025-06-03 03:54:13 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 03:54:13 --> Model "User_model" initialized
INFO - 2025-06-03 03:54:13 --> Final output sent to browser
DEBUG - 2025-06-03 03:54:13 --> Total execution time: 0.1593
INFO - 2025-06-03 03:54:14 --> Config Class Initialized
INFO - 2025-06-03 03:54:14 --> Hooks Class Initialized
DEBUG - 2025-06-03 03:54:14 --> UTF-8 Support Enabled
INFO - 2025-06-03 03:54:14 --> Utf8 Class Initialized
INFO - 2025-06-03 03:54:14 --> URI Class Initialized
INFO - 2025-06-03 03:54:14 --> Router Class Initialized
INFO - 2025-06-03 03:54:14 --> Output Class Initialized
INFO - 2025-06-03 03:54:14 --> Security Class Initialized
DEBUG - 2025-06-03 03:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 03:54:14 --> Input Class Initialized
INFO - 2025-06-03 03:54:14 --> Language Class Initialized
INFO - 2025-06-03 03:54:14 --> Loader Class Initialized
INFO - 2025-06-03 03:54:14 --> Helper loaded: url_helper
INFO - 2025-06-03 03:54:14 --> Helper loaded: form_helper
INFO - 2025-06-03 03:54:14 --> Database Driver Class Initialized
DEBUG - 2025-06-03 03:54:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 03:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 03:54:14 --> Controller Class Initialized
INFO - 2025-06-03 03:54:14 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 03:54:14 --> Model "User_model" initialized
INFO - 2025-06-03 03:54:14 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 03:54:14 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 03:54:14 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-06-03 03:54:14 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 03:54:14 --> Final output sent to browser
DEBUG - 2025-06-03 03:54:14 --> Total execution time: 0.0952
INFO - 2025-06-03 03:54:16 --> Config Class Initialized
INFO - 2025-06-03 03:54:16 --> Hooks Class Initialized
DEBUG - 2025-06-03 03:54:16 --> UTF-8 Support Enabled
INFO - 2025-06-03 03:54:16 --> Utf8 Class Initialized
INFO - 2025-06-03 03:54:16 --> URI Class Initialized
INFO - 2025-06-03 03:54:16 --> Router Class Initialized
INFO - 2025-06-03 03:54:16 --> Output Class Initialized
INFO - 2025-06-03 03:54:16 --> Security Class Initialized
DEBUG - 2025-06-03 03:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 03:54:16 --> Input Class Initialized
INFO - 2025-06-03 03:54:16 --> Language Class Initialized
INFO - 2025-06-03 03:54:16 --> Loader Class Initialized
INFO - 2025-06-03 03:54:16 --> Helper loaded: url_helper
INFO - 2025-06-03 03:54:16 --> Helper loaded: form_helper
INFO - 2025-06-03 03:54:16 --> Database Driver Class Initialized
DEBUG - 2025-06-03 03:54:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 03:54:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 03:54:16 --> Controller Class Initialized
INFO - 2025-06-03 03:54:16 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 03:54:16 --> Model "User_model" initialized
INFO - 2025-06-03 03:54:16 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 03:54:16 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 03:54:16 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/level.php
INFO - 2025-06-03 03:54:16 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 03:54:16 --> Final output sent to browser
DEBUG - 2025-06-03 03:54:16 --> Total execution time: 0.0867
INFO - 2025-06-03 03:57:08 --> Config Class Initialized
INFO - 2025-06-03 03:57:08 --> Hooks Class Initialized
DEBUG - 2025-06-03 03:57:08 --> UTF-8 Support Enabled
INFO - 2025-06-03 03:57:08 --> Utf8 Class Initialized
INFO - 2025-06-03 03:57:08 --> URI Class Initialized
INFO - 2025-06-03 03:57:08 --> Router Class Initialized
INFO - 2025-06-03 03:57:08 --> Output Class Initialized
INFO - 2025-06-03 03:57:08 --> Security Class Initialized
DEBUG - 2025-06-03 03:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 03:57:08 --> Input Class Initialized
INFO - 2025-06-03 03:57:08 --> Language Class Initialized
INFO - 2025-06-03 03:57:08 --> Loader Class Initialized
INFO - 2025-06-03 03:57:08 --> Helper loaded: url_helper
INFO - 2025-06-03 03:57:08 --> Helper loaded: form_helper
INFO - 2025-06-03 03:57:08 --> Database Driver Class Initialized
DEBUG - 2025-06-03 03:57:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 03:57:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 03:57:08 --> Controller Class Initialized
INFO - 2025-06-03 03:57:08 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 03:57:08 --> Model "User_model" initialized
INFO - 2025-06-03 03:57:08 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 03:57:08 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 03:57:08 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-06-03 03:57:08 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 03:57:08 --> Final output sent to browser
DEBUG - 2025-06-03 03:57:08 --> Total execution time: 0.1094
INFO - 2025-06-03 03:57:14 --> Config Class Initialized
INFO - 2025-06-03 03:57:14 --> Hooks Class Initialized
DEBUG - 2025-06-03 03:57:14 --> UTF-8 Support Enabled
INFO - 2025-06-03 03:57:14 --> Utf8 Class Initialized
INFO - 2025-06-03 03:57:14 --> URI Class Initialized
INFO - 2025-06-03 03:57:14 --> Router Class Initialized
INFO - 2025-06-03 03:57:14 --> Output Class Initialized
INFO - 2025-06-03 03:57:14 --> Security Class Initialized
DEBUG - 2025-06-03 03:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 03:57:14 --> Input Class Initialized
INFO - 2025-06-03 03:57:14 --> Language Class Initialized
INFO - 2025-06-03 03:57:14 --> Loader Class Initialized
INFO - 2025-06-03 03:57:14 --> Helper loaded: url_helper
INFO - 2025-06-03 03:57:14 --> Helper loaded: form_helper
INFO - 2025-06-03 03:57:14 --> Database Driver Class Initialized
DEBUG - 2025-06-03 03:57:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 03:57:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 03:57:14 --> Controller Class Initialized
INFO - 2025-06-03 03:57:14 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 03:57:14 --> Model "User_model" initialized
INFO - 2025-06-03 03:57:14 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 03:57:14 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 03:57:14 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-06-03 03:57:14 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 03:57:14 --> Final output sent to browser
DEBUG - 2025-06-03 03:57:14 --> Total execution time: 0.0846
INFO - 2025-06-03 03:57:17 --> Config Class Initialized
INFO - 2025-06-03 03:57:17 --> Hooks Class Initialized
DEBUG - 2025-06-03 03:57:17 --> UTF-8 Support Enabled
INFO - 2025-06-03 03:57:17 --> Utf8 Class Initialized
INFO - 2025-06-03 03:57:17 --> URI Class Initialized
INFO - 2025-06-03 03:57:17 --> Router Class Initialized
INFO - 2025-06-03 03:57:17 --> Output Class Initialized
INFO - 2025-06-03 03:57:17 --> Security Class Initialized
DEBUG - 2025-06-03 03:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 03:57:17 --> Input Class Initialized
INFO - 2025-06-03 03:57:17 --> Language Class Initialized
INFO - 2025-06-03 03:57:17 --> Loader Class Initialized
INFO - 2025-06-03 03:57:17 --> Helper loaded: url_helper
INFO - 2025-06-03 03:57:17 --> Helper loaded: form_helper
INFO - 2025-06-03 03:57:17 --> Database Driver Class Initialized
DEBUG - 2025-06-03 03:57:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 03:57:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 03:57:17 --> Controller Class Initialized
INFO - 2025-06-03 03:57:17 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 03:57:17 --> Model "User_model" initialized
INFO - 2025-06-03 03:57:17 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 03:57:17 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 03:57:17 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/level.php
INFO - 2025-06-03 03:57:17 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 03:57:17 --> Final output sent to browser
DEBUG - 2025-06-03 03:57:17 --> Total execution time: 0.0895
INFO - 2025-06-03 03:57:19 --> Config Class Initialized
INFO - 2025-06-03 03:57:19 --> Hooks Class Initialized
DEBUG - 2025-06-03 03:57:19 --> UTF-8 Support Enabled
INFO - 2025-06-03 03:57:19 --> Utf8 Class Initialized
INFO - 2025-06-03 03:57:19 --> URI Class Initialized
INFO - 2025-06-03 03:57:19 --> Router Class Initialized
INFO - 2025-06-03 03:57:19 --> Output Class Initialized
INFO - 2025-06-03 03:57:19 --> Security Class Initialized
DEBUG - 2025-06-03 03:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 03:57:19 --> Input Class Initialized
INFO - 2025-06-03 03:57:19 --> Language Class Initialized
INFO - 2025-06-03 03:57:19 --> Loader Class Initialized
INFO - 2025-06-03 03:57:19 --> Helper loaded: url_helper
INFO - 2025-06-03 03:57:19 --> Helper loaded: form_helper
INFO - 2025-06-03 03:57:19 --> Database Driver Class Initialized
DEBUG - 2025-06-03 03:57:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 03:57:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 03:57:19 --> Controller Class Initialized
INFO - 2025-06-03 03:57:19 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 03:57:19 --> Model "User_model" initialized
INFO - 2025-06-03 03:57:19 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 03:57:19 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 03:57:19 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-06-03 03:57:19 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 03:57:19 --> Final output sent to browser
DEBUG - 2025-06-03 03:57:19 --> Total execution time: 0.0961
INFO - 2025-06-03 03:57:27 --> Config Class Initialized
INFO - 2025-06-03 03:57:27 --> Hooks Class Initialized
DEBUG - 2025-06-03 03:57:27 --> UTF-8 Support Enabled
INFO - 2025-06-03 03:57:27 --> Utf8 Class Initialized
INFO - 2025-06-03 03:57:27 --> URI Class Initialized
INFO - 2025-06-03 03:57:27 --> Router Class Initialized
INFO - 2025-06-03 03:57:27 --> Output Class Initialized
INFO - 2025-06-03 03:57:27 --> Security Class Initialized
DEBUG - 2025-06-03 03:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 03:57:27 --> Input Class Initialized
INFO - 2025-06-03 03:57:27 --> Language Class Initialized
INFO - 2025-06-03 03:57:27 --> Loader Class Initialized
INFO - 2025-06-03 03:57:27 --> Helper loaded: url_helper
INFO - 2025-06-03 03:57:27 --> Helper loaded: form_helper
INFO - 2025-06-03 03:57:27 --> Database Driver Class Initialized
DEBUG - 2025-06-03 03:57:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 03:57:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 03:57:27 --> Controller Class Initialized
INFO - 2025-06-03 03:57:27 --> Model "User_model" initialized
INFO - 2025-06-03 03:57:27 --> Model "Community_model" initialized
INFO - 2025-06-03 03:57:27 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 03:57:27 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 03:57:27 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/community.php
INFO - 2025-06-03 03:57:27 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 03:57:27 --> Final output sent to browser
DEBUG - 2025-06-03 03:57:27 --> Total execution time: 0.1053
INFO - 2025-06-03 03:57:32 --> Config Class Initialized
INFO - 2025-06-03 03:57:32 --> Hooks Class Initialized
DEBUG - 2025-06-03 03:57:32 --> UTF-8 Support Enabled
INFO - 2025-06-03 03:57:32 --> Utf8 Class Initialized
INFO - 2025-06-03 03:57:32 --> URI Class Initialized
INFO - 2025-06-03 03:57:32 --> Router Class Initialized
INFO - 2025-06-03 03:57:32 --> Output Class Initialized
INFO - 2025-06-03 03:57:32 --> Security Class Initialized
DEBUG - 2025-06-03 03:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 03:57:32 --> Input Class Initialized
INFO - 2025-06-03 03:57:32 --> Language Class Initialized
INFO - 2025-06-03 03:57:32 --> Loader Class Initialized
INFO - 2025-06-03 03:57:32 --> Helper loaded: url_helper
INFO - 2025-06-03 03:57:32 --> Helper loaded: form_helper
INFO - 2025-06-03 03:57:32 --> Database Driver Class Initialized
DEBUG - 2025-06-03 03:57:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 03:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 03:57:32 --> Controller Class Initialized
INFO - 2025-06-03 03:57:32 --> Model "User_model" initialized
INFO - 2025-06-03 03:57:32 --> Model "Progress_model" initialized
INFO - 2025-06-03 03:57:32 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 03:57:32 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 03:57:32 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/dashboard.php
INFO - 2025-06-03 03:57:32 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 03:57:32 --> Final output sent to browser
DEBUG - 2025-06-03 03:57:32 --> Total execution time: 0.0983
INFO - 2025-06-03 03:58:06 --> Config Class Initialized
INFO - 2025-06-03 03:58:06 --> Hooks Class Initialized
DEBUG - 2025-06-03 03:58:06 --> UTF-8 Support Enabled
INFO - 2025-06-03 03:58:06 --> Utf8 Class Initialized
INFO - 2025-06-03 03:58:06 --> URI Class Initialized
INFO - 2025-06-03 03:58:06 --> Router Class Initialized
INFO - 2025-06-03 03:58:06 --> Output Class Initialized
INFO - 2025-06-03 03:58:06 --> Security Class Initialized
DEBUG - 2025-06-03 03:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 03:58:06 --> Input Class Initialized
INFO - 2025-06-03 03:58:06 --> Language Class Initialized
INFO - 2025-06-03 03:58:06 --> Loader Class Initialized
INFO - 2025-06-03 03:58:06 --> Helper loaded: url_helper
INFO - 2025-06-03 03:58:06 --> Helper loaded: form_helper
INFO - 2025-06-03 03:58:06 --> Database Driver Class Initialized
DEBUG - 2025-06-03 03:58:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 03:58:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 03:58:06 --> Controller Class Initialized
INFO - 2025-06-03 03:58:06 --> Model "User_model" initialized
INFO - 2025-06-03 03:58:06 --> Model "Progress_model" initialized
INFO - 2025-06-03 03:58:06 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 03:58:06 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 03:58:06 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/guide.php
INFO - 2025-06-03 03:58:06 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 03:58:06 --> Final output sent to browser
DEBUG - 2025-06-03 03:58:06 --> Total execution time: 0.0777
INFO - 2025-06-03 03:58:16 --> Config Class Initialized
INFO - 2025-06-03 03:58:16 --> Hooks Class Initialized
DEBUG - 2025-06-03 03:58:16 --> UTF-8 Support Enabled
INFO - 2025-06-03 03:58:16 --> Utf8 Class Initialized
INFO - 2025-06-03 03:58:16 --> URI Class Initialized
INFO - 2025-06-03 03:58:16 --> Router Class Initialized
INFO - 2025-06-03 03:58:16 --> Output Class Initialized
INFO - 2025-06-03 03:58:16 --> Security Class Initialized
DEBUG - 2025-06-03 03:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 03:58:16 --> Input Class Initialized
INFO - 2025-06-03 03:58:16 --> Language Class Initialized
INFO - 2025-06-03 03:58:16 --> Loader Class Initialized
INFO - 2025-06-03 03:58:16 --> Helper loaded: url_helper
INFO - 2025-06-03 03:58:16 --> Helper loaded: form_helper
INFO - 2025-06-03 03:58:16 --> Database Driver Class Initialized
DEBUG - 2025-06-03 03:58:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 03:58:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 03:58:16 --> Controller Class Initialized
INFO - 2025-06-03 03:58:16 --> Model "User_model" initialized
INFO - 2025-06-03 03:58:16 --> Model "Progress_model" initialized
INFO - 2025-06-03 03:58:16 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 03:58:16 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 03:58:16 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/dashboard.php
INFO - 2025-06-03 03:58:16 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 03:58:16 --> Final output sent to browser
DEBUG - 2025-06-03 03:58:16 --> Total execution time: 0.0824
INFO - 2025-06-03 03:58:32 --> Config Class Initialized
INFO - 2025-06-03 03:58:32 --> Hooks Class Initialized
DEBUG - 2025-06-03 03:58:32 --> UTF-8 Support Enabled
INFO - 2025-06-03 03:58:32 --> Utf8 Class Initialized
INFO - 2025-06-03 03:58:32 --> URI Class Initialized
INFO - 2025-06-03 03:58:32 --> Router Class Initialized
INFO - 2025-06-03 03:58:32 --> Output Class Initialized
INFO - 2025-06-03 03:58:32 --> Security Class Initialized
DEBUG - 2025-06-03 03:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 03:58:32 --> Input Class Initialized
INFO - 2025-06-03 03:58:32 --> Language Class Initialized
INFO - 2025-06-03 03:58:32 --> Loader Class Initialized
INFO - 2025-06-03 03:58:32 --> Helper loaded: url_helper
INFO - 2025-06-03 03:58:32 --> Helper loaded: form_helper
INFO - 2025-06-03 03:58:32 --> Database Driver Class Initialized
DEBUG - 2025-06-03 03:58:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 03:58:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 03:58:32 --> Controller Class Initialized
INFO - 2025-06-03 03:58:32 --> Model "User_model" initialized
INFO - 2025-06-03 03:58:32 --> Model "Progress_model" initialized
INFO - 2025-06-03 03:58:32 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 03:58:32 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 03:58:32 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/guide.php
INFO - 2025-06-03 03:58:32 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 03:58:32 --> Final output sent to browser
DEBUG - 2025-06-03 03:58:32 --> Total execution time: 0.0825
INFO - 2025-06-03 03:58:36 --> Config Class Initialized
INFO - 2025-06-03 03:58:36 --> Hooks Class Initialized
DEBUG - 2025-06-03 03:58:36 --> UTF-8 Support Enabled
INFO - 2025-06-03 03:58:36 --> Utf8 Class Initialized
INFO - 2025-06-03 03:58:36 --> URI Class Initialized
INFO - 2025-06-03 03:58:36 --> Router Class Initialized
INFO - 2025-06-03 03:58:36 --> Output Class Initialized
INFO - 2025-06-03 03:58:36 --> Security Class Initialized
DEBUG - 2025-06-03 03:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 03:58:36 --> Input Class Initialized
INFO - 2025-06-03 03:58:36 --> Language Class Initialized
INFO - 2025-06-03 03:58:36 --> Loader Class Initialized
INFO - 2025-06-03 03:58:36 --> Helper loaded: url_helper
INFO - 2025-06-03 03:58:36 --> Helper loaded: form_helper
INFO - 2025-06-03 03:58:36 --> Database Driver Class Initialized
DEBUG - 2025-06-03 03:58:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 03:58:36 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 03:58:36 --> Controller Class Initialized
INFO - 2025-06-03 03:58:36 --> Model "Progress_model" initialized
INFO - 2025-06-03 03:58:36 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 03:58:36 --> Model "User_model" initialized
INFO - 2025-06-03 03:58:36 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 03:58:36 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 03:58:36 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/progress_view.php
INFO - 2025-06-03 03:58:36 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 03:58:36 --> Final output sent to browser
DEBUG - 2025-06-03 03:58:36 --> Total execution time: 0.0859
INFO - 2025-06-03 03:58:37 --> Config Class Initialized
INFO - 2025-06-03 03:58:37 --> Hooks Class Initialized
DEBUG - 2025-06-03 03:58:37 --> UTF-8 Support Enabled
INFO - 2025-06-03 03:58:37 --> Utf8 Class Initialized
INFO - 2025-06-03 03:58:37 --> URI Class Initialized
INFO - 2025-06-03 03:58:37 --> Router Class Initialized
INFO - 2025-06-03 03:58:37 --> Output Class Initialized
INFO - 2025-06-03 03:58:37 --> Security Class Initialized
DEBUG - 2025-06-03 03:58:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 03:58:37 --> Input Class Initialized
INFO - 2025-06-03 03:58:37 --> Language Class Initialized
INFO - 2025-06-03 03:58:37 --> Loader Class Initialized
INFO - 2025-06-03 03:58:37 --> Helper loaded: url_helper
INFO - 2025-06-03 03:58:37 --> Helper loaded: form_helper
INFO - 2025-06-03 03:58:37 --> Database Driver Class Initialized
DEBUG - 2025-06-03 03:58:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 03:58:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 03:58:37 --> Controller Class Initialized
INFO - 2025-06-03 03:58:37 --> Model "Progress_model" initialized
INFO - 2025-06-03 03:58:37 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 03:58:37 --> Model "User_model" initialized
INFO - 2025-06-03 03:58:37 --> Final output sent to browser
DEBUG - 2025-06-03 03:58:37 --> Total execution time: 0.1454
INFO - 2025-06-03 03:58:46 --> Config Class Initialized
INFO - 2025-06-03 03:58:46 --> Hooks Class Initialized
DEBUG - 2025-06-03 03:58:46 --> UTF-8 Support Enabled
INFO - 2025-06-03 03:58:46 --> Utf8 Class Initialized
INFO - 2025-06-03 03:58:46 --> URI Class Initialized
INFO - 2025-06-03 03:58:46 --> Router Class Initialized
INFO - 2025-06-03 03:58:46 --> Output Class Initialized
INFO - 2025-06-03 03:58:46 --> Security Class Initialized
DEBUG - 2025-06-03 03:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 03:58:46 --> Input Class Initialized
INFO - 2025-06-03 03:58:46 --> Language Class Initialized
INFO - 2025-06-03 03:58:46 --> Loader Class Initialized
INFO - 2025-06-03 03:58:46 --> Helper loaded: url_helper
INFO - 2025-06-03 03:58:46 --> Helper loaded: form_helper
INFO - 2025-06-03 03:58:46 --> Database Driver Class Initialized
DEBUG - 2025-06-03 03:58:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 03:58:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 03:58:46 --> Controller Class Initialized
INFO - 2025-06-03 03:58:46 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 03:58:46 --> Model "User_model" initialized
INFO - 2025-06-03 03:58:47 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 03:58:47 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 03:58:47 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-06-03 03:58:47 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 03:58:47 --> Final output sent to browser
DEBUG - 2025-06-03 03:58:47 --> Total execution time: 0.0880
INFO - 2025-06-03 03:58:48 --> Config Class Initialized
INFO - 2025-06-03 03:58:48 --> Hooks Class Initialized
DEBUG - 2025-06-03 03:58:48 --> UTF-8 Support Enabled
INFO - 2025-06-03 03:58:48 --> Utf8 Class Initialized
INFO - 2025-06-03 03:58:48 --> URI Class Initialized
INFO - 2025-06-03 03:58:48 --> Router Class Initialized
INFO - 2025-06-03 03:58:48 --> Output Class Initialized
INFO - 2025-06-03 03:58:48 --> Security Class Initialized
DEBUG - 2025-06-03 03:58:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 03:58:48 --> Input Class Initialized
INFO - 2025-06-03 03:58:48 --> Language Class Initialized
INFO - 2025-06-03 03:58:48 --> Loader Class Initialized
INFO - 2025-06-03 03:58:48 --> Helper loaded: url_helper
INFO - 2025-06-03 03:58:48 --> Helper loaded: form_helper
INFO - 2025-06-03 03:58:48 --> Database Driver Class Initialized
DEBUG - 2025-06-03 03:58:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 03:58:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 03:58:48 --> Controller Class Initialized
INFO - 2025-06-03 03:58:48 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 03:58:48 --> Model "User_model" initialized
INFO - 2025-06-03 03:58:48 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 03:58:48 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 03:58:48 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/level.php
INFO - 2025-06-03 03:58:48 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 03:58:48 --> Final output sent to browser
DEBUG - 2025-06-03 03:58:48 --> Total execution time: 0.0798
INFO - 2025-06-03 03:58:53 --> Config Class Initialized
INFO - 2025-06-03 03:58:53 --> Hooks Class Initialized
DEBUG - 2025-06-03 03:58:53 --> UTF-8 Support Enabled
INFO - 2025-06-03 03:58:53 --> Utf8 Class Initialized
INFO - 2025-06-03 03:58:53 --> URI Class Initialized
INFO - 2025-06-03 03:58:53 --> Router Class Initialized
INFO - 2025-06-03 03:58:53 --> Output Class Initialized
INFO - 2025-06-03 03:58:53 --> Security Class Initialized
DEBUG - 2025-06-03 03:58:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 03:58:53 --> Input Class Initialized
INFO - 2025-06-03 03:58:53 --> Language Class Initialized
INFO - 2025-06-03 03:58:53 --> Loader Class Initialized
INFO - 2025-06-03 03:58:53 --> Helper loaded: url_helper
INFO - 2025-06-03 03:58:53 --> Helper loaded: form_helper
INFO - 2025-06-03 03:58:53 --> Database Driver Class Initialized
DEBUG - 2025-06-03 03:58:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 03:58:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 03:58:53 --> Controller Class Initialized
INFO - 2025-06-03 03:58:53 --> Model "User_model" initialized
INFO - 2025-06-03 03:58:53 --> Model "Community_model" initialized
INFO - 2025-06-03 03:58:53 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 03:58:53 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 03:58:53 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/community.php
INFO - 2025-06-03 03:58:53 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 03:58:53 --> Final output sent to browser
DEBUG - 2025-06-03 03:58:53 --> Total execution time: 0.1022
INFO - 2025-06-03 03:59:00 --> Config Class Initialized
INFO - 2025-06-03 03:59:00 --> Hooks Class Initialized
DEBUG - 2025-06-03 03:59:00 --> UTF-8 Support Enabled
INFO - 2025-06-03 03:59:00 --> Utf8 Class Initialized
INFO - 2025-06-03 03:59:00 --> URI Class Initialized
INFO - 2025-06-03 03:59:00 --> Router Class Initialized
INFO - 2025-06-03 03:59:00 --> Output Class Initialized
INFO - 2025-06-03 03:59:00 --> Security Class Initialized
DEBUG - 2025-06-03 03:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 03:59:00 --> Input Class Initialized
INFO - 2025-06-03 03:59:00 --> Language Class Initialized
INFO - 2025-06-03 03:59:00 --> Loader Class Initialized
INFO - 2025-06-03 03:59:00 --> Helper loaded: url_helper
INFO - 2025-06-03 03:59:00 --> Helper loaded: form_helper
INFO - 2025-06-03 03:59:00 --> Database Driver Class Initialized
DEBUG - 2025-06-03 03:59:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 03:59:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 03:59:00 --> Controller Class Initialized
INFO - 2025-06-03 03:59:00 --> Model "User_model" initialized
INFO - 2025-06-03 03:59:00 --> Model "Community_model" initialized
INFO - 2025-06-03 03:59:00 --> Config Class Initialized
INFO - 2025-06-03 03:59:00 --> Hooks Class Initialized
DEBUG - 2025-06-03 03:59:00 --> UTF-8 Support Enabled
INFO - 2025-06-03 03:59:00 --> Utf8 Class Initialized
INFO - 2025-06-03 03:59:00 --> URI Class Initialized
INFO - 2025-06-03 03:59:00 --> Router Class Initialized
INFO - 2025-06-03 03:59:00 --> Output Class Initialized
INFO - 2025-06-03 03:59:00 --> Security Class Initialized
DEBUG - 2025-06-03 03:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 03:59:00 --> Input Class Initialized
INFO - 2025-06-03 03:59:00 --> Language Class Initialized
INFO - 2025-06-03 03:59:00 --> Loader Class Initialized
INFO - 2025-06-03 03:59:00 --> Helper loaded: url_helper
INFO - 2025-06-03 03:59:00 --> Helper loaded: form_helper
INFO - 2025-06-03 03:59:00 --> Database Driver Class Initialized
DEBUG - 2025-06-03 03:59:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 03:59:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 03:59:00 --> Controller Class Initialized
INFO - 2025-06-03 03:59:00 --> Model "User_model" initialized
INFO - 2025-06-03 03:59:00 --> Model "Community_model" initialized
INFO - 2025-06-03 03:59:00 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 03:59:00 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 03:59:00 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/community.php
INFO - 2025-06-03 03:59:00 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 03:59:00 --> Final output sent to browser
DEBUG - 2025-06-03 03:59:00 --> Total execution time: 0.1044
INFO - 2025-06-03 03:59:06 --> Config Class Initialized
INFO - 2025-06-03 03:59:06 --> Hooks Class Initialized
DEBUG - 2025-06-03 03:59:06 --> UTF-8 Support Enabled
INFO - 2025-06-03 03:59:06 --> Utf8 Class Initialized
INFO - 2025-06-03 03:59:06 --> URI Class Initialized
INFO - 2025-06-03 03:59:06 --> Router Class Initialized
INFO - 2025-06-03 03:59:06 --> Output Class Initialized
INFO - 2025-06-03 03:59:06 --> Security Class Initialized
DEBUG - 2025-06-03 03:59:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 03:59:06 --> Input Class Initialized
INFO - 2025-06-03 03:59:06 --> Language Class Initialized
INFO - 2025-06-03 03:59:06 --> Loader Class Initialized
INFO - 2025-06-03 03:59:06 --> Helper loaded: url_helper
INFO - 2025-06-03 03:59:06 --> Helper loaded: form_helper
INFO - 2025-06-03 03:59:06 --> Database Driver Class Initialized
DEBUG - 2025-06-03 03:59:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 03:59:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 03:59:06 --> Controller Class Initialized
INFO - 2025-06-03 03:59:06 --> Model "User_model" initialized
INFO - 2025-06-03 03:59:06 --> Model "Community_model" initialized
INFO - 2025-06-03 03:59:06 --> Config Class Initialized
INFO - 2025-06-03 03:59:06 --> Hooks Class Initialized
DEBUG - 2025-06-03 03:59:06 --> UTF-8 Support Enabled
INFO - 2025-06-03 03:59:06 --> Utf8 Class Initialized
INFO - 2025-06-03 03:59:06 --> URI Class Initialized
INFO - 2025-06-03 03:59:06 --> Router Class Initialized
INFO - 2025-06-03 03:59:06 --> Output Class Initialized
INFO - 2025-06-03 03:59:06 --> Security Class Initialized
DEBUG - 2025-06-03 03:59:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 03:59:06 --> Input Class Initialized
INFO - 2025-06-03 03:59:06 --> Language Class Initialized
INFO - 2025-06-03 03:59:06 --> Loader Class Initialized
INFO - 2025-06-03 03:59:06 --> Helper loaded: url_helper
INFO - 2025-06-03 03:59:06 --> Helper loaded: form_helper
INFO - 2025-06-03 03:59:06 --> Database Driver Class Initialized
DEBUG - 2025-06-03 03:59:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 03:59:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 03:59:06 --> Controller Class Initialized
INFO - 2025-06-03 03:59:06 --> Model "User_model" initialized
INFO - 2025-06-03 03:59:06 --> Model "Community_model" initialized
INFO - 2025-06-03 03:59:06 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 03:59:06 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 03:59:06 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/community.php
INFO - 2025-06-03 03:59:06 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 03:59:06 --> Final output sent to browser
DEBUG - 2025-06-03 03:59:06 --> Total execution time: 0.1118
INFO - 2025-06-03 03:59:13 --> Config Class Initialized
INFO - 2025-06-03 03:59:13 --> Hooks Class Initialized
DEBUG - 2025-06-03 03:59:13 --> UTF-8 Support Enabled
INFO - 2025-06-03 03:59:13 --> Utf8 Class Initialized
INFO - 2025-06-03 03:59:13 --> URI Class Initialized
INFO - 2025-06-03 03:59:13 --> Router Class Initialized
INFO - 2025-06-03 03:59:13 --> Output Class Initialized
INFO - 2025-06-03 03:59:13 --> Security Class Initialized
DEBUG - 2025-06-03 03:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 03:59:13 --> Input Class Initialized
INFO - 2025-06-03 03:59:13 --> Language Class Initialized
INFO - 2025-06-03 03:59:13 --> Loader Class Initialized
INFO - 2025-06-03 03:59:13 --> Helper loaded: url_helper
INFO - 2025-06-03 03:59:13 --> Helper loaded: form_helper
INFO - 2025-06-03 03:59:13 --> Database Driver Class Initialized
DEBUG - 2025-06-03 03:59:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 03:59:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 03:59:14 --> Controller Class Initialized
INFO - 2025-06-03 03:59:14 --> Model "User_model" initialized
INFO - 2025-06-03 03:59:14 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 03:59:14 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 03:59:14 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/profile.php
INFO - 2025-06-03 03:59:14 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 03:59:14 --> Final output sent to browser
DEBUG - 2025-06-03 03:59:14 --> Total execution time: 0.1958
INFO - 2025-06-03 03:59:17 --> Config Class Initialized
INFO - 2025-06-03 03:59:17 --> Hooks Class Initialized
DEBUG - 2025-06-03 03:59:17 --> UTF-8 Support Enabled
INFO - 2025-06-03 03:59:17 --> Utf8 Class Initialized
INFO - 2025-06-03 03:59:17 --> URI Class Initialized
INFO - 2025-06-03 03:59:17 --> Router Class Initialized
INFO - 2025-06-03 03:59:17 --> Output Class Initialized
INFO - 2025-06-03 03:59:17 --> Security Class Initialized
DEBUG - 2025-06-03 03:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 03:59:17 --> Input Class Initialized
INFO - 2025-06-03 03:59:17 --> Language Class Initialized
INFO - 2025-06-03 03:59:17 --> Loader Class Initialized
INFO - 2025-06-03 03:59:17 --> Helper loaded: url_helper
INFO - 2025-06-03 03:59:17 --> Helper loaded: form_helper
INFO - 2025-06-03 03:59:17 --> Database Driver Class Initialized
DEBUG - 2025-06-03 03:59:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 03:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 03:59:17 --> Controller Class Initialized
INFO - 2025-06-03 03:59:17 --> Model "User_model" initialized
INFO - 2025-06-03 03:59:17 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 03:59:17 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 03:59:17 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/edit_profile.php
INFO - 2025-06-03 03:59:17 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 03:59:17 --> Final output sent to browser
DEBUG - 2025-06-03 03:59:17 --> Total execution time: 0.1030
INFO - 2025-06-03 03:59:21 --> Config Class Initialized
INFO - 2025-06-03 03:59:21 --> Hooks Class Initialized
DEBUG - 2025-06-03 03:59:21 --> UTF-8 Support Enabled
INFO - 2025-06-03 03:59:21 --> Utf8 Class Initialized
INFO - 2025-06-03 03:59:21 --> URI Class Initialized
INFO - 2025-06-03 03:59:21 --> Router Class Initialized
INFO - 2025-06-03 03:59:21 --> Output Class Initialized
INFO - 2025-06-03 03:59:21 --> Security Class Initialized
DEBUG - 2025-06-03 03:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 03:59:21 --> Input Class Initialized
INFO - 2025-06-03 03:59:21 --> Language Class Initialized
INFO - 2025-06-03 03:59:21 --> Loader Class Initialized
INFO - 2025-06-03 03:59:21 --> Helper loaded: url_helper
INFO - 2025-06-03 03:59:21 --> Helper loaded: form_helper
INFO - 2025-06-03 03:59:21 --> Database Driver Class Initialized
DEBUG - 2025-06-03 03:59:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 03:59:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 03:59:21 --> Controller Class Initialized
INFO - 2025-06-03 03:59:21 --> Model "User_model" initialized
INFO - 2025-06-03 03:59:21 --> Model "Progress_model" initialized
INFO - 2025-06-03 03:59:21 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 03:59:21 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 03:59:21 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/dashboard.php
INFO - 2025-06-03 03:59:21 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 03:59:21 --> Final output sent to browser
DEBUG - 2025-06-03 03:59:21 --> Total execution time: 0.1295
INFO - 2025-06-03 04:00:21 --> Config Class Initialized
INFO - 2025-06-03 04:00:21 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:00:21 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:00:21 --> Utf8 Class Initialized
INFO - 2025-06-03 04:00:21 --> URI Class Initialized
INFO - 2025-06-03 04:00:21 --> Router Class Initialized
INFO - 2025-06-03 04:00:21 --> Output Class Initialized
INFO - 2025-06-03 04:00:21 --> Security Class Initialized
DEBUG - 2025-06-03 04:00:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:00:21 --> Input Class Initialized
INFO - 2025-06-03 04:00:21 --> Language Class Initialized
INFO - 2025-06-03 04:00:21 --> Loader Class Initialized
INFO - 2025-06-03 04:00:21 --> Helper loaded: url_helper
INFO - 2025-06-03 04:00:21 --> Helper loaded: form_helper
INFO - 2025-06-03 04:00:21 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:00:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:00:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:00:21 --> Controller Class Initialized
INFO - 2025-06-03 04:00:21 --> Model "User_model" initialized
INFO - 2025-06-03 04:00:21 --> Form Validation Class Initialized
INFO - 2025-06-03 04:00:21 --> Config Class Initialized
INFO - 2025-06-03 04:00:21 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:00:21 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:00:21 --> Utf8 Class Initialized
INFO - 2025-06-03 04:00:21 --> URI Class Initialized
INFO - 2025-06-03 04:00:21 --> Router Class Initialized
INFO - 2025-06-03 04:00:21 --> Output Class Initialized
INFO - 2025-06-03 04:00:21 --> Security Class Initialized
DEBUG - 2025-06-03 04:00:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:00:21 --> Input Class Initialized
INFO - 2025-06-03 04:00:21 --> Language Class Initialized
INFO - 2025-06-03 04:00:21 --> Loader Class Initialized
INFO - 2025-06-03 04:00:21 --> Helper loaded: url_helper
INFO - 2025-06-03 04:00:21 --> Helper loaded: form_helper
INFO - 2025-06-03 04:00:21 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:00:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:00:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:00:21 --> Controller Class Initialized
INFO - 2025-06-03 04:00:21 --> Model "User_model" initialized
INFO - 2025-06-03 04:00:21 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-06-03 04:00:21 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/home.php
INFO - 2025-06-03 04:00:21 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-06-03 04:00:21 --> Final output sent to browser
DEBUG - 2025-06-03 04:00:21 --> Total execution time: 0.0915
INFO - 2025-06-03 04:01:25 --> Config Class Initialized
INFO - 2025-06-03 04:01:25 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:01:25 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:01:25 --> Utf8 Class Initialized
INFO - 2025-06-03 04:01:25 --> URI Class Initialized
INFO - 2025-06-03 04:01:25 --> Router Class Initialized
INFO - 2025-06-03 04:01:25 --> Output Class Initialized
INFO - 2025-06-03 04:01:25 --> Security Class Initialized
DEBUG - 2025-06-03 04:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:01:25 --> Input Class Initialized
INFO - 2025-06-03 04:01:25 --> Language Class Initialized
INFO - 2025-06-03 04:01:25 --> Loader Class Initialized
INFO - 2025-06-03 04:01:25 --> Helper loaded: url_helper
INFO - 2025-06-03 04:01:25 --> Helper loaded: form_helper
INFO - 2025-06-03 04:01:25 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:01:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:01:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:01:25 --> Controller Class Initialized
INFO - 2025-06-03 04:01:25 --> Model "User_model" initialized
INFO - 2025-06-03 04:01:25 --> Form Validation Class Initialized
INFO - 2025-06-03 04:01:25 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\auth/login.php
INFO - 2025-06-03 04:01:25 --> Final output sent to browser
DEBUG - 2025-06-03 04:01:25 --> Total execution time: 0.1013
INFO - 2025-06-03 04:01:29 --> Config Class Initialized
INFO - 2025-06-03 04:01:29 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:01:29 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:01:29 --> Utf8 Class Initialized
INFO - 2025-06-03 04:01:29 --> URI Class Initialized
INFO - 2025-06-03 04:01:29 --> Router Class Initialized
INFO - 2025-06-03 04:01:29 --> Output Class Initialized
INFO - 2025-06-03 04:01:29 --> Security Class Initialized
DEBUG - 2025-06-03 04:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:01:29 --> Input Class Initialized
INFO - 2025-06-03 04:01:29 --> Language Class Initialized
INFO - 2025-06-03 04:01:29 --> Loader Class Initialized
INFO - 2025-06-03 04:01:29 --> Helper loaded: url_helper
INFO - 2025-06-03 04:01:29 --> Helper loaded: form_helper
INFO - 2025-06-03 04:01:29 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:01:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:01:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:01:29 --> Controller Class Initialized
INFO - 2025-06-03 04:01:29 --> Model "User_model" initialized
INFO - 2025-06-03 04:01:29 --> Form Validation Class Initialized
DEBUG - 2025-06-03 04:01:29 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-06-03 04:01:29 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\auth/register.php
INFO - 2025-06-03 04:01:29 --> Final output sent to browser
DEBUG - 2025-06-03 04:01:29 --> Total execution time: 0.1960
INFO - 2025-06-03 04:01:31 --> Config Class Initialized
INFO - 2025-06-03 04:01:31 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:01:31 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:01:31 --> Utf8 Class Initialized
INFO - 2025-06-03 04:01:31 --> URI Class Initialized
INFO - 2025-06-03 04:01:31 --> Router Class Initialized
INFO - 2025-06-03 04:01:31 --> Output Class Initialized
INFO - 2025-06-03 04:01:31 --> Security Class Initialized
DEBUG - 2025-06-03 04:01:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:01:31 --> Input Class Initialized
INFO - 2025-06-03 04:01:31 --> Language Class Initialized
INFO - 2025-06-03 04:01:31 --> Loader Class Initialized
INFO - 2025-06-03 04:01:31 --> Helper loaded: url_helper
INFO - 2025-06-03 04:01:31 --> Helper loaded: form_helper
INFO - 2025-06-03 04:01:31 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:01:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:01:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:01:31 --> Controller Class Initialized
INFO - 2025-06-03 04:01:31 --> Model "User_model" initialized
INFO - 2025-06-03 04:01:31 --> Form Validation Class Initialized
DEBUG - 2025-06-03 04:01:31 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-06-03 04:01:31 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-06-03 04:01:31 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\auth/register.php
INFO - 2025-06-03 04:01:31 --> Final output sent to browser
DEBUG - 2025-06-03 04:01:31 --> Total execution time: 0.0989
INFO - 2025-06-03 04:01:40 --> Config Class Initialized
INFO - 2025-06-03 04:01:40 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:01:40 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:01:40 --> Utf8 Class Initialized
INFO - 2025-06-03 04:01:40 --> URI Class Initialized
INFO - 2025-06-03 04:01:40 --> Router Class Initialized
INFO - 2025-06-03 04:01:40 --> Output Class Initialized
INFO - 2025-06-03 04:01:40 --> Security Class Initialized
DEBUG - 2025-06-03 04:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:01:40 --> Input Class Initialized
INFO - 2025-06-03 04:01:40 --> Language Class Initialized
INFO - 2025-06-03 04:01:40 --> Loader Class Initialized
INFO - 2025-06-03 04:01:40 --> Helper loaded: url_helper
INFO - 2025-06-03 04:01:40 --> Helper loaded: form_helper
INFO - 2025-06-03 04:01:40 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:01:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:01:40 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:01:40 --> Controller Class Initialized
INFO - 2025-06-03 04:01:40 --> Model "User_model" initialized
INFO - 2025-06-03 04:01:40 --> Form Validation Class Initialized
DEBUG - 2025-06-03 04:01:40 --> Form_validation class already loaded. Second attempt ignored.
INFO - 2025-06-03 04:01:40 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\auth/register.php
INFO - 2025-06-03 04:01:40 --> Final output sent to browser
DEBUG - 2025-06-03 04:01:40 --> Total execution time: 0.0867
INFO - 2025-06-03 04:01:43 --> Config Class Initialized
INFO - 2025-06-03 04:01:43 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:01:43 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:01:43 --> Utf8 Class Initialized
INFO - 2025-06-03 04:01:43 --> URI Class Initialized
INFO - 2025-06-03 04:01:43 --> Router Class Initialized
INFO - 2025-06-03 04:01:43 --> Output Class Initialized
INFO - 2025-06-03 04:01:43 --> Security Class Initialized
DEBUG - 2025-06-03 04:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:01:43 --> Input Class Initialized
INFO - 2025-06-03 04:01:43 --> Language Class Initialized
INFO - 2025-06-03 04:01:43 --> Loader Class Initialized
INFO - 2025-06-03 04:01:43 --> Helper loaded: url_helper
INFO - 2025-06-03 04:01:43 --> Helper loaded: form_helper
INFO - 2025-06-03 04:01:43 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:01:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:01:43 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:01:43 --> Controller Class Initialized
INFO - 2025-06-03 04:01:43 --> Model "User_model" initialized
INFO - 2025-06-03 04:01:43 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-06-03 04:01:43 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/home.php
INFO - 2025-06-03 04:01:43 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-06-03 04:01:43 --> Final output sent to browser
DEBUG - 2025-06-03 04:01:43 --> Total execution time: 0.0830
INFO - 2025-06-03 04:01:46 --> Config Class Initialized
INFO - 2025-06-03 04:01:46 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:01:46 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:01:46 --> Utf8 Class Initialized
INFO - 2025-06-03 04:01:46 --> URI Class Initialized
INFO - 2025-06-03 04:01:46 --> Router Class Initialized
INFO - 2025-06-03 04:01:46 --> Output Class Initialized
INFO - 2025-06-03 04:01:46 --> Security Class Initialized
DEBUG - 2025-06-03 04:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:01:46 --> Input Class Initialized
INFO - 2025-06-03 04:01:46 --> Language Class Initialized
INFO - 2025-06-03 04:01:46 --> Loader Class Initialized
INFO - 2025-06-03 04:01:46 --> Helper loaded: url_helper
INFO - 2025-06-03 04:01:46 --> Helper loaded: form_helper
INFO - 2025-06-03 04:01:46 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:01:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:01:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:01:46 --> Controller Class Initialized
INFO - 2025-06-03 04:01:46 --> Model "User_model" initialized
INFO - 2025-06-03 04:01:46 --> Form Validation Class Initialized
INFO - 2025-06-03 04:01:46 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\auth/login.php
INFO - 2025-06-03 04:01:46 --> Final output sent to browser
DEBUG - 2025-06-03 04:01:46 --> Total execution time: 0.0907
INFO - 2025-06-03 04:01:52 --> Config Class Initialized
INFO - 2025-06-03 04:01:52 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:01:52 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:01:52 --> Utf8 Class Initialized
INFO - 2025-06-03 04:01:52 --> URI Class Initialized
INFO - 2025-06-03 04:01:52 --> Router Class Initialized
INFO - 2025-06-03 04:01:52 --> Output Class Initialized
INFO - 2025-06-03 04:01:52 --> Security Class Initialized
DEBUG - 2025-06-03 04:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:01:52 --> Input Class Initialized
INFO - 2025-06-03 04:01:52 --> Language Class Initialized
INFO - 2025-06-03 04:01:52 --> Loader Class Initialized
INFO - 2025-06-03 04:01:52 --> Helper loaded: url_helper
INFO - 2025-06-03 04:01:52 --> Helper loaded: form_helper
INFO - 2025-06-03 04:01:52 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:01:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:01:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:01:52 --> Controller Class Initialized
INFO - 2025-06-03 04:01:52 --> Model "User_model" initialized
INFO - 2025-06-03 04:01:52 --> Form Validation Class Initialized
INFO - 2025-06-03 04:01:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-06-03 04:01:52 --> Config Class Initialized
INFO - 2025-06-03 04:01:52 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:01:52 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:01:52 --> Utf8 Class Initialized
INFO - 2025-06-03 04:01:52 --> URI Class Initialized
INFO - 2025-06-03 04:01:52 --> Router Class Initialized
INFO - 2025-06-03 04:01:52 --> Output Class Initialized
INFO - 2025-06-03 04:01:52 --> Security Class Initialized
DEBUG - 2025-06-03 04:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:01:52 --> Input Class Initialized
INFO - 2025-06-03 04:01:52 --> Language Class Initialized
INFO - 2025-06-03 04:01:52 --> Loader Class Initialized
INFO - 2025-06-03 04:01:52 --> Helper loaded: url_helper
INFO - 2025-06-03 04:01:52 --> Helper loaded: form_helper
INFO - 2025-06-03 04:01:52 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:01:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:01:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:01:52 --> Controller Class Initialized
INFO - 2025-06-03 04:01:52 --> Model "User_model" initialized
INFO - 2025-06-03 04:01:52 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-06-03 04:01:52 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/home.php
INFO - 2025-06-03 04:01:52 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-06-03 04:01:52 --> Final output sent to browser
DEBUG - 2025-06-03 04:01:52 --> Total execution time: 0.0768
INFO - 2025-06-03 04:01:57 --> Config Class Initialized
INFO - 2025-06-03 04:01:57 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:01:57 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:01:57 --> Utf8 Class Initialized
INFO - 2025-06-03 04:01:57 --> URI Class Initialized
INFO - 2025-06-03 04:01:57 --> Router Class Initialized
INFO - 2025-06-03 04:01:57 --> Output Class Initialized
INFO - 2025-06-03 04:01:57 --> Security Class Initialized
DEBUG - 2025-06-03 04:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:01:57 --> Input Class Initialized
INFO - 2025-06-03 04:01:57 --> Language Class Initialized
INFO - 2025-06-03 04:01:57 --> Loader Class Initialized
INFO - 2025-06-03 04:01:57 --> Helper loaded: url_helper
INFO - 2025-06-03 04:01:57 --> Helper loaded: form_helper
INFO - 2025-06-03 04:01:57 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:01:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:01:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:01:57 --> Controller Class Initialized
INFO - 2025-06-03 04:01:57 --> Model "User_model" initialized
INFO - 2025-06-03 04:01:57 --> Model "Progress_model" initialized
INFO - 2025-06-03 04:01:57 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 04:01:57 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 04:01:57 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/dashboard.php
INFO - 2025-06-03 04:01:57 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 04:01:57 --> Final output sent to browser
DEBUG - 2025-06-03 04:01:57 --> Total execution time: 0.0980
INFO - 2025-06-03 04:02:00 --> Config Class Initialized
INFO - 2025-06-03 04:02:00 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:02:00 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:02:00 --> Utf8 Class Initialized
INFO - 2025-06-03 04:02:00 --> URI Class Initialized
INFO - 2025-06-03 04:02:00 --> Router Class Initialized
INFO - 2025-06-03 04:02:00 --> Output Class Initialized
INFO - 2025-06-03 04:02:00 --> Security Class Initialized
DEBUG - 2025-06-03 04:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:02:00 --> Input Class Initialized
INFO - 2025-06-03 04:02:00 --> Language Class Initialized
INFO - 2025-06-03 04:02:00 --> Loader Class Initialized
INFO - 2025-06-03 04:02:00 --> Helper loaded: url_helper
INFO - 2025-06-03 04:02:00 --> Helper loaded: form_helper
INFO - 2025-06-03 04:02:00 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:02:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:02:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:02:00 --> Controller Class Initialized
INFO - 2025-06-03 04:02:00 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 04:02:00 --> Model "User_model" initialized
INFO - 2025-06-03 04:02:00 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 04:02:00 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 04:02:00 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-06-03 04:02:00 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 04:02:00 --> Final output sent to browser
DEBUG - 2025-06-03 04:02:00 --> Total execution time: 0.0876
INFO - 2025-06-03 04:02:10 --> Config Class Initialized
INFO - 2025-06-03 04:02:10 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:02:10 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:02:10 --> Utf8 Class Initialized
INFO - 2025-06-03 04:02:10 --> URI Class Initialized
INFO - 2025-06-03 04:02:10 --> Router Class Initialized
INFO - 2025-06-03 04:02:10 --> Output Class Initialized
INFO - 2025-06-03 04:02:10 --> Security Class Initialized
DEBUG - 2025-06-03 04:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:02:10 --> Input Class Initialized
INFO - 2025-06-03 04:02:10 --> Language Class Initialized
INFO - 2025-06-03 04:02:10 --> Loader Class Initialized
INFO - 2025-06-03 04:02:10 --> Helper loaded: url_helper
INFO - 2025-06-03 04:02:10 --> Helper loaded: form_helper
INFO - 2025-06-03 04:02:10 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:02:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:02:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:02:10 --> Controller Class Initialized
INFO - 2025-06-03 04:02:10 --> Model "User_model" initialized
INFO - 2025-06-03 04:02:10 --> Model "Progress_model" initialized
INFO - 2025-06-03 04:02:10 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 04:02:10 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 04:02:10 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/guide.php
INFO - 2025-06-03 04:02:10 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 04:02:10 --> Final output sent to browser
DEBUG - 2025-06-03 04:02:10 --> Total execution time: 0.0828
INFO - 2025-06-03 04:03:21 --> Config Class Initialized
INFO - 2025-06-03 04:03:21 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:03:21 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:03:21 --> Utf8 Class Initialized
INFO - 2025-06-03 04:03:21 --> URI Class Initialized
INFO - 2025-06-03 04:03:21 --> Router Class Initialized
INFO - 2025-06-03 04:03:21 --> Output Class Initialized
INFO - 2025-06-03 04:03:21 --> Security Class Initialized
DEBUG - 2025-06-03 04:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:03:21 --> Input Class Initialized
INFO - 2025-06-03 04:03:21 --> Language Class Initialized
INFO - 2025-06-03 04:03:21 --> Loader Class Initialized
INFO - 2025-06-03 04:03:21 --> Helper loaded: url_helper
INFO - 2025-06-03 04:03:21 --> Helper loaded: form_helper
INFO - 2025-06-03 04:03:21 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:03:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:03:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:03:21 --> Controller Class Initialized
INFO - 2025-06-03 04:03:21 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 04:03:21 --> Model "User_model" initialized
INFO - 2025-06-03 04:03:21 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 04:03:21 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 04:03:21 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-06-03 04:03:21 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 04:03:21 --> Final output sent to browser
DEBUG - 2025-06-03 04:03:21 --> Total execution time: 0.0887
INFO - 2025-06-03 04:03:23 --> Config Class Initialized
INFO - 2025-06-03 04:03:23 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:03:23 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:03:23 --> Utf8 Class Initialized
INFO - 2025-06-03 04:03:23 --> URI Class Initialized
INFO - 2025-06-03 04:03:23 --> Router Class Initialized
INFO - 2025-06-03 04:03:23 --> Output Class Initialized
INFO - 2025-06-03 04:03:23 --> Security Class Initialized
DEBUG - 2025-06-03 04:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:03:23 --> Input Class Initialized
INFO - 2025-06-03 04:03:23 --> Language Class Initialized
INFO - 2025-06-03 04:03:23 --> Loader Class Initialized
INFO - 2025-06-03 04:03:23 --> Helper loaded: url_helper
INFO - 2025-06-03 04:03:23 --> Helper loaded: form_helper
INFO - 2025-06-03 04:03:23 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:03:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:03:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:03:23 --> Controller Class Initialized
INFO - 2025-06-03 04:03:23 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 04:03:23 --> Model "User_model" initialized
INFO - 2025-06-03 04:03:23 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 04:03:23 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 04:03:23 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/level.php
INFO - 2025-06-03 04:03:23 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 04:03:23 --> Final output sent to browser
DEBUG - 2025-06-03 04:03:23 --> Total execution time: 0.0894
INFO - 2025-06-03 04:03:24 --> Config Class Initialized
INFO - 2025-06-03 04:03:24 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:03:24 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:03:24 --> Utf8 Class Initialized
INFO - 2025-06-03 04:03:24 --> URI Class Initialized
INFO - 2025-06-03 04:03:24 --> Router Class Initialized
INFO - 2025-06-03 04:03:24 --> Output Class Initialized
INFO - 2025-06-03 04:03:24 --> Security Class Initialized
DEBUG - 2025-06-03 04:03:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:03:24 --> Input Class Initialized
INFO - 2025-06-03 04:03:24 --> Language Class Initialized
INFO - 2025-06-03 04:03:24 --> Loader Class Initialized
INFO - 2025-06-03 04:03:24 --> Helper loaded: url_helper
INFO - 2025-06-03 04:03:24 --> Helper loaded: form_helper
INFO - 2025-06-03 04:03:24 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:03:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:03:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:03:24 --> Controller Class Initialized
INFO - 2025-06-03 04:03:24 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 04:03:24 --> Model "User_model" initialized
INFO - 2025-06-03 04:03:24 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 04:03:24 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 04:03:24 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-06-03 04:03:24 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 04:03:24 --> Final output sent to browser
DEBUG - 2025-06-03 04:03:24 --> Total execution time: 0.0813
INFO - 2025-06-03 04:03:50 --> Config Class Initialized
INFO - 2025-06-03 04:03:50 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:03:50 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:03:50 --> Utf8 Class Initialized
INFO - 2025-06-03 04:03:50 --> URI Class Initialized
INFO - 2025-06-03 04:03:50 --> Router Class Initialized
INFO - 2025-06-03 04:03:50 --> Output Class Initialized
INFO - 2025-06-03 04:03:50 --> Security Class Initialized
DEBUG - 2025-06-03 04:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:03:50 --> Input Class Initialized
INFO - 2025-06-03 04:03:50 --> Language Class Initialized
INFO - 2025-06-03 04:03:50 --> Loader Class Initialized
INFO - 2025-06-03 04:03:50 --> Helper loaded: url_helper
INFO - 2025-06-03 04:03:50 --> Helper loaded: form_helper
INFO - 2025-06-03 04:03:50 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:03:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:03:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:03:50 --> Controller Class Initialized
INFO - 2025-06-03 04:03:50 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 04:03:50 --> Model "User_model" initialized
INFO - 2025-06-03 04:03:50 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 04:03:50 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 04:03:50 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/start.php
INFO - 2025-06-03 04:03:50 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 04:03:50 --> Final output sent to browser
DEBUG - 2025-06-03 04:03:50 --> Total execution time: 0.0899
INFO - 2025-06-03 04:07:07 --> Config Class Initialized
INFO - 2025-06-03 04:07:07 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:07:07 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:07:07 --> Utf8 Class Initialized
INFO - 2025-06-03 04:07:07 --> URI Class Initialized
INFO - 2025-06-03 04:07:07 --> Router Class Initialized
INFO - 2025-06-03 04:07:07 --> Output Class Initialized
INFO - 2025-06-03 04:07:07 --> Security Class Initialized
DEBUG - 2025-06-03 04:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:07:07 --> Input Class Initialized
INFO - 2025-06-03 04:07:07 --> Language Class Initialized
INFO - 2025-06-03 04:07:07 --> Loader Class Initialized
INFO - 2025-06-03 04:07:07 --> Helper loaded: url_helper
INFO - 2025-06-03 04:07:07 --> Helper loaded: form_helper
INFO - 2025-06-03 04:07:07 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:07:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:07:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:07:07 --> Controller Class Initialized
INFO - 2025-06-03 04:07:07 --> Model "User_model" initialized
INFO - 2025-06-03 04:07:07 --> Form Validation Class Initialized
INFO - 2025-06-03 04:07:07 --> Config Class Initialized
INFO - 2025-06-03 04:07:07 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:07:07 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:07:07 --> Utf8 Class Initialized
INFO - 2025-06-03 04:07:07 --> URI Class Initialized
INFO - 2025-06-03 04:07:07 --> Router Class Initialized
INFO - 2025-06-03 04:07:07 --> Output Class Initialized
INFO - 2025-06-03 04:07:07 --> Security Class Initialized
DEBUG - 2025-06-03 04:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:07:07 --> Input Class Initialized
INFO - 2025-06-03 04:07:07 --> Language Class Initialized
INFO - 2025-06-03 04:07:07 --> Loader Class Initialized
INFO - 2025-06-03 04:07:07 --> Helper loaded: url_helper
INFO - 2025-06-03 04:07:07 --> Helper loaded: form_helper
INFO - 2025-06-03 04:07:07 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:07:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:07:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:07:07 --> Controller Class Initialized
INFO - 2025-06-03 04:07:07 --> Model "User_model" initialized
INFO - 2025-06-03 04:07:07 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-06-03 04:07:07 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/home.php
INFO - 2025-06-03 04:07:07 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-06-03 04:07:07 --> Final output sent to browser
DEBUG - 2025-06-03 04:07:07 --> Total execution time: 0.1844
INFO - 2025-06-03 04:07:23 --> Config Class Initialized
INFO - 2025-06-03 04:07:23 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:07:23 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:07:23 --> Utf8 Class Initialized
INFO - 2025-06-03 04:07:23 --> URI Class Initialized
INFO - 2025-06-03 04:07:23 --> Router Class Initialized
INFO - 2025-06-03 04:07:23 --> Output Class Initialized
INFO - 2025-06-03 04:07:23 --> Security Class Initialized
DEBUG - 2025-06-03 04:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:07:23 --> Input Class Initialized
INFO - 2025-06-03 04:07:23 --> Language Class Initialized
INFO - 2025-06-03 04:07:23 --> Loader Class Initialized
INFO - 2025-06-03 04:07:23 --> Helper loaded: url_helper
INFO - 2025-06-03 04:07:23 --> Helper loaded: form_helper
INFO - 2025-06-03 04:07:23 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:07:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:07:23 --> Controller Class Initialized
INFO - 2025-06-03 04:07:23 --> Model "User_model" initialized
INFO - 2025-06-03 04:07:23 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-06-03 04:07:23 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/artikel.php
INFO - 2025-06-03 04:07:23 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-06-03 04:07:23 --> Final output sent to browser
DEBUG - 2025-06-03 04:07:23 --> Total execution time: 0.0852
INFO - 2025-06-03 04:07:55 --> Config Class Initialized
INFO - 2025-06-03 04:07:55 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:07:55 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:07:55 --> Utf8 Class Initialized
INFO - 2025-06-03 04:07:55 --> URI Class Initialized
INFO - 2025-06-03 04:07:55 --> Router Class Initialized
INFO - 2025-06-03 04:07:55 --> Output Class Initialized
INFO - 2025-06-03 04:07:55 --> Security Class Initialized
DEBUG - 2025-06-03 04:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:07:55 --> Input Class Initialized
INFO - 2025-06-03 04:07:55 --> Language Class Initialized
INFO - 2025-06-03 04:07:55 --> Loader Class Initialized
INFO - 2025-06-03 04:07:55 --> Helper loaded: url_helper
INFO - 2025-06-03 04:07:55 --> Helper loaded: form_helper
INFO - 2025-06-03 04:07:55 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:07:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:07:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:07:55 --> Controller Class Initialized
INFO - 2025-06-03 04:07:55 --> Model "User_model" initialized
INFO - 2025-06-03 04:07:55 --> Form Validation Class Initialized
INFO - 2025-06-03 04:07:55 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\auth/login.php
INFO - 2025-06-03 04:07:55 --> Final output sent to browser
DEBUG - 2025-06-03 04:07:55 --> Total execution time: 0.0828
INFO - 2025-06-03 04:08:01 --> Config Class Initialized
INFO - 2025-06-03 04:08:01 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:08:01 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:08:01 --> Utf8 Class Initialized
INFO - 2025-06-03 04:08:01 --> URI Class Initialized
INFO - 2025-06-03 04:08:01 --> Router Class Initialized
INFO - 2025-06-03 04:08:01 --> Output Class Initialized
INFO - 2025-06-03 04:08:01 --> Security Class Initialized
DEBUG - 2025-06-03 04:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:08:01 --> Input Class Initialized
INFO - 2025-06-03 04:08:01 --> Language Class Initialized
INFO - 2025-06-03 04:08:01 --> Loader Class Initialized
INFO - 2025-06-03 04:08:01 --> Helper loaded: url_helper
INFO - 2025-06-03 04:08:01 --> Helper loaded: form_helper
INFO - 2025-06-03 04:08:01 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:08:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:08:01 --> Controller Class Initialized
INFO - 2025-06-03 04:08:01 --> Model "User_model" initialized
INFO - 2025-06-03 04:08:01 --> Form Validation Class Initialized
INFO - 2025-06-03 04:08:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-06-03 04:08:01 --> Config Class Initialized
INFO - 2025-06-03 04:08:01 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:08:01 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:08:01 --> Utf8 Class Initialized
INFO - 2025-06-03 04:08:01 --> URI Class Initialized
INFO - 2025-06-03 04:08:01 --> Router Class Initialized
INFO - 2025-06-03 04:08:01 --> Output Class Initialized
INFO - 2025-06-03 04:08:01 --> Security Class Initialized
DEBUG - 2025-06-03 04:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:08:01 --> Input Class Initialized
INFO - 2025-06-03 04:08:01 --> Language Class Initialized
INFO - 2025-06-03 04:08:01 --> Loader Class Initialized
INFO - 2025-06-03 04:08:01 --> Helper loaded: url_helper
INFO - 2025-06-03 04:08:01 --> Helper loaded: form_helper
INFO - 2025-06-03 04:08:01 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:08:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:08:01 --> Controller Class Initialized
INFO - 2025-06-03 04:08:01 --> Model "User_model" initialized
INFO - 2025-06-03 04:08:01 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-06-03 04:08:01 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/home.php
INFO - 2025-06-03 04:08:01 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-06-03 04:08:01 --> Final output sent to browser
DEBUG - 2025-06-03 04:08:01 --> Total execution time: 0.0801
INFO - 2025-06-03 04:08:04 --> Config Class Initialized
INFO - 2025-06-03 04:08:04 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:08:04 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:08:04 --> Utf8 Class Initialized
INFO - 2025-06-03 04:08:04 --> URI Class Initialized
INFO - 2025-06-03 04:08:04 --> Router Class Initialized
INFO - 2025-06-03 04:08:04 --> Output Class Initialized
INFO - 2025-06-03 04:08:04 --> Security Class Initialized
DEBUG - 2025-06-03 04:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:08:05 --> Input Class Initialized
INFO - 2025-06-03 04:08:05 --> Language Class Initialized
INFO - 2025-06-03 04:08:05 --> Loader Class Initialized
INFO - 2025-06-03 04:08:05 --> Helper loaded: url_helper
INFO - 2025-06-03 04:08:05 --> Helper loaded: form_helper
INFO - 2025-06-03 04:08:05 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:08:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:08:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:08:05 --> Controller Class Initialized
INFO - 2025-06-03 04:08:05 --> Model "User_model" initialized
INFO - 2025-06-03 04:08:05 --> Model "Progress_model" initialized
INFO - 2025-06-03 04:08:05 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 04:08:05 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 04:08:05 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/dashboard.php
INFO - 2025-06-03 04:08:05 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 04:08:05 --> Final output sent to browser
DEBUG - 2025-06-03 04:08:05 --> Total execution time: 0.1058
INFO - 2025-06-03 04:08:51 --> Config Class Initialized
INFO - 2025-06-03 04:08:51 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:08:51 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:08:51 --> Utf8 Class Initialized
INFO - 2025-06-03 04:08:51 --> URI Class Initialized
INFO - 2025-06-03 04:08:51 --> Router Class Initialized
INFO - 2025-06-03 04:08:51 --> Output Class Initialized
INFO - 2025-06-03 04:08:51 --> Security Class Initialized
DEBUG - 2025-06-03 04:08:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:08:51 --> Input Class Initialized
INFO - 2025-06-03 04:08:51 --> Language Class Initialized
INFO - 2025-06-03 04:08:51 --> Loader Class Initialized
INFO - 2025-06-03 04:08:51 --> Helper loaded: url_helper
INFO - 2025-06-03 04:08:51 --> Helper loaded: form_helper
INFO - 2025-06-03 04:08:51 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:08:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:08:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:08:51 --> Controller Class Initialized
INFO - 2025-06-03 04:08:51 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 04:08:51 --> Model "User_model" initialized
INFO - 2025-06-03 04:08:51 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 04:08:51 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 04:08:51 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-06-03 04:08:51 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 04:08:51 --> Final output sent to browser
DEBUG - 2025-06-03 04:08:51 --> Total execution time: 0.0984
INFO - 2025-06-03 04:08:53 --> Config Class Initialized
INFO - 2025-06-03 04:08:53 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:08:53 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:08:53 --> Utf8 Class Initialized
INFO - 2025-06-03 04:08:53 --> URI Class Initialized
INFO - 2025-06-03 04:08:53 --> Router Class Initialized
INFO - 2025-06-03 04:08:53 --> Output Class Initialized
INFO - 2025-06-03 04:08:53 --> Security Class Initialized
DEBUG - 2025-06-03 04:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:08:53 --> Input Class Initialized
INFO - 2025-06-03 04:08:53 --> Language Class Initialized
INFO - 2025-06-03 04:08:53 --> Loader Class Initialized
INFO - 2025-06-03 04:08:53 --> Helper loaded: url_helper
INFO - 2025-06-03 04:08:53 --> Helper loaded: form_helper
INFO - 2025-06-03 04:08:53 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:08:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:08:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:08:53 --> Controller Class Initialized
INFO - 2025-06-03 04:08:53 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 04:08:53 --> Model "User_model" initialized
INFO - 2025-06-03 04:08:53 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 04:08:53 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 04:08:53 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/level.php
INFO - 2025-06-03 04:08:53 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 04:08:53 --> Final output sent to browser
DEBUG - 2025-06-03 04:08:53 --> Total execution time: 0.0910
INFO - 2025-06-03 04:09:05 --> Config Class Initialized
INFO - 2025-06-03 04:09:05 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:09:05 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:09:05 --> Utf8 Class Initialized
INFO - 2025-06-03 04:09:05 --> URI Class Initialized
INFO - 2025-06-03 04:09:05 --> Router Class Initialized
INFO - 2025-06-03 04:09:05 --> Output Class Initialized
INFO - 2025-06-03 04:09:05 --> Security Class Initialized
DEBUG - 2025-06-03 04:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:09:05 --> Input Class Initialized
INFO - 2025-06-03 04:09:05 --> Language Class Initialized
INFO - 2025-06-03 04:09:05 --> Loader Class Initialized
INFO - 2025-06-03 04:09:06 --> Helper loaded: url_helper
INFO - 2025-06-03 04:09:06 --> Helper loaded: form_helper
INFO - 2025-06-03 04:09:06 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:09:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:09:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:09:06 --> Controller Class Initialized
INFO - 2025-06-03 04:09:06 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 04:09:06 --> Model "User_model" initialized
INFO - 2025-06-03 04:09:06 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 04:09:06 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 04:09:06 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-06-03 04:09:06 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 04:09:06 --> Final output sent to browser
DEBUG - 2025-06-03 04:09:06 --> Total execution time: 0.0823
INFO - 2025-06-03 04:09:07 --> Config Class Initialized
INFO - 2025-06-03 04:09:07 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:09:07 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:09:07 --> Utf8 Class Initialized
INFO - 2025-06-03 04:09:07 --> URI Class Initialized
INFO - 2025-06-03 04:09:07 --> Router Class Initialized
INFO - 2025-06-03 04:09:07 --> Output Class Initialized
INFO - 2025-06-03 04:09:07 --> Security Class Initialized
DEBUG - 2025-06-03 04:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:09:07 --> Input Class Initialized
INFO - 2025-06-03 04:09:07 --> Language Class Initialized
INFO - 2025-06-03 04:09:07 --> Loader Class Initialized
INFO - 2025-06-03 04:09:07 --> Helper loaded: url_helper
INFO - 2025-06-03 04:09:07 --> Helper loaded: form_helper
INFO - 2025-06-03 04:09:07 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:09:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:09:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:09:07 --> Controller Class Initialized
INFO - 2025-06-03 04:09:07 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 04:09:07 --> Model "User_model" initialized
INFO - 2025-06-03 04:09:07 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 04:09:07 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 04:09:07 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/start.php
INFO - 2025-06-03 04:09:07 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 04:09:07 --> Final output sent to browser
DEBUG - 2025-06-03 04:09:07 --> Total execution time: 0.0828
INFO - 2025-06-03 04:09:11 --> Config Class Initialized
INFO - 2025-06-03 04:09:11 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:09:11 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:09:11 --> Utf8 Class Initialized
INFO - 2025-06-03 04:09:11 --> URI Class Initialized
INFO - 2025-06-03 04:09:11 --> Router Class Initialized
INFO - 2025-06-03 04:09:11 --> Output Class Initialized
INFO - 2025-06-03 04:09:11 --> Security Class Initialized
DEBUG - 2025-06-03 04:09:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:09:11 --> Input Class Initialized
INFO - 2025-06-03 04:09:11 --> Language Class Initialized
INFO - 2025-06-03 04:09:11 --> Loader Class Initialized
INFO - 2025-06-03 04:09:11 --> Helper loaded: url_helper
INFO - 2025-06-03 04:09:11 --> Helper loaded: form_helper
INFO - 2025-06-03 04:09:11 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:09:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:09:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:09:11 --> Controller Class Initialized
INFO - 2025-06-03 04:09:11 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 04:09:11 --> Model "User_model" initialized
INFO - 2025-06-03 04:09:11 --> Final output sent to browser
DEBUG - 2025-06-03 04:09:11 --> Total execution time: 0.2283
INFO - 2025-06-03 04:12:58 --> Config Class Initialized
INFO - 2025-06-03 04:12:58 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:12:58 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:12:58 --> Utf8 Class Initialized
INFO - 2025-06-03 04:12:58 --> URI Class Initialized
INFO - 2025-06-03 04:12:58 --> Router Class Initialized
INFO - 2025-06-03 04:12:58 --> Output Class Initialized
INFO - 2025-06-03 04:12:58 --> Security Class Initialized
DEBUG - 2025-06-03 04:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:12:58 --> Input Class Initialized
INFO - 2025-06-03 04:12:58 --> Language Class Initialized
INFO - 2025-06-03 04:12:58 --> Loader Class Initialized
INFO - 2025-06-03 04:12:58 --> Helper loaded: url_helper
INFO - 2025-06-03 04:12:58 --> Helper loaded: form_helper
INFO - 2025-06-03 04:12:58 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:12:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:12:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:12:58 --> Controller Class Initialized
INFO - 2025-06-03 04:12:58 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 04:12:58 --> Model "User_model" initialized
INFO - 2025-06-03 04:12:58 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 04:12:58 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 04:12:58 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-06-03 04:12:58 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 04:12:58 --> Final output sent to browser
DEBUG - 2025-06-03 04:12:58 --> Total execution time: 0.0710
INFO - 2025-06-03 04:14:45 --> Config Class Initialized
INFO - 2025-06-03 04:14:45 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:14:45 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:14:45 --> Utf8 Class Initialized
INFO - 2025-06-03 04:14:45 --> URI Class Initialized
INFO - 2025-06-03 04:14:45 --> Router Class Initialized
INFO - 2025-06-03 04:14:45 --> Output Class Initialized
INFO - 2025-06-03 04:14:45 --> Security Class Initialized
DEBUG - 2025-06-03 04:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:14:45 --> Input Class Initialized
INFO - 2025-06-03 04:14:45 --> Language Class Initialized
INFO - 2025-06-03 04:14:45 --> Loader Class Initialized
INFO - 2025-06-03 04:14:45 --> Helper loaded: url_helper
INFO - 2025-06-03 04:14:45 --> Helper loaded: form_helper
INFO - 2025-06-03 04:14:45 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:14:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:14:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:14:45 --> Controller Class Initialized
INFO - 2025-06-03 04:14:45 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 04:14:45 --> Model "User_model" initialized
INFO - 2025-06-03 04:14:45 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 04:14:45 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 04:14:45 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/level.php
INFO - 2025-06-03 04:14:45 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 04:14:45 --> Final output sent to browser
DEBUG - 2025-06-03 04:14:45 --> Total execution time: 0.0842
INFO - 2025-06-03 04:14:46 --> Config Class Initialized
INFO - 2025-06-03 04:14:46 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:14:46 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:14:46 --> Utf8 Class Initialized
INFO - 2025-06-03 04:14:46 --> URI Class Initialized
INFO - 2025-06-03 04:14:46 --> Router Class Initialized
INFO - 2025-06-03 04:14:46 --> Output Class Initialized
INFO - 2025-06-03 04:14:46 --> Security Class Initialized
DEBUG - 2025-06-03 04:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:14:46 --> Input Class Initialized
INFO - 2025-06-03 04:14:46 --> Language Class Initialized
INFO - 2025-06-03 04:14:46 --> Loader Class Initialized
INFO - 2025-06-03 04:14:46 --> Helper loaded: url_helper
INFO - 2025-06-03 04:14:46 --> Helper loaded: form_helper
INFO - 2025-06-03 04:14:46 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:14:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:14:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:14:46 --> Controller Class Initialized
INFO - 2025-06-03 04:14:46 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 04:14:46 --> Model "User_model" initialized
INFO - 2025-06-03 04:14:46 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 04:14:46 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 04:14:46 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-06-03 04:14:46 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 04:14:46 --> Final output sent to browser
DEBUG - 2025-06-03 04:14:46 --> Total execution time: 0.0766
INFO - 2025-06-03 04:16:07 --> Config Class Initialized
INFO - 2025-06-03 04:16:07 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:16:07 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:16:07 --> Utf8 Class Initialized
INFO - 2025-06-03 04:16:07 --> URI Class Initialized
INFO - 2025-06-03 04:16:07 --> Router Class Initialized
INFO - 2025-06-03 04:16:07 --> Output Class Initialized
INFO - 2025-06-03 04:16:07 --> Security Class Initialized
DEBUG - 2025-06-03 04:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:16:07 --> Input Class Initialized
INFO - 2025-06-03 04:16:07 --> Language Class Initialized
INFO - 2025-06-03 04:16:07 --> Loader Class Initialized
INFO - 2025-06-03 04:16:07 --> Helper loaded: url_helper
INFO - 2025-06-03 04:16:07 --> Helper loaded: form_helper
INFO - 2025-06-03 04:16:07 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:16:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:16:07 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:16:07 --> Controller Class Initialized
INFO - 2025-06-03 04:16:07 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 04:16:07 --> Model "User_model" initialized
INFO - 2025-06-03 04:16:07 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 04:16:07 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 04:16:07 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-06-03 04:16:07 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 04:16:07 --> Final output sent to browser
DEBUG - 2025-06-03 04:16:07 --> Total execution time: 0.1401
INFO - 2025-06-03 04:16:10 --> Config Class Initialized
INFO - 2025-06-03 04:16:10 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:16:10 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:16:10 --> Utf8 Class Initialized
INFO - 2025-06-03 04:16:10 --> URI Class Initialized
INFO - 2025-06-03 04:16:10 --> Router Class Initialized
INFO - 2025-06-03 04:16:10 --> Output Class Initialized
INFO - 2025-06-03 04:16:10 --> Security Class Initialized
DEBUG - 2025-06-03 04:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:16:10 --> Input Class Initialized
INFO - 2025-06-03 04:16:10 --> Language Class Initialized
INFO - 2025-06-03 04:16:10 --> Loader Class Initialized
INFO - 2025-06-03 04:16:10 --> Helper loaded: url_helper
INFO - 2025-06-03 04:16:10 --> Helper loaded: form_helper
INFO - 2025-06-03 04:16:10 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:16:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:16:10 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:16:10 --> Controller Class Initialized
INFO - 2025-06-03 04:16:10 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 04:16:10 --> Model "User_model" initialized
INFO - 2025-06-03 04:16:10 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 04:16:10 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 04:16:10 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/level.php
INFO - 2025-06-03 04:16:10 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 04:16:10 --> Final output sent to browser
DEBUG - 2025-06-03 04:16:10 --> Total execution time: 0.0918
INFO - 2025-06-03 04:16:13 --> Config Class Initialized
INFO - 2025-06-03 04:16:13 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:16:13 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:16:13 --> Utf8 Class Initialized
INFO - 2025-06-03 04:16:13 --> URI Class Initialized
INFO - 2025-06-03 04:16:13 --> Router Class Initialized
INFO - 2025-06-03 04:16:13 --> Output Class Initialized
INFO - 2025-06-03 04:16:13 --> Security Class Initialized
DEBUG - 2025-06-03 04:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:16:13 --> Input Class Initialized
INFO - 2025-06-03 04:16:13 --> Language Class Initialized
INFO - 2025-06-03 04:16:13 --> Loader Class Initialized
INFO - 2025-06-03 04:16:13 --> Helper loaded: url_helper
INFO - 2025-06-03 04:16:13 --> Helper loaded: form_helper
INFO - 2025-06-03 04:16:13 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:16:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:16:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:16:13 --> Controller Class Initialized
INFO - 2025-06-03 04:16:13 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 04:16:13 --> Model "User_model" initialized
INFO - 2025-06-03 04:16:13 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 04:16:13 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
ERROR - 2025-06-03 04:16:13 --> Severity: Warning --> Undefined variable $exercise C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard\olahraga\menu.php 46
ERROR - 2025-06-03 04:16:13 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard\olahraga\menu.php 46
INFO - 2025-06-03 04:16:13 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-06-03 04:16:13 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 04:16:13 --> Final output sent to browser
DEBUG - 2025-06-03 04:16:13 --> Total execution time: 0.0914
INFO - 2025-06-03 04:16:45 --> Config Class Initialized
INFO - 2025-06-03 04:16:45 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:16:45 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:16:45 --> Utf8 Class Initialized
INFO - 2025-06-03 04:16:45 --> URI Class Initialized
INFO - 2025-06-03 04:16:45 --> Router Class Initialized
INFO - 2025-06-03 04:16:45 --> Output Class Initialized
INFO - 2025-06-03 04:16:45 --> Security Class Initialized
DEBUG - 2025-06-03 04:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:16:45 --> Input Class Initialized
INFO - 2025-06-03 04:16:45 --> Language Class Initialized
INFO - 2025-06-03 04:16:45 --> Loader Class Initialized
INFO - 2025-06-03 04:16:45 --> Helper loaded: url_helper
INFO - 2025-06-03 04:16:45 --> Helper loaded: form_helper
INFO - 2025-06-03 04:16:45 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:16:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:16:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:16:45 --> Controller Class Initialized
INFO - 2025-06-03 04:16:45 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 04:16:45 --> Model "User_model" initialized
INFO - 2025-06-03 04:16:45 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 04:16:45 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 04:16:46 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-06-03 04:16:46 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 04:16:46 --> Final output sent to browser
DEBUG - 2025-06-03 04:16:46 --> Total execution time: 0.1324
INFO - 2025-06-03 04:16:55 --> Config Class Initialized
INFO - 2025-06-03 04:16:55 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:16:55 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:16:55 --> Utf8 Class Initialized
INFO - 2025-06-03 04:16:55 --> URI Class Initialized
INFO - 2025-06-03 04:16:55 --> Router Class Initialized
INFO - 2025-06-03 04:16:55 --> Output Class Initialized
INFO - 2025-06-03 04:16:55 --> Security Class Initialized
DEBUG - 2025-06-03 04:16:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:16:55 --> Input Class Initialized
INFO - 2025-06-03 04:16:55 --> Language Class Initialized
INFO - 2025-06-03 04:16:55 --> Loader Class Initialized
INFO - 2025-06-03 04:16:55 --> Helper loaded: url_helper
INFO - 2025-06-03 04:16:55 --> Helper loaded: form_helper
INFO - 2025-06-03 04:16:55 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:16:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:16:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:16:55 --> Controller Class Initialized
INFO - 2025-06-03 04:16:55 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 04:16:55 --> Model "User_model" initialized
INFO - 2025-06-03 04:16:55 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 04:16:55 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 04:16:55 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-06-03 04:16:55 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 04:16:55 --> Final output sent to browser
DEBUG - 2025-06-03 04:16:55 --> Total execution time: 0.0804
INFO - 2025-06-03 04:16:59 --> Config Class Initialized
INFO - 2025-06-03 04:16:59 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:16:59 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:16:59 --> Utf8 Class Initialized
INFO - 2025-06-03 04:16:59 --> URI Class Initialized
INFO - 2025-06-03 04:16:59 --> Router Class Initialized
INFO - 2025-06-03 04:16:59 --> Output Class Initialized
INFO - 2025-06-03 04:16:59 --> Security Class Initialized
DEBUG - 2025-06-03 04:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:16:59 --> Input Class Initialized
INFO - 2025-06-03 04:16:59 --> Language Class Initialized
INFO - 2025-06-03 04:16:59 --> Loader Class Initialized
INFO - 2025-06-03 04:16:59 --> Helper loaded: url_helper
INFO - 2025-06-03 04:16:59 --> Helper loaded: form_helper
INFO - 2025-06-03 04:16:59 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:16:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:16:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:16:59 --> Controller Class Initialized
INFO - 2025-06-03 04:16:59 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 04:16:59 --> Model "User_model" initialized
INFO - 2025-06-03 04:16:59 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 04:16:59 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 04:16:59 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-06-03 04:16:59 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 04:16:59 --> Final output sent to browser
DEBUG - 2025-06-03 04:16:59 --> Total execution time: 0.0844
INFO - 2025-06-03 04:17:09 --> Config Class Initialized
INFO - 2025-06-03 04:17:09 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:17:09 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:17:09 --> Utf8 Class Initialized
INFO - 2025-06-03 04:17:09 --> URI Class Initialized
INFO - 2025-06-03 04:17:09 --> Router Class Initialized
INFO - 2025-06-03 04:17:09 --> Output Class Initialized
INFO - 2025-06-03 04:17:09 --> Security Class Initialized
DEBUG - 2025-06-03 04:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:17:09 --> Input Class Initialized
INFO - 2025-06-03 04:17:09 --> Language Class Initialized
INFO - 2025-06-03 04:17:09 --> Loader Class Initialized
INFO - 2025-06-03 04:17:09 --> Helper loaded: url_helper
INFO - 2025-06-03 04:17:09 --> Helper loaded: form_helper
INFO - 2025-06-03 04:17:09 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:17:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:17:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:17:09 --> Controller Class Initialized
INFO - 2025-06-03 04:17:09 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 04:17:09 --> Model "User_model" initialized
INFO - 2025-06-03 04:17:09 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 04:17:09 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
ERROR - 2025-06-03 04:17:09 --> Severity: Warning --> Undefined variable $exercise C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard\olahraga\menu.php 46
ERROR - 2025-06-03 04:17:09 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard\olahraga\menu.php 46
INFO - 2025-06-03 04:17:09 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-06-03 04:17:09 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 04:17:09 --> Final output sent to browser
DEBUG - 2025-06-03 04:17:09 --> Total execution time: 0.0780
INFO - 2025-06-03 04:17:14 --> Config Class Initialized
INFO - 2025-06-03 04:17:14 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:17:14 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:17:14 --> Utf8 Class Initialized
INFO - 2025-06-03 04:17:27 --> Config Class Initialized
INFO - 2025-06-03 04:17:27 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:17:27 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:17:27 --> Utf8 Class Initialized
INFO - 2025-06-03 04:17:27 --> URI Class Initialized
INFO - 2025-06-03 04:17:27 --> Router Class Initialized
INFO - 2025-06-03 04:17:27 --> Output Class Initialized
INFO - 2025-06-03 04:17:27 --> Security Class Initialized
DEBUG - 2025-06-03 04:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:17:27 --> Input Class Initialized
INFO - 2025-06-03 04:17:27 --> Language Class Initialized
INFO - 2025-06-03 04:17:27 --> Loader Class Initialized
INFO - 2025-06-03 04:17:27 --> Helper loaded: url_helper
INFO - 2025-06-03 04:17:27 --> Helper loaded: form_helper
INFO - 2025-06-03 04:17:27 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:17:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:17:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:17:27 --> Controller Class Initialized
INFO - 2025-06-03 04:17:27 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 04:17:27 --> Model "User_model" initialized
INFO - 2025-06-03 04:17:27 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 04:17:27 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 04:17:27 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-06-03 04:17:27 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 04:17:27 --> Final output sent to browser
DEBUG - 2025-06-03 04:17:27 --> Total execution time: 0.1181
INFO - 2025-06-03 04:17:30 --> Config Class Initialized
INFO - 2025-06-03 04:17:30 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:17:30 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:17:30 --> Utf8 Class Initialized
INFO - 2025-06-03 04:17:30 --> URI Class Initialized
INFO - 2025-06-03 04:17:30 --> Router Class Initialized
INFO - 2025-06-03 04:17:30 --> Output Class Initialized
INFO - 2025-06-03 04:17:30 --> Security Class Initialized
DEBUG - 2025-06-03 04:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:17:30 --> Input Class Initialized
INFO - 2025-06-03 04:17:30 --> Language Class Initialized
INFO - 2025-06-03 04:17:30 --> Loader Class Initialized
INFO - 2025-06-03 04:17:30 --> Helper loaded: url_helper
INFO - 2025-06-03 04:17:30 --> Helper loaded: form_helper
INFO - 2025-06-03 04:17:30 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:17:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:17:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:17:30 --> Controller Class Initialized
INFO - 2025-06-03 04:17:31 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 04:17:31 --> Model "User_model" initialized
INFO - 2025-06-03 04:17:31 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 04:17:31 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 04:17:31 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-06-03 04:17:31 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 04:17:31 --> Final output sent to browser
DEBUG - 2025-06-03 04:17:31 --> Total execution time: 0.0870
INFO - 2025-06-03 04:17:33 --> Config Class Initialized
INFO - 2025-06-03 04:17:33 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:17:33 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:17:33 --> Utf8 Class Initialized
INFO - 2025-06-03 04:17:33 --> URI Class Initialized
INFO - 2025-06-03 04:17:33 --> Router Class Initialized
INFO - 2025-06-03 04:17:33 --> Output Class Initialized
INFO - 2025-06-03 04:17:33 --> Security Class Initialized
DEBUG - 2025-06-03 04:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:17:33 --> Input Class Initialized
INFO - 2025-06-03 04:17:33 --> Language Class Initialized
INFO - 2025-06-03 04:17:33 --> Loader Class Initialized
INFO - 2025-06-03 04:17:33 --> Helper loaded: url_helper
INFO - 2025-06-03 04:17:33 --> Helper loaded: form_helper
INFO - 2025-06-03 04:17:33 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:17:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:17:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:17:33 --> Controller Class Initialized
INFO - 2025-06-03 04:17:33 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 04:17:33 --> Model "User_model" initialized
INFO - 2025-06-03 04:17:33 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 04:17:33 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 04:17:33 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/level.php
INFO - 2025-06-03 04:17:33 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 04:17:33 --> Final output sent to browser
DEBUG - 2025-06-03 04:17:33 --> Total execution time: 0.0827
INFO - 2025-06-03 04:17:35 --> Config Class Initialized
INFO - 2025-06-03 04:17:35 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:17:35 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:17:35 --> Utf8 Class Initialized
INFO - 2025-06-03 04:17:35 --> URI Class Initialized
INFO - 2025-06-03 04:17:35 --> Router Class Initialized
INFO - 2025-06-03 04:17:35 --> Output Class Initialized
INFO - 2025-06-03 04:17:35 --> Security Class Initialized
DEBUG - 2025-06-03 04:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:17:35 --> Input Class Initialized
INFO - 2025-06-03 04:17:35 --> Language Class Initialized
INFO - 2025-06-03 04:17:35 --> Loader Class Initialized
INFO - 2025-06-03 04:17:35 --> Helper loaded: url_helper
INFO - 2025-06-03 04:17:35 --> Helper loaded: form_helper
INFO - 2025-06-03 04:17:35 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:17:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:17:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:17:35 --> Controller Class Initialized
INFO - 2025-06-03 04:17:35 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 04:17:35 --> Model "User_model" initialized
INFO - 2025-06-03 04:17:35 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 04:17:35 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 04:17:35 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-06-03 04:17:35 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 04:17:35 --> Final output sent to browser
DEBUG - 2025-06-03 04:17:35 --> Total execution time: 0.0951
INFO - 2025-06-03 04:17:39 --> Config Class Initialized
INFO - 2025-06-03 04:17:39 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:17:39 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:17:39 --> Utf8 Class Initialized
INFO - 2025-06-03 04:17:39 --> URI Class Initialized
INFO - 2025-06-03 04:17:39 --> Router Class Initialized
INFO - 2025-06-03 04:17:39 --> Output Class Initialized
INFO - 2025-06-03 04:17:39 --> Security Class Initialized
DEBUG - 2025-06-03 04:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:17:39 --> Input Class Initialized
INFO - 2025-06-03 04:17:39 --> Language Class Initialized
INFO - 2025-06-03 04:17:39 --> Loader Class Initialized
INFO - 2025-06-03 04:17:39 --> Helper loaded: url_helper
INFO - 2025-06-03 04:17:39 --> Helper loaded: form_helper
INFO - 2025-06-03 04:17:39 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:17:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:17:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:17:39 --> Controller Class Initialized
INFO - 2025-06-03 04:17:39 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 04:17:39 --> Model "User_model" initialized
INFO - 2025-06-03 04:17:39 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 04:17:39 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 04:17:39 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-06-03 04:17:39 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 04:17:39 --> Final output sent to browser
DEBUG - 2025-06-03 04:17:39 --> Total execution time: 0.0771
INFO - 2025-06-03 04:19:31 --> Config Class Initialized
INFO - 2025-06-03 04:19:31 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:19:31 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:19:31 --> Utf8 Class Initialized
INFO - 2025-06-03 04:19:31 --> URI Class Initialized
INFO - 2025-06-03 04:19:31 --> Router Class Initialized
INFO - 2025-06-03 04:19:31 --> Output Class Initialized
INFO - 2025-06-03 04:19:31 --> Security Class Initialized
DEBUG - 2025-06-03 04:19:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:19:31 --> Input Class Initialized
INFO - 2025-06-03 04:19:31 --> Language Class Initialized
INFO - 2025-06-03 04:19:31 --> Loader Class Initialized
INFO - 2025-06-03 04:19:31 --> Helper loaded: url_helper
INFO - 2025-06-03 04:19:31 --> Helper loaded: form_helper
INFO - 2025-06-03 04:19:31 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:19:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:19:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:19:31 --> Controller Class Initialized
INFO - 2025-06-03 04:19:31 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 04:19:31 --> Model "User_model" initialized
INFO - 2025-06-03 04:19:31 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 04:19:31 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 04:19:31 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-06-03 04:19:31 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 04:19:31 --> Final output sent to browser
DEBUG - 2025-06-03 04:19:31 --> Total execution time: 0.0805
INFO - 2025-06-03 04:19:33 --> Config Class Initialized
INFO - 2025-06-03 04:19:33 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:19:33 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:19:33 --> Utf8 Class Initialized
INFO - 2025-06-03 04:19:33 --> URI Class Initialized
INFO - 2025-06-03 04:19:33 --> Router Class Initialized
INFO - 2025-06-03 04:19:33 --> Output Class Initialized
INFO - 2025-06-03 04:19:33 --> Security Class Initialized
DEBUG - 2025-06-03 04:19:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:19:33 --> Input Class Initialized
INFO - 2025-06-03 04:19:33 --> Language Class Initialized
INFO - 2025-06-03 04:19:33 --> Loader Class Initialized
INFO - 2025-06-03 04:19:33 --> Helper loaded: url_helper
INFO - 2025-06-03 04:19:33 --> Helper loaded: form_helper
INFO - 2025-06-03 04:19:33 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:19:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:19:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:19:33 --> Controller Class Initialized
INFO - 2025-06-03 04:19:33 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 04:19:33 --> Model "User_model" initialized
INFO - 2025-06-03 04:19:33 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 04:19:33 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 04:19:33 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/start.php
INFO - 2025-06-03 04:19:33 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 04:19:33 --> Final output sent to browser
DEBUG - 2025-06-03 04:19:33 --> Total execution time: 0.1719
INFO - 2025-06-03 04:19:36 --> Config Class Initialized
INFO - 2025-06-03 04:19:36 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:19:36 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:19:36 --> Utf8 Class Initialized
INFO - 2025-06-03 04:19:36 --> URI Class Initialized
INFO - 2025-06-03 04:19:36 --> Router Class Initialized
INFO - 2025-06-03 04:19:36 --> Output Class Initialized
INFO - 2025-06-03 04:19:36 --> Security Class Initialized
DEBUG - 2025-06-03 04:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:19:37 --> Input Class Initialized
INFO - 2025-06-03 04:19:37 --> Language Class Initialized
INFO - 2025-06-03 04:19:37 --> Loader Class Initialized
INFO - 2025-06-03 04:19:37 --> Helper loaded: url_helper
INFO - 2025-06-03 04:19:37 --> Helper loaded: form_helper
INFO - 2025-06-03 04:19:37 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:19:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:19:37 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:19:37 --> Controller Class Initialized
INFO - 2025-06-03 04:19:37 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 04:19:37 --> Model "User_model" initialized
INFO - 2025-06-03 04:19:37 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 04:19:37 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 04:19:37 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-06-03 04:19:37 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 04:19:37 --> Final output sent to browser
DEBUG - 2025-06-03 04:19:37 --> Total execution time: 0.1008
INFO - 2025-06-03 04:19:39 --> Config Class Initialized
INFO - 2025-06-03 04:19:39 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:19:39 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:19:39 --> Utf8 Class Initialized
INFO - 2025-06-03 04:19:39 --> URI Class Initialized
INFO - 2025-06-03 04:19:39 --> Router Class Initialized
INFO - 2025-06-03 04:19:39 --> Output Class Initialized
INFO - 2025-06-03 04:19:39 --> Security Class Initialized
DEBUG - 2025-06-03 04:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:19:39 --> Input Class Initialized
INFO - 2025-06-03 04:19:39 --> Language Class Initialized
INFO - 2025-06-03 04:19:39 --> Loader Class Initialized
INFO - 2025-06-03 04:19:39 --> Helper loaded: url_helper
INFO - 2025-06-03 04:19:39 --> Helper loaded: form_helper
INFO - 2025-06-03 04:19:39 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:19:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:19:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:19:39 --> Controller Class Initialized
INFO - 2025-06-03 04:19:39 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 04:19:39 --> Model "User_model" initialized
INFO - 2025-06-03 04:19:39 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 04:19:39 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 04:19:39 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/start.php
INFO - 2025-06-03 04:19:39 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 04:19:39 --> Final output sent to browser
DEBUG - 2025-06-03 04:19:39 --> Total execution time: 0.0991
INFO - 2025-06-03 04:19:51 --> Config Class Initialized
INFO - 2025-06-03 04:19:51 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:19:51 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:19:51 --> Utf8 Class Initialized
INFO - 2025-06-03 04:19:51 --> URI Class Initialized
INFO - 2025-06-03 04:19:51 --> Router Class Initialized
INFO - 2025-06-03 04:19:51 --> Output Class Initialized
INFO - 2025-06-03 04:19:51 --> Security Class Initialized
DEBUG - 2025-06-03 04:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:19:51 --> Input Class Initialized
INFO - 2025-06-03 04:19:51 --> Language Class Initialized
INFO - 2025-06-03 04:19:51 --> Loader Class Initialized
INFO - 2025-06-03 04:19:51 --> Helper loaded: url_helper
INFO - 2025-06-03 04:19:51 --> Helper loaded: form_helper
INFO - 2025-06-03 04:19:51 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:19:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:19:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:19:51 --> Controller Class Initialized
INFO - 2025-06-03 04:19:51 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 04:19:51 --> Model "User_model" initialized
INFO - 2025-06-03 04:19:51 --> Final output sent to browser
DEBUG - 2025-06-03 04:19:51 --> Total execution time: 0.0990
INFO - 2025-06-03 04:20:18 --> Config Class Initialized
INFO - 2025-06-03 04:20:18 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:20:18 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:20:18 --> Utf8 Class Initialized
INFO - 2025-06-03 04:20:18 --> URI Class Initialized
INFO - 2025-06-03 04:20:18 --> Router Class Initialized
INFO - 2025-06-03 04:20:18 --> Output Class Initialized
INFO - 2025-06-03 04:20:18 --> Security Class Initialized
DEBUG - 2025-06-03 04:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:20:18 --> Input Class Initialized
INFO - 2025-06-03 04:20:18 --> Language Class Initialized
INFO - 2025-06-03 04:20:18 --> Loader Class Initialized
INFO - 2025-06-03 04:20:18 --> Helper loaded: url_helper
INFO - 2025-06-03 04:20:18 --> Helper loaded: form_helper
INFO - 2025-06-03 04:20:18 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:20:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:20:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:20:18 --> Controller Class Initialized
INFO - 2025-06-03 04:20:18 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 04:20:18 --> Model "User_model" initialized
INFO - 2025-06-03 04:20:18 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 04:20:18 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 04:20:18 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/start.php
INFO - 2025-06-03 04:20:18 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 04:20:18 --> Final output sent to browser
DEBUG - 2025-06-03 04:20:18 --> Total execution time: 0.1232
INFO - 2025-06-03 04:20:26 --> Config Class Initialized
INFO - 2025-06-03 04:20:26 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:20:26 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:20:26 --> Utf8 Class Initialized
INFO - 2025-06-03 04:20:26 --> URI Class Initialized
INFO - 2025-06-03 04:20:26 --> Router Class Initialized
INFO - 2025-06-03 04:20:26 --> Output Class Initialized
INFO - 2025-06-03 04:20:26 --> Security Class Initialized
DEBUG - 2025-06-03 04:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:20:26 --> Input Class Initialized
INFO - 2025-06-03 04:20:26 --> Language Class Initialized
INFO - 2025-06-03 04:20:26 --> Loader Class Initialized
INFO - 2025-06-03 04:20:27 --> Helper loaded: url_helper
INFO - 2025-06-03 04:20:27 --> Helper loaded: form_helper
INFO - 2025-06-03 04:20:27 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:20:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:20:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:20:27 --> Controller Class Initialized
INFO - 2025-06-03 04:20:27 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 04:20:27 --> Model "User_model" initialized
INFO - 2025-06-03 04:20:27 --> Final output sent to browser
DEBUG - 2025-06-03 04:20:27 --> Total execution time: 0.1032
INFO - 2025-06-03 04:20:33 --> Config Class Initialized
INFO - 2025-06-03 04:20:33 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:20:33 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:20:33 --> Utf8 Class Initialized
INFO - 2025-06-03 04:20:33 --> URI Class Initialized
INFO - 2025-06-03 04:20:33 --> Router Class Initialized
INFO - 2025-06-03 04:20:33 --> Output Class Initialized
INFO - 2025-06-03 04:20:33 --> Security Class Initialized
DEBUG - 2025-06-03 04:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:20:33 --> Input Class Initialized
INFO - 2025-06-03 04:20:33 --> Language Class Initialized
INFO - 2025-06-03 04:20:33 --> Loader Class Initialized
INFO - 2025-06-03 04:20:33 --> Helper loaded: url_helper
INFO - 2025-06-03 04:20:33 --> Helper loaded: form_helper
INFO - 2025-06-03 04:20:33 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:20:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:20:33 --> Controller Class Initialized
INFO - 2025-06-03 04:20:33 --> Model "User_model" initialized
INFO - 2025-06-03 04:20:33 --> Model "Progress_model" initialized
INFO - 2025-06-03 04:20:33 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 04:20:33 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 04:20:33 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/dashboard.php
INFO - 2025-06-03 04:20:33 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 04:20:33 --> Final output sent to browser
DEBUG - 2025-06-03 04:20:33 --> Total execution time: 0.0887
INFO - 2025-06-03 04:20:39 --> Config Class Initialized
INFO - 2025-06-03 04:20:39 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:20:39 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:20:39 --> Utf8 Class Initialized
INFO - 2025-06-03 04:20:39 --> URI Class Initialized
INFO - 2025-06-03 04:20:39 --> Router Class Initialized
INFO - 2025-06-03 04:20:39 --> Output Class Initialized
INFO - 2025-06-03 04:20:39 --> Security Class Initialized
DEBUG - 2025-06-03 04:20:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:20:39 --> Input Class Initialized
INFO - 2025-06-03 04:20:39 --> Language Class Initialized
INFO - 2025-06-03 04:20:39 --> Loader Class Initialized
INFO - 2025-06-03 04:20:39 --> Helper loaded: url_helper
INFO - 2025-06-03 04:20:39 --> Helper loaded: form_helper
INFO - 2025-06-03 04:20:39 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:20:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:20:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:20:39 --> Controller Class Initialized
INFO - 2025-06-03 04:20:39 --> Model "User_model" initialized
INFO - 2025-06-03 04:20:39 --> Model "Progress_model" initialized
INFO - 2025-06-03 04:20:39 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 04:20:39 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 04:20:39 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/guide.php
INFO - 2025-06-03 04:20:39 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 04:20:39 --> Final output sent to browser
DEBUG - 2025-06-03 04:20:39 --> Total execution time: 0.0925
INFO - 2025-06-03 04:20:45 --> Config Class Initialized
INFO - 2025-06-03 04:20:45 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:20:45 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:20:45 --> Utf8 Class Initialized
INFO - 2025-06-03 04:20:45 --> URI Class Initialized
INFO - 2025-06-03 04:20:45 --> Router Class Initialized
INFO - 2025-06-03 04:20:45 --> Output Class Initialized
INFO - 2025-06-03 04:20:45 --> Security Class Initialized
DEBUG - 2025-06-03 04:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:20:45 --> Input Class Initialized
INFO - 2025-06-03 04:20:45 --> Language Class Initialized
INFO - 2025-06-03 04:20:45 --> Loader Class Initialized
INFO - 2025-06-03 04:20:45 --> Helper loaded: url_helper
INFO - 2025-06-03 04:20:45 --> Helper loaded: form_helper
INFO - 2025-06-03 04:20:45 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:20:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:20:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:20:45 --> Controller Class Initialized
INFO - 2025-06-03 04:20:45 --> Model "Progress_model" initialized
INFO - 2025-06-03 04:20:45 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 04:20:45 --> Model "User_model" initialized
INFO - 2025-06-03 04:20:45 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 04:20:45 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 04:20:45 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/progress_view.php
INFO - 2025-06-03 04:20:45 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 04:20:45 --> Final output sent to browser
DEBUG - 2025-06-03 04:20:45 --> Total execution time: 0.0937
INFO - 2025-06-03 04:20:45 --> Config Class Initialized
INFO - 2025-06-03 04:20:45 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:20:45 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:20:45 --> Utf8 Class Initialized
INFO - 2025-06-03 04:20:45 --> URI Class Initialized
INFO - 2025-06-03 04:20:45 --> Router Class Initialized
INFO - 2025-06-03 04:20:45 --> Output Class Initialized
INFO - 2025-06-03 04:20:45 --> Security Class Initialized
DEBUG - 2025-06-03 04:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:20:45 --> Input Class Initialized
INFO - 2025-06-03 04:20:45 --> Language Class Initialized
INFO - 2025-06-03 04:20:45 --> Loader Class Initialized
INFO - 2025-06-03 04:20:45 --> Helper loaded: url_helper
INFO - 2025-06-03 04:20:45 --> Helper loaded: form_helper
INFO - 2025-06-03 04:20:45 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:20:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:20:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:20:45 --> Controller Class Initialized
INFO - 2025-06-03 04:20:45 --> Model "Progress_model" initialized
INFO - 2025-06-03 04:20:45 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 04:20:45 --> Model "User_model" initialized
INFO - 2025-06-03 04:20:46 --> Final output sent to browser
DEBUG - 2025-06-03 04:20:46 --> Total execution time: 0.1694
INFO - 2025-06-03 04:20:48 --> Config Class Initialized
INFO - 2025-06-03 04:20:48 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:20:48 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:20:48 --> Utf8 Class Initialized
INFO - 2025-06-03 04:20:48 --> URI Class Initialized
INFO - 2025-06-03 04:20:48 --> Router Class Initialized
INFO - 2025-06-03 04:20:48 --> Output Class Initialized
INFO - 2025-06-03 04:20:48 --> Security Class Initialized
DEBUG - 2025-06-03 04:20:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:20:48 --> Input Class Initialized
INFO - 2025-06-03 04:20:48 --> Language Class Initialized
INFO - 2025-06-03 04:20:48 --> Loader Class Initialized
INFO - 2025-06-03 04:20:48 --> Helper loaded: url_helper
INFO - 2025-06-03 04:20:48 --> Helper loaded: form_helper
INFO - 2025-06-03 04:20:48 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:20:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:20:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:20:48 --> Controller Class Initialized
INFO - 2025-06-03 04:20:48 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 04:20:48 --> Model "User_model" initialized
INFO - 2025-06-03 04:20:48 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 04:20:48 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 04:20:48 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-06-03 04:20:48 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 04:20:48 --> Final output sent to browser
DEBUG - 2025-06-03 04:20:48 --> Total execution time: 0.0796
INFO - 2025-06-03 04:20:50 --> Config Class Initialized
INFO - 2025-06-03 04:20:50 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:20:50 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:20:50 --> Utf8 Class Initialized
INFO - 2025-06-03 04:20:50 --> URI Class Initialized
INFO - 2025-06-03 04:20:50 --> Router Class Initialized
INFO - 2025-06-03 04:20:50 --> Output Class Initialized
INFO - 2025-06-03 04:20:50 --> Security Class Initialized
DEBUG - 2025-06-03 04:20:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:20:50 --> Input Class Initialized
INFO - 2025-06-03 04:20:50 --> Language Class Initialized
INFO - 2025-06-03 04:20:50 --> Loader Class Initialized
INFO - 2025-06-03 04:20:50 --> Helper loaded: url_helper
INFO - 2025-06-03 04:20:50 --> Helper loaded: form_helper
INFO - 2025-06-03 04:20:50 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:20:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:20:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:20:50 --> Controller Class Initialized
INFO - 2025-06-03 04:20:50 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 04:20:50 --> Model "User_model" initialized
INFO - 2025-06-03 04:20:50 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 04:20:50 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 04:20:50 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/level.php
INFO - 2025-06-03 04:20:50 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 04:20:50 --> Final output sent to browser
DEBUG - 2025-06-03 04:20:50 --> Total execution time: 0.0834
INFO - 2025-06-03 04:21:08 --> Config Class Initialized
INFO - 2025-06-03 04:21:08 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:21:08 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:21:08 --> Utf8 Class Initialized
INFO - 2025-06-03 04:21:08 --> URI Class Initialized
INFO - 2025-06-03 04:21:08 --> Router Class Initialized
INFO - 2025-06-03 04:21:08 --> Output Class Initialized
INFO - 2025-06-03 04:21:08 --> Security Class Initialized
DEBUG - 2025-06-03 04:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:21:08 --> Input Class Initialized
INFO - 2025-06-03 04:21:08 --> Language Class Initialized
INFO - 2025-06-03 04:21:08 --> Loader Class Initialized
INFO - 2025-06-03 04:21:08 --> Helper loaded: url_helper
INFO - 2025-06-03 04:21:08 --> Helper loaded: form_helper
INFO - 2025-06-03 04:21:08 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:21:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:21:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:21:09 --> Controller Class Initialized
INFO - 2025-06-03 04:21:09 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 04:21:09 --> Model "User_model" initialized
INFO - 2025-06-03 04:21:09 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 04:21:09 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 04:21:09 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/level.php
INFO - 2025-06-03 04:21:09 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 04:21:09 --> Final output sent to browser
DEBUG - 2025-06-03 04:21:09 --> Total execution time: 0.0809
INFO - 2025-06-03 04:22:01 --> Config Class Initialized
INFO - 2025-06-03 04:22:01 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:22:01 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:22:01 --> Utf8 Class Initialized
INFO - 2025-06-03 04:22:01 --> URI Class Initialized
INFO - 2025-06-03 04:22:01 --> Router Class Initialized
INFO - 2025-06-03 04:22:01 --> Output Class Initialized
INFO - 2025-06-03 04:22:01 --> Security Class Initialized
DEBUG - 2025-06-03 04:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:22:01 --> Input Class Initialized
INFO - 2025-06-03 04:22:01 --> Language Class Initialized
INFO - 2025-06-03 04:22:01 --> Loader Class Initialized
INFO - 2025-06-03 04:22:01 --> Helper loaded: url_helper
INFO - 2025-06-03 04:22:01 --> Helper loaded: form_helper
INFO - 2025-06-03 04:22:01 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:22:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:22:01 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:22:01 --> Controller Class Initialized
INFO - 2025-06-03 04:22:01 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 04:22:01 --> Model "User_model" initialized
INFO - 2025-06-03 04:22:01 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 04:22:01 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 04:22:01 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-06-03 04:22:01 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 04:22:01 --> Final output sent to browser
DEBUG - 2025-06-03 04:22:01 --> Total execution time: 0.1445
INFO - 2025-06-03 04:22:04 --> Config Class Initialized
INFO - 2025-06-03 04:22:04 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:22:04 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:22:04 --> Utf8 Class Initialized
INFO - 2025-06-03 04:22:04 --> URI Class Initialized
INFO - 2025-06-03 04:22:04 --> Router Class Initialized
INFO - 2025-06-03 04:22:04 --> Output Class Initialized
INFO - 2025-06-03 04:22:04 --> Security Class Initialized
DEBUG - 2025-06-03 04:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:22:04 --> Input Class Initialized
INFO - 2025-06-03 04:22:04 --> Language Class Initialized
INFO - 2025-06-03 04:22:04 --> Loader Class Initialized
INFO - 2025-06-03 04:22:04 --> Helper loaded: url_helper
INFO - 2025-06-03 04:22:04 --> Helper loaded: form_helper
INFO - 2025-06-03 04:22:04 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:22:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:22:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:22:04 --> Controller Class Initialized
INFO - 2025-06-03 04:22:04 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 04:22:04 --> Model "User_model" initialized
INFO - 2025-06-03 04:22:04 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 04:22:04 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 04:22:04 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/start.php
INFO - 2025-06-03 04:22:04 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 04:22:04 --> Final output sent to browser
DEBUG - 2025-06-03 04:22:04 --> Total execution time: 0.0864
INFO - 2025-06-03 04:24:16 --> Config Class Initialized
INFO - 2025-06-03 04:24:16 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:24:16 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:24:16 --> Utf8 Class Initialized
INFO - 2025-06-03 04:24:16 --> URI Class Initialized
INFO - 2025-06-03 04:24:16 --> Router Class Initialized
INFO - 2025-06-03 04:24:16 --> Output Class Initialized
INFO - 2025-06-03 04:24:16 --> Security Class Initialized
DEBUG - 2025-06-03 04:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:24:16 --> Input Class Initialized
INFO - 2025-06-03 04:24:16 --> Language Class Initialized
INFO - 2025-06-03 04:24:16 --> Loader Class Initialized
INFO - 2025-06-03 04:24:16 --> Helper loaded: url_helper
INFO - 2025-06-03 04:24:16 --> Helper loaded: form_helper
INFO - 2025-06-03 04:24:16 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:24:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:24:16 --> Controller Class Initialized
INFO - 2025-06-03 04:24:16 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 04:24:16 --> Model "User_model" initialized
INFO - 2025-06-03 04:24:16 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 04:24:16 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 04:24:16 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/start.php
INFO - 2025-06-03 04:24:16 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 04:24:16 --> Final output sent to browser
DEBUG - 2025-06-03 04:24:16 --> Total execution time: 0.1079
INFO - 2025-06-03 04:24:22 --> Config Class Initialized
INFO - 2025-06-03 04:24:22 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:24:22 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:24:22 --> Utf8 Class Initialized
INFO - 2025-06-03 04:24:22 --> URI Class Initialized
INFO - 2025-06-03 04:24:22 --> Router Class Initialized
INFO - 2025-06-03 04:24:22 --> Output Class Initialized
INFO - 2025-06-03 04:24:22 --> Security Class Initialized
DEBUG - 2025-06-03 04:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:24:22 --> Input Class Initialized
INFO - 2025-06-03 04:24:22 --> Language Class Initialized
INFO - 2025-06-03 04:24:22 --> Loader Class Initialized
INFO - 2025-06-03 04:24:22 --> Helper loaded: url_helper
INFO - 2025-06-03 04:24:22 --> Helper loaded: form_helper
INFO - 2025-06-03 04:24:22 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:24:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:24:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:24:23 --> Controller Class Initialized
INFO - 2025-06-03 04:24:23 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 04:24:23 --> Model "User_model" initialized
INFO - 2025-06-03 04:24:23 --> Final output sent to browser
DEBUG - 2025-06-03 04:24:23 --> Total execution time: 0.1014
INFO - 2025-06-03 04:24:27 --> Config Class Initialized
INFO - 2025-06-03 04:24:27 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:24:27 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:24:27 --> Utf8 Class Initialized
INFO - 2025-06-03 04:24:27 --> URI Class Initialized
INFO - 2025-06-03 04:24:27 --> Router Class Initialized
INFO - 2025-06-03 04:24:27 --> Output Class Initialized
INFO - 2025-06-03 04:24:27 --> Security Class Initialized
DEBUG - 2025-06-03 04:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:24:27 --> Input Class Initialized
INFO - 2025-06-03 04:24:27 --> Language Class Initialized
INFO - 2025-06-03 04:24:27 --> Loader Class Initialized
INFO - 2025-06-03 04:24:27 --> Helper loaded: url_helper
INFO - 2025-06-03 04:24:27 --> Helper loaded: form_helper
INFO - 2025-06-03 04:24:27 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:24:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:24:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:24:27 --> Controller Class Initialized
INFO - 2025-06-03 04:24:27 --> Model "User_model" initialized
INFO - 2025-06-03 04:24:27 --> Model "Progress_model" initialized
INFO - 2025-06-03 04:24:27 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 04:24:27 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 04:24:27 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/dashboard.php
INFO - 2025-06-03 04:24:27 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 04:24:27 --> Final output sent to browser
DEBUG - 2025-06-03 04:24:27 --> Total execution time: 0.0855
INFO - 2025-06-03 04:24:32 --> Config Class Initialized
INFO - 2025-06-03 04:24:32 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:24:32 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:24:32 --> Utf8 Class Initialized
INFO - 2025-06-03 04:24:32 --> URI Class Initialized
INFO - 2025-06-03 04:24:32 --> Router Class Initialized
INFO - 2025-06-03 04:24:32 --> Output Class Initialized
INFO - 2025-06-03 04:24:32 --> Security Class Initialized
DEBUG - 2025-06-03 04:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:24:32 --> Input Class Initialized
INFO - 2025-06-03 04:24:32 --> Language Class Initialized
INFO - 2025-06-03 04:24:32 --> Loader Class Initialized
INFO - 2025-06-03 04:24:32 --> Helper loaded: url_helper
INFO - 2025-06-03 04:24:32 --> Helper loaded: form_helper
INFO - 2025-06-03 04:24:32 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:24:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:24:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:24:32 --> Controller Class Initialized
INFO - 2025-06-03 04:24:32 --> Model "Progress_model" initialized
INFO - 2025-06-03 04:24:32 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 04:24:32 --> Model "User_model" initialized
INFO - 2025-06-03 04:24:32 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 04:24:32 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 04:24:32 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/progress_view.php
INFO - 2025-06-03 04:24:32 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 04:24:32 --> Final output sent to browser
DEBUG - 2025-06-03 04:24:32 --> Total execution time: 0.0872
INFO - 2025-06-03 04:24:32 --> Config Class Initialized
INFO - 2025-06-03 04:24:32 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:24:32 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:24:32 --> Utf8 Class Initialized
INFO - 2025-06-03 04:24:32 --> URI Class Initialized
INFO - 2025-06-03 04:24:32 --> Router Class Initialized
INFO - 2025-06-03 04:24:32 --> Output Class Initialized
INFO - 2025-06-03 04:24:32 --> Security Class Initialized
DEBUG - 2025-06-03 04:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:24:32 --> Input Class Initialized
INFO - 2025-06-03 04:24:32 --> Language Class Initialized
INFO - 2025-06-03 04:24:33 --> Loader Class Initialized
INFO - 2025-06-03 04:24:33 --> Helper loaded: url_helper
INFO - 2025-06-03 04:24:33 --> Helper loaded: form_helper
INFO - 2025-06-03 04:24:33 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:24:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:24:33 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:24:33 --> Controller Class Initialized
INFO - 2025-06-03 04:24:33 --> Model "Progress_model" initialized
INFO - 2025-06-03 04:24:33 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 04:24:33 --> Model "User_model" initialized
INFO - 2025-06-03 04:24:33 --> Final output sent to browser
DEBUG - 2025-06-03 04:24:33 --> Total execution time: 0.0764
INFO - 2025-06-03 04:24:35 --> Config Class Initialized
INFO - 2025-06-03 04:24:35 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:24:35 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:24:35 --> Utf8 Class Initialized
INFO - 2025-06-03 04:24:35 --> URI Class Initialized
INFO - 2025-06-03 04:24:35 --> Router Class Initialized
INFO - 2025-06-03 04:24:35 --> Output Class Initialized
INFO - 2025-06-03 04:24:35 --> Security Class Initialized
DEBUG - 2025-06-03 04:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:24:35 --> Input Class Initialized
INFO - 2025-06-03 04:24:35 --> Language Class Initialized
INFO - 2025-06-03 04:24:35 --> Loader Class Initialized
INFO - 2025-06-03 04:24:35 --> Helper loaded: url_helper
INFO - 2025-06-03 04:24:35 --> Helper loaded: form_helper
INFO - 2025-06-03 04:24:35 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:24:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:24:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:24:35 --> Controller Class Initialized
INFO - 2025-06-03 04:24:35 --> Model "User_model" initialized
INFO - 2025-06-03 04:24:35 --> Model "Progress_model" initialized
INFO - 2025-06-03 04:24:35 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 04:24:35 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 04:24:35 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/dashboard.php
INFO - 2025-06-03 04:24:35 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 04:24:35 --> Final output sent to browser
DEBUG - 2025-06-03 04:24:35 --> Total execution time: 0.0896
INFO - 2025-06-03 04:26:27 --> Config Class Initialized
INFO - 2025-06-03 04:26:27 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:26:27 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:26:27 --> Utf8 Class Initialized
INFO - 2025-06-03 04:26:27 --> URI Class Initialized
INFO - 2025-06-03 04:26:27 --> Router Class Initialized
INFO - 2025-06-03 04:26:27 --> Output Class Initialized
INFO - 2025-06-03 04:26:27 --> Security Class Initialized
DEBUG - 2025-06-03 04:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:26:27 --> Input Class Initialized
INFO - 2025-06-03 04:26:27 --> Language Class Initialized
INFO - 2025-06-03 04:26:27 --> Loader Class Initialized
INFO - 2025-06-03 04:26:27 --> Helper loaded: url_helper
INFO - 2025-06-03 04:26:27 --> Helper loaded: form_helper
INFO - 2025-06-03 04:26:27 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:26:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:26:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:26:27 --> Controller Class Initialized
INFO - 2025-06-03 04:26:27 --> Model "User_model" initialized
INFO - 2025-06-03 04:26:27 --> Model "Progress_model" initialized
INFO - 2025-06-03 04:26:27 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 04:26:27 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 04:26:27 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/guide.php
INFO - 2025-06-03 04:26:27 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 04:26:27 --> Final output sent to browser
DEBUG - 2025-06-03 04:26:27 --> Total execution time: 0.0865
INFO - 2025-06-03 04:30:13 --> Config Class Initialized
INFO - 2025-06-03 04:30:13 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:30:13 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:30:13 --> Utf8 Class Initialized
INFO - 2025-06-03 04:30:13 --> URI Class Initialized
INFO - 2025-06-03 04:30:13 --> Router Class Initialized
INFO - 2025-06-03 04:30:13 --> Output Class Initialized
INFO - 2025-06-03 04:30:13 --> Security Class Initialized
DEBUG - 2025-06-03 04:30:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:30:13 --> Input Class Initialized
INFO - 2025-06-03 04:30:13 --> Language Class Initialized
INFO - 2025-06-03 04:30:13 --> Loader Class Initialized
INFO - 2025-06-03 04:30:13 --> Helper loaded: url_helper
INFO - 2025-06-03 04:30:13 --> Helper loaded: form_helper
INFO - 2025-06-03 04:30:13 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:30:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:30:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:30:13 --> Controller Class Initialized
INFO - 2025-06-03 04:30:13 --> Model "User_model" initialized
INFO - 2025-06-03 04:30:13 --> Form Validation Class Initialized
INFO - 2025-06-03 04:30:13 --> Config Class Initialized
INFO - 2025-06-03 04:30:13 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:30:13 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:30:13 --> Utf8 Class Initialized
INFO - 2025-06-03 04:30:13 --> URI Class Initialized
INFO - 2025-06-03 04:30:13 --> Router Class Initialized
INFO - 2025-06-03 04:30:13 --> Output Class Initialized
INFO - 2025-06-03 04:30:13 --> Security Class Initialized
DEBUG - 2025-06-03 04:30:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:30:13 --> Input Class Initialized
INFO - 2025-06-03 04:30:13 --> Language Class Initialized
INFO - 2025-06-03 04:30:13 --> Loader Class Initialized
INFO - 2025-06-03 04:30:13 --> Helper loaded: url_helper
INFO - 2025-06-03 04:30:13 --> Helper loaded: form_helper
INFO - 2025-06-03 04:30:13 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:30:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:30:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:30:13 --> Controller Class Initialized
INFO - 2025-06-03 04:30:13 --> Model "User_model" initialized
INFO - 2025-06-03 04:30:13 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-06-03 04:30:13 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/home.php
INFO - 2025-06-03 04:30:13 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-06-03 04:30:13 --> Final output sent to browser
DEBUG - 2025-06-03 04:30:13 --> Total execution time: 0.0830
INFO - 2025-06-03 04:30:17 --> Config Class Initialized
INFO - 2025-06-03 04:30:17 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:30:17 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:30:17 --> Utf8 Class Initialized
INFO - 2025-06-03 04:30:17 --> URI Class Initialized
INFO - 2025-06-03 04:30:17 --> Router Class Initialized
INFO - 2025-06-03 04:30:17 --> Output Class Initialized
INFO - 2025-06-03 04:30:17 --> Security Class Initialized
DEBUG - 2025-06-03 04:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:30:17 --> Input Class Initialized
INFO - 2025-06-03 04:30:17 --> Language Class Initialized
INFO - 2025-06-03 04:30:17 --> Loader Class Initialized
INFO - 2025-06-03 04:30:17 --> Helper loaded: url_helper
INFO - 2025-06-03 04:30:17 --> Helper loaded: form_helper
INFO - 2025-06-03 04:30:17 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:30:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:30:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:30:17 --> Controller Class Initialized
INFO - 2025-06-03 04:30:17 --> Model "User_model" initialized
INFO - 2025-06-03 04:30:17 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-06-03 04:30:17 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/artikel.php
INFO - 2025-06-03 04:30:17 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-06-03 04:30:17 --> Final output sent to browser
DEBUG - 2025-06-03 04:30:17 --> Total execution time: 0.0857
INFO - 2025-06-03 04:30:19 --> Config Class Initialized
INFO - 2025-06-03 04:30:19 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:30:19 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:30:19 --> Utf8 Class Initialized
INFO - 2025-06-03 04:30:19 --> URI Class Initialized
INFO - 2025-06-03 04:30:19 --> Router Class Initialized
INFO - 2025-06-03 04:30:19 --> Output Class Initialized
INFO - 2025-06-03 04:30:19 --> Security Class Initialized
DEBUG - 2025-06-03 04:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:30:19 --> Input Class Initialized
INFO - 2025-06-03 04:30:19 --> Language Class Initialized
INFO - 2025-06-03 04:30:19 --> Loader Class Initialized
INFO - 2025-06-03 04:30:19 --> Helper loaded: url_helper
INFO - 2025-06-03 04:30:19 --> Helper loaded: form_helper
INFO - 2025-06-03 04:30:19 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:30:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:30:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:30:19 --> Controller Class Initialized
INFO - 2025-06-03 04:30:19 --> Model "User_model" initialized
INFO - 2025-06-03 04:30:19 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-06-03 04:30:19 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/home.php
INFO - 2025-06-03 04:30:19 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-06-03 04:30:19 --> Final output sent to browser
DEBUG - 2025-06-03 04:30:19 --> Total execution time: 0.0793
INFO - 2025-06-03 04:31:06 --> Config Class Initialized
INFO - 2025-06-03 04:31:06 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:31:06 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:31:06 --> Utf8 Class Initialized
INFO - 2025-06-03 04:31:06 --> URI Class Initialized
INFO - 2025-06-03 04:31:06 --> Router Class Initialized
INFO - 2025-06-03 04:31:06 --> Output Class Initialized
INFO - 2025-06-03 04:31:06 --> Security Class Initialized
DEBUG - 2025-06-03 04:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:31:06 --> Input Class Initialized
INFO - 2025-06-03 04:31:06 --> Language Class Initialized
INFO - 2025-06-03 04:31:06 --> Loader Class Initialized
INFO - 2025-06-03 04:31:06 --> Helper loaded: url_helper
INFO - 2025-06-03 04:31:06 --> Helper loaded: form_helper
INFO - 2025-06-03 04:31:06 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:31:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:31:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:31:06 --> Controller Class Initialized
INFO - 2025-06-03 04:31:06 --> Model "User_model" initialized
INFO - 2025-06-03 04:31:06 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-06-03 04:31:06 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/home.php
INFO - 2025-06-03 04:31:06 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-06-03 04:31:06 --> Final output sent to browser
DEBUG - 2025-06-03 04:31:06 --> Total execution time: 0.2415
INFO - 2025-06-03 04:31:15 --> Config Class Initialized
INFO - 2025-06-03 04:31:15 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:31:15 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:31:15 --> Utf8 Class Initialized
INFO - 2025-06-03 04:31:15 --> URI Class Initialized
INFO - 2025-06-03 04:31:15 --> Router Class Initialized
INFO - 2025-06-03 04:31:15 --> Output Class Initialized
INFO - 2025-06-03 04:31:15 --> Security Class Initialized
DEBUG - 2025-06-03 04:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:31:15 --> Input Class Initialized
INFO - 2025-06-03 04:31:15 --> Language Class Initialized
INFO - 2025-06-03 04:31:15 --> Loader Class Initialized
INFO - 2025-06-03 04:31:15 --> Helper loaded: url_helper
INFO - 2025-06-03 04:31:15 --> Helper loaded: form_helper
INFO - 2025-06-03 04:31:16 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:31:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:31:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:31:16 --> Controller Class Initialized
INFO - 2025-06-03 04:31:16 --> Model "User_model" initialized
INFO - 2025-06-03 04:31:16 --> Form Validation Class Initialized
INFO - 2025-06-03 04:31:16 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\auth/login.php
INFO - 2025-06-03 04:31:16 --> Final output sent to browser
DEBUG - 2025-06-03 04:31:16 --> Total execution time: 0.0880
INFO - 2025-06-03 04:31:19 --> Config Class Initialized
INFO - 2025-06-03 04:31:19 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:31:19 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:31:19 --> Utf8 Class Initialized
INFO - 2025-06-03 04:31:19 --> URI Class Initialized
INFO - 2025-06-03 04:31:19 --> Router Class Initialized
INFO - 2025-06-03 04:31:19 --> Output Class Initialized
INFO - 2025-06-03 04:31:19 --> Security Class Initialized
DEBUG - 2025-06-03 04:31:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:31:19 --> Input Class Initialized
INFO - 2025-06-03 04:31:19 --> Language Class Initialized
INFO - 2025-06-03 04:31:19 --> Loader Class Initialized
INFO - 2025-06-03 04:31:19 --> Helper loaded: url_helper
INFO - 2025-06-03 04:31:19 --> Helper loaded: form_helper
INFO - 2025-06-03 04:31:19 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:31:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:31:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:31:19 --> Controller Class Initialized
INFO - 2025-06-03 04:31:19 --> Model "User_model" initialized
INFO - 2025-06-03 04:31:19 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-06-03 04:31:19 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/artikel.php
INFO - 2025-06-03 04:31:19 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-06-03 04:31:19 --> Final output sent to browser
DEBUG - 2025-06-03 04:31:19 --> Total execution time: 0.0970
INFO - 2025-06-03 04:31:21 --> Config Class Initialized
INFO - 2025-06-03 04:31:21 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:31:21 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:31:21 --> Utf8 Class Initialized
INFO - 2025-06-03 04:31:21 --> URI Class Initialized
INFO - 2025-06-03 04:31:21 --> Router Class Initialized
INFO - 2025-06-03 04:31:21 --> Output Class Initialized
INFO - 2025-06-03 04:31:21 --> Security Class Initialized
DEBUG - 2025-06-03 04:31:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:31:21 --> Input Class Initialized
INFO - 2025-06-03 04:31:21 --> Language Class Initialized
INFO - 2025-06-03 04:31:21 --> Loader Class Initialized
INFO - 2025-06-03 04:31:21 --> Helper loaded: url_helper
INFO - 2025-06-03 04:31:21 --> Helper loaded: form_helper
INFO - 2025-06-03 04:31:21 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:31:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:31:21 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:31:21 --> Controller Class Initialized
INFO - 2025-06-03 04:31:21 --> Model "User_model" initialized
INFO - 2025-06-03 04:31:21 --> Form Validation Class Initialized
INFO - 2025-06-03 04:31:21 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\auth/login.php
INFO - 2025-06-03 04:31:21 --> Final output sent to browser
DEBUG - 2025-06-03 04:31:21 --> Total execution time: 0.0814
INFO - 2025-06-03 04:31:51 --> Config Class Initialized
INFO - 2025-06-03 04:31:51 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:31:51 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:31:51 --> Utf8 Class Initialized
INFO - 2025-06-03 04:31:51 --> URI Class Initialized
INFO - 2025-06-03 04:31:51 --> Router Class Initialized
INFO - 2025-06-03 04:31:51 --> Output Class Initialized
INFO - 2025-06-03 04:31:51 --> Security Class Initialized
DEBUG - 2025-06-03 04:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:31:51 --> Input Class Initialized
INFO - 2025-06-03 04:31:51 --> Language Class Initialized
INFO - 2025-06-03 04:31:51 --> Loader Class Initialized
INFO - 2025-06-03 04:31:51 --> Helper loaded: url_helper
INFO - 2025-06-03 04:31:51 --> Helper loaded: form_helper
INFO - 2025-06-03 04:31:51 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:31:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:31:51 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:31:51 --> Controller Class Initialized
INFO - 2025-06-03 04:31:51 --> Model "User_model" initialized
INFO - 2025-06-03 04:31:51 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-06-03 04:31:51 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/artikel.php
INFO - 2025-06-03 04:31:51 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-06-03 04:31:51 --> Final output sent to browser
DEBUG - 2025-06-03 04:31:51 --> Total execution time: 0.1220
INFO - 2025-06-03 04:31:54 --> Config Class Initialized
INFO - 2025-06-03 04:31:54 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:31:54 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:31:54 --> Utf8 Class Initialized
INFO - 2025-06-03 04:31:54 --> URI Class Initialized
INFO - 2025-06-03 04:31:54 --> Router Class Initialized
INFO - 2025-06-03 04:31:54 --> Output Class Initialized
INFO - 2025-06-03 04:31:54 --> Security Class Initialized
DEBUG - 2025-06-03 04:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:31:54 --> Input Class Initialized
INFO - 2025-06-03 04:31:54 --> Language Class Initialized
INFO - 2025-06-03 04:31:54 --> Loader Class Initialized
INFO - 2025-06-03 04:31:54 --> Helper loaded: url_helper
INFO - 2025-06-03 04:31:54 --> Helper loaded: form_helper
INFO - 2025-06-03 04:31:54 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:31:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:31:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:31:54 --> Controller Class Initialized
INFO - 2025-06-03 04:31:54 --> Model "User_model" initialized
INFO - 2025-06-03 04:31:54 --> Form Validation Class Initialized
INFO - 2025-06-03 04:31:54 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\auth/login.php
INFO - 2025-06-03 04:31:54 --> Final output sent to browser
DEBUG - 2025-06-03 04:31:54 --> Total execution time: 0.0804
INFO - 2025-06-03 04:31:58 --> Config Class Initialized
INFO - 2025-06-03 04:31:58 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:31:58 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:31:58 --> Utf8 Class Initialized
INFO - 2025-06-03 04:31:58 --> URI Class Initialized
INFO - 2025-06-03 04:31:58 --> Router Class Initialized
INFO - 2025-06-03 04:31:58 --> Output Class Initialized
INFO - 2025-06-03 04:31:58 --> Security Class Initialized
DEBUG - 2025-06-03 04:31:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:31:58 --> Input Class Initialized
INFO - 2025-06-03 04:31:58 --> Language Class Initialized
INFO - 2025-06-03 04:31:58 --> Loader Class Initialized
INFO - 2025-06-03 04:31:58 --> Helper loaded: url_helper
INFO - 2025-06-03 04:31:58 --> Helper loaded: form_helper
INFO - 2025-06-03 04:31:58 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:31:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:31:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:31:58 --> Controller Class Initialized
INFO - 2025-06-03 04:31:58 --> Model "User_model" initialized
INFO - 2025-06-03 04:31:58 --> Form Validation Class Initialized
INFO - 2025-06-03 04:31:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-06-03 04:31:58 --> Config Class Initialized
INFO - 2025-06-03 04:31:58 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:31:58 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:31:58 --> Utf8 Class Initialized
INFO - 2025-06-03 04:31:58 --> URI Class Initialized
INFO - 2025-06-03 04:31:58 --> Router Class Initialized
INFO - 2025-06-03 04:31:58 --> Output Class Initialized
INFO - 2025-06-03 04:31:58 --> Security Class Initialized
DEBUG - 2025-06-03 04:31:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:31:58 --> Input Class Initialized
INFO - 2025-06-03 04:31:58 --> Language Class Initialized
INFO - 2025-06-03 04:31:58 --> Loader Class Initialized
INFO - 2025-06-03 04:31:58 --> Helper loaded: url_helper
INFO - 2025-06-03 04:31:58 --> Helper loaded: form_helper
INFO - 2025-06-03 04:31:58 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:31:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:31:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:31:58 --> Controller Class Initialized
INFO - 2025-06-03 04:31:58 --> Model "User_model" initialized
INFO - 2025-06-03 04:31:58 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-06-03 04:31:58 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/home.php
INFO - 2025-06-03 04:31:58 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-06-03 04:31:58 --> Final output sent to browser
DEBUG - 2025-06-03 04:31:58 --> Total execution time: 0.0762
INFO - 2025-06-03 04:32:02 --> Config Class Initialized
INFO - 2025-06-03 04:32:02 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:32:02 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:32:02 --> Utf8 Class Initialized
INFO - 2025-06-03 04:32:02 --> URI Class Initialized
INFO - 2025-06-03 04:32:02 --> Router Class Initialized
INFO - 2025-06-03 04:32:02 --> Output Class Initialized
INFO - 2025-06-03 04:32:02 --> Security Class Initialized
DEBUG - 2025-06-03 04:32:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:32:02 --> Input Class Initialized
INFO - 2025-06-03 04:32:02 --> Language Class Initialized
INFO - 2025-06-03 04:32:02 --> Loader Class Initialized
INFO - 2025-06-03 04:32:02 --> Helper loaded: url_helper
INFO - 2025-06-03 04:32:02 --> Helper loaded: form_helper
INFO - 2025-06-03 04:32:02 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:32:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:32:02 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:32:02 --> Controller Class Initialized
INFO - 2025-06-03 04:32:02 --> Model "User_model" initialized
INFO - 2025-06-03 04:32:02 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-06-03 04:32:02 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/artikel.php
INFO - 2025-06-03 04:32:02 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-06-03 04:32:02 --> Final output sent to browser
DEBUG - 2025-06-03 04:32:02 --> Total execution time: 0.1071
INFO - 2025-06-03 04:32:03 --> Config Class Initialized
INFO - 2025-06-03 04:32:03 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:32:03 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:32:03 --> Utf8 Class Initialized
INFO - 2025-06-03 04:32:03 --> URI Class Initialized
INFO - 2025-06-03 04:32:03 --> Router Class Initialized
INFO - 2025-06-03 04:32:03 --> Output Class Initialized
INFO - 2025-06-03 04:32:03 --> Security Class Initialized
DEBUG - 2025-06-03 04:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:32:03 --> Input Class Initialized
INFO - 2025-06-03 04:32:03 --> Language Class Initialized
INFO - 2025-06-03 04:32:03 --> Loader Class Initialized
INFO - 2025-06-03 04:32:03 --> Helper loaded: url_helper
INFO - 2025-06-03 04:32:03 --> Helper loaded: form_helper
INFO - 2025-06-03 04:32:03 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:32:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:32:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:32:03 --> Controller Class Initialized
INFO - 2025-06-03 04:32:03 --> Model "User_model" initialized
INFO - 2025-06-03 04:32:03 --> Model "Progress_model" initialized
INFO - 2025-06-03 04:32:03 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 04:32:03 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 04:32:03 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/dashboard.php
INFO - 2025-06-03 04:32:03 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 04:32:03 --> Final output sent to browser
DEBUG - 2025-06-03 04:32:03 --> Total execution time: 0.1467
INFO - 2025-06-03 04:32:12 --> Config Class Initialized
INFO - 2025-06-03 04:32:12 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:32:12 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:32:12 --> Utf8 Class Initialized
INFO - 2025-06-03 04:32:12 --> URI Class Initialized
INFO - 2025-06-03 04:32:12 --> Router Class Initialized
INFO - 2025-06-03 04:32:12 --> Output Class Initialized
INFO - 2025-06-03 04:32:12 --> Security Class Initialized
DEBUG - 2025-06-03 04:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:32:12 --> Input Class Initialized
INFO - 2025-06-03 04:32:12 --> Language Class Initialized
INFO - 2025-06-03 04:32:12 --> Loader Class Initialized
INFO - 2025-06-03 04:32:12 --> Helper loaded: url_helper
INFO - 2025-06-03 04:32:12 --> Helper loaded: form_helper
INFO - 2025-06-03 04:32:12 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:32:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:32:12 --> Controller Class Initialized
INFO - 2025-06-03 04:32:12 --> Model "User_model" initialized
INFO - 2025-06-03 04:32:12 --> Form Validation Class Initialized
INFO - 2025-06-03 04:32:12 --> Config Class Initialized
INFO - 2025-06-03 04:32:12 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:32:12 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:32:12 --> Utf8 Class Initialized
INFO - 2025-06-03 04:32:12 --> URI Class Initialized
INFO - 2025-06-03 04:32:12 --> Router Class Initialized
INFO - 2025-06-03 04:32:12 --> Output Class Initialized
INFO - 2025-06-03 04:32:12 --> Security Class Initialized
DEBUG - 2025-06-03 04:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:32:12 --> Input Class Initialized
INFO - 2025-06-03 04:32:12 --> Language Class Initialized
INFO - 2025-06-03 04:32:12 --> Loader Class Initialized
INFO - 2025-06-03 04:32:12 --> Helper loaded: url_helper
INFO - 2025-06-03 04:32:13 --> Helper loaded: form_helper
INFO - 2025-06-03 04:32:13 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:32:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:32:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:32:13 --> Controller Class Initialized
INFO - 2025-06-03 04:32:13 --> Model "User_model" initialized
INFO - 2025-06-03 04:32:13 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-06-03 04:32:13 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/home.php
INFO - 2025-06-03 04:32:13 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-06-03 04:32:13 --> Final output sent to browser
DEBUG - 2025-06-03 04:32:13 --> Total execution time: 0.0749
INFO - 2025-06-03 04:32:15 --> Config Class Initialized
INFO - 2025-06-03 04:32:15 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:32:15 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:32:15 --> Utf8 Class Initialized
INFO - 2025-06-03 04:32:15 --> URI Class Initialized
INFO - 2025-06-03 04:32:15 --> Router Class Initialized
INFO - 2025-06-03 04:32:15 --> Output Class Initialized
INFO - 2025-06-03 04:32:15 --> Security Class Initialized
DEBUG - 2025-06-03 04:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:32:15 --> Input Class Initialized
INFO - 2025-06-03 04:32:15 --> Language Class Initialized
INFO - 2025-06-03 04:32:15 --> Loader Class Initialized
INFO - 2025-06-03 04:32:15 --> Helper loaded: url_helper
INFO - 2025-06-03 04:32:15 --> Helper loaded: form_helper
INFO - 2025-06-03 04:32:15 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:32:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:32:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:32:15 --> Controller Class Initialized
INFO - 2025-06-03 04:32:15 --> Model "User_model" initialized
INFO - 2025-06-03 04:32:15 --> Form Validation Class Initialized
INFO - 2025-06-03 04:32:15 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\auth/login.php
INFO - 2025-06-03 04:32:15 --> Final output sent to browser
DEBUG - 2025-06-03 04:32:15 --> Total execution time: 0.0947
INFO - 2025-06-03 04:32:20 --> Config Class Initialized
INFO - 2025-06-03 04:32:20 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:32:20 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:32:20 --> Utf8 Class Initialized
INFO - 2025-06-03 04:32:20 --> URI Class Initialized
INFO - 2025-06-03 04:32:20 --> Router Class Initialized
INFO - 2025-06-03 04:32:20 --> Output Class Initialized
INFO - 2025-06-03 04:32:20 --> Security Class Initialized
DEBUG - 2025-06-03 04:32:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:32:20 --> Input Class Initialized
INFO - 2025-06-03 04:32:20 --> Language Class Initialized
INFO - 2025-06-03 04:32:20 --> Loader Class Initialized
INFO - 2025-06-03 04:32:20 --> Helper loaded: url_helper
INFO - 2025-06-03 04:32:20 --> Helper loaded: form_helper
INFO - 2025-06-03 04:32:20 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:32:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:32:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:32:20 --> Controller Class Initialized
INFO - 2025-06-03 04:32:20 --> Model "User_model" initialized
INFO - 2025-06-03 04:32:20 --> Form Validation Class Initialized
INFO - 2025-06-03 04:32:20 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-06-03 04:32:20 --> Config Class Initialized
INFO - 2025-06-03 04:32:20 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:32:20 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:32:20 --> Utf8 Class Initialized
INFO - 2025-06-03 04:32:20 --> URI Class Initialized
INFO - 2025-06-03 04:32:20 --> Router Class Initialized
INFO - 2025-06-03 04:32:20 --> Output Class Initialized
INFO - 2025-06-03 04:32:20 --> Security Class Initialized
DEBUG - 2025-06-03 04:32:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:32:20 --> Input Class Initialized
INFO - 2025-06-03 04:32:20 --> Language Class Initialized
INFO - 2025-06-03 04:32:20 --> Loader Class Initialized
INFO - 2025-06-03 04:32:20 --> Helper loaded: url_helper
INFO - 2025-06-03 04:32:20 --> Helper loaded: form_helper
INFO - 2025-06-03 04:32:20 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:32:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:32:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:32:20 --> Controller Class Initialized
INFO - 2025-06-03 04:32:20 --> Model "User_model" initialized
INFO - 2025-06-03 04:32:20 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-06-03 04:32:20 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/home.php
INFO - 2025-06-03 04:32:20 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-06-03 04:32:20 --> Final output sent to browser
DEBUG - 2025-06-03 04:32:20 --> Total execution time: 0.0812
INFO - 2025-06-03 04:35:13 --> Config Class Initialized
INFO - 2025-06-03 04:35:13 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:35:13 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:35:13 --> Utf8 Class Initialized
INFO - 2025-06-03 04:35:13 --> URI Class Initialized
INFO - 2025-06-03 04:35:13 --> Router Class Initialized
INFO - 2025-06-03 04:35:13 --> Output Class Initialized
INFO - 2025-06-03 04:35:13 --> Security Class Initialized
DEBUG - 2025-06-03 04:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:35:13 --> Input Class Initialized
INFO - 2025-06-03 04:35:13 --> Language Class Initialized
INFO - 2025-06-03 04:35:13 --> Loader Class Initialized
INFO - 2025-06-03 04:35:14 --> Helper loaded: url_helper
INFO - 2025-06-03 04:35:14 --> Helper loaded: form_helper
INFO - 2025-06-03 04:35:14 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:35:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:35:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:35:14 --> Controller Class Initialized
INFO - 2025-06-03 04:35:14 --> Model "User_model" initialized
INFO - 2025-06-03 04:35:14 --> Model "Progress_model" initialized
INFO - 2025-06-03 04:35:14 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 04:35:14 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 04:35:14 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/dashboard.php
INFO - 2025-06-03 04:35:14 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 04:35:14 --> Final output sent to browser
DEBUG - 2025-06-03 04:35:14 --> Total execution time: 0.1563
INFO - 2025-06-03 04:35:35 --> Config Class Initialized
INFO - 2025-06-03 04:35:35 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:35:35 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:35:35 --> Utf8 Class Initialized
INFO - 2025-06-03 04:35:35 --> URI Class Initialized
INFO - 2025-06-03 04:35:35 --> Router Class Initialized
INFO - 2025-06-03 04:35:35 --> Output Class Initialized
INFO - 2025-06-03 04:35:35 --> Security Class Initialized
DEBUG - 2025-06-03 04:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:35:35 --> Input Class Initialized
INFO - 2025-06-03 04:35:35 --> Language Class Initialized
INFO - 2025-06-03 04:35:35 --> Loader Class Initialized
INFO - 2025-06-03 04:35:35 --> Helper loaded: url_helper
INFO - 2025-06-03 04:35:35 --> Helper loaded: form_helper
INFO - 2025-06-03 04:35:35 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:35:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:35:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:35:35 --> Controller Class Initialized
INFO - 2025-06-03 04:35:35 --> Model "User_model" initialized
INFO - 2025-06-03 04:35:35 --> Model "Progress_model" initialized
INFO - 2025-06-03 04:35:35 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 04:35:35 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 04:35:35 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/dashboard.php
INFO - 2025-06-03 04:35:35 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 04:35:35 --> Final output sent to browser
DEBUG - 2025-06-03 04:35:35 --> Total execution time: 0.1279
INFO - 2025-06-03 04:36:47 --> Config Class Initialized
INFO - 2025-06-03 04:36:47 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:36:47 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:36:47 --> Utf8 Class Initialized
INFO - 2025-06-03 04:36:47 --> URI Class Initialized
INFO - 2025-06-03 04:36:47 --> Router Class Initialized
INFO - 2025-06-03 04:36:47 --> Output Class Initialized
INFO - 2025-06-03 04:36:47 --> Security Class Initialized
DEBUG - 2025-06-03 04:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:36:47 --> Input Class Initialized
INFO - 2025-06-03 04:36:47 --> Language Class Initialized
INFO - 2025-06-03 04:36:47 --> Loader Class Initialized
INFO - 2025-06-03 04:36:47 --> Helper loaded: url_helper
INFO - 2025-06-03 04:36:47 --> Helper loaded: form_helper
INFO - 2025-06-03 04:36:47 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:36:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:36:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:36:47 --> Controller Class Initialized
INFO - 2025-06-03 04:36:47 --> Model "User_model" initialized
INFO - 2025-06-03 04:36:47 --> Model "Progress_model" initialized
INFO - 2025-06-03 04:36:47 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 04:36:48 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 04:36:48 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/dashboard.php
INFO - 2025-06-03 04:36:48 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 04:36:48 --> Final output sent to browser
DEBUG - 2025-06-03 04:36:48 --> Total execution time: 0.1326
INFO - 2025-06-03 04:37:25 --> Config Class Initialized
INFO - 2025-06-03 04:37:25 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:37:25 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:37:25 --> Utf8 Class Initialized
INFO - 2025-06-03 04:37:25 --> URI Class Initialized
INFO - 2025-06-03 04:37:25 --> Router Class Initialized
INFO - 2025-06-03 04:37:25 --> Output Class Initialized
INFO - 2025-06-03 04:37:25 --> Security Class Initialized
DEBUG - 2025-06-03 04:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:37:25 --> Input Class Initialized
INFO - 2025-06-03 04:37:25 --> Language Class Initialized
INFO - 2025-06-03 04:37:25 --> Loader Class Initialized
INFO - 2025-06-03 04:37:25 --> Helper loaded: url_helper
INFO - 2025-06-03 04:37:25 --> Helper loaded: form_helper
INFO - 2025-06-03 04:37:25 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:37:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:37:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:37:25 --> Controller Class Initialized
INFO - 2025-06-03 04:37:25 --> Model "User_model" initialized
INFO - 2025-06-03 04:37:25 --> Model "Progress_model" initialized
INFO - 2025-06-03 04:37:25 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 04:37:25 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 04:37:25 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/dashboard.php
INFO - 2025-06-03 04:37:25 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 04:37:25 --> Final output sent to browser
DEBUG - 2025-06-03 04:37:25 --> Total execution time: 0.1414
INFO - 2025-06-03 04:37:46 --> Config Class Initialized
INFO - 2025-06-03 04:37:46 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:37:46 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:37:46 --> Utf8 Class Initialized
INFO - 2025-06-03 04:37:46 --> URI Class Initialized
INFO - 2025-06-03 04:37:46 --> Router Class Initialized
INFO - 2025-06-03 04:37:46 --> Output Class Initialized
INFO - 2025-06-03 04:37:46 --> Security Class Initialized
DEBUG - 2025-06-03 04:37:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:37:46 --> Input Class Initialized
INFO - 2025-06-03 04:37:46 --> Language Class Initialized
INFO - 2025-06-03 04:37:46 --> Loader Class Initialized
INFO - 2025-06-03 04:37:46 --> Helper loaded: url_helper
INFO - 2025-06-03 04:37:46 --> Helper loaded: form_helper
INFO - 2025-06-03 04:37:46 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:37:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:37:46 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:37:46 --> Controller Class Initialized
INFO - 2025-06-03 04:37:46 --> Model "User_model" initialized
INFO - 2025-06-03 04:37:46 --> Model "Progress_model" initialized
INFO - 2025-06-03 04:37:46 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 04:37:46 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 04:37:46 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/dashboard.php
INFO - 2025-06-03 04:37:46 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 04:37:46 --> Final output sent to browser
DEBUG - 2025-06-03 04:37:46 --> Total execution time: 0.1368
INFO - 2025-06-03 04:38:05 --> Config Class Initialized
INFO - 2025-06-03 04:38:05 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:38:05 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:38:05 --> Utf8 Class Initialized
INFO - 2025-06-03 04:38:05 --> URI Class Initialized
INFO - 2025-06-03 04:38:05 --> Router Class Initialized
INFO - 2025-06-03 04:38:05 --> Output Class Initialized
INFO - 2025-06-03 04:38:05 --> Security Class Initialized
DEBUG - 2025-06-03 04:38:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:38:05 --> Input Class Initialized
INFO - 2025-06-03 04:38:05 --> Language Class Initialized
INFO - 2025-06-03 04:38:05 --> Loader Class Initialized
INFO - 2025-06-03 04:38:05 --> Helper loaded: url_helper
INFO - 2025-06-03 04:38:05 --> Helper loaded: form_helper
INFO - 2025-06-03 04:38:06 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:38:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:38:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:38:06 --> Controller Class Initialized
INFO - 2025-06-03 04:38:06 --> Model "User_model" initialized
INFO - 2025-06-03 04:38:06 --> Model "Progress_model" initialized
INFO - 2025-06-03 04:38:06 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 04:38:06 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 04:38:06 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/dashboard.php
INFO - 2025-06-03 04:38:06 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 04:38:06 --> Final output sent to browser
DEBUG - 2025-06-03 04:38:06 --> Total execution time: 0.1414
INFO - 2025-06-03 04:38:25 --> Config Class Initialized
INFO - 2025-06-03 04:38:25 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:38:25 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:38:25 --> Utf8 Class Initialized
INFO - 2025-06-03 04:38:25 --> URI Class Initialized
INFO - 2025-06-03 04:38:25 --> Router Class Initialized
INFO - 2025-06-03 04:38:25 --> Output Class Initialized
INFO - 2025-06-03 04:38:25 --> Security Class Initialized
DEBUG - 2025-06-03 04:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:38:25 --> Input Class Initialized
INFO - 2025-06-03 04:38:25 --> Language Class Initialized
INFO - 2025-06-03 04:38:25 --> Loader Class Initialized
INFO - 2025-06-03 04:38:25 --> Helper loaded: url_helper
INFO - 2025-06-03 04:38:25 --> Helper loaded: form_helper
INFO - 2025-06-03 04:38:25 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:38:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:38:25 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:38:25 --> Controller Class Initialized
INFO - 2025-06-03 04:38:25 --> Model "User_model" initialized
INFO - 2025-06-03 04:38:25 --> Model "Progress_model" initialized
INFO - 2025-06-03 04:38:25 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 04:38:25 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 04:38:25 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/dashboard.php
INFO - 2025-06-03 04:38:25 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 04:38:25 --> Final output sent to browser
DEBUG - 2025-06-03 04:38:25 --> Total execution time: 0.1520
INFO - 2025-06-03 04:38:35 --> Config Class Initialized
INFO - 2025-06-03 04:38:35 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:38:35 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:38:35 --> Utf8 Class Initialized
INFO - 2025-06-03 04:38:35 --> URI Class Initialized
INFO - 2025-06-03 04:38:35 --> Router Class Initialized
INFO - 2025-06-03 04:38:35 --> Output Class Initialized
INFO - 2025-06-03 04:38:35 --> Security Class Initialized
DEBUG - 2025-06-03 04:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:38:35 --> Input Class Initialized
INFO - 2025-06-03 04:38:35 --> Language Class Initialized
INFO - 2025-06-03 04:38:35 --> Loader Class Initialized
INFO - 2025-06-03 04:38:35 --> Helper loaded: url_helper
INFO - 2025-06-03 04:38:35 --> Helper loaded: form_helper
INFO - 2025-06-03 04:38:35 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:38:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:38:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:38:35 --> Controller Class Initialized
INFO - 2025-06-03 04:38:35 --> Model "User_model" initialized
INFO - 2025-06-03 04:38:35 --> Model "Progress_model" initialized
INFO - 2025-06-03 04:38:35 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 04:38:35 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 04:38:35 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/dashboard.php
INFO - 2025-06-03 04:38:35 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 04:38:35 --> Final output sent to browser
DEBUG - 2025-06-03 04:38:35 --> Total execution time: 0.1423
INFO - 2025-06-03 04:38:47 --> Config Class Initialized
INFO - 2025-06-03 04:38:47 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:38:47 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:38:47 --> Utf8 Class Initialized
INFO - 2025-06-03 04:38:47 --> URI Class Initialized
INFO - 2025-06-03 04:38:47 --> Router Class Initialized
INFO - 2025-06-03 04:38:47 --> Output Class Initialized
INFO - 2025-06-03 04:38:48 --> Security Class Initialized
DEBUG - 2025-06-03 04:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:38:48 --> Input Class Initialized
INFO - 2025-06-03 04:38:48 --> Language Class Initialized
INFO - 2025-06-03 04:38:48 --> Loader Class Initialized
INFO - 2025-06-03 04:38:48 --> Helper loaded: url_helper
INFO - 2025-06-03 04:38:48 --> Helper loaded: form_helper
INFO - 2025-06-03 04:38:48 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:38:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:38:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:38:48 --> Controller Class Initialized
INFO - 2025-06-03 04:38:48 --> Model "User_model" initialized
INFO - 2025-06-03 04:38:48 --> Model "Progress_model" initialized
INFO - 2025-06-03 04:38:48 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 04:38:48 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 04:38:48 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/dashboard.php
INFO - 2025-06-03 04:38:48 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 04:38:48 --> Final output sent to browser
DEBUG - 2025-06-03 04:38:48 --> Total execution time: 0.1467
INFO - 2025-06-03 04:38:54 --> Config Class Initialized
INFO - 2025-06-03 04:38:54 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:38:54 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:38:54 --> Utf8 Class Initialized
INFO - 2025-06-03 04:38:54 --> URI Class Initialized
INFO - 2025-06-03 04:38:54 --> Router Class Initialized
INFO - 2025-06-03 04:38:54 --> Output Class Initialized
INFO - 2025-06-03 04:38:54 --> Security Class Initialized
DEBUG - 2025-06-03 04:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:38:54 --> Input Class Initialized
INFO - 2025-06-03 04:38:54 --> Language Class Initialized
INFO - 2025-06-03 04:38:54 --> Loader Class Initialized
INFO - 2025-06-03 04:38:54 --> Helper loaded: url_helper
INFO - 2025-06-03 04:38:54 --> Helper loaded: form_helper
INFO - 2025-06-03 04:38:54 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:38:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:38:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:38:54 --> Controller Class Initialized
INFO - 2025-06-03 04:38:54 --> Model "User_model" initialized
INFO - 2025-06-03 04:38:54 --> Model "Progress_model" initialized
INFO - 2025-06-03 04:38:55 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 04:38:55 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 04:38:55 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/dashboard.php
INFO - 2025-06-03 04:38:55 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 04:38:55 --> Final output sent to browser
DEBUG - 2025-06-03 04:38:55 --> Total execution time: 0.0888
INFO - 2025-06-03 04:39:03 --> Config Class Initialized
INFO - 2025-06-03 04:39:03 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:39:03 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:39:03 --> Utf8 Class Initialized
INFO - 2025-06-03 04:39:03 --> URI Class Initialized
INFO - 2025-06-03 04:39:03 --> Router Class Initialized
INFO - 2025-06-03 04:39:03 --> Output Class Initialized
INFO - 2025-06-03 04:39:03 --> Security Class Initialized
DEBUG - 2025-06-03 04:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:39:03 --> Input Class Initialized
INFO - 2025-06-03 04:39:03 --> Language Class Initialized
INFO - 2025-06-03 04:39:03 --> Loader Class Initialized
INFO - 2025-06-03 04:39:03 --> Helper loaded: url_helper
INFO - 2025-06-03 04:39:03 --> Helper loaded: form_helper
INFO - 2025-06-03 04:39:03 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:39:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:39:03 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:39:03 --> Controller Class Initialized
INFO - 2025-06-03 04:39:03 --> Model "User_model" initialized
INFO - 2025-06-03 04:39:03 --> Model "Progress_model" initialized
INFO - 2025-06-03 04:39:03 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 04:39:03 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 04:39:03 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/dashboard.php
INFO - 2025-06-03 04:39:03 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 04:39:03 --> Final output sent to browser
DEBUG - 2025-06-03 04:39:03 --> Total execution time: 0.0978
INFO - 2025-06-03 04:40:59 --> Config Class Initialized
INFO - 2025-06-03 04:40:59 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:40:59 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:40:59 --> Utf8 Class Initialized
INFO - 2025-06-03 04:40:59 --> URI Class Initialized
INFO - 2025-06-03 04:40:59 --> Router Class Initialized
INFO - 2025-06-03 04:40:59 --> Output Class Initialized
INFO - 2025-06-03 04:40:59 --> Security Class Initialized
DEBUG - 2025-06-03 04:40:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:40:59 --> Input Class Initialized
INFO - 2025-06-03 04:40:59 --> Language Class Initialized
INFO - 2025-06-03 04:40:59 --> Loader Class Initialized
INFO - 2025-06-03 04:40:59 --> Helper loaded: url_helper
INFO - 2025-06-03 04:40:59 --> Helper loaded: form_helper
INFO - 2025-06-03 04:40:59 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:40:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:40:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:40:59 --> Controller Class Initialized
INFO - 2025-06-03 04:40:59 --> Model "User_model" initialized
INFO - 2025-06-03 04:40:59 --> Model "Progress_model" initialized
INFO - 2025-06-03 04:40:59 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 04:40:59 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 04:40:59 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/dashboard.php
INFO - 2025-06-03 04:40:59 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 04:40:59 --> Final output sent to browser
DEBUG - 2025-06-03 04:40:59 --> Total execution time: 0.1338
INFO - 2025-06-03 04:41:08 --> Config Class Initialized
INFO - 2025-06-03 04:41:08 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:41:08 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:41:08 --> Utf8 Class Initialized
INFO - 2025-06-03 04:41:08 --> URI Class Initialized
INFO - 2025-06-03 04:41:08 --> Router Class Initialized
INFO - 2025-06-03 04:41:08 --> Output Class Initialized
INFO - 2025-06-03 04:41:08 --> Security Class Initialized
DEBUG - 2025-06-03 04:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:41:08 --> Input Class Initialized
INFO - 2025-06-03 04:41:08 --> Language Class Initialized
INFO - 2025-06-03 04:41:08 --> Loader Class Initialized
INFO - 2025-06-03 04:41:08 --> Helper loaded: url_helper
INFO - 2025-06-03 04:41:08 --> Helper loaded: form_helper
INFO - 2025-06-03 04:41:08 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:41:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:41:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:41:08 --> Controller Class Initialized
INFO - 2025-06-03 04:41:08 --> Model "User_model" initialized
INFO - 2025-06-03 04:41:08 --> Model "Progress_model" initialized
INFO - 2025-06-03 04:41:08 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 04:41:08 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 04:41:08 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/dashboard.php
INFO - 2025-06-03 04:41:08 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 04:41:08 --> Final output sent to browser
DEBUG - 2025-06-03 04:41:08 --> Total execution time: 0.0843
INFO - 2025-06-03 04:41:35 --> Config Class Initialized
INFO - 2025-06-03 04:41:35 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:41:35 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:41:35 --> Utf8 Class Initialized
INFO - 2025-06-03 04:41:35 --> URI Class Initialized
INFO - 2025-06-03 04:41:35 --> Router Class Initialized
INFO - 2025-06-03 04:41:35 --> Output Class Initialized
INFO - 2025-06-03 04:41:35 --> Security Class Initialized
DEBUG - 2025-06-03 04:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:41:35 --> Input Class Initialized
INFO - 2025-06-03 04:41:35 --> Language Class Initialized
INFO - 2025-06-03 04:41:35 --> Loader Class Initialized
INFO - 2025-06-03 04:41:35 --> Helper loaded: url_helper
INFO - 2025-06-03 04:41:35 --> Helper loaded: form_helper
INFO - 2025-06-03 04:41:35 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:41:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:41:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:41:35 --> Controller Class Initialized
INFO - 2025-06-03 04:41:35 --> Model "User_model" initialized
INFO - 2025-06-03 04:41:35 --> Model "Progress_model" initialized
INFO - 2025-06-03 04:41:35 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 04:41:35 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 04:41:35 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/dashboard.php
INFO - 2025-06-03 04:41:35 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 04:41:35 --> Final output sent to browser
DEBUG - 2025-06-03 04:41:35 --> Total execution time: 0.0841
INFO - 2025-06-03 04:41:45 --> Config Class Initialized
INFO - 2025-06-03 04:41:45 --> Hooks Class Initialized
DEBUG - 2025-06-03 04:41:45 --> UTF-8 Support Enabled
INFO - 2025-06-03 04:41:45 --> Utf8 Class Initialized
INFO - 2025-06-03 04:41:45 --> URI Class Initialized
INFO - 2025-06-03 04:41:45 --> Router Class Initialized
INFO - 2025-06-03 04:41:45 --> Output Class Initialized
INFO - 2025-06-03 04:41:45 --> Security Class Initialized
DEBUG - 2025-06-03 04:41:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 04:41:45 --> Input Class Initialized
INFO - 2025-06-03 04:41:45 --> Language Class Initialized
INFO - 2025-06-03 04:41:45 --> Loader Class Initialized
INFO - 2025-06-03 04:41:45 --> Helper loaded: url_helper
INFO - 2025-06-03 04:41:45 --> Helper loaded: form_helper
INFO - 2025-06-03 04:41:45 --> Database Driver Class Initialized
DEBUG - 2025-06-03 04:41:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 04:41:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 04:41:45 --> Controller Class Initialized
INFO - 2025-06-03 04:41:45 --> Model "User_model" initialized
INFO - 2025-06-03 04:41:45 --> Model "Progress_model" initialized
INFO - 2025-06-03 04:41:45 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 04:41:45 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 04:41:45 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/dashboard.php
INFO - 2025-06-03 04:41:45 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 04:41:45 --> Final output sent to browser
DEBUG - 2025-06-03 04:41:45 --> Total execution time: 0.0953
INFO - 2025-06-03 14:30:47 --> Config Class Initialized
INFO - 2025-06-03 14:30:47 --> Hooks Class Initialized
DEBUG - 2025-06-03 14:30:47 --> UTF-8 Support Enabled
INFO - 2025-06-03 14:30:47 --> Utf8 Class Initialized
INFO - 2025-06-03 14:30:47 --> URI Class Initialized
DEBUG - 2025-06-03 14:30:47 --> No URI present. Default controller set.
INFO - 2025-06-03 14:30:47 --> Router Class Initialized
INFO - 2025-06-03 14:30:47 --> Output Class Initialized
INFO - 2025-06-03 14:30:47 --> Security Class Initialized
DEBUG - 2025-06-03 14:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 14:30:47 --> Input Class Initialized
INFO - 2025-06-03 14:30:47 --> Language Class Initialized
INFO - 2025-06-03 14:30:47 --> Loader Class Initialized
INFO - 2025-06-03 14:30:47 --> Helper loaded: url_helper
INFO - 2025-06-03 14:30:47 --> Helper loaded: form_helper
INFO - 2025-06-03 14:30:47 --> Database Driver Class Initialized
DEBUG - 2025-06-03 14:30:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 14:30:47 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 14:30:47 --> Controller Class Initialized
INFO - 2025-06-03 14:30:47 --> Model "User_model" initialized
INFO - 2025-06-03 14:30:47 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-06-03 14:30:47 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/home.php
INFO - 2025-06-03 14:30:47 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-06-03 14:30:47 --> Final output sent to browser
DEBUG - 2025-06-03 14:30:47 --> Total execution time: 0.2240
INFO - 2025-06-03 14:30:54 --> Config Class Initialized
INFO - 2025-06-03 14:30:54 --> Hooks Class Initialized
DEBUG - 2025-06-03 14:30:54 --> UTF-8 Support Enabled
INFO - 2025-06-03 14:30:54 --> Utf8 Class Initialized
INFO - 2025-06-03 14:30:54 --> URI Class Initialized
INFO - 2025-06-03 14:30:54 --> Router Class Initialized
INFO - 2025-06-03 14:30:54 --> Output Class Initialized
INFO - 2025-06-03 14:30:55 --> Security Class Initialized
DEBUG - 2025-06-03 14:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 14:30:55 --> Input Class Initialized
INFO - 2025-06-03 14:30:55 --> Language Class Initialized
INFO - 2025-06-03 14:30:55 --> Loader Class Initialized
INFO - 2025-06-03 14:30:55 --> Helper loaded: url_helper
INFO - 2025-06-03 14:30:55 --> Helper loaded: form_helper
INFO - 2025-06-03 14:30:55 --> Database Driver Class Initialized
DEBUG - 2025-06-03 14:30:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 14:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 14:30:55 --> Controller Class Initialized
INFO - 2025-06-03 14:30:55 --> Model "User_model" initialized
INFO - 2025-06-03 14:30:55 --> Form Validation Class Initialized
INFO - 2025-06-03 14:30:55 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\auth/login.php
INFO - 2025-06-03 14:30:55 --> Final output sent to browser
DEBUG - 2025-06-03 14:30:55 --> Total execution time: 0.1003
INFO - 2025-06-03 14:31:00 --> Config Class Initialized
INFO - 2025-06-03 14:31:00 --> Hooks Class Initialized
DEBUG - 2025-06-03 14:31:00 --> UTF-8 Support Enabled
INFO - 2025-06-03 14:31:00 --> Utf8 Class Initialized
INFO - 2025-06-03 14:31:00 --> URI Class Initialized
INFO - 2025-06-03 14:31:00 --> Router Class Initialized
INFO - 2025-06-03 14:31:00 --> Output Class Initialized
INFO - 2025-06-03 14:31:00 --> Security Class Initialized
DEBUG - 2025-06-03 14:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 14:31:00 --> Input Class Initialized
INFO - 2025-06-03 14:31:00 --> Language Class Initialized
INFO - 2025-06-03 14:31:00 --> Loader Class Initialized
INFO - 2025-06-03 14:31:00 --> Helper loaded: url_helper
INFO - 2025-06-03 14:31:00 --> Helper loaded: form_helper
INFO - 2025-06-03 14:31:00 --> Database Driver Class Initialized
DEBUG - 2025-06-03 14:31:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 14:31:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 14:31:00 --> Controller Class Initialized
INFO - 2025-06-03 14:31:00 --> Model "User_model" initialized
INFO - 2025-06-03 14:31:00 --> Form Validation Class Initialized
INFO - 2025-06-03 14:31:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-06-03 14:31:00 --> Config Class Initialized
INFO - 2025-06-03 14:31:00 --> Hooks Class Initialized
DEBUG - 2025-06-03 14:31:00 --> UTF-8 Support Enabled
INFO - 2025-06-03 14:31:00 --> Utf8 Class Initialized
INFO - 2025-06-03 14:31:00 --> URI Class Initialized
INFO - 2025-06-03 14:31:00 --> Router Class Initialized
INFO - 2025-06-03 14:31:00 --> Output Class Initialized
INFO - 2025-06-03 14:31:00 --> Security Class Initialized
DEBUG - 2025-06-03 14:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 14:31:00 --> Input Class Initialized
INFO - 2025-06-03 14:31:00 --> Language Class Initialized
INFO - 2025-06-03 14:31:00 --> Loader Class Initialized
INFO - 2025-06-03 14:31:00 --> Helper loaded: url_helper
INFO - 2025-06-03 14:31:00 --> Helper loaded: form_helper
INFO - 2025-06-03 14:31:00 --> Database Driver Class Initialized
DEBUG - 2025-06-03 14:31:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 14:31:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 14:31:00 --> Controller Class Initialized
INFO - 2025-06-03 14:31:00 --> Model "User_model" initialized
INFO - 2025-06-03 14:31:00 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-06-03 14:31:00 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/home.php
INFO - 2025-06-03 14:31:00 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-06-03 14:31:00 --> Final output sent to browser
DEBUG - 2025-06-03 14:31:00 --> Total execution time: 0.0857
INFO - 2025-06-03 14:31:03 --> Config Class Initialized
INFO - 2025-06-03 14:31:03 --> Hooks Class Initialized
DEBUG - 2025-06-03 14:31:04 --> UTF-8 Support Enabled
INFO - 2025-06-03 14:31:04 --> Utf8 Class Initialized
INFO - 2025-06-03 14:31:04 --> URI Class Initialized
INFO - 2025-06-03 14:31:04 --> Router Class Initialized
INFO - 2025-06-03 14:31:04 --> Output Class Initialized
INFO - 2025-06-03 14:31:04 --> Security Class Initialized
DEBUG - 2025-06-03 14:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 14:31:04 --> Input Class Initialized
INFO - 2025-06-03 14:31:04 --> Language Class Initialized
INFO - 2025-06-03 14:31:04 --> Loader Class Initialized
INFO - 2025-06-03 14:31:04 --> Helper loaded: url_helper
INFO - 2025-06-03 14:31:04 --> Helper loaded: form_helper
INFO - 2025-06-03 14:31:04 --> Database Driver Class Initialized
DEBUG - 2025-06-03 14:31:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 14:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 14:31:04 --> Controller Class Initialized
INFO - 2025-06-03 14:31:04 --> Model "User_model" initialized
INFO - 2025-06-03 14:31:04 --> Model "Progress_model" initialized
INFO - 2025-06-03 14:31:04 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 14:31:04 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 14:31:04 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/dashboard.php
INFO - 2025-06-03 14:31:04 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 14:31:04 --> Final output sent to browser
DEBUG - 2025-06-03 14:31:04 --> Total execution time: 0.1054
INFO - 2025-06-03 14:31:09 --> Config Class Initialized
INFO - 2025-06-03 14:31:09 --> Hooks Class Initialized
DEBUG - 2025-06-03 14:31:09 --> UTF-8 Support Enabled
INFO - 2025-06-03 14:31:09 --> Utf8 Class Initialized
INFO - 2025-06-03 14:31:09 --> URI Class Initialized
INFO - 2025-06-03 14:31:09 --> Router Class Initialized
INFO - 2025-06-03 14:31:09 --> Output Class Initialized
INFO - 2025-06-03 14:31:09 --> Security Class Initialized
DEBUG - 2025-06-03 14:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 14:31:09 --> Input Class Initialized
INFO - 2025-06-03 14:31:09 --> Language Class Initialized
INFO - 2025-06-03 14:31:09 --> Loader Class Initialized
INFO - 2025-06-03 14:31:09 --> Helper loaded: url_helper
INFO - 2025-06-03 14:31:09 --> Helper loaded: form_helper
INFO - 2025-06-03 14:31:09 --> Database Driver Class Initialized
DEBUG - 2025-06-03 14:31:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 14:31:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 14:31:09 --> Controller Class Initialized
INFO - 2025-06-03 14:31:09 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 14:31:09 --> Model "User_model" initialized
INFO - 2025-06-03 14:31:09 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 14:31:09 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 14:31:09 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-06-03 14:31:09 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 14:31:09 --> Final output sent to browser
DEBUG - 2025-06-03 14:31:09 --> Total execution time: 0.0803
INFO - 2025-06-03 14:31:10 --> Config Class Initialized
INFO - 2025-06-03 14:31:10 --> Hooks Class Initialized
DEBUG - 2025-06-03 14:31:10 --> UTF-8 Support Enabled
INFO - 2025-06-03 14:31:10 --> Utf8 Class Initialized
INFO - 2025-06-03 14:31:10 --> URI Class Initialized
INFO - 2025-06-03 14:31:10 --> Router Class Initialized
INFO - 2025-06-03 14:31:10 --> Output Class Initialized
INFO - 2025-06-03 14:31:10 --> Security Class Initialized
DEBUG - 2025-06-03 14:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 14:31:10 --> Input Class Initialized
INFO - 2025-06-03 14:31:10 --> Language Class Initialized
INFO - 2025-06-03 14:31:10 --> Loader Class Initialized
INFO - 2025-06-03 14:31:10 --> Helper loaded: url_helper
INFO - 2025-06-03 14:31:10 --> Helper loaded: form_helper
INFO - 2025-06-03 14:31:11 --> Database Driver Class Initialized
DEBUG - 2025-06-03 14:31:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 14:31:11 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 14:31:11 --> Controller Class Initialized
INFO - 2025-06-03 14:31:11 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 14:31:11 --> Model "User_model" initialized
INFO - 2025-06-03 14:31:11 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 14:31:11 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 14:31:11 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/level.php
INFO - 2025-06-03 14:31:11 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 14:31:11 --> Final output sent to browser
DEBUG - 2025-06-03 14:31:11 --> Total execution time: 0.0779
INFO - 2025-06-03 14:31:12 --> Config Class Initialized
INFO - 2025-06-03 14:31:12 --> Hooks Class Initialized
DEBUG - 2025-06-03 14:31:12 --> UTF-8 Support Enabled
INFO - 2025-06-03 14:31:12 --> Utf8 Class Initialized
INFO - 2025-06-03 14:31:12 --> URI Class Initialized
INFO - 2025-06-03 14:31:12 --> Router Class Initialized
INFO - 2025-06-03 14:31:12 --> Output Class Initialized
INFO - 2025-06-03 14:31:12 --> Security Class Initialized
DEBUG - 2025-06-03 14:31:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 14:31:12 --> Input Class Initialized
INFO - 2025-06-03 14:31:12 --> Language Class Initialized
INFO - 2025-06-03 14:31:12 --> Loader Class Initialized
INFO - 2025-06-03 14:31:12 --> Helper loaded: url_helper
INFO - 2025-06-03 14:31:12 --> Helper loaded: form_helper
INFO - 2025-06-03 14:31:12 --> Database Driver Class Initialized
DEBUG - 2025-06-03 14:31:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 14:31:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 14:31:12 --> Controller Class Initialized
INFO - 2025-06-03 14:31:12 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 14:31:12 --> Model "User_model" initialized
INFO - 2025-06-03 14:31:12 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 14:31:12 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 14:31:12 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-06-03 14:31:12 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 14:31:12 --> Final output sent to browser
DEBUG - 2025-06-03 14:31:12 --> Total execution time: 0.0845
INFO - 2025-06-03 14:31:15 --> Config Class Initialized
INFO - 2025-06-03 14:31:15 --> Hooks Class Initialized
DEBUG - 2025-06-03 14:31:15 --> UTF-8 Support Enabled
INFO - 2025-06-03 14:31:15 --> Utf8 Class Initialized
INFO - 2025-06-03 14:31:15 --> URI Class Initialized
INFO - 2025-06-03 14:31:15 --> Router Class Initialized
INFO - 2025-06-03 14:31:15 --> Output Class Initialized
INFO - 2025-06-03 14:31:15 --> Security Class Initialized
DEBUG - 2025-06-03 14:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 14:31:15 --> Input Class Initialized
INFO - 2025-06-03 14:31:15 --> Language Class Initialized
INFO - 2025-06-03 14:31:15 --> Loader Class Initialized
INFO - 2025-06-03 14:31:15 --> Helper loaded: url_helper
INFO - 2025-06-03 14:31:15 --> Helper loaded: form_helper
INFO - 2025-06-03 14:31:15 --> Database Driver Class Initialized
DEBUG - 2025-06-03 14:31:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 14:31:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 14:31:15 --> Controller Class Initialized
INFO - 2025-06-03 14:31:15 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 14:31:15 --> Model "User_model" initialized
INFO - 2025-06-03 14:31:15 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 14:31:15 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 14:31:15 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/start.php
INFO - 2025-06-03 14:31:15 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 14:31:15 --> Final output sent to browser
DEBUG - 2025-06-03 14:31:15 --> Total execution time: 0.0883
INFO - 2025-06-03 14:31:26 --> Config Class Initialized
INFO - 2025-06-03 14:31:26 --> Hooks Class Initialized
DEBUG - 2025-06-03 14:31:26 --> UTF-8 Support Enabled
INFO - 2025-06-03 14:31:26 --> Utf8 Class Initialized
INFO - 2025-06-03 14:31:26 --> URI Class Initialized
INFO - 2025-06-03 14:31:26 --> Router Class Initialized
INFO - 2025-06-03 14:31:26 --> Output Class Initialized
INFO - 2025-06-03 14:31:26 --> Security Class Initialized
DEBUG - 2025-06-03 14:31:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 14:31:26 --> Input Class Initialized
INFO - 2025-06-03 14:31:26 --> Language Class Initialized
INFO - 2025-06-03 14:31:26 --> Loader Class Initialized
INFO - 2025-06-03 14:31:26 --> Helper loaded: url_helper
INFO - 2025-06-03 14:31:26 --> Helper loaded: form_helper
INFO - 2025-06-03 14:31:26 --> Database Driver Class Initialized
DEBUG - 2025-06-03 14:31:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 14:31:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 14:31:26 --> Controller Class Initialized
INFO - 2025-06-03 14:31:26 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 14:31:26 --> Model "User_model" initialized
INFO - 2025-06-03 14:31:26 --> Final output sent to browser
DEBUG - 2025-06-03 14:31:26 --> Total execution time: 0.1219
INFO - 2025-06-03 14:32:09 --> Config Class Initialized
INFO - 2025-06-03 14:32:09 --> Hooks Class Initialized
DEBUG - 2025-06-03 14:32:09 --> UTF-8 Support Enabled
INFO - 2025-06-03 14:32:09 --> Utf8 Class Initialized
INFO - 2025-06-03 14:32:09 --> URI Class Initialized
INFO - 2025-06-03 14:32:09 --> Router Class Initialized
INFO - 2025-06-03 14:32:09 --> Output Class Initialized
INFO - 2025-06-03 14:32:09 --> Security Class Initialized
DEBUG - 2025-06-03 14:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 14:32:09 --> Input Class Initialized
INFO - 2025-06-03 14:32:09 --> Language Class Initialized
INFO - 2025-06-03 14:32:09 --> Loader Class Initialized
INFO - 2025-06-03 14:32:09 --> Helper loaded: url_helper
INFO - 2025-06-03 14:32:09 --> Helper loaded: form_helper
INFO - 2025-06-03 14:32:09 --> Database Driver Class Initialized
DEBUG - 2025-06-03 14:32:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 14:32:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 14:32:09 --> Controller Class Initialized
INFO - 2025-06-03 14:32:09 --> Model "User_model" initialized
INFO - 2025-06-03 14:32:09 --> Model "Community_model" initialized
INFO - 2025-06-03 14:32:10 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 14:32:10 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 14:32:10 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/community.php
INFO - 2025-06-03 14:32:10 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 14:32:10 --> Final output sent to browser
DEBUG - 2025-06-03 14:32:10 --> Total execution time: 0.1826
INFO - 2025-06-03 14:32:11 --> Config Class Initialized
INFO - 2025-06-03 14:32:11 --> Hooks Class Initialized
DEBUG - 2025-06-03 14:32:11 --> UTF-8 Support Enabled
INFO - 2025-06-03 14:32:11 --> Utf8 Class Initialized
INFO - 2025-06-03 14:32:11 --> URI Class Initialized
INFO - 2025-06-03 14:32:11 --> Router Class Initialized
INFO - 2025-06-03 14:32:11 --> Output Class Initialized
INFO - 2025-06-03 14:32:11 --> Security Class Initialized
DEBUG - 2025-06-03 14:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 14:32:11 --> Input Class Initialized
INFO - 2025-06-03 14:32:11 --> Language Class Initialized
INFO - 2025-06-03 14:32:11 --> Loader Class Initialized
INFO - 2025-06-03 14:32:11 --> Helper loaded: url_helper
INFO - 2025-06-03 14:32:11 --> Helper loaded: form_helper
INFO - 2025-06-03 14:32:11 --> Database Driver Class Initialized
DEBUG - 2025-06-03 14:32:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 14:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 14:32:12 --> Controller Class Initialized
INFO - 2025-06-03 14:32:12 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 14:32:12 --> Model "User_model" initialized
INFO - 2025-06-03 14:32:12 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 14:32:12 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 14:32:12 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-06-03 14:32:12 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 14:32:12 --> Final output sent to browser
DEBUG - 2025-06-03 14:32:12 --> Total execution time: 0.1229
INFO - 2025-06-03 14:32:13 --> Config Class Initialized
INFO - 2025-06-03 14:32:13 --> Hooks Class Initialized
DEBUG - 2025-06-03 14:32:13 --> UTF-8 Support Enabled
INFO - 2025-06-03 14:32:13 --> Utf8 Class Initialized
INFO - 2025-06-03 14:32:13 --> URI Class Initialized
INFO - 2025-06-03 14:32:13 --> Router Class Initialized
INFO - 2025-06-03 14:32:13 --> Output Class Initialized
INFO - 2025-06-03 14:32:13 --> Security Class Initialized
DEBUG - 2025-06-03 14:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 14:32:13 --> Input Class Initialized
INFO - 2025-06-03 14:32:13 --> Language Class Initialized
INFO - 2025-06-03 14:32:13 --> Loader Class Initialized
INFO - 2025-06-03 14:32:13 --> Helper loaded: url_helper
INFO - 2025-06-03 14:32:13 --> Helper loaded: form_helper
INFO - 2025-06-03 14:32:13 --> Database Driver Class Initialized
DEBUG - 2025-06-03 14:32:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 14:32:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 14:32:13 --> Controller Class Initialized
INFO - 2025-06-03 14:32:13 --> Model "Progress_model" initialized
INFO - 2025-06-03 14:32:13 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 14:32:13 --> Model "User_model" initialized
INFO - 2025-06-03 14:32:13 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 14:32:13 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 14:32:13 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/progress_view.php
INFO - 2025-06-03 14:32:13 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 14:32:13 --> Final output sent to browser
DEBUG - 2025-06-03 14:32:13 --> Total execution time: 0.0831
INFO - 2025-06-03 14:32:14 --> Config Class Initialized
INFO - 2025-06-03 14:32:14 --> Hooks Class Initialized
DEBUG - 2025-06-03 14:32:14 --> UTF-8 Support Enabled
INFO - 2025-06-03 14:32:14 --> Utf8 Class Initialized
INFO - 2025-06-03 14:32:14 --> URI Class Initialized
INFO - 2025-06-03 14:32:14 --> Router Class Initialized
INFO - 2025-06-03 14:32:14 --> Output Class Initialized
INFO - 2025-06-03 14:32:14 --> Security Class Initialized
DEBUG - 2025-06-03 14:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 14:32:14 --> Input Class Initialized
INFO - 2025-06-03 14:32:14 --> Language Class Initialized
INFO - 2025-06-03 14:32:14 --> Loader Class Initialized
INFO - 2025-06-03 14:32:14 --> Helper loaded: url_helper
INFO - 2025-06-03 14:32:14 --> Helper loaded: form_helper
INFO - 2025-06-03 14:32:14 --> Database Driver Class Initialized
DEBUG - 2025-06-03 14:32:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 14:32:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 14:32:14 --> Controller Class Initialized
INFO - 2025-06-03 14:32:14 --> Model "Progress_model" initialized
INFO - 2025-06-03 14:32:14 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 14:32:14 --> Model "User_model" initialized
INFO - 2025-06-03 14:32:14 --> Final output sent to browser
DEBUG - 2025-06-03 14:32:14 --> Total execution time: 0.3837
INFO - 2025-06-03 14:32:15 --> Config Class Initialized
INFO - 2025-06-03 14:32:15 --> Hooks Class Initialized
DEBUG - 2025-06-03 14:32:15 --> UTF-8 Support Enabled
INFO - 2025-06-03 14:32:15 --> Utf8 Class Initialized
INFO - 2025-06-03 14:32:15 --> URI Class Initialized
INFO - 2025-06-03 14:32:15 --> Router Class Initialized
INFO - 2025-06-03 14:32:15 --> Output Class Initialized
INFO - 2025-06-03 14:32:15 --> Security Class Initialized
DEBUG - 2025-06-03 14:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 14:32:15 --> Input Class Initialized
INFO - 2025-06-03 14:32:15 --> Language Class Initialized
INFO - 2025-06-03 14:32:15 --> Loader Class Initialized
INFO - 2025-06-03 14:32:15 --> Helper loaded: url_helper
INFO - 2025-06-03 14:32:15 --> Helper loaded: form_helper
INFO - 2025-06-03 14:32:15 --> Database Driver Class Initialized
DEBUG - 2025-06-03 14:32:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 14:32:15 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 14:32:15 --> Controller Class Initialized
INFO - 2025-06-03 14:32:15 --> Model "User_model" initialized
INFO - 2025-06-03 14:32:15 --> Model "Progress_model" initialized
INFO - 2025-06-03 14:32:15 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 14:32:15 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 14:32:15 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/guide.php
INFO - 2025-06-03 14:32:15 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 14:32:15 --> Final output sent to browser
DEBUG - 2025-06-03 14:32:15 --> Total execution time: 0.0756
INFO - 2025-06-03 14:32:17 --> Config Class Initialized
INFO - 2025-06-03 14:32:17 --> Hooks Class Initialized
DEBUG - 2025-06-03 14:32:17 --> UTF-8 Support Enabled
INFO - 2025-06-03 14:32:17 --> Utf8 Class Initialized
INFO - 2025-06-03 14:32:17 --> URI Class Initialized
INFO - 2025-06-03 14:32:17 --> Router Class Initialized
INFO - 2025-06-03 14:32:17 --> Output Class Initialized
INFO - 2025-06-03 14:32:17 --> Security Class Initialized
DEBUG - 2025-06-03 14:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 14:32:17 --> Input Class Initialized
INFO - 2025-06-03 14:32:17 --> Language Class Initialized
INFO - 2025-06-03 14:32:17 --> Loader Class Initialized
INFO - 2025-06-03 14:32:17 --> Helper loaded: url_helper
INFO - 2025-06-03 14:32:17 --> Helper loaded: form_helper
INFO - 2025-06-03 14:32:17 --> Database Driver Class Initialized
DEBUG - 2025-06-03 14:32:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 14:32:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 14:32:17 --> Controller Class Initialized
INFO - 2025-06-03 14:32:17 --> Model "Progress_model" initialized
INFO - 2025-06-03 14:32:17 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 14:32:17 --> Model "User_model" initialized
INFO - 2025-06-03 14:32:17 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 14:32:17 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 14:32:17 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/progress_view.php
INFO - 2025-06-03 14:32:17 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 14:32:17 --> Final output sent to browser
DEBUG - 2025-06-03 14:32:17 --> Total execution time: 0.0848
INFO - 2025-06-03 14:32:18 --> Config Class Initialized
INFO - 2025-06-03 14:32:18 --> Hooks Class Initialized
DEBUG - 2025-06-03 14:32:18 --> UTF-8 Support Enabled
INFO - 2025-06-03 14:32:18 --> Utf8 Class Initialized
INFO - 2025-06-03 14:32:18 --> URI Class Initialized
INFO - 2025-06-03 14:32:18 --> Router Class Initialized
INFO - 2025-06-03 14:32:18 --> Output Class Initialized
INFO - 2025-06-03 14:32:18 --> Security Class Initialized
DEBUG - 2025-06-03 14:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 14:32:18 --> Input Class Initialized
INFO - 2025-06-03 14:32:18 --> Language Class Initialized
INFO - 2025-06-03 14:32:18 --> Loader Class Initialized
INFO - 2025-06-03 14:32:18 --> Helper loaded: url_helper
INFO - 2025-06-03 14:32:18 --> Helper loaded: form_helper
INFO - 2025-06-03 14:32:18 --> Database Driver Class Initialized
DEBUG - 2025-06-03 14:32:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 14:32:18 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 14:32:18 --> Controller Class Initialized
INFO - 2025-06-03 14:32:18 --> Model "Progress_model" initialized
INFO - 2025-06-03 14:32:18 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 14:32:18 --> Model "User_model" initialized
INFO - 2025-06-03 14:32:18 --> Final output sent to browser
DEBUG - 2025-06-03 14:32:18 --> Total execution time: 0.3016
INFO - 2025-06-03 14:32:22 --> Config Class Initialized
INFO - 2025-06-03 14:32:22 --> Hooks Class Initialized
DEBUG - 2025-06-03 14:32:23 --> UTF-8 Support Enabled
INFO - 2025-06-03 14:32:23 --> Utf8 Class Initialized
INFO - 2025-06-03 14:32:23 --> URI Class Initialized
INFO - 2025-06-03 14:32:23 --> Router Class Initialized
INFO - 2025-06-03 14:32:23 --> Output Class Initialized
INFO - 2025-06-03 14:32:23 --> Security Class Initialized
DEBUG - 2025-06-03 14:32:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 14:32:23 --> Input Class Initialized
INFO - 2025-06-03 14:32:23 --> Language Class Initialized
INFO - 2025-06-03 14:32:23 --> Loader Class Initialized
INFO - 2025-06-03 14:32:23 --> Helper loaded: url_helper
INFO - 2025-06-03 14:32:23 --> Helper loaded: form_helper
INFO - 2025-06-03 14:32:23 --> Database Driver Class Initialized
DEBUG - 2025-06-03 14:32:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 14:32:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 14:32:23 --> Controller Class Initialized
INFO - 2025-06-03 14:32:23 --> Model "Progress_model" initialized
INFO - 2025-06-03 14:32:23 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 14:32:23 --> Model "User_model" initialized
INFO - 2025-06-03 14:32:23 --> Final output sent to browser
DEBUG - 2025-06-03 14:32:23 --> Total execution time: 0.0642
INFO - 2025-06-03 14:32:26 --> Config Class Initialized
INFO - 2025-06-03 14:32:26 --> Hooks Class Initialized
DEBUG - 2025-06-03 14:32:26 --> UTF-8 Support Enabled
INFO - 2025-06-03 14:32:26 --> Utf8 Class Initialized
INFO - 2025-06-03 14:32:26 --> URI Class Initialized
INFO - 2025-06-03 14:32:26 --> Router Class Initialized
INFO - 2025-06-03 14:32:26 --> Output Class Initialized
INFO - 2025-06-03 14:32:26 --> Security Class Initialized
DEBUG - 2025-06-03 14:32:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 14:32:26 --> Input Class Initialized
INFO - 2025-06-03 14:32:26 --> Language Class Initialized
INFO - 2025-06-03 14:32:26 --> Loader Class Initialized
INFO - 2025-06-03 14:32:26 --> Helper loaded: url_helper
INFO - 2025-06-03 14:32:26 --> Helper loaded: form_helper
INFO - 2025-06-03 14:32:26 --> Database Driver Class Initialized
DEBUG - 2025-06-03 14:32:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 14:32:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 14:32:26 --> Controller Class Initialized
INFO - 2025-06-03 14:32:26 --> Model "User_model" initialized
INFO - 2025-06-03 14:32:26 --> Model "Progress_model" initialized
INFO - 2025-06-03 14:32:26 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 14:32:26 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 14:32:26 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/guide.php
INFO - 2025-06-03 14:32:26 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 14:32:26 --> Final output sent to browser
DEBUG - 2025-06-03 14:32:26 --> Total execution time: 0.0830
INFO - 2025-06-03 14:32:31 --> Config Class Initialized
INFO - 2025-06-03 14:32:31 --> Hooks Class Initialized
DEBUG - 2025-06-03 14:32:31 --> UTF-8 Support Enabled
INFO - 2025-06-03 14:32:31 --> Utf8 Class Initialized
INFO - 2025-06-03 14:32:31 --> URI Class Initialized
INFO - 2025-06-03 14:32:31 --> Router Class Initialized
INFO - 2025-06-03 14:32:31 --> Output Class Initialized
INFO - 2025-06-03 14:32:31 --> Security Class Initialized
DEBUG - 2025-06-03 14:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 14:32:31 --> Input Class Initialized
INFO - 2025-06-03 14:32:31 --> Language Class Initialized
INFO - 2025-06-03 14:32:31 --> Loader Class Initialized
INFO - 2025-06-03 14:32:31 --> Helper loaded: url_helper
INFO - 2025-06-03 14:32:31 --> Helper loaded: form_helper
INFO - 2025-06-03 14:32:31 --> Database Driver Class Initialized
DEBUG - 2025-06-03 14:32:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 14:32:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 14:32:31 --> Controller Class Initialized
INFO - 2025-06-03 14:32:31 --> Model "User_model" initialized
INFO - 2025-06-03 14:32:31 --> Model "Progress_model" initialized
INFO - 2025-06-03 14:32:31 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 14:32:31 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 14:32:31 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/dashboard.php
INFO - 2025-06-03 14:32:31 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 14:32:31 --> Final output sent to browser
DEBUG - 2025-06-03 14:32:31 --> Total execution time: 0.0893
INFO - 2025-06-03 14:32:39 --> Config Class Initialized
INFO - 2025-06-03 14:32:39 --> Hooks Class Initialized
DEBUG - 2025-06-03 14:32:39 --> UTF-8 Support Enabled
INFO - 2025-06-03 14:32:39 --> Utf8 Class Initialized
INFO - 2025-06-03 14:32:39 --> URI Class Initialized
INFO - 2025-06-03 14:32:39 --> Router Class Initialized
INFO - 2025-06-03 14:32:39 --> Output Class Initialized
INFO - 2025-06-03 14:32:39 --> Security Class Initialized
DEBUG - 2025-06-03 14:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 14:32:39 --> Input Class Initialized
INFO - 2025-06-03 14:32:39 --> Language Class Initialized
INFO - 2025-06-03 14:32:39 --> Loader Class Initialized
INFO - 2025-06-03 14:32:39 --> Helper loaded: url_helper
INFO - 2025-06-03 14:32:39 --> Helper loaded: form_helper
INFO - 2025-06-03 14:32:39 --> Database Driver Class Initialized
DEBUG - 2025-06-03 14:32:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 14:32:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 14:32:39 --> Controller Class Initialized
INFO - 2025-06-03 14:32:39 --> Model "User_model" initialized
INFO - 2025-06-03 14:32:39 --> Model "Progress_model" initialized
INFO - 2025-06-03 14:32:39 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 14:32:39 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 14:32:39 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/guide.php
INFO - 2025-06-03 14:32:39 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 14:32:39 --> Final output sent to browser
DEBUG - 2025-06-03 14:32:39 --> Total execution time: 0.0820
INFO - 2025-06-03 14:32:41 --> Config Class Initialized
INFO - 2025-06-03 14:32:41 --> Hooks Class Initialized
DEBUG - 2025-06-03 14:32:41 --> UTF-8 Support Enabled
INFO - 2025-06-03 14:32:41 --> Utf8 Class Initialized
INFO - 2025-06-03 14:32:41 --> URI Class Initialized
INFO - 2025-06-03 14:32:41 --> Router Class Initialized
INFO - 2025-06-03 14:32:41 --> Output Class Initialized
INFO - 2025-06-03 14:32:41 --> Security Class Initialized
DEBUG - 2025-06-03 14:32:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 14:32:41 --> Input Class Initialized
INFO - 2025-06-03 14:32:41 --> Language Class Initialized
INFO - 2025-06-03 14:32:41 --> Loader Class Initialized
INFO - 2025-06-03 14:32:41 --> Helper loaded: url_helper
INFO - 2025-06-03 14:32:41 --> Helper loaded: form_helper
INFO - 2025-06-03 14:32:41 --> Database Driver Class Initialized
DEBUG - 2025-06-03 14:32:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 14:32:41 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 14:32:41 --> Controller Class Initialized
INFO - 2025-06-03 14:32:41 --> Model "User_model" initialized
INFO - 2025-06-03 14:32:41 --> Model "Progress_model" initialized
INFO - 2025-06-03 14:32:41 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 14:32:41 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 14:32:41 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/dashboard.php
INFO - 2025-06-03 14:32:41 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 14:32:41 --> Final output sent to browser
DEBUG - 2025-06-03 14:32:41 --> Total execution time: 0.0877
INFO - 2025-06-03 14:32:45 --> Config Class Initialized
INFO - 2025-06-03 14:32:45 --> Hooks Class Initialized
DEBUG - 2025-06-03 14:32:45 --> UTF-8 Support Enabled
INFO - 2025-06-03 14:32:45 --> Utf8 Class Initialized
INFO - 2025-06-03 14:32:45 --> URI Class Initialized
INFO - 2025-06-03 14:32:45 --> Router Class Initialized
INFO - 2025-06-03 14:32:45 --> Output Class Initialized
INFO - 2025-06-03 14:32:45 --> Security Class Initialized
DEBUG - 2025-06-03 14:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 14:32:45 --> Input Class Initialized
INFO - 2025-06-03 14:32:45 --> Language Class Initialized
INFO - 2025-06-03 14:32:45 --> Loader Class Initialized
INFO - 2025-06-03 14:32:45 --> Helper loaded: url_helper
INFO - 2025-06-03 14:32:45 --> Helper loaded: form_helper
INFO - 2025-06-03 14:32:45 --> Database Driver Class Initialized
DEBUG - 2025-06-03 14:32:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 14:32:45 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 14:32:45 --> Controller Class Initialized
INFO - 2025-06-03 14:32:45 --> Model "User_model" initialized
INFO - 2025-06-03 14:32:45 --> Model "Progress_model" initialized
INFO - 2025-06-03 14:32:45 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 14:32:45 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 14:32:45 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/guide.php
INFO - 2025-06-03 14:32:45 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 14:32:45 --> Final output sent to browser
DEBUG - 2025-06-03 14:32:45 --> Total execution time: 0.0806
INFO - 2025-06-03 14:32:48 --> Config Class Initialized
INFO - 2025-06-03 14:32:48 --> Hooks Class Initialized
DEBUG - 2025-06-03 14:32:48 --> UTF-8 Support Enabled
INFO - 2025-06-03 14:32:48 --> Utf8 Class Initialized
INFO - 2025-06-03 14:32:48 --> URI Class Initialized
INFO - 2025-06-03 14:32:48 --> Router Class Initialized
INFO - 2025-06-03 14:32:48 --> Output Class Initialized
INFO - 2025-06-03 14:32:48 --> Security Class Initialized
DEBUG - 2025-06-03 14:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 14:32:48 --> Input Class Initialized
INFO - 2025-06-03 14:32:48 --> Language Class Initialized
INFO - 2025-06-03 14:32:48 --> Loader Class Initialized
INFO - 2025-06-03 14:32:48 --> Helper loaded: url_helper
INFO - 2025-06-03 14:32:48 --> Helper loaded: form_helper
INFO - 2025-06-03 14:32:48 --> Database Driver Class Initialized
DEBUG - 2025-06-03 14:32:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 14:32:48 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 14:32:48 --> Controller Class Initialized
INFO - 2025-06-03 14:32:48 --> Model "Progress_model" initialized
INFO - 2025-06-03 14:32:48 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 14:32:48 --> Model "User_model" initialized
INFO - 2025-06-03 14:32:48 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 14:32:48 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 14:32:48 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/progress_view.php
INFO - 2025-06-03 14:32:48 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 14:32:48 --> Final output sent to browser
DEBUG - 2025-06-03 14:32:48 --> Total execution time: 0.0797
INFO - 2025-06-03 14:32:48 --> Config Class Initialized
INFO - 2025-06-03 14:32:48 --> Hooks Class Initialized
DEBUG - 2025-06-03 14:32:48 --> UTF-8 Support Enabled
INFO - 2025-06-03 14:32:48 --> Utf8 Class Initialized
INFO - 2025-06-03 14:32:48 --> URI Class Initialized
INFO - 2025-06-03 14:32:48 --> Router Class Initialized
INFO - 2025-06-03 14:32:48 --> Output Class Initialized
INFO - 2025-06-03 14:32:48 --> Security Class Initialized
DEBUG - 2025-06-03 14:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 14:32:48 --> Input Class Initialized
INFO - 2025-06-03 14:32:48 --> Language Class Initialized
INFO - 2025-06-03 14:32:48 --> Loader Class Initialized
INFO - 2025-06-03 14:32:48 --> Helper loaded: url_helper
INFO - 2025-06-03 14:32:48 --> Helper loaded: form_helper
INFO - 2025-06-03 14:32:49 --> Database Driver Class Initialized
DEBUG - 2025-06-03 14:32:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 14:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 14:32:49 --> Controller Class Initialized
INFO - 2025-06-03 14:32:49 --> Model "Progress_model" initialized
INFO - 2025-06-03 14:32:49 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 14:32:49 --> Model "User_model" initialized
INFO - 2025-06-03 14:32:49 --> Final output sent to browser
DEBUG - 2025-06-03 14:32:49 --> Total execution time: 0.5353
INFO - 2025-06-03 14:32:49 --> Config Class Initialized
INFO - 2025-06-03 14:32:49 --> Hooks Class Initialized
DEBUG - 2025-06-03 14:32:49 --> UTF-8 Support Enabled
INFO - 2025-06-03 14:32:49 --> Utf8 Class Initialized
INFO - 2025-06-03 14:32:49 --> URI Class Initialized
INFO - 2025-06-03 14:32:49 --> Router Class Initialized
INFO - 2025-06-03 14:32:49 --> Output Class Initialized
INFO - 2025-06-03 14:32:49 --> Security Class Initialized
DEBUG - 2025-06-03 14:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 14:32:49 --> Input Class Initialized
INFO - 2025-06-03 14:32:49 --> Language Class Initialized
INFO - 2025-06-03 14:32:49 --> Loader Class Initialized
INFO - 2025-06-03 14:32:49 --> Helper loaded: url_helper
INFO - 2025-06-03 14:32:49 --> Helper loaded: form_helper
INFO - 2025-06-03 14:32:49 --> Database Driver Class Initialized
DEBUG - 2025-06-03 14:32:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 14:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 14:32:49 --> Controller Class Initialized
INFO - 2025-06-03 14:32:49 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 14:32:49 --> Model "User_model" initialized
INFO - 2025-06-03 14:32:49 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 14:32:49 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 14:32:49 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-06-03 14:32:49 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 14:32:49 --> Final output sent to browser
DEBUG - 2025-06-03 14:32:49 --> Total execution time: 0.0804
INFO - 2025-06-03 14:32:58 --> Config Class Initialized
INFO - 2025-06-03 14:32:58 --> Hooks Class Initialized
DEBUG - 2025-06-03 14:32:58 --> UTF-8 Support Enabled
INFO - 2025-06-03 14:32:58 --> Utf8 Class Initialized
INFO - 2025-06-03 14:32:58 --> URI Class Initialized
INFO - 2025-06-03 14:32:58 --> Router Class Initialized
INFO - 2025-06-03 14:32:58 --> Output Class Initialized
INFO - 2025-06-03 14:32:58 --> Security Class Initialized
DEBUG - 2025-06-03 14:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 14:32:58 --> Input Class Initialized
INFO - 2025-06-03 14:32:58 --> Language Class Initialized
INFO - 2025-06-03 14:32:58 --> Loader Class Initialized
INFO - 2025-06-03 14:32:58 --> Helper loaded: url_helper
INFO - 2025-06-03 14:32:58 --> Helper loaded: form_helper
INFO - 2025-06-03 14:32:58 --> Database Driver Class Initialized
DEBUG - 2025-06-03 14:32:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 14:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 14:32:58 --> Controller Class Initialized
INFO - 2025-06-03 14:32:58 --> Model "User_model" initialized
INFO - 2025-06-03 14:32:58 --> Form Validation Class Initialized
INFO - 2025-06-03 14:32:58 --> Config Class Initialized
INFO - 2025-06-03 14:32:58 --> Hooks Class Initialized
DEBUG - 2025-06-03 14:32:58 --> UTF-8 Support Enabled
INFO - 2025-06-03 14:32:58 --> Utf8 Class Initialized
INFO - 2025-06-03 14:32:58 --> URI Class Initialized
INFO - 2025-06-03 14:32:58 --> Router Class Initialized
INFO - 2025-06-03 14:32:58 --> Output Class Initialized
INFO - 2025-06-03 14:32:58 --> Security Class Initialized
DEBUG - 2025-06-03 14:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 14:32:58 --> Input Class Initialized
INFO - 2025-06-03 14:32:58 --> Language Class Initialized
INFO - 2025-06-03 14:32:58 --> Loader Class Initialized
INFO - 2025-06-03 14:32:58 --> Helper loaded: url_helper
INFO - 2025-06-03 14:32:58 --> Helper loaded: form_helper
INFO - 2025-06-03 14:32:58 --> Database Driver Class Initialized
DEBUG - 2025-06-03 14:32:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 14:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 14:32:58 --> Controller Class Initialized
INFO - 2025-06-03 14:32:58 --> Model "User_model" initialized
INFO - 2025-06-03 14:32:58 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-06-03 14:32:58 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/home.php
INFO - 2025-06-03 14:32:58 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-06-03 14:32:58 --> Final output sent to browser
DEBUG - 2025-06-03 14:32:58 --> Total execution time: 0.2878
INFO - 2025-06-03 14:33:04 --> Config Class Initialized
INFO - 2025-06-03 14:33:04 --> Hooks Class Initialized
DEBUG - 2025-06-03 14:33:04 --> UTF-8 Support Enabled
INFO - 2025-06-03 14:33:04 --> Utf8 Class Initialized
INFO - 2025-06-03 14:33:04 --> URI Class Initialized
INFO - 2025-06-03 14:33:04 --> Router Class Initialized
INFO - 2025-06-03 14:33:04 --> Output Class Initialized
INFO - 2025-06-03 14:33:04 --> Security Class Initialized
DEBUG - 2025-06-03 14:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 14:33:04 --> Input Class Initialized
INFO - 2025-06-03 14:33:04 --> Language Class Initialized
INFO - 2025-06-03 14:33:04 --> Loader Class Initialized
INFO - 2025-06-03 14:33:04 --> Helper loaded: url_helper
INFO - 2025-06-03 14:33:04 --> Helper loaded: form_helper
INFO - 2025-06-03 14:33:04 --> Database Driver Class Initialized
DEBUG - 2025-06-03 14:33:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 14:33:04 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 14:33:04 --> Controller Class Initialized
INFO - 2025-06-03 14:33:04 --> Model "User_model" initialized
INFO - 2025-06-03 14:33:04 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-06-03 14:33:04 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/artikel.php
INFO - 2025-06-03 14:33:04 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-06-03 14:33:04 --> Final output sent to browser
DEBUG - 2025-06-03 14:33:04 --> Total execution time: 0.1106
INFO - 2025-06-03 16:40:55 --> Config Class Initialized
INFO - 2025-06-03 16:40:55 --> Hooks Class Initialized
DEBUG - 2025-06-03 16:40:56 --> UTF-8 Support Enabled
INFO - 2025-06-03 16:40:56 --> Utf8 Class Initialized
INFO - 2025-06-03 16:40:56 --> URI Class Initialized
DEBUG - 2025-06-03 16:40:56 --> No URI present. Default controller set.
INFO - 2025-06-03 16:40:56 --> Router Class Initialized
INFO - 2025-06-03 16:40:56 --> Output Class Initialized
INFO - 2025-06-03 16:40:56 --> Security Class Initialized
DEBUG - 2025-06-03 16:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 16:40:56 --> Input Class Initialized
INFO - 2025-06-03 16:40:56 --> Language Class Initialized
INFO - 2025-06-03 16:40:56 --> Loader Class Initialized
INFO - 2025-06-03 16:40:56 --> Helper loaded: url_helper
INFO - 2025-06-03 16:40:56 --> Helper loaded: form_helper
INFO - 2025-06-03 16:40:57 --> Database Driver Class Initialized
DEBUG - 2025-06-03 16:40:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 16:40:57 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 16:40:57 --> Controller Class Initialized
INFO - 2025-06-03 16:40:57 --> Model "User_model" initialized
INFO - 2025-06-03 16:40:57 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-06-03 16:40:57 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/home.php
INFO - 2025-06-03 16:40:57 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-06-03 16:40:57 --> Final output sent to browser
DEBUG - 2025-06-03 16:40:57 --> Total execution time: 1.7591
INFO - 2025-06-03 16:40:59 --> Config Class Initialized
INFO - 2025-06-03 16:40:59 --> Hooks Class Initialized
DEBUG - 2025-06-03 16:40:59 --> UTF-8 Support Enabled
INFO - 2025-06-03 16:40:59 --> Utf8 Class Initialized
INFO - 2025-06-03 16:40:59 --> URI Class Initialized
INFO - 2025-06-03 16:40:59 --> Router Class Initialized
INFO - 2025-06-03 16:40:59 --> Output Class Initialized
INFO - 2025-06-03 16:40:59 --> Security Class Initialized
DEBUG - 2025-06-03 16:40:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 16:40:59 --> Input Class Initialized
INFO - 2025-06-03 16:40:59 --> Language Class Initialized
INFO - 2025-06-03 16:40:59 --> Loader Class Initialized
INFO - 2025-06-03 16:40:59 --> Helper loaded: url_helper
INFO - 2025-06-03 16:40:59 --> Helper loaded: form_helper
INFO - 2025-06-03 16:40:59 --> Database Driver Class Initialized
DEBUG - 2025-06-03 16:40:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 16:40:59 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 16:40:59 --> Controller Class Initialized
INFO - 2025-06-03 16:40:59 --> Model "User_model" initialized
INFO - 2025-06-03 16:40:59 --> Form Validation Class Initialized
INFO - 2025-06-03 16:40:59 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\auth/login.php
INFO - 2025-06-03 16:40:59 --> Final output sent to browser
DEBUG - 2025-06-03 16:40:59 --> Total execution time: 0.2055
INFO - 2025-06-03 16:41:05 --> Config Class Initialized
INFO - 2025-06-03 16:41:05 --> Hooks Class Initialized
DEBUG - 2025-06-03 16:41:05 --> UTF-8 Support Enabled
INFO - 2025-06-03 16:41:05 --> Utf8 Class Initialized
INFO - 2025-06-03 16:41:05 --> URI Class Initialized
INFO - 2025-06-03 16:41:05 --> Router Class Initialized
INFO - 2025-06-03 16:41:05 --> Output Class Initialized
INFO - 2025-06-03 16:41:05 --> Security Class Initialized
DEBUG - 2025-06-03 16:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 16:41:05 --> Input Class Initialized
INFO - 2025-06-03 16:41:05 --> Language Class Initialized
INFO - 2025-06-03 16:41:05 --> Loader Class Initialized
INFO - 2025-06-03 16:41:05 --> Helper loaded: url_helper
INFO - 2025-06-03 16:41:05 --> Helper loaded: form_helper
INFO - 2025-06-03 16:41:05 --> Database Driver Class Initialized
DEBUG - 2025-06-03 16:41:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 16:41:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 16:41:05 --> Controller Class Initialized
INFO - 2025-06-03 16:41:05 --> Model "User_model" initialized
INFO - 2025-06-03 16:41:05 --> Form Validation Class Initialized
INFO - 2025-06-03 16:41:05 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-06-03 16:41:05 --> Config Class Initialized
INFO - 2025-06-03 16:41:05 --> Hooks Class Initialized
DEBUG - 2025-06-03 16:41:05 --> UTF-8 Support Enabled
INFO - 2025-06-03 16:41:05 --> Utf8 Class Initialized
INFO - 2025-06-03 16:41:05 --> URI Class Initialized
INFO - 2025-06-03 16:41:05 --> Router Class Initialized
INFO - 2025-06-03 16:41:05 --> Output Class Initialized
INFO - 2025-06-03 16:41:05 --> Security Class Initialized
DEBUG - 2025-06-03 16:41:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 16:41:05 --> Input Class Initialized
INFO - 2025-06-03 16:41:05 --> Language Class Initialized
INFO - 2025-06-03 16:41:05 --> Loader Class Initialized
INFO - 2025-06-03 16:41:05 --> Helper loaded: url_helper
INFO - 2025-06-03 16:41:05 --> Helper loaded: form_helper
INFO - 2025-06-03 16:41:05 --> Database Driver Class Initialized
DEBUG - 2025-06-03 16:41:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 16:41:05 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 16:41:05 --> Controller Class Initialized
INFO - 2025-06-03 16:41:05 --> Model "User_model" initialized
INFO - 2025-06-03 16:41:05 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-06-03 16:41:05 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/home.php
INFO - 2025-06-03 16:41:05 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-06-03 16:41:05 --> Final output sent to browser
DEBUG - 2025-06-03 16:41:05 --> Total execution time: 0.0999
INFO - 2025-06-03 16:41:08 --> Config Class Initialized
INFO - 2025-06-03 16:41:08 --> Hooks Class Initialized
DEBUG - 2025-06-03 16:41:08 --> UTF-8 Support Enabled
INFO - 2025-06-03 16:41:08 --> Utf8 Class Initialized
INFO - 2025-06-03 16:41:08 --> URI Class Initialized
INFO - 2025-06-03 16:41:08 --> Router Class Initialized
INFO - 2025-06-03 16:41:08 --> Output Class Initialized
INFO - 2025-06-03 16:41:08 --> Security Class Initialized
DEBUG - 2025-06-03 16:41:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 16:41:08 --> Input Class Initialized
INFO - 2025-06-03 16:41:08 --> Language Class Initialized
INFO - 2025-06-03 16:41:08 --> Loader Class Initialized
INFO - 2025-06-03 16:41:08 --> Helper loaded: url_helper
INFO - 2025-06-03 16:41:08 --> Helper loaded: form_helper
INFO - 2025-06-03 16:41:08 --> Database Driver Class Initialized
DEBUG - 2025-06-03 16:41:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 16:41:08 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 16:41:08 --> Controller Class Initialized
INFO - 2025-06-03 16:41:08 --> Model "User_model" initialized
INFO - 2025-06-03 16:41:08 --> Model "Progress_model" initialized
INFO - 2025-06-03 16:41:08 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 16:41:08 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 16:41:08 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/dashboard.php
INFO - 2025-06-03 16:41:08 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 16:41:09 --> Final output sent to browser
DEBUG - 2025-06-03 16:41:09 --> Total execution time: 0.2285
INFO - 2025-06-03 16:41:12 --> Config Class Initialized
INFO - 2025-06-03 16:41:12 --> Hooks Class Initialized
DEBUG - 2025-06-03 16:41:12 --> UTF-8 Support Enabled
INFO - 2025-06-03 16:41:12 --> Utf8 Class Initialized
INFO - 2025-06-03 16:41:12 --> URI Class Initialized
INFO - 2025-06-03 16:41:12 --> Router Class Initialized
INFO - 2025-06-03 16:41:12 --> Output Class Initialized
INFO - 2025-06-03 16:41:12 --> Security Class Initialized
DEBUG - 2025-06-03 16:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 16:41:12 --> Input Class Initialized
INFO - 2025-06-03 16:41:12 --> Language Class Initialized
INFO - 2025-06-03 16:41:12 --> Loader Class Initialized
INFO - 2025-06-03 16:41:12 --> Helper loaded: url_helper
INFO - 2025-06-03 16:41:12 --> Helper loaded: form_helper
INFO - 2025-06-03 16:41:12 --> Database Driver Class Initialized
DEBUG - 2025-06-03 16:41:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 16:41:12 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 16:41:12 --> Controller Class Initialized
INFO - 2025-06-03 16:41:12 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 16:41:12 --> Model "User_model" initialized
INFO - 2025-06-03 16:41:12 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 16:41:12 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 16:41:12 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-06-03 16:41:12 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 16:41:12 --> Final output sent to browser
DEBUG - 2025-06-03 16:41:12 --> Total execution time: 0.1293
INFO - 2025-06-03 16:41:14 --> Config Class Initialized
INFO - 2025-06-03 16:41:14 --> Hooks Class Initialized
DEBUG - 2025-06-03 16:41:14 --> UTF-8 Support Enabled
INFO - 2025-06-03 16:41:14 --> Utf8 Class Initialized
INFO - 2025-06-03 16:41:14 --> URI Class Initialized
INFO - 2025-06-03 16:41:14 --> Router Class Initialized
INFO - 2025-06-03 16:41:14 --> Output Class Initialized
INFO - 2025-06-03 16:41:14 --> Security Class Initialized
DEBUG - 2025-06-03 16:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 16:41:14 --> Input Class Initialized
INFO - 2025-06-03 16:41:14 --> Language Class Initialized
INFO - 2025-06-03 16:41:14 --> Loader Class Initialized
INFO - 2025-06-03 16:41:14 --> Helper loaded: url_helper
INFO - 2025-06-03 16:41:14 --> Helper loaded: form_helper
INFO - 2025-06-03 16:41:14 --> Database Driver Class Initialized
DEBUG - 2025-06-03 16:41:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 16:41:14 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 16:41:14 --> Controller Class Initialized
INFO - 2025-06-03 16:41:14 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 16:41:14 --> Model "User_model" initialized
INFO - 2025-06-03 16:41:14 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 16:41:14 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 16:41:14 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/level.php
INFO - 2025-06-03 16:41:14 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 16:41:14 --> Final output sent to browser
DEBUG - 2025-06-03 16:41:14 --> Total execution time: 0.1128
INFO - 2025-06-03 16:41:16 --> Config Class Initialized
INFO - 2025-06-03 16:41:16 --> Hooks Class Initialized
DEBUG - 2025-06-03 16:41:16 --> UTF-8 Support Enabled
INFO - 2025-06-03 16:41:16 --> Utf8 Class Initialized
INFO - 2025-06-03 16:41:16 --> URI Class Initialized
INFO - 2025-06-03 16:41:16 --> Router Class Initialized
INFO - 2025-06-03 16:41:16 --> Output Class Initialized
INFO - 2025-06-03 16:41:16 --> Security Class Initialized
DEBUG - 2025-06-03 16:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 16:41:16 --> Input Class Initialized
INFO - 2025-06-03 16:41:16 --> Language Class Initialized
INFO - 2025-06-03 16:41:16 --> Loader Class Initialized
INFO - 2025-06-03 16:41:16 --> Helper loaded: url_helper
INFO - 2025-06-03 16:41:16 --> Helper loaded: form_helper
INFO - 2025-06-03 16:41:16 --> Database Driver Class Initialized
DEBUG - 2025-06-03 16:41:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 16:41:16 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 16:41:16 --> Controller Class Initialized
INFO - 2025-06-03 16:41:16 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 16:41:16 --> Model "User_model" initialized
INFO - 2025-06-03 16:41:16 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 16:41:16 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 16:41:16 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-06-03 16:41:16 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 16:41:16 --> Final output sent to browser
DEBUG - 2025-06-03 16:41:16 --> Total execution time: 0.0974
INFO - 2025-06-03 16:41:19 --> Config Class Initialized
INFO - 2025-06-03 16:41:19 --> Hooks Class Initialized
DEBUG - 2025-06-03 16:41:19 --> UTF-8 Support Enabled
INFO - 2025-06-03 16:41:19 --> Utf8 Class Initialized
INFO - 2025-06-03 16:41:19 --> URI Class Initialized
INFO - 2025-06-03 16:41:19 --> Router Class Initialized
INFO - 2025-06-03 16:41:19 --> Output Class Initialized
INFO - 2025-06-03 16:41:19 --> Security Class Initialized
DEBUG - 2025-06-03 16:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 16:41:19 --> Input Class Initialized
INFO - 2025-06-03 16:41:19 --> Language Class Initialized
INFO - 2025-06-03 16:41:19 --> Loader Class Initialized
INFO - 2025-06-03 16:41:19 --> Helper loaded: url_helper
INFO - 2025-06-03 16:41:19 --> Helper loaded: form_helper
INFO - 2025-06-03 16:41:19 --> Database Driver Class Initialized
DEBUG - 2025-06-03 16:41:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 16:41:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 16:41:19 --> Controller Class Initialized
INFO - 2025-06-03 16:41:19 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 16:41:19 --> Model "User_model" initialized
INFO - 2025-06-03 16:41:19 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 16:41:19 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 16:41:19 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/level.php
INFO - 2025-06-03 16:41:19 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 16:41:19 --> Final output sent to browser
DEBUG - 2025-06-03 16:41:19 --> Total execution time: 0.1171
INFO - 2025-06-03 16:41:26 --> Config Class Initialized
INFO - 2025-06-03 16:41:26 --> Hooks Class Initialized
DEBUG - 2025-06-03 16:41:26 --> UTF-8 Support Enabled
INFO - 2025-06-03 16:41:26 --> Utf8 Class Initialized
INFO - 2025-06-03 16:41:26 --> URI Class Initialized
INFO - 2025-06-03 16:41:26 --> Router Class Initialized
INFO - 2025-06-03 16:41:26 --> Output Class Initialized
INFO - 2025-06-03 16:41:26 --> Security Class Initialized
DEBUG - 2025-06-03 16:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 16:41:26 --> Input Class Initialized
INFO - 2025-06-03 16:41:26 --> Language Class Initialized
INFO - 2025-06-03 16:41:26 --> Loader Class Initialized
INFO - 2025-06-03 16:41:26 --> Helper loaded: url_helper
INFO - 2025-06-03 16:41:26 --> Helper loaded: form_helper
INFO - 2025-06-03 16:41:26 --> Database Driver Class Initialized
DEBUG - 2025-06-03 16:41:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 16:41:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 16:41:26 --> Controller Class Initialized
INFO - 2025-06-03 16:41:26 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 16:41:26 --> Model "User_model" initialized
INFO - 2025-06-03 16:41:26 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 16:41:26 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 16:41:26 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/level.php
INFO - 2025-06-03 16:41:26 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 16:41:26 --> Final output sent to browser
DEBUG - 2025-06-03 16:41:26 --> Total execution time: 0.0949
INFO - 2025-06-03 16:41:30 --> Config Class Initialized
INFO - 2025-06-03 16:41:30 --> Hooks Class Initialized
DEBUG - 2025-06-03 16:41:30 --> UTF-8 Support Enabled
INFO - 2025-06-03 16:41:30 --> Utf8 Class Initialized
INFO - 2025-06-03 16:41:30 --> URI Class Initialized
INFO - 2025-06-03 16:41:30 --> Router Class Initialized
INFO - 2025-06-03 16:41:30 --> Output Class Initialized
INFO - 2025-06-03 16:41:30 --> Security Class Initialized
DEBUG - 2025-06-03 16:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 16:41:30 --> Input Class Initialized
INFO - 2025-06-03 16:41:30 --> Language Class Initialized
INFO - 2025-06-03 16:41:30 --> Loader Class Initialized
INFO - 2025-06-03 16:41:30 --> Helper loaded: url_helper
INFO - 2025-06-03 16:41:30 --> Helper loaded: form_helper
INFO - 2025-06-03 16:41:30 --> Database Driver Class Initialized
DEBUG - 2025-06-03 16:41:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 16:41:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 16:41:30 --> Controller Class Initialized
INFO - 2025-06-03 16:41:30 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 16:41:30 --> Model "User_model" initialized
INFO - 2025-06-03 16:41:30 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 16:41:30 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
ERROR - 2025-06-03 16:41:30 --> Severity: Warning --> Undefined variable $exercise C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard\olahraga\menu.php 46
ERROR - 2025-06-03 16:41:30 --> Severity: Warning --> Attempt to read property "id" on null C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard\olahraga\menu.php 46
INFO - 2025-06-03 16:41:30 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-06-03 16:41:30 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 16:41:30 --> Final output sent to browser
DEBUG - 2025-06-03 16:41:30 --> Total execution time: 0.1044
INFO - 2025-06-03 16:41:34 --> Config Class Initialized
INFO - 2025-06-03 16:41:34 --> Hooks Class Initialized
DEBUG - 2025-06-03 16:41:34 --> UTF-8 Support Enabled
INFO - 2025-06-03 16:41:34 --> Utf8 Class Initialized
INFO - 2025-06-03 16:42:20 --> Config Class Initialized
INFO - 2025-06-03 16:42:20 --> Hooks Class Initialized
DEBUG - 2025-06-03 16:42:20 --> UTF-8 Support Enabled
INFO - 2025-06-03 16:42:20 --> Utf8 Class Initialized
INFO - 2025-06-03 16:42:20 --> URI Class Initialized
INFO - 2025-06-03 16:42:20 --> Router Class Initialized
INFO - 2025-06-03 16:42:20 --> Output Class Initialized
INFO - 2025-06-03 16:42:20 --> Security Class Initialized
DEBUG - 2025-06-03 16:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 16:42:20 --> Input Class Initialized
INFO - 2025-06-03 16:42:20 --> Language Class Initialized
INFO - 2025-06-03 16:42:20 --> Loader Class Initialized
INFO - 2025-06-03 16:42:20 --> Helper loaded: url_helper
INFO - 2025-06-03 16:42:20 --> Helper loaded: form_helper
INFO - 2025-06-03 16:42:20 --> Database Driver Class Initialized
DEBUG - 2025-06-03 16:42:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 16:42:20 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 16:42:20 --> Controller Class Initialized
INFO - 2025-06-03 16:42:20 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 16:42:20 --> Model "User_model" initialized
INFO - 2025-06-03 16:42:20 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 16:42:20 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 16:42:20 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-06-03 16:42:20 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 16:42:20 --> Final output sent to browser
DEBUG - 2025-06-03 16:42:20 --> Total execution time: 0.0910
INFO - 2025-06-03 16:42:22 --> Config Class Initialized
INFO - 2025-06-03 16:42:22 --> Hooks Class Initialized
DEBUG - 2025-06-03 16:42:22 --> UTF-8 Support Enabled
INFO - 2025-06-03 16:42:22 --> Utf8 Class Initialized
INFO - 2025-06-03 16:42:22 --> URI Class Initialized
INFO - 2025-06-03 16:42:22 --> Router Class Initialized
INFO - 2025-06-03 16:42:22 --> Output Class Initialized
INFO - 2025-06-03 16:42:22 --> Security Class Initialized
DEBUG - 2025-06-03 16:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 16:42:22 --> Input Class Initialized
INFO - 2025-06-03 16:42:22 --> Language Class Initialized
INFO - 2025-06-03 16:42:22 --> Loader Class Initialized
INFO - 2025-06-03 16:42:22 --> Helper loaded: url_helper
INFO - 2025-06-03 16:42:22 --> Helper loaded: form_helper
INFO - 2025-06-03 16:42:22 --> Database Driver Class Initialized
DEBUG - 2025-06-03 16:42:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 16:42:22 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 16:42:22 --> Controller Class Initialized
INFO - 2025-06-03 16:42:22 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 16:42:22 --> Model "User_model" initialized
INFO - 2025-06-03 16:42:22 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 16:42:22 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 16:42:22 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/level.php
INFO - 2025-06-03 16:42:22 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 16:42:22 --> Final output sent to browser
DEBUG - 2025-06-03 16:42:22 --> Total execution time: 0.0917
INFO - 2025-06-03 16:42:23 --> Config Class Initialized
INFO - 2025-06-03 16:42:23 --> Hooks Class Initialized
DEBUG - 2025-06-03 16:42:23 --> UTF-8 Support Enabled
INFO - 2025-06-03 16:42:23 --> Utf8 Class Initialized
INFO - 2025-06-03 16:42:23 --> URI Class Initialized
INFO - 2025-06-03 16:42:23 --> Router Class Initialized
INFO - 2025-06-03 16:42:23 --> Output Class Initialized
INFO - 2025-06-03 16:42:23 --> Security Class Initialized
DEBUG - 2025-06-03 16:42:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 16:42:23 --> Input Class Initialized
INFO - 2025-06-03 16:42:23 --> Language Class Initialized
INFO - 2025-06-03 16:42:23 --> Loader Class Initialized
INFO - 2025-06-03 16:42:23 --> Helper loaded: url_helper
INFO - 2025-06-03 16:42:23 --> Helper loaded: form_helper
INFO - 2025-06-03 16:42:23 --> Database Driver Class Initialized
DEBUG - 2025-06-03 16:42:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 16:42:23 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 16:42:23 --> Controller Class Initialized
INFO - 2025-06-03 16:42:23 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 16:42:23 --> Model "User_model" initialized
INFO - 2025-06-03 16:42:23 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 16:42:23 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 16:42:23 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-06-03 16:42:23 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 16:42:23 --> Final output sent to browser
DEBUG - 2025-06-03 16:42:23 --> Total execution time: 0.1533
INFO - 2025-06-03 16:42:26 --> Config Class Initialized
INFO - 2025-06-03 16:42:26 --> Hooks Class Initialized
DEBUG - 2025-06-03 16:42:26 --> UTF-8 Support Enabled
INFO - 2025-06-03 16:42:26 --> Utf8 Class Initialized
INFO - 2025-06-03 16:42:26 --> URI Class Initialized
INFO - 2025-06-03 16:42:26 --> Router Class Initialized
INFO - 2025-06-03 16:42:26 --> Output Class Initialized
INFO - 2025-06-03 16:42:26 --> Security Class Initialized
DEBUG - 2025-06-03 16:42:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 16:42:26 --> Input Class Initialized
INFO - 2025-06-03 16:42:26 --> Language Class Initialized
INFO - 2025-06-03 16:42:26 --> Loader Class Initialized
INFO - 2025-06-03 16:42:26 --> Helper loaded: url_helper
INFO - 2025-06-03 16:42:26 --> Helper loaded: form_helper
INFO - 2025-06-03 16:42:26 --> Database Driver Class Initialized
DEBUG - 2025-06-03 16:42:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 16:42:26 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 16:42:26 --> Controller Class Initialized
INFO - 2025-06-03 16:42:26 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 16:42:26 --> Model "User_model" initialized
INFO - 2025-06-03 16:42:26 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 16:42:26 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 16:42:26 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/level.php
INFO - 2025-06-03 16:42:26 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 16:42:26 --> Final output sent to browser
DEBUG - 2025-06-03 16:42:26 --> Total execution time: 0.1049
INFO - 2025-06-03 16:42:27 --> Config Class Initialized
INFO - 2025-06-03 16:42:27 --> Hooks Class Initialized
DEBUG - 2025-06-03 16:42:27 --> UTF-8 Support Enabled
INFO - 2025-06-03 16:42:27 --> Utf8 Class Initialized
INFO - 2025-06-03 16:42:27 --> URI Class Initialized
INFO - 2025-06-03 16:42:27 --> Router Class Initialized
INFO - 2025-06-03 16:42:27 --> Output Class Initialized
INFO - 2025-06-03 16:42:27 --> Security Class Initialized
DEBUG - 2025-06-03 16:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 16:42:27 --> Input Class Initialized
INFO - 2025-06-03 16:42:27 --> Language Class Initialized
INFO - 2025-06-03 16:42:27 --> Loader Class Initialized
INFO - 2025-06-03 16:42:27 --> Helper loaded: url_helper
INFO - 2025-06-03 16:42:27 --> Helper loaded: form_helper
INFO - 2025-06-03 16:42:27 --> Database Driver Class Initialized
DEBUG - 2025-06-03 16:42:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 16:42:27 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 16:42:27 --> Controller Class Initialized
INFO - 2025-06-03 16:42:27 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 16:42:27 --> Model "User_model" initialized
INFO - 2025-06-03 16:42:27 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 16:42:27 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 16:42:27 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-06-03 16:42:27 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 16:42:27 --> Final output sent to browser
DEBUG - 2025-06-03 16:42:27 --> Total execution time: 0.1193
INFO - 2025-06-03 16:42:29 --> Config Class Initialized
INFO - 2025-06-03 16:42:29 --> Hooks Class Initialized
DEBUG - 2025-06-03 16:42:29 --> UTF-8 Support Enabled
INFO - 2025-06-03 16:42:29 --> Utf8 Class Initialized
INFO - 2025-06-03 16:42:29 --> URI Class Initialized
INFO - 2025-06-03 16:42:29 --> Router Class Initialized
INFO - 2025-06-03 16:42:29 --> Output Class Initialized
INFO - 2025-06-03 16:42:29 --> Security Class Initialized
DEBUG - 2025-06-03 16:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 16:42:29 --> Input Class Initialized
INFO - 2025-06-03 16:42:29 --> Language Class Initialized
INFO - 2025-06-03 16:42:29 --> Loader Class Initialized
INFO - 2025-06-03 16:42:29 --> Helper loaded: url_helper
INFO - 2025-06-03 16:42:29 --> Helper loaded: form_helper
INFO - 2025-06-03 16:42:29 --> Database Driver Class Initialized
DEBUG - 2025-06-03 16:42:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 16:42:29 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 16:42:29 --> Controller Class Initialized
INFO - 2025-06-03 16:42:29 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 16:42:29 --> Model "User_model" initialized
INFO - 2025-06-03 16:42:29 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 16:42:29 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 16:42:29 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/level.php
INFO - 2025-06-03 16:42:29 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 16:42:29 --> Final output sent to browser
DEBUG - 2025-06-03 16:42:29 --> Total execution time: 0.0913
INFO - 2025-06-03 16:42:54 --> Config Class Initialized
INFO - 2025-06-03 16:42:54 --> Hooks Class Initialized
DEBUG - 2025-06-03 16:42:54 --> UTF-8 Support Enabled
INFO - 2025-06-03 16:42:54 --> Utf8 Class Initialized
INFO - 2025-06-03 16:42:54 --> URI Class Initialized
INFO - 2025-06-03 16:42:54 --> Router Class Initialized
INFO - 2025-06-03 16:42:54 --> Output Class Initialized
INFO - 2025-06-03 16:42:54 --> Security Class Initialized
DEBUG - 2025-06-03 16:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 16:42:54 --> Input Class Initialized
INFO - 2025-06-03 16:42:54 --> Language Class Initialized
INFO - 2025-06-03 16:42:54 --> Loader Class Initialized
INFO - 2025-06-03 16:42:54 --> Helper loaded: url_helper
INFO - 2025-06-03 16:42:54 --> Helper loaded: form_helper
INFO - 2025-06-03 16:42:54 --> Database Driver Class Initialized
DEBUG - 2025-06-03 16:42:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 16:42:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 16:42:54 --> Controller Class Initialized
INFO - 2025-06-03 16:42:54 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 16:42:54 --> Model "User_model" initialized
INFO - 2025-06-03 16:42:54 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 16:42:54 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 16:42:54 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-06-03 16:42:54 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 16:42:54 --> Final output sent to browser
DEBUG - 2025-06-03 16:42:54 --> Total execution time: 0.0858
INFO - 2025-06-03 16:42:58 --> Config Class Initialized
INFO - 2025-06-03 16:42:58 --> Hooks Class Initialized
DEBUG - 2025-06-03 16:42:58 --> UTF-8 Support Enabled
INFO - 2025-06-03 16:42:58 --> Utf8 Class Initialized
INFO - 2025-06-03 16:42:58 --> URI Class Initialized
INFO - 2025-06-03 16:42:58 --> Router Class Initialized
INFO - 2025-06-03 16:42:58 --> Output Class Initialized
INFO - 2025-06-03 16:42:58 --> Security Class Initialized
DEBUG - 2025-06-03 16:42:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 16:42:58 --> Input Class Initialized
INFO - 2025-06-03 16:42:58 --> Language Class Initialized
INFO - 2025-06-03 16:42:58 --> Loader Class Initialized
INFO - 2025-06-03 16:42:58 --> Helper loaded: url_helper
INFO - 2025-06-03 16:42:58 --> Helper loaded: form_helper
INFO - 2025-06-03 16:42:58 --> Database Driver Class Initialized
DEBUG - 2025-06-03 16:42:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 16:42:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 16:42:58 --> Controller Class Initialized
INFO - 2025-06-03 16:42:58 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 16:42:58 --> Model "User_model" initialized
INFO - 2025-06-03 16:42:58 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 16:42:58 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 16:42:58 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/start.php
INFO - 2025-06-03 16:42:58 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 16:42:58 --> Final output sent to browser
DEBUG - 2025-06-03 16:42:58 --> Total execution time: 0.1150
INFO - 2025-06-03 16:45:09 --> Config Class Initialized
INFO - 2025-06-03 16:45:09 --> Hooks Class Initialized
DEBUG - 2025-06-03 16:45:09 --> UTF-8 Support Enabled
INFO - 2025-06-03 16:45:09 --> Utf8 Class Initialized
INFO - 2025-06-03 16:45:09 --> URI Class Initialized
INFO - 2025-06-03 16:45:09 --> Router Class Initialized
INFO - 2025-06-03 16:45:09 --> Output Class Initialized
INFO - 2025-06-03 16:45:09 --> Security Class Initialized
DEBUG - 2025-06-03 16:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 16:45:09 --> Input Class Initialized
INFO - 2025-06-03 16:45:09 --> Language Class Initialized
INFO - 2025-06-03 16:45:09 --> Loader Class Initialized
INFO - 2025-06-03 16:45:09 --> Helper loaded: url_helper
INFO - 2025-06-03 16:45:09 --> Helper loaded: form_helper
INFO - 2025-06-03 16:45:09 --> Database Driver Class Initialized
DEBUG - 2025-06-03 16:45:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 16:45:09 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 16:45:09 --> Controller Class Initialized
INFO - 2025-06-03 16:45:09 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 16:45:09 --> Model "User_model" initialized
INFO - 2025-06-03 16:45:09 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 16:45:09 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 16:45:09 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/start.php
INFO - 2025-06-03 16:45:09 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 16:45:09 --> Final output sent to browser
DEBUG - 2025-06-03 16:45:09 --> Total execution time: 0.2157
INFO - 2025-06-03 16:45:17 --> Config Class Initialized
INFO - 2025-06-03 16:45:17 --> Hooks Class Initialized
DEBUG - 2025-06-03 16:45:17 --> UTF-8 Support Enabled
INFO - 2025-06-03 16:45:17 --> Utf8 Class Initialized
INFO - 2025-06-03 16:45:17 --> URI Class Initialized
INFO - 2025-06-03 16:45:17 --> Router Class Initialized
INFO - 2025-06-03 16:45:17 --> Output Class Initialized
INFO - 2025-06-03 16:45:17 --> Security Class Initialized
DEBUG - 2025-06-03 16:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 16:45:17 --> Input Class Initialized
INFO - 2025-06-03 16:45:17 --> Language Class Initialized
INFO - 2025-06-03 16:45:17 --> Loader Class Initialized
INFO - 2025-06-03 16:45:17 --> Helper loaded: url_helper
INFO - 2025-06-03 16:45:17 --> Helper loaded: form_helper
INFO - 2025-06-03 16:45:17 --> Database Driver Class Initialized
DEBUG - 2025-06-03 16:45:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 16:45:17 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 16:45:17 --> Controller Class Initialized
INFO - 2025-06-03 16:45:17 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 16:45:17 --> Model "User_model" initialized
INFO - 2025-06-03 16:45:17 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 16:45:17 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 16:45:17 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/start.php
INFO - 2025-06-03 16:45:17 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 16:45:17 --> Final output sent to browser
DEBUG - 2025-06-03 16:45:17 --> Total execution time: 0.1356
INFO - 2025-06-03 16:45:24 --> Config Class Initialized
INFO - 2025-06-03 16:45:24 --> Hooks Class Initialized
DEBUG - 2025-06-03 16:45:24 --> UTF-8 Support Enabled
INFO - 2025-06-03 16:45:24 --> Utf8 Class Initialized
INFO - 2025-06-03 16:45:24 --> URI Class Initialized
INFO - 2025-06-03 16:45:24 --> Router Class Initialized
INFO - 2025-06-03 16:45:24 --> Output Class Initialized
INFO - 2025-06-03 16:45:24 --> Security Class Initialized
DEBUG - 2025-06-03 16:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 16:45:24 --> Input Class Initialized
INFO - 2025-06-03 16:45:24 --> Language Class Initialized
INFO - 2025-06-03 16:45:24 --> Loader Class Initialized
INFO - 2025-06-03 16:45:24 --> Helper loaded: url_helper
INFO - 2025-06-03 16:45:24 --> Helper loaded: form_helper
INFO - 2025-06-03 16:45:24 --> Database Driver Class Initialized
DEBUG - 2025-06-03 16:45:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 16:45:24 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 16:45:24 --> Controller Class Initialized
INFO - 2025-06-03 16:45:24 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 16:45:24 --> Model "User_model" initialized
INFO - 2025-06-03 16:45:24 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 16:45:24 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 16:45:24 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/start.php
INFO - 2025-06-03 16:45:24 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 16:45:24 --> Final output sent to browser
DEBUG - 2025-06-03 16:45:24 --> Total execution time: 0.1117
INFO - 2025-06-03 16:46:31 --> Config Class Initialized
INFO - 2025-06-03 16:46:31 --> Hooks Class Initialized
DEBUG - 2025-06-03 16:46:31 --> UTF-8 Support Enabled
INFO - 2025-06-03 16:46:31 --> Utf8 Class Initialized
INFO - 2025-06-03 16:46:31 --> URI Class Initialized
INFO - 2025-06-03 16:46:31 --> Router Class Initialized
INFO - 2025-06-03 16:46:31 --> Output Class Initialized
INFO - 2025-06-03 16:46:31 --> Security Class Initialized
DEBUG - 2025-06-03 16:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 16:46:31 --> Input Class Initialized
INFO - 2025-06-03 16:46:31 --> Language Class Initialized
INFO - 2025-06-03 16:46:31 --> Loader Class Initialized
INFO - 2025-06-03 16:46:31 --> Helper loaded: url_helper
INFO - 2025-06-03 16:46:31 --> Helper loaded: form_helper
INFO - 2025-06-03 16:46:31 --> Database Driver Class Initialized
DEBUG - 2025-06-03 16:46:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 16:46:31 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 16:46:31 --> Controller Class Initialized
INFO - 2025-06-03 16:46:31 --> Model "Olahraga_model" initialized
INFO - 2025-06-03 16:46:31 --> Model "User_model" initialized
INFO - 2025-06-03 16:46:31 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 16:46:31 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 16:46:31 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/start.php
INFO - 2025-06-03 16:46:31 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 16:46:31 --> Final output sent to browser
DEBUG - 2025-06-03 16:46:31 --> Total execution time: 0.2327
INFO - 2025-06-03 16:51:49 --> Config Class Initialized
INFO - 2025-06-03 16:51:49 --> Hooks Class Initialized
DEBUG - 2025-06-03 16:51:49 --> UTF-8 Support Enabled
INFO - 2025-06-03 16:51:49 --> Utf8 Class Initialized
INFO - 2025-06-03 16:51:49 --> URI Class Initialized
INFO - 2025-06-03 16:51:49 --> Router Class Initialized
INFO - 2025-06-03 16:51:49 --> Output Class Initialized
INFO - 2025-06-03 16:51:49 --> Security Class Initialized
DEBUG - 2025-06-03 16:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 16:51:49 --> Input Class Initialized
INFO - 2025-06-03 16:51:49 --> Language Class Initialized
INFO - 2025-06-03 16:51:49 --> Loader Class Initialized
INFO - 2025-06-03 16:51:49 --> Helper loaded: url_helper
INFO - 2025-06-03 16:51:49 --> Helper loaded: form_helper
INFO - 2025-06-03 16:51:49 --> Database Driver Class Initialized
DEBUG - 2025-06-03 16:51:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 16:51:49 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 16:51:49 --> Controller Class Initialized
INFO - 2025-06-03 16:51:49 --> Model "User_model" initialized
INFO - 2025-06-03 16:51:49 --> Model "Progress_model" initialized
INFO - 2025-06-03 16:51:49 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 16:51:49 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 16:51:49 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/guide.php
INFO - 2025-06-03 16:51:49 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 16:51:49 --> Final output sent to browser
DEBUG - 2025-06-03 16:51:49 --> Total execution time: 0.1348
INFO - 2025-06-03 16:51:52 --> Config Class Initialized
INFO - 2025-06-03 16:51:52 --> Hooks Class Initialized
DEBUG - 2025-06-03 16:51:52 --> UTF-8 Support Enabled
INFO - 2025-06-03 16:51:52 --> Utf8 Class Initialized
INFO - 2025-06-03 16:51:52 --> URI Class Initialized
INFO - 2025-06-03 16:51:52 --> Router Class Initialized
INFO - 2025-06-03 16:51:52 --> Output Class Initialized
INFO - 2025-06-03 16:51:52 --> Security Class Initialized
DEBUG - 2025-06-03 16:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 16:51:52 --> Input Class Initialized
INFO - 2025-06-03 16:51:52 --> Language Class Initialized
INFO - 2025-06-03 16:51:52 --> Loader Class Initialized
INFO - 2025-06-03 16:51:52 --> Helper loaded: url_helper
INFO - 2025-06-03 16:51:52 --> Helper loaded: form_helper
INFO - 2025-06-03 16:51:52 --> Database Driver Class Initialized
DEBUG - 2025-06-03 16:51:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 16:51:52 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 16:51:52 --> Controller Class Initialized
INFO - 2025-06-03 16:51:52 --> Model "User_model" initialized
INFO - 2025-06-03 16:51:52 --> Model "Progress_model" initialized
INFO - 2025-06-03 16:51:52 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-03 16:51:52 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-03 16:51:52 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/dashboard.php
INFO - 2025-06-03 16:51:52 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-03 16:51:52 --> Final output sent to browser
DEBUG - 2025-06-03 16:51:52 --> Total execution time: 0.1548
INFO - 2025-06-03 16:51:53 --> Config Class Initialized
INFO - 2025-06-03 16:51:53 --> Hooks Class Initialized
DEBUG - 2025-06-03 16:51:53 --> UTF-8 Support Enabled
INFO - 2025-06-03 16:51:53 --> Utf8 Class Initialized
INFO - 2025-06-03 16:51:53 --> URI Class Initialized
INFO - 2025-06-03 16:51:53 --> Router Class Initialized
INFO - 2025-06-03 16:51:53 --> Output Class Initialized
INFO - 2025-06-03 16:51:53 --> Security Class Initialized
DEBUG - 2025-06-03 16:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 16:51:53 --> Input Class Initialized
INFO - 2025-06-03 16:51:53 --> Language Class Initialized
INFO - 2025-06-03 16:51:53 --> Loader Class Initialized
INFO - 2025-06-03 16:51:53 --> Helper loaded: url_helper
INFO - 2025-06-03 16:51:53 --> Helper loaded: form_helper
INFO - 2025-06-03 16:51:53 --> Database Driver Class Initialized
DEBUG - 2025-06-03 16:51:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 16:51:53 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 16:51:53 --> Controller Class Initialized
INFO - 2025-06-03 16:51:53 --> Model "User_model" initialized
INFO - 2025-06-03 16:51:53 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-06-03 16:51:53 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/home.php
INFO - 2025-06-03 16:51:53 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-06-03 16:51:53 --> Final output sent to browser
DEBUG - 2025-06-03 16:51:53 --> Total execution time: 0.1109
INFO - 2025-06-03 16:52:06 --> Config Class Initialized
INFO - 2025-06-03 16:52:06 --> Hooks Class Initialized
DEBUG - 2025-06-03 16:52:06 --> UTF-8 Support Enabled
INFO - 2025-06-03 16:52:06 --> Utf8 Class Initialized
INFO - 2025-06-03 16:52:06 --> URI Class Initialized
INFO - 2025-06-03 16:52:06 --> Router Class Initialized
INFO - 2025-06-03 16:52:06 --> Output Class Initialized
INFO - 2025-06-03 16:52:06 --> Security Class Initialized
DEBUG - 2025-06-03 16:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 16:52:06 --> Input Class Initialized
INFO - 2025-06-03 16:52:06 --> Language Class Initialized
INFO - 2025-06-03 16:52:06 --> Loader Class Initialized
INFO - 2025-06-03 16:52:06 --> Helper loaded: url_helper
INFO - 2025-06-03 16:52:06 --> Helper loaded: form_helper
INFO - 2025-06-03 16:52:06 --> Database Driver Class Initialized
DEBUG - 2025-06-03 16:52:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 16:52:06 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 16:52:06 --> Controller Class Initialized
INFO - 2025-06-03 16:52:06 --> Model "User_model" initialized
INFO - 2025-06-03 16:52:06 --> Form Validation Class Initialized
INFO - 2025-06-03 16:52:06 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\auth/login.php
INFO - 2025-06-03 16:52:06 --> Final output sent to browser
DEBUG - 2025-06-03 16:52:06 --> Total execution time: 0.1066
INFO - 2025-06-03 16:52:13 --> Config Class Initialized
INFO - 2025-06-03 16:52:13 --> Hooks Class Initialized
DEBUG - 2025-06-03 16:52:13 --> UTF-8 Support Enabled
INFO - 2025-06-03 16:52:13 --> Utf8 Class Initialized
INFO - 2025-06-03 16:52:13 --> URI Class Initialized
INFO - 2025-06-03 16:52:13 --> Router Class Initialized
INFO - 2025-06-03 16:52:13 --> Output Class Initialized
INFO - 2025-06-03 16:52:13 --> Security Class Initialized
DEBUG - 2025-06-03 16:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 16:52:13 --> Input Class Initialized
INFO - 2025-06-03 16:52:13 --> Language Class Initialized
INFO - 2025-06-03 16:52:13 --> Loader Class Initialized
INFO - 2025-06-03 16:52:13 --> Helper loaded: url_helper
INFO - 2025-06-03 16:52:13 --> Helper loaded: form_helper
INFO - 2025-06-03 16:52:13 --> Database Driver Class Initialized
DEBUG - 2025-06-03 16:52:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 16:52:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 16:52:13 --> Controller Class Initialized
INFO - 2025-06-03 16:52:13 --> Model "User_model" initialized
INFO - 2025-06-03 16:52:13 --> Form Validation Class Initialized
INFO - 2025-06-03 16:52:13 --> Config Class Initialized
INFO - 2025-06-03 16:52:13 --> Hooks Class Initialized
DEBUG - 2025-06-03 16:52:13 --> UTF-8 Support Enabled
INFO - 2025-06-03 16:52:13 --> Utf8 Class Initialized
INFO - 2025-06-03 16:52:13 --> URI Class Initialized
INFO - 2025-06-03 16:52:13 --> Router Class Initialized
INFO - 2025-06-03 16:52:13 --> Output Class Initialized
INFO - 2025-06-03 16:52:13 --> Security Class Initialized
DEBUG - 2025-06-03 16:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-03 16:52:13 --> Input Class Initialized
INFO - 2025-06-03 16:52:13 --> Language Class Initialized
INFO - 2025-06-03 16:52:13 --> Loader Class Initialized
INFO - 2025-06-03 16:52:13 --> Helper loaded: url_helper
INFO - 2025-06-03 16:52:13 --> Helper loaded: form_helper
INFO - 2025-06-03 16:52:13 --> Database Driver Class Initialized
DEBUG - 2025-06-03 16:52:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-03 16:52:13 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-03 16:52:13 --> Controller Class Initialized
INFO - 2025-06-03 16:52:13 --> Model "User_model" initialized
INFO - 2025-06-03 16:52:13 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-06-03 16:52:13 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/home.php
INFO - 2025-06-03 16:52:13 --> File loaded: C:\xampp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-06-03 16:52:13 --> Final output sent to browser
DEBUG - 2025-06-03 16:52:13 --> Total execution time: 0.1208
