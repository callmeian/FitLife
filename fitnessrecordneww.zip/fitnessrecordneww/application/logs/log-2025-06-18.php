<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2025-06-18 16:56:17 --> Config Class Initialized
INFO - 2025-06-18 16:56:17 --> Hooks Class Initialized
DEBUG - 2025-06-18 16:56:18 --> UTF-8 Support Enabled
INFO - 2025-06-18 16:56:18 --> Utf8 Class Initialized
INFO - 2025-06-18 16:56:18 --> URI Class Initialized
DEBUG - 2025-06-18 16:56:18 --> No URI present. Default controller set.
INFO - 2025-06-18 16:56:18 --> Router Class Initialized
INFO - 2025-06-18 16:56:18 --> Output Class Initialized
INFO - 2025-06-18 16:56:18 --> Security Class Initialized
DEBUG - 2025-06-18 16:56:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-18 16:56:18 --> Input Class Initialized
INFO - 2025-06-18 16:56:18 --> Language Class Initialized
INFO - 2025-06-18 16:56:18 --> Loader Class Initialized
INFO - 2025-06-18 16:56:18 --> Helper loaded: url_helper
INFO - 2025-06-18 16:56:18 --> Helper loaded: form_helper
INFO - 2025-06-18 16:56:19 --> Database Driver Class Initialized
DEBUG - 2025-06-18 16:56:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-18 16:56:19 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-18 16:56:19 --> Controller Class Initialized
INFO - 2025-06-18 16:56:19 --> Model "User_model" initialized
INFO - 2025-06-18 16:56:20 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-06-18 16:56:20 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\landing_page/home.php
INFO - 2025-06-18 16:56:20 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-06-18 16:56:20 --> Final output sent to browser
DEBUG - 2025-06-18 16:56:20 --> Total execution time: 3.0320
INFO - 2025-06-18 16:56:30 --> Config Class Initialized
INFO - 2025-06-18 16:56:30 --> Hooks Class Initialized
DEBUG - 2025-06-18 16:56:30 --> UTF-8 Support Enabled
INFO - 2025-06-18 16:56:30 --> Utf8 Class Initialized
INFO - 2025-06-18 16:56:30 --> URI Class Initialized
INFO - 2025-06-18 16:56:30 --> Router Class Initialized
INFO - 2025-06-18 16:56:30 --> Output Class Initialized
INFO - 2025-06-18 16:56:30 --> Security Class Initialized
DEBUG - 2025-06-18 16:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-18 16:56:30 --> Input Class Initialized
INFO - 2025-06-18 16:56:30 --> Language Class Initialized
INFO - 2025-06-18 16:56:30 --> Loader Class Initialized
INFO - 2025-06-18 16:56:30 --> Helper loaded: url_helper
INFO - 2025-06-18 16:56:30 --> Helper loaded: form_helper
INFO - 2025-06-18 16:56:30 --> Database Driver Class Initialized
DEBUG - 2025-06-18 16:56:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-18 16:56:30 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-18 16:56:30 --> Controller Class Initialized
INFO - 2025-06-18 16:56:30 --> Model "User_model" initialized
INFO - 2025-06-18 16:56:30 --> Form Validation Class Initialized
INFO - 2025-06-18 16:56:30 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\auth/login.php
INFO - 2025-06-18 16:56:30 --> Final output sent to browser
DEBUG - 2025-06-18 16:56:30 --> Total execution time: 0.2846
INFO - 2025-06-18 16:56:39 --> Config Class Initialized
INFO - 2025-06-18 16:56:39 --> Hooks Class Initialized
DEBUG - 2025-06-18 16:56:39 --> UTF-8 Support Enabled
INFO - 2025-06-18 16:56:39 --> Utf8 Class Initialized
INFO - 2025-06-18 16:56:39 --> URI Class Initialized
INFO - 2025-06-18 16:56:39 --> Router Class Initialized
INFO - 2025-06-18 16:56:39 --> Output Class Initialized
INFO - 2025-06-18 16:56:39 --> Security Class Initialized
DEBUG - 2025-06-18 16:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-18 16:56:39 --> Input Class Initialized
INFO - 2025-06-18 16:56:39 --> Language Class Initialized
INFO - 2025-06-18 16:56:39 --> Loader Class Initialized
INFO - 2025-06-18 16:56:39 --> Helper loaded: url_helper
INFO - 2025-06-18 16:56:39 --> Helper loaded: form_helper
INFO - 2025-06-18 16:56:39 --> Database Driver Class Initialized
DEBUG - 2025-06-18 16:56:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-18 16:56:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-18 16:56:39 --> Controller Class Initialized
INFO - 2025-06-18 16:56:39 --> Model "User_model" initialized
INFO - 2025-06-18 16:56:39 --> Form Validation Class Initialized
INFO - 2025-06-18 16:56:39 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-06-18 16:56:39 --> Config Class Initialized
INFO - 2025-06-18 16:56:39 --> Hooks Class Initialized
DEBUG - 2025-06-18 16:56:39 --> UTF-8 Support Enabled
INFO - 2025-06-18 16:56:39 --> Utf8 Class Initialized
INFO - 2025-06-18 16:56:39 --> URI Class Initialized
INFO - 2025-06-18 16:56:39 --> Router Class Initialized
INFO - 2025-06-18 16:56:39 --> Output Class Initialized
INFO - 2025-06-18 16:56:39 --> Security Class Initialized
DEBUG - 2025-06-18 16:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-18 16:56:39 --> Input Class Initialized
INFO - 2025-06-18 16:56:39 --> Language Class Initialized
INFO - 2025-06-18 16:56:39 --> Loader Class Initialized
INFO - 2025-06-18 16:56:39 --> Helper loaded: url_helper
INFO - 2025-06-18 16:56:39 --> Helper loaded: form_helper
INFO - 2025-06-18 16:56:39 --> Database Driver Class Initialized
DEBUG - 2025-06-18 16:56:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-18 16:56:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-18 16:56:39 --> Controller Class Initialized
INFO - 2025-06-18 16:56:39 --> Model "User_model" initialized
INFO - 2025-06-18 16:56:39 --> Form Validation Class Initialized
INFO - 2025-06-18 16:56:39 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\auth/login.php
INFO - 2025-06-18 16:56:39 --> Final output sent to browser
DEBUG - 2025-06-18 16:56:39 --> Total execution time: 0.0657
INFO - 2025-06-18 16:57:35 --> Config Class Initialized
INFO - 2025-06-18 16:57:35 --> Hooks Class Initialized
DEBUG - 2025-06-18 16:57:35 --> UTF-8 Support Enabled
INFO - 2025-06-18 16:57:35 --> Utf8 Class Initialized
INFO - 2025-06-18 16:57:35 --> URI Class Initialized
INFO - 2025-06-18 16:57:35 --> Router Class Initialized
INFO - 2025-06-18 16:57:35 --> Output Class Initialized
INFO - 2025-06-18 16:57:35 --> Security Class Initialized
DEBUG - 2025-06-18 16:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-18 16:57:35 --> Input Class Initialized
INFO - 2025-06-18 16:57:35 --> Language Class Initialized
INFO - 2025-06-18 16:57:35 --> Loader Class Initialized
INFO - 2025-06-18 16:57:35 --> Helper loaded: url_helper
INFO - 2025-06-18 16:57:35 --> Helper loaded: form_helper
INFO - 2025-06-18 16:57:35 --> Database Driver Class Initialized
DEBUG - 2025-06-18 16:57:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-18 16:57:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-18 16:57:35 --> Controller Class Initialized
INFO - 2025-06-18 16:57:35 --> Model "User_model" initialized
INFO - 2025-06-18 16:57:35 --> Form Validation Class Initialized
INFO - 2025-06-18 16:57:35 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2025-06-18 16:57:35 --> Config Class Initialized
INFO - 2025-06-18 16:57:35 --> Hooks Class Initialized
DEBUG - 2025-06-18 16:57:35 --> UTF-8 Support Enabled
INFO - 2025-06-18 16:57:35 --> Utf8 Class Initialized
INFO - 2025-06-18 16:57:35 --> URI Class Initialized
INFO - 2025-06-18 16:57:35 --> Router Class Initialized
INFO - 2025-06-18 16:57:35 --> Output Class Initialized
INFO - 2025-06-18 16:57:35 --> Security Class Initialized
DEBUG - 2025-06-18 16:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-18 16:57:35 --> Input Class Initialized
INFO - 2025-06-18 16:57:35 --> Language Class Initialized
INFO - 2025-06-18 16:57:35 --> Loader Class Initialized
INFO - 2025-06-18 16:57:35 --> Helper loaded: url_helper
INFO - 2025-06-18 16:57:35 --> Helper loaded: form_helper
INFO - 2025-06-18 16:57:35 --> Database Driver Class Initialized
DEBUG - 2025-06-18 16:57:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-18 16:57:35 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-18 16:57:35 --> Controller Class Initialized
INFO - 2025-06-18 16:57:35 --> Model "User_model" initialized
INFO - 2025-06-18 16:57:35 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\landing_page/layout/header.php
INFO - 2025-06-18 16:57:35 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\landing_page/home.php
INFO - 2025-06-18 16:57:35 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\landing_page/layout/footer.php
INFO - 2025-06-18 16:57:35 --> Final output sent to browser
DEBUG - 2025-06-18 16:57:35 --> Total execution time: 0.0576
INFO - 2025-06-18 16:57:42 --> Config Class Initialized
INFO - 2025-06-18 16:57:42 --> Hooks Class Initialized
DEBUG - 2025-06-18 16:57:42 --> UTF-8 Support Enabled
INFO - 2025-06-18 16:57:42 --> Utf8 Class Initialized
INFO - 2025-06-18 16:57:42 --> URI Class Initialized
INFO - 2025-06-18 16:57:42 --> Router Class Initialized
INFO - 2025-06-18 16:57:42 --> Output Class Initialized
INFO - 2025-06-18 16:57:42 --> Security Class Initialized
DEBUG - 2025-06-18 16:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-18 16:57:42 --> Input Class Initialized
INFO - 2025-06-18 16:57:42 --> Language Class Initialized
INFO - 2025-06-18 16:57:42 --> Loader Class Initialized
INFO - 2025-06-18 16:57:42 --> Helper loaded: url_helper
INFO - 2025-06-18 16:57:42 --> Helper loaded: form_helper
INFO - 2025-06-18 16:57:42 --> Database Driver Class Initialized
DEBUG - 2025-06-18 16:57:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-18 16:57:42 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-18 16:57:42 --> Controller Class Initialized
INFO - 2025-06-18 16:57:42 --> Model "User_model" initialized
INFO - 2025-06-18 16:57:42 --> Model "Progress_model" initialized
INFO - 2025-06-18 16:57:42 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-18 16:57:42 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-18 16:57:42 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/dashboard.php
INFO - 2025-06-18 16:57:42 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-18 16:57:42 --> Final output sent to browser
DEBUG - 2025-06-18 16:57:42 --> Total execution time: 0.6512
INFO - 2025-06-18 16:57:50 --> Config Class Initialized
INFO - 2025-06-18 16:57:50 --> Hooks Class Initialized
DEBUG - 2025-06-18 16:57:50 --> UTF-8 Support Enabled
INFO - 2025-06-18 16:57:50 --> Utf8 Class Initialized
INFO - 2025-06-18 16:57:50 --> URI Class Initialized
INFO - 2025-06-18 16:57:50 --> Router Class Initialized
INFO - 2025-06-18 16:57:50 --> Output Class Initialized
INFO - 2025-06-18 16:57:50 --> Security Class Initialized
DEBUG - 2025-06-18 16:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-18 16:57:50 --> Input Class Initialized
INFO - 2025-06-18 16:57:50 --> Language Class Initialized
INFO - 2025-06-18 16:57:50 --> Loader Class Initialized
INFO - 2025-06-18 16:57:50 --> Helper loaded: url_helper
INFO - 2025-06-18 16:57:50 --> Helper loaded: form_helper
INFO - 2025-06-18 16:57:50 --> Database Driver Class Initialized
DEBUG - 2025-06-18 16:57:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-18 16:57:50 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-18 16:57:50 --> Controller Class Initialized
INFO - 2025-06-18 16:57:50 --> Model "Olahraga_model" initialized
INFO - 2025-06-18 16:57:50 --> Model "User_model" initialized
INFO - 2025-06-18 16:57:50 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-18 16:57:50 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-18 16:57:50 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/olahraga.php
INFO - 2025-06-18 16:57:50 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-18 16:57:50 --> Final output sent to browser
DEBUG - 2025-06-18 16:57:50 --> Total execution time: 0.2648
INFO - 2025-06-18 16:57:54 --> Config Class Initialized
INFO - 2025-06-18 16:57:54 --> Hooks Class Initialized
DEBUG - 2025-06-18 16:57:54 --> UTF-8 Support Enabled
INFO - 2025-06-18 16:57:54 --> Utf8 Class Initialized
INFO - 2025-06-18 16:57:54 --> URI Class Initialized
INFO - 2025-06-18 16:57:54 --> Router Class Initialized
INFO - 2025-06-18 16:57:54 --> Output Class Initialized
INFO - 2025-06-18 16:57:54 --> Security Class Initialized
DEBUG - 2025-06-18 16:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-18 16:57:54 --> Input Class Initialized
INFO - 2025-06-18 16:57:54 --> Language Class Initialized
INFO - 2025-06-18 16:57:54 --> Loader Class Initialized
INFO - 2025-06-18 16:57:54 --> Helper loaded: url_helper
INFO - 2025-06-18 16:57:54 --> Helper loaded: form_helper
INFO - 2025-06-18 16:57:54 --> Database Driver Class Initialized
DEBUG - 2025-06-18 16:57:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-18 16:57:54 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-18 16:57:54 --> Controller Class Initialized
INFO - 2025-06-18 16:57:54 --> Model "Olahraga_model" initialized
INFO - 2025-06-18 16:57:54 --> Model "User_model" initialized
INFO - 2025-06-18 16:57:54 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-18 16:57:54 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-18 16:57:54 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/level.php
INFO - 2025-06-18 16:57:54 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-18 16:57:54 --> Final output sent to browser
DEBUG - 2025-06-18 16:57:54 --> Total execution time: 0.0667
INFO - 2025-06-18 16:57:58 --> Config Class Initialized
INFO - 2025-06-18 16:57:58 --> Hooks Class Initialized
DEBUG - 2025-06-18 16:57:58 --> UTF-8 Support Enabled
INFO - 2025-06-18 16:57:58 --> Utf8 Class Initialized
INFO - 2025-06-18 16:57:58 --> URI Class Initialized
INFO - 2025-06-18 16:57:58 --> Router Class Initialized
INFO - 2025-06-18 16:57:58 --> Output Class Initialized
INFO - 2025-06-18 16:57:58 --> Security Class Initialized
DEBUG - 2025-06-18 16:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-18 16:57:58 --> Input Class Initialized
INFO - 2025-06-18 16:57:58 --> Language Class Initialized
INFO - 2025-06-18 16:57:58 --> Loader Class Initialized
INFO - 2025-06-18 16:57:58 --> Helper loaded: url_helper
INFO - 2025-06-18 16:57:58 --> Helper loaded: form_helper
INFO - 2025-06-18 16:57:58 --> Database Driver Class Initialized
DEBUG - 2025-06-18 16:57:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-18 16:57:58 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-18 16:57:58 --> Controller Class Initialized
INFO - 2025-06-18 16:57:58 --> Model "Olahraga_model" initialized
INFO - 2025-06-18 16:57:58 --> Model "User_model" initialized
INFO - 2025-06-18 16:57:58 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-18 16:57:58 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-18 16:57:58 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/menu.php
INFO - 2025-06-18 16:57:58 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-18 16:57:58 --> Final output sent to browser
DEBUG - 2025-06-18 16:57:58 --> Total execution time: 0.1049
INFO - 2025-06-18 16:58:32 --> Config Class Initialized
INFO - 2025-06-18 16:58:32 --> Hooks Class Initialized
DEBUG - 2025-06-18 16:58:32 --> UTF-8 Support Enabled
INFO - 2025-06-18 16:58:32 --> Utf8 Class Initialized
INFO - 2025-06-18 16:58:32 --> URI Class Initialized
INFO - 2025-06-18 16:58:32 --> Router Class Initialized
INFO - 2025-06-18 16:58:32 --> Output Class Initialized
INFO - 2025-06-18 16:58:32 --> Security Class Initialized
DEBUG - 2025-06-18 16:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-18 16:58:32 --> Input Class Initialized
INFO - 2025-06-18 16:58:32 --> Language Class Initialized
INFO - 2025-06-18 16:58:32 --> Loader Class Initialized
INFO - 2025-06-18 16:58:32 --> Helper loaded: url_helper
INFO - 2025-06-18 16:58:32 --> Helper loaded: form_helper
INFO - 2025-06-18 16:58:32 --> Database Driver Class Initialized
DEBUG - 2025-06-18 16:58:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-18 16:58:32 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-18 16:58:32 --> Controller Class Initialized
INFO - 2025-06-18 16:58:32 --> Model "Olahraga_model" initialized
INFO - 2025-06-18 16:58:32 --> Model "User_model" initialized
INFO - 2025-06-18 16:58:32 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-18 16:58:32 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-18 16:58:32 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/start.php
INFO - 2025-06-18 16:58:32 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-18 16:58:32 --> Final output sent to browser
DEBUG - 2025-06-18 16:58:32 --> Total execution time: 0.1134
INFO - 2025-06-18 16:58:39 --> Config Class Initialized
INFO - 2025-06-18 16:58:39 --> Hooks Class Initialized
DEBUG - 2025-06-18 16:58:39 --> UTF-8 Support Enabled
INFO - 2025-06-18 16:58:39 --> Utf8 Class Initialized
INFO - 2025-06-18 16:58:39 --> URI Class Initialized
INFO - 2025-06-18 16:58:39 --> Router Class Initialized
INFO - 2025-06-18 16:58:39 --> Output Class Initialized
INFO - 2025-06-18 16:58:39 --> Security Class Initialized
DEBUG - 2025-06-18 16:58:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-18 16:58:39 --> Input Class Initialized
INFO - 2025-06-18 16:58:39 --> Language Class Initialized
INFO - 2025-06-18 16:58:39 --> Loader Class Initialized
INFO - 2025-06-18 16:58:39 --> Helper loaded: url_helper
INFO - 2025-06-18 16:58:39 --> Helper loaded: form_helper
INFO - 2025-06-18 16:58:39 --> Database Driver Class Initialized
DEBUG - 2025-06-18 16:58:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-18 16:58:39 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-18 16:58:39 --> Controller Class Initialized
INFO - 2025-06-18 16:58:39 --> Model "Olahraga_model" initialized
INFO - 2025-06-18 16:58:39 --> Model "User_model" initialized
INFO - 2025-06-18 16:58:39 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-18 16:58:39 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-18 16:58:39 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/start.php
INFO - 2025-06-18 16:58:39 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-18 16:58:39 --> Final output sent to browser
DEBUG - 2025-06-18 16:58:39 --> Total execution time: 0.0693
INFO - 2025-06-18 16:59:00 --> Config Class Initialized
INFO - 2025-06-18 16:59:00 --> Hooks Class Initialized
DEBUG - 2025-06-18 16:59:00 --> UTF-8 Support Enabled
INFO - 2025-06-18 16:59:00 --> Utf8 Class Initialized
INFO - 2025-06-18 16:59:00 --> URI Class Initialized
INFO - 2025-06-18 16:59:00 --> Router Class Initialized
INFO - 2025-06-18 16:59:00 --> Output Class Initialized
INFO - 2025-06-18 16:59:00 --> Security Class Initialized
DEBUG - 2025-06-18 16:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2025-06-18 16:59:00 --> Input Class Initialized
INFO - 2025-06-18 16:59:00 --> Language Class Initialized
INFO - 2025-06-18 16:59:00 --> Loader Class Initialized
INFO - 2025-06-18 16:59:00 --> Helper loaded: url_helper
INFO - 2025-06-18 16:59:00 --> Helper loaded: form_helper
INFO - 2025-06-18 16:59:00 --> Database Driver Class Initialized
DEBUG - 2025-06-18 16:59:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2025-06-18 16:59:00 --> Session: Class initialized using 'files' driver.
INFO - 2025-06-18 16:59:00 --> Controller Class Initialized
INFO - 2025-06-18 16:59:00 --> Model "Olahraga_model" initialized
INFO - 2025-06-18 16:59:00 --> Model "User_model" initialized
INFO - 2025-06-18 16:59:00 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/header.php
INFO - 2025-06-18 16:59:00 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/sidebar.php
INFO - 2025-06-18 16:59:00 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/olahraga/start.php
INFO - 2025-06-18 16:59:00 --> File loaded: C:\xamp\htdocs\fitnessrecordneww\application\views\dashboard/layout/footer.php
INFO - 2025-06-18 16:59:00 --> Final output sent to browser
DEBUG - 2025-06-18 16:59:00 --> Total execution time: 0.0585
