<?php
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * @property CI_Input $input
 * @property User_model $User_model
 * @property CI_Session $session
 * @property form_validation $form_validation
 */
class Auth extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('User_model');
        $this->load->library('form_validation');
    }

    public function login()
    {
        if ($this->input->post()) {
            // Validasi form
            $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
            $this->form_validation->set_rules('password', 'Password', 'required');

            if ($this->form_validation->run() == FALSE) {
                // Validasi gagal
                $this->session->set_flashdata('error', validation_errors());
                redirect('auth/login');
            } else {
                $email = $this->input->post('email');
                $password = $this->input->post('password');
                $user = $this->User_model->get_by_email($email);

                if ($user && password_verify($password, $user->password)) {
                    // Simpan data user ke session
                    $this->session->set_userdata([
                        'user_id' => $user->id,
                        'name' => $user->name, // nama dari database
                        'logged_in' => true
                    ]);

                    $this->session->set_flashdata('success', 'Login berhasil!');
                    redirect('LandingPage'); // redirect ke halaman home/landing
                } else {
                    $this->session->set_flashdata('error', 'Email atau password salah.');
                    redirect('auth/login');
                }
            }
        } else {
            $this->load->view('auth/login');
        }
    }

    public function register()
    {
        $this->load->library('form_validation');

        $this->form_validation->set_rules('name', 'Full Name', 'required|trim');
        $this->form_validation->set_rules('email', 'Email', 'required|trim|valid_email|is_unique[users.email]');
        $this->form_validation->set_rules('password', 'Password', 'required|min_length[6]');
        $this->form_validation->set_rules('terms', 'Terms and Conditions', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->session->set_flashdata('error', validation_errors('<li>', '</li>'));
            $this->load->view('auth/register');
        } else {
            $data = [
                'name' => htmlspecialchars($this->input->post('name', true)),
                'email' => htmlspecialchars($this->input->post('email', true)),
                'password' => password_hash($this->input->post('password'), PASSWORD_BCRYPT),
                'created_at' => date('Y-m-d H:i:s')
            ];
            $this->User_model->insert($data);
            $this->session->set_flashdata('success', 'Pendaftaran berhasil! Silakan login.');
            redirect('auth/login');
        }
    }


    public function logout()
    {
        $this->session->unset_userdata('user_id');
        redirect('LandingPage');
    }
}
