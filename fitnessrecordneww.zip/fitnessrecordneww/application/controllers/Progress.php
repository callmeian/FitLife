<?php
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * @property CI_Input $input
 * @property CI_Session $session
 * @property User_model $User_model
 * @property Progress_model $Progress_model
 * @property Olahraga_model $Olahraga_model
 */
class Progress extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Progress_model');
        $this->load->model('Olahraga_model');
        $this->load->model('User_model');
        if (!$this->session->userdata('user_id')) {
            redirect('auth/login');
        }
    }

    public function index()
    {
        if (!$this->session->userdata('user_id')) {
            redirect('auth/login');
        }

        $data['user'] = $this->User_model->get_by_id($this->session->userdata('user_id'));
        $this->load->view('dashboard/layout/header', $data);
        $this->load->view('dashboard/layout/sidebar');
        $this->load->view('dashboard/progress_view', $data);
        $this->load->view('dashboard/layout/footer');
    }

    public function get_events()
    {
        if (!$this->session->userdata('user_id')) {
            redirect('auth/login');
        }
        $user_id = $this->session->userdata('user_id');
        $events = $this->Progress_model->get_selesai_progress($user_id);
        echo json_encode($events);
    }

    public function get_event_detail($id)
    {
        if (!$this->session->userdata('user_id')) {
            redirect('auth/login');
        }
        $user_id = $this->session->userdata('user_id');
        $result = $this->Progress_model->get_progress_by_id($id, $user_id);

        if ($result['data']) {
            echo json_encode($result);
        } else {
            echo json_encode(['error' => 'Data tidak ditemukan atau bukan milik user']);
        }
    }
}
