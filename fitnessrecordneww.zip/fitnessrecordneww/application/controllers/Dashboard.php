<?php
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * @property CI_Input $input
 * @property User_model $User_model
 * @property CI_Session $session
 * @property db $db
 * @property Progress_model $Progress_model
 */

class Dashboard extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();

        // Cek apakah user sudah login
        if (!$this->session->userdata('user_id')) {
            redirect('auth/login');
        }

        $this->load->model('User_model');
        $this->load->model('Progress_model');
    }

    public function index()
    {
        $user_id = $this->session->userdata('user_id');
        $data['user'] = $this->User_model->get_by_id($user_id);

        // Data grafik workout & kalori 7 hari terakhir
        $data['chart_data'] = $this->Progress_model->get_weekly_chart_data($user_id);

        // Data persentase otot
        $data['muscle_distribution'] = $this->Progress_model->get_muscle_distribution($user_id);

        // Ambil filter dari query param, default 'week'
        $filter = $this->input->get('filter') ?? 'week';

        // Ambil ringkasan workout berdasarkan filter waktu
        $summary = $this->Progress_model->get_summary($user_id, $filter);
        $data['total_workouts'] = $summary->total_workouts ?? 0;
        $data['total_calories'] = $summary->total_calories ?? 0;

        // Ambil semua workout selesai untuk recent table (bisa tanpa filter atau kamu tambahkan filter juga)
        $this->db->where('user_id', $user_id);
        $this->db->where('status', 'selesai');
        $this->db->order_by('progress_date', 'DESC');
        $data['recent_workouts'] = $this->db->get('fitness_progress')->result();

        // Kirim juga data filter ke view agar dropdown bisa ter-set selected
        $data['filter'] = $filter;

        $this->load->view('dashboard/layout/header', $data);
        $this->load->view('dashboard/layout/sidebar', $data);
        $this->load->view('dashboard/dashboard', $data);
        $this->load->view('dashboard/layout/footer');
    }


    public function guide()
    {
        $data['user'] = $this->User_model->get_by_id($this->session->userdata('user_id'));
        $this->load->view('dashboard/layout/header', $data);
        $this->load->view('dashboard/layout/sidebar');
        $this->load->view('dashboard/guide');
        $this->load->view('dashboard/layout/footer');
    }
}
