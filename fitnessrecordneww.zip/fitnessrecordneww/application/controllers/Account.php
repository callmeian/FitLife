<?php
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * @property CI_Input $input
 * @property User_model $User_model
 * @property CI_Session $session
 */

class Account extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        if (!$this->session->userdata('user_id')) {
            redirect('auth/login');
        }
        $this->load->model('User_model');
    }

    public function profile()
    {
        $data['user'] = $this->User_model->get_by_id($this->session->userdata('user_id'));
        $this->load->view('dashboard/layout/header', $data);
        $this->load->view('dashboard/layout/sidebar');
        $this->load->view('dashboard/profile', $data);
        $this->load->view('dashboard/layout/footer');
    }

    public function edit_profile()
    {
        $id = $this->session->userdata('user_id');
        $data['user'] = $this->User_model->get_by_id($id);

        $this->load->library('form_validation');

        $this->form_validation->set_rules('name', 'Nama', 'required');
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email');

        if ($this->input->post()) {
            if ($this->form_validation->run() == FALSE) {
                // Validasi gagal, tampilkan form lagi
                $this->load->view('dashboard/layout/header', $data);
                $this->load->view('dashboard/layout/sidebar');
                $this->load->view('dashboard/edit_profile', $data);
                $this->load->view('dashboard/layout/footer');
            } else {
                // Validasi berhasil, update data
                $update = [
                    'name' => $this->input->post('name'),
                    'email' => $this->input->post('email'),
                ];

                if ($this->input->post('password')) {
                    $update['password'] = password_hash($this->input->post('password'), PASSWORD_BCRYPT);
                }

                $this->User_model->update($id, $update);
                $this->session->set_flashdata('success', 'Profil berhasil diperbarui.');
                redirect('Dashboard/index');
            }
        } else {
            // Jika belum submit, tampilkan form
            $this->load->view('dashboard/layout/header', $data);
            $this->load->view('dashboard/layout/sidebar');
            $this->load->view('dashboard/edit_profile', $data);
            $this->load->view('dashboard/layout/footer');
        }
    }
}
