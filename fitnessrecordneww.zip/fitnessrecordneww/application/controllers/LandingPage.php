<?php
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * @property CI_Input $input
 * @property User_model $User_model
 * @property CI_Session $session
 */

class LandingPage extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('User_model');
    }

    public function index()
    {
        $data['user'] = $this->User_model->get_by_id($this->session->userdata('user_id'));
        $this->load->view('landing_page/layout/header', $data);
        $this->load->view('landing_page/home');
        $this->load->view('landing_page/layout/footer');
    }

    public function artikel()
    {
        $data['user'] = $this->User_model->get_by_id($this->session->userdata('user_id'));
        $this->load->view('landing_page/layout/header', $data);
        $this->load->view('landing_page/artikel');
        $this->load->view('landing_page/layout/footer');
    }
}
