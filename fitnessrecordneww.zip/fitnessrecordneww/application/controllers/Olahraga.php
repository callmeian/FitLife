<?php
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * @property CI_Input $input
 * @property User_model $User_model
 * @property CI_Session $session
 * @property Olahraga_model $Olahraga_model
 * @property db $db
 */

class Olahraga extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('Olahraga_model');
        $this->load->model('User_model');
        if (!$this->session->userdata('user_id')) {
            redirect('auth/login');
        }
    }

    public function index()
    {
        if (!$this->session->userdata('user_id')) {
            redirect('auth/login');
        }

        $data['user'] = $this->User_model->get_by_id($this->session->userdata('user_id'));
        $this->load->view('dashboard/layout/header', $data);
        $this->load->view('dashboard/layout/sidebar');
        $this->load->view('dashboard/olahraga/olahraga');
        $this->load->view('dashboard/layout/footer');
    }

    public function level($muscle)
    {
        if (!$this->session->userdata('user_id')) {
            redirect('auth/login');
        }

        $data['user'] = $this->User_model->get_by_id($this->session->userdata('user_id'));
        $data['muscle'] = $muscle;
        $this->load->view('dashboard/layout/header', $data);
        $this->load->view('dashboard/layout/sidebar');
        $this->load->view('dashboard/olahraga/level', $data); // Halaman pilih level
        $this->load->view('dashboard/layout/footer');
    }

    public function menu($muscle, $level)
    {
        // Misalnya kamu punya model bernama Workout_model
        $this->load->model('Olahraga_model');
        if (!$this->session->userdata('user_id')) {
            redirect('auth/login');
        }

        $data['user'] = $this->User_model->get_by_id($this->session->userdata('user_id'));
        $data['exercises'] = $this->Olahraga_model->get_menu_by_muscle_and_level($muscle, $level);
        $data['muscle'] = $muscle;
        $data['level'] = $level;
        $this->load->view('dashboard/layout/header', $data);
        $this->load->view('dashboard/layout/sidebar');
        $this->load->view('dashboard/olahraga/menu', $data); // Halaman daftar menu latihan
        $this->load->view('dashboard/layout/footer');
    }

    public function timer($id)
    {
        $this->load->model('Olahraga_model');
        $data['user'] = $this->User_model->get_by_id($this->session->userdata('user_id'));
        $latihan = $this->Olahraga_model->get_by_id($id);
        $next_latihan = $this->Olahraga_model->get_next_latihan($id, $latihan->target_otot, $latihan->level);
        $data['next_latihan'] = $next_latihan;
        $data['latihan'] = $latihan;
        $data['muscle'] = $latihan->target_otot;
        $data['level'] = $latihan->level;
        $this->load->view('dashboard/layout/header', $data);
        $this->load->view('dashboard/layout/sidebar');
        $this->load->view('dashboard/olahraga/start', $data);
        $this->load->view('dashboard/layout/footer');
    }

    public function save()
    {
        $user_id = $this->session->userdata('user_id');

        $data = [
            'user_id' => $user_id,
            'activity' => $this->input->post('activity'),
            'duration_minutes' => $this->input->post('duration'),
            'calories' => $this->input->post('calories'),
            'muscle' => $this->input->post('muscle'),
            'level' => $this->input->post('level'),
            'progress_date' => date('Y-m-d')
        ];

        $this->Olahraga_model->insert($data);
        echo json_encode(['status' => 'success']);
    }
}
