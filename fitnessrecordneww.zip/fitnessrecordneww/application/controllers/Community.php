<?php
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * @property CI_Input $input
 * @property User_model $User_model
 * @property CI_Session $session
 * @property Community_model $Community_model
 */

class Community extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        if (!$this->session->userdata('user_id')) {
            redirect('auth/login');
        }
        $this->load->model('User_model');
        $this->load->model('Community_model');
    }

    public function index()
    {
        $data['user'] = $this->User_model->get_by_id($this->session->userdata('user_id'));
        $data['posts'] = $this->Community_model->get_all_posts();
        $this->load->view('dashboard/layout/header', $data);
        $this->load->view('dashboard/layout/sidebar', $data);
        $this->load->view('dashboard/community', $data);
        $this->load->view('dashboard/layout/footer');
    }

    public function create_post()
    {
        $content = $this->input->post('content');
        $user_id = $this->session->userdata('user_id'); // pastikan session login aktif

        if ($content && $user_id) {
            $this->Community_model->insert_post($user_id, $content);
        }

        redirect('community');
    }

    public function delete_post($id)
    {
        $post = $this->Community_model->get_post_by_id($id);
        $user_id = $this->session->userdata('user_id');

        if ($post && $post->user_id == $user_id) {
            $this->Community_model->delete_post($id);
            $this->session->set_flashdata('success', 'Post berhasil dihapus.');
        } else {
            $this->session->set_flashdata('error', 'Tidak diizinkan menghapus post ini.');
        }

        redirect('community');
    }
}
