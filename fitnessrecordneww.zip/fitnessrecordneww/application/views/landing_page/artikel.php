  <header class="hero-header mx-auto mt-20">
    <h1>FitLife Articles</h1>
  </header>
  <main class="max-w-5xl mx-auto px-6 pt-12 pb-20 flex-grow space-y-20">
    <article class="bg-gray-800 rounded-2xl shadow-lg overflow-hidden p-10 article-card article-layout-1" style="animation-delay: 0.1s;">
      <div class="article-image-wrapper">
        <img alt="Fitness article cover showing a person lifting weights in a gym with intense focus" src="https://i.pinimg.com/736x/39/5a/ab/395aabc02419ce4158541aee03d26681.jpg" />
      </div>
      <div class="article-text">
        <h2 class="text-3xl font-bold mb-6 text-white cursor-pointer">
          5 Tips to Boost Your Workout Performance
        </h2>
        <p class="text-gray-300 mb-6">
          Maximizing your workout performance is essential to achieving your fitness goals efficiently. Here are five expert tips to help you get the most out of every training session:
        </p>
        <ul class="list-disc list-inside text-gray-300 mb-6 space-y-2">
          <li><strong>Warm Up Properly:</strong> Begin each session with dynamic stretches and light cardio to prepare your muscles and reduce injury risk.</li>
          <li><strong>Focus on Form:</strong> Proper technique ensures you target the right muscles and avoid strain or injury.</li>
          <li><strong>Progressive Overload:</strong> Gradually increase weights or intensity to continuously challenge your body.</li>
          <li><strong>Stay Hydrated:</strong> Drink water before, during, and after workouts to maintain performance and recovery.</li>
          <li><strong>Rest and Recover:</strong> Allow muscles time to repair with adequate rest days and sleep.</li>
        </ul>
        <p class="text-gray-300">
          Incorporate these tips consistently, and you'll notice improvements in strength, endurance, and overall fitness.
        </p>
      </div>
    </article>
    <article class="bg-gray-800 rounded-2xl shadow-lg overflow-hidden p-10 article-card article-layout-2" style="animation-delay: 0.3s;">
      <div class="article-image-wrapper">
        <img alt="Healthy meal prep with colorful vegetables and lean proteins on a wooden table" src="https://i.pinimg.com/736x/cf/59/2a/cf592a190a351b337252d64333746db8.jpg" />
      </div>
      <div class="article-text">
        <h2 class="text-3xl font-bold mb-6 text-white cursor-pointer">
          Nutrition Guide for Muscle Growth
        </h2>
        <p class="text-gray-300 mb-6">
          Proper nutrition is the foundation of muscle growth. To build muscle effectively, focus on the following nutritional principles:
        </p>
        <ul class="list-disc list-inside text-gray-300 mb-6 space-y-2">
          <li><strong>Consume Adequate Protein:</strong> Aim for 1.6-2.2 grams of protein per kilogram of body weight daily from sources like lean meats, dairy, legumes, and plant-based proteins.</li>
          <li><strong>Eat Enough Calories:</strong> Maintain a slight calorie surplus to fuel muscle repair and growth.</li>
          <li><strong>Balance Macronutrients:</strong> Include healthy fats and complex carbohydrates to support energy and hormone production.</li>
          <li><strong>Stay Hydrated:</strong> Water supports digestion, nutrient transport, and muscle function.</li>
          <li><strong>Timing Matters:</strong> Consume protein-rich meals spaced evenly throughout the day, including post-workout nutrition.</li>
        </ul>
        <p class="text-gray-300">
          Combining these nutritional strategies with consistent training will help you maximize muscle gains and recovery.
        </p>
      </div>
    </article>
    <article class="bg-gray-800 rounded-2xl shadow-lg overflow-hidden p-10 article-card article-layout-1" style="animation-delay: 0.5s;">
      <div class="article-image-wrapper">
        <img alt="A person stretching on a yoga mat in a bright studio with natural light" src="https://i.pinimg.com/736x/5f/1d/0f/5f1d0f4d4396e4b27603bc53cd5f6006.jpg" />
      </div>
      <div class="article-text">
        <h2 class="text-3xl font-bold mb-6 text-white cursor-pointer">
          Stretching Routines to Improve Flexibility
        </h2>
        <p class="text-gray-300 mb-6">
          Flexibility is key to preventing injuries and improving overall movement quality. Incorporate these stretching routines into your fitness regimen:
        </p>
        <ul class="list-disc list-inside text-gray-300 mb-6 space-y-2">
          <li><strong>Dynamic Stretching:</strong> Perform leg swings, arm circles, and torso twists before workouts to warm up muscles.</li>
          <li><strong>Static Stretching:</strong> Hold stretches like hamstring, quad, and shoulder stretches for 20-30 seconds post-workout to improve flexibility.</li>
          <li><strong>Yoga Poses:</strong> Incorporate poses such as downward dog, child's pose, and cat-cow to enhance mobility and relaxation.</li>
          <li><strong>Consistency:</strong> Stretch regularly, ideally daily or at least 3-4 times per week, for best results.</li>
        </ul>
        <p class="text-gray-300">
          These routines will help you move better, reduce muscle tightness, and support your fitness goals.
        </p>
      </div>
    </article>
  </main>