<html lang="en">

<head>
  <meta charset="utf-8" />
  <meta content="width=device-width, initial-scale=1" name="viewport" />
  <title>
    FITNESS WEBSITE
  </title>
  <script src="https://cdn.tailwindcss.com">
  </script>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&amp;family=Poppins:wght@600;700&amp;display=swap" rel="stylesheet" />
  <style>
    body {
      font-family: 'Poppins', 'Montserrat', sans-serif;
      background-color: #1F2937;
      color: #F2F2F7;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
      margin: 0;
    }

    /* Animations */
    @keyframes fadeInUp {
      0% {
        opacity: 0;
        transform: translateY(20px);
      }

      100% {
        opacity: 1;
        transform: translateY(0);
      }
    }

    @keyframes pulseButton {

      0%,
      100% {
        transform: scale(1);
      }

      50% {
        transform: scale(1.05);
      }
    }

    @keyframes fadeInScale {
      0% {
        opacity: 0;
        transform: scale(0.95);
      }

      100% {
        opacity: 1;
        transform: scale(1);
      }
    }

    @keyframes slideUpFade {
      0% {
        opacity: 0;
        transform: translateY(30px);
      }

      100% {
        opacity: 1;
        transform: translateY(0);
      }
    }

    .fade-in-up {
      animation: fadeInUp 1s ease forwards;
    }

    .pulse-button {
      animation: pulseButton 2.5s infinite;
    }

    .fade-in-scale {
      animation: fadeInScale 0.8s ease forwards;
    }

    .slide-up-fade {
      animation: slideUpFade 1s ease forwards;
    }

    /* Carousel styles */
    .carousel-container {
      position: relative;
      overflow: hidden;
      border-radius: 0;
      max-width: 100vw;
      height: 100vh;
      background-color: #1F2937;
      /* bg-gray-800 fallback */
      margin-bottom: 4rem;
    }

    .carousel-slide {
      display: none;
      position: absolute;
      inset: 0;
      color: #F2F2F7;
      overflow: hidden;
      opacity: 0;
      transition: opacity 0.8s ease;
      user-select: none;
    }

    .carousel-slide.active {
      display: block;
      opacity: 1;
      animation: fadeInUp 1s ease forwards;
      z-index: 10;
    }

    .carousel-image {
      position: absolute;
      inset: 0;
      width: 100%;
      height: 100%;
      object-fit: cover;
      filter: brightness(0.45);
      transition: filter 0.3s ease;
    }

    .carousel-slide.active .carousel-image {
      filter: brightness(0.45);
    }

    .carousel-content {
      position: relative;
      z-index: 20;
      max-width: 700px;
      padding: 2rem 1.5rem;
      margin: 0 auto;
      top: 50%;
      transform: translateY(-50%);
      text-align: center;
      user-select: none;
      color: #F2F2F7;
      text-shadow: 0 2px 8px rgba(0, 0, 0, 0.8);
      font-family: 'Poppins', sans-serif;
    }

    .carousel-content h1 {
      font-weight: 700;
      font-size: 3.5rem;
      color: #FA7C15;
      /* orange-500 */
      margin-bottom: 1rem;
      line-height: 1.1;
      letter-spacing: 0.02em;
    }

    .carousel-content p {
      color: #F2F2F7;
      /* gray-300 */
      font-size: 1.25rem;
      margin-bottom: 1.5rem;
      text-shadow: 0 1px 6px rgba(0, 0, 0, 0.7);
      font-weight: 500;
      letter-spacing: 0.01em;
    }

    .carousel-buttons {
      display: flex;
      gap: 1rem;
      justify-content: center;
      flex-wrap: wrap;
    }

    .carousel-buttons a {
      font-weight: 700;
      padding: 0.75rem 2.5rem;
      border-radius: 0.5rem;
      box-shadow: 0 10px 15px -3px rgb(251 191 36 / 0.5);
      transition: background-color 0.3s ease;
      cursor: pointer;
      text-decoration: none;
      display: inline-flex;
      align-items: center;
      gap: 0.5rem;
      user-select: none;
      font-size: 1.125rem;
      font-family: 'Poppins', sans-serif;
    }

    .btn-primary {
      background-color: #FA7C15;
      /* orange-500 */
      color: #F2F2F7;
    }

    .btn-primary:hover {
      background-color: #FA7C15;
      /* orange-600 */
    }

    .btn-secondary {
      border: 2px solid #FA7C15;
      color: #FA7C15;
      background-color: transparent;
    }

    .btn-secondary:hover {
      background-color: #FA7C15;
      color: #F2F2F7;
    }

    /* Navigation dots */
    .carousel-dots {
      position: absolute;
      bottom: 2rem;
      left: 50%;
      transform: translateX(-50%);
      display: flex;
      gap: 1rem;
      z-index: 30;
      user-select: none;
    }

    .carousel-dot {
      width: 16px;
      height: 16px;
      background-color: #6b7280;
      /* gray-500 */
      border-radius: 9999px;
      cursor: pointer;
      transition: background-color 0.3s ease;
      box-shadow: 0 0 5px rgba(0, 0, 0, 0.4);
    }

    .carousel-dot.active {
      background-color: #FA7C15;
      /* orange-500 */
      box-shadow: 0 0 12px #FA7C15;
    }

    @media (min-width: 768px) {
      .carousel-content {
        max-width: 700px;
        padding: 3rem 2rem;
        text-align: left;
        margin-left: 4rem;
        top: 50%;
        transform: translateY(-50%);
      }

      .carousel-content h1 {
        font-size: 4rem;
      }

      .carousel-buttons {
        justify-content: flex-start;
      }
    }

    /* Transparent navigation */
    nav {
      background-color: rgba(31, 41, 55, 0.5);
      /* bg-gray-800 with 50% opacity */
      backdrop-filter: saturate(180%) blur(10px);
      -webkit-backdrop-filter: saturate(180%) blur(10px);
      transition: background-color 0.3s ease;
      z-index: 50;
    }

    nav.scrolled {
      background-color: #1F2937;
      /* solid bg-gray-800 */
      backdrop-filter: none;
      -webkit-backdrop-filter: none;
    }

    nav a {
      user-select: none;
      font-family: 'Montserrat', sans-serif;
    }

    nav a:hover {
      color: #FA7C15;
    }

    /* Mobile menu */
    #mobile-menu {
      background-color: rgba(31, 41, 55, 0.9);
      backdrop-filter: saturate(180%) blur(10px);
      -webkit-backdrop-filter: saturate(180%) blur(10px);
    }

    /* Footer styles */
    footer {
      background: linear-gradient(90deg, #FA7C15, #FA7C15);
      padding: 2rem 1rem;
      text-align: center;
      color: #F2F2F7;
      font-weight: 600;
      box-shadow: 0 -4px 10px rgb(234 88 12 / 0.6);
      user-select: none;
      animation: fadeInScale 1.2s ease forwards;
      margin-top: auto;
      font-family: 'Montserrat', sans-serif;
      font-size: 0.9rem;
    }

    footer a {
      color: #fff;
      text-decoration: underline;
      font-weight: 700;
    }

    footer a:hover {
      color: #fbbf24;
    }

    h1,
    h2,
    h3 {
      font-family: 'Poppins', sans-serif;
    }

    p {
      font-family: 'Montserrat', sans-serif;
      line-height: 1.7;
    }

    /* Animations */
    .fade-in-up {
      animation: fadeInUp 1s ease forwards;
    }

    @keyframes fadeInUp {
      0% {
        opacity: 0;
        transform: translateY(20px);
      }

      100% {
        opacity: 1;
        transform: translateY(0);
      }
    }

    .slide-up-fade {
      animation: slideUpFade 1s ease forwards;
    }

    @keyframes slideUpFade {
      0% {
        opacity: 0;
        transform: translateY(30px);
      }

      100% {
        opacity: 1;
        transform: translateY(0);
      }
    }

    .article-card {
      opacity: 0;
      transform: translateY(40px);
      animation-fill-mode: forwards;
      animation-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
    }

    .article-card.animate {
      animation-name: fadeSlideUp;
      animation-duration: 0.8s;
    }

    @keyframes fadeSlideUp {
      0% {
        opacity: 0;
        transform: translateY(40px);
        filter: blur(8px);
      }

      100% {
        opacity: 1;
        transform: translateY(0);
        filter: blur(0);
      }
    }

    /* Image container fixed size with object-contain */
    .article-image-wrapper {
      overflow: hidden;
      border-radius: 1rem;
      max-height: 250px;
      max-width: 100%;
      margin-bottom: 2rem;
      display: flex;
      justify-content: center;
      align-items: center;
      background-color: #313945;
      /* dark bg behind image */
    }

    .article-image-wrapper img {
      max-height: 250px;
      max-width: 100%;
      object-fit: contain;
      transition: transform 0.5s ease;
      display: block;
    }

    .article-image-wrapper:hover img {
      transform: scale(1.05);
    }

    /* Heading underline animation */
    h1,
    h2,
    h3 {
      position: relative;
    }

    h1::after,
    h2::after,
    h3::after {
      content: '';
      position: absolute;
      width: 50px;
      height: 4px;
      background: #FA7C15;
      bottom: -8px;
      left: 0;
      border-radius: 2px;
      transform-origin: left;
      transform: scaleX(0);
      transition: transform 0.4s ease;
    }

    h1:hover::after,
    h2:hover::after,
    h3:hover::after {
      transform: scaleX(1);
    }

    /* Responsive spacing for articles */
    @media (min-width: 768px) {
      main {
        padding-top: 7rem;
        padding-bottom: 5rem;
      }
    }

    /* Layout variations */
    .article-layout-1 {
      display: flex;
      flex-direction: column;
    }

    @media (min-width: 768px) {
      .article-layout-1 {
        flex-direction: row;
        gap: 3rem;
        align-items: center;
      }
    }

    .article-layout-2 {
      display: flex;
      flex-direction: column;
    }

    @media (min-width: 768px) {
      .article-layout-2 {
        flex-direction: row-reverse;
        gap: 3rem;
        align-items: center;
      }
    }

    .article-text {
      flex: 1;
    }

    /* Hero background for header full viewport */
    header.hero-header {
      position: relative;
      width: 100vw;
      height: 100vh;
      background: url('https://i.pinimg.com/736x/5f/1d/0f/5f1d0f4d4396e4b27603bc53cd5f6006.jpg') center center/cover no-repeat;
      display: flex;
      align-items: center;
      justify-content: center;
      margin-top: 4rem;
      border-radius: 0;
      box-shadow: 0 10px 30px rgb(249 115 22 / 0.5);
    }

    header.hero-header::before {
      content: "";
      position: absolute;
      inset: 0;
      background: rgba(31, 41, 55, 0.7);
      z-index: 0;
    }

    header.hero-header h1 {
      position: relative;
      z-index: 10;
      font-size: 4rem;
      font-weight: 700;
      color: #FA7C15;
      text-align: center;
      padding: 0 1rem;
      text-shadow: 0 2px 8px rgba(0, 0, 0, 0.8);
      font-family: 'Poppins', sans-serif;
    }

    @media (max-width: 767px) {
      header.hero-header {
        height: 60vh;
      }

      header.hero-header h1 {
        font-size: 2.5rem;
      }
    }
  </style>
</head>
<?php if ($this->session->flashdata('success')) : ?>
  <div
    id="success-alert"
    class="fixed top-16 left-1/2 transform -translate-x-1/2 z-50 px-6 py-4 rounded-lg bg-green-600 text-#F2F2F7 text-center shadow-lg transition-opacity duration-500 ease-in-out">
    Halo, <strong><?= $this->session->userdata('name'); ?></strong>! <?= $this->session->flashdata('success'); ?>
  </div>
<?php endif; ?>


<body>
  <nav class="fixed w-full z-50 shadow-md transition-colors duration-300" id="navbar">
    <div class="max-w-7xl mx-auto px-6">
      <div class="flex items-center justify-between h-16">
        <div class="flex items-center space-x-4">
          <a class="text-orange-500 text-2xl font-extrabold tracking-wide select-none" href="<?php echo site_url('LandingPage/index') ?>" style="font-family: 'Poppins', sans-serif;">
            FitLife
          </a>
        </div>
        <div class="hidden md:flex space-x-8 font-semibold items-center">
          <!-- Link Home -->
          <a href="<?= site_url('LandingPage/index') ?>"
            class="transition-colors duration-300 select-none <?= ($this->uri->segment(2) == 'index' || $this->uri->segment(2) == '') ? 'text-orange-500' : 'text-gray-300 hover:text-orange-500'; ?>">
            Home
          </a>
          <!-- Link Artikel -->
          <a href="<?= site_url('LandingPage/artikel') ?>"
            class="transition-colors duration-300 select-none <?= ($this->uri->segment(2) == 'artikel') ? 'text-orange-500' : 'text-gray-300 hover:text-orange-500'; ?>">
            Artikel
          </a>
          <?php if ($this->session->userdata('user_id')): ?>
            <!-- Link Dashboard -->
            <a href="<?= site_url('dashboard') ?>"
              class="transition-colors duration-300 text-gray-300 hover:text-orange-500 select-none">
              Dashboard
            </a>
            <!-- User Settings Dropdown -->
            <div class="relative inline-block text-left">
              <!-- User Icon Button -->
              <button aria-label="User settings" id="settings-button"
                class="text-gray-400 hover:text-orange-500 focus:outline-none focus:ring-2 focus:ring-orange-500 rounded-full p-2">
                <i class="fas fa-user fa-lg"></i>
              </button>
              <!-- Dropdown Menu -->
              <div id="settings-menu"
                class="hidden absolute right-0 mt-2 w-48 bg-gray-800 border border-gray-700 rounded-md shadow-lg py-2 z-50">
                <!-- Username Display -->
                <div class="px-4 py-2 border-b border-gray-700">
                  <span class="block text-orange-400 font-semibold text-sm truncate">
                    <i class="fas fa-user-alt mr-3"></i>
                    <?= $user->name ?>
                  </span>
                </div>
                <!-- Logout Button -->
                <button onclick="openLogoutModal()"
                  class="block w-full text-left px-4 py-2 text-gray-300 hover:bg-gray-700 hover:text-red-400 transition-colors duration-150 text-sm">
                  <i class="fas fa-sign-out-alt mr-3"></i>
                  Log out
                </button>

              </div>
            </div>
          <?php else: ?>
            <!-- Login Button -->
            <a href="<?= site_url('auth/login') ?>"
              class="transition-colors duration-300 flex items-center space-x-1 text-gray-300 hover:text-orange-500 select-none <?= ($this->uri->segment(1) == 'Auth') ? 'text-orange-500' : ''; ?>">
              <i class="fas fa-sign-in-alt"></i>
              <span>Login</span>
            </a>
          <?php endif; ?>
        </div>
        <div class="md:hidden">
          <button aria-label="Toggle menu" class="focus:outline-none" id="menu-btn">
            <i class="fas fa-bars text-2xl text-gray-300"></i>
          </button>
        </div>
      </div>
    </div>

    <!-- Mobile Menu -->
    <div class="hidden md:hidden px-6 pb-4" id="mobile-menu">
      <!-- Link Home -->
      <a href="<?= site_url('LandingPage/index') ?>"
        class="block py-2 font-semibold select-none <?= ($this->uri->segment(2) == 'index' || $this->uri->segment(2) == '') ? 'text-orange-500' : 'text-gray-300 hover:text-orange-500'; ?>">
        Home
      </a>

      <!-- Link Artikel -->
      <a href="<?= site_url('LandingPage/artikel') ?>"
        class="block py-2 font-semibold select-none <?= ($this->uri->segment(2) == 'artikel') ? 'text-orange-500' : 'text-gray-300 hover:text-orange-500'; ?>">
        Artikel
      </a>

      <?php if ($this->session->userdata('user_id')): ?>
        <!-- Link Dashboard -->
        <a href="<?= site_url('dashboard') ?>"
          class="block py-2 font-semibold text-gray-300 hover:text-orange-500 transition-colors">
          Dashboard
        </a>

        <!-- Nama User (opsional) -->
        <div class="py-2 px-2 text-sm text-orange-400 font-semibold border-t border-gray-700">
          <i class="fas fa-user-alt mr-3"></i>
          <?= $user->name ?>
        </div>

        <!-- Logout Button -->
        <button onclick="openLogoutModal()"
          class="block w-full text-left px-4 py-2 text-gray-300 hover:bg-gray-700 hover:text-red-400 transition-colors duration-150 text-sm">
          <i class="fas fa-sign-out-alt mr-3"></i>
          Log out
        </button>

      <?php else: ?>
        <!-- Login -->
        <a href="<?= site_url('auth/login') ?>"
          class="block py-2 font-semibold flex items-center space-x-1 text-gray-300 hover:text-orange-500 select-none <?= ($this->uri->segment(1) == 'Auth') ? 'text-orange-500' : ''; ?>">
          <i class="fas fa-sign-in-alt"></i>
          <span>Login</span>
        </a>
      <?php endif; ?>
    </div>

  </nav>



  <!-- Modal Konfirmasi Logout -->
  <div id="logoutModal" class="fixed inset-0 z-50 bg-black bg-opacity-60 hidden justify-center items-center">
    <div class="bg-gray-800 text-#F2F2F7 rounded-xl p-6 w-full max-w-sm shadow-2xl border border-gray-700">
      <h2 class="text-xl font-bold text-orange-500 mb-2">Konfirmasi Logout</h2>
      <p class="text-gray-300 mb-6">Apakah kamu yakin ingin log out?</p>
      <div class="flex justify-end gap-3">
        <button onclick="closeLogoutModal()" class="px-4 py-2 rounded-lg bg-gray-700 hover:bg-gray-600 text-#F2F2F7 transition duration-150">
          Batal
        </button>
        <a href="<?= site_url('auth/logout') ?>" class="px-4 py-2 rounded-lg bg-red-600 hover:bg-red-700 text-#F2F2F7 transition duration-150">
          Ya, Logout
        </a>
      </div>
    </div>
  </div>



  <script>
    function openLogoutModal() {
      document.getElementById('logoutModal').classList.remove('hidden');
      document.getElementById('logoutModal').classList.add('flex');
    }

    function closeLogoutModal() {
      document.getElementById('logoutModal').classList.add('hidden');
      document.getElementById('logoutModal').classList.remove('flex');
    }
  </script>

  <script>
    setTimeout(function() {
      const alert = document.getElementById('success-alert');
      if (alert) {
        alert.classList.add('opacity-0');
        setTimeout(() => alert.remove(), 500); // Hilangkan elemen setelah efek fade
      }
    }, 3000); // 3 detik
  </script>