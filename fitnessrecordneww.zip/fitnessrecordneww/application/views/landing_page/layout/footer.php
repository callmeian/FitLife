 <footer>
   <div class="max-w-7xl mx-auto px-6 text-center text-white text-sm select-none">
     © 2025 Fitness. All rights reserved. &nbsp;|&nbsp;
     <a href="#" class="hover:text-yellow-300 transition-colors duration-300">Privacy Policy</a> &nbsp;|&nbsp;
     <a href="#" class="hover:text-yellow-300 transition-colors duration-300">Terms of Service</a>
   </div>
 </footer>
 <script>
   document.addEventListener('DOMContentLoaded', function() {
     // Navbar toggle
     const menuBtn = document.getElementById('menu-btn');
     const mobileMenu = document.getElementById('mobile-menu');
     const navbar = document.getElementById('navbar');

     if (menuBtn && mobileMenu) {
       menuBtn.addEventListener('click', () => {
         mobileMenu.classList.toggle('hidden');
       });
     }

     // Navbar scroll behavior
     window.addEventListener('scroll', () => {
       if (window.scrollY > 50) {
         navbar.classList.add('scrolled');
       } else {
         navbar.classList.remove('scrolled');
       }

       animateArticles(); // Panggil fungsi animasi artikel saat scroll
     });

     // Carousel
     const slides = document.querySelectorAll('.carousel-slide');
     const dots = document.querySelectorAll('.carousel-dot');
     let currentIndex = 0;
     let slideInterval;

     function showSlide(index) {
       slides.forEach((slide, i) => {
         const isActive = i === index;
         slide.classList.toggle('active', isActive);
         dots[i].classList.toggle('active', isActive);
         dots[i].setAttribute('tabindex', isActive ? '0' : '-1');
         slide.setAttribute('aria-hidden', !isActive);
         slide.setAttribute('tabindex', isActive ? '0' : '-1');
       });
       currentIndex = index;
     }

     function nextSlide() {
       let nextIndex = (currentIndex + 1) % slides.length;
       showSlide(nextIndex);
     }

     if (dots.length > 0) {
       dots.forEach(dot => {
         dot.addEventListener('click', () => {
           clearInterval(slideInterval);
           showSlide(parseInt(dot.dataset.index));
           slideInterval = setInterval(nextSlide, 7000);
         });
         dot.addEventListener('keydown', e => {
           if (e.key === 'Enter' || e.key === ' ') {
             e.preventDefault();
             dot.click();
           }
         });
       });
       slideInterval = setInterval(nextSlide, 7000);
     }

     // Animate articles on scroll
     const articles = document.querySelectorAll('.article-card');

     function isInViewport(el) {
       const rect = el.getBoundingClientRect();
       return rect.top <= (window.innerHeight || document.documentElement.clientHeight) - 100;
     }

     function animateArticles() {
       articles.forEach((article, index) => {
         if (isInViewport(article) && !article.classList.contains('animate')) {
           setTimeout(() => {
             article.classList.add('animate');
           }, index * 150);
         }
       });
     }

     // Jalankan saat load juga
     animateArticles();

     // Sidebar mobile menu & settings (jika ada)
     const mobileMenuButton = document.getElementById('mobile-menu-button');
     const mobileMenuClose = document.getElementById('mobile-menu-close');
     const settingsButton = document.getElementById('settings-button');
     const settingsMenu = document.getElementById('settings-menu');

     if (mobileMenuButton && mobileMenu && mobileMenuClose) {
       mobileMenuButton.addEventListener('click', () => {
         mobileMenu.classList.remove('-translate-x-full');
       });

       mobileMenuClose.addEventListener('click', () => {
         mobileMenu.classList.add('-translate-x-full');
       });

       window.addEventListener('click', (e) => {
         if (!mobileMenu.contains(e.target) && !mobileMenuButton.contains(e.target)) {
           if (!mobileMenu.classList.contains('-translate-x-full')) {
             mobileMenu.classList.add('-translate-x-full');
           }
         }
       });
     }

     if (settingsButton && settingsMenu) {
       settingsButton.addEventListener('click', (e) => {
         e.stopPropagation();
         settingsMenu.classList.toggle('hidden');
       });

       window.addEventListener('click', (e) => {
         if (!settingsMenu.contains(e.target) && !settingsButton.contains(e.target)) {
           if (!settingsMenu.classList.contains('hidden')) {
             settingsMenu.classList.add('hidden');
           }
         }
       });
     }
   });
 </script>
 </body>

 </html>