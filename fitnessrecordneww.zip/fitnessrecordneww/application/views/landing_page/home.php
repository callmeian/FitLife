  <header class="pt-16 w-full flex-grow">
    <div class="carousel-container mx-auto relative" role="region" aria-label="Fitness promotional carousel">
      <div class="carousel-slide active" data-index="0" role="tabpanel" aria-hidden="false" tabindex="0">
        <img alt="A fit man jogging outdoors on a trail during sunrise, wearing athletic workout clothes, showing fitness and workout motivation" class="carousel-image" src="https://i.pinimg.com/736x/5f/1d/0f/5f1d0f4d4396e4b27603bc53cd5f6006.jpg" />
        <div class="carousel-content">
          <h1>
            Transform Your Body, Transform Your Life
          </h1>
          <p>
            Join FitLife and start your fitness journey today. Expert guidance, motivating community, and personalized workouts await you.
          </p>
          <div class="carousel-buttons">
            <a class="btn-primary pulse-button" href="<?php echo site_url('Auth/login') ?>" tabindex="0">
              Get Started
            </a>
            <a class="btn-secondary flex items-center" href="<?php echo site_url('LandingPage/artikel') ?>" tabindex="0">
              <i class="fas fa-info-circle"></i>
              <span>Learn More</span>
            </a>
          </div>
        </div>
      </div>
      <div class="carousel-slide" data-index="1" role="tabpanel" aria-hidden="true" tabindex="-1">
        <img alt="A muscular man performing pull ups facing away from the camera, showing his back muscles and workout strength in a gym setting with dark moody lighting" class="carousel-image" src="https://i.pinimg.com/736x/39/5a/ab/395aabc02419ce4158541aee03d26681.jpg" />
        <div class="carousel-content">
          <h1>
            Build Strength and Endurance
          </h1>
          <p>
            Access tailored workout plans designed to help you gain muscle and improve stamina.
          </p>
          <div class="carousel-buttons">
            <a class="btn-primary pulse-button" href="<?php echo site_url('Auth/login') ?>" tabindex="0">
              Get Started
            </a>
            <a class="btn-secondary flex items-center" href="<?php echo site_url('LandingPage/artikel') ?>" tabindex="0">
              <i class="fas fa-info-circle"></i>
              <span>Learn More</span>
            </a>
          </div>
        </div>
      </div>
      <div class="carousel-slide" data-index="2" role="tabpanel" aria-hidden="true" tabindex="-1">
        <img alt="Healthy meal prep with colorful vegetables and lean proteins on a wooden table" class="carousel-image" src="https://i.pinimg.com/736x/cf/59/2a/cf592a190a351b337252d64333746db8.jpg" />
        <div class="carousel-content">
          <h1>
            Nutrition to Fuel Your Gains
          </h1>
          <p>
            Discover meal plans and nutrition tips to support your fitness goals and recovery.
          </p>
          <div class="carousel-buttons">
            <a class="btn-primary pulse-button" href="<?php echo site_url('Auth/login') ?>" tabindex="0">
              Get Started
            </a>
            <a class="btn-secondary flex items-center" href="<?php echo site_url('LandingPage/artikel') ?>" tabindex="0">
              <i class="fas fa-info-circle"></i>
              <span>Learn More</span>
            </a>
          </div>
        </div>
      </div>
      <div class="carousel-dots" role="tablist" aria-label="Carousel navigation">
        <button aria-label="Slide 1" class="carousel-dot active" data-index="0" role="tab" tabindex="0"></button>
        <button aria-label="Slide 2" class="carousel-dot" data-index="1" role="tab" tabindex="-1"></button>
        <button aria-label="Slide 3" class="carousel-dot" data-index="2" role="tab" tabindex="-1"></button>
      </div>
    </div>
  </header>
  <section class="max-w-7xl mx-auto px-6 mt-20 mb-20">
    <h2 class="text-3xl font-extrabold text-orange-500 mb-10 text-center fade-in-up" style="font-family: 'Poppins', sans-serif;">
      Latest Articles
    </h2>
    <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
      <article class="bg-gray-800 rounded-2xl shadow-lg overflow-hidden hover:shadow-orange-500/50 transition-shadow duration-300 slide-up-fade" style="font-family: 'Montserrat', sans-serif;">
        <img alt="Fitness article cover showing a person lifting weights in a gym with intense focus" class="w-full h-48 object-cover" height="400" src="https://i.pinimg.com/736x/39/5a/ab/395aabc02419ce4158541aee03d26681.jpg" width="600" />
        <div class="p-6">
          <h3 class="text-xl font-bold mb-2 text-white">
            5 Tips to Boost Your Workout Performance
          </h3>
          <p class="text-gray-400 text-sm mb-4">
            Learn how to maximize your training sessions with these expert tips.
          </p>
          <a class="text-orange-500 font-semibold hover:underline" href="<?php echo site_url('LandingPage/artikel') ?>">
            Read More →
          </a>
        </div>
      </article>
      <article class="bg-gray-800 rounded-2xl shadow-lg overflow-hidden hover:shadow-orange-500/50 transition-shadow duration-300 slide-up-fade" style="animation-delay: 0.2s; font-family: 'Montserrat', sans-serif;">
        <img alt="Healthy meal prep with colorful vegetables and lean proteins on a wooden table" class="w-full h-48 object-cover" height="400" src="https://i.pinimg.com/736x/cf/59/2a/cf592a190a351b337252d64333746db8.jpg" width="600" />
        <div class="p-6">
          <h3 class="text-xl font-bold mb-2 text-white">
            Nutrition Guide for Muscle Growth
          </h3>
          <p class="text-gray-400 text-sm mb-4">
            Discover the best foods to fuel your gains and recovery.
          </p>
          <a class="text-orange-500 font-semibold hover:underline" href="<?php echo site_url('LandingPage/artikel') ?>">
            Read More →
          </a>
        </div>
      </article>
      <article class="bg-gray-800 rounded-2xl shadow-lg overflow-hidden hover:shadow-orange-500/50 transition-shadow duration-300 slide-up-fade" style="animation-delay: 0.4s; font-family: 'Montserrat', sans-serif;">
        <img alt="A person stretching on a yoga mat in a bright studio with natural light" class="w-full h-48 object-cover" height="400" src="https://i.pinimg.com/736x/5f/1d/0f/5f1d0f4d4396e4b27603bc53cd5f6006.jpg" width="600" />
        <div class="p-6">
          <h3 class="text-xl font-bold mb-2 text-white">
            Stretching Routines to Improve Flexibility
          </h3>
          <p class="text-gray-400 text-sm mb-4">
            Simple stretches to enhance your mobility and prevent injuries.
          </p>
          <a class="text-orange-500 font-semibold hover:underline" href="<?php echo site_url('LandingPage/artikel') ?>">
            Read More →
          </a>
        </div>
      </article>
    </div>
  </section>