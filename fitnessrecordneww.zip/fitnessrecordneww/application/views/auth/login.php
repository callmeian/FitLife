<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <meta content="width=device-width, initial-scale=1" name="viewport" />
  <title>Fitness Login</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap" rel="stylesheet" />
  <style>
    body {
      font-family: 'Montserrat', sans-serif;
    }

    @keyframes fadeInSlide {
      0% {
        opacity: 0;
        transform: translateX(-30px);
      }

      100% {
        opacity: 1;
        transform: translateX(0);
      }
    }

    @keyframes bouncePulse {

      0%,
      100% {
        transform: scale(1);
      }

      50% {
        transform: scale(1.05);
      }
    }

    @keyframes shake {

      0%,
      100% {
        transform: translateX(0);
      }

      20%,
      60% {
        transform: translateX(-5px);
      }

      40%,
      80% {
        transform: translateX(5px);
      }
    }

    .fade-in-slide {
      animation: fadeInSlide 1s ease forwards;
    }

    .bounce-pulse {
      animation: bouncePulse 2.5s infinite;
    }

    input:focus {
      animation: shake 0.3s ease;
    }

    @keyframes fadeIn {
      from {
        opacity: 0;
        transform: translateY(-10px);
      }

      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    .animate-fadeIn {
      animation: fadeIn 0.5s ease-out forwards;
    }
  </style>
</head>

<body class="bg-gray-900 min-h-screen flex items-center justify-center px-4">
  <div class="max-w-6xl w-full bg-gray-800 rounded-3xl shadow-lg overflow-hidden grid grid-cols-1 md:grid-cols-2">

    <!-- LEFT IMAGE SIDE -->
    <div class="hidden md:flex flex-col justify-center bg-gray-900 p-12 relative fade-in-slide">
      <img class="rounded-2xl object-cover w-full h-full" src="https://i.pinimg.com/736x/79/fa/43/79fa431f228ff2d9b0c767f6e4a6d876.jpg" alt="Workout image" />
      <div class="absolute bottom-8 left-8 text-white bg-gradient-to-t from-black/70 to-transparent p-4 rounded-lg max-w-xs">
        <h2 class="text-3xl font-bold mb-2">Get Stronger Every Day</h2>
        <p class="text-gray-300 text-sm">Join our community and start your fitness journey with expert guidance and motivation.</p>
      </div>
    </div>

    <!-- LOGIN FORM -->
    <div class="p-10 md:p-16 flex flex-col justify-center bg-gray-800">
      <!-- Flash Messages -->
      <?php if ($this->session->flashdata('success')): ?>
        <div class="mb-4 p-4 bg-green-600 text-white rounded-lg shadow animate-fadeIn">
          <i class="fas fa-check-circle mr-2"></i><?= $this->session->flashdata('success') ?>
        </div>
      <?php endif; ?>

      <?php if ($this->session->flashdata('error')): ?>
        <div class="mb-4 p-4 bg-red-600 text-white rounded-lg shadow animate-fadeIn">
          <i class="fas fa-times-circle mr-2"></i><?= $this->session->flashdata('error') ?>
        </div>
      <?php endif; ?>

      <?php if (!empty($validation_errors = validation_errors())): ?>
        <div class="mb-4 p-4 bg-yellow-500 text-white rounded-lg shadow animate-fadeIn">
          <i class="fas fa-exclamation-triangle mr-2"></i><?= $validation_errors ?>
        </div>
      <?php endif; ?>

      <h1 class="text-4xl font-extrabold text-orange-500 mb-6 text-center md:text-left fade-in-slide" style="animation-delay: 0.3s;">Fitness Login</h1>

      <?php echo form_open('auth/login', ['class' => 'space-y-6', 'novalidate' => '']); ?>

      <!-- Email -->
      <div>
        <label class="block text-gray-300 font-semibold mb-2" for="email">Email Address</label>
        <div class="relative">
          <input class="w-full rounded-lg bg-gray-700 text-white placeholder-gray-400 py-3 px-4 pr-12 focus:outline-none focus:ring-2 focus:ring-orange-500"
            id="email" name="email" placeholder="you@example.com" type="email" value="<?= set_value('email') ?>" required />
          <span class="absolute inset-y-0 right-3 flex items-center text-orange-500">
            <i class="fas fa-envelope"></i>
          </span>
        </div>
        <?php echo form_error('email', '<p class="text-sm text-red-400 mt-1 italic animate-fadeIn">', '</p>'); ?>
      </div>

      <!-- Password -->
      <div>
        <label class="block text-gray-300 font-semibold mb-2" for="password">Password</label>
        <div class="relative">
          <input class="w-full rounded-lg bg-gray-700 text-white placeholder-gray-400 py-3 px-4 pr-12 focus:outline-none focus:ring-2 focus:ring-orange-500"
            id="password" name="password" placeholder="Enter your password" type="password" required />
          <span class="absolute inset-y-0 right-3 flex items-center text-orange-500 cursor-pointer" onclick="togglePassword()">
            <i class="fas fa-eye" id="eyeIcon"></i>
          </span>
        </div>
        <?php echo form_error('password', '<p class="text-sm text-red-400 mt-1 italic animate-fadeIn">', '</p>'); ?>
      </div>

      <!-- Remember -->
      <div class="flex items-center justify-between text-sm text-gray-400">
        <label class="flex items-center space-x-2">
          <input class="rounded border-gray-600 bg-gray-700 text-orange-500 focus:ring-orange-500" name="remember" type="checkbox" />
          <span>Remember me</span>
        </label>
      </div>

      <!-- Submit -->
      <button class="w-full bg-orange-500 hover:bg-orange-600 text-white font-bold py-3 rounded-lg shadow-md transition-colors duration-300 bounce-pulse" type="submit">
        Sign In
      </button>

      <?php echo form_close(); ?>

      <!-- Footer Links -->
      <p class="mt-2 text-center text-gray-400">
        Don't have an account?
        <a class="text-orange-500 font-semibold hover:underline" href="<?php echo site_url('Auth/register') ?>">Sign Up</a>
      </p>

      <br><br>
      <a class="text-red-500 hover:underline text-center block" href="<?php echo site_url('LandingPage') ?>">
        Back to home
      </a>
    </div>
  </div>

  <!-- Toggle Password Script -->
  <script>
    function togglePassword() {
      const passwordInput = document.getElementById('password');
      const eyeIcon = document.getElementById('eyeIcon');
      if (passwordInput.type === 'password') {
        passwordInput.type = 'text';
        eyeIcon.classList.remove('fa-eye');
        eyeIcon.classList.add('fa-eye-slash');
      } else {
        passwordInput.type = 'password';
        eyeIcon.classList.remove('fa-eye-slash');
        eyeIcon.classList.add('fa-eye');
      }
    }
  </script>
</body>

</html>