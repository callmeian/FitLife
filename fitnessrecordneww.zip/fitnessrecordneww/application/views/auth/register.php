<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Fitness Registration</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap" rel="stylesheet" />
  <style>
    body {
      font-family: 'Montserrat', sans-serif;
    }

    @keyframes fadeInSlide {
      0% {
        opacity: 0;
        transform: translateY(30px);
      }

      100% {
        opacity: 1;
        transform: translateY(0);
      }
    }

    @keyframes bouncePulse {

      0%,
      100% {
        transform: scale(1);
      }

      50% {
        transform: scale(1.05);
      }
    }

    @keyframes shake {

      0%,
      100% {
        transform: translateX(0);
      }

      20%,
      60% {
        transform: translateX(-5px);
      }

      40%,
      80% {
        transform: translateX(5px);
      }
    }

    .fade-in-slide {
      animation: fadeInSlide 1s ease forwards;
    }

    .bounce-pulse {
      animation: bouncePulse 2.5s infinite;
    }

    input:focus {
      animation: shake 0.3s ease;
    }
  </style>
</head>

<body class="bg-gray-900 min-h-screen flex items-center justify-center px-4">
  <div class="max-w-5xl w-full bg-gray-800 rounded-3xl shadow-lg overflow-hidden grid grid-cols-1 md:grid-cols-3">
    <div class="col-span-1 md:col-span-2 p-10 md:p-16 flex flex-col justify-center bg-gray-900 rounded-l-3xl">
      <h1 class="text-4xl font-extrabold text-orange-500 mb-8 text-center md:text-left fade-in-slide" style="animation-delay: 0.3s;">
        Create Your Account
      </h1>

      <?php if ($this->session->flashdata('error')): ?>
        <div class="bg-red-500/10 border border-red-500 text-red-500 px-4 py-3 rounded-lg mb-6 animate-pulse">
          <p><i class="fas fa-exclamation-circle mr-2"></i><?= $this->session->flashdata('error'); ?></p>
        </div>
      <?php endif; ?>

      <form class="space-y-6" method="POST" action="<?= site_url('auth/register') ?>" novalidate="">
        <div>
          <label class="block text-gray-300 font-semibold mb-2" for="fullname">Full Name</label>
          <div class="relative">
            <input class="w-full rounded-lg bg-gray-700 text-white placeholder-gray-400 py-3 px-4 pr-12 focus:outline-none focus:ring-2 focus:ring-orange-500" id="name" name="name" placeholder="Your full name" value="<?= set_value('name') ?>" type="text" />
            <span class="absolute inset-y-0 right-3 flex items-center text-orange-500"><i class="fas fa-user"></i></span>
          </div>
          <?= form_error('name', '<p class="text-sm text-red-400 mt-1 italic">', '</p>'); ?>
        </div>

        <div>
          <label class="block text-gray-300 font-semibold mb-2" for="email">Email Address</label>
          <div class="relative">
            <input class="w-full rounded-lg bg-gray-700 text-white placeholder-gray-400 py-3 px-4 pr-12 focus:outline-none focus:ring-2 focus:ring-orange-500" id="email" name="email" placeholder="you@example.com" value="<?= set_value('email') ?>" type="email" />
            <span class="absolute inset-y-0 right-3 flex items-center text-orange-500"><i class="fas fa-envelope"></i></span>
          </div>
          <?= form_error('email', '<p class="text-sm text-red-400 mt-1 italic">', '</p>'); ?>
        </div>

        <div>
          <label class="block text-gray-300 font-semibold mb-2" for="password">Password</label>
          <div class="relative">
            <input class="w-full rounded-lg bg-gray-700 text-white placeholder-gray-400 py-3 px-4 pr-12 focus:outline-none focus:ring-2 focus:ring-orange-500" id="password" name="password" placeholder="Create a password" type="password" />
            <span class="absolute inset-y-0 right-3 flex items-center text-orange-500 cursor-pointer" onclick="togglePassword()">
              <i class="fas fa-eye" id="eyeIcon"></i>
            </span>
          </div>
          <?= form_error('password', '<p class="text-sm text-red-400 mt-1 italic">', '</p>'); ?>
        </div>

        <div class="flex items-center text-sm text-gray-400">
          <label class="flex items-center space-x-2">
            <input class="rounded border-gray-600 bg-gray-700 text-orange-500 focus:ring-orange-500" name="terms" type="checkbox" />
            <span>I agree to the <a class="text-orange-400 hover:underline" href="#">Terms & Conditions</a></span>
          </label>
          <?= form_error('terms', '<p class="text-sm text-red-400 ml-3 italic">', '</p>'); ?>
        </div>

        <button class="w-full bg-orange-500 hover:bg-orange-600 text-white font-bold py-3 rounded-lg shadow-md transition-colors duration-300 bounce-pulse" type="submit">
          Register
        </button>
      </form>

      <p class="mt-8 text-center text-gray-400">
        Already have an account?
        <a class="text-orange-500 font-semibold hover:underline" href="<?= site_url('auth/login') ?>">Sign In</a>
      </p>
    </div>

    <div class="hidden md:flex flex-col justify-center bg-gradient-to-b from-orange-600 via-orange-700 to-orange-800 p-12 relative rounded-r-3xl fade-in-slide">
      <img alt="A fit man jogging outdoors on a trail during sunrise" class="rounded-2xl object-cover w-full h-96 shadow-lg" src="https://i.pinimg.com/736x/fd/7c/82/fd7c82337d855325804ae9dd0b8a9cc7.jpg" />
      <div class="mt-8 text-white">
        <h2 class="text-3xl font-bold mb-2">Start Your Journey</h2>
        <p class="text-orange-200 text-sm max-w-xs">Sign up today and take the first step towards a healthier, stronger you.</p>
      </div>
    </div>
  </div>

  <script>
    function togglePassword() {
      const passwordInput = document.getElementById('password');
      const eyeIcon = document.getElementById('eyeIcon');
      if (passwordInput.type === 'password') {
        passwordInput.type = 'text';
        eyeIcon.classList.remove('fa-eye');
        eyeIcon.classList.add('fa-eye-slash');
      } else {
        passwordInput.type = 'password';
        eyeIcon.classList.remove('fa-eye-slash');
        eyeIcon.classList.add('fa-eye');
      }
    }
  </script>
</body>

</html>