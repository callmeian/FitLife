  <!-- Main Content -->
  <main class="flex-grow ml-0 sm:ml-64 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 pb-24">
    <h2 class="text-3xl font-bold text-orange-500 mb-8 flex items-center">
      <i class="fas fa-users mr-3"></i>
      </i>
      Komunitas
    </h2>
    <section>
      <!-- Community Intro -->
      <div class="mb-8">
        <h3 class="text-xl font-semibold text-white mb-2">
          Welcome to the Fitness Community
        </h3>
        <p class="text-gray-400 max-w-3xl">
          Connect with fellow fitness enthusiasts, share your progress, ask questions, and get motivated!
        </p>
      </div>
      <!-- Create Post -->
      <div class="bg-gray-800 rounded-lg p-6 mb-8 shadow-md">
        <h4 class="text-lg font-semibold text-white mb-4">
          Create a Post
        </h4>
        <form method="POST" action="<?= site_url('community/create_post') ?>" class="space-y-4">
          <textarea name="content" class="w-full rounded-md bg-gray-700 text-gray-200 placeholder-gray-400 p-3 resize-none focus:outline-none focus:ring-2 focus:ring-orange-500" placeholder="Tulis sesuatu..." rows="3"></textarea>
          <div class="flex justify-end">
            <button class="bg-orange-600 hover:bg-orange-700 text-white font-semibold px-5 py-2 rounded-md transition" type="submit">
              Post
            </button>
          </div>
        </form>
      </div>
      <div class="space-y-6">
        <?php foreach ($posts as $post): ?>
          <article class="bg-gray-800 rounded-lg p-6 shadow-md">
            <header class="flex items-center space-x-4 mb-4">
              <div class="h-12 w-12 rounded-full bg-gray-700 flex items-center justify-center text-white font-semibold select-none">
                <?= strtoupper(substr($post->name, 0, 1)) ?>
              </div>
              <div>
                <h5 class="text-white font-semibold">
                  <?= htmlspecialchars($post->name) ?>
                </h5>
                <time class="text-gray-400 text-sm">
                  <?= date('F j, Y · g:i A', strtotime($post->created_at)) ?>
                </time>
              </div>
            </header>
            <p class="text-gray-300 mb-4">
              <?= nl2br(htmlspecialchars($post->content)) ?>
            </p>

            <?php if ($this->session->userdata('user_id') == $post->user_id): ?>
              <form action="<?= site_url('Community/delete_post/' . $post->id) ?>" method="POST" onsubmit="return confirm('Yakin ingin menghapus post ini?');">
                <button type="submit" class="text-red-500 hover:text-red-700 font-semibold">
                  <i class="fas fa-trash-alt"></i>
                </button>
              </form>
            <?php endif; ?>
          </article>
        <?php endforeach; ?>
      </div>
    </section>
  </main>