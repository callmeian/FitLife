<br>
<main class="ml-0 sm:ml-64 px-4 sm:px-6 lg:px-8 pt-2 pb-12 min-h-screen flex flex-col">
    <h2 class="text-3xl font-bold text-orange-500 mb-4 flex items-center">
        <i class="fas fa-dumbbell mr-3"></i>
        Level Olahraga
    </h2>
    <h2 class="font-semibold text-white mb-4 text-base">
        Pilih Level untuk Otot: <?= ucfirst($muscle) ?>
    </h2>
    <br>
    <div class="flex flex-col items-center mt-0 space-y-12 w-full max-w-xs mx-auto">
        <a href="<?= site_url('Olahraga/menu/' . $muscle . '/pemula') ?>"
            class="flex justify-center items-center bg-transparent border-4 border-[#f77f17] text-[#f77f17] font-semibold text-xl rounded-2xl px-20 py-8 w-full shadow-inner hover:bg-[#f77f17] hover:text-white transition-colors duration-300">
            Pemula
        </a>
        <a href="<?= site_url('Olahraga/menu/' . $muscle . '/mahir') ?>"
            class="flex justify-center items-center bg-transparent border-4 border-[#f77f17] text-[#f77f17] font-semibold text-xl rounded-2xl px-20 py-8 w-full shadow-inner hover:bg-[#f77f17] hover:text-white transition-colors duration-300">
            Mahir
        </a>
    </div>
</main>