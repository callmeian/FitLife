<main class="flex-grow ml-0 sm:ml-64 max-w-full mx-auto px-4 sm:px-6 lg:px-8 py-12 pb-24">
  <h2 class="text-3xl font-bold text-orange-500 mb-4 flex items-center">
    <i class="fas fa-dumbbell mr-5"></i>
    <?= ucfirst($muscle) ?> (Level: <?= ucfirst($level) ?>)
  </h2>

  <section class="flex flex-col max-w-5xl mx-auto">
    <p class="font-semibold text-white mb-4 text-base">
      Menu Olahraga : 2 Latihan
    </p>

    <div class="space-y-12">
      <?php foreach ($exercises as $exercise): ?>
        <div class="flex items-center space-x-8">
          <img
            alt="Muscular man side view showing abs and arm muscles in gym environment"
            class="w-[240px] h-[180px] rounded-xl object-cover flex-shrink-0"
            src="https://storage.googleapis.com/a1aa/image/a1c05f6d-8e75-4a27-72be-55aa80efa4bd.jpg"
            width="240"
            height="180"
          />
          <div>
            <p class="text-white font-semibold text-2xl">
              <?= $exercise->nama_latihan ?> - <?= $exercise->durasi ?> menit
            </p>
            <p class="text-white text-xl">
              12 x 2 set
            </p>
            <a href="<?= site_url('Olahraga/timer/' . $exercise->id) ?>">
              <button class="bg-[#f97316] text-white font-semibold rounded-full px-10 py-4 mt-3 text-xl">
                Mulai
              </button>
            </a>
          </div>
        </div>
      <?php endforeach; ?>
    </div>

    <div class="flex items-center mt-16 space-x-4 text-white font-semibold text-xl">
      <i class="fas fa-stopwatch fa-lg"></i>
      <span>15 Minutes</span>
    </div>

    <!-- Tombol Back mepet kanan -->
    <div class="flex justify-center sm:justify-end mt-10">
      <a href="<?= site_url('Olahraga/level/' . $muscle) ?>" class="bg-[#ff4a00] text-white font-semibold rounded-full px-10 py-4 text-xl" type="button">
        Back
      </a>
    </div>
  </section>
</main>
