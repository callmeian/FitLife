<!-- Main content -->
   <main class="flex-grow ml-0 sm:ml-64 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 pb-24">
      <h2 class="text-3xl font-bold text-orange-500 mb-8 flex items-center">
         <i class="fas fa-dumbbell mr-3">
         </i>
         Olahraga
      </h2>
      <section>
         <h2 class="font-semibold text-white mb-4 text-base">
            Fokus Tubuh
         </h2>
         <div class="grid grid-cols-2 gap-4 max-w-4xl">
            <a href="<?= site_url('Olahraga/level/perut') ?>" class="relative rounded-xl overflow-hidden block border border-transparent hover:border-[#F47C20] transition-colors duration-300">
               <img alt="Muscular male torso side view showing well-defined abdominal muscles" class="w-full h-auto rounded-xl object-cover" height="200" src="https://i.pinimg.com/736x/ee/30/2c/ee302c46fb7864e276d02dcc21e4d5bb.jpg" width="400" />
               <div class="absolute bottom-3 left-3 text-white font-semibold text-lg drop-shadow-lg">
                  Otot perut
               </div>
            </a>
            <a href="<?= site_url('Olahraga/level/lengan') ?>" class="relative rounded-xl overflow-hidden block border border-transparent hover:border-[#F47C20] transition-colors duration-300">
               <img alt="Veiny muscular arm with clenched fist on black background" class="w-full h-auto rounded-xl object-cover" height="200" src="https://i.pinimg.com/736x/a0/05/43/a00543613a36b4ce059fd36359b51258.jpg" width="400" />
               <div class="absolute bottom-3 left-3 text-white font-semibold text-lg drop-shadow-lg">
                  Lengan
               </div>
            </a>
            <a href="<?= site_url('Olahraga/level/dada') ?>" class="relative rounded-xl overflow-hidden block border border-transparent hover:border-[#F47C20] transition-colors duration-300">
               <img alt="Muscular male chest front view showing well-defined pectoral muscles" class="w-full h-auto rounded-xl object-cover" height="200" src="https://i.pinimg.com/736x/5d/a5/01/5da5010f894364596651823f171e0134.jpg" width="400" />
               <div class="absolute bottom-3 left-3 text-white font-semibold text-lg drop-shadow-lg">
                  Dada
               </div>
            </a>
            <a href="<?= site_url('Olahraga/level/kaki') ?>" class="relative rounded-xl overflow-hidden block border border-transparent hover:border-[#F47C20] transition-colors duration-300">
               <img alt="Muscular calf legs back view in gym environment" class="w-full h-auto rounded-xl object-cover" height="200" src="https://i.pinimg.com/736x/4d/e4/91/4de4919c964fcb8c481124ab77498cb6.jpg" width="400" />
               <div class="absolute bottom-3 left-3 text-white font-semibold text-lg drop-shadow-lg">
                  Kaki
               </div>
            </a>
            <a href="<?= site_url('Olahraga/level/bahu') ?>" class="relative rounded-xl overflow-hidden max-w-[400px] block border border-transparent hover:border-[#F47C20] transition-colors duration-300">
               <img alt="Muscular back flexing arms showing shoulder and back muscles" class="w-full h-auto rounded-xl object-cover" height="200" src="https://i.pinimg.com/736x/bd/a8/d8/bda8d8b0302d54cebe4522ceb2c11c54.jpg" width="400" />
               <div class="absolute bottom-3 left-3 text-white font-semibold text-lg drop-shadow-lg">
                  Bahu & Punggung
               </div>
            </a>
         </div>
      </section>
   </main>