<main class="flex-grow ml-0 sm:ml-64 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 pb-24">
    <h2 class="text-3xl font-bold text-orange-500 mb-8 flex items-center">
        <i class="fas fa-dumbbell mr-3"></i>
        Start Workout
    </h2>
    <section class="bg-[#1F2937] rounded-xl p-6 max-w-4xl mx-auto">
        <div class="flex items-center justify-between mb-4">
            <div class="flex items-center space-x-2 text-[#F68B1E] font-extrabold text-lg">
                <i class="fas fa-dumbbell text-[#F68B1E] text-xl"></i>
                <span><?= ucfirst($muscle) ?> (Level: <?= ucfirst($level) ?>)</span>
            </div>
            <div class="flex items-center space-x-2 text-white font-semibold text-lg">
                <i class="fas fa-stopwatch"></i>
                <?php $totalSeconds = $latihan->durasi * 60; ?>
                <?php $minutes = floor($totalSeconds / 60); ?>
                <?php $seconds = $totalSeconds % 60; ?>

                <p>Durasi:
                    <span id="duration" data-seconds="<?= $totalSeconds ?>">
                        <?= str_pad($minutes, 2, "0", STR_PAD_LEFT) ?>:<?= str_pad($seconds, 2, "0", STR_PAD_LEFT) ?> Menit
                    </span>
                </p>
            </div>
        </div>
        <h2 class="text-white font-extrabold text-2xl mb-4">
            <?= $latihan->nama_latihan ?> 12 x 2 set
        </h2>
        <iframe id="ytvideo" width="560" height="315"
            src="<?= $latihan->video_url ?>?enablejsapi=1&autoplay=0"
            frameborder="0" allow="autoplay; encrypted-media" allowfullscreen>
        </iframe>
        <div id="timer_display" class="text-2xl font-bold mt-4 text-orange-500">Menunggu...</div>

        <div class="flex justify-between items-center mt-4">
            <div class="flex space-x-2">
                <button id="pauseBtn" class="px-4 py-2 bg-yellow-500 text-white rounded hover:bg-yellow-600">Pause</button>
                <button id="stopBtn" class="px-4 py-2 bg-orange-600 text-white rounded hover:bg-orange-700">Stop</button>
            </div>

            <?php if (!empty($next_latihan)): ?>
                <div class="flex items-center space-x-4">
                    <div id="nextInfo" class="text-white font-semibold">
                        Latihan Selanjutnya:
                        <span class="text-orange-400"><?= $next_latihan->nama_latihan ?></span>
                    </div>
                    <a id="nextBtn" href="<?= site_url('olahraga/timer/' . $next_latihan->id) ?>" 
                    class="px-4 py-2 bg-yellow-600 text-white rounded hover:bg-green-700">
                        Next Excercise
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </section>
</main>

<script>
    let duration = parseInt(document.getElementById('duration').dataset.seconds);

    let timerDisplay = document.getElementById('timer_display');
    let stopBtn = document.getElementById('stopBtn');
    let pauseBtn = document.getElementById('pauseBtn');
    let player;
    let stopped = false;
    let paused = false;
    let interval;

    function formatTime(seconds) {
        const minutes = Math.floor(seconds / 60);
        const secs = seconds % 60;
        return `${String(minutes).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
    }

    function saveProgress() {
        fetch("<?= site_url('Olahraga/save') ?>", {
                method: "POST",
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                body: new URLSearchParams({
                    activity: "<?= $latihan->nama_latihan ?>",
                    duration: <?= $latihan->durasi ?>,
                    calories: <?= $latihan->kalori ?> * <?= $latihan->durasi ?>,
                    muscle: "<?= $muscle ?>",
                    level: "<?= $level ?>"
                })
            }).then(res => res.json())
            .then(data => {
                if (data.status === "success") {
                    alert("Data latihan disimpan!");
                }
            }).catch(err => {
                console.error("Gagal menyimpan progress:", err);
            });
    }

    function onYouTubeIframeAPIReady() {
        player = new YT.Player('ytvideo', {
            events: {
                'onReady': startCountdown
            }
        });
    }

    function startCountdown() {
        interval = setInterval(() => {
            if (stopped) {
                clearInterval(interval);
                return;
            }

            if (!paused) {
                if (duration <= 0) {
                    clearInterval(interval);
                    timerDisplay.innerText = "Selesai!";
                    saveProgress();

                    document.getElementById('nextBtn')?.classList.remove('hidden');
                    document.getElementById('nextInfo')?.classList.remove('hidden');
                } else {
                    timerDisplay.innerText = formatTime(duration);
                    duration--;
                }
            }
        }, 1000);

        player.playVideo();
    }

    stopBtn.addEventListener('click', function() {
        if (!stopped) {
            stopped = true;
            clearInterval(interval);
            player.stopVideo();
            timerDisplay.innerText = "Dihentikan oleh pengguna";
            saveProgress();

            document.getElementById('nextBtn')?.classList.remove('hidden');
            document.getElementById('nextInfo')?.classList.remove('hidden');
        }
    });

    pauseBtn.addEventListener('click', function() {
        if (!paused) {
            paused = true;
            player.pauseVideo();
            pauseBtn.innerText = "Resume";
            pauseBtn.classList.remove("bg-yellow-500");
            pauseBtn.classList.add("bg-green-600");
        } else {
            paused = false;
            player.playVideo();
            pauseBtn.innerText = "Pause";
            pauseBtn.classList.remove("bg-green-600");
            pauseBtn.classList.add("bg-yellow-500");
        }
    });

    let tag = document.createElement('script');
    tag.src = "https://www.youtube.com/iframe_api";
    document.body.appendChild(tag);
</script>