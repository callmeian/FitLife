<main class="flex-grow ml-0 sm:ml-64 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 pb-24">
    <h2 class="text-3xl font-bold text-orange-500 mb-6 flex items-center">
      <i class="fas fa-user-circle mr-3">
      </i>
      Account
    </h2>
      <form aria-label="User profile form" class="space-y-6">
        <div>
          <label class="block text-gray-300 font-semibold mb-2" for="name">
            Name
          </label>
          <input class="w-full rounded-md bg-gray-700 border border-gray-600 text-white px-4 py-3 focus:outline-none focus:ring-2 focus:ring-orange-500" id="name" name="name" readonly="" type="text" value="<?= $user->name ?>" />
        </div>
        <div>
          <label class="block text-gray-300 font-semibold mb-2" for="email">
            Email
          </label>
          <input class="w-full rounded-md bg-gray-700 border border-gray-600 text-white px-4 py-3 focus:outline-none focus:ring-2 focus:ring-orange-500" id="email" name="email" readonly="" type="email" value="<?= $user->email ?>" />
        </div>
        <a href="<?= site_url('Account/edit_profile') ?>" class="block w-full bg-orange-600 hover:bg-orange-700 transition text-white font-semibold py-3 rounded-md text-center">
          Edit Account
        </a>
      </form>
    </div>
  </main>
</script>