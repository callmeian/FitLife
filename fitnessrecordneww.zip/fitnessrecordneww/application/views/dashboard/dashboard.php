<?php if ($this->session->flashdata('success')) : ?>
    <div
        id="alert-success"
        class="fixed top-16 left-1/2 transform -translate-x-1/2 z-50 px-6 py-4 rounded-lg bg-green-600 text-#F2F2F7 text-center shadow-lg transition-opacity duration-500 ease-in-out">
        <i class="fas fa-check-circle text-green-400 mr-3 mt-1"></i>
        <strong>Berhasil</strong>! <?= $this->session->flashdata('success'); ?>
    </div>
<?php endif; ?>

<?php if (validation_errors()) : ?>
    <div
        id="alert-error"
        class="fixed top-16 left-1/2 transform -translate-x-1/2 z-50 px-6 py-4 rounded-lg bg-red-600 text-#F2F2F7 text-center shadow-lg transition-opacity duration-500 ease-in-out">
        <i class="fas fa-exclamation-triangle text-red-400 mr-3 mt-1"></i>
        <strong>Error</strong>! <?= validation_errors(); ?>
    </div>
<?php endif; ?>

<!-- Main Content -->
<main class="flex-grow ml-0 sm:ml-64 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 pb-24">
    <h2 class="text-3xl font-bold text-orange-500 mb-8 flex items-center">
        <i class="fas fa-tachometer-alt mr-3"></i>
        Dashboard Overview
    </h2>
    <!-- Filter Dropdown -->
    <form method="get" id="filterForm" class="mb-6">
        <label for="filter" class="text-white font-semibold mr-2">Filter:</label>
        <select name="filter" id="filter" class="rounded p-1 bg-gray-700 text-white" onchange="document.getElementById('filterForm').submit()">
            <option value="week" <?= ($filter == 'week') ? 'selected' : '' ?>>Last 7 Days</option>
            <option value="month" <?= ($filter == 'month') ? 'selected' : '' ?>>This Month</option>
            <option value="year" <?= ($filter == 'year') ? 'selected' : '' ?>>This Year</option>
            <option value="all" <?= ($filter == 'all') ? 'selected' : '' ?>>All Time</option>
        </select>
    </form>
    <section class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-10">
        <div class="bg-gray-800 rounded-lg p-6 shadow-lg border border-gray-700">
            <div class="flex items-center justify-between mb-4">
                <div class="text-orange-500 text-3xl">
                    <i class="fas fa-dumbbell"></i>
                </div>
                <div class="text-white font-bold text-2xl">
                    <?= $total_workouts ?? 0 ?>
                </div>
            </div>
            <p class="text-gray-400 font-semibold">
                Workouts Completed
            </p>
        </div>
        <div class="bg-gray-800 rounded-lg p-6 shadow-lg border border-gray-700">
            <div class="flex items-center justify-between mb-4">
                <div class="text-orange-500 text-3xl">
                    <i class="fas fa-fire"></i>
                </div>
                <div class="text-white font-bold text-2xl">
                    <?= $total_calories ?? 0 ?>
                </div>
            </div>
            <p class="text-gray-400 font-semibold">
                Calories Burned
            </p>
        </div>
    </section>
    <section class="mt-12">
        <h3 class="text-2xl font-semibold text-white mb-6 flex items-center">
            <i class="fas fa-chart-line text-orange-400 mr-3"></i> Statistik Mingguan
        </h3>

        <!-- Tabs -->
        <div class="mb-6 border-b border-gray-700">
            <nav class="flex space-x-4" id="chartTabs">
                <button class="tab-btn text-white py-2 px-4 bg-gray-700 rounded-t-md border border-b-0 border-gray-600" data-tab="combo">Workout & Kalori</button>
                <button class="tab-btn text-white py-2 px-4 hover:bg-gray-700 rounded-t-md border border-b-0 border-gray-600" data-tab="donut">Persentase Otot</button>
            </nav>
        </div>

        <!-- Tab Content -->
        <div class="bg-gray-800 rounded-xl shadow-lg p-6 border border-gray-700">
            <div id="combo" class="tab-content">
                <h4 class="text-lg font-semibold text-white mb-4">Workout & Kalori</h4>
                <canvas id="comboChart" class="w-full h-[300px]"></canvas>
            </div>
            <div id="donut" class="tab-content hidden">
                <h4 class="text-lg font-semibold text-white mb-4">Persentase Otot Dilatih</h4>
                <div class="flex justify-center items-center">
                    <div class="w-full max-w-xs sm:max-w-sm md:max-w-md">
                        <canvas id="donutChart" class="w-full h-auto"></canvas>
                    </div>
                </div>
            </div>

        </div>
    </section>
    <br>

    <section>
        <h3 class="text-2xl font-semibold text-white mb-4">
            Recent Workouts
        </h3>
        <div class="overflow-x-auto rounded-lg border border-gray-700 bg-gray-800 shadow-md">
            <table class="min-w-full divide-y divide-gray-700">
                <thead class="bg-gray-900">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-semibold text-orange-400 uppercase tracking-wider">Aktivitas</th>
                        <th class="px-6 py-3 text-left text-xs font-semibold text-orange-400 uppercase tracking-wider">Target Otot</th>
                        <th class="px-6 py-3 text-left text-xs font-semibold text-orange-400 uppercase tracking-wider">Level</th>
                        <th class="px-6 py-3 text-left text-xs font-semibold text-orange-400 uppercase tracking-wider">Durasi (Menit)</th>
                        <th class="px-6 py-3 text-left text-xs font-semibold text-orange-400 uppercase tracking-wider">Kalori</th>
                        <th class="px-6 py-3 text-left text-xs font-semibold text-orange-400 uppercase tracking-wider">Tanggal</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-700">
                    <?php foreach ($recent_workouts as $workout): ?>
                        <tr class="hover:bg-gray-700 transition-colors duration-150">
                            <td class="px-6 py-4 whitespace-nowrap text-white font-semibold"><?= $workout->activity ?></td>
                            <td class="px-6 py-4 whitespace-normal text-gray-400"><?= ucfirst($workout->muscle ?? '-') ?></td>
                            <td class="px-6 py-4 whitespace-normal text-gray-400"><?= ucfirst($workout->level ?? '-') ?></td>
                            <td class="px-6 py-4 whitespace-normal text-gray-400"><?= $workout->duration_minutes ?></td>
                            <td class="px-6 py-4 whitespace-normal text-gray-400"><?= $workout->calories ?></td>
                            <td class="px-6 py-4 whitespace-normal text-gray-400"><?= date('d-m-Y', strtotime($workout->progress_date)) ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </section>
</main>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    const labels = <?= json_encode($chart_data['labels']) ?>;
    const workoutData = <?= json_encode($chart_data['workouts']) ?>;
    const caloriesData = <?= json_encode($chart_data['calories']) ?>;
    const muscleLabels = <?= json_encode(array_column($muscle_distribution, 'muscle')) ?>;
    const muscleCounts = <?= json_encode(array_column($muscle_distribution, 'count')) ?>;

    // Gabungan Bar (Workout) + Line (Calories)
    new Chart(document.getElementById('comboChart'), {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                    label: 'Workout',
                    data: workoutData,
                    backgroundColor: 'rgba(59, 130, 246, 0.8)',
                    borderRadius: 6
                },
                {
                    label: 'Calories Burned',
                    data: caloriesData,
                    type: 'line',
                    borderColor: 'rgba(252, 165, 165, 1)',
                    backgroundColor: 'rgba(252, 165, 165, 0.2)',
                    tension: 0.4,
                    fill: true,
                    pointBackgroundColor: 'rgba(252, 165, 165, 1)'
                }
            ]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    display: false // disini legend disembunyikan
                }
            },
            scales: {
                x: {
                    ticks: {
                        color: '#d1d5db'
                    },
                    grid: {
                        color: 'rgba(255,255,255,0.05)'
                    }
                },
                y: {
                    ticks: {
                        color: '#d1d5db'
                    },
                    grid: {
                        color: 'rgba(255,255,255,0.05)'
                    },
                    beginAtZero: true
                }
            }
        }
    });


    // Donut Chart
    new Chart(document.getElementById('donutChart'), {
        type: 'doughnut',
        data: {
            labels: muscleLabels,
            datasets: [{
                label: 'Persentase Latihan Otot',
                data: muscleCounts,
                backgroundColor: [
                    '#3B82F6', '#F59E0B', '#10B981', '#EF4444', '#8B5CF6', '#EC4899'
                ],
                borderWidth: 2,
                borderColor: '#1F2937' // border color untuk dark mode background
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            cutout: '60%', // membuat lubang tengah lebih rapi
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        color: '#fff',
                        padding: 20,
                        boxWidth: 16,
                        font: {
                            size: 13,
                            weight: '500'
                        }
                    }
                },
                tooltip: {
                    backgroundColor: '#1F2937',
                    titleColor: '#fff',
                    bodyColor: '#ddd',
                    borderColor: '#4B5563',
                    borderWidth: 1
                }
            }
        }
    });
</script>

<script>
    // Tab Switching
    const tabs = document.querySelectorAll('.tab-btn');
    const contents = document.querySelectorAll('.tab-content');

    tabs.forEach(btn => {
        btn.addEventListener('click', () => {
            // Reset semua tab
            tabs.forEach(tab => tab.classList.remove('bg-gray-700'));
            contents.forEach(content => content.classList.add('hidden'));

            // Aktifkan yang diklik
            btn.classList.add('bg-gray-700');
            document.getElementById(btn.dataset.tab).classList.remove('hidden');
        });
    });
</script>

<script>
    // Hilangkan alert setelah 4 detik
    setTimeout(() => {
        const successAlert = document.getElementById('alert-success');
        const errorAlert = document.getElementById('alert-error');

        if (successAlert) {
            successAlert.classList.add('opacity-0');
            setTimeout(() => successAlert.remove(), 500); // hapus dari DOM
        }

        if (errorAlert) {
            errorAlert.classList.add('opacity-0');
            setTimeout(() => errorAlert.remove(), 500);
        }
    }, 4000); // 4000 ms = 4 detik
</script>