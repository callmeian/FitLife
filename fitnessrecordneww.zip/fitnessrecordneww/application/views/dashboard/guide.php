<main class="flex-grow ml-0 sm:ml-64 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 pb-24">
   <h2 class="text-3xl font-bold text-orange-500 mb-8 flex items-center">
      <i class="fas fa-book-open mr-3">
      </i>
      Panduan Pemula
   </h2>
   <article class="max-w-4xl mx-auto space-y-10">
      <section>
         <h3 class="text-2xl font-semibold text-white mb-4 border-b border-orange-500 pb-2">
            Welcome to Your Fitness Journey
         </h3>
         <p class="text-gray-300 leading-relaxed">
            Starting a fitness journey can be both exciting and overwhelming. This guide is designed to help beginners understand the basics of fitness, set realistic goals, and build a sustainable workout routine that fits your lifestyle.
         </p>
         <img alt="Motivational image of a diverse group of people exercising together in a gym with orange and grey workout attire" class="mt-6 rounded-lg shadow-lg border-4 border-orange-500" height="300" src="https://i.pinimg.com/736x/c4/fd/87/c4fd879989ebd4aafec55161448da54c.jpg" width="600" />
      </section>
      <section>
         <h3 class="text-2xl font-semibold text-white mb-4 border-b border-orange-500 pb-2">
            Step 1: Set Clear and Achievable Goals
         </h3>
         <p class="text-gray-300 leading-relaxed">
            Define what you want to achieve. Whether it’s losing weight, building muscle, improving endurance, or just staying active, having clear goals will keep you motivated and focused.
         </p>
         <ul class="list-disc list-inside mt-4 text-gray-300 space-y-2">
            <li>
               Start with small, measurable goals.
            </li>
            <li>
               Track your progress regularly.
            </li>
            <li>
               Adjust your goals as you improve.
            </li>
         </ul>
         <img alt="Checklist on a clipboard with fitness goals written, orange and grey color theme" class="mt-6 rounded-lg shadow-lg border-4 border-orange-500" height="300" src="https://i.pinimg.com/736x/0e/32/45/0e32458b5b7d06bf2362af030d68fcd5.jpg" width="600" />
      </section>
      <section>
         <h3 class="text-2xl font-semibold text-white mb-4 border-b border-orange-500 pb-2">
            Step 2: Learn Proper Form and Technique
         </h3>
         <p class="text-gray-300 leading-relaxed">
            Proper form is essential to prevent injuries and maximize the effectiveness of your workouts. Take time to learn the correct techniques for exercises you plan to do.
         </p>
         <img alt="Trainer demonstrating proper squat form to a beginner in a gym with orange and grey accents" class="mt-6 rounded-lg shadow-lg border-4 border-orange-500" height="300" src="https://storage.googleapis.com/a1aa/image/0ae608dd-21e6-4fe1-300f-a4e24ca71bdb.jpg" width="600" />
      </section>
      <section>
         <h3 class="text-2xl font-semibold text-white mb-4 border-b border-orange-500 pb-2">
            Step 3: Start with a Balanced Workout Routine
         </h3>
         <p class="text-gray-300 leading-relaxed">
            A balanced routine includes cardiovascular exercises, strength training, and flexibility work. This helps improve overall fitness and reduces the risk of injury.
         </p>
         <ul class="list-disc list-inside mt-4 text-gray-300 space-y-2">
            <li>
               Cardio: Running, cycling, swimming
            </li>
            <li>
               Strength: Weight lifting, bodyweight exercises
            </li>
            <li>
               Flexibility: Stretching, yoga
            </li>
         </ul>
         <img alt="Dumbbells, running shoes, and yoga mat arranged on a gym floor with orange and grey color scheme" class="mt-6 rounded-lg shadow-lg border-4 border-orange-500" height="300" src="https://storage.googleapis.com/a1aa/image/c758ead4-d6b0-4644-ce3c-616a66746ec9.jpg" width="600" />
      </section>
      <section>
         <h3 class="text-2xl font-semibold text-white mb-4 border-b border-orange-500 pb-2">
            Step 4: Nutrition and Hydration
         </h3>
         <p class="text-gray-300 leading-relaxed">
            Fuel your body with nutritious foods and stay hydrated. Proper nutrition supports your workouts and recovery.
         </p>
         <ul class="list-disc list-inside mt-4 text-gray-300 space-y-2">
            <li>
               Eat a balanced diet rich in protein, carbs, and healthy fats.
            </li>
            <li>
               Drink plenty of water throughout the day.
            </li>
            <li>
               Avoid excessive processed foods and sugars.
            </li>
         </ul>
         <img alt="Healthy meal bowl with vegetables, grains, and protein in orange and grey tones" class="mt-6 rounded-lg shadow-lg border-4 border-orange-500" height="300" src="https://i.pinimg.com/736x/cf/59/2a/cf592a190a351b337252d64333746db8.jpg" width="600" />
      </section>
      <section>
         <h3 class="text-2xl font-semibold text-white mb-4 border-b border-orange-500 pb-2">
            Step 5: Rest and Recovery
         </h3>
         <p class="text-gray-300 leading-relaxed">
            Rest days are just as important as workout days. They allow your muscles to recover and grow stronger.
         </p>
         <img alt="Person relaxing on a yoga mat with eyes closed, orange and grey workout clothes" class="mt-6 rounded-lg shadow-lg border-4 border-orange-500" height="300" src="https://storage.googleapis.com/a1aa/image/7f6d5dc8-4659-415d-21cb-3ed855bc09d3.jpg" width="600" />
      </section>
      <section>
         <h3 class="text-2xl font-semibold text-white mb-4 border-b border-orange-500 pb-2">
            Final Tips
         </h3>
         <ul class="list-disc list-inside mt-4 text-gray-300 space-y-2">
            <li>
               Stay consistent and patient with your progress.
            </li>
            <li>
               Listen to your body and avoid overtraining.
            </li>
            <li>
               Seek professional advice if unsure about exercises or nutrition.
            </li>
            <li>
               Enjoy the process and celebrate your achievements.
            </li>
         </ul>
      </section>
   </article>
</main>