<html lang="en">

<head>
  <meta charset="utf-8" />
  <meta content="width=device-width, initial-scale=1" name="viewport" />
  <title>
    Fitness Dashboard
  </title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&amp;display=swap" rel="stylesheet" />
  <link href="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.8/index.global.min.css" rel="stylesheet" />
  <script src="https://cdn.jsdelivr.net/npm/fullcalendar@6.1.8/index.global.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <style>
    body {
      font-family: 'Poppins', 'Montserrat', sans-serif;
    }

    #calendar {
      height: 350px;
      width: 950px;
      font-size: 1rem;
    }
  </style>
</head>

<body class="bg-gray-900 text-gray-200 min-h-screen flex flex-col">
  <!-- Header -->
  <!-- Header -->
  <header class="bg-gray-800 border-b border-gray-700 fixed top-0 left-0 right-0 z-40 h-16 flex items-center px-4 sm:px-6 lg:px-8">
    <div class="flex items-center justify-between w-full">

      <!-- Tombol menu sidebar (hanya di mobile) -->
      <button aria-label="Open sidebar menu" id="mobile-menu-button"
        class="sm:hidden text-orange-400 hover:text-orange-500 focus:outline-none focus:ring-2 focus:ring-orange-500 rounded">
        <i class="fas fa-bars fa-lg"></i>
      </button>

      <!-- Judul -->
      <h1 class="text-orange-500 text-xl font-bold tracking-wide mx-auto sm:mx-0">
        FitLife Dashboard
      </h1>

      <!-- Bagian kanan header (hanya muncul di layar ≥ sm) -->
      <div class="hidden sm:flex items-center space-x-4 relative">

        <!-- Nama user -->
        <span class="text-orange-400 font-semibold text-lg select-none">
          Halo, <?= $user->name ?>
        </span>

        <!-- Tombol Settings -->
        <button aria-label="User settings" id="settings-button"
          class="text-gray-400 hover:text-orange-500 focus:outline-none focus:ring-2 focus:ring-orange-500 rounded-full p-2">
          <i class="fas fa-cog fa-lg"></i>
        </button>

        <!-- Dropdown Menu -->
        <div id="settings-menu"
          class="hidden absolute right-0 top-full mt-2 w-40 bg-gray-800 border border-gray-700 rounded-md shadow-lg py-1 z-50">

          <!-- Link ke Profil -->
          <a href="<?= site_url('Account/profile') ?>"
            class="block px-4 py-2 text-gray-300 hover:bg-gray-700 hover:text-orange-400 transition-colors duration-150">
            <i class="fas fa-user mr-3"></i>
            Account
          </a>

          <!-- Logout Button -->
          <button onclick="openLogoutModal()"
            class="block w-full text-left px-4 py-2 text-gray-300 hover:bg-gray-700 hover:text-red-400 transition-colors duration-150 text-sm">
            <i class="fas fa-sign-out-alt mr-3"></i>
            Log out
          </button>
        </div>

      </div>
    </div>
  </header>

  <!-- Modal Konfirmasi Logout -->
  <div id="logoutModal" class="fixed inset-0 z-50 bg-black bg-opacity-60 hidden justify-center items-center">
    <div class="bg-gray-800 text-white rounded-xl p-6 w-full max-w-sm shadow-2xl border border-gray-700">
      <h2 class="text-xl font-bold text-orange-500 mb-2">Konfirmasi Logout</h2>
      <p class="text-gray-300 mb-6">Apakah kamu yakin ingin log out?</p>
      <div class="flex justify-end gap-3">
        <button onclick="closeLogoutModal()" class="px-4 py-2 rounded-lg bg-gray-700 hover:bg-gray-600 text-white transition duration-150">
          Batal
        </button>
        <a href="<?= site_url('auth/logout') ?>" class="px-4 py-2 rounded-lg bg-red-600 hover:bg-red-700 text-white transition duration-150">
          Ya, Logout
        </a>
      </div>
    </div>
  </div>

  <script>
    function openLogoutModal() {
      document.getElementById('logoutModal').classList.remove('hidden');
      document.getElementById('logoutModal').classList.add('flex');
    }

    function closeLogoutModal() {
      document.getElementById('logoutModal').classList.add('hidden');
      document.getElementById('logoutModal').classList.remove('flex');
    }
  </script>