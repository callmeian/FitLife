<!-- Footer -->
<footer class="bg-gray-800 border-t border-gray-700 fixed bottom-0 left-0 right-0 z-30">
  <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 flex flex-col sm:flex-row justify-between items-center text-gray-400 text-sm">
    <p>
      © 2025 Fitness. All rights reserved.
    </p>
    <!-- <div class="flex space-x-6 mt-3 sm:mt-0">
      <a aria-label="Facebook" class="hover:text-orange-500" href="#">
        <i class="fab fa-facebook fa-lg"></i>
      </a>
      <a aria-label="Twitter" class="hover:text-orange-500" href="#">
        <i class="fab fa-twitter fa-lg"></i>
      </a>
      <a aria-label="Instagram" class="hover:text-orange-500" href="#">
        <i class="fab fa-instagram fa-lg"></i>
      </a>
      <a aria-label="LinkedIn" class="hover:text-orange-500" href="#">
        <i class="fab fa-linkedin fa-lg"></i>
      </a>
    </div> -->
  </div>
</footer>

<script>
  const mobileMenuButton = document.getElementById('mobile-menu-button');
  const mobileMenu = document.getElementById('mobile-menu');
  const mobileMenuClose = document.getElementById('mobile-menu-close');
  const settingsButton = document.getElementById('settings-button');
  const settingsMenu = document.getElementById('settings-menu');

  mobileMenuButton.addEventListener('click', () => {
    mobileMenu.classList.remove('-translate-x-full');
  });

  mobileMenuClose.addEventListener('click', () => {
    mobileMenu.classList.add('-translate-x-full');
  });

  // Close mobile menu when clicking outside sidebar on mobile
  window.addEventListener('click', (e) => {
    if (!mobileMenu.contains(e.target) && !mobileMenuButton.contains(e.target)) {
      if (!mobileMenu.classList.contains('-translate-x-full')) {
        mobileMenu.classList.add('-translate-x-full');
      }
    }
  });

  // Toggle settings menu
  settingsButton.addEventListener('click', (e) => {
    e.stopPropagation();
    settingsMenu.classList.toggle('hidden');
  });

  // Close settings menu when clicking outside
  window.addEventListener('click', (e) => {
    if (!settingsMenu.contains(e.target) && !settingsButton.contains(e.target)) {
      if (!settingsMenu.classList.contains('hidden')) {
        settingsMenu.classList.add('hidden');
      }
    }
  });
</script>

<!-- Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<script>
  document.addEventListener('DOMContentLoaded', () => {
    const canvas = document.getElementById("weeklyChart");
    if (!canvas) {
      console.warn("weeklyChart canvas not found.");
      return;
    }

    fetch("<?= site_url('Dashboard/get_weekly_summary') ?>")
      .then(res => res.json())
      .then(data => {
        const labels = [];
        const workouts = [];
        const calories = [];

        for (let i = 0; i < 7; i++) {
          const d = new Date();
          d.setDate(d.getDate() - 6 + i);
          const ymd = d.toISOString().slice(0, 10);
          labels.push(ymd);
          const dayData = data.find(item => item.date === ymd);
          workouts.push(dayData ? parseInt(dayData.total_workouts) : 0);
          calories.push(dayData ? parseInt(dayData.total_calories) : 0);
        }

        new Chart(canvas.getContext("2d"), {
          type: "bar",
          data: {
            labels,
            datasets: [{
                label: "Workouts",
                data: workouts,
                backgroundColor: "#f97316"
              },
              {
                label: "Calories",
                data: calories,
                backgroundColor: "#5bc0be"
              }
            ]
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
              x: {
                ticks: {
                  color: "#ffffff"
                },
                grid: {
                  color: "#374151"
                }
              },
              y: {
                ticks: {
                  color: "#ffffff"
                },
                grid: {
                  color: "#374151"
                }
              }
            },
            plugins: {
              legend: {
                labels: {
                  color: "#ffffff"
                }
              }
            }
          }
        });
      })
      .catch(err => {
        console.error("Error fetching chart data:", err);
      });
  });
</script>

</body>

</html>