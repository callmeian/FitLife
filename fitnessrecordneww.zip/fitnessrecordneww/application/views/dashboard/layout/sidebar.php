<div class="flex flex-1 pt-16">
  <!-- Desktop Sidebar -->
  <aside class="hidden sm:flex bg-gray-800 w-64 min-h-screen fixed top-16 left-0 border-r border-gray-700 flex flex-col z-20">
    <!-- Navigation -->
    <nav class="flex-1 px-4 py-6 overflow-y-auto">
      <ul class="space-y-2">
        <li>
          <a href="<?= site_url('Dashboard') ?>"
            class="flex items-center px-3 py-2 rounded-md <?= ($this->uri->segment(1) == 'Dashboard' && $this->uri->segment(2) == '') ? 'bg-gray-900 text-orange-400 font-semibold' : 'hover:bg-gray-700 hover:text-orange-400 transition-colors duration-200' ?>">
            <i class="fas fa-tachometer-alt mr-3"></i>
            Dashboard
          </a>
        </li>
        <li>
          <a href="<?= site_url('Dashboard/guide') ?>"
            class="flex items-center px-3 py-2 rounded-md <?= ($this->uri->segment(1) == 'Dashboard' && $this->uri->segment(2) == 'guide') ? 'bg-gray-900 text-orange-400 font-semibold' : 'hover:bg-gray-700 hover:text-orange-400 transition-colors duration-200' ?>">
            <i class="fas fa-book-open mr-3"></i>
            Panduan Pemula
          </a>
        </li>
        <li>
          <a href="<?= site_url('Progress') ?>" class="flex items-center px-3 py-2 rounded-md <?= ($this->uri->segment(1) == 'Progress') ? 'bg-gray-900 text-orange-400 font-semibold' : 'hover:bg-gray-700 hover:text-orange-400 transition-colors duration-200' ?>">
            <i class="fas fa-stopwatch mr-4"></i>
            Record Olahraga
          </a>
        </li>
        <li>
          <a href="<?= site_url('Olahraga') ?>"
            class="flex items-center px-3 py-2 rounded-md <?= ($this->uri->segment(1) == 'Olahraga') ? 'bg-gray-900 text-orange-400 font-semibold' : 'hover:bg-gray-700 hover:text-orange-400 transition-colors duration-200' ?>">
            <i class="fas fa-dumbbell mr-2"></i>
            Olahraga
          </a>
        </li>
        <li>
          <a href="<?= site_url('Community') ?>"
            class="flex items-center px-3 py-2 rounded-md <?= ($this->uri->segment(1) == 'Community') ? 'bg-gray-900 text-orange-400 font-semibold' : 'hover:bg-gray-700 hover:text-orange-400 transition-colors duration-200' ?>">
            <i class="fas fa-users mr-2"></i>
            Komunitas
          </a>
        </li>
        <li class="border-t border-gray-700 mt-4 pt-4">
          <a href="<?php echo site_url('LandingPage') ?>"
            class="flex items-center px-3 py-2 rounded-md hover:bg-gray-700 hover:text-red-400 transition-colors duration-200">
            <i class="fas fa-arrow-left mr-3"></i>
            Back to home
          </a>
        </li>
      </ul>
    </nav>
  </aside>


  <!-- Mobile sidebar -->
  <div id="mobile-menu" class="fixed inset-0 z-50 bg-gray-900 bg-opacity-95 transform -translate-x-full transition-transform duration-300 ease-in-out sm:hidden">
    <div class="flex flex-col h-full w-64 bg-gray-800 border-r border-gray-700 p-6">
      <!-- Header -->
      <div class="flex justify-between items-center mb-8">
        <h2 class="text-orange-400 font-bold text-xl">Menu</h2>
        <button id="mobile-menu-close" aria-label="Close sidebar menu"
          class="text-orange-400 hover:text-orange-500 focus:outline-none focus:ring-2 focus:ring-orange-500 rounded">
          <i class="fas fa-times fa-lg"></i>
        </button>
      </div>

      <!-- Username Display -->
      <div class="px-4 py-2 border-b border-gray-700">
        <span class="block text-orange-400 font-semibold text-sm truncate">
          Halo, <?= $user->name ?>
        </span>
      </div>

      <!-- Navigation -->
      <nav class="flex-1 overflow-y-auto mt-4">
        <ul class="space-y-4">
          <li>
            <a href="<?= site_url('Dashboard') ?>" class="flex items-center px-3 py-2 rounded-md <?= ($this->uri->segment(1) == 'Dashboard' && $this->uri->segment(2) == '') ? 'bg-gray-900 text-orange-400 font-semibold' : 'hover:bg-gray-700 hover:text-orange-400 transition-colors duration-200' ?>">
              <i class="fas fa-tachometer-alt mr-3" ></i>
              Dashboard
            </a>
          </li>
          <li>
            <a href="<?= site_url('Dashboard/guide') ?>" class="flex items-center px-3 py-2 rounded-md <?= ($this->uri->segment(1) == 'Dashboard' && $this->uri->segment(2) == 'guide') ? 'bg-gray-900 text-orange-400 font-semibold' : 'hover:bg-gray-700 hover:text-orange-400 transition-colors duration-200' ?>">
              <i class="fas fa-book-open mr-3"></i>
              Panduan Pemula
            </a>
          </li>
          <li>
            <a href="<?= site_url('Progress') ?>" class="flex items-center px-3 py-2 rounded-md <?= ($this->uri->segment(1) == 'Progress') ? 'bg-gray-900 text-orange-400 font-semibold' : 'hover:bg-gray-700 hover:text-orange-400 transition-colors duration-200' ?>">
              <i class="fas fa-stopwatch mr-3"></i>
              Record Olahraga
            </a>
          </li>
          <li>
            <a href="<?= site_url('Olahraga') ?>"
              class="flex items-center px-3 py-2 rounded-md <?= ($this->uri->segment(1) == 'Olahraga') ? 'bg-gray-900 text-orange-400 font-semibold' : 'hover:bg-gray-700 hover:text-orange-400 transition-colors duration-200' ?>">
              <i class="fas fa-dumbbell mr-3"></i>
              Olahraga
            </a>
          </li>
          <li>
            <a href="<?= site_url('Community') ?>" class="flex items-center px-3 py-2 rounded-md <?= ($this->uri->segment(1) == 'Community') ? 'bg-gray-900 text-orange-400 font-semibold' : 'hover:bg-gray-700 hover:text-orange-400 transition-colors duration-200' ?>">
              <i class="fas fa-users mr-3"></i>
              Komunitas
            </a>
          </li>
          <li class="border-t border-gray-700 mt-4 pt-4">
            <a href="<?php echo site_url('LandingPage') ?>"
              class="flex items-center px-3 py-2 rounded-md hover:bg-gray-700 hover:text-red-400 transition-colors duration-200">
              <i class="fas fa-arrow-left mr-3"></i>
              Back to home
            </a>
          </li>
        </ul>
      </nav>

      <!-- Logout -->
      <div class="pt-6 border-t border-gray-700">
        <!-- Logout Button -->
        <button onclick="openLogoutModal()"
          class="block w-full text-left px-4 py-2 text-gray-300 hover:bg-gray-700 hover:text-red-400 transition-colors duration-150 text-sm">
          <i class="fas fa-sign-out-alt mr-3"></i>
          Log out
        </button>
      </div>
    </div>
  </div>
</div>


<!-- Modal Konfirmasi Logout -->
<div id="logoutModal" class="fixed inset-0 z-50 bg-black bg-opacity-60 hidden justify-center items-center">
  <div class="bg-gray-800 text-white rounded-xl p-6 w-full max-w-sm shadow-2xl border border-gray-700">
    <h2 class="text-xl font-bold text-orange-500 mb-2">Konfirmasi Logout</h2>
    <p class="text-gray-300 mb-6">Apakah kamu yakin ingin log out?</p>
    <div class="flex justify-end gap-3">
      <button onclick="closeLogoutModal()" class="px-4 py-2 rounded-lg bg-gray-700 hover:bg-gray-600 text-white transition duration-150">
        Batal
      </button>
      <a href="<?= site_url('auth/logout') ?>" class="px-4 py-2 rounded-lg bg-red-600 hover:bg-red-700 text-white transition duration-150">
        Ya, Logout
      </a>
    </div>
  </div>
</div>

<script>
  function openLogoutModal() {
    document.getElementById('logoutModal').classList.remove('hidden');
    document.getElementById('logoutModal').classList.add('flex');
  }

  function closeLogoutModal() {
    document.getElementById('logoutModal').classList.add('hidden');
    document.getElementById('logoutModal').classList.remove('flex');
  }
</script>