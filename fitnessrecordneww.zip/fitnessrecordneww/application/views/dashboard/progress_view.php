    <main class="flex-grow ml-0 sm:ml-64 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 pb-24">
        <h2 class="text-3xl font-bold text-orange-500 mb-8 flex items-center">
            <i class="fas fa-stopwatch mr-3">
            </i>
            Record Workouts
        </h2>
        <div id="calendar"></div>

        <section>
            <!-- Modal detail -->
            <div id="modal" class="hidden fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center">
                <div class="bg-gray-800 rounded-lg shadow-lg p-6 w-full max-w-md text-gray-200">
                    <h2 class="text-xl font-bold mb-4 text-orange-400" id="modalTitle">Detail Aktivitas</h2>
                    <div class="space-y-2">
                        <p><strong>Aktivitas:</strong> <span id="modalActivity">-</span></p>
                        <p><strong>Otot Target:</strong> <span id="modalMuscle">-</span></p>
                        <p><strong>Level:</strong> <span id="modalLevel">-</span></p>
                        <p><strong>Durasi:</strong> <span id="modalDuration">-</span></p>
                        <p><strong>Kalori:</strong> <span id="modalCalories">-</span></p>
                        <p><strong>Tanggal:</strong> <span id="modalDate">-</span></p>
                    </div>
                    <div class="mt-4 text-right">
                        <button onclick="closeModal()" class="px-4 py-2 bg-red-600 text-white rounded hover:bg-red-700">
                            Tutup
                        </button>
                    </div>
                </div>
            </div>

            <script>
                document.addEventListener('DOMContentLoaded', function() {
                    const calendarEl = document.getElementById('calendar');
                    const calendar = new FullCalendar.Calendar(calendarEl, {
                        initialView: 'dayGridMonth',
                        events: '<?= site_url('progress/get_events') ?>',
                        eventClick: function(info) {
                            const eventId = info.event.id;

                            fetch('<?= site_url('progress/get_event_detail/') ?>' + eventId)
                                .then(res => res.json())
                                .then(response => {
                                    if (response && response.data) {
                                        const data = response.data;

                                        document.getElementById('modalTitle').textContent = 'Detail: ';
                                        document.getElementById('modalActivity').textContent = data.activity;
                                        document.getElementById('modalDuration').textContent = data.duration_minutes + ' menit';
                                        document.getElementById('modalCalories').textContent = data.calories + ' kkal';
                                        document.getElementById('modalDate').textContent = data.progress_date;
                                        document.getElementById('modalMuscle').textContent = data.muscle;
                                        document.getElementById('modalLevel').textContent = data.level;


                                        document.getElementById('modal').classList.remove('hidden');
                                    } else {
                                        alert("Data tidak ditemukan.");
                                    }
                                })
                                .catch(err => {
                                    console.error('Gagal ambil data detail:', err);
                                    alert("Gagal memuat data detail.");
                                });
                        }
                    });

                    calendar.render();
                });

                function closeModal() {
                    document.getElementById('modal').classList.add('hidden');
                }
            </script>
    </main>