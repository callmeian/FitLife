-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 24 Jul 2025 pada 09.09
-- Versi server: 10.4.32-MariaDB
-- Versi PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fitnessrec`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `fitness_progress`
--

CREATE TABLE `fitness_progress` (
  `id` int(11) NOT NULL,
  `activity` varchar(255) DEFAULT NULL,
  `duration_minutes` int(11) DEFAULT NULL,
  `calories` int(11) DEFAULT NULL,
  `progress_date` date DEFAULT NULL,
  `status` enum('selesai','belum') DEFAULT 'selesai',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `muscle` varchar(50) DEFAULT NULL,
  `level` varchar(50) DEFAULT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `fitness_progress`
--

INSERT INTO `fitness_progress` (`id`, `activity`, `duration_minutes`, `calories`, `progress_date`, `status`, `created_at`, `muscle`, `level`, `user_id`) VALUES
(15, 'Leg Raise', 15, 105, '2025-05-24', 'selesai', '2025-05-24 16:41:57', 'perut', 'mahir', 2),
(16, 'Bicep Curl', 10, 60, '2025-05-24', 'selesai', '2025-05-24 17:01:48', 'lengan', 'pemula', 1),
(17, 'Sit Up', 10, 50, '2025-05-25', 'selesai', '2025-05-25 13:31:25', 'perut', 'pemula', 2),
(18, 'Squat', 10, 70, '2025-05-25', 'selesai', '2025-05-25 13:33:08', 'kaki', 'pemula', 2),
(19, 'Plank', 5, 30, '2025-05-25', 'selesai', '2025-05-25 13:39:06', 'perut', 'pemula', 2),
(20, 'Shoulder Tap', 10, 50, '2025-05-25', 'selesai', '2025-05-25 14:08:40', 'bahu', 'pemula', 2),
(21, 'Push Up Lutut', 8, 40, '2025-05-25', 'selesai', '2025-05-25 14:11:18', 'lengan', 'pemula', 2),
(22, 'Sit Up', 10, 50, '2025-05-25', 'selesai', '2025-05-25 15:19:02', 'perut', 'pemula', 2),
(23, 'Russian Twist', 10, 60, '2025-06-01', 'selesai', '2025-06-01 13:21:36', 'perut', 'mahir', 1),
(24, 'Sit Up', 10, 50, '2025-06-03', 'selesai', '2025-06-03 02:09:11', 'perut', 'pemula', 1),
(25, 'Leg Raise', 15, 105, '2025-06-03', 'selesai', '2025-06-03 02:19:51', 'perut', 'mahir', 1),
(26, 'Russian Twist', 10, 60, '2025-06-03', 'selesai', '2025-06-03 02:20:27', 'perut', 'mahir', 1),
(27, 'Bicep Curl', 10, 60, '2025-06-03', 'selesai', '2025-06-03 02:24:23', 'lengan', 'pemula', 1),
(28, 'Sit Up', 10, 50, '2025-06-03', 'selesai', '2025-06-03 12:31:26', 'perut', 'pemula', 1),
(29, 'Plank', 5, 30, '2025-07-03', 'selesai', '2025-07-03 06:48:22', 'perut', 'pemula', 1),
(30, 'Bicep Curl', 10, 60, '2025-07-04', 'selesai', '2025-07-04 13:11:31', 'lengan', 'pemula', 1),
(31, 'Lunges', 2, 12, '2025-07-04', 'selesai', '2025-07-04 13:30:25', 'kaki', 'pemula', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `menu_latihan`
--

CREATE TABLE `menu_latihan` (
  `id` int(11) NOT NULL,
  `nama_latihan` varchar(100) DEFAULT NULL,
  `target_otot` varchar(50) DEFAULT NULL,
  `level` enum('pemula','mahir') DEFAULT NULL,
  `durasi` int(11) DEFAULT NULL,
  `video_url` varchar(255) DEFAULT NULL,
  `kalori` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `menu_latihan`
--

INSERT INTO `menu_latihan` (`id`, `nama_latihan`, `target_otot`, `level`, `durasi`, `video_url`, `kalori`) VALUES
(21, 'Sit Up', 'perut', 'pemula', 2, 'https://www.youtube.com/embed/pMS2dU0FuPk', 5),
(22, 'Plank', 'perut', 'pemula', 2, 'https://www.youtube.com/embed/hZlW7KIVhB4', 6),
(23, 'Leg Raise', 'perut', 'mahir', 2, 'https://www.youtube.com/embed/l4kQd9eWclE', 7),
(24, 'Russian Twist', 'perut', 'mahir', 2, 'https://www.youtube.com/embed/wkD8rjkodUI', 6),
(25, 'Bicep Curl', 'lengan', 'pemula', 2, 'https://www.youtube.com/embed/ykJmrZ5v0Oo', 6),
(26, 'Push Up Lutut', 'lengan', 'pemula', 2, 'https://www.youtube.com/embed/lFR1GWy1Dcs', 5),
(27, 'Diamond Push Up', 'lengan', 'mahir', 3, 'https://www.youtube.com/embed/kGhDnFwMY3E', 7),
(28, 'Chin Up', 'lengan', 'mahir', 2, 'https://www.youtube.com/embed/T78xCiw_R6g', 8),
(29, 'Squat', 'kaki', 'pemula', 6, 'https://www.youtube.com/embed/HFnSsLIB7a4', 7),
(30, 'Lunges', 'kaki', 'pemula', 2, 'https://www.youtube.com/embed/wrwwXE_x-pQ', 6),
(31, 'Jump Squat', 'kaki', 'mahir', 2, 'https://www.youtube.com/embed/DeTBwEL4m7s', 8),
(32, 'Bulgarian Split Squat', 'kaki', 'mahir', 2, 'https://www.youtube.com/embed/7Aqeb8UHl4k', 8),
(33, 'Push Up', 'dada', 'pemula', 4, 'https://www.youtube.com/embed/IODxDxX7oi4', 6),
(34, 'Wide Push Up', 'dada', 'mahir', 2, 'https://www.youtube.com/embed/EsIdzx1J0iA', 7),
(35, 'Shoulder Tap', 'bahu', 'pemula', 2, 'https://www.youtube.com/embed/a2duDaO9BhM', 5),
(36, 'Arm Circles', 'bahu', 'pemula', 2, 'https://www.youtube.com/embed/35h5gdlm46w', 4),
(37, 'Pike Push Up', 'bahu', 'mahir', 5, 'https://www.youtube.com/embed/fXgou2W10ok', 7),
(38, 'Handstand Hold', 'bahu', 'mahir', 5, 'https://www.youtube.com/embed/zA2nuzsSDKQ', 6),
(39, 'Incline Push Up', 'dada', 'pemula', 3, 'https://www.youtube.com/embed/cfns5VDVVvk', 5),
(40, 'Chest Dip', 'dada', 'mahir', 2, 'https://www.youtube.com/embed/4la6BkUBLgo', 8);

-- --------------------------------------------------------

--
-- Struktur dari tabel `posts`
--

CREATE TABLE `posts` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `content` text NOT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `posts`
--

INSERT INTO `posts` (`id`, `user_id`, `content`, `created_at`) VALUES
(1, 2, 'bjkkjb', '2025-05-13 23:38:33'),
(3, 3, 'jkvblhnlj;l', '2025-05-14 11:14:39'),
(5, 1, 'Halo fitlife', '2025-07-13 17:31:33');

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `created_at`) VALUES
(1, 'Tyan', 'tyann@gmail.com', '$2y$10$qggg/SO0hGZPfvK.R8u2..rsM3NU/YkQrFLeC8ar6QSG0/oYL/fTy', '2025-05-08 21:19:57'),
(2, 'Hannibal Lecter', 'hannibal@gmail.com', '$2y$10$t7laxvgdsKHjoaisBQV2qeh6i9D7vLwDFLYZaW2UW35Ili9qEqvb2', '2025-05-11 19:56:52'),
(3, 'Valentino', 'valen@gmail.com', '$2y$10$FwDRrS.zzycuI3CG3SlGc.n65LqAtGz6O7LKmhRYyMUQPym8gRi7O', '2025-05-14 11:13:06'),
(4, 'Bizar', 'bizar@gmail.com', '$2y$10$crCY4Kg0ry.kYFNPG7wY3e2CXfEEueukZ3QjoWNNfATcP0vCzcA2q', '2025-07-13 12:24:44'),
(5, 'Okki Dedi', 'okki@gmail.com', '$2y$10$QxLcYuES03XtZSQKX4ufhe.rBVnZzKGuyioDlNzLrYw3jmlhMYWAe', '2025-07-13 13:34:29'),
(6, 'Alvelino Diego', 'diego@gmail.com', '$2y$10$GdlEjUfbutBd9H4BiXk9IuJzqbinxbfVOYudVb27ODVIVKU8gjIXG', '2025-07-13 13:39:07');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `fitness_progress`
--
ALTER TABLE `fitness_progress`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `menu_latihan`
--
ALTER TABLE `menu_latihan`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `fitness_progress`
--
ALTER TABLE `fitness_progress`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT untuk tabel `menu_latihan`
--
ALTER TABLE `menu_latihan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;

--
-- AUTO_INCREMENT untuk tabel `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
